-- Step 2: Create enum types for the gig delivery platform
-- These must be created before tables that reference them

-- User role types
CREATE TYPE public.user_role_type AS ENUM (
  'vendor',
  'shipper', 
  'broker',
  'driver',
  'carrier',
  'admin'
);

-- Job status types
CREATE TYPE public.job_status_type AS ENUM (
  'draft',
  'posted',
  'assigned',
  'in_progress',
  'delivered',
  'completed',
  'cancelled',
  'disputed'
);

-- Cargo types
CREATE TYPE public.cargo_type AS ENUM (
  'general',
  'fragile',
  'hazardous',
  'perishable',
  'oversized',
  'valuable',
  'liquid',
  'electronics'
);

-- Vehicle types
CREATE TYPE public.vehicle_type AS ENUM (
  'van',
  'truck',
  'pickup',
  'motorcycle',
  'bicycle',
  'semi_truck',
  'box_truck',
  'flatbed'
);

-- Payment status types
CREATE TYPE public.payment_status_type AS ENUM (
  'pending',
  'processing',
  'completed',
  'failed',
  'refunded',
  'disputed'
);

-- Document types
CREATE TYPE public.document_type AS ENUM (
  'drivers_license',
  'commercial_license',
  'insurance',
  'registration',
  'business_license',
  'tax_document',
  'proof_of_delivery'
);