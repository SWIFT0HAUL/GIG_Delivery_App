import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (req.method !== 'GET' && req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405, headers: corsHeaders })
  }

  const url = new URL(req.url)
  let placeId = url.searchParams.get('place_id') || ''

  if (req.method === 'POST') {
    try {
      const body = await req.json()
      if (body?.place_id && typeof body.place_id === 'string') {
        placeId = body.place_id
      }
    } catch (_) {}
  }

  if (!placeId) {
    return new Response(JSON.stringify({ error: 'Missing place_id parameter' }), { 
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  // Retrieve API key from secrets
  const apiKey = Deno.env.get('LOCATIONIQ_KEY')
  if (!apiKey) {
    console.error('Missing LOCATIONIQ_KEY')
    return new Response(JSON.stringify({ error: 'Server config error' }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  // Place ID is in format "lat,lon" from autocomplete
  // Use LocationIQ reverse geocoding endpoint
  const [lat, lon] = placeId.split(',')
  
  if (!lat || !lon) {
    return new Response(JSON.stringify({ error: 'Invalid place_id format. Expected lat,lon' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  const detailsUrl = `https://us1.locationiq.com/v1/reverse.php?key=${apiKey}&lat=${lat}&lon=${lon}&format=json&addressdetails=1&normalizeaddress=1`

  const resp = await fetch(detailsUrl, {
    method: 'GET'
  })

  const place = await resp.json()

  if (!resp.ok || !place) {
    console.warn('LocationIQ Reverse Geocoding API error', place)
    return new Response(JSON.stringify({ error: 'Place details error', details: place }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
  const address = place.address || {}
  const addressData: any = {
    formatted_address: place.display_name || '',
    lat: parseFloat(place.lat) || 0,
    lng: parseFloat(place.lon) || 0
  }

  // Parse address components from LocationIQ format
  addressData.street_number = address.house_number || ''
  const route = address.road || ''
  
  if (addressData.street_number && route) {
    addressData.street_number = `${addressData.street_number} ${route}`.trim()
  } else if (route) {
    addressData.street_number = route.trim()
  }
  
  addressData.city = address.city || address.town || address.village || ''
  addressData.state = address.state || ''
  addressData.zip = address.postcode || ''
  addressData.postal_code = address.postcode || ''

  return new Response(JSON.stringify(addressData), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    status: 200,
  })
})
