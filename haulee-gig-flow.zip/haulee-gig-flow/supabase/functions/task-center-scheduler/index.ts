// Task Center Scheduler - Runs every 24 hours to generate recurring tasks
import { createClient } from 'jsr:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('[Task Scheduler] Starting recurring task generation...');

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Call the SQL function to generate recurring tasks
    const { data, error } = await supabase.rpc('fn_generate_recurring_tasks');

    if (error) {
      console.error('[Task Scheduler] Error generating tasks:', error);
      throw error;
    }

    // Get statistics about generated tasks
    const { data: stats, error: statsError } = await supabase
      .from('admin_tasks')
      .select('category, status, auto_generated')
      .eq('auto_generated', true)
      .gte('created_at', new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString());

    const tasksGenerated = stats?.length || 0;

    console.log(`[Task Scheduler] Successfully generated ${tasksGenerated} tasks`);

    // Send notification to super admins about task generation
    if (tasksGenerated > 0) {
      const { data: superAdmins } = await supabase
        .from('profiles')
        .select('id')
        .eq('role_key', 'super_admin')
        .eq('is_active', true)
        .eq('is_approved', true);

      if (superAdmins && superAdmins.length > 0) {
        const notifications = superAdmins.map(admin => ({
          user_id: admin.id,
          type: 'system',
          title: 'Daily Tasks Generated',
          message: `${tasksGenerated} recurring tasks have been automatically generated and assigned.`,
          metadata: {
            task_count: tasksGenerated,
            generated_at: new Date().toISOString()
          }
        }));

        await supabase.from('notifications').insert(notifications);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: `Generated ${tasksGenerated} recurring tasks`,
        timestamp: new Date().toISOString()
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );

  } catch (error) {
    console.error('[Task Scheduler] Fatal error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
