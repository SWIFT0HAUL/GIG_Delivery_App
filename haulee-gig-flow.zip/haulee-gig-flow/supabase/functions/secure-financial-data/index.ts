import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Initialize Supabase client
const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Get encryption key from environment
const encryptionKey = Deno.env.get('ENCRYPTION_KEY');

if (!encryptionKey || encryptionKey.length !== 64) {
  console.error('ENCRYPTION_KEY must be exactly 64 characters (256-bit hex key)');
}

// Crypto utilities for AES-256-GCM encryption
async function getKey(): Promise<CryptoKey> {
  const keyData = new Uint8Array(
    encryptionKey!.match(/.{1,2}/g)!.map(byte => parseInt(byte, 16))
  );
  return await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'AES-GCM' },
    false,
    ['encrypt', 'decrypt']
  );
}

async function encryptData(plaintext: string): Promise<string> {
  if (!plaintext || plaintext.trim() === '') return '';
  
  const key = await getKey();
  const encoder = new TextEncoder();
  const data = encoder.encode(plaintext);
  
  // Generate random IV for each encryption
  const iv = crypto.getRandomValues(new Uint8Array(12));
  
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    key,
    data
  );

  // Combine IV and encrypted data
  const combined = new Uint8Array(iv.length + encrypted.byteLength);
  combined.set(iv);
  combined.set(new Uint8Array(encrypted), iv.length);
  
  // Return base64 encoded string
  return btoa(String.fromCharCode.apply(null, Array.from(combined)));
}

async function decryptData(encryptedData: string): Promise<string> {
  if (!encryptedData || encryptedData.trim() === '') return '';
  
  try {
    const key = await getKey();
    const combined = new Uint8Array(
      atob(encryptedData).split('').map(char => char.charCodeAt(0))
    );
    
    // Extract IV and encrypted data
    const iv = combined.slice(0, 12);
    const encrypted = combined.slice(12);
    
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      encrypted
    );

    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
  } catch (error) {
    console.error('Decryption failed:', error);
    return '[ENCRYPTED_DATA_ERROR]';
  }
}

// Mask decrypted data for display
function maskFinancialData(data: string, type: string): string {
  if (!data || data === '[ENCRYPTED_DATA_ERROR]') return 'N/A';
  
  switch (type) {
    case 'card_number':
      return data.length >= 4 ? `****-****-****-${data.slice(-4)}` : '****';
    case 'account_number':
      return data.length >= 4 ? `****${data.slice(-4)}` : '****';
    case 'routing_number':
      return data.length >= 2 ? `${'*'.repeat(data.length - 2)}${data.slice(-2)}` : '**';
    case 'card_cvv':
      return '***';
    default:
      return data;
  }
}

// Helper function to check if user is admin - SECURE VERSION
async function isUserAdmin(userId: string): Promise<boolean> {
  try {
    // Use the existing security definer function that properly checks user_roles table
    const { data, error } = await supabase.rpc('is_admin', {
      _user_id: userId
    });

    if (error) {
      console.error('Error checking admin status:', error);
      return false;
    }

    console.log('Admin check result for user', userId, ':', data);
    return data === true;
  } catch (error) {
    console.error('Error in isUserAdmin:', error);
    return false;
  }
}

// Log access to financial data
async function logFinancialAccess(userId: string, vendorUserId: string, dataType: string, accessType: string) {
  try {
    await supabase
      .from('financial_data_access_log')
      .insert({
        user_id: userId,
        accessed_vendor_id: vendorUserId,
        data_type: dataType,
        access_type: accessType
      });
  } catch (error) {
    console.error('Failed to log financial access:', error);
  }
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, data, userId } = await req.json();
    
    console.log('Received request:', { action, userId });
    
    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'User ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    switch (action) {
      case 'encrypt_vendor_data': {
        const { vendorData } = data;
        
        // Encrypt sensitive financial fields
        const encryptedData = {
          ...vendorData,
          account_number: vendorData.account_number ? await encryptData(vendorData.account_number) : null,
          routing_number: vendorData.routing_number ? await encryptData(vendorData.routing_number) : null,
          card_number: vendorData.card_number ? await encryptData(vendorData.card_number) : null,
          card_cvv: vendorData.card_cvv ? await encryptData(vendorData.card_cvv) : null,
        };

        // Update the vendor_merchant_onboarding table with encrypted data
        const { error } = await supabase
          .from('vendor_merchant_onboarding')
          .update(encryptedData)
          .eq('user_id', vendorData.user_id);

        if (error) throw error;

        // Log the encryption operation
        await logFinancialAccess(userId, vendorData.user_id, 'vendor_financial_data', 'encrypt');

        return new Response(
          JSON.stringify({ success: true, message: 'Financial data encrypted successfully' }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'decrypt_vendor_data': {
        const { vendorUserId, maskData = true } = data;
        
        // Check if user is admin or owner
        const isAdmin = await isUserAdmin(userId);
        const isOwner = userId === vendorUserId;

        if (!isAdmin && !isOwner) {
          return new Response(
            JSON.stringify({ error: 'Access denied: Insufficient permissions' }),
            { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Get encrypted vendor/merchant data
        const { data: vendorData, error: vendorError } = await supabase
          .from('vendor_merchant_onboarding')
          .select('*')
          .eq('user_id', vendorUserId)
          .single();

        if (vendorError || !vendorData) {
          return new Response(
            JSON.stringify({ error: 'Vendor/Merchant data not found' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Decrypt sensitive fields
        const decryptedAccountNumber = vendorData.account_number ? await decryptData(vendorData.account_number) : '';
        const decryptedRoutingNumber = vendorData.routing_number ? await decryptData(vendorData.routing_number) : '';
        const decryptedCardNumber = vendorData.card_number ? await decryptData(vendorData.card_number) : '';
        const decryptedCardCvv = vendorData.card_cvv ? await decryptData(vendorData.card_cvv) : '';

        // Apply masking based on user role and request
        const responseData = {
          ...vendorData,
          account_number: (maskData && !isAdmin) ? 
            maskFinancialData(decryptedAccountNumber, 'account_number') : decryptedAccountNumber,
          routing_number: (maskData && !isAdmin) ? 
            maskFinancialData(decryptedRoutingNumber, 'routing_number') : decryptedRoutingNumber,
          card_number: (maskData && !isAdmin) ? 
            maskFinancialData(decryptedCardNumber, 'card_number') : decryptedCardNumber,
          card_cvv: maskData ? '***' : decryptedCardCvv, // CVV always masked unless explicitly requested
        };

        // Log the access
        const accessType = isAdmin ? 'admin_decrypt' : 'owner_decrypt';
        await logFinancialAccess(userId, vendorUserId, 'vendor_financial_data', accessType);

        return new Response(
          JSON.stringify({ success: true, data: responseData }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'migrate_existing_data': {
        // Only admins can run data migration
        const isAdmin = await isUserAdmin(userId);

        if (!isAdmin) {
          console.log('Migration access denied for user:', userId);
          return new Response(
            JSON.stringify({ error: 'Access denied: Admin privileges required' }),
            { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        console.log('Starting data migration for admin user:', userId);

        // Get all vendor/merchant data that might have unencrypted financial info
        const { data: allVendors, error: vendorsError } = await supabase
          .from('vendor_merchant_onboarding')
          .select('user_id, account_number, routing_number, card_number, card_cvv');

        if (vendorsError) throw vendorsError;

        let migratedCount = 0;
        const errors = [];

        for (const vendor of allVendors || []) {
          try {
            // Check if data is already encrypted (contains colon separator)
            const isAlreadyEncrypted = (data: string) => {
              if (!data) return true;
              // Check if it looks like base64 encoded data from our encryption
              try {
                const decoded = atob(data);
                return decoded.length >= 12; // IV is 12 bytes minimum
              } catch {
                return false;
              }
            };

            const updates: any = {};
            
            if (vendor.account_number && !isAlreadyEncrypted(vendor.account_number)) {
              updates.account_number = await encryptData(vendor.account_number);
              console.log(`Encrypting account_number for vendor ${vendor.user_id}`);
            }
            if (vendor.routing_number && !isAlreadyEncrypted(vendor.routing_number)) {
              updates.routing_number = await encryptData(vendor.routing_number);
              console.log(`Encrypting routing_number for vendor ${vendor.user_id}`);
            }
            if (vendor.card_number && !isAlreadyEncrypted(vendor.card_number)) {
              updates.card_number = await encryptData(vendor.card_number);
              console.log(`Encrypting card_number for vendor ${vendor.user_id}`);
            }
            if (vendor.card_cvv && !isAlreadyEncrypted(vendor.card_cvv)) {
              updates.card_cvv = await encryptData(vendor.card_cvv);
              console.log(`Encrypting card_cvv for vendor ${vendor.user_id}`);
            }

            if (Object.keys(updates).length > 0) {
              const { error } = await supabase
                .from('vendor_merchant_onboarding')
                .update(updates)
                .eq('user_id', vendor.user_id);

              if (error) throw error;
              migratedCount++;
              console.log(`Successfully migrated data for vendor ${vendor.user_id}`);
            }
          } catch (error: any) {
            console.error(`Failed to migrate data for vendor ${vendor.user_id}:`, error);
            errors.push({ vendor_id: vendor.user_id, error: error?.message || 'Unknown error' });
          }
        }

        // Log the migration
        await logFinancialAccess(userId, 'system', 'bulk_financial_data', 'encrypt_migration');

        console.log(`Migration completed. Migrated: ${migratedCount}, Errors: ${errors.length}`);

        return new Response(
          JSON.stringify({ 
            success: true, 
            migrated_count: migratedCount,
            errors: errors.length > 0 ? errors : undefined
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      default:
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
    }
  } catch (error: any) {
    console.error('Error in secure-financial-data function:', error);
    return new Response(
      JSON.stringify({ error: error?.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});