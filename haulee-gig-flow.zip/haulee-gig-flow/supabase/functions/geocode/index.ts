import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (req.method !== 'GET') {
    return new Response('Method Not Allowed', { status: 405, headers: corsHeaders })
  }

  const url = new URL(req.url)
  const place_id = url.searchParams.get('place_id')
  const address = url.searchParams.get('address')

  if (!place_id && !address) {
    return new Response(JSON.stringify({ error: 'Provide place_id or address' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  const apiKey = Deno.env.get('LOCATIONIQ_KEY')
  if (!apiKey) {
    console.error('Missing LOCATIONIQ_KEY')
    return new Response(JSON.stringify({ error: 'Server config error' }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  let geocodeUrl: string
  if (place_id) {
    // LocationIQ doesn't support place_id in the same way, so we'll treat it as an address search
    geocodeUrl = `https://us1.locationiq.com/v1/search.php?key=${apiKey}&q=${encodeURIComponent(
      place_id
    )}&format=json&limit=1`
  } else {
    geocodeUrl = `https://us1.locationiq.com/v1/search.php?key=${apiKey}&q=${encodeURIComponent(
      address!
    )}&format=json&limit=1`
  }

  let resp: Response | null = null
  let json: any = null

  // Retry a few times on rate limiting to smooth bursts
  for (let attempt = 0; attempt < 3; attempt++) {
    resp = await fetch(geocodeUrl)
    try {
      json = await resp.json()
    } catch {
      json = null
    }

    const isSuccessful = resp.ok && Array.isArray(json) && json.length > 0
    const isRateLimited = resp.status === 429 || (json && typeof json?.error === 'string' && json.error.toLowerCase().includes('rate'))

    if (isSuccessful) break

    if (isRateLimited && attempt < 2) {
      // Exponential backoff: 250ms, 500ms
      await new Promise((r) => setTimeout(r, 250 * (attempt + 1)))
      continue
    }
    break
  }

  if (!resp || !resp.ok || !Array.isArray(json) || json.length === 0) {
    console.warn('LocationIQ Geocode error', json)
    const status = resp?.status === 429 ? 429 : 400
    return new Response(JSON.stringify({ error: 'Geocoding failed', details: json }), {
      status,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  const result = json[0]

  return new Response(
    JSON.stringify({
      address: result.display_name,
      lat: parseFloat(result.lat),
      lng: parseFloat(result.lon),
    }),
    { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
  )
})
