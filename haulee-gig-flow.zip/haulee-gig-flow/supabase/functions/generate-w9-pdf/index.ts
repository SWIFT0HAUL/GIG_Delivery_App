import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const {
      taxpayerName,
      businessName,
      tinType,
      tin,
      address,
      city,
      state,
      zip,
      signatureData,
      userId,
    } = await req.json();

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Generate simple text-based PDF content (in production, use a proper PDF library)
    const pdfContent = generateW9Content({
      taxpayerName,
      businessName,
      tinType,
      tin,
      address,
      city,
      state,
      zip,
    });

    // Upload PDF to storage
    const fileName = `${userId}/${Date.now()}_w9.txt`;
    const { error: uploadError } = await supabaseClient.storage
      .from("w9-forms")
      .upload(fileName, pdfContent, {
        contentType: "text/plain",
        upsert: true,
      });

    if (uploadError) throw uploadError;

    // Save record to database
    const { error: dbError } = await supabaseClient.from("w9_forms").insert({
      user_id: userId,
      taxpayer_name: taxpayerName,
      business_name: businessName,
      tin_type: tinType,
      tin: tin,
      address: address,
      city: city,
      state: state,
      zip: zip,
      signature_data: signatureData,
      pdf_url: fileName,
    });

    if (dbError) throw dbError;

    return new Response(
      JSON.stringify({ success: true, pdfUrl: fileName }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Error generating W-9:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});

function generateW9Content(data: any): string {
  return `
═══════════════════════════════════════════════════════════════
                      FORM W-9
           Request for Taxpayer Identification Number
                  and Certification
═══════════════════════════════════════════════════════════════

1. Name: ${data.taxpayerName}

2. Business name (if different): ${data.businessName || "N/A"}

3. Tax Classification:
   Federal tax classification: ${data.tinType === "EIN" ? "Business Entity" : "Individual/Sole Proprietor"}

4. Address: ${data.address}
   City, State, ZIP: ${data.city}, ${data.state} ${data.zip}

5. Taxpayer Identification Number:
   ${data.tinType}: ${data.tin}

═══════════════════════════════════════════════════════════════

Under penalties of perjury, I certify that:
1. The number shown on this form is my correct taxpayer identification number
2. I am not subject to backup withholding
3. I am a U.S. citizen or other U.S. person
4. The FATCA code(s) entered on this form (if any) indicating that I am exempt from FATCA reporting is correct

Signature: [Digital Signature Provided]
Date: ${new Date().toLocaleDateString()}

═══════════════════════════════════════════════════════════════
Form W-9 (Rev. October 2018)
Department of the Treasury - Internal Revenue Service
═══════════════════════════════════════════════════════════════
  `;
}
