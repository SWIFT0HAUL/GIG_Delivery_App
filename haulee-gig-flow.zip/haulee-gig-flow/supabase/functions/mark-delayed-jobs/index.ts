import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🕐 Starting delayed jobs check...');

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Calculate the threshold time (current time minus 1 minute)
    const oneMinuteAgo = new Date();
    oneMinuteAgo.setMinutes(oneMinuteAgo.getMinutes() - 1);
    const thresholdTime = oneMinuteAgo.toISOString();

    console.log(`⏰ Checking jobs with delivery_time before: ${thresholdTime}`);

    // Find jobs that should be marked as delayed
    // Jobs that are past their delivery window and not already completed/cancelled/delayed
    const { data: jobsToDelay, error: fetchError } = await supabaseClient
      .from('jobs')
      .select('id, title, delivery_time, status, assigned_driver_id')
      .lt('delivery_time', thresholdTime)
      .not('delivery_time', 'is', null)
      .in('status', ['assigned', 'in_progress', 'picked_up', 'posted', 'pending', 'planned', 'scheduled'])
      .order('delivery_time', { ascending: true });

    if (fetchError) {
      console.error('❌ Error fetching jobs:', fetchError);
      throw fetchError;
    }

    if (!jobsToDelay || jobsToDelay.length === 0) {
      console.log('✅ No jobs need to be marked as delayed');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No delayed jobs found',
          checked_at: new Date().toISOString()
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200 
        }
      );
    }

    console.log(`⚠️ Found ${jobsToDelay.length} jobs to mark as delayed`);

    // Update jobs to delayed status
    const jobIds = jobsToDelay.map(job => job.id);
    
    const { data: updatedJobs, error: updateError } = await supabaseClient
      .from('jobs')
      .update({ 
        status: 'delayed',
        updated_at: new Date().toISOString(),
        metadata: supabaseClient.rpc('jsonb_set', {
          target: 'metadata',
          path: '{marked_delayed_at}',
          new_value: JSON.stringify(new Date().toISOString())
        })
      })
      .in('id', jobIds)
      .select('id, title, status, assigned_driver_id');

    if (updateError) {
      console.error('❌ Error updating jobs to delayed:', updateError);
      throw updateError;
    }

    console.log(`✅ Successfully marked ${updatedJobs?.length || 0} jobs as delayed`);

    // Create notifications for affected drivers
    for (const job of jobsToDelay) {
      if (job.assigned_driver_id) {
        const { error: notificationError } = await supabaseClient
          .from('notifications')
          .insert({
            user_id: job.assigned_driver_id,
            type: 'system',
            title: 'Job Marked as Delayed',
            message: `Job "${job.title}" has been marked as delayed because it's past the delivery time window.`,
            metadata: {
              job_id: job.id,
              original_delivery_time: job.delivery_time,
              marked_delayed_at: new Date().toISOString()
            }
          });

        if (notificationError) {
          console.error(`⚠️ Failed to create notification for driver ${job.assigned_driver_id}:`, notificationError);
        }
      }
    }

    console.log('📬 Notifications sent to affected drivers');

    return new Response(
      JSON.stringify({ 
        success: true, 
        jobs_marked_delayed: updatedJobs?.length || 0,
        job_ids: jobIds,
        checked_at: new Date().toISOString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('❌ Error in mark-delayed-jobs function:', error);
    return new Response(
      JSON.stringify({ 
        error: error.message,
        success: false 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
