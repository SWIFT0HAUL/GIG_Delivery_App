import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      throw new Error('No authorization header')
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      { global: { headers: { Authorization: authHeader } } }
    )

    // Verify user is authenticated and is admin
    const { data: { user }, error: userError } = await supabaseClient.auth.getUser()
    if (userError || !user) {
      throw new Error('Unauthorized')
    }

    // Check if user is admin
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('role_key')
      .eq('id', user.id)
      .single()

    if (profile?.role_key !== 'admin' && profile?.role_key !== 'super_admin') {
      throw new Error('Unauthorized: Admin access required')
    }

    const { apiKey } = await req.json()

    if (!apiKey || typeof apiKey !== 'string' || apiKey.length < 10) {
      throw new Error('Invalid API key format')
    }

    // Update Supabase secret using Management API
    const supabaseProjectRef = Deno.env.get('SUPABASE_PROJECT_REF') || 'cqoydkxlonzobykwjcin'
    const supabaseAccessToken = Deno.env.get('SUPABASE_ACCESS_TOKEN')

    if (!supabaseAccessToken) {
      console.warn('SUPABASE_ACCESS_TOKEN not configured - cannot update secrets')
      return new Response(
        JSON.stringify({ 
          success: false, 
          message: 'Secret update not configured. Please set SUPABASE_ACCESS_TOKEN to enable this feature.',
          apiKeyStored: apiKey.substring(0, 10) + '***'
        }),
        { 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200
        }
      )
    }

    // Update the secret via Supabase Management API
    const secretUpdateResponse = await fetch(
      `https://api.supabase.com/v1/projects/${supabaseProjectRef}/secrets`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${supabaseAccessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify([
          {
            name: 'GOOGLE_MAPS_API_KEY',
            value: apiKey
          }
        ])
      }
    )

    if (!secretUpdateResponse.ok) {
      const error = await secretUpdateResponse.text()
      console.error('Failed to update secret:', error)
      throw new Error('Failed to update Supabase secret')
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Google Maps API key updated successfully in Supabase secrets',
        note: 'Edge functions will use the new key after redeployment'
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ 
        error: error.message || 'Internal server error',
        success: false
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400
      }
    )
  }
})
