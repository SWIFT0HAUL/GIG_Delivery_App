import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface Job {
  id: string
  pickup_location: any
  delivery_location: any
  estimated_duration?: number
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    console.log('🔄 Starting job duration recalculation...')

    // Create Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseKey)

    // Get Google Maps API key
    const googleMapsApiKey = Deno.env.get('GOOGLE_MAPS_API_KEY')
    if (!googleMapsApiKey) {
      console.error('❌ Missing GOOGLE_MAPS_API_KEY')
      return new Response(
        JSON.stringify({ error: 'Server configuration error: Missing API key' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Fetch all jobs with locations
    console.log('📋 Fetching jobs from database...')
    const { data: jobs, error: fetchError } = await supabase
      .from('jobs')
      .select('id, pickup_location, delivery_location, estimated_duration')
      .not('pickup_location', 'is', null)
      .not('delivery_location', 'is', null)

    if (fetchError) {
      console.error('❌ Error fetching jobs:', fetchError)
      return new Response(
        JSON.stringify({ error: 'Failed to fetch jobs', details: fetchError.message }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    console.log(`📊 Found ${jobs?.length || 0} jobs to process`)

    if (!jobs || jobs.length === 0) {
      return new Response(
        JSON.stringify({ 
          message: 'No jobs found with valid locations',
          processed: 0,
          updated: 0,
          failed: 0
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    let updated = 0
    let failed = 0
    let skipped = 0
    const failedJobs: Array<{ id: string, reason: string }> = []

    // Process each job
    for (const job of jobs) {
      try {
        // Extract addresses from location objects
        const pickupAddress = getAddress(job.pickup_location)
        const deliveryAddress = getAddress(job.delivery_location)

        if (!pickupAddress || !deliveryAddress) {
          console.warn(`⚠️ Job ${job.id}: Missing address information`)
          skipped++
          failedJobs.push({ id: job.id, reason: 'Missing address data' })
          continue
        }

        // Call Google Directions API
        const dirUrl = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(
          pickupAddress
        )}&destination=${encodeURIComponent(
          deliveryAddress
        )}&mode=driving&key=${googleMapsApiKey}`

        const response = await fetch(dirUrl)
        const data = await response.json()

        if (data.status !== 'OK') {
          console.warn(`⚠️ Job ${job.id}: Google API returned status ${data.status}`)
          failed++
          failedJobs.push({ id: job.id, reason: `API status: ${data.status}` })
          continue
        }

        // Calculate total duration in minutes
        if (data.routes && data.routes.length > 0) {
          const route = data.routes[0]
          let totalDurationSeconds = 0

          route.legs.forEach((leg: any) => {
            totalDurationSeconds += leg.duration.value
          })

          const durationMinutes = Math.round(totalDurationSeconds / 60)

          // Update job in database
          const { error: updateError } = await supabase
            .from('jobs')
            .update({ estimated_duration: durationMinutes })
            .eq('id', job.id)

          if (updateError) {
            console.error(`❌ Job ${job.id}: Failed to update - ${updateError.message}`)
            failed++
            failedJobs.push({ id: job.id, reason: updateError.message })
          } else {
            console.log(`✅ Job ${job.id}: Updated duration to ${durationMinutes} minutes`)
            updated++
          }
        } else {
          console.warn(`⚠️ Job ${job.id}: No routes found in response`)
          failed++
          failedJobs.push({ id: job.id, reason: 'No routes found' })
        }

        // Add a small delay to avoid rate limiting
        await new Promise(resolve => setTimeout(resolve, 100))

      } catch (error) {
        console.error(`❌ Job ${job.id}: Error processing -`, error)
        failed++
        failedJobs.push({ 
          id: job.id, 
          reason: error instanceof Error ? error.message : 'Unknown error' 
        })
      }
    }

    const result = {
      message: 'Job duration recalculation complete',
      total: jobs.length,
      updated,
      failed,
      skipped,
      failedJobs: failedJobs.slice(0, 10) // Return first 10 failed jobs for review
    }

    console.log('✨ Recalculation complete:', result)

    return new Response(
      JSON.stringify(result),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('❌ Fatal error:', error)
    return new Response(
      JSON.stringify({ 
        error: 'Internal server error', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

// Helper function to extract address from location object
function getAddress(location: any): string | null {
  if (!location) return null
  if (typeof location === 'string') return location
  if (location.address) return location.address
  if (location.formatted_address) return location.formatted_address
  
  // Try to construct from parts
  const parts = []
  if (location.street_number) parts.push(location.street_number)
  if (location.street) parts.push(location.street)
  if (location.city) parts.push(location.city)
  if (location.state) parts.push(location.state)
  if (location.zip || location.postal_code) parts.push(location.zip || location.postal_code)
  
  return parts.length > 0 ? parts.join(', ') : null
}
