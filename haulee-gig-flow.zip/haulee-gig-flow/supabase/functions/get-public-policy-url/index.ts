// Deno Deploy / Supabase Edge Function: get-public-policy-url
// Returns a signed URL for the latest approved Terms/Privacy/Consent policy PDF

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      return new Response(JSON.stringify({ error: "Server misconfiguration" }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
        status: 500,
      });
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Find the latest approved policy document
    const { data: docs, error: docsError } = await supabase
      .from("admin_documents")
      .select("file_path, document_name, category, is_approved, is_archived, created_at")
      .eq("category", "policy")
      .eq("is_approved", true)
      .eq("is_archived", false)
      .or(
        [
          "document_name.ilike.%terms%policy%",
          "document_name.ilike.%terms%policies%",
          "document_name.ilike.%privacy%consent%",
          "document_name.ilike.%terms%privacy%",
          "document_name.ilike.%policy%privacy%consent%",
        ].join(",")
      )
      .order("created_at", { ascending: false })
      .limit(1);

    if (docsError) {
      return new Response(JSON.stringify({ error: docsError.message }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
        status: 400,
      });
    }

    if (!docs || docs.length === 0) {
      return new Response(JSON.stringify({ error: "Document not found" }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
        status: 404,
      });
    }

    const filePath = docs[0].file_path as string;

    const { data: signed, error: signError } = await supabase.storage
      .from("admin_docs")
      .createSignedUrl(filePath, 60 * 60); // 1 hour

    if (signError || !signed?.signedUrl) {
      return new Response(JSON.stringify({ error: signError?.message || "Failed to sign URL" }), {
        headers: { "Content-Type": "application/json", ...corsHeaders },
        status: 500,
      });
    }

    return new Response(JSON.stringify({ url: signed.signedUrl }), {
      headers: { "Content-Type": "application/json", ...corsHeaders },
      status: 200,
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e?.message || "Unknown error" }), {
      headers: { "Content-Type": "application/json", ...corsHeaders },
      status: 500,
    });
  }
});
