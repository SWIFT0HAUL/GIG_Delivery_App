import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.58.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface JobRow {
  id: string
  title: string
  status: string | null
  pickup_location: any
  delivery_location: any
  estimated_duration: number | null
  distance_miles: number | null
}

function buildAddress(loc: any): string | null {
  if (!loc) return null
  if (typeof loc === 'string') return loc
  if (loc.address && String(loc.address).length > 0) return String(loc.address)
  const parts = [loc.street, loc.city, loc.state, loc.zipCode].filter(Boolean)
  if (parts.length) return parts.join(', ')
  return null
}

async function getDirections(origin: string, destination: string) {
  const apiKey = Deno.env.get('GOOGLE_MAPS_API_KEY')
  if (!apiKey) throw new Error('Missing GOOGLE_MAPS_API_KEY')
  const url = `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&mode=driving&key=${apiKey}`
  const res = await fetch(url)
  const data = await res.json()
  if (data.status !== 'OK') {
    throw new Error(`Directions failed: ${data.status}`)
  }
  const route = data.routes?.[0]
  const legs = route?.legs || []
  const totalMeters = legs.reduce((sum: number, l: any) => sum + (l.distance?.value ?? 0), 0)
  const totalSeconds = legs.reduce((sum: number, l: any) => sum + (l.duration?.value ?? 0), 0)
  const miles = totalMeters / 1609.34
  const minutes = Math.round(totalSeconds / 60)
  return { miles, minutes }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Optional query params: status, limit
    const url = new URL(req.url)
    const targetStatus = url.searchParams.get('status') ?? 'pending'
    const limit = Number(url.searchParams.get('limit') ?? '50')

    // Fetch candidate jobs
    const { data: jobs, error } = await supabase
      .from('jobs')
      .select('id,title,status,pickup_location,delivery_location,estimated_duration,distance_miles')
      .eq('status', targetStatus)
      .limit(limit)

    if (error) throw error

    const updates: Array<{ id: string; estimated_duration: number; distance_miles: number }> = []
    const skipped: Array<{ id: string; reason: string }> = []

    for (const job of (jobs ?? []) as JobRow[]) {
      const origin = buildAddress(job.pickup_location)
      const destination = buildAddress(job.delivery_location)
      if (!origin || !destination) {
        skipped.push({ id: job.id, reason: 'missing addresses' })
        continue
      }

      try {
        const { miles, minutes } = await getDirections(origin, destination)
        // Sanity check
        const mph = minutes > 0 ? (miles * 60) / minutes : 999
        if (mph < 15 || mph > 85) {
          // Still odd, but update with heuristic to avoid absurd values
          const heuristicMinutes = Math.round((miles / 55) * 60)
          updates.push({ id: job.id, estimated_duration: heuristicMinutes, distance_miles: Number(miles.toFixed(2)) })
        } else {
          updates.push({ id: job.id, estimated_duration: minutes, distance_miles: Number(miles.toFixed(2)) })
        }
        // Gentle rate limit to respect API quota
        await new Promise((r) => setTimeout(r, 150))
      } catch (e) {
        skipped.push({ id: job.id, reason: (e as Error).message })
      }
    }

    // Batch update - update each job individually to avoid constraint issues
    for (const u of updates) {
      const { error: upErr } = await supabase
        .from('jobs')
        .update({
          estimated_duration: u.estimated_duration,
          distance_miles: u.distance_miles,
          updated_at: new Date().toISOString(),
        })
        .eq('id', u.id)
      
      if (upErr) {
        console.error('Failed to update job', u.id, upErr)
        skipped.push({ id: u.id, reason: upErr.message })
      }
    }

    return new Response(
      JSON.stringify({ success: true, updated: updates.length, skipped }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (err) {
    console.error('backfill-job-durations error', err)
    return new Response(
      JSON.stringify({ success: false, error: (err as Error).message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
