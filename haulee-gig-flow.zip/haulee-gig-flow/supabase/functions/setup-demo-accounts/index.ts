import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface DemoAccount {
  email: string;
  password: string;
  role: string;
  firstName: string;
  lastName: string;
  companyName?: string;
}

const DEMO_ACCOUNTS: DemoAccount[] = [
  {
    email: "demo.driver@haulee.com",
    password: "Demo123!@#",
    role: "driver",
    firstName: "Demo",
    lastName: "Driver",
  },
  {
    email: "demo.shipper@haulee.com",
    password: "Demo123!@#",
    role: "shipper",
    firstName: "Demo",
    lastName: "Shipper",
    companyName: "Demo Shipping Co.",
  },
  {
    email: "demo.carrier@haulee.com",
    password: "Demo123!@#",
    role: "carrier",
    firstName: "Demo",
    lastName: "Carrier",
    companyName: "Demo Carrier LLC",
  },
  {
    email: "demo.broker@haulee.com",
    password: "Demo123!@#",
    role: "broker",
    firstName: "Demo",
    lastName: "Broker",
    companyName: "Demo Brokerage Inc.",
  },
  {
    email: "demo.vendor@haulee.com",
    password: "Demo123!@#",
    role: "vendor_merchant",
    firstName: "Demo",
    lastName: "Vendor",
    companyName: "Demo Vendors Corp.",
  },
  {
    email: "demo.admin@haulee.com",
    password: "Demo123!@#",
    role: "admin",
    firstName: "Demo",
    lastName: "Admin",
  },
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    const results = [];

    for (const account of DEMO_ACCOUNTS) {
      try {
        // Check if user already exists
        const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
        const userExists = existingUsers?.users?.some(u => u.email === account.email);

        if (userExists) {
          console.log(`User ${account.email} already exists, skipping...`);
          results.push({ email: account.email, status: "exists" });
          continue;
        }

        // Get role ID
        const { data: roleData, error: roleError } = await supabaseAdmin
          .from("roles")
          .select("id")
          .eq("role_key", account.role)
          .single();

        if (roleError) {
          throw new Error(`Role not found: ${account.role}`);
        }

        // Create user in auth
        const { data: userData, error: userError } = await supabaseAdmin.auth.admin.createUser({
          email: account.email,
          password: account.password,
          email_confirm: true,
          user_metadata: {
            full_name: `${account.firstName} ${account.lastName}`,
            first_name: account.firstName,
            last_name: account.lastName,
            company_name: account.companyName,
            role: account.role,
          },
        });

        if (userError) throw userError;
        if (!userData.user) throw new Error("User creation failed");

        // Update profile
        const { error: profileError } = await supabaseAdmin
          .from("profiles")
          .update({
            role_id: roleData.id,
            role_key: account.role,
            onboarding_complete: true,
            is_approved: true,
            is_active: true,
            first_login_completed: true,
          })
          .eq("id", userData.user.id);

        if (profileError) throw profileError;

        // Create role-specific profiles
        if (account.role === "shipper") {
          await supabaseAdmin.from("shipper_profiles").insert({
            user_id: userData.user.id,
            company_name: account.companyName,
          });
        } else if (account.role === "carrier") {
          await supabaseAdmin.from("carrier_company_status").insert({
            user_id: userData.user.id,
            company_name: account.companyName,
            company_status: "approved",
          });
        } else if (account.role === "broker") {
          await supabaseAdmin.from("broker_profiles").insert({
            user_id: userData.user.id,
            company_name: account.companyName,
          });
        } else if (account.role === "vendor_merchant") {
          await supabaseAdmin.from("vendor_profiles").insert({
            user_id: userData.user.id,
            company_name: account.companyName,
          });
        }

        results.push({ email: account.email, status: "created", id: userData.user.id });
      } catch (error) {
        console.error(`Error creating ${account.email}:`, error);
        results.push({ email: account.email, status: "error", error: error.message });
      }
    }

    // Create sample jobs for demo shipper
    const { data: shipperUser } = await supabaseAdmin.auth.admin.listUsers();
    const demoShipper = shipperUser?.users?.find(u => u.email === "demo.shipper@haulee.com");

    if (demoShipper) {
      const sampleJobs = [
        {
          title: "Electronics Delivery - Downtown",
          description: "Urgent delivery of electronics equipment to downtown office building",
          status: "in_progress",
          shipper_id: demoShipper.id,
          created_by: demoShipper.id,
          pickup_address: "123 Warehouse Ave, San Francisco, CA 94102",
          delivery_address: "456 Office Plaza, San Francisco, CA 94104",
          pay_amount: 250.0,
          vehicle_type: "Van",
          carrier_company_name: "Demo Carrier LLC",
        },
        {
          title: "Furniture Transport - Residential",
          description: "Moving furniture set from warehouse to residential address",
          status: "posted",
          shipper_id: demoShipper.id,
          created_by: demoShipper.id,
          pickup_address: "789 Storage Dr, Oakland, CA 94601",
          delivery_address: "321 Residential St, Berkeley, CA 94702",
          pay_amount: 350.0,
          vehicle_type: "Box Truck",
        },
        {
          title: "Medical Supplies - Hospital",
          description: "Time-sensitive medical supplies delivery to hospital",
          status: "delivered",
          shipper_id: demoShipper.id,
          created_by: demoShipper.id,
          pickup_address: "555 Medical Supply Way, San Jose, CA 95110",
          delivery_address: "777 Hospital Blvd, San Jose, CA 95112",
          pay_amount: 450.0,
          vehicle_type: "Refrigerated Truck",
          carrier_company_name: "Demo Carrier LLC",
        },
      ];

      for (const job of sampleJobs) {
        await supabaseAdmin.from("jobs").insert(job).select().single();
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (error) {
    console.error("Setup error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 400,
    });
  }
});
