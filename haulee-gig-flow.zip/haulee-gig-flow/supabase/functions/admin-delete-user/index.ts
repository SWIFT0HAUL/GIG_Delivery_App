import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.4";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DeleteUserRequest {
  userId: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Get the authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Missing authorization header' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Create supabase client with service role key for auth admin operations
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

    // Create regular client to verify the requesting user
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseAnonKey, {
      global: {
        headers: {
          Authorization: authHeader,
        },
      },
    });

    // Extract user info from JWT (already verified by Supabase when verify_jwt=true)
    const token = authHeader.replace('Bearer ', '').trim();
    const parts = token.split('.');
    if (parts.length !== 3) {
      return new Response(
        JSON.stringify({ error: 'Invalid token format' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Base64url decode payload
    const base64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const payloadJson = atob(base64);
    const payload = JSON.parse(payloadJson);

    const requesterId: string | undefined = payload.sub;
    const requesterEmail: string | undefined = payload.email;

    if (!requesterId) {
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if the requesting user is a super admin via RBAC
    const { data: isSuperAdmin, error: roleError } = await supabase.rpc('has_role', {
      _user_id: requesterId,
      _role: 'super_admin'
    });

    if (roleError || !isSuperAdmin) {
      return new Response(
        JSON.stringify({ error: 'Access denied. Super admin privileges required.' }),
        { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { userId }: DeleteUserRequest = await req.json();

    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'User ID is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Prevent self-deletion
    if (userId === requesterId) {
      return new Response(
        JSON.stringify({ error: 'Cannot delete your own account' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get user details for logging before deletion
    const { data: userToDelete, error: fetchError } = await supabase
      .from('profiles')
      .select('email, full_name, role_key')
      .eq('id', userId)
      .single();

    if (fetchError) {
      return new Response(
        JSON.stringify({ error: 'User not found' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Super admin ${requesterEmail ?? requesterId} attempting to delete user ${userToDelete.email}`);

    // First handle foreign key constraints by nullifying or deleting related records
    // Update jobs created_by to null before deleting user
    const { error: jobsUpdateError } = await supabaseAdmin
      .from('jobs')
      .update({ created_by: null })
      .eq('created_by', userId);

    if (jobsUpdateError) {
      console.error('Error updating jobs created_by:', jobsUpdateError);
      return new Response(
        JSON.stringify({ error: `Failed to update related jobs: ${jobsUpdateError.message}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Delete from public tables using the secure function (before auth deletion)
    const { error: publicDeleteError } = await supabase.rpc('delete_user_account', {
      target_user_id: userId
    });

    if (publicDeleteError) {
      console.error('Error deleting from public tables:', publicDeleteError);
      return new Response(
        JSON.stringify({ error: `Failed to clean up user data: ${publicDeleteError.message}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Finally delete from auth.users using admin client
    const { error: authDeleteError } = await supabaseAdmin.auth.admin.deleteUser(userId);

    if (authDeleteError) {
      console.error('Error deleting from auth.users:', authDeleteError);
      return new Response(
        JSON.stringify({ error: `Failed to delete user from authentication system: ${authDeleteError.message}` }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Attempt to log the deletion (optional, ignore failures if table/policy not available)
    try {
      await supabase
        .from('audit_logs')
        .insert({
          user_id: requesterId,
          action: 'DELETE_USER',
          entity_type: 'user',
          entity_id: userId,
          details: {
            deleted_user_email: userToDelete.email,
            deleted_user_name: userToDelete.full_name,
            deleted_user_role: userToDelete.role_key,
            deleted_by: requesterId,
            deleted_by_email: requesterEmail
          }
        });
    } catch (e) {
      console.warn('Audit log insert failed (non-blocking):', e?.message || e);
    }

    console.log(`Successfully deleted user ${userToDelete.email} from Supabase`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'User successfully deleted from Supabase',
        deletedUser: {
          email: userToDelete.email,
          name: userToDelete.full_name
        }
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in admin-delete-user function:', error);
    return new Response(
      JSON.stringify({ error: `Internal server error: ${error.message}` }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
};

Deno.serve(handler);