import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    console.log('Starting route transition check at:', new Date().toISOString());

    // Call the database function to transition jobs
    const { data, error } = await supabaseClient.rpc('transition_planned_jobs_to_active');

    if (error) {
      console.error('Database function error:', error);
      throw error;
    }

    console.log('Transition results:', data);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Route transition check completed',
        transitions_made: data?.transitions_made || 0,
        conflicts_detected: data?.conflicts_detected || 0,
        checked_at: data?.checked_at
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error transitioning jobs:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
