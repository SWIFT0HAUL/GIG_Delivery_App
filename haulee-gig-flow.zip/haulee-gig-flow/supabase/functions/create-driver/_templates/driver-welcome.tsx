import {
  Body,
  Container,
  Head,
  Heading,
  Html,
  Link,
  Preview,
  Text,
} from 'npm:@react-email/components@0.0.22';
import * as React from 'npm:react@18.3.1';

interface DriverWelcomeEmailProps {
  driver_name: string;
  email: string;
  temp_password: string;
  role: string;
  login_url: string;
}

export const DriverWelcomeEmail = ({
  driver_name,
  email,
  temp_password,
  role,
  login_url,
}: DriverWelcomeEmailProps) => (
  <Html>
    <Head />
    <Preview>Welcome to SwiftoHaul - Account Created</Preview>
    <Body style={main}>
      <Container style={container}>
        <Heading style={h1}>Welcome to SwiftoHaul!</Heading>
        <Text style={text}>
          Hello {driver_name},
        </Text>
        <Text style={text}>
          Your account has been created with the role of <strong>{role}</strong>.
        </Text>
        <Text style={text}>
          Your login credentials are:
        </Text>
        <Container style={credentialsBox}>
          <Text style={credentialsText}>
            <strong>Email:</strong> {email}
          </Text>
          <Text style={credentialsText}>
            <strong>Temporary Password:</strong> {temp_password}
          </Text>
        </Container>
        <Text style={warningText}>
          <strong>Important:</strong> Please change your password after your first login for security.
        </Text>
        <Container style={buttonContainer}>
          <Link
            href={login_url}
            target="_blank"
            style={button}
          >
            Login to Your Account
          </Link>
        </Container>
        <Text style={text}>
          If you have any questions, please contact our support team.
        </Text>
        <Text style={text}>
          Best regards,<br/>
          The SwiftoHaul Team
        </Text>
      </Container>
    </Body>
  </Html>
);

export default DriverWelcomeEmail;

const main = {
  backgroundColor: '#ffffff',
};

const container = {
  paddingLeft: '12px',
  paddingRight: '12px',
  margin: '0 auto',
};

const h1 = {
  color: '#333',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '24px',
  fontWeight: 'bold',
  margin: '40px 0',
  padding: '0',
};

const link = {
  color: '#2754C5',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  textDecoration: 'underline',
};

const text = {
  color: '#333',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  margin: '24px 0',
  lineHeight: '24px',
};

const credentialsBox = {
  backgroundColor: '#f5f5f5',
  padding: '15px',
  borderRadius: '5px',
  margin: '20px 0',
};

const credentialsText = {
  color: '#333',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  margin: '8px 0',
  lineHeight: '24px',
};

const warningText = {
  color: '#d32f2f',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  margin: '24px 0',
  lineHeight: '24px',
};

const buttonContainer = {
  textAlign: 'center' as const,
  margin: '30px 0',
};

const button = {
  backgroundColor: '#1976d2',
  color: '#ffffff',
  padding: '12px 24px',
  textDecoration: 'none',
  borderRadius: '5px',
  display: 'inline-block',
  fontFamily:
    "-apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif",
  fontSize: '14px',
  fontWeight: 'bold',
};
