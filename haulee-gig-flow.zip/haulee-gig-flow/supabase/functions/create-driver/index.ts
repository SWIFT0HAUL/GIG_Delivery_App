import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import React from 'npm:react@18.3.1';
import { Resend } from 'npm:resend@4.0.0';
import { renderAsync } from 'npm:@react-email/components@0.0.22';
import { DriverWelcomeEmail } from './_templates/driver-welcome.tsx';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    );

    // Get the authenticated user (carrier) making the request
    const authHeader = req.headers.get('Authorization');
    let carrierId = null;
    let carrierName = null;

    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: { user: requestingUser } } = await supabaseAdmin.auth.getUser(token);
      
      if (requestingUser) {
        carrierId = requestingUser.id;
        const { data: carrierProfile } = await supabaseAdmin
          .from('profiles')
          .select('full_name')
          .eq('id', carrierId)
          .single();
        carrierName = carrierProfile?.full_name;
      }
    }

    const { 
      email, 
      first_name, 
      last_name, 
      middle_name,
      full_name: providedFullName,
      phone, 
      vehicle_assignment, 
      role_key, 
      sub_role,
      password: providedPassword 
    } = await req.json();

    // Build full_name from parts or use provided full_name
    let full_name = providedFullName;
    if (!full_name && (first_name || last_name)) {
      const nameParts = [first_name, middle_name, last_name].filter(Boolean);
      full_name = nameParts.join(' ');
    }

    if (!email || !full_name || !phone) {
      return new Response(
        JSON.stringify({
          error: 'Missing required fields: email, name (first/last or full_name), phone'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Check if user already exists
    const { data: existingUsers } = await supabaseAdmin.auth.admin.listUsers();
    const userExists = existingUsers?.users?.some(user => user.email === email);

    if (userExists) {
      return new Response(
        JSON.stringify({
          error: 'A driver with this email address already exists. Please use a different email.'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Use provided password or generate a fallback (should always be provided from frontend)
    let tempPassword = providedPassword;
    
    if (!tempPassword) {
      // Fallback: Generate 12-character password with at least one special character
      const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      const lowercase = 'abcdefghijkmnopqrstuvwxyz';
      const numbers = '0123456789';
      const special = '!@#$%^&*';
      const allChars = uppercase + lowercase + numbers + special;
      
      let password = '';
      password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
      password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
      password += numbers.charAt(Math.floor(Math.random() * numbers.length));
      password += special.charAt(Math.floor(Math.random() * special.length));
      
      for (let i = password.length; i < 12; i++) {
        password += allChars.charAt(Math.floor(Math.random() * allChars.length));
      }
      
      tempPassword = password.split('').sort(() => Math.random() - 0.5).join('');
      console.log('Warning: No password provided, generated fallback password');
    }

    // Create the user using admin API
    const { data: userData, error: userError } = await supabaseAdmin.auth.admin.createUser({
      email,
      password: tempPassword,
      email_confirm: true,
      user_metadata: {
        full_name,
        first_name,
        last_name,
        middle_name,
        phone,
        vehicle_assignment
      }
    });

    if (userError) {
      console.error('Error creating user:', userError);
      return new Response(
        JSON.stringify({
          error: userError.message || 'Failed to create driver account'
        }),
        {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Update the profile with role and additional details
    if (userData.user) {
      // Update profile basic info
      const { error: profileError } = await supabaseAdmin
        .from('profiles')
        .update({
          full_name,
          phone,
          is_active: false,
          is_approved: false,
          onboarding_complete: false
        })
        .eq('id', userData.user.id);

      if (profileError) throw profileError;

      // Use RPC to properly assign role
      const { error: roleError } = await supabaseAdmin.rpc('update_user_role', {
        p_user_id: userData.user.id,
        p_new_role: role_key || 'driver'
      });

      if (roleError) throw roleError;

      // Create carrier-driver relationship if carrier is creating the driver
      if (carrierId) {
        const { error: relationshipError } = await supabaseAdmin
          .from('carrier_drivers')
          .insert({
            carrier_id: carrierId,
            driver_id: userData.user.id,
            vehicle_assignment: vehicle_assignment || null,
            hire_date: new Date().toISOString()
          });

        if (relationshipError) {
          console.error('Error creating carrier-driver relationship:', relationshipError);
          // Don't fail the entire operation, just log the error
        }
      }

      // Send welcome email to the driver
      try {
        const resend = new Resend(Deno.env.get('RESEND_API_KEY'));
        const fromEmail = Deno.env.get('RESEND_FROM_EMAIL') || 'onboarding@resend.dev';
        
        // Get the app URL from environment or use default
        const appUrl = Deno.env.get('APP_URL') || 'https://083b4646-0999-4abf-8b63-fba56b8fc586.lovableproject.com';
        const loginUrl = `${appUrl}/auth`;

        const html = await renderAsync(
          React.createElement(DriverWelcomeEmail, {
            driver_name: full_name,
            email: email,
            temp_password: tempPassword,
            role: role_key || 'driver',
            login_url: loginUrl
          })
        );

        await resend.emails.send({
          from: fromEmail,
          to: [email],
          subject: 'Welcome - Your Driver Account Has Been Created',
          html
        });

        console.log('Welcome email sent to:', email);
      } catch (emailError) {
        // Log error but don't fail the entire operation
        console.error('Error sending welcome email:', emailError);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        user: userData.user,
        message: 'Driver created successfully'
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  } catch (error) {
    console.error('Error in create-driver function:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'An unexpected error occurred'
      }),
      {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );
  }
});
