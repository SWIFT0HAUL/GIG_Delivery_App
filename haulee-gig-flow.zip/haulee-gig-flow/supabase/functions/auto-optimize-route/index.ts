import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.58.0';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Timezone offset map (in hours from UTC)
const TIMEZONE_OFFSETS: Record<string, number> = {
  'UTC': 0,
  'EST': -5,
  'PST': -8,
  'GMT': 0,
  'CST': -6,
  'MST': -7,
};

// Convert UTC date to platform timezone
function convertToTimezone(utcDate: Date, timezone: string): Date {
  const offset = TIMEZONE_OFFSETS[timezone] || 0;
  const localDate = new Date(utcDate.getTime() + offset * 60 * 60 * 1000);
  return localDate;
}

// Get platform timezone setting
async function getPlatformTimezone(supabase: any): Promise<string> {
  const { data, error } = await supabase
    .from('platform_settings')
    .select('setting_value')
    .eq('setting_key', 'systemTimezone')
    .eq('status', 'active')
    .single();
  
  if (error || !data) {
    console.log('[Timezone] Using default UTC timezone');
    return 'UTC';
  }
  
  const timezone = data.setting_value?.toString() || 'UTC';
  console.log('[Timezone] Platform timezone:', timezone);
  return timezone;
}

interface Job {
  id: string;
  title: string;
  pickup_time: string;
  delivery_time: string;
  pickup_location: any;
  delivery_location: any;
  distance_miles: number;
  estimated_duration: number;
}

interface Stop {
  jobId: string;
  jobTitle: string;
  type: 'pickup' | 'dropoff';
  location: any;
  scheduledTime: Date;
}

// Haversine distance calculation
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

function getCoordinates(location: any): { lat: number; lng: number } | null {
  if (!location) return null;
  
  if (location.coordinates) {
    return {
      lat: location.coordinates.lat || location.coordinates.latitude,
      lng: location.coordinates.lng || location.coordinates.longitude
    };
  }
  
  if (location.lat && location.lng) {
    return { lat: location.lat, lng: location.lng };
  }
  
  if (location.latitude && location.longitude) {
    return { lat: location.latitude, lng: location.longitude };
  }
  
  return null;
}

function estimateTravelTime(from: any, to: any): number {
  const fromCoords = getCoordinates(from);
  const toCoords = getCoordinates(to);
  
  if (!fromCoords || !toCoords) {
    return 15; // Default fallback
  }
  
  const distanceMiles = calculateDistance(
    fromCoords.lat, fromCoords.lng,
    toCoords.lat, toCoords.lng
  );
  
  // Assume 30 mph average speed + 5 min buffer per stop
  const travelMinutes = (distanceMiles / 30) * 60 + 5;
  return Math.ceil(travelMinutes);
}

// Generate all possible stop sequences
function generateStopSequences(jobs: Job[], timezone: string): Stop[][] {
  const sequences: Stop[][] = [];
  
  if (jobs.length === 1) {
    const job = jobs[0];
    const pickupTime = convertToTimezone(new Date(job.pickup_time), timezone);
    const deliveryTime = convertToTimezone(new Date(job.delivery_time), timezone);
    sequences.push([
      { jobId: job.id, jobTitle: job.title, type: 'pickup', location: job.pickup_location, scheduledTime: pickupTime },
      { jobId: job.id, jobTitle: job.title, type: 'dropoff', location: job.delivery_location, scheduledTime: deliveryTime }
    ]);
  } else if (jobs.length === 2) {
    const [j1, j2] = jobs;
    
    // Convert times to platform timezone
    const p1Time = convertToTimezone(new Date(j1.pickup_time), timezone);
    const d1Time = convertToTimezone(new Date(j1.delivery_time), timezone);
    const p2Time = convertToTimezone(new Date(j2.pickup_time), timezone);
    const d2Time = convertToTimezone(new Date(j2.delivery_time), timezone);
    
    // P1 → D1 → P2 → D2
    sequences.push([
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: p1Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: d1Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: p2Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: d2Time }
    ]);
    
    // P1 → P2 → D1 → D2
    sequences.push([
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: p1Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: p2Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: d1Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: d2Time }
    ]);
    
    // P1 → P2 → D2 → D1
    sequences.push([
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: p1Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: p2Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: d2Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: d1Time }
    ]);
    
    // P2 → P1 → D1 → D2
    sequences.push([
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: p2Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: p1Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: d1Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: d2Time }
    ]);
    
    // P2 → P1 → D2 → D1
    sequences.push([
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: p2Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: p1Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: d2Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: d1Time }
    ]);
    
    // P2 → D2 → P1 → D1
    sequences.push([
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: p2Time },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: d2Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: p1Time },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: d1Time }
    ]);
  } else {
    // For 3+ jobs, try pickup-all then deliver-all
    const pickups: Stop[] = jobs.map(j => ({
      jobId: j.id, jobTitle: j.title, type: 'pickup',
      location: j.pickup_location, scheduledTime: convertToTimezone(new Date(j.pickup_time), timezone)
    }));
    const deliveries: Stop[] = jobs.map(j => ({
      jobId: j.id, jobTitle: j.title, type: 'dropoff',
      location: j.delivery_location, scheduledTime: convertToTimezone(new Date(j.delivery_time), timezone)
    }));
    sequences.push([...pickups, ...deliveries]);
  }
  
  return sequences;
}

// Validate sequence with travel time calculations
function validateSequence(sequence: Stop[], startTime: Date): { valid: boolean; reason?: string; stops?: Stop[] } {
  if (sequence.length === 0) {
    return { valid: false, reason: 'Empty sequence' };
  }
  
  let currentTime = new Date(startTime);
  const validatedStops: Stop[] = [];
  const LOAD_UNLOAD_MINUTES = 10;
  const LATE_TOLERANCE_MINUTES = 15; // Allow up to 15 minutes late
  
  for (let i = 0; i < sequence.length; i++) {
    const stop = sequence[i];
    
    // Calculate travel time from previous stop
    if (i > 0) {
      const travelMinutes = estimateTravelTime(sequence[i - 1].location, stop.location);
      currentTime = new Date(currentTime.getTime() + travelMinutes * 60 * 1000);
    }
    
    // Add load/unload time
    currentTime = new Date(currentTime.getTime() + LOAD_UNLOAD_MINUTES * 60 * 1000);
    
    // Check if we arrive too early (pickup)
    if (stop.type === 'pickup' && currentTime < stop.scheduledTime) {
      currentTime = new Date(stop.scheduledTime);
    }
    
    // Check if we arrive too late (delivery) - with tolerance buffer
    if (stop.type === 'dropoff') {
      const lateByMinutes = (currentTime.getTime() - stop.scheduledTime.getTime()) / (60 * 1000);
      if (lateByMinutes > LATE_TOLERANCE_MINUTES) {
        return {
          valid: false,
          reason: `Cannot complete delivery for "${stop.jobTitle}" by ${stop.scheduledTime.toLocaleTimeString()} (${Math.ceil(lateByMinutes)} min late, max ${LATE_TOLERANCE_MINUTES} min allowed)`
        };
      }
    }
    
    validatedStops.push({ ...stop, scheduledTime: new Date(currentTime) });
  }
  
  return { valid: true, stops: validatedStops };
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { driver_id, route_date, job_id } = await req.json();

    console.log('[Auto-Optimize-Route] Starting optimization:', {
      driver_id,
      route_date,
      triggering_job_id: job_id
    });

    // Fetch all planned scheduled jobs for this driver on this date
    const { data: jobs, error: jobsError } = await supabase
      .from('jobs')
      .select('id, title, pickup_time, delivery_time, pickup_location, delivery_location, distance_miles, estimated_duration')
      .eq('assigned_driver_id', driver_id)
      .eq('status', 'planned')
      .eq('priority', 'scheduled')
      .gte('pickup_time', `${route_date}T00:00:00`)
      .lt('pickup_time', `${route_date}T23:59:59`)
      .order('pickup_time', { ascending: true });

    if (jobsError) {
      console.error('[Auto-Optimize-Route] Error fetching jobs:', jobsError);
      throw jobsError;
    }

    if (!jobs || jobs.length === 0) {
      console.log('[Auto-Optimize-Route] No jobs found for route');
      return new Response(
        JSON.stringify({ message: 'No jobs to optimize' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
      );
    }

    console.log(`[Auto-Optimize-Route] Found ${jobs.length} jobs to optimize`);

    // Get platform timezone setting
    const platformTimezone = await getPlatformTimezone(supabase);
    console.log(`[Auto-Optimize-Route] Using timezone: ${platformTimezone}`);

    // Generate and try different stop sequences
    const sortedJobs = [...jobs].sort((a, b) => 
      new Date(a.pickup_time).getTime() - new Date(b.pickup_time).getTime()
    );
    const startTimeUTC = new Date(sortedJobs[0].pickup_time);
    const startTime = convertToTimezone(startTimeUTC, platformTimezone);
    console.log(`[Auto-Optimize-Route] Start time UTC: ${startTimeUTC.toISOString()}, Platform TZ: ${startTime.toLocaleString()}`);
    
    const sequences = generateStopSequences(sortedJobs, platformTimezone);
    console.log(`[Auto-Optimize-Route] Generated ${sequences.length} possible sequences`);
    
    let bestSequence: Stop[] | null = null;
    let bestValidation: any = null;
    
    for (let i = 0; i < sequences.length; i++) {
      const sequence = sequences[i];
      const validation = validateSequence(sequence, startTime);
      
      if (validation.valid && validation.stops) {
        bestSequence = validation.stops;
        bestValidation = validation;
        const sequenceDesc = sequence.map(s => `${s.type === 'pickup' ? 'P' : 'D'}(${s.jobTitle})`).join(' → ');
        console.log(`[Auto-Optimize-Route] Found valid sequence #${i + 1}: ${sequenceDesc}`);
        break;
      } else {
        console.log(`[Auto-Optimize-Route] Sequence #${i + 1} invalid: ${validation.reason}`);
      }
    }
    
    if (!bestSequence) {
      console.error('[Auto-Optimize-Route] No valid sequence found for jobs');
      return new Response(
        JSON.stringify({ error: 'No valid route sequence found. Jobs cannot be completed within time windows.' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
      );
    }

    const optimizedStops = bestSequence;
    
    // Calculate totals from optimized route
    let totalDistance = 0;
    let totalDuration = 0;
    
    for (let i = 0; i < optimizedStops.length - 1; i++) {
      const from = optimizedStops[i];
      const to = optimizedStops[i + 1];
      
      const fromCoords = getCoordinates(from.location);
      const toCoords = getCoordinates(to.location);
      
      if (fromCoords && toCoords) {
        totalDistance += calculateDistance(fromCoords.lat, fromCoords.lng, toCoords.lat, toCoords.lng);
      }
      
      totalDuration += estimateTravelTime(from.location, to.location);
    }

    // Upsert route (prevents race condition duplicates)
    console.log('[Auto-Optimize-Route] Upserting route for driver/date');
    
    const routeName = `Route ${route_date}`;
    const waypoints = validSequence.map(stop => ({
      location: stop.location,
      type: stop.type,
      job_title: stop.job_title
    }));
    
    const { data: route, error: upsertError } = await supabase
      .from('routes')
      .upsert(
        {
          driver_id,
          route_date,
          route_name: routeName,
          waypoints,
          total_distance: totalDistance,
          estimated_duration: totalDuration,
          status: 'planned',
          updated_at: new Date().toISOString()
        },
        {
          onConflict: 'driver_id,route_date',
          ignoreDuplicates: false
        }
      )
      .select('id')
      .single();

    if (upsertError) {
      console.error('[Auto-Optimize-Route] Error upserting route:', upsertError);
      throw upsertError;
    }

    const routeId = route.id;
    console.log('[Auto-Optimize-Route] Route ID:', routeId);

    // Delete old stops before inserting new ones
    const { error: deleteStopsError } = await supabase
      .from('route_stops')
      .delete()
      .eq('route_id', routeId);

    if (deleteStopsError) {
      console.error('[Auto-Optimize-Route] Error deleting old stops:', deleteStopsError);
      throw deleteStopsError;
    }

    // Insert optimized stops with sequence
    const stopsToInsert = optimizedStops.map((stop, index) => ({
      route_id: routeId,
      job_id: stop.jobId,
      stop_type: stop.type,
      location: stop.location,
      scheduled_time: stop.scheduledTime.toISOString(),
      stop_sequence: index + 1,
      status: 'pending'
    }));

    const { error: insertStopsError } = await supabase
      .from('route_stops')
      .insert(stopsToInsert);

    if (insertStopsError) {
      console.error('[Auto-Optimize-Route] Error inserting stops:', insertStopsError);
      throw insertStopsError;
    }

    // Update all jobs with route_id
    const { error: updateJobsError } = await supabase
      .from('jobs')
      .update({ route_id: routeId })
      .in('id', jobs.map(j => j.id));

    if (updateJobsError) {
      console.error('[Auto-Optimize-Route] Error updating jobs with route_id:', updateJobsError);
      throw updateJobsError;
    }

    console.log('[Auto-Optimize-Route] Route optimization completed successfully:', {
      route_id: routeId,
      total_jobs: jobs.length,
      total_stops: optimizedStops.length,
      total_distance: totalDistance,
      total_duration: totalDuration
    });

    return new Response(
      JSON.stringify({
        success: true,
        route_id: routeId,
        jobs_count: jobs.length,
        stops_count: optimizedStops.length,
        total_distance: totalDistance,
        total_duration: totalDuration
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 200 }
    );

  } catch (error) {
    console.error('[Auto-Optimize-Route] Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});
