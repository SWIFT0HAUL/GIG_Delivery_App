import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (req.method !== 'GET' && req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405, headers: corsHeaders })
  }

  const url = new URL(req.url)
  let query = url.searchParams.get('q') || ''

  if (req.method === 'POST') {
    try {
      const body = await req.json()
      if (body?.q && typeof body.q === 'string') {
        query = body.q
      }
    } catch (_) {}
  }

  if (!query || query.trim().length < 3) {
    return new Response(JSON.stringify({ error: 'Query must be at least 3 characters' }), { 
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  // Retrieve API key from secrets (environment variable or secret store)
  const apiKey = Deno.env.get('LOCATIONIQ_KEY')
  if (!apiKey) {
    console.error('Missing LOCATIONIQ_KEY')
    return new Response(JSON.stringify({ error: 'Server config error' }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  // Use LocationIQ Autocomplete API - filter to US only
  const placesUrl = `https://us1.locationiq.com/v1/autocomplete.php?key=${apiKey}&q=${encodeURIComponent(query)}&limit=5&dedupe=1&countrycodes=us&format=json`

  const resp = await fetch(placesUrl, {
    method: 'GET'
  })

  const json = await resp.json()

  // Handle LocationIQ error responses gracefully
  if (!resp.ok) {
    console.warn('LocationIQ API returned error status', resp.status, json)
    // Return empty suggestions instead of error for geocoding failures
    if (json?.error === 'Unable to geocode') {
      return new Response(JSON.stringify({ suggestions: [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      })
    }
    return new Response(JSON.stringify({ error: 'Autocomplete error', details: json }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  // If LocationIQ returns an error object instead of array (200 OK but with error)
  if (!Array.isArray(json)) {
    console.warn('LocationIQ returned non-array response', json)
    // Return empty suggestions for "Unable to geocode" errors
    if (json?.error === 'Unable to geocode') {
      return new Response(JSON.stringify({ suggestions: [] }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      })
    }
    return new Response(JSON.stringify({ error: 'Autocomplete error', details: json }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  const suggestions = json.map((p: any) => {
    // LocationIQ returns lat/lon which we'll use for place details lookup
    return {
      description: p.display_name || p.display_address || '',
      place_id: `${p.lat},${p.lon}`, // Use lat,lon as place_id for reverse geocoding
    }
  })

  return new Response(JSON.stringify({ suggestions }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    status: 200,
  })
})
