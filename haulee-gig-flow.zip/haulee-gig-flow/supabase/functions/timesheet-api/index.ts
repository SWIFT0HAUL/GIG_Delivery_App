import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface ClockInRequest {
  admin_id?: string;
  user_id?: string;
  task_id?: string;
  job_id?: string;
  job_stage?: string;
  mileage?: number;
}

interface ClockOutRequest {
  timesheet_id: string;
  mileage?: number;
  wait_time_minutes?: number;
  break_time_minutes?: number;
}

interface ManualEntryRequest {
  admin_id?: string;
  user_id?: string;
  clock_in: string;
  clock_out: string;
  reason: string;
  notes?: string;
  task_id?: string;
  job_id?: string;
  job_stage?: string;
  mileage?: number;
  wait_time_minutes?: number;
  break_time_minutes?: number;
}

interface ApprovalRequest {
  timesheet_id: string;
  action: 'approve' | 'reject';
  rejection_reason?: string;
}

interface JobStageTransitionRequest {
  timesheet_id: string;
  new_stage: string;
  notes?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false,
        },
      }
    );

    // Get authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    // Set auth token
    const { data: { user }, error: authError } = await supabase.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const url = new URL(req.url);
    const path = url.pathname.split('/').pop();

    switch (path) {
      case 'clock-in': {
        if (req.method !== 'POST') {
          return new Response('Method not allowed', { status: 405, headers: corsHeaders });
        }

        const { admin_id, user_id, task_id, job_id, job_stage, mileage }: ClockInRequest = await req.json();
        const effectiveUserId = user_id || admin_id;
        
        if (!effectiveUserId) {
          return new Response(
            JSON.stringify({ error: 'User ID or Admin ID is required' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Get user role
        const { data: profile } = await supabase
          .from('profiles')
          .select('role_key')
          .eq('id', effectiveUserId)
          .single();

        // Check for active session
        const { data: existingSession, error: checkError } = await supabase
          .from('timesheets')
          .select('id')
          .or(`user_id.eq.${effectiveUserId},admin_id.eq.${effectiveUserId}`)
          .is('clock_out', null)
          .maybeSingle();

        if (checkError) {
          console.error('Error checking for existing session:', checkError);
          throw checkError;
        }

        if (existingSession) {
          return new Response(
            JSON.stringify({ error: 'Active session already exists. Please clock out first.' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Create new timesheet entry
        const { data: timesheet, error: insertError } = await supabase
          .from('timesheets')
          .insert({
            user_id: effectiveUserId,
            admin_id: effectiveUserId,
            role_key: profile?.role_key,
            clock_in: new Date().toISOString(),
            last_activity: new Date().toISOString(),
            status: 'active',
            manual_entry: false,
            activity_count: 0,
            job_id,
            job_stage: job_stage || (job_id ? 'assigned' : null),
            mileage: mileage || 0
          })
          .select()
          .single();

        if (insertError) {
          console.error('Error creating timesheet:', insertError);
          throw insertError;
        }

        // Create job stage entry if job linked
        if (job_id && timesheet) {
          await supabase
            .from('timesheet_job_stages')
            .insert({
              timesheet_id: timesheet.id,
              job_id,
              stage: job_stage || 'assigned',
              started_at: new Date().toISOString()
            });
        }

        // Create activity log
        if (timesheet) {
          await supabase
            .from('timesheet_activity_logs')
            .insert({
              timesheet_id: timesheet.id,
              activity_type: job_id ? 'JOB_START' : (task_id ? 'TASK_START' : 'CLOCK_IN'),
              activity_description: job_id ? `Started job ${job_id}` : (task_id ? 'Started working on task' : 'Clocked in'),
              task_id,
              metadata: { task_id, job_id, job_stage }
            });
        }

        return new Response(
          JSON.stringify({ success: true, timesheet }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'clock-out': {
        if (req.method !== 'POST') {
          return new Response('Method not allowed', { status: 405, headers: corsHeaders });
        }

        const { timesheet_id, mileage, wait_time_minutes, break_time_minutes }: ClockOutRequest = await req.json();

        // Get existing timesheet
        const { data: existingTimesheet, error: fetchError } = await supabase
          .from('timesheets')
          .select('*')
          .eq('id', timesheet_id)
          .single();

        if (fetchError || !existingTimesheet) {
          return new Response(
            JSON.stringify({ error: 'Timesheet not found' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        if (existingTimesheet.clock_out) {
          return new Response(
            JSON.stringify({ error: 'Already clocked out' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const clockOutTime = new Date().toISOString();
        const clockInTime = new Date(existingTimesheet.clock_in).getTime();
        const clockOutTimeMs = new Date(clockOutTime).getTime();
        const duration = (clockOutTimeMs - clockInTime) / (1000 * 60 * 60);

        const { data: timesheet, error: updateError } = await supabase
          .from('timesheets')
          .update({
            clock_out: clockOutTime,
            total_duration: duration,
            status: 'completed',
            mileage: mileage !== undefined ? mileage : existingTimesheet.mileage,
            wait_time_minutes: wait_time_minutes !== undefined ? wait_time_minutes : existingTimesheet.wait_time_minutes,
            break_time_minutes: break_time_minutes !== undefined ? break_time_minutes : existingTimesheet.break_time_minutes
          })
          .eq('id', timesheet_id)
          .select()
          .single();

        if (updateError) {
          console.error('Error clocking out:', updateError);
          throw updateError;
        }

        // Complete current job stage if exists
        if (existingTimesheet.job_id) {
          await supabase
            .from('timesheet_job_stages')
            .update({
              completed_at: clockOutTime
            })
            .eq('timesheet_id', timesheet_id)
            .is('completed_at', null);
        }

        // Log activity
        await supabase
          .from('timesheet_activity_logs')
          .insert({
            timesheet_id,
            activity_type: 'CLOCK_OUT',
            activity_description: 'Clocked out',
            metadata: { 
              duration_hours: duration,
              mileage,
              wait_time_minutes,
              break_time_minutes
            }
          });

        return new Response(
          JSON.stringify({ success: true, timesheet }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'manual-entry': {
        if (req.method !== 'POST') {
          return new Response('Method not allowed', { status: 405, headers: corsHeaders });
        }

        const { admin_id, user_id, clock_in, clock_out, reason, notes, task_id, job_id, job_stage, mileage, wait_time_minutes, break_time_minutes }: ManualEntryRequest = await req.json();
        const effectiveUserId = user_id || admin_id;

        if (!effectiveUserId) {
          return new Response(
            JSON.stringify({ error: 'User ID or Admin ID is required' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Get user role
        const { data: profile } = await supabase
          .from('profiles')
          .select('role_key')
          .eq('id', effectiveUserId)
          .single();

        // Validate timestamps
        const clockInDate = new Date(clock_in);
        const clockOutDate = new Date(clock_out);
        const now = new Date();

        if (clockInDate > now || clockOutDate > now) {
          return new Response(
            JSON.stringify({ error: 'Cannot create entries with future timestamps' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        if (clockInDate >= clockOutDate) {
          return new Response(
            JSON.stringify({ error: 'Clock out time must be after clock in time' }),
            { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const { data: timesheet, error: insertError } = await supabase
          .from('timesheets')
          .insert({
            user_id: effectiveUserId,
            admin_id: effectiveUserId,
            role_key: profile?.role_key,
            clock_in: clockInDate.toISOString(),
            clock_out: clockOutDate.toISOString(),
            status: 'pending_approval',
            manual_entry: true,
            manual_entry_reason: reason,
            notes,
            job_id,
            job_stage: job_stage || (job_id ? 'assigned' : null),
            mileage,
            wait_time_minutes,
            break_time_minutes
          })
          .select()
          .single();

        if (insertError) {
          console.error('Error creating manual entry:', insertError);
          
          if (insertError.message.includes('overlaps')) {
            return new Response(
              JSON.stringify({ error: 'This timesheet entry overlaps with an existing session' }),
              { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
            );
          }
          
          throw insertError;
        }

        // Create job stage entry if job linked
        if (job_id && timesheet) {
          await supabase
            .from('timesheet_job_stages')
            .insert({
              timesheet_id: timesheet.id,
              job_id,
              stage: job_stage || 'assigned',
              started_at: clockInDate.toISOString(),
              completed_at: clockOutDate.toISOString()
            });
        }

        // Create activity log
        if (task_id && timesheet) {
          await supabase
            .from('timesheet_activity_logs')
            .insert({
              timesheet_id: timesheet.id,
              activity_type: 'MANUAL_ENTRY',
              activity_description: 'Manual entry created',
              task_id,
              metadata: { task_id, job_id, job_stage }
            });
        }

        return new Response(
          JSON.stringify({ success: true, timesheet }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'job-stage-transition': {
        if (req.method !== 'POST') {
          return new Response('Method not allowed', { status: 405, headers: corsHeaders });
        }

        const { timesheet_id, new_stage, notes }: JobStageTransitionRequest = await req.json();

        // Get existing timesheet
        const { data: existingTimesheet } = await supabase
          .from('timesheets')
          .select('*')
          .eq('id', timesheet_id)
          .single();

        if (!existingTimesheet || !existingTimesheet.job_id) {
          return new Response(
            JSON.stringify({ error: 'Timesheet not found or not linked to a job' }),
            { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        // Complete current stage
        await supabase
          .from('timesheet_job_stages')
          .update({
            completed_at: new Date().toISOString()
          })
          .eq('timesheet_id', timesheet_id)
          .is('completed_at', null);

        // Create new stage entry
        await supabase
          .from('timesheet_job_stages')
          .insert({
            timesheet_id,
            job_id: existingTimesheet.job_id,
            stage: new_stage,
            started_at: new Date().toISOString(),
            notes
          });

        // Update timesheet
        const { data: timesheet, error: updateError } = await supabase
          .from('timesheets')
          .update({
            job_stage: new_stage
          })
          .eq('id', timesheet_id)
          .select()
          .single();

        if (updateError) throw updateError;

        // Log activity
        await supabase
          .from('timesheet_activity_logs')
          .insert({
            timesheet_id,
            activity_type: 'STAGE_TRANSITION',
            activity_description: `Transitioned to ${new_stage}`,
            metadata: { new_stage, notes }
          });

        return new Response(
          JSON.stringify({ success: true, timesheet }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'approve': {
        if (req.method !== 'POST') {
          return new Response('Method not allowed', { status: 405, headers: corsHeaders });
        }

        const { timesheet_id, action, rejection_reason }: ApprovalRequest = await req.json();

        // Verify user is admin or super admin
        const { data: profile } = await supabase
          .from('profiles')
          .select('role_key')
          .eq('id', user.id)
          .single();

        if (!profile || !['admin', 'super_admin'].includes(profile.role_key)) {
          return new Response(
            JSON.stringify({ error: 'Unauthorized: Admin access required' }),
            { status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
          );
        }

        const updateData: any = {
          approved_by: user.id,
          approved_at: new Date().toISOString(),
          status: action === 'approve' ? 'approved' : 'rejected',
        };

        if (action === 'reject' && rejection_reason) {
          updateData.rejection_reason = rejection_reason;
        }

        const { data: timesheet, error: updateError } = await supabase
          .from('timesheets')
          .update(updateData)
          .eq('id', timesheet_id)
          .select()
          .single();

        if (updateError) {
          console.error('Error updating timesheet:', updateError);
          throw updateError;
        }

        return new Response(
          JSON.stringify({ success: true, timesheet }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      case 'report': {
        if (req.method !== 'GET') {
          return new Response('Method not allowed', { status: 405, headers: corsHeaders });
        }

        const startDate = url.searchParams.get('start_date');
        const endDate = url.searchParams.get('end_date');
        const adminId = url.searchParams.get('admin_id');
        const userId = url.searchParams.get('user_id');
        const roleKey = url.searchParams.get('role_key');

        let query = supabase
          .from('timesheets')
          .select('*, timesheet_activity_logs(*)')
          .order('clock_in', { ascending: false });

        if (startDate) {
          query = query.gte('clock_in', startDate);
        }
        if (endDate) {
          query = query.lte('clock_in', endDate);
        }
        if (adminId) {
          query = query.eq('admin_id', adminId);
        }
        if (userId) {
          query = query.eq('user_id', userId);
        }
        if (roleKey) {
          query = query.eq('role_key', roleKey);
        }

        const { data: timesheets, error: queryError } = await query;

        if (queryError) {
          console.error('Error fetching report data:', queryError);
          throw queryError;
        }

        // Calculate summary statistics
        const totalHours = timesheets?.reduce((sum, t) => sum + (t.total_duration || 0), 0) || 0;
        const overtimeHours = timesheets?.reduce(
          (sum, t) => sum + Math.max(0, (t.total_duration || 0) - 8),
          0
        ) || 0;
        const pendingCount = timesheets?.filter(t => 
          t.status === 'pending' || t.status === 'pending_approval'
        ).length || 0;
        const totalMileage = timesheets?.reduce((sum, t) => sum + (t.mileage || 0), 0) || 0;

        return new Response(
          JSON.stringify({
            success: true,
            report: {
              timesheets,
              summary: {
                total_hours: totalHours,
                overtime_hours: overtimeHours,
                pending_count: pendingCount,
                total_entries: timesheets?.length || 0,
                total_mileage: totalMileage,
              }
            }
          }),
          { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      default:
        return new Response('Not found', { status: 404, headers: corsHeaders });
    }
  } catch (error: any) {
    console.error('Error in timesheet-api:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: error.message === 'Unauthorized' ? 401 : 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      }
    );
  }
});