import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { Resend } from "https://esm.sh/resend@4.0.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface CreateUserRequest {
  email: string;
  password?: string; // Optional - if not provided, generates temp password
  fullName?: string; // Support both fullName and full_name
  full_name?: string;
  phone?: string;
  role: 'super_admin' | 'admin' | 'vendor_merchant' | 'shipper' | 'driver' | 'carrier' | 'broker';
  subRole?: string;
  sub_role?: string;
  sendInvitation?: boolean;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client with service role key for admin operations
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const body = await req.json() as any;
    const {
      email,
      password,
      fullName,
      full_name,
      phone,
      role,
      subRole,
      sub_role,
      sendInvitation,
      send_invitation
    } = body;
    
    // Support both naming conventions
    const userName = fullName || full_name;
    const userSubRole = subRole || sub_role;
    const sendInvitationFlag = (typeof sendInvitation === 'boolean')
      ? sendInvitation
      : ((typeof send_invitation === 'boolean') ? send_invitation : true);

    console.log(`Creating user for: ${email} with role: ${role}`);

    // Validate input
    if (!email || !userName || !role) {
      return new Response(
        JSON.stringify({ error: "Missing required fields: email, full_name, and role are required" }),
        {
          status: 400,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }
    
    // Validate password if provided
    if (password) {
      if (password.length < 12) {
        return new Response(
          JSON.stringify({ error: "Password must be at least 12 characters" }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          }
        );
      }
      
      // Check for at least one special character
      const specialCharRegex = /[!@#$%^&*]/;
      if (!specialCharRegex.test(password)) {
        return new Response(
          JSON.stringify({ error: "Password must include at least one special character (!@#$%^&*)" }),
          {
            status: 400,
            headers: { "Content-Type": "application/json", ...corsHeaders },
          }
        );
      }
    }

    // Check if user already exists
    const { data: existingUser } = await supabase
      .from('profiles')
      .select('email')
      .eq('email', email)
      .single();

    if (existingUser) {
      return new Response(
        JSON.stringify({ error: "User with this email already exists" }),
        {
          status: 409,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Generate a temporary password if not provided (12 chars with special character)
    let userPassword = password;
    if (!userPassword) {
      const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      const lowercase = 'abcdefghijkmnopqrstuvwxyz';
      const numbers = '0123456789';
      const special = '!@#$%^&*';
      const allChars = uppercase + lowercase + numbers + special;
      
      let tempPassword = '';
      tempPassword += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
      tempPassword += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
      tempPassword += numbers.charAt(Math.floor(Math.random() * numbers.length));
      tempPassword += special.charAt(Math.floor(Math.random() * special.length));
      
      for (let i = tempPassword.length; i < 12; i++) {
        tempPassword += allChars.charAt(Math.floor(Math.random() * allChars.length));
      }
      
      userPassword = tempPassword.split('').sort(() => Math.random() - 0.5).join('');
    }

    // Create user in Supabase Auth
    const { data: authUser, error: authError } = await supabase.auth.admin.createUser({
      email,
      password: userPassword,
      email_confirm: true, // Admin-created users are auto-confirmed
      user_metadata: {
        full_name: userName,
        phone: phone || null,
        role: role,
        sub_role: userSubRole || null,
        force_password_change: true // Force password change on first login
      }
    });

    if (authError) {
      console.error("Error creating auth user:", authError);
      return new Response(
        JSON.stringify({ error: "Failed to create user account", details: authError.message }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    console.log(`Auth user created with ID: ${authUser.user?.id}`);

    // Update the existing profile that was created by the trigger
    const { error: profileError } = await supabase
      .from('profiles')
      .update({
        full_name: userName,
        email: email,
        phone: phone || null,
        role_key: role,
        sub_role: userSubRole || null,
        email_confirmed: true,
        is_approved: false,
        is_active: false,
        onboarding_complete: false
      })
      .eq('id', authUser.user!.id);

    if (profileError) {
      console.error("Error creating profile:", profileError);
      // Clean up auth user if profile creation fails
      await supabase.auth.admin.deleteUser(authUser.user!.id);
      return new Response(
        JSON.stringify({ error: "Failed to create user profile", details: profileError.message }),
        {
          status: 500,
          headers: { "Content-Type": "application/json", ...corsHeaders },
        }
      );
    }

    // Send invitation email if requested
    console.log(`sendInvitation flag: ${sendInvitationFlag}`);
    
    if (sendInvitationFlag) {
      try {
        console.log(`Attempting to send email to: ${email}`);
        const resendApiKey = Deno.env.get("RESEND_API_KEY");
        
        if (!resendApiKey) {
          console.error("RESEND_API_KEY is not configured");
          throw new Error("Email service not configured");
        }
        
        console.log("Resend API key found, initializing Resend...");
        const resend = new Resend(resendApiKey);
        
        // Use your verified domain here (e.g., "SwiftoHaul <noreply@yourdomain.com>")
        const fromEmail = Deno.env.get("RESEND_FROM_EMAIL") || "SwiftoHaul <onboarding@resend.dev>";
        
        // Standard email with temporary password and sign-in link
        console.log("Sending standard invitation with temporary password");
        
        const emailResponse = await resend.emails.send({
          from: fromEmail,
          to: [email],
          subject: "Welcome to SwiftoHaul - Account Created",
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h1 style="color: #333; text-align: center;">Welcome to SwiftoHaul!</h1>
              <p>Hello ${userName},</p>
              <p>Your account has been created with the role of <strong>${role}</strong>.</p>
              <p>Your login credentials are:</p>
              <div style="background-color: #f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Temporary Password:</strong> ${userPassword}</p>
              </div>
              <p style="color: #d32f2f; font-size: 14px;">
                <strong>Important:</strong> Please change your password after your first login for security.
              </p>
              <div style="text-align: center; margin: 30px 0;">
                <a href="https://083b4646-0999-4abf-8b63-fba56b8fc586.lovableproject.com/auth" 
                   style="background-color: #1976d2; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; display: inline-block;">
                  Login to Your Account
                </a>
              </div>
              <p>If you have any questions, please contact our support team.</p>
              <p>Best regards,<br>The SwiftoHaul Team</p>
            </div>
          `,
        });

        console.log("Invitation email sent successfully:", JSON.stringify(emailResponse));
      } catch (emailError: any) {
        console.error("Error sending invitation email:", emailError);
        console.error("Email error details:", JSON.stringify(emailError));
        // Don't fail the entire operation if email fails, just log it
      }
    } else {
      console.log("Skipping email - sendInvitation is false");
    }

    return new Response(
      JSON.stringify({ 
        message: "User created successfully",
        success: true,
        user: {
          id: authUser.user!.id,
          email: email,
          full_name: userName,
          role: role,
          sub_role: userSubRole || null
        },
        invitationSent: sendInvitation || false
      }),
      {
        status: 201,
        headers: {
          "Content-Type": "application/json",
          ...corsHeaders,
        },
      }
    );
  } catch (error: any) {
    console.error("Error in create-user-invitation function:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 500,
        headers: { "Content-Type": "application/json", ...corsHeaders },
      }
    );
  }
};

serve(handler);