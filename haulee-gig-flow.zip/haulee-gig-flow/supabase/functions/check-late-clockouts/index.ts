import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Database {
  public: {
    Tables: {
      timesheets: {
        Row: {
          id: string;
          admin_id: string;
          clock_in: string;
          clock_out: string | null;
          status: string;
        };
      };
    };
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient<Database>(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          persistSession: false,
        },
      }
    );

    console.log('Checking for late clock-outs...');

    // Find all active timesheet sessions older than 10 hours
    const tenHoursAgo = new Date(Date.now() - 10 * 60 * 60 * 1000).toISOString();

    const { data: lateTimesheets, error: fetchError } = await supabaseClient
      .from('timesheets')
      .select('id, admin_id, clock_in')
      .is('clock_out', null)
      .eq('status', 'active')
      .lt('clock_in', tenHoursAgo);

    if (fetchError) {
      console.error('Error fetching late timesheets:', fetchError);
      throw fetchError;
    }

    console.log(`Found ${lateTimesheets?.length || 0} late clock-outs`);

    // Send notification for each late timesheet
    if (lateTimesheets && lateTimesheets.length > 0) {
      for (const timesheet of lateTimesheets) {
        const clockInTime = new Date(timesheet.clock_in);
        const hoursElapsed = Math.floor((Date.now() - clockInTime.getTime()) / (1000 * 60 * 60));

        const { error: notificationError } = await supabaseClient
          .from('notifications')
          .insert({
            user_id: timesheet.admin_id,
            type: 'system',
            title: 'Late Clock-Out Reminder',
            message: `You have been clocked in for ${hoursElapsed} hours. Please clock out if your shift has ended. Clock-in time: ${clockInTime.toLocaleString()}`,
            metadata: {
              timesheet_id: timesheet.id,
              hours_elapsed: hoursElapsed,
            },
          });

        if (notificationError) {
          console.error('Error creating notification:', notificationError);
        } else {
          console.log(`Notification sent for timesheet ${timesheet.id}`);
        }
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        checked: lateTimesheets?.length || 0,
        message: `Checked ${lateTimesheets?.length || 0} late clock-outs`,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error in check-late-clockouts:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});
