import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Job {
  id: string;
  pickup_time: string;
  estimated_duration: number;
  pickup_location: any;
  delivery_location: any;
  distance_miles: number;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { driver_id, route_date } = await req.json();

    if (!driver_id || !route_date) {
      throw new Error('Missing required parameters: driver_id and route_date');
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Step 1: Fetch all jobs for this driver on this date (pickup on same day)
    const { data: jobs, error: jobsError } = await supabaseClient
      .from('jobs')
      .select('*')
      .eq('assigned_driver_id', driver_id)
      .gte('pickup_time', `${route_date}T00:00:00`)
      .lte('pickup_time', `${route_date}T23:59:59`)
      .in('status', ['planned', 'assigned', 'accepted', 'in_progress'])
      .order('pickup_time', { ascending: true });

    if (jobsError) throw jobsError;
    if (!jobs || jobs.length === 0) {
      return new Response(
        JSON.stringify({ success: true, message: 'No jobs to group', route: null }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Step 2: Calculate totals
    const orderedJobIds = jobs.map(job => job.id);
    const totalDistance = jobs.reduce((sum, job) => sum + (job.distance_miles || 0), 0);
    const totalDuration = jobs.reduce((sum, job) => sum + (job.estimated_duration || 60), 0);

    // Step 3: Save or update route
    const { data: existingRoute } = await supabaseClient
      .from('routes')
      .select('id')
      .eq('driver_id', driver_id)
      .eq('route_date', route_date)
      .single();

    const routeData = {
      driver_id,
      route_date,
      ordered_job_ids: orderedJobIds,
      total_distance: totalDistance,
      total_duration: Math.round(totalDuration),
      delay_risk: false,
      conflict_reason: null,
      status: 'active',
      updated_at: new Date().toISOString(),
    };

    let routeId: string;

    if (existingRoute) {
      const { data: updatedRoute, error: updateError } = await supabaseClient
        .from('routes')
        .update(routeData)
        .eq('id', existingRoute.id)
        .select()
        .single();

      if (updateError) throw updateError;
      routeId = updatedRoute.id;
    } else {
      const { data: newRoute, error: insertError } = await supabaseClient
        .from('routes')
        .insert(routeData)
        .select()
        .single();

      if (insertError) throw insertError;
      routeId = newRoute.id;
    }

    // Step 4: Update jobs with route_id and route_order
    for (let i = 0; i < orderedJobIds.length; i++) {
      await supabaseClient
        .from('jobs')
        .update({
          route_id: routeId,
          route_order: i + 1,
        })
        .eq('id', orderedJobIds[i]);
    }

    return new Response(
      JSON.stringify({
        success: true,
        route: {
          id: routeId,
          ordered_job_ids: orderedJobIds,
          total_distance: totalDistance,
          total_duration: totalDuration,
          has_conflict: false,
          conflict_reason: null,
        },
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error creating route:', error);
    return new Response(
      JSON.stringify({ success: false, error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
