import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  if (req.method !== 'GET') {
    return new Response('Method Not Allowed', { status: 405, headers: corsHeaders })
  }

  const url = new URL(req.url)
  const origin = url.searchParams.get('origin')
  const destination = url.searchParams.get('destination')
  const waypoints = url.searchParams.get('waypoints') // optional
  const mode = url.searchParams.get('mode') // optional: driving, walking etc.

  if (!origin || !destination) {
    return new Response(
      JSON.stringify({ error: 'origin & destination required' }),
      { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }

  const apiKey = Deno.env.get('LOCATIONIQ_KEY')
  if (!apiKey) {
    console.error('Missing LOCATIONIQ_KEY')
    return new Response(JSON.stringify({ error: 'Server config error' }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  let dirUrl = `https://us1.locationiq.com/v1/directions/driving/${encodeURIComponent(
    origin
  )};${encodeURIComponent(destination)}?key=${apiKey}&steps=true&alternatives=false&geometries=polyline&overview=full`

  if (waypoints) {
    // LocationIQ uses semicolon-separated waypoints in the path
    const waypointCoords = waypoints.split('|').join(';')
    dirUrl = `https://us1.locationiq.com/v1/directions/driving/${encodeURIComponent(
      origin
    )};${waypointCoords};${encodeURIComponent(destination)}?key=${apiKey}&steps=true&alternatives=false&geometries=polyline&overview=full`
  }

  const resp = await fetch(dirUrl)
  const json = await resp.json()

  if (!resp.ok || !json.routes || json.routes.length === 0) {
    console.warn('LocationIQ Directions error', json)
    return new Response(JSON.stringify({ error: 'Directions failed', details: json }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  return new Response(JSON.stringify(json), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    status: 200,
  })
})
