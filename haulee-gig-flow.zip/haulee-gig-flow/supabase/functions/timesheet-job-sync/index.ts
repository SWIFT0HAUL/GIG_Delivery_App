import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          persistSession: false,
        },
      }
    );

    const { jobId, newStatus, oldStatus } = await req.json();

    if (!jobId || !newStatus) {
      return new Response(
        JSON.stringify({ error: 'Job ID and new status are required' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 400,
        }
      );
    }

    console.log(`Syncing job ${jobId} status change: ${oldStatus} -> ${newStatus}`);

    // Get job details
    const { data: job, error: jobError } = await supabaseClient
      .from('jobs')
      .select('*')
      .eq('id', jobId)
      .single();

    if (jobError || !job) {
      console.error('Job not found:', jobError);
      return new Response(
        JSON.stringify({ error: 'Job not found' }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 404,
        }
      );
    }

    // Get active timesheet for this job
    const { data: activeTimesheet } = await supabaseClient
      .from('timesheets')
      .select('*')
      .eq('job_id', jobId)
      .is('clock_out', null)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    // Map job statuses to timesheet stages
    const stageMap: Record<string, string> = {
      'assigned': 'assigned',
      'in_progress': 'start',
      'picked_up': 'pickup',
      'delivered': 'delivered',
      'completed': 'completed'
    };

    const newStage = stageMap[newStatus];

    if (activeTimesheet && newStage) {
      // Complete previous stage
      await supabaseClient
        .from('timesheet_job_stages')
        .update({ completed_at: new Date().toISOString() })
        .eq('timesheet_id', activeTimesheet.id)
        .is('completed_at', null);

      // Create new stage entry
      await supabaseClient
        .from('timesheet_job_stages')
        .insert([{
          timesheet_id: activeTimesheet.id,
          job_id: jobId,
          stage: newStage,
          started_at: new Date().toISOString()
        }]);

      // Update timesheet job_stage
      await supabaseClient
        .from('timesheets')
        .update({ job_stage: newStage })
        .eq('id', activeTimesheet.id);

      // Log activity
      await supabaseClient
        .from('timesheet_activity_logs')
        .insert([{
          timesheet_id: activeTimesheet.id,
          activity_type: 'job_stage_change',
          activity_description: `Job status changed to ${newStatus}`,
          metadata: {
            job_id: jobId,
            old_status: oldStatus,
            new_status: newStatus,
            new_stage: newStage
          }
        }]);

      console.log(`Updated timesheet ${activeTimesheet.id} to stage ${newStage}`);
    }

    // Auto clock-out on job completion
    if (newStatus === 'completed' && activeTimesheet) {
      const clockOutTime = new Date().toISOString();
      const duration = (new Date(clockOutTime).getTime() - new Date(activeTimesheet.clock_in).getTime()) / (1000 * 60 * 60);

      await supabaseClient
        .from('timesheets')
        .update({
          clock_out: clockOutTime,
          total_duration: duration,
          status: 'completed'
        })
        .eq('id', activeTimesheet.id);

      // Complete all stages
      await supabaseClient
        .from('timesheet_job_stages')
        .update({ completed_at: clockOutTime })
        .eq('timesheet_id', activeTimesheet.id)
        .is('completed_at', null);

      console.log(`Auto clocked out timesheet ${activeTimesheet.id} on job completion`);
    }

    return new Response(
      JSON.stringify({ success: true, message: 'Job sync completed' }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error) {
    console.error('Error in timesheet-job-sync:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});