export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      access_violation_logs: {
        Row: {
          action_attempted: string
          created_at: string | null
          id: string
          ip_address: string | null
          reason: string | null
          resource_id: string | null
          resource_type: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          action_attempted: string
          created_at?: string | null
          id?: string
          ip_address?: string | null
          reason?: string | null
          resource_id?: string | null
          resource_type: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          action_attempted?: string
          created_at?: string | null
          id?: string
          ip_address?: string | null
          reason?: string | null
          resource_id?: string | null
          resource_type?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      admin_approvals: {
        Row: {
          action_type: string | null
          approval_type: string
          created_at: string | null
          id: string
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: Database["public"]["Enums"]["approval_status"] | null
          submitted_data: Json | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          action_type?: string | null
          approval_type: string
          created_at?: string | null
          id?: string
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["approval_status"] | null
          submitted_data?: Json | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          action_type?: string | null
          approval_type?: string
          created_at?: string | null
          id?: string
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: Database["public"]["Enums"]["approval_status"] | null
          submitted_data?: Json | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      admin_documents: {
        Row: {
          approved_by: string | null
          category: Database["public"]["Enums"]["doc_category"]
          created_at: string | null
          description: string | null
          document_name: string
          file_path: string
          file_size: number | null
          id: string
          is_approved: boolean | null
          is_archived: boolean | null
          linked_module: string | null
          updated_at: string | null
          uploaded_by: string | null
          version_number: string
        }
        Insert: {
          approved_by?: string | null
          category: Database["public"]["Enums"]["doc_category"]
          created_at?: string | null
          description?: string | null
          document_name: string
          file_path: string
          file_size?: number | null
          id?: string
          is_approved?: boolean | null
          is_archived?: boolean | null
          linked_module?: string | null
          updated_at?: string | null
          uploaded_by?: string | null
          version_number: string
        }
        Update: {
          approved_by?: string | null
          category?: Database["public"]["Enums"]["doc_category"]
          created_at?: string | null
          description?: string | null
          document_name?: string
          file_path?: string
          file_size?: number | null
          id?: string
          is_approved?: boolean | null
          is_archived?: boolean | null
          linked_module?: string | null
          updated_at?: string | null
          uploaded_by?: string | null
          version_number?: string
        }
        Relationships: []
      }
      admin_task_logs: {
        Row: {
          changed_by: string | null
          created_at: string | null
          id: string
          metadata: Json | null
          new_status: Database["public"]["Enums"]["task_status"] | null
          note: string | null
          old_status: Database["public"]["Enums"]["task_status"] | null
          task_id: string
        }
        Insert: {
          changed_by?: string | null
          created_at?: string | null
          id?: string
          metadata?: Json | null
          new_status?: Database["public"]["Enums"]["task_status"] | null
          note?: string | null
          old_status?: Database["public"]["Enums"]["task_status"] | null
          task_id: string
        }
        Update: {
          changed_by?: string | null
          created_at?: string | null
          id?: string
          metadata?: Json | null
          new_status?: Database["public"]["Enums"]["task_status"] | null
          note?: string | null
          old_status?: Database["public"]["Enums"]["task_status"] | null
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_task_logs_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "admin_task_logs_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_task_logs_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "admin_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_task_templates: {
        Row: {
          assigned_role: Database["public"]["Enums"]["task_role"]
          auto_assign: boolean | null
          category: Database["public"]["Enums"]["task_category"]
          created_at: string | null
          created_by: string | null
          description: string | null
          frequency: Database["public"]["Enums"]["task_category"]
          id: string
          is_active: boolean | null
          metadata: Json | null
          priority: Database["public"]["Enums"]["task_priority"]
          title: string
          updated_at: string | null
        }
        Insert: {
          assigned_role: Database["public"]["Enums"]["task_role"]
          auto_assign?: boolean | null
          category: Database["public"]["Enums"]["task_category"]
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          frequency: Database["public"]["Enums"]["task_category"]
          id?: string
          is_active?: boolean | null
          metadata?: Json | null
          priority?: Database["public"]["Enums"]["task_priority"]
          title: string
          updated_at?: string | null
        }
        Update: {
          assigned_role?: Database["public"]["Enums"]["task_role"]
          auto_assign?: boolean | null
          category?: Database["public"]["Enums"]["task_category"]
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          frequency?: Database["public"]["Enums"]["task_category"]
          id?: string
          is_active?: boolean | null
          metadata?: Json | null
          priority?: Database["public"]["Enums"]["task_priority"]
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_task_templates_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "admin_task_templates_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_tasks: {
        Row: {
          assigned_role: Database["public"]["Enums"]["task_role"]
          assigned_to: string | null
          auto_generated: boolean | null
          category: Database["public"]["Enums"]["task_category"]
          completed_at: string | null
          completed_by: string | null
          created_at: string | null
          description: string | null
          due_date: string
          frequency: Database["public"]["Enums"]["task_category"]
          id: string
          metadata: Json | null
          priority: Database["public"]["Enums"]["task_priority"]
          status: Database["public"]["Enums"]["task_status"]
          template_id: string | null
          title: string
          updated_at: string | null
        }
        Insert: {
          assigned_role: Database["public"]["Enums"]["task_role"]
          assigned_to?: string | null
          auto_generated?: boolean | null
          category: Database["public"]["Enums"]["task_category"]
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          description?: string | null
          due_date: string
          frequency: Database["public"]["Enums"]["task_category"]
          id?: string
          metadata?: Json | null
          priority?: Database["public"]["Enums"]["task_priority"]
          status?: Database["public"]["Enums"]["task_status"]
          template_id?: string | null
          title: string
          updated_at?: string | null
        }
        Update: {
          assigned_role?: Database["public"]["Enums"]["task_role"]
          assigned_to?: string | null
          auto_generated?: boolean | null
          category?: Database["public"]["Enums"]["task_category"]
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          description?: string | null
          due_date?: string
          frequency?: Database["public"]["Enums"]["task_category"]
          id?: string
          metadata?: Json | null
          priority?: Database["public"]["Enums"]["task_priority"]
          status?: Database["public"]["Enums"]["task_status"]
          template_id?: string | null
          title?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "admin_tasks_assigned_to_fkey"
            columns: ["assigned_to"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "admin_tasks_completed_by_fkey"
            columns: ["completed_by"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "admin_tasks_completed_by_fkey"
            columns: ["completed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      api_keys: {
        Row: {
          created_at: string | null
          encrypted_value: string
          id: string
          integration_id: string | null
          key_identifier: string
          last_used: string | null
          name: string
          status: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          encrypted_value: string
          id?: string
          integration_id?: string | null
          key_identifier: string
          last_used?: string | null
          name: string
          status?: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          encrypted_value?: string
          id?: string
          integration_id?: string | null
          key_identifier?: string
          last_used?: string | null
          name?: string
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "api_keys_integration_id_fkey"
            columns: ["integration_id"]
            isOneToOne: false
            referencedRelation: "integrations"
            referencedColumns: ["id"]
          },
        ]
      }
      audit_logs: {
        Row: {
          action: string
          created_at: string | null
          details: Json | null
          entity_id: string | null
          entity_type: string | null
          id: string
          ip_address: unknown
          user_id: string | null
        }
        Insert: {
          action: string
          created_at?: string | null
          details?: Json | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          ip_address?: unknown
          user_id?: string | null
        }
        Update: {
          action?: string
          created_at?: string | null
          details?: Json | null
          entity_id?: string | null
          entity_type?: string | null
          id?: string
          ip_address?: unknown
          user_id?: string | null
        }
        Relationships: []
      }
      broker_profiles: {
        Row: {
          bond_amount: number | null
          bond_company: string | null
          bond_expiry_date: string | null
          bond_policy_number: string | null
          brokerage_name: string | null
          business_type: string | null
          created_at: string | null
          dba_name: string | null
          dot_number: string | null
          ein_tax_id: string | null
          id: string
          insurance_company: string | null
          insurance_coverage_limit: number | null
          insurance_expiry_date: string | null
          insurance_policy_number: string | null
          license_verified: boolean | null
          mailing_address: Json | null
          mc_number: string | null
          physical_address: Json | null
          primary_contact_email: string | null
          primary_contact_name: string | null
          primary_contact_phone: string | null
          primary_contact_title: string | null
          service_areas: string[] | null
          status: string | null
          updated_at: string | null
          user_id: string
          year_established: number | null
        }
        Insert: {
          bond_amount?: number | null
          bond_company?: string | null
          bond_expiry_date?: string | null
          bond_policy_number?: string | null
          brokerage_name?: string | null
          business_type?: string | null
          created_at?: string | null
          dba_name?: string | null
          dot_number?: string | null
          ein_tax_id?: string | null
          id?: string
          insurance_company?: string | null
          insurance_coverage_limit?: number | null
          insurance_expiry_date?: string | null
          insurance_policy_number?: string | null
          license_verified?: boolean | null
          mailing_address?: Json | null
          mc_number?: string | null
          physical_address?: Json | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          service_areas?: string[] | null
          status?: string | null
          updated_at?: string | null
          user_id: string
          year_established?: number | null
        }
        Update: {
          bond_amount?: number | null
          bond_company?: string | null
          bond_expiry_date?: string | null
          bond_policy_number?: string | null
          brokerage_name?: string | null
          business_type?: string | null
          created_at?: string | null
          dba_name?: string | null
          dot_number?: string | null
          ein_tax_id?: string | null
          id?: string
          insurance_company?: string | null
          insurance_coverage_limit?: number | null
          insurance_expiry_date?: string | null
          insurance_policy_number?: string | null
          license_verified?: boolean | null
          mailing_address?: Json | null
          mc_number?: string | null
          physical_address?: Json | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          service_areas?: string[] | null
          status?: string | null
          updated_at?: string | null
          user_id?: string
          year_established?: number | null
        }
        Relationships: []
      }
      carrier_company_status: {
        Row: {
          active_since: string | null
          carrier_type: string | null
          company_name: string | null
          compliance_score: number | null
          created_at: string | null
          dba_name: string | null
          dot_number: string | null
          driver_count: number | null
          ein_tax_id: string | null
          fleet_size: number | null
          id: string
          insurance_company: string | null
          insurance_coverage_limit: number | null
          insurance_coverage_type: string | null
          insurance_effective_date: string | null
          insurance_expiry_date: string | null
          insurance_policy_number: string | null
          insurance_verified: boolean | null
          last_updated: string | null
          mailing_address: Json | null
          mc_number: string | null
          operation_type: string | null
          physical_address: Json | null
          primary_contact_email: string | null
          primary_contact_name: string | null
          primary_contact_phone: string | null
          primary_contact_title: string | null
          status: string
          updated_at: string | null
          user_id: string
          vehicle_registration_numbers: string[] | null
          vehicle_types: string[] | null
          year_established: number | null
        }
        Insert: {
          active_since?: string | null
          carrier_type?: string | null
          company_name?: string | null
          compliance_score?: number | null
          created_at?: string | null
          dba_name?: string | null
          dot_number?: string | null
          driver_count?: number | null
          ein_tax_id?: string | null
          fleet_size?: number | null
          id?: string
          insurance_company?: string | null
          insurance_coverage_limit?: number | null
          insurance_coverage_type?: string | null
          insurance_effective_date?: string | null
          insurance_expiry_date?: string | null
          insurance_policy_number?: string | null
          insurance_verified?: boolean | null
          last_updated?: string | null
          mailing_address?: Json | null
          mc_number?: string | null
          operation_type?: string | null
          physical_address?: Json | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          status?: string
          updated_at?: string | null
          user_id: string
          vehicle_registration_numbers?: string[] | null
          vehicle_types?: string[] | null
          year_established?: number | null
        }
        Update: {
          active_since?: string | null
          carrier_type?: string | null
          company_name?: string | null
          compliance_score?: number | null
          created_at?: string | null
          dba_name?: string | null
          dot_number?: string | null
          driver_count?: number | null
          ein_tax_id?: string | null
          fleet_size?: number | null
          id?: string
          insurance_company?: string | null
          insurance_coverage_limit?: number | null
          insurance_coverage_type?: string | null
          insurance_effective_date?: string | null
          insurance_expiry_date?: string | null
          insurance_policy_number?: string | null
          insurance_verified?: boolean | null
          last_updated?: string | null
          mailing_address?: Json | null
          mc_number?: string | null
          operation_type?: string | null
          physical_address?: Json | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          status?: string
          updated_at?: string | null
          user_id?: string
          vehicle_registration_numbers?: string[] | null
          vehicle_types?: string[] | null
          year_established?: number | null
        }
        Relationships: []
      }
      carrier_drivers: {
        Row: {
          carrier_id: string
          created_at: string | null
          driver_id: string
          hire_date: string | null
          id: string
          updated_at: string | null
          vehicle_assignment: string | null
        }
        Insert: {
          carrier_id: string
          created_at?: string | null
          driver_id: string
          hire_date?: string | null
          id?: string
          updated_at?: string | null
          vehicle_assignment?: string | null
        }
        Update: {
          carrier_id?: string
          created_at?: string | null
          driver_id?: string
          hire_date?: string | null
          id?: string
          updated_at?: string | null
          vehicle_assignment?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "carrier_drivers_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_drivers_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_drivers_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: true
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_drivers_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      carrier_job_assignments: {
        Row: {
          assigned_at: string | null
          carrier_id: string
          completed_at: string | null
          created_at: string
          driver_id: string
          id: string
          job_id: string
          notes: string | null
          started_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          assigned_at?: string | null
          carrier_id: string
          completed_at?: string | null
          created_at?: string
          driver_id: string
          id?: string
          job_id: string
          notes?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          assigned_at?: string | null
          carrier_id?: string
          completed_at?: string | null
          created_at?: string
          driver_id?: string
          id?: string
          job_id?: string
          notes?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "carrier_job_assignments_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_job_assignments_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_job_assignments_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_job_assignments_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_job_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_job_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "carrier_job_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      carrier_jobs: {
        Row: {
          accepted_at: string | null
          actual_delivery_time: string | null
          assigned_driver_id: string | null
          broker_commission: number | null
          broker_id: string | null
          broker_notes: string | null
          cancellation_reason: string | null
          cancellation_reason_category:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at: string | null
          cargo_details: Json | null
          cargo_dimensions: Json | null
          cargo_weight: number | null
          carrier_id: string | null
          carrier_rate: number | null
          completed_at: string | null
          created_at: string
          created_by: string | null
          delay_reason: string | null
          delivery_contact_name: string | null
          delivery_contact_phone: string | null
          delivery_location: Json
          delivery_time: string | null
          description: string | null
          distance_miles: number | null
          equipment_type: string | null
          estimated_duration: number | null
          feedback: string | null
          hazmat_details: string | null
          id: string
          insurance_requirements: string | null
          invoice_id: string | null
          is_hazmat: boolean | null
          job_volume_kg: number | null
          metadata: Json | null
          pay_amount: number | null
          payment_terms: string | null
          pickup_contact_name: string | null
          pickup_contact_phone: string | null
          pickup_location: Json
          pickup_time: string | null
          priority: string | null
          proof_of_delivery_url: string | null
          rating: number | null
          required_certifications: string[] | null
          route_id: string | null
          secondary_status: string | null
          shipper_id: string | null
          signature_required: boolean | null
          special_instructions: string | null
          started_at: string | null
          status: string | null
          temperature_requirements: string | null
          title: string
          trailer_type: string | null
          updated_at: string
          vehicle_category_id: number | null
          vehicle_type_id: number | null
          vendor_id: string | null
        }
        Insert: {
          accepted_at?: string | null
          actual_delivery_time?: string | null
          assigned_driver_id?: string | null
          broker_commission?: number | null
          broker_id?: string | null
          broker_notes?: string | null
          cancellation_reason?: string | null
          cancellation_reason_category?:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at?: string | null
          cargo_details?: Json | null
          cargo_dimensions?: Json | null
          cargo_weight?: number | null
          carrier_id?: string | null
          carrier_rate?: number | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          delay_reason?: string | null
          delivery_contact_name?: string | null
          delivery_contact_phone?: string | null
          delivery_location: Json
          delivery_time?: string | null
          description?: string | null
          distance_miles?: number | null
          equipment_type?: string | null
          estimated_duration?: number | null
          feedback?: string | null
          hazmat_details?: string | null
          id?: string
          insurance_requirements?: string | null
          invoice_id?: string | null
          is_hazmat?: boolean | null
          job_volume_kg?: number | null
          metadata?: Json | null
          pay_amount?: number | null
          payment_terms?: string | null
          pickup_contact_name?: string | null
          pickup_contact_phone?: string | null
          pickup_location: Json
          pickup_time?: string | null
          priority?: string | null
          proof_of_delivery_url?: string | null
          rating?: number | null
          required_certifications?: string[] | null
          route_id?: string | null
          secondary_status?: string | null
          shipper_id?: string | null
          signature_required?: boolean | null
          special_instructions?: string | null
          started_at?: string | null
          status?: string | null
          temperature_requirements?: string | null
          title: string
          trailer_type?: string | null
          updated_at?: string
          vehicle_category_id?: number | null
          vehicle_type_id?: number | null
          vendor_id?: string | null
        }
        Update: {
          accepted_at?: string | null
          actual_delivery_time?: string | null
          assigned_driver_id?: string | null
          broker_commission?: number | null
          broker_id?: string | null
          broker_notes?: string | null
          cancellation_reason?: string | null
          cancellation_reason_category?:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at?: string | null
          cargo_details?: Json | null
          cargo_dimensions?: Json | null
          cargo_weight?: number | null
          carrier_id?: string | null
          carrier_rate?: number | null
          completed_at?: string | null
          created_at?: string
          created_by?: string | null
          delay_reason?: string | null
          delivery_contact_name?: string | null
          delivery_contact_phone?: string | null
          delivery_location?: Json
          delivery_time?: string | null
          description?: string | null
          distance_miles?: number | null
          equipment_type?: string | null
          estimated_duration?: number | null
          feedback?: string | null
          hazmat_details?: string | null
          id?: string
          insurance_requirements?: string | null
          invoice_id?: string | null
          is_hazmat?: boolean | null
          job_volume_kg?: number | null
          metadata?: Json | null
          pay_amount?: number | null
          payment_terms?: string | null
          pickup_contact_name?: string | null
          pickup_contact_phone?: string | null
          pickup_location?: Json
          pickup_time?: string | null
          priority?: string | null
          proof_of_delivery_url?: string | null
          rating?: number | null
          required_certifications?: string[] | null
          route_id?: string | null
          secondary_status?: string | null
          shipper_id?: string | null
          signature_required?: boolean | null
          special_instructions?: string | null
          started_at?: string | null
          status?: string | null
          temperature_requirements?: string | null
          title?: string
          trailer_type?: string | null
          updated_at?: string
          vehicle_category_id?: number | null
          vehicle_type_id?: number | null
          vendor_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "carrier_jobs_assigned_driver_id_fkey"
            columns: ["assigned_driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_jobs_assigned_driver_id_fkey"
            columns: ["assigned_driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_jobs_broker_id_fkey"
            columns: ["broker_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_jobs_broker_id_fkey"
            columns: ["broker_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_jobs_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_jobs_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_jobs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_jobs_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_jobs_shipper_id_fkey"
            columns: ["shipper_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_jobs_shipper_id_fkey"
            columns: ["shipper_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "carrier_jobs_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "carrier_jobs_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      compliance_documents: {
        Row: {
          coverage_amount: number | null
          created_at: string | null
          document_category: string
          document_name: string
          document_type: string
          expiry_date: string | null
          file_path: string | null
          id: string
          issue_date: string | null
          issuing_authority: string | null
          metadata: Json | null
          notes: string | null
          policy_number: string | null
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          coverage_amount?: number | null
          created_at?: string | null
          document_category: string
          document_name: string
          document_type: string
          expiry_date?: string | null
          file_path?: string | null
          id?: string
          issue_date?: string | null
          issuing_authority?: string | null
          metadata?: Json | null
          notes?: string | null
          policy_number?: string | null
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          coverage_amount?: number | null
          created_at?: string | null
          document_category?: string
          document_name?: string
          document_type?: string
          expiry_date?: string | null
          file_path?: string | null
          id?: string
          issue_date?: string | null
          issuing_authority?: string | null
          metadata?: Json | null
          notes?: string | null
          policy_number?: string | null
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      custom_tasks: {
        Row: {
          assigned_roles: string[] | null
          category: string | null
          created_at: string | null
          created_by: string | null
          custom_link: string | null
          deleted_at: string | null
          deleted_by: string | null
          description: string | null
          due_date: string | null
          id: string
          is_deleted: boolean
          name: string
          priority: string | null
          redirect_path: Json | null
          required: boolean | null
          status: string | null
          task_approval_status: string | null
          task_approved_at: string | null
          task_approved_by: string | null
          task_form_schema: Json | null
          updated_at: string | null
        }
        Insert: {
          assigned_roles?: string[] | null
          category?: string | null
          created_at?: string | null
          created_by?: string | null
          custom_link?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          is_deleted?: boolean
          name: string
          priority?: string | null
          redirect_path?: Json | null
          required?: boolean | null
          status?: string | null
          task_approval_status?: string | null
          task_approved_at?: string | null
          task_approved_by?: string | null
          task_form_schema?: Json | null
          updated_at?: string | null
        }
        Update: {
          assigned_roles?: string[] | null
          category?: string | null
          created_at?: string | null
          created_by?: string | null
          custom_link?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          description?: string | null
          due_date?: string | null
          id?: string
          is_deleted?: boolean
          name?: string
          priority?: string | null
          redirect_path?: Json | null
          required?: boolean | null
          status?: string | null
          task_approval_status?: string | null
          task_approved_at?: string | null
          task_approved_by?: string | null
          task_form_schema?: Json | null
          updated_at?: string | null
        }
        Relationships: []
      }
      default_task_templates: {
        Row: {
          created_at: string | null
          created_by: string | null
          display_order: number | null
          id: string
          role_key: string
          task_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          display_order?: number | null
          id?: string
          role_key: string
          task_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          display_order?: number | null
          id?: string
          role_key?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "default_task_templates_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "custom_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      dispute_evidence: {
        Row: {
          created_at: string | null
          description: string | null
          dispute_id: string
          file_name: string
          file_path: string
          file_size: number | null
          file_type: string | null
          id: string
          uploaded_by: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          dispute_id: string
          file_name: string
          file_path: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          uploaded_by?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          dispute_id?: string
          file_name?: string
          file_path?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          uploaded_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "dispute_evidence_dispute_id_fkey"
            columns: ["dispute_id"]
            isOneToOne: false
            referencedRelation: "disputes"
            referencedColumns: ["id"]
          },
        ]
      }
      dispute_messages: {
        Row: {
          created_at: string | null
          dispute_id: string
          id: string
          is_internal: boolean | null
          message: string
          message_type: string
          metadata: Json | null
          sender_id: string | null
        }
        Insert: {
          created_at?: string | null
          dispute_id: string
          id?: string
          is_internal?: boolean | null
          message: string
          message_type?: string
          metadata?: Json | null
          sender_id?: string | null
        }
        Update: {
          created_at?: string | null
          dispute_id?: string
          id?: string
          is_internal?: boolean | null
          message?: string
          message_type?: string
          metadata?: Json | null
          sender_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "dispute_messages_dispute_id_fkey"
            columns: ["dispute_id"]
            isOneToOne: false
            referencedRelation: "disputes"
            referencedColumns: ["id"]
          },
        ]
      }
      disputes: {
        Row: {
          assigned_to: string | null
          created_at: string | null
          description: string | null
          dispute_type: string
          id: string
          job_id: string | null
          parties_involved: Json | null
          priority: string
          reporter_id: string | null
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          assigned_to?: string | null
          created_at?: string | null
          description?: string | null
          dispute_type: string
          id?: string
          job_id?: string | null
          parties_involved?: Json | null
          priority?: string
          reporter_id?: string | null
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          assigned_to?: string | null
          created_at?: string | null
          description?: string | null
          dispute_type?: string
          id?: string
          job_id?: string | null
          parties_involved?: Json | null
          priority?: string
          reporter_id?: string | null
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "disputes_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "disputes_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "disputes_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      document_activity_log: {
        Row: {
          action: string
          admin_id: string | null
          created_at: string | null
          document_id: string | null
          document_name: string
          id: string
          metadata: Json | null
        }
        Insert: {
          action: string
          admin_id?: string | null
          created_at?: string | null
          document_id?: string | null
          document_name: string
          id?: string
          metadata?: Json | null
        }
        Update: {
          action?: string
          admin_id?: string | null
          created_at?: string | null
          document_id?: string | null
          document_name?: string
          id?: string
          metadata?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "document_activity_log_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "admin_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      document_versions: {
        Row: {
          created_at: string | null
          document_id: string | null
          file_path: string
          id: string
          uploaded_by: string | null
          version_number: string
        }
        Insert: {
          created_at?: string | null
          document_id?: string | null
          file_path: string
          id?: string
          uploaded_by?: string | null
          version_number: string
        }
        Update: {
          created_at?: string | null
          document_id?: string | null
          file_path?: string
          id?: string
          uploaded_by?: string | null
          version_number?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_versions_document_id_fkey"
            columns: ["document_id"]
            isOneToOne: false
            referencedRelation: "admin_documents"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_compliance: {
        Row: {
          cdl_document_path: string | null
          cdl_expiry_date: string | null
          cdl_status: string
          compliance_score: number | null
          created_at: string
          driver_name: string
          hazmat_document_path: string | null
          hazmat_expiry_date: string | null
          hazmat_status: string
          id: string
          medical_document_path: string | null
          medical_expiry_date: string | null
          medical_status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          cdl_document_path?: string | null
          cdl_expiry_date?: string | null
          cdl_status: string
          compliance_score?: number | null
          created_at?: string
          driver_name: string
          hazmat_document_path?: string | null
          hazmat_expiry_date?: string | null
          hazmat_status: string
          id?: string
          medical_document_path?: string | null
          medical_expiry_date?: string | null
          medical_status: string
          updated_at?: string
          user_id: string
        }
        Update: {
          cdl_document_path?: string | null
          cdl_expiry_date?: string | null
          cdl_status?: string
          compliance_score?: number | null
          created_at?: string
          driver_name?: string
          hazmat_document_path?: string | null
          hazmat_expiry_date?: string | null
          hazmat_status?: string
          id?: string
          medical_document_path?: string | null
          medical_expiry_date?: string | null
          medical_status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      driver_earnings: {
        Row: {
          amount: number
          created_at: string | null
          driver_id: string
          earning_type: string | null
          id: string
          job_id: string | null
          paid_at: string | null
          status: string | null
        }
        Insert: {
          amount: number
          created_at?: string | null
          driver_id: string
          earning_type?: string | null
          id?: string
          job_id?: string | null
          paid_at?: string | null
          status?: string | null
        }
        Update: {
          amount?: number
          created_at?: string | null
          driver_id?: string
          earning_type?: string | null
          id?: string
          job_id?: string | null
          paid_at?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "driver_earnings_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "driver_earnings_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "driver_earnings_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_expenses: {
        Row: {
          amount: number
          category: string | null
          created_at: string | null
          description: string | null
          driver_id: string
          expense_date: string
          expense_type: string
          id: string
          job_id: string | null
          metadata: Json | null
          receipt_url: string | null
          updated_at: string | null
        }
        Insert: {
          amount: number
          category?: string | null
          created_at?: string | null
          description?: string | null
          driver_id: string
          expense_date: string
          expense_type: string
          id?: string
          job_id?: string | null
          metadata?: Json | null
          receipt_url?: string | null
          updated_at?: string | null
        }
        Update: {
          amount?: number
          category?: string | null
          created_at?: string | null
          description?: string | null
          driver_id?: string
          expense_date?: string
          expense_type?: string
          id?: string
          job_id?: string | null
          metadata?: Json | null
          receipt_url?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      driver_insurance: {
        Row: {
          company: string | null
          coverage_amount: number | null
          created_at: string | null
          driver_id: string
          expiry_date: string | null
          id: string
          is_active: boolean | null
          policy_number: string | null
          updated_at: string | null
          vehicle_id: string | null
        }
        Insert: {
          company?: string | null
          coverage_amount?: number | null
          created_at?: string | null
          driver_id: string
          expiry_date?: string | null
          id?: string
          is_active?: boolean | null
          policy_number?: string | null
          updated_at?: string | null
          vehicle_id?: string | null
        }
        Update: {
          company?: string | null
          coverage_amount?: number | null
          created_at?: string | null
          driver_id?: string
          expiry_date?: string | null
          id?: string
          is_active?: boolean | null
          policy_number?: string | null
          updated_at?: string | null
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "driver_insurance_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "driver_insurance_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "driver_insurance_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "driver_vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_payment_methods: {
        Row: {
          account_holder: string | null
          account_number_last4: string | null
          bank_name: string | null
          created_at: string | null
          driver_id: string
          id: string
          is_primary: boolean | null
          payment_type: string
          routing_number: string | null
          updated_at: string | null
        }
        Insert: {
          account_holder?: string | null
          account_number_last4?: string | null
          bank_name?: string | null
          created_at?: string | null
          driver_id: string
          id?: string
          is_primary?: boolean | null
          payment_type?: string
          routing_number?: string | null
          updated_at?: string | null
        }
        Update: {
          account_holder?: string | null
          account_number_last4?: string | null
          bank_name?: string | null
          created_at?: string | null
          driver_id?: string
          id?: string
          is_primary?: boolean | null
          payment_type?: string
          routing_number?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "driver_payment_methods_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "driver_payment_methods_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_profiles: {
        Row: {
          background_check_date: string | null
          background_check_status: string | null
          cdl_endorsed: boolean | null
          cdl_number: string | null
          created_at: string | null
          emergency_contact_name: string | null
          emergency_contact_phone: string | null
          emergency_contact_relationship: string | null
          id: string
          license_class: string | null
          license_expiry_date: string | null
          license_number: string | null
          license_state: string | null
          medical_card_expiry: string | null
          preferred_routes: string[] | null
          status: string | null
          updated_at: string | null
          user_id: string
          years_of_experience: number | null
        }
        Insert: {
          background_check_date?: string | null
          background_check_status?: string | null
          cdl_endorsed?: boolean | null
          cdl_number?: string | null
          created_at?: string | null
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          emergency_contact_relationship?: string | null
          id?: string
          license_class?: string | null
          license_expiry_date?: string | null
          license_number?: string | null
          license_state?: string | null
          medical_card_expiry?: string | null
          preferred_routes?: string[] | null
          status?: string | null
          updated_at?: string | null
          user_id: string
          years_of_experience?: number | null
        }
        Update: {
          background_check_date?: string | null
          background_check_status?: string | null
          cdl_endorsed?: boolean | null
          cdl_number?: string | null
          created_at?: string | null
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          emergency_contact_relationship?: string | null
          id?: string
          license_class?: string | null
          license_expiry_date?: string | null
          license_number?: string | null
          license_state?: string | null
          medical_card_expiry?: string | null
          preferred_routes?: string[] | null
          status?: string | null
          updated_at?: string | null
          user_id?: string
          years_of_experience?: number | null
        }
        Relationships: []
      }
      driver_ratings: {
        Row: {
          created_at: string | null
          driver_id: string
          id: string
          job_id: string | null
          rated_by: string | null
          rating: number | null
          review_text: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          driver_id: string
          id?: string
          job_id?: string | null
          rated_by?: string | null
          rating?: number | null
          review_text?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          driver_id?: string
          id?: string
          job_id?: string | null
          rated_by?: string | null
          rating?: number | null
          review_text?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      driver_status: {
        Row: {
          created_at: string | null
          driver_id: string
          id: string
          is_online: boolean | null
          last_location: Json | null
          last_ping: string | null
          status_updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          driver_id: string
          id?: string
          is_online?: boolean | null
          last_location?: Json | null
          last_ping?: string | null
          status_updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          driver_id?: string
          id?: string
          is_online?: boolean | null
          last_location?: Json | null
          last_ping?: string | null
          status_updated_at?: string | null
        }
        Relationships: []
      }
      driver_support_messages: {
        Row: {
          created_at: string | null
          id: string
          is_support_agent: boolean | null
          message: string
          sender_name: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_support_agent?: boolean | null
          message: string
          sender_name?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_support_agent?: boolean | null
          message?: string
          sender_name?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      driver_support_tickets: {
        Row: {
          assignment_id: string | null
          created_at: string
          details: string
          driver_id: string | null
          id: string
          issue_context: string
          issue_type: string
          job_id: string | null
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
          updated_at: string
        }
        Insert: {
          assignment_id?: string | null
          created_at?: string
          details: string
          driver_id?: string | null
          id?: string
          issue_context: string
          issue_type: string
          job_id?: string | null
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          assignment_id?: string | null
          created_at?: string
          details?: string
          driver_id?: string | null
          id?: string
          issue_context?: string
          issue_type?: string
          job_id?: string | null
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "driver_support_tickets_assignment_id_fkey"
            columns: ["assignment_id"]
            isOneToOne: false
            referencedRelation: "job_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "driver_support_tickets_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "driver_support_tickets_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "driver_support_tickets_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_vehicles: {
        Row: {
          color: string | null
          created_at: string | null
          driver_id: string
          id: string
          is_primary: boolean | null
          license_plate: string | null
          make: string | null
          model: string | null
          registration_expiry: string | null
          updated_at: string | null
          vin: string | null
          year: string | null
        }
        Insert: {
          color?: string | null
          created_at?: string | null
          driver_id: string
          id?: string
          is_primary?: boolean | null
          license_plate?: string | null
          make?: string | null
          model?: string | null
          registration_expiry?: string | null
          updated_at?: string | null
          vin?: string | null
          year?: string | null
        }
        Update: {
          color?: string | null
          created_at?: string | null
          driver_id?: string
          id?: string
          is_primary?: boolean | null
          license_plate?: string | null
          make?: string | null
          model?: string | null
          registration_expiry?: string | null
          updated_at?: string | null
          vin?: string | null
          year?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "driver_vehicles_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "driver_vehicles_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      financial_data_access_log: {
        Row: {
          accessed_by: string | null
          action: string | null
          created_at: string | null
          data_type: string | null
          id: string
          ip_address: unknown
          metadata: Json | null
          user_id: string
        }
        Insert: {
          accessed_by?: string | null
          action?: string | null
          created_at?: string | null
          data_type?: string | null
          id?: string
          ip_address?: unknown
          metadata?: Json | null
          user_id: string
        }
        Update: {
          accessed_by?: string | null
          action?: string | null
          created_at?: string | null
          data_type?: string | null
          id?: string
          ip_address?: unknown
          metadata?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      integrations: {
        Row: {
          config: Json | null
          created_at: string | null
          description: string | null
          icon: string | null
          id: string
          integration_type: string
          last_sync: string | null
          name: string
          status: string
          updated_at: string | null
        }
        Insert: {
          config?: Json | null
          created_at?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          integration_type: string
          last_sync?: string | null
          name: string
          status?: string
          updated_at?: string | null
        }
        Update: {
          config?: Json | null
          created_at?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          integration_type?: string
          last_sync?: string | null
          name?: string
          status?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount: number
          client: string
          created_at: string | null
          due_date: string
          id: string
          invoice_number: string
          paid_date: string | null
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount: number
          client: string
          created_at?: string | null
          due_date: string
          id?: string
          invoice_number: string
          paid_date?: string | null
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          client?: string
          created_at?: string | null
          due_date?: string
          id?: string
          invoice_number?: string
          paid_date?: string | null
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      job_assignments: {
        Row: {
          accepted_at: string | null
          assigned_at: string | null
          completed_at: string | null
          driver_id: string
          id: string
          job_id: string
          pickup_photo_url: string | null
          started_at: string | null
          status: string | null
        }
        Insert: {
          accepted_at?: string | null
          assigned_at?: string | null
          completed_at?: string | null
          driver_id: string
          id?: string
          job_id: string
          pickup_photo_url?: string | null
          started_at?: string | null
          status?: string | null
        }
        Update: {
          accepted_at?: string | null
          assigned_at?: string | null
          completed_at?: string | null
          driver_id?: string
          id?: string
          job_id?: string
          pickup_photo_url?: string | null
          started_at?: string | null
          status?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "job_assignments_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      job_claim_authorization_requests: {
        Row: {
          admin_notes: string | null
          created_at: string | null
          driver_current_jobs: Json | null
          driver_id: string
          driver_location: Json | null
          id: string
          job_id: string
          request_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          admin_notes?: string | null
          created_at?: string | null
          driver_current_jobs?: Json | null
          driver_id: string
          driver_location?: Json | null
          id?: string
          job_id: string
          request_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          admin_notes?: string | null
          created_at?: string | null
          driver_current_jobs?: Json | null
          driver_id?: string
          driver_location?: Json | null
          id?: string
          job_id?: string
          request_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "job_claim_authorization_requests_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_claim_authorization_requests_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "job_claim_authorization_requests_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      jobs: {
        Row: {
          accepted_at: string | null
          actual_delivery_time: string | null
          assigned_driver_id: string | null
          broker_commission: number | null
          broker_id: string | null
          broker_notes: string | null
          cancellation_reason: string | null
          cancellation_reason_category:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at: string | null
          cargo_details: Json | null
          cargo_dimensions: Json | null
          cargo_weight: number | null
          carrier_display_name: string | null
          carrier_id: string | null
          carrier_rate: number | null
          completed_at: string | null
          created_at: string | null
          created_by: string | null
          delay_reason: string | null
          delivery_contact_name: string | null
          delivery_contact_phone: string | null
          delivery_location: Json
          delivery_time: string | null
          description: string | null
          distance_miles: number | null
          driver_display_name: string | null
          equipment_type: string | null
          estimated_duration: number | null
          feedback: string | null
          hazmat_details: string | null
          id: string
          insurance_requirements: string | null
          invoice_id: string | null
          is_hazmat: boolean | null
          job_volume_kg: number | null
          metadata: Json | null
          pay_amount: number | null
          payment_terms: string | null
          pickup_contact_name: string | null
          pickup_contact_phone: string | null
          pickup_location: Json
          pickup_time: string | null
          priority: string | null
          proof_of_delivery_url: string | null
          rating: number | null
          required_certifications: string[] | null
          route_id: string | null
          secondary_status: string | null
          shipper_id: string | null
          signature_required: boolean | null
          special_instructions: string | null
          started_at: string | null
          status: string | null
          temperature_requirements: string | null
          title: string
          trailer_type: string | null
          updated_at: string | null
          vehicle_category_id: number | null
          vehicle_type_id: number | null
          vendor_id: string | null
        }
        Insert: {
          accepted_at?: string | null
          actual_delivery_time?: string | null
          assigned_driver_id?: string | null
          broker_commission?: number | null
          broker_id?: string | null
          broker_notes?: string | null
          cancellation_reason?: string | null
          cancellation_reason_category?:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at?: string | null
          cargo_details?: Json | null
          cargo_dimensions?: Json | null
          cargo_weight?: number | null
          carrier_display_name?: string | null
          carrier_id?: string | null
          carrier_rate?: number | null
          completed_at?: string | null
          created_at?: string | null
          created_by?: string | null
          delay_reason?: string | null
          delivery_contact_name?: string | null
          delivery_contact_phone?: string | null
          delivery_location: Json
          delivery_time?: string | null
          description?: string | null
          distance_miles?: number | null
          driver_display_name?: string | null
          equipment_type?: string | null
          estimated_duration?: number | null
          feedback?: string | null
          hazmat_details?: string | null
          id?: string
          insurance_requirements?: string | null
          invoice_id?: string | null
          is_hazmat?: boolean | null
          job_volume_kg?: number | null
          metadata?: Json | null
          pay_amount?: number | null
          payment_terms?: string | null
          pickup_contact_name?: string | null
          pickup_contact_phone?: string | null
          pickup_location: Json
          pickup_time?: string | null
          priority?: string | null
          proof_of_delivery_url?: string | null
          rating?: number | null
          required_certifications?: string[] | null
          route_id?: string | null
          secondary_status?: string | null
          shipper_id?: string | null
          signature_required?: boolean | null
          special_instructions?: string | null
          started_at?: string | null
          status?: string | null
          temperature_requirements?: string | null
          title: string
          trailer_type?: string | null
          updated_at?: string | null
          vehicle_category_id?: number | null
          vehicle_type_id?: number | null
          vendor_id?: string | null
        }
        Update: {
          accepted_at?: string | null
          actual_delivery_time?: string | null
          assigned_driver_id?: string | null
          broker_commission?: number | null
          broker_id?: string | null
          broker_notes?: string | null
          cancellation_reason?: string | null
          cancellation_reason_category?:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at?: string | null
          cargo_details?: Json | null
          cargo_dimensions?: Json | null
          cargo_weight?: number | null
          carrier_display_name?: string | null
          carrier_id?: string | null
          carrier_rate?: number | null
          completed_at?: string | null
          created_at?: string | null
          created_by?: string | null
          delay_reason?: string | null
          delivery_contact_name?: string | null
          delivery_contact_phone?: string | null
          delivery_location?: Json
          delivery_time?: string | null
          description?: string | null
          distance_miles?: number | null
          driver_display_name?: string | null
          equipment_type?: string | null
          estimated_duration?: number | null
          feedback?: string | null
          hazmat_details?: string | null
          id?: string
          insurance_requirements?: string | null
          invoice_id?: string | null
          is_hazmat?: boolean | null
          job_volume_kg?: number | null
          metadata?: Json | null
          pay_amount?: number | null
          payment_terms?: string | null
          pickup_contact_name?: string | null
          pickup_contact_phone?: string | null
          pickup_location?: Json
          pickup_time?: string | null
          priority?: string | null
          proof_of_delivery_url?: string | null
          rating?: number | null
          required_certifications?: string[] | null
          route_id?: string | null
          secondary_status?: string | null
          shipper_id?: string | null
          signature_required?: boolean | null
          special_instructions?: string | null
          started_at?: string | null
          status?: string | null
          temperature_requirements?: string | null
          title?: string
          trailer_type?: string | null
          updated_at?: string | null
          vehicle_category_id?: number | null
          vehicle_type_id?: number | null
          vendor_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "jobs_assigned_driver_id_fkey"
            columns: ["assigned_driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_assigned_driver_id_fkey"
            columns: ["assigned_driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_broker_id_fkey"
            columns: ["broker_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_broker_id_fkey"
            columns: ["broker_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_route_id_fkey"
            columns: ["route_id"]
            isOneToOne: false
            referencedRelation: "routes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_category"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "jobs_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "jobs_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "vehicle_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["vehicle_type_id"]
          },
          {
            foreignKeyName: "jobs_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "vehicle_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      kyc_audit_log: {
        Row: {
          action: string
          admin_id: string | null
          created_at: string | null
          id: string
          kyc_submission_id: string
          metadata: Json | null
          new_status: string | null
          notes: string | null
          old_status: string | null
          user_id: string
        }
        Insert: {
          action: string
          admin_id?: string | null
          created_at?: string | null
          id?: string
          kyc_submission_id: string
          metadata?: Json | null
          new_status?: string | null
          notes?: string | null
          old_status?: string | null
          user_id: string
        }
        Update: {
          action?: string
          admin_id?: string | null
          created_at?: string | null
          id?: string
          kyc_submission_id?: string
          metadata?: Json | null
          new_status?: string | null
          notes?: string | null
          old_status?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "kyc_audit_log_kyc_submission_id_fkey"
            columns: ["kyc_submission_id"]
            isOneToOne: false
            referencedRelation: "kyc_submissions"
            referencedColumns: ["id"]
          },
        ]
      }
      kyc_submissions: {
        Row: {
          admin_notes: string | null
          government_id_path: string
          id: string
          metadata: Json | null
          proof_of_address_path: string
          rejection_reason: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          selfie_path: string | null
          status: string
          submitted_at: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          government_id_path: string
          id?: string
          metadata?: Json | null
          proof_of_address_path: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          selfie_path?: string | null
          status?: string
          submitted_at?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          government_id_path?: string
          id?: string
          metadata?: Json | null
          proof_of_address_path?: string
          rejection_reason?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          selfie_path?: string | null
          status?: string
          submitted_at?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      maintenance_schedules: {
        Row: {
          completed_at: string | null
          created_at: string | null
          id: string
          maintenance_type: string
          notes: string | null
          scheduled_date: string
          status: string
          updated_at: string | null
          user_id: string
          vehicle_id: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          id?: string
          maintenance_type: string
          notes?: string | null
          scheduled_date: string
          status?: string
          updated_at?: string | null
          user_id: string
          vehicle_id?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          id?: string
          maintenance_type?: string
          notes?: string | null
          scheduled_date?: string
          status?: string
          updated_at?: string | null
          user_id?: string
          vehicle_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "maintenance_schedules_vehicle_id_fkey"
            columns: ["vehicle_id"]
            isOneToOne: false
            referencedRelation: "vehicles"
            referencedColumns: ["id"]
          },
        ]
      }
      menu_permissions: {
        Row: {
          created_at: string | null
          id: string
          menu_id: string
          permission_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          menu_id: string
          permission_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          menu_id?: string
          permission_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "menu_permissions_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "menus"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "menu_permissions_permission_id_fkey"
            columns: ["permission_id"]
            isOneToOne: false
            referencedRelation: "permissions"
            referencedColumns: ["id"]
          },
        ]
      }
      menu_subtabs: {
        Row: {
          created_at: string | null
          display_order: number | null
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          tab_id: string
        }
        Insert: {
          created_at?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          tab_id: string
        }
        Update: {
          created_at?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          tab_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "menu_subtabs_tab_id_fkey"
            columns: ["tab_id"]
            isOneToOne: false
            referencedRelation: "menu_tabs"
            referencedColumns: ["id"]
          },
        ]
      }
      menu_tabs: {
        Row: {
          created_at: string | null
          display_order: number | null
          icon: string | null
          id: string
          is_active: boolean | null
          menu_id: string
          name: string
        }
        Insert: {
          created_at?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          menu_id: string
          name: string
        }
        Update: {
          created_at?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          menu_id?: string
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "menu_tabs_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "menus"
            referencedColumns: ["id"]
          },
        ]
      }
      menu_widgets: {
        Row: {
          created_at: string | null
          description: string | null
          display_order: number | null
          icon: string | null
          id: string
          is_active: boolean | null
          link: string | null
          name: string
          subtab_id: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          link?: string | null
          name: string
          subtab_id: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          link?: string | null
          name?: string
          subtab_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "menu_widgets_subtab_id_fkey"
            columns: ["subtab_id"]
            isOneToOne: false
            referencedRelation: "menu_subtabs"
            referencedColumns: ["id"]
          },
        ]
      }
      menus: {
        Row: {
          category: string | null
          created_at: string | null
          display_mode: string
          display_order: number | null
          icon: string | null
          id: string
          is_active: boolean | null
          name: string
          path: string | null
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          display_mode?: string
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name: string
          path?: string | null
        }
        Update: {
          category?: string | null
          created_at?: string | null
          display_mode?: string
          display_order?: number | null
          icon?: string | null
          id?: string
          is_active?: boolean | null
          name?: string
          path?: string | null
        }
        Relationships: []
      }
      notification_event_templates: {
        Row: {
          created_at: string | null
          default_link: string | null
          default_message: string
          default_title: string
          event_category: string
          event_type: Database["public"]["Enums"]["notification_event_type"]
          id: string
          is_active: boolean | null
          priority: string | null
          requires_admin_approval: boolean | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          default_link?: string | null
          default_message: string
          default_title: string
          event_category: string
          event_type: Database["public"]["Enums"]["notification_event_type"]
          id?: string
          is_active?: boolean | null
          priority?: string | null
          requires_admin_approval?: boolean | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          default_link?: string | null
          default_message?: string
          default_title?: string
          event_category?: string
          event_type?: Database["public"]["Enums"]["notification_event_type"]
          id?: string
          is_active?: boolean | null
          priority?: string | null
          requires_admin_approval?: boolean | null
          updated_at?: string | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string | null
          id: string
          is_read: boolean | null
          link: string | null
          message: string
          metadata: Json | null
          sender_id: string | null
          title: string
          type: Database["public"]["Enums"]["notification_type"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          link?: string | null
          message: string
          metadata?: Json | null
          sender_id?: string | null
          title: string
          type: Database["public"]["Enums"]["notification_type"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_read?: boolean | null
          link?: string | null
          message?: string
          metadata?: Json | null
          sender_id?: string | null
          title?: string
          type?: Database["public"]["Enums"]["notification_type"]
          user_id?: string
        }
        Relationships: []
      }
      onboarding_data: {
        Row: {
          completed_steps: number[] | null
          created_at: string | null
          id: string
          is_complete: boolean | null
          last_step_number: number | null
          step_data: Json | null
          step_number: number
          step_title: string
          steps: Json | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          completed_steps?: number[] | null
          created_at?: string | null
          id?: string
          is_complete?: boolean | null
          last_step_number?: number | null
          step_data?: Json | null
          step_number: number
          step_title: string
          steps?: Json | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          completed_steps?: number[] | null
          created_at?: string | null
          id?: string
          is_complete?: boolean | null
          last_step_number?: number | null
          step_data?: Json | null
          step_number?: number
          step_title?: string
          steps?: Json | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      permissions: {
        Row: {
          category: string | null
          created_at: string | null
          description: string | null
          id: string
          name: string
        }
        Insert: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          name: string
        }
        Update: {
          category?: string | null
          created_at?: string | null
          description?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          category: string
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          is_global: boolean | null
          modified_by: string | null
          role_access: string[] | null
          setting_key: string
          setting_value: Json
          status: string | null
          subcategory: string | null
          updated_at: string | null
          value_type: string
        }
        Insert: {
          category: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_global?: boolean | null
          modified_by?: string | null
          role_access?: string[] | null
          setting_key: string
          setting_value?: Json
          status?: string | null
          subcategory?: string | null
          updated_at?: string | null
          value_type?: string
        }
        Update: {
          category?: string
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_global?: boolean | null
          modified_by?: string | null
          role_access?: string[] | null
          setting_key?: string
          setting_value?: Json
          status?: string | null
          subcategory?: string | null
          updated_at?: string | null
          value_type?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          address_lat: number | null
          address_lng: number | null
          avatar_url: string | null
          capacity_volume_kg: number | null
          created_at: string | null
          email: string | null
          email_confirmed: boolean | null
          emergency_contact_name: string | null
          emergency_contact_phone: string | null
          first_login_completed: boolean | null
          full_address: string | null
          full_name: string | null
          id: string
          is_active: boolean | null
          is_approved: boolean | null
          is_system_account: boolean | null
          kyc_status: string | null
          kyc_verified: boolean | null
          mfa_backup_codes: Json | null
          mfa_enabled: boolean | null
          mfa_method: string | null
          mfa_phone: string | null
          mfa_pin_hash: string | null
          mfa_totp_secret: string | null
          notification_preferences: Json | null
          onboarding_complete: boolean | null
          phone: string | null
          role_id: string | null
          role_key: Database["public"]["Enums"]["app_role"] | null
          role_name: string | null
          sub_role: Database["public"]["Enums"]["sub_role"] | null
          updated_at: string | null
          vehicle_category_id: number | null
          vehicle_type_id: number | null
        }
        Insert: {
          address_lat?: number | null
          address_lng?: number | null
          avatar_url?: string | null
          capacity_volume_kg?: number | null
          created_at?: string | null
          email?: string | null
          email_confirmed?: boolean | null
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          first_login_completed?: boolean | null
          full_address?: string | null
          full_name?: string | null
          id: string
          is_active?: boolean | null
          is_approved?: boolean | null
          is_system_account?: boolean | null
          kyc_status?: string | null
          kyc_verified?: boolean | null
          mfa_backup_codes?: Json | null
          mfa_enabled?: boolean | null
          mfa_method?: string | null
          mfa_phone?: string | null
          mfa_pin_hash?: string | null
          mfa_totp_secret?: string | null
          notification_preferences?: Json | null
          onboarding_complete?: boolean | null
          phone?: string | null
          role_id?: string | null
          role_key?: Database["public"]["Enums"]["app_role"] | null
          role_name?: string | null
          sub_role?: Database["public"]["Enums"]["sub_role"] | null
          updated_at?: string | null
          vehicle_category_id?: number | null
          vehicle_type_id?: number | null
        }
        Update: {
          address_lat?: number | null
          address_lng?: number | null
          avatar_url?: string | null
          capacity_volume_kg?: number | null
          created_at?: string | null
          email?: string | null
          email_confirmed?: boolean | null
          emergency_contact_name?: string | null
          emergency_contact_phone?: string | null
          first_login_completed?: boolean | null
          full_address?: string | null
          full_name?: string | null
          id?: string
          is_active?: boolean | null
          is_approved?: boolean | null
          is_system_account?: boolean | null
          kyc_status?: string | null
          kyc_verified?: boolean | null
          mfa_backup_codes?: Json | null
          mfa_enabled?: boolean | null
          mfa_method?: string | null
          mfa_phone?: string | null
          mfa_pin_hash?: string | null
          mfa_totp_secret?: string | null
          notification_preferences?: Json | null
          onboarding_complete?: boolean | null
          phone?: string | null
          role_id?: string | null
          role_key?: Database["public"]["Enums"]["app_role"] | null
          role_name?: string | null
          sub_role?: Database["public"]["Enums"]["sub_role"] | null
          updated_at?: string | null
          vehicle_category_id?: number | null
          vehicle_type_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "profiles_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_category"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "profiles_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "profiles_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "vehicle_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "profiles_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["vehicle_type_id"]
          },
          {
            foreignKeyName: "profiles_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "vehicle_types"
            referencedColumns: ["id"]
          },
        ]
      }
      role_functions: {
        Row: {
          created_at: string | null
          function_description: string | null
          function_name: string
          id: string
          is_enabled: boolean | null
          role_key: Database["public"]["Enums"]["app_role"]
        }
        Insert: {
          created_at?: string | null
          function_description?: string | null
          function_name: string
          id?: string
          is_enabled?: boolean | null
          role_key: Database["public"]["Enums"]["app_role"]
        }
        Update: {
          created_at?: string | null
          function_description?: string | null
          function_name?: string
          id?: string
          is_enabled?: boolean | null
          role_key?: Database["public"]["Enums"]["app_role"]
        }
        Relationships: []
      }
      role_menu_permissions: {
        Row: {
          created_at: string | null
          id: string
          menu_id: string | null
          role_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          menu_id?: string | null
          role_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          menu_id?: string | null
          role_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "role_menu_permissions_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "menus"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "role_menu_permissions_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
        ]
      }
      role_permissions: {
        Row: {
          created_at: string | null
          id: string
          permission_id: string | null
          role_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          permission_id?: string | null
          role_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          permission_id?: string | null
          role_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "role_permissions_role_id_fkey"
            columns: ["role_id"]
            isOneToOne: false
            referencedRelation: "roles"
            referencedColumns: ["id"]
          },
        ]
      }
      roles: {
        Row: {
          created_at: string | null
          description: string | null
          function_name: string | null
          id: string
          is_active: boolean | null
          role_key: Database["public"]["Enums"]["app_role"]
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          function_name?: string | null
          id?: string
          is_active?: boolean | null
          role_key: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string | null
          function_name?: string | null
          id?: string
          is_active?: boolean | null
          role_key?: Database["public"]["Enums"]["app_role"]
          updated_at?: string | null
        }
        Relationships: []
      }
      route_stops: {
        Row: {
          completed_at: string | null
          completed_by: string | null
          created_at: string | null
          id: string
          job_id: string
          location: Json
          notes: string | null
          proof_photo_url: string | null
          route_id: string
          scheduled_time: string | null
          signature_url: string | null
          status: string
          stop_sequence: number
          stop_type: string
          updated_at: string | null
        }
        Insert: {
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          id?: string
          job_id: string
          location: Json
          notes?: string | null
          proof_photo_url?: string | null
          route_id: string
          scheduled_time?: string | null
          signature_url?: string | null
          status?: string
          stop_sequence: number
          stop_type: string
          updated_at?: string | null
        }
        Update: {
          completed_at?: string | null
          completed_by?: string | null
          created_at?: string | null
          id?: string
          job_id?: string
          location?: Json
          notes?: string | null
          proof_photo_url?: string | null
          route_id?: string
          scheduled_time?: string | null
          signature_url?: string | null
          status?: string
          stop_sequence?: number
          stop_type?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "route_stops_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "route_stops_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "route_stops_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "route_stops_route_id_fkey"
            columns: ["route_id"]
            isOneToOne: false
            referencedRelation: "routes"
            referencedColumns: ["id"]
          },
        ]
      }
      routes: {
        Row: {
          created_at: string | null
          driver_id: string
          estimated_duration: number | null
          id: string
          route_date: string | null
          route_name: string
          status: string | null
          total_distance: number | null
          updated_at: string | null
          waypoints: Json
        }
        Insert: {
          created_at?: string | null
          driver_id: string
          estimated_duration?: number | null
          id?: string
          route_date?: string | null
          route_name: string
          status?: string | null
          total_distance?: number | null
          updated_at?: string | null
          waypoints: Json
        }
        Update: {
          created_at?: string | null
          driver_id?: string
          estimated_duration?: number | null
          id?: string
          route_date?: string | null
          route_name?: string
          status?: string | null
          total_distance?: number | null
          updated_at?: string | null
          waypoints?: Json
        }
        Relationships: []
      }
      schema_versions: {
        Row: {
          applied_at: string | null
          description: string | null
          version: number
        }
        Insert: {
          applied_at?: string | null
          description?: string | null
          version: number
        }
        Update: {
          applied_at?: string | null
          description?: string | null
          version?: number
        }
        Relationships: []
      }
      settings_audit_log: {
        Row: {
          action: string
          affected_user_id: string | null
          change_reason: string | null
          changed_by: string | null
          created_at: string | null
          id: string
          ip_address: unknown
          is_global: boolean | null
          new_value: Json | null
          old_value: Json | null
          setting_key: string
          user_agent: string | null
        }
        Insert: {
          action: string
          affected_user_id?: string | null
          change_reason?: string | null
          changed_by?: string | null
          created_at?: string | null
          id?: string
          ip_address?: unknown
          is_global?: boolean | null
          new_value?: Json | null
          old_value?: Json | null
          setting_key: string
          user_agent?: string | null
        }
        Update: {
          action?: string
          affected_user_id?: string | null
          change_reason?: string | null
          changed_by?: string | null
          created_at?: string | null
          id?: string
          ip_address?: unknown
          is_global?: boolean | null
          new_value?: Json | null
          old_value?: Json | null
          setting_key?: string
          user_agent?: string | null
        }
        Relationships: []
      }
      settings_profiles: {
        Row: {
          created_at: string | null
          created_by: string | null
          description: string | null
          id: string
          is_active: boolean | null
          profile_name: string
          settings_snapshot: Json
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          profile_name: string
          settings_snapshot: Json
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          description?: string | null
          id?: string
          is_active?: boolean | null
          profile_name?: string
          settings_snapshot?: Json
          updated_at?: string | null
        }
        Relationships: []
      }
      shipper_profiles: {
        Row: {
          billing_contact_email: string | null
          billing_contact_name: string | null
          billing_contact_phone: string | null
          business_type: string | null
          company_name: string | null
          created_at: string | null
          credit_limit: number | null
          dba_name: string | null
          ein_tax_id: string | null
          id: string
          industry: string | null
          mailing_address: Json | null
          payment_terms: string | null
          physical_address: Json | null
          preferred_carriers: string[] | null
          primary_contact_email: string | null
          primary_contact_name: string | null
          primary_contact_phone: string | null
          primary_contact_title: string | null
          shipping_volume_monthly: number | null
          status: string | null
          updated_at: string | null
          user_id: string
          year_established: number | null
        }
        Insert: {
          billing_contact_email?: string | null
          billing_contact_name?: string | null
          billing_contact_phone?: string | null
          business_type?: string | null
          company_name?: string | null
          created_at?: string | null
          credit_limit?: number | null
          dba_name?: string | null
          ein_tax_id?: string | null
          id?: string
          industry?: string | null
          mailing_address?: Json | null
          payment_terms?: string | null
          physical_address?: Json | null
          preferred_carriers?: string[] | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          shipping_volume_monthly?: number | null
          status?: string | null
          updated_at?: string | null
          user_id: string
          year_established?: number | null
        }
        Update: {
          billing_contact_email?: string | null
          billing_contact_name?: string | null
          billing_contact_phone?: string | null
          business_type?: string | null
          company_name?: string | null
          created_at?: string | null
          credit_limit?: number | null
          dba_name?: string | null
          ein_tax_id?: string | null
          id?: string
          industry?: string | null
          mailing_address?: Json | null
          payment_terms?: string | null
          physical_address?: Json | null
          preferred_carriers?: string[] | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          shipping_volume_monthly?: number | null
          status?: string | null
          updated_at?: string | null
          user_id?: string
          year_established?: number | null
        }
        Relationships: []
      }
      sub_role_menu_permissions: {
        Row: {
          created_at: string | null
          id: string
          menu_id: string
          sub_role: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          menu_id: string
          sub_role: string
        }
        Update: {
          created_at?: string | null
          id?: string
          menu_id?: string
          sub_role?: string
        }
        Relationships: [
          {
            foreignKeyName: "sub_role_menu_permissions_menu_id_fkey"
            columns: ["menu_id"]
            isOneToOne: false
            referencedRelation: "menus"
            referencedColumns: ["id"]
          },
        ]
      }
      task_assignments: {
        Row: {
          approval_status: string | null
          approved_at: string | null
          approved_by: string | null
          assigned_by: string | null
          completed_at: string | null
          created_at: string | null
          deleted_at: string | null
          deleted_by: string | null
          id: string
          is_deleted: boolean
          notes: string | null
          rejection_reason: string | null
          status: string | null
          task_id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          assigned_by?: string | null
          completed_at?: string | null
          created_at?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          id?: string
          is_deleted?: boolean
          notes?: string | null
          rejection_reason?: string | null
          status?: string | null
          task_id: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          approval_status?: string | null
          approved_at?: string | null
          approved_by?: string | null
          assigned_by?: string | null
          completed_at?: string | null
          created_at?: string | null
          deleted_at?: string | null
          deleted_by?: string | null
          id?: string
          is_deleted?: boolean
          notes?: string | null
          rejection_reason?: string | null
          status?: string | null
          task_id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_assignments_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "custom_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      task_responses: {
        Row: {
          created_at: string | null
          field_label: string | null
          field_name: string
          field_type: string | null
          field_value: string | null
          id: string
          task_id: string
          updated_at: string | null
          uploaded_file_url: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          field_label?: string | null
          field_name: string
          field_type?: string | null
          field_value?: string | null
          id?: string
          task_id: string
          updated_at?: string | null
          uploaded_file_url?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          field_label?: string | null
          field_name?: string
          field_type?: string | null
          field_value?: string | null
          id?: string
          task_id?: string
          updated_at?: string | null
          uploaded_file_url?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_responses_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "custom_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      task_step_submissions: {
        Row: {
          admin_notes: string | null
          id: string
          notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string
          step_number: number
          submission_data: Json
          submitted_at: string
          task_id: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          id?: string
          notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          step_number: number
          submission_data?: Json
          submitted_at?: string
          task_id: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          id?: string
          notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string
          step_number?: number
          submission_data?: Json
          submitted_at?: string
          task_id?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "task_step_submissions_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "custom_tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      tasks: {
        Row: {
          created_at: string | null
          due_date: string | null
          id: string
          status: string | null
          task_category: string | null
          task_description: string | null
          task_form_schema: Json | null
          task_name: string
          task_role: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          due_date?: string | null
          id?: string
          status?: string | null
          task_category?: string | null
          task_description?: string | null
          task_form_schema?: Json | null
          task_name: string
          task_role?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          due_date?: string | null
          id?: string
          status?: string | null
          task_category?: string | null
          task_description?: string | null
          task_form_schema?: Json | null
          task_name?: string
          task_role?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      timesheet_activity_logs: {
        Row: {
          activity_description: string | null
          activity_type: string
          created_at: string | null
          id: string
          metadata: Json | null
          task_assignment_id: string | null
          task_id: string | null
          timesheet_id: string
        }
        Insert: {
          activity_description?: string | null
          activity_type: string
          created_at?: string | null
          id?: string
          metadata?: Json | null
          task_assignment_id?: string | null
          task_id?: string | null
          timesheet_id: string
        }
        Update: {
          activity_description?: string | null
          activity_type?: string
          created_at?: string | null
          id?: string
          metadata?: Json | null
          task_assignment_id?: string | null
          task_id?: string | null
          timesheet_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "timesheet_activity_logs_task_assignment_id_fkey"
            columns: ["task_assignment_id"]
            isOneToOne: false
            referencedRelation: "task_assignments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheet_activity_logs_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "custom_tasks"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheet_activity_logs_timesheet_id_fkey"
            columns: ["timesheet_id"]
            isOneToOne: false
            referencedRelation: "timesheets"
            referencedColumns: ["id"]
          },
        ]
      }
      timesheet_job_stages: {
        Row: {
          completed_at: string | null
          created_at: string | null
          duration_hours: number | null
          id: string
          job_id: string
          notes: string | null
          stage: string
          started_at: string
          timesheet_id: string
          updated_at: string | null
        }
        Insert: {
          completed_at?: string | null
          created_at?: string | null
          duration_hours?: number | null
          id?: string
          job_id: string
          notes?: string | null
          stage: string
          started_at?: string
          timesheet_id: string
          updated_at?: string | null
        }
        Update: {
          completed_at?: string | null
          created_at?: string | null
          duration_hours?: number | null
          id?: string
          job_id?: string
          notes?: string | null
          stage?: string
          started_at?: string
          timesheet_id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "timesheet_job_stages_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheet_job_stages_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "timesheet_job_stages_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheet_job_stages_timesheet_id_fkey"
            columns: ["timesheet_id"]
            isOneToOne: false
            referencedRelation: "timesheets"
            referencedColumns: ["id"]
          },
        ]
      }
      timesheet_payroll_exports: {
        Row: {
          created_at: string | null
          export_date: string
          export_file_path: string | null
          exported_by: string | null
          id: string
          notes: string | null
          period_end: string
          period_start: string
          status: string
          timesheet_ids: string[]
          total_hours: number
          total_records: number
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          export_date?: string
          export_file_path?: string | null
          exported_by?: string | null
          id?: string
          notes?: string | null
          period_end: string
          period_start: string
          status?: string
          timesheet_ids: string[]
          total_hours?: number
          total_records?: number
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          export_date?: string
          export_file_path?: string | null
          exported_by?: string | null
          id?: string
          notes?: string | null
          period_end?: string
          period_start?: string
          status?: string
          timesheet_ids?: string[]
          total_hours?: number
          total_records?: number
          updated_at?: string | null
        }
        Relationships: []
      }
      timesheet_weekly_summaries: {
        Row: {
          admin_id: string
          generated_at: string | null
          id: string
          overtime_hours: number | null
          status: string | null
          total_activities: number | null
          total_hours: number | null
          week_end: string
          week_start: string
        }
        Insert: {
          admin_id: string
          generated_at?: string | null
          id?: string
          overtime_hours?: number | null
          status?: string | null
          total_activities?: number | null
          total_hours?: number | null
          week_end: string
          week_start: string
        }
        Update: {
          admin_id?: string
          generated_at?: string | null
          id?: string
          overtime_hours?: number | null
          status?: string | null
          total_activities?: number | null
          total_hours?: number | null
          week_end?: string
          week_start?: string
        }
        Relationships: []
      }
      timesheets: {
        Row: {
          activity_count: number | null
          adjusted_from: string | null
          adjustment_reason: string | null
          admin_id: string
          approved_at: string | null
          approved_by: string | null
          break_time_minutes: number | null
          clock_in: string
          clock_out: string | null
          created_at: string | null
          date: string | null
          id: string
          is_archived: boolean | null
          job_id: string | null
          job_stage: string | null
          last_activity: string | null
          manual_entry: boolean | null
          manual_entry_reason: string | null
          mileage: number | null
          notes: string | null
          payroll_export_date: string | null
          payroll_exported: boolean | null
          payroll_period_end: string | null
          payroll_period_start: string | null
          rejection_reason: string | null
          role_key: string | null
          status: string | null
          total_duration: number | null
          updated_at: string | null
          user_id: string | null
          wait_time_minutes: number | null
        }
        Insert: {
          activity_count?: number | null
          adjusted_from?: string | null
          adjustment_reason?: string | null
          admin_id: string
          approved_at?: string | null
          approved_by?: string | null
          break_time_minutes?: number | null
          clock_in: string
          clock_out?: string | null
          created_at?: string | null
          date?: string | null
          id?: string
          is_archived?: boolean | null
          job_id?: string | null
          job_stage?: string | null
          last_activity?: string | null
          manual_entry?: boolean | null
          manual_entry_reason?: string | null
          mileage?: number | null
          notes?: string | null
          payroll_export_date?: string | null
          payroll_exported?: boolean | null
          payroll_period_end?: string | null
          payroll_period_start?: string | null
          rejection_reason?: string | null
          role_key?: string | null
          status?: string | null
          total_duration?: number | null
          updated_at?: string | null
          user_id?: string | null
          wait_time_minutes?: number | null
        }
        Update: {
          activity_count?: number | null
          adjusted_from?: string | null
          adjustment_reason?: string | null
          admin_id?: string
          approved_at?: string | null
          approved_by?: string | null
          break_time_minutes?: number | null
          clock_in?: string
          clock_out?: string | null
          created_at?: string | null
          date?: string | null
          id?: string
          is_archived?: boolean | null
          job_id?: string | null
          job_stage?: string | null
          last_activity?: string | null
          manual_entry?: boolean | null
          manual_entry_reason?: string | null
          mileage?: number | null
          notes?: string | null
          payroll_export_date?: string | null
          payroll_exported?: boolean | null
          payroll_period_end?: string | null
          payroll_period_start?: string | null
          rejection_reason?: string | null
          role_key?: string | null
          status?: string | null
          total_duration?: number | null
          updated_at?: string | null
          user_id?: string | null
          wait_time_minutes?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "timesheets_adjusted_from_fkey"
            columns: ["adjusted_from"]
            isOneToOne: false
            referencedRelation: "timesheets"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheets_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "timesheets_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheets_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "timesheets_approved_by_fkey"
            columns: ["approved_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheets_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "completed_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "timesheets_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["job_id"]
          },
          {
            foreignKeyName: "timesheets_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      user_account_number: {
        Row: {
          account_number: string
          generated_at: string | null
          id: string
          is_active: boolean | null
          user_id: string
        }
        Insert: {
          account_number: string
          generated_at?: string | null
          id?: string
          is_active?: boolean | null
          user_id: string
        }
        Update: {
          account_number?: string
          generated_at?: string | null
          id?: string
          is_active?: boolean | null
          user_id?: string
        }
        Relationships: []
      }
      user_activity_logs: {
        Row: {
          activity_description: string | null
          activity_type: string
          created_at: string | null
          id: string
          ip_address: unknown
          metadata: Json | null
          user_agent: string | null
          user_id: string
        }
        Insert: {
          activity_description?: string | null
          activity_type: string
          created_at?: string | null
          id?: string
          ip_address?: unknown
          metadata?: Json | null
          user_agent?: string | null
          user_id: string
        }
        Update: {
          activity_description?: string | null
          activity_type?: string
          created_at?: string | null
          id?: string
          ip_address?: unknown
          metadata?: Json | null
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_approval_checklists: {
        Row: {
          activation_approval: string | null
          activation_notes: string | null
          activation_unlocked: boolean | null
          admin_id: string | null
          admin_name: string | null
          all_steps_approval: string | null
          all_steps_complete: boolean | null
          all_steps_notes: string | null
          approval_note: string | null
          approval_note_approval: string | null
          approval_note_recorded: boolean | null
          audit_approval: string | null
          audit_complete: boolean | null
          audit_notes: string | null
          background_check_approval: string | null
          background_check_complete: boolean | null
          background_check_notes: string | null
          checklist_date: string
          created_at: string | null
          documents_approval: string | null
          documents_notes: string | null
          documents_readable: boolean | null
          documents_stored_approval: string | null
          documents_stored_notes: string | null
          documents_stored_securely: boolean | null
          email_phone_approval: string | null
          email_phone_notes: string | null
          email_phone_verified: boolean | null
          id: string
          id_approval: string | null
          id_notes: string | null
          id_reviewed: boolean | null
          incomplete_approval: string | null
          incomplete_marked: boolean | null
          incomplete_notes: string | null
          legal_agreements_approval: string | null
          legal_agreements_notes: string | null
          legal_agreements_signed: boolean | null
          locked: boolean | null
          name_approval: string | null
          name_notes: string | null
          name_verified: boolean | null
          no_duplicates: boolean | null
          no_duplicates_approval: string | null
          no_duplicates_notes: string | null
          no_suspicious_activity: boolean | null
          no_suspicious_activity_approval: string | null
          no_suspicious_activity_notes: string | null
          notification_approval: string | null
          notification_notes: string | null
          notification_sent: boolean | null
          payment_data_approval: string | null
          payment_data_correct: boolean | null
          payment_data_notes: string | null
          profile_fields_approval: string | null
          profile_fields_complete: boolean | null
          profile_fields_notes: string | null
          profile_picture_approval: string | null
          profile_picture_notes: string | null
          profile_picture_valid: boolean | null
          role_approval: string | null
          role_notes: string | null
          role_validated: boolean | null
          status: string | null
          status_changed: boolean | null
          status_changed_approval: string | null
          status_changed_notes: string | null
          super_admin_approval: string | null
          super_admin_notes: string | null
          super_admin_reviewed: boolean | null
          unique_account_approval: string | null
          unique_account_notes: string | null
          unique_account_verified: boolean | null
          unique_identifiers_approval: string | null
          unique_identifiers_notes: string | null
          unique_identifiers_verified: boolean | null
          updated_at: string | null
          user_approved_approval: string | null
          user_approved_in_system: boolean | null
          user_approved_notes: string | null
          user_id: string
        }
        Insert: {
          activation_approval?: string | null
          activation_notes?: string | null
          activation_unlocked?: boolean | null
          admin_id?: string | null
          admin_name?: string | null
          all_steps_approval?: string | null
          all_steps_complete?: boolean | null
          all_steps_notes?: string | null
          approval_note?: string | null
          approval_note_approval?: string | null
          approval_note_recorded?: boolean | null
          audit_approval?: string | null
          audit_complete?: boolean | null
          audit_notes?: string | null
          background_check_approval?: string | null
          background_check_complete?: boolean | null
          background_check_notes?: string | null
          checklist_date?: string
          created_at?: string | null
          documents_approval?: string | null
          documents_notes?: string | null
          documents_readable?: boolean | null
          documents_stored_approval?: string | null
          documents_stored_notes?: string | null
          documents_stored_securely?: boolean | null
          email_phone_approval?: string | null
          email_phone_notes?: string | null
          email_phone_verified?: boolean | null
          id?: string
          id_approval?: string | null
          id_notes?: string | null
          id_reviewed?: boolean | null
          incomplete_approval?: string | null
          incomplete_marked?: boolean | null
          incomplete_notes?: string | null
          legal_agreements_approval?: string | null
          legal_agreements_notes?: string | null
          legal_agreements_signed?: boolean | null
          locked?: boolean | null
          name_approval?: string | null
          name_notes?: string | null
          name_verified?: boolean | null
          no_duplicates?: boolean | null
          no_duplicates_approval?: string | null
          no_duplicates_notes?: string | null
          no_suspicious_activity?: boolean | null
          no_suspicious_activity_approval?: string | null
          no_suspicious_activity_notes?: string | null
          notification_approval?: string | null
          notification_notes?: string | null
          notification_sent?: boolean | null
          payment_data_approval?: string | null
          payment_data_correct?: boolean | null
          payment_data_notes?: string | null
          profile_fields_approval?: string | null
          profile_fields_complete?: boolean | null
          profile_fields_notes?: string | null
          profile_picture_approval?: string | null
          profile_picture_notes?: string | null
          profile_picture_valid?: boolean | null
          role_approval?: string | null
          role_notes?: string | null
          role_validated?: boolean | null
          status?: string | null
          status_changed?: boolean | null
          status_changed_approval?: string | null
          status_changed_notes?: string | null
          super_admin_approval?: string | null
          super_admin_notes?: string | null
          super_admin_reviewed?: boolean | null
          unique_account_approval?: string | null
          unique_account_notes?: string | null
          unique_account_verified?: boolean | null
          unique_identifiers_approval?: string | null
          unique_identifiers_notes?: string | null
          unique_identifiers_verified?: boolean | null
          updated_at?: string | null
          user_approved_approval?: string | null
          user_approved_in_system?: boolean | null
          user_approved_notes?: string | null
          user_id: string
        }
        Update: {
          activation_approval?: string | null
          activation_notes?: string | null
          activation_unlocked?: boolean | null
          admin_id?: string | null
          admin_name?: string | null
          all_steps_approval?: string | null
          all_steps_complete?: boolean | null
          all_steps_notes?: string | null
          approval_note?: string | null
          approval_note_approval?: string | null
          approval_note_recorded?: boolean | null
          audit_approval?: string | null
          audit_complete?: boolean | null
          audit_notes?: string | null
          background_check_approval?: string | null
          background_check_complete?: boolean | null
          background_check_notes?: string | null
          checklist_date?: string
          created_at?: string | null
          documents_approval?: string | null
          documents_notes?: string | null
          documents_readable?: boolean | null
          documents_stored_approval?: string | null
          documents_stored_notes?: string | null
          documents_stored_securely?: boolean | null
          email_phone_approval?: string | null
          email_phone_notes?: string | null
          email_phone_verified?: boolean | null
          id?: string
          id_approval?: string | null
          id_notes?: string | null
          id_reviewed?: boolean | null
          incomplete_approval?: string | null
          incomplete_marked?: boolean | null
          incomplete_notes?: string | null
          legal_agreements_approval?: string | null
          legal_agreements_notes?: string | null
          legal_agreements_signed?: boolean | null
          locked?: boolean | null
          name_approval?: string | null
          name_notes?: string | null
          name_verified?: boolean | null
          no_duplicates?: boolean | null
          no_duplicates_approval?: string | null
          no_duplicates_notes?: string | null
          no_suspicious_activity?: boolean | null
          no_suspicious_activity_approval?: string | null
          no_suspicious_activity_notes?: string | null
          notification_approval?: string | null
          notification_notes?: string | null
          notification_sent?: boolean | null
          payment_data_approval?: string | null
          payment_data_correct?: boolean | null
          payment_data_notes?: string | null
          profile_fields_approval?: string | null
          profile_fields_complete?: boolean | null
          profile_fields_notes?: string | null
          profile_picture_approval?: string | null
          profile_picture_notes?: string | null
          profile_picture_valid?: boolean | null
          role_approval?: string | null
          role_notes?: string | null
          role_validated?: boolean | null
          status?: string | null
          status_changed?: boolean | null
          status_changed_approval?: string | null
          status_changed_notes?: string | null
          super_admin_approval?: string | null
          super_admin_notes?: string | null
          super_admin_reviewed?: boolean | null
          unique_account_approval?: string | null
          unique_account_notes?: string | null
          unique_account_verified?: boolean | null
          unique_identifiers_approval?: string | null
          unique_identifiers_notes?: string | null
          unique_identifiers_verified?: boolean | null
          updated_at?: string | null
          user_approved_approval?: string | null
          user_approved_in_system?: boolean | null
          user_approved_notes?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_customization: {
        Row: {
          accent_color: string | null
          animation_style: string | null
          animations_enabled: boolean | null
          background_color: string | null
          background_gradient: string | null
          background_image: string | null
          background_type: string | null
          border_color: string | null
          border_radius: number | null
          button_hover: string | null
          button_size: string | null
          button_style: string | null
          card_style: string | null
          click_behavior: Json | null
          content_filters: Json | null
          content_padding: string | null
          created_at: string | null
          custom_css: string | null
          dashboard_layout: Json | null
          default_view: string | null
          focus_indicators: boolean | null
          font_family: string | null
          font_scaling: number | null
          font_size: number | null
          font_weight: number | null
          gradient_primary: string | null
          gradient_secondary: string | null
          header_height: number | null
          header_position: string | null
          header_style: string | null
          heading_font: string | null
          heading_size: number | null
          high_contrast: boolean | null
          hover_effect: string | null
          icon_style: string | null
          id: string
          input_style: string | null
          is_platform_default: boolean | null
          items_per_page: number | null
          keyboard_navigation: boolean | null
          keyboard_shortcuts: Json | null
          letter_spacing: number | null
          line_height: number | null
          max_content_width: string | null
          notification_preferences: Json | null
          notification_style: string | null
          panel_arrangement: Json | null
          popup_style: string | null
          primary_color: string | null
          profile_name: string | null
          reduce_motion: boolean | null
          screen_reader_support: boolean | null
          secondary_color: string | null
          shadow_intensity: string | null
          sidebar_position: string | null
          sidebar_style: string | null
          sidebar_width: number | null
          surface_color: string | null
          text_muted: string | null
          text_primary: string | null
          text_secondary: string | null
          theme: string | null
          tooltips_enabled: boolean | null
          transition_speed: number | null
          updated_at: string | null
          user_id: string
          visible_metrics: Json | null
          visible_sections: Json | null
        }
        Insert: {
          accent_color?: string | null
          animation_style?: string | null
          animations_enabled?: boolean | null
          background_color?: string | null
          background_gradient?: string | null
          background_image?: string | null
          background_type?: string | null
          border_color?: string | null
          border_radius?: number | null
          button_hover?: string | null
          button_size?: string | null
          button_style?: string | null
          card_style?: string | null
          click_behavior?: Json | null
          content_filters?: Json | null
          content_padding?: string | null
          created_at?: string | null
          custom_css?: string | null
          dashboard_layout?: Json | null
          default_view?: string | null
          focus_indicators?: boolean | null
          font_family?: string | null
          font_scaling?: number | null
          font_size?: number | null
          font_weight?: number | null
          gradient_primary?: string | null
          gradient_secondary?: string | null
          header_height?: number | null
          header_position?: string | null
          header_style?: string | null
          heading_font?: string | null
          heading_size?: number | null
          high_contrast?: boolean | null
          hover_effect?: string | null
          icon_style?: string | null
          id?: string
          input_style?: string | null
          is_platform_default?: boolean | null
          items_per_page?: number | null
          keyboard_navigation?: boolean | null
          keyboard_shortcuts?: Json | null
          letter_spacing?: number | null
          line_height?: number | null
          max_content_width?: string | null
          notification_preferences?: Json | null
          notification_style?: string | null
          panel_arrangement?: Json | null
          popup_style?: string | null
          primary_color?: string | null
          profile_name?: string | null
          reduce_motion?: boolean | null
          screen_reader_support?: boolean | null
          secondary_color?: string | null
          shadow_intensity?: string | null
          sidebar_position?: string | null
          sidebar_style?: string | null
          sidebar_width?: number | null
          surface_color?: string | null
          text_muted?: string | null
          text_primary?: string | null
          text_secondary?: string | null
          theme?: string | null
          tooltips_enabled?: boolean | null
          transition_speed?: number | null
          updated_at?: string | null
          user_id: string
          visible_metrics?: Json | null
          visible_sections?: Json | null
        }
        Update: {
          accent_color?: string | null
          animation_style?: string | null
          animations_enabled?: boolean | null
          background_color?: string | null
          background_gradient?: string | null
          background_image?: string | null
          background_type?: string | null
          border_color?: string | null
          border_radius?: number | null
          button_hover?: string | null
          button_size?: string | null
          button_style?: string | null
          card_style?: string | null
          click_behavior?: Json | null
          content_filters?: Json | null
          content_padding?: string | null
          created_at?: string | null
          custom_css?: string | null
          dashboard_layout?: Json | null
          default_view?: string | null
          focus_indicators?: boolean | null
          font_family?: string | null
          font_scaling?: number | null
          font_size?: number | null
          font_weight?: number | null
          gradient_primary?: string | null
          gradient_secondary?: string | null
          header_height?: number | null
          header_position?: string | null
          header_style?: string | null
          heading_font?: string | null
          heading_size?: number | null
          high_contrast?: boolean | null
          hover_effect?: string | null
          icon_style?: string | null
          id?: string
          input_style?: string | null
          is_platform_default?: boolean | null
          items_per_page?: number | null
          keyboard_navigation?: boolean | null
          keyboard_shortcuts?: Json | null
          letter_spacing?: number | null
          line_height?: number | null
          max_content_width?: string | null
          notification_preferences?: Json | null
          notification_style?: string | null
          panel_arrangement?: Json | null
          popup_style?: string | null
          primary_color?: string | null
          profile_name?: string | null
          reduce_motion?: boolean | null
          screen_reader_support?: boolean | null
          secondary_color?: string | null
          shadow_intensity?: string | null
          sidebar_position?: string | null
          sidebar_style?: string | null
          sidebar_width?: number | null
          surface_color?: string | null
          text_muted?: string | null
          text_primary?: string | null
          text_secondary?: string | null
          theme?: string | null
          tooltips_enabled?: boolean | null
          transition_speed?: number | null
          updated_at?: string | null
          user_id?: string
          visible_metrics?: Json | null
          visible_sections?: Json | null
        }
        Relationships: []
      }
      user_customization_backup: {
        Row: {
          backed_up_at: string | null
          customization_data: Json
          expires_at: string | null
          id: string
          user_id: string
        }
        Insert: {
          backed_up_at?: string | null
          customization_data: Json
          expires_at?: string | null
          id?: string
          user_id: string
        }
        Update: {
          backed_up_at?: string | null
          customization_data?: Json
          expires_at?: string | null
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      user_documents: {
        Row: {
          document_name: string
          document_type: string | null
          file_path: string
          file_size: number | null
          id: string
          metadata: Json | null
          review_notes: string | null
          reviewed_at: string | null
          reviewed_by: string | null
          status: string | null
          uploaded_at: string | null
          user_id: string
        }
        Insert: {
          document_name: string
          document_type?: string | null
          file_path: string
          file_size?: number | null
          id?: string
          metadata?: Json | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          uploaded_at?: string | null
          user_id: string
        }
        Update: {
          document_name?: string
          document_type?: string | null
          file_path?: string
          file_size?: number | null
          id?: string
          metadata?: Json | null
          review_notes?: string | null
          reviewed_at?: string | null
          reviewed_by?: string | null
          status?: string | null
          uploaded_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_messages: {
        Row: {
          created_at: string | null
          from_user_id: string | null
          id: string
          message: string
          message_type: string
          metadata: Json | null
          read_at: string | null
          status: string | null
          subject: string
          to_user_id: string
        }
        Insert: {
          created_at?: string | null
          from_user_id?: string | null
          id?: string
          message: string
          message_type?: string
          metadata?: Json | null
          read_at?: string | null
          status?: string | null
          subject: string
          to_user_id: string
        }
        Update: {
          created_at?: string | null
          from_user_id?: string | null
          id?: string
          message?: string
          message_type?: string
          metadata?: Json | null
          read_at?: string | null
          status?: string | null
          subject?: string
          to_user_id?: string
        }
        Relationships: []
      }
      user_preactivation_checklists: {
        Row: {
          account_activated: boolean | null
          activation_approval: string | null
          activation_logged: boolean | null
          activation_notes: string | null
          activity_approval: string | null
          activity_monitored: boolean | null
          activity_notes: string | null
          admin_id: string | null
          admin_name: string | null
          admin_sign_off: boolean | null
          all_checks_confirmed: boolean | null
          audit_approval: string | null
          audit_notes: string | null
          audit_trail_created: boolean | null
          checklist_complete: boolean | null
          checklist_date: string
          checks_approval: string | null
          checks_notes: string | null
          complete_approval: string | null
          complete_notes: string | null
          created_at: string | null
          feedback_approval: string | null
          feedback_notes: string | null
          first_login_instructions: boolean | null
          flags_approval: string | null
          flags_notes: string | null
          id: string
          instructions_approval: string | null
          instructions_notes: string | null
          log_approval: string | null
          log_notes: string | null
          login_approval: string | null
          login_notes: string | null
          login_tested: boolean | null
          managerial_approval_checked: boolean | null
          managerial_approval_status: string | null
          managerial_notes: string | null
          mfa_approval: string | null
          mfa_configured: boolean | null
          mfa_notes: string | null
          no_system_flags: boolean | null
          password_approval: string | null
          password_notes: string | null
          permissions_approval: string | null
          permissions_assigned: boolean | null
          permissions_notes: string | null
          permissions_verified: boolean | null
          permissions_verify_approval: string | null
          permissions_verify_notes: string | null
          security_approval: string | null
          security_notes: string | null
          security_scan_complete: boolean | null
          sign_off_approval: string | null
          sign_off_notes: string | null
          status: string | null
          strong_password_verified: boolean | null
          support_approval: string | null
          support_contact_provided: boolean | null
          support_notes: string | null
          updated_at: string | null
          user_feedback_collected: boolean | null
          user_id: string
          welcome_email_approval: string | null
          welcome_email_notes: string | null
          welcome_email_sent: boolean | null
        }
        Insert: {
          account_activated?: boolean | null
          activation_approval?: string | null
          activation_logged?: boolean | null
          activation_notes?: string | null
          activity_approval?: string | null
          activity_monitored?: boolean | null
          activity_notes?: string | null
          admin_id?: string | null
          admin_name?: string | null
          admin_sign_off?: boolean | null
          all_checks_confirmed?: boolean | null
          audit_approval?: string | null
          audit_notes?: string | null
          audit_trail_created?: boolean | null
          checklist_complete?: boolean | null
          checklist_date?: string
          checks_approval?: string | null
          checks_notes?: string | null
          complete_approval?: string | null
          complete_notes?: string | null
          created_at?: string | null
          feedback_approval?: string | null
          feedback_notes?: string | null
          first_login_instructions?: boolean | null
          flags_approval?: string | null
          flags_notes?: string | null
          id?: string
          instructions_approval?: string | null
          instructions_notes?: string | null
          log_approval?: string | null
          log_notes?: string | null
          login_approval?: string | null
          login_notes?: string | null
          login_tested?: boolean | null
          managerial_approval_checked?: boolean | null
          managerial_approval_status?: string | null
          managerial_notes?: string | null
          mfa_approval?: string | null
          mfa_configured?: boolean | null
          mfa_notes?: string | null
          no_system_flags?: boolean | null
          password_approval?: string | null
          password_notes?: string | null
          permissions_approval?: string | null
          permissions_assigned?: boolean | null
          permissions_notes?: string | null
          permissions_verified?: boolean | null
          permissions_verify_approval?: string | null
          permissions_verify_notes?: string | null
          security_approval?: string | null
          security_notes?: string | null
          security_scan_complete?: boolean | null
          sign_off_approval?: string | null
          sign_off_notes?: string | null
          status?: string | null
          strong_password_verified?: boolean | null
          support_approval?: string | null
          support_contact_provided?: boolean | null
          support_notes?: string | null
          updated_at?: string | null
          user_feedback_collected?: boolean | null
          user_id: string
          welcome_email_approval?: string | null
          welcome_email_notes?: string | null
          welcome_email_sent?: boolean | null
        }
        Update: {
          account_activated?: boolean | null
          activation_approval?: string | null
          activation_logged?: boolean | null
          activation_notes?: string | null
          activity_approval?: string | null
          activity_monitored?: boolean | null
          activity_notes?: string | null
          admin_id?: string | null
          admin_name?: string | null
          admin_sign_off?: boolean | null
          all_checks_confirmed?: boolean | null
          audit_approval?: string | null
          audit_notes?: string | null
          audit_trail_created?: boolean | null
          checklist_complete?: boolean | null
          checklist_date?: string
          checks_approval?: string | null
          checks_notes?: string | null
          complete_approval?: string | null
          complete_notes?: string | null
          created_at?: string | null
          feedback_approval?: string | null
          feedback_notes?: string | null
          first_login_instructions?: boolean | null
          flags_approval?: string | null
          flags_notes?: string | null
          id?: string
          instructions_approval?: string | null
          instructions_notes?: string | null
          log_approval?: string | null
          log_notes?: string | null
          login_approval?: string | null
          login_notes?: string | null
          login_tested?: boolean | null
          managerial_approval_checked?: boolean | null
          managerial_approval_status?: string | null
          managerial_notes?: string | null
          mfa_approval?: string | null
          mfa_configured?: boolean | null
          mfa_notes?: string | null
          no_system_flags?: boolean | null
          password_approval?: string | null
          password_notes?: string | null
          permissions_approval?: string | null
          permissions_assigned?: boolean | null
          permissions_notes?: string | null
          permissions_verified?: boolean | null
          permissions_verify_approval?: string | null
          permissions_verify_notes?: string | null
          security_approval?: string | null
          security_notes?: string | null
          security_scan_complete?: boolean | null
          sign_off_approval?: string | null
          sign_off_notes?: string | null
          status?: string | null
          strong_password_verified?: boolean | null
          support_approval?: string | null
          support_contact_provided?: boolean | null
          support_notes?: string | null
          updated_at?: string | null
          user_feedback_collected?: boolean | null
          user_id?: string
          welcome_email_approval?: string | null
          welcome_email_notes?: string | null
          welcome_email_sent?: boolean | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          created_at: string | null
          id: string
          is_enabled: boolean | null
          setting_key: string
          setting_value: Json
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_enabled?: boolean | null
          setting_key: string
          setting_value: Json
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_enabled?: boolean | null
          setting_key?: string
          setting_value?: Json
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      vehicle_categories: {
        Row: {
          created_at: string | null
          description: string | null
          icon: string | null
          id: number
          name: string
        }
        Insert: {
          created_at?: string | null
          description?: string | null
          icon?: string | null
          id?: number
          name: string
        }
        Update: {
          created_at?: string | null
          description?: string | null
          icon?: string | null
          id?: number
          name?: string
        }
        Relationships: []
      }
      vehicle_types: {
        Row: {
          capacity: string | null
          category_id: number | null
          created_at: string | null
          id: number
          name: string
        }
        Insert: {
          capacity?: string | null
          category_id?: number | null
          created_at?: string | null
          id?: number
          name: string
        }
        Update: {
          capacity?: string | null
          category_id?: number | null
          created_at?: string | null
          id?: number
          name?: string
        }
        Relationships: [
          {
            foreignKeyName: "vehicle_types_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_category"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "vehicle_types_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "vehicle_types_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "vehicle_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      vehicles: {
        Row: {
          capacity: string | null
          carrier_id: string
          created_at: string | null
          driver: string | null
          id: string
          location: string | null
          mileage: string | null
          model: string | null
          name: string
          next_maintenance: string | null
          plate: string
          status: string
          type: string
          updated_at: string | null
          vin: string | null
        }
        Insert: {
          capacity?: string | null
          carrier_id: string
          created_at?: string | null
          driver?: string | null
          id?: string
          location?: string | null
          mileage?: string | null
          model?: string | null
          name: string
          next_maintenance?: string | null
          plate: string
          status?: string
          type: string
          updated_at?: string | null
          vin?: string | null
        }
        Update: {
          capacity?: string | null
          carrier_id?: string
          created_at?: string | null
          driver?: string | null
          id?: string
          location?: string | null
          mileage?: string | null
          model?: string | null
          name?: string
          next_maintenance?: string | null
          plate?: string
          status?: string
          type?: string
          updated_at?: string | null
          vin?: string | null
        }
        Relationships: []
      }
      vendor_merchant_onboarding: {
        Row: {
          account_number: string | null
          business_name: string | null
          business_type: string | null
          created_at: string | null
          data_encrypted: boolean | null
          documents: Json | null
          encrypted_at: string | null
          id: string
          routing_number: string | null
          tax_id: string | null
          updated_at: string | null
          user_id: string
          verification_status:
            | Database["public"]["Enums"]["approval_status"]
            | null
        }
        Insert: {
          account_number?: string | null
          business_name?: string | null
          business_type?: string | null
          created_at?: string | null
          data_encrypted?: boolean | null
          documents?: Json | null
          encrypted_at?: string | null
          id?: string
          routing_number?: string | null
          tax_id?: string | null
          updated_at?: string | null
          user_id: string
          verification_status?:
            | Database["public"]["Enums"]["approval_status"]
            | null
        }
        Update: {
          account_number?: string | null
          business_name?: string | null
          business_type?: string | null
          created_at?: string | null
          data_encrypted?: boolean | null
          documents?: Json | null
          encrypted_at?: string | null
          id?: string
          routing_number?: string | null
          tax_id?: string | null
          updated_at?: string | null
          user_id?: string
          verification_status?:
            | Database["public"]["Enums"]["approval_status"]
            | null
        }
        Relationships: []
      }
      vendor_profiles: {
        Row: {
          account_holder_name: string | null
          bank_name: string | null
          business_hours: Json | null
          business_name: string | null
          business_type: string | null
          business_verified: boolean | null
          created_at: string | null
          dba_name: string | null
          delivery_radius_miles: number | null
          ein_tax_id: string | null
          id: string
          mailing_address: Json | null
          payment_processor: string | null
          primary_contact_email: string | null
          primary_contact_name: string | null
          primary_contact_phone: string | null
          primary_contact_title: string | null
          product_categories: string[] | null
          status: string | null
          store_address: Json | null
          tax_id_verified: boolean | null
          updated_at: string | null
          user_id: string
          year_established: number | null
        }
        Insert: {
          account_holder_name?: string | null
          bank_name?: string | null
          business_hours?: Json | null
          business_name?: string | null
          business_type?: string | null
          business_verified?: boolean | null
          created_at?: string | null
          dba_name?: string | null
          delivery_radius_miles?: number | null
          ein_tax_id?: string | null
          id?: string
          mailing_address?: Json | null
          payment_processor?: string | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          product_categories?: string[] | null
          status?: string | null
          store_address?: Json | null
          tax_id_verified?: boolean | null
          updated_at?: string | null
          user_id: string
          year_established?: number | null
        }
        Update: {
          account_holder_name?: string | null
          bank_name?: string | null
          business_hours?: Json | null
          business_name?: string | null
          business_type?: string | null
          business_verified?: boolean | null
          created_at?: string | null
          dba_name?: string | null
          delivery_radius_miles?: number | null
          ein_tax_id?: string | null
          id?: string
          mailing_address?: Json | null
          payment_processor?: string | null
          primary_contact_email?: string | null
          primary_contact_name?: string | null
          primary_contact_phone?: string | null
          primary_contact_title?: string | null
          product_categories?: string[] | null
          status?: string | null
          store_address?: Json | null
          tax_id_verified?: boolean | null
          updated_at?: string | null
          user_id?: string
          year_established?: number | null
        }
        Relationships: []
      }
      w9_forms: {
        Row: {
          approved_at: string | null
          approved_by: string | null
          form_data: Json
          id: string
          pdf_url: string | null
          status: Database["public"]["Enums"]["approval_status"] | null
          submitted_at: string | null
          user_id: string
        }
        Insert: {
          approved_at?: string | null
          approved_by?: string | null
          form_data: Json
          id?: string
          pdf_url?: string | null
          status?: Database["public"]["Enums"]["approval_status"] | null
          submitted_at?: string | null
          user_id: string
        }
        Update: {
          approved_at?: string | null
          approved_by?: string | null
          form_data?: Json
          id?: string
          pdf_url?: string | null
          status?: Database["public"]["Enums"]["approval_status"] | null
          submitted_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      webhooks: {
        Row: {
          created_at: string | null
          events: string[]
          id: string
          integration_id: string | null
          last_triggered: string | null
          name: string
          secret: string | null
          status: string
          updated_at: string | null
          url: string
        }
        Insert: {
          created_at?: string | null
          events: string[]
          id?: string
          integration_id?: string | null
          last_triggered?: string | null
          name: string
          secret?: string | null
          status?: string
          updated_at?: string | null
          url: string
        }
        Update: {
          created_at?: string | null
          events?: string[]
          id?: string
          integration_id?: string | null
          last_triggered?: string | null
          name?: string
          secret?: string | null
          status?: string
          updated_at?: string | null
          url?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhooks_integration_id_fkey"
            columns: ["integration_id"]
            isOneToOne: false
            referencedRelation: "integrations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      completed_jobs: {
        Row: {
          accepted_at: string | null
          actual_delivery_time: string | null
          assigned_driver_id: string | null
          broker_commission: number | null
          broker_id: string | null
          broker_notes: string | null
          cancellation_reason: string | null
          cancellation_reason_category:
            | Database["public"]["Enums"]["cancellation_reason_category"]
            | null
          cancelled_at: string | null
          cargo_details: Json | null
          cargo_dimensions: Json | null
          cargo_weight: number | null
          carrier_id: string | null
          carrier_rate: number | null
          completed_at: string | null
          created_at: string | null
          created_by: string | null
          delay_reason: string | null
          delivery_contact_name: string | null
          delivery_contact_phone: string | null
          delivery_location: Json | null
          delivery_time: string | null
          description: string | null
          distance_miles: number | null
          driver_email: string | null
          driver_name: string | null
          driver_phone: string | null
          equipment_type: string | null
          estimated_duration: number | null
          feedback: string | null
          hazmat_details: string | null
          id: string | null
          insurance_requirements: string | null
          invoice_id: string | null
          is_hazmat: boolean | null
          job_volume_kg: number | null
          metadata: Json | null
          pay_amount: number | null
          payment_terms: string | null
          pickup_contact_name: string | null
          pickup_contact_phone: string | null
          pickup_location: Json | null
          pickup_time: string | null
          priority: string | null
          proof_of_delivery_url: string | null
          rating: number | null
          required_certifications: string[] | null
          route_id: string | null
          secondary_status: string | null
          shipper_id: string | null
          signature_required: boolean | null
          special_instructions: string | null
          started_at: string | null
          status: string | null
          temperature_requirements: string | null
          title: string | null
          trailer_type: string | null
          updated_at: string | null
          vehicle_category_id: number | null
          vehicle_type_id: number | null
          vendor_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "jobs_assigned_driver_id_fkey"
            columns: ["assigned_driver_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_assigned_driver_id_fkey"
            columns: ["assigned_driver_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_broker_id_fkey"
            columns: ["broker_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_broker_id_fkey"
            columns: ["broker_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_carrier_id_fkey"
            columns: ["carrier_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_route_id_fkey"
            columns: ["route_id"]
            isOneToOne: false
            referencedRelation: "routes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_category"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "jobs_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["category_id"]
          },
          {
            foreignKeyName: "jobs_vehicle_category_id_fkey"
            columns: ["vehicle_category_id"]
            isOneToOne: false
            referencedRelation: "vehicle_categories"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "jobs_by_vehicle_type"
            referencedColumns: ["vehicle_type_id"]
          },
          {
            foreignKeyName: "jobs_vehicle_type_id_fkey"
            columns: ["vehicle_type_id"]
            isOneToOne: false
            referencedRelation: "vehicle_types"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "jobs_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "driver_eligible_jobs"
            referencedColumns: ["driver_id"]
          },
          {
            foreignKeyName: "jobs_vendor_id_fkey"
            columns: ["vendor_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      driver_eligible_jobs: {
        Row: {
          delivery_location: Json | null
          distance_miles: number | null
          driver_id: string | null
          job_id: string | null
          match_type: string | null
          pay_amount: number | null
          pickup_location: Json | null
          status: string | null
          title: string | null
        }
        Relationships: []
      }
      jobs_by_vehicle_category: {
        Row: {
          avg_distance_miles: number | null
          avg_pay_amount: number | null
          category_description: string | null
          category_icon: string | null
          category_id: number | null
          category_name: string | null
          completed_jobs: number | null
          in_progress_jobs: number | null
          pending_jobs: number | null
          posted_jobs: number | null
          total_distance_miles: number | null
          total_jobs: number | null
          total_pay_amount: number | null
        }
        Relationships: []
      }
      jobs_by_vehicle_type: {
        Row: {
          avg_pay_amount: number | null
          capacity: string | null
          category_icon: string | null
          category_id: number | null
          category_name: string | null
          completed_jobs: number | null
          in_progress_jobs: number | null
          pending_jobs: number | null
          posted_jobs: number | null
          total_jobs: number | null
          total_pay_amount: number | null
          vehicle_type_id: number | null
          vehicle_type_name: string | null
        }
        Relationships: []
      }
      notifications_view: {
        Row: {
          created_at: string | null
          id: string | null
          is_read: boolean | null
          link: string | null
          message: string | null
          metadata: Json | null
          read: boolean | null
          sender_id: string | null
          title: string | null
          type: Database["public"]["Enums"]["notification_type"] | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string | null
          is_read?: boolean | null
          link?: string | null
          message?: string | null
          metadata?: Json | null
          read?: boolean | null
          sender_id?: string | null
          title?: string | null
          type?: Database["public"]["Enums"]["notification_type"] | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string | null
          is_read?: boolean | null
          link?: string | null
          message?: string | null
          metadata?: Json | null
          read?: boolean | null
          sender_id?: string | null
          title?: string | null
          type?: Database["public"]["Enums"]["notification_type"] | null
          user_id?: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      admin_update_job_status: {
        Args: { p_job_id: string; p_new_status: string; p_notes?: string }
        Returns: undefined
      }
      approve_job_claim_request: {
        Args: { p_admin_notes?: string; p_request_id: string }
        Returns: Json
      }
      approve_task_assignment: {
        Args: { p_approved_by: string; p_assignment_id: string }
        Returns: undefined
      }
      archive_old_scheduled_jobs: { Args: never; Returns: undefined }
      archive_old_timesheets: { Args: never; Returns: undefined }
      auth_user_exists: { Args: { _user_id: string }; Returns: boolean }
      auto_timeout_timesheets: { Args: never; Returns: undefined }
      backfill_driver_data_from_tasks: {
        Args: never
        Returns: {
          errors: string[]
          synced_count: number
        }[]
      }
      backup_user_customization: {
        Args: { p_user_id: string }
        Returns: string
      }
      bulk_update_settings: {
        Args: { p_settings: Json; p_user_id?: string }
        Returns: undefined
      }
      carrier_add_driver: {
        Args: {
          p_carrier_id: string
          p_driver_id: string
          p_hire_date?: string
          p_vehicle_assignment?: string
        }
        Returns: string
      }
      check_driver_capacity: {
        Args: {
          p_driver_id: string
          p_is_scheduled?: boolean
          p_job_id: string
        }
        Returns: Json
      }
      check_missing_timesheets: { Args: never; Returns: undefined }
      check_my_role: {
        Args: never
        Returns: {
          email: string
          is_active: boolean
          is_admin: boolean
          is_approved: boolean
          is_super_admin: boolean
          onboarding_complete: boolean
          role_key: string
          role_name: string
          user_id: string
        }[]
      }
      claim_job_atomic: {
        Args: {
          p_admin_override?: boolean
          p_driver_id: string
          p_job_id: string
          p_override_reason?: string
        }
        Returns: Json
      }
      complete_delivery_atomic: {
        Args: {
          p_assignment_id: string
          p_delivery_photo_url: string
          p_job_id: string
        }
        Returns: Json
      }
      create_notification_from_event: {
        Args: {
          p_event_type: Database["public"]["Enums"]["notification_event_type"]
          p_link?: string
          p_message?: string
          p_metadata?: Json
          p_title?: string
          p_user_id: string
        }
        Returns: string
      }
      delete_user_account: {
        Args: { target_user_id: string }
        Returns: undefined
      }
      find_job_id_by_prefix: { Args: { prefix: string }; Returns: string }
      fn_generate_recurring_tasks: { Args: never; Returns: undefined }
      generate_account_number: { Args: never; Returns: string }
      generate_weekly_summary: {
        Args: { _admin_id: string; _week_start: string }
        Returns: undefined
      }
      get_carrier_drivers:
        | {
            Args: never
            Returns: {
              created_at: string
              email: string
              full_name: string
              id: string
              is_active: boolean
              is_approved: boolean
              phone: string
              status: string
              vehicle_assignment: string
            }[]
          }
        | {
            Args: { p_carrier_id: string }
            Returns: {
              created_at: string
              driver_email: string
              driver_id: string
              driver_name: string
              driver_phone: string
              driver_status: string
              hire_date: string
              id: string
              vehicle_assignment: string
            }[]
          }
      get_comprehensive_onboarding_status: {
        Args: { p_user_id?: string }
        Returns: {
          completed_steps: number[]
          is_approved: boolean
          last_step: number
          next_action: string
          onboarding_complete: boolean
          pending_approvals: number
          role: string
        }[]
      }
      get_effective_setting: {
        Args: { p_setting_key: string; p_user_id?: string }
        Returns: Json
      }
      get_platform_default_customization: {
        Args: never
        Returns: {
          accent_color: string
          customization_data: Json
          font_family: string
          primary_color: string
          secondary_color: string
          theme: string
        }[]
      }
      get_role_step_count: { Args: { p_role_key: string }; Returns: number }
      get_super_admin_logs:
        | {
            Args: { limit_count?: number; p_limit?: number; p_offset?: number }
            Returns: {
              action: string
              created_at: string
              details: Json
              entity_id: string
              entity_type: string
              id: string
              ip_address: unknown
              user_id: string
            }[]
          }
        | {
            Args: { p_limit?: number; p_offset?: number }
            Returns: {
              action: string
              created_at: string
              details: Json
              entity_id: string
              entity_type: string
              id: string
              ip_address: unknown
              user_id: string
            }[]
          }
      get_user_account_number: {
        Args: { _user_id?: string }
        Returns: {
          account_number: string
          generated_at: string
          is_active: boolean
        }[]
      }
      get_user_permissions: {
        Args: { _user_id?: string }
        Returns: {
          category: string
          permission_description: string
          permission_name: string
        }[]
      }
      get_user_storage_path: { Args: { _user_id?: string }; Returns: string }
      get_user_upload_info: {
        Args: never
        Returns: {
          account_number: string
          bucket_name: string
          storage_path: string
        }[]
      }
      get_valid_job_statuses: {
        Args: never
        Returns: {
          available_for_role: string[]
          description: string
          status: string
        }[]
      }
      get_vendor_financial_data: {
        Args: { _user_id?: string }
        Returns: {
          has_bank_account: boolean
          has_card: boolean
          verification_status: Database["public"]["Enums"]["approval_status"]
        }[]
      }
      get_vendor_onboarding_secure: {
        Args: { _user_id?: string }
        Returns: {
          business_name: string
          business_type: string
          created_at: string
          verification_status: Database["public"]["Enums"]["approval_status"]
        }[]
      }
      has_active_timesheet: { Args: { _admin_id: string }; Returns: boolean }
      has_function_permission: {
        Args: { _function_name: string; _user_id: string }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      initialize_user_storage: { Args: { _user_id?: string }; Returns: string }
      log_access_violation: {
        Args: {
          p_action: string
          p_reason?: string
          p_resource_id: string
          p_resource_type: string
        }
        Returns: undefined
      }
      log_document_activity: {
        Args: {
          p_action: string
          p_document_id: string
          p_document_name: string
          p_metadata?: Json
        }
        Returns: undefined
      }
      log_user_activity: {
        Args: {
          p_activity_description?: string
          p_activity_type: string
          p_metadata?: Json
          p_user_id: string
        }
        Returns: undefined
      }
      mark_overdue_admin_tasks: { Args: never; Returns: undefined }
      pickup_job_atomic: {
        Args: {
          p_assignment_id: string
          p_job_id: string
          p_pickup_photo_url: string
        }
        Returns: Json
      }
      process_kyc_from_onboarding: {
        Args: { p_user_id: string }
        Returns: Json
      }
      reject_job_claim_request: {
        Args: { p_admin_notes?: string; p_request_id: string }
        Returns: Json
      }
      reject_task_assignment: {
        Args: {
          p_assignment_id: string
          p_rejected_by: string
          p_rejection_reason: string
        }
        Returns: undefined
      }
      reset_settings_to_defaults: {
        Args: { p_backup?: boolean; p_user_id?: string }
        Returns: undefined
      }
      restore_user_customization: {
        Args: { p_backup_id: string }
        Returns: undefined
      }
      revert_job_status_atomic: {
        Args: {
          p_assignment_id: string
          p_current_status: string
          p_job_id: string
        }
        Returns: Json
      }
      review_user_document: {
        Args: {
          p_document_id: string
          p_review_notes?: string
          p_status: string
        }
        Returns: undefined
      }
      save_onboarding_step:
        | {
            Args: {
              p_mark_complete?: boolean
              p_step_data: Json
              p_step_number: number
              p_step_title: string
            }
            Returns: undefined
          }
        | {
            Args: {
              p_mark_complete?: boolean
              p_step_data: Json
              p_step_number: number
              p_step_title: string
              p_uploaded_files?: Json
            }
            Returns: undefined
          }
      send_user_message: {
        Args: {
          p_message: string
          p_message_type?: string
          p_subject: string
          p_to_user_id: string
        }
        Returns: string
      }
      send_weekly_timesheet_reminder: { Args: never; Returns: undefined }
      setup_super_admin_account: {
        Args: { p_mfa_pin_hash: string; p_user_id: string }
        Returns: undefined
      }
      start_job_atomic: {
        Args: { p_assignment_id: string; p_job_id: string }
        Returns: Json
      }
      transition_planned_jobs_to_active: { Args: never; Returns: Json }
      undo_last_setting_change: {
        Args: { p_setting_key?: string }
        Returns: undefined
      }
      update_onboarding_progress:
        | {
            Args: {
              p_mark_complete?: boolean
              p_step_number: number
              p_user_id?: string
            }
            Returns: undefined
          }
        | {
            Args: { p_mark_complete?: boolean; p_step_number: number }
            Returns: undefined
          }
      update_platform_setting: {
        Args: {
          p_category?: string
          p_setting_key: string
          p_setting_value: Json
          p_subcategory?: string
          p_value_type?: string
        }
        Returns: undefined
      }
      update_user_role: {
        Args: { p_new_role: string; p_user_id: string }
        Returns: undefined
      }
      user_can_access_critical_features: {
        Args: { _user_id?: string }
        Returns: boolean
      }
      user_can_access_job: {
        Args: { p_action: string; p_job_id: string; p_user_id: string }
        Returns: boolean
      }
      user_can_access_storage_path: {
        Args: { _path: string; _user_id: string }
        Returns: boolean
      }
      user_can_access_task: {
        Args: { p_action: string; p_task_id: string; p_user_id: string }
        Returns: boolean
      }
      user_has_permission: {
        Args: { p_permission_name: string; p_user_id: string }
        Returns: boolean
      }
      user_requires_password_change: {
        Args: { _user_id: string }
        Returns: boolean
      }
      verify_super_admin_mfa: {
        Args: { p_mfa_pin_hash: string; p_user_id: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "super_admin"
        | "admin"
        | "vendor"
        | "shipper"
        | "broker"
        | "driver"
        | "carrier"
        | "vendor_merchant"
      approval_status: "pending" | "approved" | "rejected"
      cancellation_reason_category:
        | "vehicle_issue"
        | "personal_emergency"
        | "preference_based"
        | "claim_by_mistake"
        | "other"
      doc_category: "sop" | "policy" | "tutorial" | "release_note" | "archived"
      notification_event_type:
        | "JOB_CREATED"
        | "JOB_PUBLISHED"
        | "JOB_ASSIGNED"
        | "JOB_CLAIMED"
        | "JOB_UNASSIGNED"
        | "JOB_ACCEPTED"
        | "JOB_DECLINED"
        | "JOB_REASSIGNED"
        | "JOB_DETAILS_UPDATED"
        | "JOB_DELETED"
        | "JOB_STARTED"
        | "PICKUP_IN_PROGRESS"
        | "DRIVER_ARRIVED_PICKUP"
        | "PICKUP_PHOTO_UPLOADED"
        | "PICKUP_COMPLETED"
        | "DELIVERY_IN_PROGRESS"
        | "DRIVER_ARRIVED_DROPOFF"
        | "MARK_AS_DELIVERED"
        | "DROPOFF_LOCATION_SELECTED"
        | "DELIVERY_PHOTO_UPLOADED"
        | "RECIPIENT_SIGNATURE_CAPTURED"
        | "DELIVERY_PROOF_SUBMITTED"
        | "DELIVERY_COMPLETED"
        | "JOB_CANCELLED_BY_DRIVER"
        | "JOB_CANCELLED_BY_ADMIN"
        | "JOB_CANCELLED_BY_SHIPPER"
        | "JOB_FAILED"
        | "JOB_RESCHEDULED"
        | "JOB_REOPENED"
        | "PICKUP_CONFIRMATION_APPROVED"
        | "PROOF_OF_PICKUP_UPLOADED"
        | "PROOF_OF_DELIVERY_UPLOADED"
        | "DELIVERY_CONFIRMATION_APPROVED"
        | "RECIPIENT_SIGNATURE_VERIFIED"
        | "DELIVERY_PROOF_REJECTED"
        | "PAYMENT_REQUESTED"
        | "PAYMENT_REQUEST_APPROVED"
        | "PAYMENT_REQUEST_REJECTED"
        | "PAYMENT_PROCESSING_STARTED"
        | "PAYMENT_COMPLETED"
        | "PAYMENT_FAILED"
        | "PAYMENT_ON_HOLD"
        | "REFUND_ISSUED"
        | "INVOICE_GENERATED"
        | "INVOICE_SENT"
        | "PAYOUT_SCHEDULED"
        | "PAYOUT_RELEASED"
        | "PAYOUT_DELAYED"
        | "PAYOUT_CANCELLED"
        | "NEW_CHAT_MESSAGE"
        | "NEW_COMMENT_ON_JOB"
        | "MENTIONED_IN_COMMENT"
        | "ADMIN_BROADCAST_SENT"
        | "DIRECT_MESSAGE_RECEIVED"
        | "MESSAGE_READ_CONFIRMATION"
        | "CHAT_ATTACHMENT_UPLOADED"
        | "SUPPORT_MESSAGE_REPLIED"
        | "PICKUP_DOCUMENT_UPLOADED"
        | "DELIVERY_DOCUMENT_UPLOADED"
        | "ID_VERIFICATION_REQUIRED"
        | "ID_VERIFICATION_APPROVED"
        | "ID_VERIFICATION_REJECTED"
        | "PROOF_DOCUMENT_MISSING"
        | "DOCUMENT_VERIFIED"
        | "DOCUMENT_REJECTED"
        | "DRIVER_NEAR_PICKUP"
        | "DRIVER_NEAR_DROPOFF"
        | "ETA_UPDATED"
        | "JOB_DELAYED"
        | "DRIVER_OFF_ROUTE"
        | "DRIVER_LOCATION_UPDATED"
        | "JOB_TIMER_STARTED"
        | "PICKUP_TIME_APPROACHING"
        | "DELIVERY_TIME_APPROACHING"
        | "SCHEDULED_JOB_ACTIVE"
        | "SCHEDULED_JOB_MISSED"
        | "USER_ACCOUNT_CREATED"
        | "USER_ACCOUNT_APPROVED"
        | "USER_ROLE_UPDATED"
        | "USER_ACCOUNT_SUSPENDED"
        | "USER_ACCOUNT_REACTIVATED"
        | "PASSWORD_RESET_REQUESTED"
        | "PASSWORD_RESET_SUCCESSFUL"
        | "EMAIL_VERIFIED"
        | "TWO_FACTOR_ENABLED"
        | "API_KEY_GENERATED"
        | "API_KEY_REVOKED"
        | "INTEGRATION_ADDED"
        | "INTEGRATION_REMOVED"
        | "PLATFORM_SETTINGS_UPDATED"
        | "SYSTEM_MAINTENANCE_SCHEDULED"
        | "PLATFORM_BACK_ONLINE"
        | "SYSTEM_ERROR_LOGGED"
        | "NEW_JOB_AVAILABLE_NEARBY"
        | "NEW_JOB_POSTED_IN_REGION"
        | "JOB_ASSIGNED_TO_YOU"
        | "JOB_REMOVED_FROM_YOU"
        | "PICKUP_LOCATION_UPDATED"
        | "DROPOFF_LOCATION_UPDATED"
        | "PAYMENT_RELEASED_TO_WALLET"
        | "VEHICLE_INSPECTION_REQUIRED"
        | "DRIVER_RATING_UPDATED"
        | "LICENSE_EXPIRING_SOON"
        | "ACCOUNT_REVERIFICATION_REQUIRED"
        | "NEW_COMPANY_ANNOUNCEMENT"
        | "JOB_REQUEST_SUBMITTED"
        | "JOB_REQUEST_APPROVED"
        | "JOB_REQUEST_DECLINED"
        | "DRIVER_ASSIGNED_TO_JOB"
        | "DRIVER_EN_ROUTE_PICKUP"
        | "SHIPPER_PICKUP_COMPLETED"
        | "SHIPPER_DELIVERY_COMPLETED"
        | "PROOF_OF_DELIVERY_AVAILABLE"
        | "SHIPPER_JOB_CANCELLED"
        | "SHIPPER_JOB_RESCHEDULED"
        | "SHIPPER_INVOICE_GENERATED"
        | "PAYMENT_REQUIRED"
        | "PAYMENT_RECEIVED"
        | "DISPUTE_OPENED"
        | "DISPUTE_RESOLVED"
        | "JOB_FEEDBACK_REQUESTED"
        | "JOB_RECEIVED_FROM_PARTNER"
        | "JOB_FORWARDED_TO_VENDOR"
        | "PARTNER_JOB_UPDATED"
        | "SUBCONTRACTOR_ASSIGNED"
        | "SUBCONTRACTOR_JOB_COMPLETED"
        | "COMMISSION_PAYMENT_RELEASED"
        | "PARTNER_JOB_CANCELLED"
        | "PARTNER_PAYMENT_RECEIVED"
        | "RATING_SUBMITTED_BY_DRIVER"
        | "RATING_SUBMITTED_BY_SHIPPER"
        | "RATING_RECEIVED"
        | "REVIEW_COMMENT_POSTED"
        | "REVIEW_APPROVED"
        | "SUPPORT_TICKET_CREATED"
        | "SUPPORT_TICKET_UPDATED"
        | "SUPPORT_TICKET_CLOSED"
        | "SUPPORT_TICKET_ASSIGNED"
        | "DISPUTE_CREATED"
        | "DISPUTE_UPDATED"
        | "DISPUTE_RESOLVED_FINAL"
        | "DISPUTE_ESCALATED"
        | "REFUND_APPROVED"
        | "NOTIFICATION_DELIVERED"
        | "NOTIFICATION_SEEN"
        | "NOTIFICATION_FAILED"
        | "EMAIL_NOTIFICATION_SENT"
        | "PUSH_NOTIFICATION_SENT"
        | "SMS_NOTIFICATION_SENT"
        | "NOTIFICATION_PREFERENCES_UPDATED"
        | "SYSTEM_UPDATE_AVAILABLE"
        | "NEW_APP_VERSION_RELEASED"
        | "NEW_FEATURE_ANNOUNCEMENT"
        | "POLICY_UPDATED"
        | "PRIVACY_POLICY_UPDATED"
        | "SYSTEM_ALERT_HIGH_LOAD"
        | "DATABASE_MIGRATION_COMPLETED"
        | "BACKUP_SUCCESSFUL"
        | "BACKUP_FAILED"
        | "API_SERVICE_DISRUPTION"
        | "NEW_LOGIN_UNKNOWN_DEVICE"
        | "MULTIPLE_FAILED_LOGINS"
        | "ACCOUNT_LOCKED"
        | "PASSWORD_CHANGED"
        | "DEVICE_AUTHORIZED"
        | "SESSION_EXPIRED"
        | "ADMIN_ACCESS_GRANTED"
        | "ADMIN_ACCESS_REVOKED"
        | "SUSPICIOUS_ACTIVITY_DETECTED"
        | "DAILY_JOB_SUMMARY"
        | "WEEKLY_JOB_REPORT"
        | "DRIVER_PERFORMANCE_SUMMARY"
        | "SHIPPER_MONTHLY_REPORT"
        | "VENDOR_PAYMENT_SUMMARY"
        | "ADMIN_PLATFORM_REPORT"
        | "BEST_DRIVER_OF_WEEK"
        | "JOB_REMINDER_MANUAL"
        | "DELIVERY_CONFIRMATION_REMINDER"
        | "DOCUMENT_UPLOAD_REMINDER"
        | "PAYMENT_REMINDER"
        | "PROFILE_COMPLETION_REMINDER"
        | "RATING_REQUEST_REMINDER"
        | "APP_FEEDBACK_REQUEST"
        | "SYSTEM_WELCOME_MESSAGE"
        | "ACCOUNT_MILESTONE"
        | "HOLIDAY_GREETINGS"
        | "DRIVER_ENTERED_PICKUP_RADIUS"
        | "DRIVER_EXITED_PICKUP_RADIUS"
        | "DRIVER_ENTERED_DROPOFF_RADIUS"
        | "DRIVER_EXITED_DROPOFF_RADIUS"
        | "ROUTE_DEVIATION_ALERT"
        | "ROUTE_OPTIMIZED"
        | "GPS_SIGNAL_LOST"
        | "GPS_SIGNAL_RECOVERED"
        | "DRIVER_IDLE_TOO_LONG"
        | "UNEXPECTED_STOP_DETECTED"
        | "DELIVERY_ETA_CHANGED"
        | "RECIPIENT_LOCATION_CHANGED"
        | "ALTERNATE_DROPOFF_CHOSEN"
        | "MULTI_DROP_JOB_COMPLETED"
      notification_type:
        | "system"
        | "job_posted"
        | "job_claimed"
        | "job_completed"
        | "payment"
        | "approval"
        | "message"
      sub_role:
        | "technical_admin"
        | "it_administrator"
        | "operations_manager"
        | "business_associate"
        | "account_manager"
        | "vendor_merchant"
        | "shipper"
        | "broker"
        | "carrier"
        | "driver"
        | "finance_manager"
        | "accountant"
        | "payroll_officer"
        | "auditor"
        | "compliance_officer"
        | "legal_advisor"
        | "hr_officer"
        | "recruitment_officer"
        | "task_coordinator"
        | "driver_support"
        | "platform_engineer"
        | "data_analyst"
        | "system_auditor"
        | "carrier_driver"
        | "independent_driver"
      task_category: "daily" | "weekly" | "monthly" | "quarterly" | "yearly"
      task_priority: "low" | "medium" | "high" | "critical"
      task_role: "admin" | "super_admin"
      task_status: "pending" | "in_progress" | "completed" | "overdue"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "super_admin",
        "admin",
        "vendor",
        "shipper",
        "broker",
        "driver",
        "carrier",
        "vendor_merchant",
      ],
      approval_status: ["pending", "approved", "rejected"],
      cancellation_reason_category: [
        "vehicle_issue",
        "personal_emergency",
        "preference_based",
        "claim_by_mistake",
        "other",
      ],
      doc_category: ["sop", "policy", "tutorial", "release_note", "archived"],
      notification_event_type: [
        "JOB_CREATED",
        "JOB_PUBLISHED",
        "JOB_ASSIGNED",
        "JOB_CLAIMED",
        "JOB_UNASSIGNED",
        "JOB_ACCEPTED",
        "JOB_DECLINED",
        "JOB_REASSIGNED",
        "JOB_DETAILS_UPDATED",
        "JOB_DELETED",
        "JOB_STARTED",
        "PICKUP_IN_PROGRESS",
        "DRIVER_ARRIVED_PICKUP",
        "PICKUP_PHOTO_UPLOADED",
        "PICKUP_COMPLETED",
        "DELIVERY_IN_PROGRESS",
        "DRIVER_ARRIVED_DROPOFF",
        "MARK_AS_DELIVERED",
        "DROPOFF_LOCATION_SELECTED",
        "DELIVERY_PHOTO_UPLOADED",
        "RECIPIENT_SIGNATURE_CAPTURED",
        "DELIVERY_PROOF_SUBMITTED",
        "DELIVERY_COMPLETED",
        "JOB_CANCELLED_BY_DRIVER",
        "JOB_CANCELLED_BY_ADMIN",
        "JOB_CANCELLED_BY_SHIPPER",
        "JOB_FAILED",
        "JOB_RESCHEDULED",
        "JOB_REOPENED",
        "PICKUP_CONFIRMATION_APPROVED",
        "PROOF_OF_PICKUP_UPLOADED",
        "PROOF_OF_DELIVERY_UPLOADED",
        "DELIVERY_CONFIRMATION_APPROVED",
        "RECIPIENT_SIGNATURE_VERIFIED",
        "DELIVERY_PROOF_REJECTED",
        "PAYMENT_REQUESTED",
        "PAYMENT_REQUEST_APPROVED",
        "PAYMENT_REQUEST_REJECTED",
        "PAYMENT_PROCESSING_STARTED",
        "PAYMENT_COMPLETED",
        "PAYMENT_FAILED",
        "PAYMENT_ON_HOLD",
        "REFUND_ISSUED",
        "INVOICE_GENERATED",
        "INVOICE_SENT",
        "PAYOUT_SCHEDULED",
        "PAYOUT_RELEASED",
        "PAYOUT_DELAYED",
        "PAYOUT_CANCELLED",
        "NEW_CHAT_MESSAGE",
        "NEW_COMMENT_ON_JOB",
        "MENTIONED_IN_COMMENT",
        "ADMIN_BROADCAST_SENT",
        "DIRECT_MESSAGE_RECEIVED",
        "MESSAGE_READ_CONFIRMATION",
        "CHAT_ATTACHMENT_UPLOADED",
        "SUPPORT_MESSAGE_REPLIED",
        "PICKUP_DOCUMENT_UPLOADED",
        "DELIVERY_DOCUMENT_UPLOADED",
        "ID_VERIFICATION_REQUIRED",
        "ID_VERIFICATION_APPROVED",
        "ID_VERIFICATION_REJECTED",
        "PROOF_DOCUMENT_MISSING",
        "DOCUMENT_VERIFIED",
        "DOCUMENT_REJECTED",
        "DRIVER_NEAR_PICKUP",
        "DRIVER_NEAR_DROPOFF",
        "ETA_UPDATED",
        "JOB_DELAYED",
        "DRIVER_OFF_ROUTE",
        "DRIVER_LOCATION_UPDATED",
        "JOB_TIMER_STARTED",
        "PICKUP_TIME_APPROACHING",
        "DELIVERY_TIME_APPROACHING",
        "SCHEDULED_JOB_ACTIVE",
        "SCHEDULED_JOB_MISSED",
        "USER_ACCOUNT_CREATED",
        "USER_ACCOUNT_APPROVED",
        "USER_ROLE_UPDATED",
        "USER_ACCOUNT_SUSPENDED",
        "USER_ACCOUNT_REACTIVATED",
        "PASSWORD_RESET_REQUESTED",
        "PASSWORD_RESET_SUCCESSFUL",
        "EMAIL_VERIFIED",
        "TWO_FACTOR_ENABLED",
        "API_KEY_GENERATED",
        "API_KEY_REVOKED",
        "INTEGRATION_ADDED",
        "INTEGRATION_REMOVED",
        "PLATFORM_SETTINGS_UPDATED",
        "SYSTEM_MAINTENANCE_SCHEDULED",
        "PLATFORM_BACK_ONLINE",
        "SYSTEM_ERROR_LOGGED",
        "NEW_JOB_AVAILABLE_NEARBY",
        "NEW_JOB_POSTED_IN_REGION",
        "JOB_ASSIGNED_TO_YOU",
        "JOB_REMOVED_FROM_YOU",
        "PICKUP_LOCATION_UPDATED",
        "DROPOFF_LOCATION_UPDATED",
        "PAYMENT_RELEASED_TO_WALLET",
        "VEHICLE_INSPECTION_REQUIRED",
        "DRIVER_RATING_UPDATED",
        "LICENSE_EXPIRING_SOON",
        "ACCOUNT_REVERIFICATION_REQUIRED",
        "NEW_COMPANY_ANNOUNCEMENT",
        "JOB_REQUEST_SUBMITTED",
        "JOB_REQUEST_APPROVED",
        "JOB_REQUEST_DECLINED",
        "DRIVER_ASSIGNED_TO_JOB",
        "DRIVER_EN_ROUTE_PICKUP",
        "SHIPPER_PICKUP_COMPLETED",
        "SHIPPER_DELIVERY_COMPLETED",
        "PROOF_OF_DELIVERY_AVAILABLE",
        "SHIPPER_JOB_CANCELLED",
        "SHIPPER_JOB_RESCHEDULED",
        "SHIPPER_INVOICE_GENERATED",
        "PAYMENT_REQUIRED",
        "PAYMENT_RECEIVED",
        "DISPUTE_OPENED",
        "DISPUTE_RESOLVED",
        "JOB_FEEDBACK_REQUESTED",
        "JOB_RECEIVED_FROM_PARTNER",
        "JOB_FORWARDED_TO_VENDOR",
        "PARTNER_JOB_UPDATED",
        "SUBCONTRACTOR_ASSIGNED",
        "SUBCONTRACTOR_JOB_COMPLETED",
        "COMMISSION_PAYMENT_RELEASED",
        "PARTNER_JOB_CANCELLED",
        "PARTNER_PAYMENT_RECEIVED",
        "RATING_SUBMITTED_BY_DRIVER",
        "RATING_SUBMITTED_BY_SHIPPER",
        "RATING_RECEIVED",
        "REVIEW_COMMENT_POSTED",
        "REVIEW_APPROVED",
        "SUPPORT_TICKET_CREATED",
        "SUPPORT_TICKET_UPDATED",
        "SUPPORT_TICKET_CLOSED",
        "SUPPORT_TICKET_ASSIGNED",
        "DISPUTE_CREATED",
        "DISPUTE_UPDATED",
        "DISPUTE_RESOLVED_FINAL",
        "DISPUTE_ESCALATED",
        "REFUND_APPROVED",
        "NOTIFICATION_DELIVERED",
        "NOTIFICATION_SEEN",
        "NOTIFICATION_FAILED",
        "EMAIL_NOTIFICATION_SENT",
        "PUSH_NOTIFICATION_SENT",
        "SMS_NOTIFICATION_SENT",
        "NOTIFICATION_PREFERENCES_UPDATED",
        "SYSTEM_UPDATE_AVAILABLE",
        "NEW_APP_VERSION_RELEASED",
        "NEW_FEATURE_ANNOUNCEMENT",
        "POLICY_UPDATED",
        "PRIVACY_POLICY_UPDATED",
        "SYSTEM_ALERT_HIGH_LOAD",
        "DATABASE_MIGRATION_COMPLETED",
        "BACKUP_SUCCESSFUL",
        "BACKUP_FAILED",
        "API_SERVICE_DISRUPTION",
        "NEW_LOGIN_UNKNOWN_DEVICE",
        "MULTIPLE_FAILED_LOGINS",
        "ACCOUNT_LOCKED",
        "PASSWORD_CHANGED",
        "DEVICE_AUTHORIZED",
        "SESSION_EXPIRED",
        "ADMIN_ACCESS_GRANTED",
        "ADMIN_ACCESS_REVOKED",
        "SUSPICIOUS_ACTIVITY_DETECTED",
        "DAILY_JOB_SUMMARY",
        "WEEKLY_JOB_REPORT",
        "DRIVER_PERFORMANCE_SUMMARY",
        "SHIPPER_MONTHLY_REPORT",
        "VENDOR_PAYMENT_SUMMARY",
        "ADMIN_PLATFORM_REPORT",
        "BEST_DRIVER_OF_WEEK",
        "JOB_REMINDER_MANUAL",
        "DELIVERY_CONFIRMATION_REMINDER",
        "DOCUMENT_UPLOAD_REMINDER",
        "PAYMENT_REMINDER",
        "PROFILE_COMPLETION_REMINDER",
        "RATING_REQUEST_REMINDER",
        "APP_FEEDBACK_REQUEST",
        "SYSTEM_WELCOME_MESSAGE",
        "ACCOUNT_MILESTONE",
        "HOLIDAY_GREETINGS",
        "DRIVER_ENTERED_PICKUP_RADIUS",
        "DRIVER_EXITED_PICKUP_RADIUS",
        "DRIVER_ENTERED_DROPOFF_RADIUS",
        "DRIVER_EXITED_DROPOFF_RADIUS",
        "ROUTE_DEVIATION_ALERT",
        "ROUTE_OPTIMIZED",
        "GPS_SIGNAL_LOST",
        "GPS_SIGNAL_RECOVERED",
        "DRIVER_IDLE_TOO_LONG",
        "UNEXPECTED_STOP_DETECTED",
        "DELIVERY_ETA_CHANGED",
        "RECIPIENT_LOCATION_CHANGED",
        "ALTERNATE_DROPOFF_CHOSEN",
        "MULTI_DROP_JOB_COMPLETED",
      ],
      notification_type: [
        "system",
        "job_posted",
        "job_claimed",
        "job_completed",
        "payment",
        "approval",
        "message",
      ],
      sub_role: [
        "technical_admin",
        "it_administrator",
        "operations_manager",
        "business_associate",
        "account_manager",
        "vendor_merchant",
        "shipper",
        "broker",
        "carrier",
        "driver",
        "finance_manager",
        "accountant",
        "payroll_officer",
        "auditor",
        "compliance_officer",
        "legal_advisor",
        "hr_officer",
        "recruitment_officer",
        "task_coordinator",
        "driver_support",
        "platform_engineer",
        "data_analyst",
        "system_auditor",
        "carrier_driver",
        "independent_driver",
      ],
      task_category: ["daily", "weekly", "monthly", "quarterly", "yearly"],
      task_priority: ["low", "medium", "high", "critical"],
      task_role: ["admin", "super_admin"],
      task_status: ["pending", "in_progress", "completed", "overdue"],
    },
  },
} as const
