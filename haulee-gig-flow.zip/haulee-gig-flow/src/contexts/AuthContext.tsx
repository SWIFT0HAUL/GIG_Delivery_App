import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import type { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { crossTabSync } from '@/lib/crossTabSync';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  signUp: (userData: {
    email: string;
    password: string;
    full_name: string;
    role: string;
    phone: string;
    company_name?: string;
    first_name: string;
    last_name: string;
  }) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  redirectUser: (user: User) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

interface AuthProviderProps {
  children: ReactNode;
}

export function AuthProvider({ children }: AuthProviderProps) {
  const navigate = useNavigate();
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  
  const redirectUser = async (user: User) => {
    try {
      // Check for force password change
      const forcePasswordChange = user.user_metadata?.force_password_change;
      if (forcePasswordChange === true || forcePasswordChange === 'true') {
        console.log('User requires password change - blocking navigation');
        return;
      }

      // Check for admin-created user first login
      const { data: initialProfile } = await supabase
        .from('profiles')
        .select('role_key, onboarding_complete, email_confirmed')
        .eq('id', user.id)
        .single();
      
      if (initialProfile?.email_confirmed && !initialProfile?.onboarding_complete && initialProfile?.role_key) {
        const role = initialProfile.role_key;
        console.log(`Admin-created user first login - redirecting to onboarding for role ${role}`);
        return navigate(`/onboarding?role=${role}`, { replace: true });
      }
      
      // Get comprehensive onboarding status
      const { data: userStatus, error } = await supabase
        .rpc("get_comprehensive_onboarding_status", { p_user_id: user.id })
        .maybeSingle();

      if (error) {
        console.error('Comprehensive onboarding status RPC error:', error);
        const isFirstSignIn = user.created_at === user.last_sign_in_at;
        const role = user.user_metadata?.role || "default";
        const onboardingCompleted = user.user_metadata?.onboarding_completed || false;
        const lastOnboardingStep = user.user_metadata?.last_onboarding_step || 1;

        if (isFirstSignIn) {
          return navigate(`/onboarding?role=${role}`, { replace: true });
        }
        if (!onboardingCompleted) {
          return navigate(`/onboarding?role=${role}&step=${lastOnboardingStep}`, { replace: true });
        }
        return navigate(`/dashboard/${role}`, { replace: true });
      }

      if (!userStatus) {
        const role = user.user_metadata?.role;
        const onboardingUrl = role ? `/onboarding?role=${role}` : '/onboarding';
        return navigate(onboardingUrl, { replace: true });
      }

      console.log('User role:', userStatus.role, 'Approved:', userStatus.is_approved, 'Next action:', userStatus.next_action);

      // Super Admin always goes to unified dashboard
      if (userStatus.role === "super_admin") {
        console.log('Super Admin detected - redirecting to unified dashboard');
        return navigate("/dashboard/admin-users", { replace: true });
      }

      // Check if user is active and first login status
      const { data: profileData } = await supabase
        .from('profiles')
        .select('is_active, first_login_completed')
        .eq('id', user.id)
        .single();
      
      const isUserActive = profileData?.is_active === true;
      const firstLoginCompleted = profileData?.first_login_completed === true;
      console.log('Admin user active status:', isUserActive, 'First login completed:', firstLoginCompleted);

      // Active Admin users - check first login
      if (userStatus.role === "admin" && isUserActive && userStatus.is_approved) {
        if (!firstLoginCompleted) {
          console.log('✅ Active Admin first login - redirecting to job management');
          return navigate("/admin-dashboard/jobs", { replace: true });
        }
        console.log('✅ Active Admin detected - redirecting to unified dashboard');
        return navigate("/dashboard/admin-users", { replace: true });
      }

      // Admin approved but not active
      if (userStatus.role === "admin" && !isUserActive && userStatus.is_approved) {
        console.log('⚠️ Admin approved but not active - redirecting to status page');
        return navigate("/status-and-tasks", { replace: true });
      }
      
      // Route based on next_action
      switch (userStatus.next_action) {
        case "complete_onboarding":
          const userRole = userStatus.role || user.user_metadata?.role;
          const onboardingUrl = userRole ? `/onboarding?role=${userRole}` : '/onboarding';
          
          if (userStatus.last_step && Number(userStatus.last_step) > 0) {
            console.log(`Redirecting to onboarding step ${userStatus.last_step} for role ${userRole}`);
            return navigate(`${onboardingUrl}&step=${userStatus.last_step}`, { replace: true });
          }
          console.log(`Redirecting to onboarding for role ${userRole}`);
          return navigate(onboardingUrl, { replace: true });
        
        case "awaiting_approval":
          console.log('User awaiting approval - redirecting to status page');
          return navigate("/status-and-tasks", { replace: true });
        
        case "dashboard":
          if (isUserActive) {
            const roleToDashboard: Record<string, string> = {
              driver: "/driver-dashboard/driver-available-jobs",
              carrier: "/carrier-dashboard",
              shipper: "/shipper-dashboard",
              broker: "/broker-dashboard",
              vendor: "/vendor-dashboard",
              vendor_merchant: "/vendor-dashboard",
              admin: "/dashboard/admin-users",
              super_admin: "/dashboard/admin-users",
            };
            const target = roleToDashboard[userStatus.role] || "/dashboard";
            console.log(`✅ Active user (${userStatus.role}) redirecting to: ${target}`);
            return navigate(target, { replace: true });
          } else {
            console.log('⚠️ User approved but not active - redirecting to status page');
            return navigate("/status-and-tasks", { replace: true });
          }
        
        default:
          console.log('Unknown next_action, defaulting to onboarding');
          return navigate("/onboarding", { replace: true });
      }
    } catch (err) {
      console.error('Error in redirectUser:', err);
      return navigate("/onboarding", { replace: true });
    }
  };

  useEffect(() => {
    let redirectTimeout: NodeJS.Timeout | null = null;
    let profileSubscription: any = null;

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        console.log('🔐 Auth state change:', event);
        
        setSession(session);
        setUser(session?.user ?? null);
        setLoading(false);

        // Handle all auth events
        if (event === 'SIGNED_OUT') {
          crossTabSync.send('LOGOUT');
        }
        
        if (event === 'TOKEN_REFRESHED') {
          console.log('🔄 Token refreshed - checking metadata');
        }

        if (event === 'USER_UPDATED') {
          console.log('👤 User metadata updated');
        }
        
        if (event === 'SIGNED_IN' && session?.user) {
          const urlParams = new URLSearchParams(window.location.search);
          const isEmailVerification = urlParams.get('type') === 'signup';
          const isConfirmed = urlParams.get('confirmed') === '1';
          const hasTokenParams = urlParams.get('token_hash') || urlParams.get('access_token');
          
          if (session.user.email_confirmed_at) {
            if (isEmailVerification || isConfirmed || hasTokenParams) {
              window.history.replaceState({}, document.title, window.location.pathname);
            }
            
            if (redirectTimeout) clearTimeout(redirectTimeout);
            if (!window.location.pathname.startsWith('/auth')) {
              redirectUser(session.user);
            } else {
              console.log('On /auth - skipping auto redirect after sign-in');
            }
          }
        }

        // Setup profile subscription when user signs in
        if (event === 'SIGNED_IN' && session?.user?.id && !profileSubscription) {
          profileSubscription = supabase
            .channel(`profile-changes-${session.user.id}`)
            .on(
              'postgres_changes',
              {
                event: 'UPDATE',
                schema: 'public',
                table: 'profiles',
                filter: `id=eq.${session.user.id}`,
              },
              (payload) => {
                console.log('Profile updated:', payload);
                const newProfile = payload.new;
                if (newProfile.is_active === false) {
                  console.log('User deactivated - redirecting to status page');
                  navigate('/status-and-tasks', { replace: true });
                } else if (newProfile.is_active === true && newProfile.is_approved === true) {
                  console.log('User activated - redirecting to dashboard');
                  if (session.user && !window.location.pathname.startsWith('/auth')) {
                    redirectUser(session.user);
                  } else if (session.user) {
                    console.log('On /auth - skipping auto redirect on profile activation');
                  }
                }
              }
            )
            .subscribe();
        }

        // Cleanup profile subscription on sign out
        if (event === 'SIGNED_OUT' && profileSubscription) {
          supabase.removeChannel(profileSubscription);
          profileSubscription = null;
        }
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);

      // Setup initial profile subscription if user exists
      if (session?.user?.id) {
        profileSubscription = supabase
          .channel(`profile-changes-${session.user.id}`)
          .on(
            'postgres_changes',
            {
              event: 'UPDATE',
              schema: 'public',
              table: 'profiles',
              filter: `id=eq.${session.user.id}`,
            },
            (payload) => {
              console.log('Profile updated:', payload);
              const newProfile = payload.new;
              if (newProfile.is_active === false) {
                console.log('User deactivated - redirecting to status page');
                navigate('/status-and-tasks', { replace: true });
              } else if (newProfile.is_active === true && newProfile.is_approved === true) {
                console.log('User activated - redirecting to dashboard');
                if (session.user && !window.location.pathname.startsWith('/auth')) {
                  redirectUser(session.user);
                } else if (session.user) {
                  console.log('On /auth - skipping auto redirect on profile activation');
                }
              }
            }
          )
          .subscribe();
      }
    });

    return () => {
      subscription.unsubscribe();
      if (profileSubscription) {
        supabase.removeChannel(profileSubscription);
      }
      if (redirectTimeout) clearTimeout(redirectTimeout);
    };
  }, [navigate]);

  const signUp = async (userData: {
    email: string;
    password: string;
    full_name: string;
    role: string;
    phone: string;
    company_name?: string;
    first_name: string;
    last_name: string;
  }) => {
    const { email, password, full_name, role, phone, company_name, first_name, last_name } = userData;

    try {
      setLoading(true);
      
      const isProduction = window.location.hostname === 'swiftohaul.com';
      const siteUrl = isProduction ? 'https://swiftohaul.com' : window.location.origin;
      const redirectUrl = `${siteUrl}/auth?type=signup`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: { full_name, role, phone, company_name, first_name, last_name },
          emailRedirectTo: redirectUrl
        }
      });

      if (error) {
        toast({
          title: "Sign up failed",
          description: error.message,
          variant: "destructive",
        });
        return { error };
      }

      toast({
        title: "Sign up successful!",
        description: "Please check your email to confirm your account.",
      });

      return { error: null };
    } catch (error) {
      console.error('Unexpected error:', error);
      toast({
        title: "An unexpected error occurred",
        description: "Please try again later.",
        variant: "destructive",
      });
      return { error };
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      await supabase.auth.signOut({ scope: 'local' }).catch(() => {});
      
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast({
          title: "Sign In Error",
          description: error.message,
          variant: "destructive",
        });
        return { error };
      }

      const forcePasswordChange = data.user?.user_metadata?.force_password_change;
      if (forcePasswordChange === true || forcePasswordChange === 'true') {
        console.log('User requires password change - staying on auth page');
        return { error: null };
      }

      toast({
        title: "Welcome back!",
        description: "You have been signed in successfully.",
      });

      redirectUser(data.user);

      return { error: null };
    } catch (error: any) {
      return { error };
    }
  };

  const signOut = async () => {
    try {
      crossTabSync.send('LOGOUT');
      
      setUser(null);
      setSession(null);
      
      const { error } = await supabase.auth.signOut({ scope: 'local' });
      
      if (error && error.message !== "Auth session missing!") {
        toast({
          title: "Sign Out Error",
          description: error.message,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Signed out",
          description: "You have been signed out successfully.",
        });
      }
      
      navigate('/', { replace: true });
    } catch (error: any) {
      setUser(null);
      setSession(null);
      
      toast({
        title: "Signed out",
        description: "You have been signed out.",
      });
      
      navigate('/', { replace: true });
    }
  };

  const value: AuthContextType = {
    user,
    session,
    loading,
    signUp,
    signIn,
    signOut,
    redirectUser,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}
