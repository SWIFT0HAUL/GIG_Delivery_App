import React, { createContext, useContext, useState, ReactNode } from 'react';

export interface DispatchJob {
  id: string;
  title: string;
  pickup: string;
  delivery: string;
  distance: string;
  duration: string;
  cargo: string;
  price: string;
  priority?: 'high' | 'medium' | 'low';
  deadline?: string;
  assignedDriver?: string;
}

interface DispatchContextType {
  unassignedJobs: DispatchJob[];
  assignedJobs: DispatchJob[];
  addJobToDispatch: (job: DispatchJob) => void;
  removeJobFromDispatch: (jobId: string) => void;
  assignDriver: (jobId: string, driverName: string) => void;
}

const DispatchContext = createContext<DispatchContextType | undefined>(undefined);

export const DispatchProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [unassignedJobs, setUnassignedJobs] = useState<DispatchJob[]>([]);
  const [assignedJobs, setAssignedJobs] = useState<DispatchJob[]>([]);

  const addJobToDispatch = (job: DispatchJob) => {
    setUnassignedJobs((prev) => {
      // Avoid duplicates
      if (prev.some((j) => j.id === job.id)) {
        return prev;
      }
      return [...prev, job];
    });
  };

  const removeJobFromDispatch = (jobId: string) => {
    setUnassignedJobs((prev) => prev.filter((j) => j.id !== jobId));
  };

  const assignDriver = (jobId: string, driverName: string) => {
    const job = unassignedJobs.find((j) => j.id === jobId);
    if (job) {
      const assignedJob = { ...job, assignedDriver: driverName };
      setAssignedJobs((prev) => [...prev, assignedJob]);
      setUnassignedJobs((prev) => prev.filter((j) => j.id !== jobId));
    }
  };

  return (
    <DispatchContext.Provider value={{ unassignedJobs, assignedJobs, addJobToDispatch, removeJobFromDispatch, assignDriver }}>
      {children}
    </DispatchContext.Provider>
  );
};

export const useDispatch = () => {
  const context = useContext(DispatchContext);
  if (context === undefined) {
    throw new Error('useDispatch must be used within a DispatchProvider');
  }
  return context;
};
