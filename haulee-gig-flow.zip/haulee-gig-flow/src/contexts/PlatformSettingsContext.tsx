import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from './AuthContext';
import { toast } from '@/hooks/use-toast';

interface PlatformSettings {
  // Users
  defaultUserRole?: string;
  autoApproveUsers?: boolean;
  requireEmailVerification?: boolean;
  
  // Security
  passwordMinLength?: number;
  requireMFA?: boolean;
  sessionTimeout?: number;
  maxLoginAttempts?: number;
  
  // Notifications
  enableEmailNotifications?: boolean;
  enablePushNotifications?: boolean;
  enableInAppNotifications?: boolean;
  
  // Platform Customization
  theme?: string;
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  backgroundColor?: string;
  surfaceColor?: string;
  fontFamily?: string;
  fontSize?: number;
  borderRadius?: number;
  
  // Branding
  brandLogoUrl?: string;
  brandFaviconUrl?: string;
  brandTagline?: string;
  seoMetaTitle?: string;
  seoMetaDescription?: string;
  seoSocialImage?: string;
  
  // Extended Colors
  textPrimaryColor?: string;
  textSecondaryColor?: string;
  textMutedColor?: string;
  borderColor?: string;
  shadowColor?: string;
  gradientPrimary?: string;
  gradientSecondary?: string;
  
  // Typography Extended
  headingFont?: string;
  headingSize?: number;
  lineHeight?: number;
  letterSpacing?: number;
  fontWeight?: number;
  
  // Layout
  headerHeight?: number;
  headerStyle?: string;
  headerPosition?: string;
  sidebarWidth?: number;
  sidebarStyle?: string;
  sidebarPosition?: string;
  contentPadding?: string;
  maxContentWidth?: string;
  
  // Backgrounds
  backgroundType?: string;
  backgroundGradient?: string;
  backgroundImage?: string;
  
  // Components
  buttonStyle?: string;
  buttonSize?: string;
  buttonHover?: string;
  hoverEffect?: string;
  cardStyle?: string;
  inputStyle?: string;
  iconStyle?: string;
  shadowIntensity?: string;
  
  // Behavior Extended
  darkMode?: boolean;
  autoRefresh?: boolean;
  defaultMapView?: string;
  customCSS?: string;
  
  // Integrations
  onfidoEnabled?: boolean;
  stripeEnabled?: boolean;
  twilioEnabled?: boolean;
  googleMapsEnabled?: boolean;
  googleMapsApiKey?: string;
  checkrPortalUrl?: string;
  
  // Billing
  defaultPlan?: string;
  billingCycle?: string;
  
  // API
  apiRateLimit?: number;
  apiVersion?: string;
  
  // General / Platform
  platformName?: string;
  maintenanceMode?: boolean;
  allowRegistration?: boolean;
  
  // System
  systemVersion?: string;
  maxUploadSize?: number;
  systemTimezone?: string;
  platformCurrency?: string;
  platformFee?: number;
  maxUsersPerOrg?: number;
  maxStoragePerUser?: number;
  
  // Delivery Radius Enforcement
  enableRadiusEnforcement?: boolean;
  enablePickupRadius?: boolean;
  enableDropoffRadius?: boolean;
  showRadiusMap?: boolean;
  logRadiusAttempts?: boolean;
  
  // Analytics
  enableAnalytics?: boolean;
  enablePerformanceMonitoring?: boolean;
  enableUserBehaviorAnalytics?: boolean;
  analyticsRetention?: string;
  enableWeeklyReports?: boolean;
  enableMonthlyReports?: boolean;
  reportFormat?: string;
  enableAuditLogging?: boolean;
  auditLogRetention?: string;
  
  // Customization - Content
  itemsPerPage?: number;
  defaultView?: string;
  
  // Customization - Behavior
  animationStyle?: string;
  transitionSpeed?: number;
  
  // Customization - Accessibility
  fontScaling?: number;
  highContrast?: boolean;
  reduceMotion?: boolean;
  keyboardNavigation?: boolean;
  focusIndicators?: boolean;
  
  // Behavior
  animationsEnabled?: boolean;
  tooltipsEnabled?: boolean;
}

interface PlatformSettingsContextType {
  settings: PlatformSettings;
  loading: boolean;
  updateSetting: (key: string, value: any) => void;
  bulkUpdateSettings: (updates: Partial<PlatformSettings>) => void;
  saveAllChanges: () => Promise<void>;
  discardChanges: () => void;
  reloadSettings: () => Promise<void>;
  resetToDefaults: () => Promise<void>;
  undoLastChange: () => Promise<void>;
  activityLog: ActivityLogEntry[];
  canUndo: boolean;
  hasUnsavedChanges: boolean;
  stagedSettings: PlatformSettings;
}

interface ActivityLogEntry {
  id: string;
  timestamp: Date;
  action: string;
  key: string;
  oldValue?: any;
  newValue: any;
  userId: string;
}

const PlatformSettingsContext = createContext<PlatformSettingsContextType | undefined>(undefined);

export const PlatformSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [settings, setSettings] = useState<PlatformSettings>({});
  const [stagedSettings, setStagedSettings] = useState<PlatformSettings>({});
  const [loading, setLoading] = useState(true);
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

  const loadSettings = useCallback(async () => {
    try {
      setLoading(true);
      const settingsObj: any = {};

      // 1) Load platform-wide settings from platform_settings table
      const { data: platformData, error: platformError } = await supabase
        .from('platform_settings')
        .select('*')
        .eq('status', 'active');

      if (!platformError && platformData?.length) {
        platformData.forEach((item: any) => {
          // Extract value from JSONB setting_value
          settingsObj[item.setting_key] = item.setting_value;
        });
        console.log('✅ Loaded platform settings:', platformData.length);
      } else {
        console.warn('No platform settings found or error:', platformError?.message);
      }

      // 2) Apply user-specific overrides from user_settings table
      if (user?.id) {
        const { data: userSettings, error: userError } = await supabase
          .from('user_settings')
          .select('*')
          .eq('user_id', user.id)
          .eq('is_enabled', true);

        if (!userError && userSettings?.length) {
          userSettings.forEach((override: any) => {
            settingsObj[override.setting_key] = override.setting_value;
          });
          console.log('✅ Applied user overrides:', userSettings.length);
        }
      }

      // 3) Fallback: get platform default customization if no settings found
      if (!platformData?.length) {
        const { data: defaults, error: defaultsError } = await supabase.rpc('get_platform_default_customization');
        if (!defaultsError && defaults && defaults.length > 0) {
          const row = defaults[0];
          const cd = (row as any).customization_data || {};

          // Map core fields to camelCase expected by UI/hooks
          if (row.primary_color) settingsObj.primaryColor = row.primary_color;
          if (row.secondary_color) settingsObj.secondaryColor = row.secondary_color;
          if (row.accent_color) settingsObj.accentColor = row.accent_color;
          if (row.font_family) settingsObj.fontFamily = row.font_family;
          Object.assign(settingsObj, cd);
          console.log('✅ Applied fallback defaults');
        } else if (defaultsError) {
          console.error('RPC get_platform_default_customization failed:', defaultsError);
        }
      }

      console.log('📊 Final Platform Settings:', settingsObj);
      setSettings(settingsObj);
      setStagedSettings(settingsObj);
      setHasUnsavedChanges(false);
    } catch (error) {
      console.error('Error loading platform settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to load platform settings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadSettings();
  }, [loadSettings]);

  // Real-time subscription to platform_settings changes
  useEffect(() => {
    const channel = supabase
      .channel('platform-settings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'platform_settings',
        },
        (payload) => {
          console.log('Platform settings changed:', payload);
          loadSettings(); // Reload on any change
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [loadSettings]);

  // Real-time subscription to user_settings changes
  useEffect(() => {
    if (!user?.id) return;

    const userSettingsChannel = supabase
      .channel('user-settings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_settings',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔄 User settings changed:', payload);
          loadSettings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(userSettingsChannel);
    };
  }, [user?.id, loadSettings]);

  const logActivity = useCallback((action: string, key: string, oldValue: any, newValue: any) => {
    const entry: ActivityLogEntry = {
      id: crypto.randomUUID(),
      timestamp: new Date(),
      action,
      key,
      oldValue,
      newValue,
      userId: user?.id || 'system',
    };
    setActivityLog(prev => [entry, ...prev].slice(0, 100)); // Keep last 100 entries
  }, [user?.id]);

  const updateSetting = useCallback((key: string, value: any) => {
    // Stage the change locally without saving
    setStagedSettings(prev => ({ ...prev, [key]: value }));
    setHasUnsavedChanges(true);
  }, []);

  const bulkUpdateSettings = useCallback((updates: Partial<PlatformSettings>) => {
    // Stage multiple changes locally
    setStagedSettings(prev => ({ ...prev, ...updates }));
    setHasUnsavedChanges(true);
  }, []);

  const saveAllChanges = useCallback(async () => {
    try {
      const changedKeys = Object.keys(stagedSettings).filter(
        key => stagedSettings[key as keyof PlatformSettings] !== settings[key as keyof PlatformSettings]
      );

      if (changedKeys.length === 0) {
        toast({
          title: 'No Changes',
          description: 'There are no changes to save',
        });
        return;
      }

      // Save all changed settings
      const promises = changedKeys.map(async (key) => {
        const value = stagedSettings[key as keyof PlatformSettings];
        const oldValue = settings[key as keyof PlatformSettings];

        const { error } = await supabase.rpc('update_platform_setting', {
          p_setting_key: key,
          p_setting_value: value,
        });

        if (error) throw error;

        logActivity('UPDATE', key, oldValue, value);
      });

      await Promise.all(promises);

      setSettings(stagedSettings);
      setHasUnsavedChanges(false);

      toast({
        title: 'Settings Saved',
        description: `Successfully saved ${changedKeys.length} setting${changedKeys.length > 1 ? 's' : ''}`,
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to save settings',
        variant: 'destructive',
      });
    }
  }, [stagedSettings, settings, user?.id, logActivity]);

  const discardChanges = useCallback(() => {
    setStagedSettings(settings);
    setHasUnsavedChanges(false);
    toast({
      title: 'Changes Discarded',
      description: 'All unsaved changes have been discarded',
    });
  }, [settings]);

  const reloadSettings = useCallback(async () => {
    await loadSettings();
  }, [loadSettings]);

  const undoLastChange = useCallback(async () => {
    if (activityLog.length === 0) {
      toast({
        title: 'Nothing to Undo',
        description: 'No recent changes to undo',
        variant: 'destructive',
      });
      return;
    }

    const lastEntry = activityLog[0];
    
    try {
      // Stage the old value
      updateSetting(lastEntry.key, lastEntry.oldValue);
      
      // Remove the undo entry from activity log
      setActivityLog(prev => prev.slice(1));
      
      toast({
        title: 'Change Undone',
        description: `Reverted ${lastEntry.key} to previous value (not saved yet)`,
      });
    } catch (error) {
      console.error('Error undoing change:', error);
      toast({
        title: 'Error',
        description: 'Failed to undo change',
        variant: 'destructive',
      });
    }
  }, [activityLog, updateSetting]);

  const resetToDefaults = useCallback(async () => {
    try {
      if (!user?.id) return;

      // Delete user-specific overrides to fall back to platform defaults
      const { error } = await supabase
        .from('user_settings')
        .delete()
        .eq('user_id', user.id);

      if (error) throw error;

      await loadSettings();
      
      logActivity('RESET', 'all', settings, {});
      
      toast({
        title: 'Settings Reset',
        description: 'All settings have been reset to defaults',
      });
    } catch (error) {
      console.error('Error resetting settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to reset settings',
        variant: 'destructive',
      });
    }
  }, [user?.id, loadSettings, settings, logActivity]);

  return (
    <PlatformSettingsContext.Provider
      value={{
        settings: stagedSettings,
        loading,
        updateSetting,
        bulkUpdateSettings,
        saveAllChanges,
        discardChanges,
        reloadSettings,
        resetToDefaults,
        undoLastChange,
        activityLog,
        canUndo: activityLog.length > 0,
        hasUnsavedChanges,
        stagedSettings,
      }}
    >
      {children}
    </PlatformSettingsContext.Provider>
  );
};

export const usePlatformSettings = () => {
  const context = useContext(PlatformSettingsContext);
  if (context === undefined) {
    throw new Error('usePlatformSettings must be used within PlatformSettingsProvider');
  }
  return context;
};
