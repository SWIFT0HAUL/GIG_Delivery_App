import React, { createContext, useContext, useState, ReactNode } from 'react';

interface SafeModeContextType {
  isSafeModeActive: boolean;
  toggleSafeMode: () => void;
  setSafeMode: (active: boolean) => void;
}

const SafeModeContext = createContext<SafeModeContextType | undefined>(undefined);

export const SafeModeProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isSafeModeActive, setIsSafeModeActive] = useState(false);

  const toggleSafeMode = () => {
    setIsSafeModeActive(prev => !prev);
  };

  const setSafeMode = (active: boolean) => {
    setIsSafeModeActive(active);
  };

  return (
    <SafeModeContext.Provider value={{ isSafeModeActive, toggleSafeMode, setSafeMode }}>
      {children}
    </SafeModeContext.Provider>
  );
};

export const useSafeMode = () => {
  const context = useContext(SafeModeContext);
  if (context === undefined) {
    throw new Error('useSafeMode must be used within a SafeModeProvider');
  }
  return context;
};
