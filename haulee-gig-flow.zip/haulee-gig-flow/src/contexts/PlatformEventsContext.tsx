import React, { createContext, useContext, useEffect, useCallback, ReactNode, useRef } from 'react';

type PlatformEventType = 
  | 'AUTH_SIGN_IN'
  | 'AUTH_SIGN_OUT'
  | 'AUTH_TOKEN_REFRESHED'
  | 'AUTH_PASSWORD_CHANGED'
  | 'AUTH_USER_DELETED'
  | 'AUTH_USER_UPDATED'
  | 'AUTH_SESSION_EXPIRED'
  | 'PROFILE_UPDATED'
  | 'ROLE_CHANGED'
  | 'PERMISSION_CHANGED'
  | 'USER_APPROVED'
  | 'USER_ACTIVATED'
  | 'USER_DEACTIVATED'
  | 'USER_BANNED'
  | 'NOTIFICATION_RECEIVED'
  | 'JOB_ASSIGNMENT_UPDATED'
  | 'JOB_STATUS_UPDATED'
  | 'CROSS_TAB_LOGOUT'
  | 'CROSS_TAB_ROLE_CHANGE'
  | 'FORCE_RELOAD';

interface PlatformEvent {
  type: PlatformEventType;
  payload?: any;
  timestamp: number;
  userId?: string;
}

type EventHandler = (event: PlatformEvent) => void;

interface PlatformEventsContextType {
  emit: (type: PlatformEventType, payload?: any) => void;
  subscribe: (type: PlatformEventType | PlatformEventType[], handler: EventHandler) => () => void;
}

const PlatformEventsContext = createContext<PlatformEventsContextType | undefined>(undefined);

export function usePlatformEvents() {
  const context = useContext(PlatformEventsContext);
  if (!context) {
    throw new Error('usePlatformEvents must be used within PlatformEventsProvider');
  }
  return context;
}

interface PlatformEventsProviderProps {
  children: ReactNode;
}

export function PlatformEventsProvider({ children }: PlatformEventsProviderProps) {
  const subscribers = useRef<Map<PlatformEventType, Set<EventHandler>>>(new Map());

  const emit = useCallback((type: PlatformEventType, payload?: any) => {
    const event: PlatformEvent = {
      type,
      payload,
      timestamp: Date.now(),
    };

    console.log('🔔 Platform Event:', type, payload);

    const handlers = subscribers.current.get(type);
    if (handlers) {
      handlers.forEach(handler => {
        try {
          handler(event);
        } catch (error) {
          console.error('Error in event handler:', error);
        }
      });
    }
  }, []);

  const subscribe = useCallback((types: PlatformEventType | PlatformEventType[], handler: EventHandler) => {
    const eventTypes = Array.isArray(types) ? types : [types];

    eventTypes.forEach(type => {
      if (!subscribers.current.has(type)) {
        subscribers.current.set(type, new Set());
      }
      subscribers.current.get(type)!.add(handler);
    });

    return () => {
      eventTypes.forEach(type => {
        const handlers = subscribers.current.get(type);
        if (handlers) {
          handlers.delete(handler);
          if (handlers.size === 0) {
            subscribers.current.delete(type);
          }
        }
      });
    };
  }, []);

  const value: PlatformEventsContextType = {
    emit,
    subscribe,
  };

  return (
    <PlatformEventsContext.Provider value={value}>
      {children}
    </PlatformEventsContext.Provider>
  );
}
