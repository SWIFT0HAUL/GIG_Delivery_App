/**
 * Calculate distance between two coordinates using Haversine formula
 * Returns distance in miles
 */
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

/**
 * Extract coordinates from job location object
 */
export function getJobCoordinates(location: any): { lat: number; lng: number } | null {
  if (!location) return null;
  
  // Try different possible coordinate formats
  if (location.coordinates) {
    return {
      lat: location.coordinates.lat || location.coordinates.latitude,
      lng: location.coordinates.lng || location.coordinates.longitude
    };
  }
  
  if (location.lat && location.lng) {
    return { lat: location.lat, lng: location.lng };
  }
  
  if (location.latitude && location.longitude) {
    return { lat: location.latitude, lng: location.longitude };
  }
  
  return null;
}

/**
 * Filter jobs by distance from driver location
 */
export function filterJobsByDistance(
  jobs: any[],
  driverLat: number,
  driverLng: number,
  maxDistanceMiles: number = 75
): any[] {
  return jobs.filter(job => {
    const pickupCoords = getJobCoordinates(job.pickup_location);
    
    if (!pickupCoords) {
      // If we can't determine coordinates, don't filter out (show all)
      return true;
    }
    
    const distance = calculateDistance(
      driverLat,
      driverLng,
      pickupCoords.lat,
      pickupCoords.lng
    );
    
    return distance <= maxDistanceMiles;
  });
}
