import { supabase } from "@/integrations/supabase/client";

export async function updateOnboarding(step: number, completed = false) {
  try {
    // Get current user
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      throw new Error("No authenticated user found");
    }

    // Use the database function to update onboarding progress
    const { data, error } = await supabase.rpc('update_onboarding_progress', {
      p_user_id: user.id,
      p_step_number: step,
      p_mark_complete: completed
    });

    if (error) {
      console.error("❌ Failed to update onboarding:", error);
      throw error;
    }

    console.log("✅ Onboarding updated successfully");
    return { success: true };
  } catch (error) {
    console.error("❌ Failed to update onboarding:", error);
    return { success: false, error };
  }
}

export async function getOnboardingStatus(userId?: string) {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    const targetUserId = userId || user?.id;
    
    if (!targetUserId) {
      throw new Error("No user ID provided");
    }

    const { data, error } = await supabase.rpc('get_comprehensive_onboarding_status', {
      p_user_id: targetUserId
    });

    if (error) {
      console.error("❌ Failed to get onboarding status:", error);
      throw error;
    }

    return { success: true, data };
  } catch (error) {
    console.error("❌ Failed to get onboarding status:", error);
    return { success: false, error };
  }
}

export async function saveOnboardingStep(
  stepNumber: number, 
  stepTitle: string, 
  stepData: Record<string, any>, 
  uploadedFiles: any[] = [],
  markComplete: boolean = true
) {
  try {
    const { data, error } = await supabase.rpc('save_onboarding_step', {
      p_step_number: stepNumber,
      p_step_title: stepTitle,
      p_step_data: stepData,
      p_uploaded_files: uploadedFiles,
      p_mark_complete: markComplete
    });

    if (error) {
      console.error("❌ Failed to save onboarding step:", error);
      throw error;
    }

    console.log("✅ Onboarding step saved successfully");
    return { success: true };
  } catch (error) {
    console.error("❌ Failed to save onboarding step:", error);
    return { success: false, error };
  }
}