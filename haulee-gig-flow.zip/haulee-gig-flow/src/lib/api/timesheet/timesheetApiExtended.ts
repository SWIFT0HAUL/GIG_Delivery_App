import { supabase } from '@/integrations/supabase/client';

const BASE_URL = 'https://cqoydkxlonzobykwjcin.supabase.co/functions/v1/timesheet-api';

// Get authorization headers
async function getAuthHeaders() {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    throw new Error('No active session');
  }

  return {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${session.access_token}`,
  };
}

export interface ClockInParams {
  user_id: string;
  task_id?: string;
  job_id?: string;
  job_stage?: string;
  mileage?: number;
}

export interface ClockOutParams {
  timesheet_id: string;
  mileage?: number;
  wait_time_minutes?: number;
  break_time_minutes?: number;
}

export interface ManualEntryParams {
  user_id: string;
  clock_in: string;
  clock_out: string;
  reason: string;
  notes?: string;
  task_id?: string;
  job_id?: string;
  job_stage?: string;
  mileage?: number;
  wait_time_minutes?: number;
  break_time_minutes?: number;
}

export interface JobStageTransitionParams {
  timesheet_id: string;
  new_stage: string;
  notes?: string;
}

export const TimesheetApiExtended = {
  // Clock in with job support
  async clockIn(params: ClockInParams) {
    const headers = await getAuthHeaders();
    const response = await fetch(`${BASE_URL}/clock-in`, {
      method: 'POST',
      headers,
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to clock in');
    }

    return response.json();
  },

  // Clock out with additional tracking
  async clockOut(params: ClockOutParams) {
    const headers = await getAuthHeaders();
    const response = await fetch(`${BASE_URL}/clock-out`, {
      method: 'POST',
      headers,
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to clock out');
    }

    return response.json();
  },

  // Create manual entry with job support
  async createManualEntry(params: ManualEntryParams) {
    const headers = await getAuthHeaders();
    const response = await fetch(`${BASE_URL}/manual-entry`, {
      method: 'POST',
      headers,
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to create manual entry');
    }

    return response.json();
  },

  // Transition job stage
  async transitionJobStage(params: JobStageTransitionParams) {
    const headers = await getAuthHeaders();
    const response = await fetch(`${BASE_URL}/job-stage-transition`, {
      method: 'POST',
      headers,
      body: JSON.stringify(params),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'Failed to transition job stage');
    }

    return response.json();
  },

  // Get timesheet by job
  async getTimesheetByJob(jobId: string) {
    const { data, error } = await supabase
      .from('timesheets')
      .select('*')
      .eq('job_id', jobId)
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (error) throw error;
    return data;
  },

  // Get job stages for timesheet
  async getJobStages(timesheetId: string) {
    const { data, error } = await supabase
      .from('timesheet_job_stages')
      .select('*')
      .eq('timesheet_id', timesheetId)
      .order('started_at', { ascending: true });

    if (error) throw error;
    return data;
  },

  // Get timesheets by role
  async getTimesheetsByRole(roleKey: string, startDate?: string, endDate?: string) {
    let query = supabase
      .from('timesheets')
      .select('*')
      .eq('role_key', roleKey)
      .order('clock_in', { ascending: false });

    if (startDate) {
      query = query.gte('clock_in', startDate);
    }
    if (endDate) {
      query = query.lte('clock_in', endDate);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Get user timesheets
  async getUserTimesheets(userId: string, startDate?: string, endDate?: string) {
    let query = supabase
      .from('timesheets')
      .select('*')
      .or(`user_id.eq.${userId},admin_id.eq.${userId}`)
      .order('clock_in', { ascending: false });

    if (startDate) {
      query = query.gte('clock_in', startDate);
    }
    if (endDate) {
      query = query.lte('clock_in', endDate);
    }

    const { data, error } = await query;
    if (error) throw error;
    return data;
  },

  // Check active session
  async hasActiveSession(userId: string) {
    const { data, error } = await supabase
      .from('timesheets')
      .select('id')
      .or(`user_id.eq.${userId},admin_id.eq.${userId}`)
      .is('clock_out', null)
      .limit(1);

    if (error) throw error;
    return data && data.length > 0;
  },

  // Get active session
  async getActiveSession(userId: string) {
    const { data, error } = await supabase
      .from('timesheets')
      .select('*')
      .or(`user_id.eq.${userId},admin_id.eq.${userId}`)
      .is('clock_out', null)
      .order('clock_in', { ascending: false })
      .limit(1)
      .single();

    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },
};