import { supabase } from '@/integrations/supabase/client';

export type TaskCategory = 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly';
export type TaskStatus = 'pending' | 'in_progress' | 'completed' | 'overdue';
export type TaskPriority = 'low' | 'medium' | 'high' | 'critical';
export type TaskRole = 'admin' | 'super_admin';

export interface AdminTask {
  id: string;
  title: string;
  description: string | null;
  category: TaskCategory;
  assigned_to: string | null;
  assigned_role: TaskRole;
  due_date: string;
  frequency: TaskCategory;
  status: TaskStatus;
  priority: TaskPriority;
  auto_generated: boolean;
  template_id: string | null;
  metadata: any;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
  completed_by: string | null;
  assigned_user?: {
    id: string;
    full_name: string | null;
    email: string;
  };
}

export interface AdminTaskLog {
  id: string;
  task_id: string;
  changed_by: string | null;
  old_status: TaskStatus | null;
  new_status: TaskStatus | null;
  note: string | null;
  metadata: any;
  created_at: string;
  changed_by_user?: {
    full_name: string | null;
    email: string;
  };
}

export interface AdminTaskTemplate {
  id: string;
  title: string;
  description: string | null;
  category: TaskCategory;
  assigned_role: TaskRole;
  priority: TaskPriority;
  frequency: TaskCategory;
  is_active: boolean;
  auto_assign: boolean;
  metadata: any;
  created_at: string;
  updated_at: string;
}

export interface TaskFilters {
  category?: TaskCategory;
  status?: TaskStatus;
  priority?: TaskPriority;
  assigned_role?: TaskRole;
  assigned_to?: string;
  date_from?: string;
  date_to?: string;
  auto_generated?: boolean;
}

export interface TaskStats {
  total: number;
  pending: number;
  in_progress: number;
  completed: number;
  overdue: number;
  due_today: number;
  high_priority: number;
}

// Fetch tasks with filters
export const fetchTasks = async (filters?: TaskFilters): Promise<AdminTask[]> => {
  let query = supabase
    .from('admin_tasks')
    .select(`
      *,
      assigned_user:profiles!admin_tasks_assigned_to_fkey(id, full_name, email)
    `)
    .order('due_date', { ascending: true });

  if (filters?.category) {
    query = query.eq('category', filters.category);
  }
  if (filters?.status) {
    query = query.eq('status', filters.status);
  }
  if (filters?.priority) {
    query = query.eq('priority', filters.priority);
  }
  if (filters?.assigned_role) {
    query = query.eq('assigned_role', filters.assigned_role);
  }
  if (filters?.assigned_to) {
    query = query.eq('assigned_to', filters.assigned_to);
  }
  if (filters?.date_from) {
    query = query.gte('due_date', filters.date_from);
  }
  if (filters?.date_to) {
    query = query.lte('due_date', filters.date_to);
  }
  if (filters?.auto_generated !== undefined) {
    query = query.eq('auto_generated', filters.auto_generated);
  }

  const { data, error } = await query;
  
  if (error) throw error;
  return data || [];
};

// Fetch single task
export const fetchTaskById = async (taskId: string): Promise<AdminTask | null> => {
  const { data, error } = await supabase
    .from('admin_tasks')
    .select(`
      *,
      assigned_user:profiles!admin_tasks_assigned_to_fkey(id, full_name, email)
    `)
    .eq('id', taskId)
    .single();

  if (error) throw error;
  return data;
};

// Fetch task logs
export const fetchTaskLogs = async (taskId: string): Promise<AdminTaskLog[]> => {
  const { data, error } = await supabase
    .from('admin_task_logs')
    .select(`
      *,
      changed_by_user:profiles!admin_task_logs_changed_by_fkey(full_name, email)
    `)
    .eq('task_id', taskId)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data || [];
};

// Update task status
export const updateTaskStatus = async (
  taskId: string,
  status: TaskStatus,
  note?: string
): Promise<void> => {
  const { error } = await supabase
    .from('admin_tasks')
    .update({ status })
    .eq('id', taskId);

  if (error) throw error;

  // Add note if provided
  if (note) {
    await addTaskNote(taskId, note);
  }
};

// Add task note
export const addTaskNote = async (taskId: string, note: string): Promise<void> => {
  const { error } = await supabase
    .from('admin_task_logs')
    .insert({
      task_id: taskId,
      note,
      metadata: {}
    });

  if (error) throw error;
};

// Create manual task
export const createTask = async (task: Partial<AdminTask>): Promise<AdminTask> => {
  const { data, error } = await supabase
    .from('admin_tasks')
    .insert({
      title: task.title,
      description: task.description,
      category: task.category,
      assigned_to: task.assigned_to,
      assigned_role: task.assigned_role,
      due_date: task.due_date,
      frequency: task.frequency || task.category,
      status: task.status || 'pending',
      priority: task.priority || 'medium',
      auto_generated: false,
      metadata: task.metadata || {}
    })
    .select()
    .single();

  if (error) throw error;
  return data;
};

// Reassign task (super admin only)
export const reassignTask = async (taskId: string, newAssigneeId: string): Promise<void> => {
  const { error } = await supabase
    .from('admin_tasks')
    .update({ assigned_to: newAssigneeId })
    .eq('id', taskId);

  if (error) throw error;
};

// Delete task (super admin only)
export const deleteTask = async (taskId: string): Promise<void> => {
  const { error } = await supabase
    .from('admin_tasks')
    .delete()
    .eq('id', taskId);

  if (error) throw error;
};

// Fetch task stats
export const fetchTaskStats = async (userId?: string): Promise<TaskStats> => {
  let query = supabase.from('admin_tasks').select('status, due_date, priority');

  if (userId) {
    query = query.eq('assigned_to', userId);
  }

  const { data, error } = await query;

  if (error) throw error;

  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const stats: TaskStats = {
    total: data?.length || 0,
    pending: 0,
    in_progress: 0,
    completed: 0,
    overdue: 0,
    due_today: 0,
    high_priority: 0
  };

  data?.forEach(task => {
    if (task.status === 'pending') stats.pending++;
    if (task.status === 'in_progress') stats.in_progress++;
    if (task.status === 'completed') stats.completed++;
    if (task.status === 'overdue') stats.overdue++;
    if (task.priority === 'high' || task.priority === 'critical') stats.high_priority++;
    
    const dueDate = new Date(task.due_date);
    if (dueDate >= today && dueDate < new Date(today.getTime() + 24 * 60 * 60 * 1000)) {
      stats.due_today++;
    }
  });

  return stats;
};

// Template management (super admin only)
export const fetchTemplates = async (): Promise<AdminTaskTemplate[]> => {
  const { data, error } = await supabase
    .from('admin_task_templates')
    .select('*')
    .order('category', { ascending: true })
    .order('priority', { ascending: false });

  if (error) throw error;
  return data || [];
};

export const createTemplate = async (template: Partial<AdminTaskTemplate>): Promise<AdminTaskTemplate> => {
  const { data, error } = await supabase
    .from('admin_task_templates')
    .insert(template as any)
    .select()
    .single();

  if (error) throw error;
  return data;
};

export const updateTemplate = async (id: string, updates: Partial<AdminTaskTemplate>): Promise<void> => {
  const { error } = await supabase
    .from('admin_task_templates')
    .update(updates)
    .eq('id', id);

  if (error) throw error;
};

export const deleteTemplate = async (id: string): Promise<void> => {
  const { error } = await supabase
    .from('admin_task_templates')
    .delete()
    .eq('id', id);

  if (error) throw error;
};
