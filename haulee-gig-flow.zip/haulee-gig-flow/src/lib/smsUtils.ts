/**
 * Generate a random verification code
 * @param length - Length of the code (default: 6)
 * @returns A numeric verification code as a string
 */
export function generateVerificationCode(length: number = 6): string {
  const min = Math.pow(10, length - 1);
  const max = Math.pow(10, length) - 1;
  return Math.floor(Math.random() * (max - min + 1) + min).toString();
}

/**
 * Format phone number to E.164 format
 * @param phone - Phone number in any format
 * @param countryCode - Country code (default: '1' for US)
 * @returns Formatted phone number with + prefix
 */
export function formatPhoneNumber(phone: string, countryCode: string = '1'): string {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  // Add country code if needed
  let formatted = digits;
  if (digits.length === 10 && !digits.startsWith(countryCode)) {
    formatted = countryCode + digits;
  }
  
  // Add + prefix
  if (!formatted.startsWith('+')) {
    formatted = '+' + formatted;
  }
  
  return formatted;
}

/**
 * Validate phone number format
 * @param phone - Phone number to validate
 * @returns True if valid, false otherwise
 */
export function isValidPhoneNumber(phone: string): boolean {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  // Check if it's a valid length (10 digits for US, or 11 with country code)
  return digits.length === 10 || digits.length === 11;
}

/**
 * Store verification code with expiration
 * @param phoneNumber - Phone number
 * @param code - Verification code
 * @param expirationMinutes - Expiration time in minutes (default: 10)
 */
export function storeVerificationCode(
  phoneNumber: string, 
  code: string, 
  expirationMinutes: number = 10
): void {
  const data = {
    code,
    expiresAt: Date.now() + expirationMinutes * 60 * 1000,
  };
  localStorage.setItem(`sms_verification_${phoneNumber}`, JSON.stringify(data));
}

/**
 * Verify stored verification code
 * @param phoneNumber - Phone number
 * @param code - Code to verify
 * @returns True if code is valid and not expired
 */
export function verifyStoredCode(phoneNumber: string, code: string): boolean {
  const stored = localStorage.getItem(`sms_verification_${phoneNumber}`);
  if (!stored) return false;
  
  try {
    const data = JSON.parse(stored);
    
    // Check if expired
    if (Date.now() > data.expiresAt) {
      localStorage.removeItem(`sms_verification_${phoneNumber}`);
      return false;
    }
    
    // Verify code
    if (data.code === code) {
      localStorage.removeItem(`sms_verification_${phoneNumber}`);
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Error verifying code:', error);
    return false;
  }
}

/**
 * Clear expired verification codes from localStorage
 */
export function clearExpiredCodes(): void {
  const keys = Object.keys(localStorage);
  const now = Date.now();
  
  keys.forEach(key => {
    if (key.startsWith('sms_verification_')) {
      try {
        const data = JSON.parse(localStorage.getItem(key) || '{}');
        if (data.expiresAt && now > data.expiresAt) {
          localStorage.removeItem(key);
        }
      } catch (error) {
        // Invalid data, remove it
        localStorage.removeItem(key);
      }
    }
  });
}
