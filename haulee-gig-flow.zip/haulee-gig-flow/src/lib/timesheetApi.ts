/**
 * Timesheet API Client
 * Centralized API calls for timesheet operations
 */

import { supabase } from '@/integrations/supabase/client';

const BASE_URL = 'https://cqoydkxlonzobykwjcin.supabase.co/functions/v1/timesheet-api';

/**
 * Get authorization header with current session token
 */
const getAuthHeaders = async () => {
  const { data: { session } } = await supabase.auth.getSession();
  if (!session) {
    throw new Error('No active session');
  }
  
  return {
    'Authorization': `Bearer ${session.access_token}`,
    'Content-Type': 'application/json',
  };
};

/**
 * Clock in to start a new timesheet session
 */
export const clockIn = async (adminId: string, taskId?: string) => {
  const headers = await getAuthHeaders();
  
  const response = await fetch(`${BASE_URL}/clock-in`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      admin_id: adminId,
      task_id: taskId,
    }),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to clock in');
  }
  
  return await response.json();
};

/**
 * Clock out to end an active timesheet session
 */
export const clockOut = async (timesheetId: string) => {
  const headers = await getAuthHeaders();
  
  const response = await fetch(`${BASE_URL}/clock-out`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      timesheet_id: timesheetId,
    }),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to clock out');
  }
  
  return await response.json();
};

/**
 * Create a manual timesheet entry
 */
export const createManualEntry = async (params: {
  adminId: string;
  clockIn: string;
  clockOut: string;
  reason: string;
  notes?: string;
  taskId?: string;
}) => {
  const headers = await getAuthHeaders();
  
  const response = await fetch(`${BASE_URL}/manual-entry`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      admin_id: params.adminId,
      clock_in: params.clockIn,
      clock_out: params.clockOut,
      reason: params.reason,
      notes: params.notes,
      task_id: params.taskId,
    }),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to create manual entry');
  }
  
  return await response.json();
};

/**
 * Approve or reject a timesheet entry (Super Admin only)
 */
export const approveTimesheet = async (
  timesheetId: string,
  action: 'approve' | 'reject',
  rejectionReason?: string
) => {
  const headers = await getAuthHeaders();
  
  const response = await fetch(`${BASE_URL}/approve`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      timesheet_id: timesheetId,
      action,
      rejection_reason: rejectionReason,
    }),
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to process approval');
  }
  
  return await response.json();
};

/**
 * Generate a timesheet report
 */
export const generateReport = async (params?: {
  startDate?: string;
  endDate?: string;
  adminId?: string;
}) => {
  const headers = await getAuthHeaders();
  
  const url = new URL(`${BASE_URL}/report`);
  if (params?.startDate) {
    url.searchParams.append('start_date', params.startDate);
  }
  if (params?.endDate) {
    url.searchParams.append('end_date', params.endDate);
  }
  if (params?.adminId) {
    url.searchParams.append('admin_id', params.adminId);
  }
  
  const response = await fetch(url.toString(), {
    method: 'GET',
    headers,
  });
  
  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.error || 'Failed to generate report');
  }
  
  return await response.json();
};

/**
 * Export types for API responses
 */
export interface TimesheetResponse {
  success: boolean;
  timesheet: {
    id: string;
    admin_id: string;
    clock_in: string;
    clock_out?: string;
    total_duration?: number;
    status: string;
    manual_entry: boolean;
    approved_by?: string;
    approved_at?: string;
  };
}

export interface ReportResponse {
  success: boolean;
  report: {
    timesheets: Array<any>;
    summary: {
      total_hours: number;
      overtime_hours: number;
      pending_count: number;
      total_entries: number;
    };
  };
}