// Application configuration
// Use environment variables for domain-aware URLs

export const config = {
  // Base URL - defaults to localhost in development
  baseUrl: import.meta.env.VITE_BASE_URL || 'http://localhost:8080',
  
  // Supabase configuration
  supabase: {
    url: import.meta.env.VITE_SUPABASE_URL || 'https://qjepietehdcvarrogqyy.supabase.co',
    anonKey: import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFqZXBpZXRlaGRjdmFycm9ncXl5Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk2NzY4NzQsImV4cCI6MjA3NTI1Mjg3NH0.EUiUgSH-6GDr15-swRtlyPrbsuXpfGL-xpB0IqJQWDY',
  },
  
  // Auth redirect URLs
  auth: {
    redirectTo: `${import.meta.env.VITE_BASE_URL || 'http://localhost:8080'}/auth/callback`,
    emailRedirectTo: `${import.meta.env.VITE_BASE_URL || 'http://localhost:8080'}/`,
  },
  
  // API endpoints
  api: {
    webhook: `${import.meta.env.VITE_BASE_URL || 'http://localhost:8080'}/webhook`,
  },
};

// Helper function to get absolute URL
export const getAbsoluteUrl = (path: string = ''): string => {
  const base = config.baseUrl.replace(/\/$/, '');
  const cleanPath = path.replace(/^\//, '');
  return cleanPath ? `${base}/${cleanPath}` : base;
};
