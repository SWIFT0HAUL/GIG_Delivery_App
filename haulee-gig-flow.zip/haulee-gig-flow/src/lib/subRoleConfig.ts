export interface SubRoleOption {
  value: string;
  label: string;
}

export const SUB_ROLE_CONFIG: Record<string, SubRoleOption[]> = {
  admin: [
    { value: 'technical_admin', label: 'Technical Admin / IT Administrator' },
    { value: 'operations_manager', label: 'Operations Manager' },
    { value: 'business_associate', label: 'Business Associate' },
    { value: 'account_manager', label: 'Account Manager' },
    { value: 'finance_manager', label: 'Finance Manager' },
    { value: 'hr_officer', label: 'HR / User Management Officer' },
    { value: 'task_coordinator', label: 'Task Coordinator' },
    { value: 'platform_engineer', label: 'Developer / Platform Engineer' },
    { value: 'data_analyst', label: 'Data Analyst / Reporting Officer' },
    { value: 'system_auditor', label: 'System Auditor / Security Analyst' }
  ],
  super_admin: [
    { value: 'technical_admin', label: 'Technical Admin / IT Administrator' },
    { value: 'platform_engineer', label: 'Developer / Platform Engineer' },
    { value: 'system_auditor', label: 'System Auditor / Security Analyst' }
  ],
  vendor_merchant: [
    { value: 'vendor_merchant', label: 'Vendor / Merchant' },
    { value: 'business_associate', label: 'Business Associate' }
  ],
  shipper: [
    { value: 'shipper', label: 'Shipper' },
    { value: 'account_manager', label: 'Account Manager' }
  ],
  broker: [
    { value: 'broker', label: 'Broker' },
    { value: 'account_manager', label: 'Account Manager' }
  ],
  driver: [
    { value: 'independent_driver', label: 'Independent Driver' },
    { value: 'carrier_driver', label: 'Carrier Driver' },
    { value: 'driver_support', label: 'Driver Support' }
  ],
  carrier: [
    { value: 'carrier', label: 'Carrier' },
    { value: 'operations_manager', label: 'Operations Manager' }
  ]
};

export const ALL_SUB_ROLES: SubRoleOption[] = [
  { value: 'technical_admin', label: 'Technical Admin / IT Administrator' },
  { value: 'it_administrator', label: 'IT Administrator' },
  { value: 'operations_manager', label: 'Operations Manager' },
  { value: 'business_associate', label: 'Business Associate' },
  { value: 'account_manager', label: 'Account Manager' },
  { value: 'vendor_merchant', label: 'Vendor / Merchant' },
  { value: 'shipper', label: 'Shipper' },
  { value: 'broker', label: 'Broker' },
  { value: 'carrier', label: 'Carrier' },
  { value: 'independent_driver', label: 'Independent Driver' },
  { value: 'carrier_driver', label: 'Carrier Driver' },
  { value: 'finance_manager', label: 'Finance Manager' },
  { value: 'accountant', label: 'Accountant / Accounting Officer' },
  { value: 'payroll_officer', label: 'Payroll Officer' },
  { value: 'auditor', label: 'Auditor' },
  { value: 'compliance_officer', label: 'Compliance Officer' },
  { value: 'legal_advisor', label: 'Legal Advisor / Corporate Counsel' },
  { value: 'hr_officer', label: 'HR / User Management Officer' },
  { value: 'recruitment_officer', label: 'Recruitment Officer' },
  { value: 'task_coordinator', label: 'Task Coordinator' },
  { value: 'driver_support', label: 'Driver Support' },
  { value: 'platform_engineer', label: 'Developer / Platform Engineer' },
  { value: 'data_analyst', label: 'Data Analyst / Reporting Officer' },
  { value: 'system_auditor', label: 'System Auditor / Security Analyst' }
];

export function getSubRolesForRole(role: string): SubRoleOption[] {
  return SUB_ROLE_CONFIG[role] || [];
}

export function getSubRoleLabel(subRole: string | null): string {
  if (!subRole) return '';
  const found = ALL_SUB_ROLES.find(sr => sr.value === subRole);
  return found ? found.label : subRole;
}
