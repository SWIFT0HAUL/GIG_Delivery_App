import { supabase } from '@/integrations/supabase/client';
import { GeocodeResult } from './geocoding';

/**
 * Extended address data for comprehensive storage
 */
export interface StoredAddress extends GeocodeResult {
  street_number?: string;
  apt_suite?: string;
  city?: string;
  state?: string;
  zip?: string;
  postal_code?: string;
}

/**
 * Update user profile address
 */
export async function updateProfileAddress(
  userId: string,
  address: GeocodeResult
): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update({
      full_address: address.address,
      address_lat: address.lat,
      address_lng: address.lng,
    })
    .eq('id', userId);

  if (error) {
    throw new Error(`Failed to update profile address: ${error.message}`);
  }
}

/**
 * Get user profile address
 */
export async function getProfileAddress(
  userId: string
): Promise<GeocodeResult | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('full_address, address_lat, address_lng')
    .eq('id', userId)
    .single();

  if (error) {
    throw new Error(`Failed to get profile address: ${error.message}`);
  }

  if (!data?.full_address || !data?.address_lat || !data?.address_lng) {
    return null;
  }

  return {
    address: data.full_address,
    lat: Number(data.address_lat),
    lng: Number(data.address_lng),
  };
}

/**
 * Create job location object for pickup or delivery
 */
export function createJobLocation(address: StoredAddress): object {
  return {
    full_address: address.address,
    lat: address.lat,
    lng: address.lng,
    street_number: address.street_number,
    apt_suite: address.apt_suite,
    city: address.city,
    state: address.state,
    zip: address.zip || address.postal_code,
  };
}

/**
 * Update job pickup location
 */
export async function updateJobPickupLocation(
  jobId: string,
  address: StoredAddress
): Promise<void> {
  const location = createJobLocation(address);

  const { error } = await supabase
    .from('jobs')
    .update({ pickup_location: location as any })
    .eq('id', jobId);

  if (error) {
    throw new Error(`Failed to update pickup location: ${error.message}`);
  }
}

/**
 * Update job delivery location
 */
export async function updateJobDeliveryLocation(
  jobId: string,
  address: StoredAddress
): Promise<void> {
  const location = createJobLocation(address);

  const { error } = await supabase
    .from('jobs')
    .update({ delivery_location: location as any })
    .eq('id', jobId);

  if (error) {
    throw new Error(`Failed to update delivery location: ${error.message}`);
  }
}

/**
 * Extract coordinates from job location
 */
export function extractCoordinates(location: any): { lat: number; lng: number } | null {
  if (!location?.lat || !location?.lng) {
    return null;
  }

  return {
    lat: Number(location.lat),
    lng: Number(location.lng),
  };
}
