/**
 * Duration utilities for job duration calculations and display
 * 
 * The estimated_duration in the database is the single source of truth.
 * It's calculated from Google Maps Directions API and stored in minutes.
 */

/**
 * Get job duration in minutes.
 * Falls back to distance-based estimate only if no duration is stored.
 * 
 * @param estimatedDuration - Duration from database (minutes)
 * @param distanceMiles - Distance in miles (optional, for fallback only)
 * @returns Duration in minutes
 */
export function getJobDuration(
  estimatedDuration?: number | null,
  distanceMiles?: number | null
): number {
  // Use database value if available (single source of truth)
  if (estimatedDuration != null && estimatedDuration > 0) {
    return Math.round(estimatedDuration);
  }

  // Fallback: estimate from distance using 55 mph average
  if (distanceMiles != null && distanceMiles > 0) {
    return Math.round((distanceMiles / 55) * 60);
  }

  // No data available
  return 0;
}

/**
 * Format duration for display
 * 
 * @param minutes - Duration in minutes
 * @returns Formatted string (e.g., "1h 30m", "45m", "2h")
 */
export function formatDuration(minutes: number): string {
  if (minutes <= 0) return 'N/A';
  
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);

  if (hours === 0) {
    return `${mins}m`;
  } else if (mins === 0) {
    return `${hours}h`;
  } else {
    return `${hours}h ${mins}m`;
  }
}

/**
 * Calculate average speed from duration and distance
 * 
 * @param durationMinutes - Duration in minutes
 * @param distanceMiles - Distance in miles
 * @returns Speed in mph, or null if calculation not possible
 */
export function calculateAverageSpeed(
  durationMinutes?: number | null,
  distanceMiles?: number | null
): number | null {
  if (
    durationMinutes == null ||
    distanceMiles == null ||
    durationMinutes <= 0 ||
    distanceMiles <= 0
  ) {
    return null;
  }

  const mph = (distanceMiles * 60) / durationMinutes;
  return Math.round(mph);
}
