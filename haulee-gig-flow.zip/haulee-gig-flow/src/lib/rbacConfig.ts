/**
 * RBAC Configuration
 * Central configuration for all permission keys used across the platform
 */

export const PERMISSIONS = {
  // Job Permissions
  JOB: {
    // Create
    CREATE: 'job.create',
    
    // View (scope-based)
    VIEW_OWN: 'job.view.own',
    VIEW_ALL: 'job.view.all',
    VIEW_ASSIGNED: 'job.view.assigned',
    
    // Edit / Update
    EDIT_OWN: 'job.edit.own',
    EDIT_ALL: 'job.edit.all',
    
    // Assign / Claim
    ASSIGN: 'job.assign',
    CLAIM: 'job.claim',
    
    // Status Update
    STATUS_UPDATE: 'job.status.update',
    STATUS_COMPLETE: 'job.status.complete',
    STATUS_CANCEL: 'job.status.cancel',
    
    // Delete
    DELETE_OWN: 'job.delete.own',
    DELETE_ALL: 'job.delete.all',
    
    // Export / Reports
    EXPORT: 'job.export',
    REPORTS: 'job.reports',
    
    // Audit / History View
    AUDIT_VIEW: 'job.audit.view',
    HISTORY_VIEW: 'job.history.view',
  },
  
  // User Permissions
  USER: {
    VIEW_ALL: 'user.view.all',
    VIEW_OWN: 'user.view.own',
    EDIT_ALL: 'user.edit.all',
    EDIT_OWN: 'user.edit.own',
    DELETE: 'user.delete',
    APPROVE: 'user.approve',
    ACTIVATE: 'user.activate',
    ASSIGN_ROLE: 'user.assign_role',
    MESSAGE: 'user.message',
  },
  
  // Document Permissions
  DOCUMENT: {
    UPLOAD_OWN: 'document.upload.own',
    VIEW_OWN: 'document.view.own',
    VIEW_ALL: 'document.view.all',
    REVIEW: 'document.review',
    DELETE_OWN: 'document.delete.own',
    DELETE_ALL: 'document.delete.all',
  },
  
  // Financial Permissions
  FINANCIAL: {
    VIEW_OWN: 'financial.view.own',
    VIEW_ALL: 'financial.view.all',
    PROCESS_PAYMENT: 'financial.process_payment',
    APPROVE_PAYOUT: 'financial.approve_payout',
    EXPORT: 'financial.export',
    DISPUTE: 'financial.dispute',
  },
  
  // Dashboard & Settings Permissions
  DASHBOARD: {
    ADMIN: 'dashboard.admin',
    ANALYTICS: 'dashboard.analytics',
  },
  
  SETTINGS: {
    PLATFORM: 'settings.platform',
    ROLES: 'settings.roles',
  },
  
  // Audit & System Permissions
  AUDIT: {
    VIEW: 'audit.view',
  },
  
  NOTIFICATION: {
    SEND: 'notification.send',
  },
} as const;

export const RESOURCES = {
  JOB: 'job',
  USER: 'user',
  DOCUMENT: 'document',
  FINANCIAL: 'financial',
  DASHBOARD: 'dashboard',
} as const;

export const ACTIONS = {
  CREATE: 'create',
  READ: 'read',
  UPDATE: 'update',
  DELETE: 'delete',
  APPROVE: 'approve',
  EXPORT: 'export',
} as const;

/**
 * Permission groups for common scenarios
 */
export const PERMISSION_GROUPS = {
  ADMIN_FULL: [
    PERMISSIONS.USER.VIEW_ALL,
    PERMISSIONS.USER.EDIT_ALL,
    PERMISSIONS.USER.APPROVE,
    PERMISSIONS.USER.ACTIVATE,
    PERMISSIONS.JOB.VIEW_ALL,
    PERMISSIONS.JOB.EDIT_ALL,
    PERMISSIONS.DOCUMENT.VIEW_ALL,
    PERMISSIONS.DOCUMENT.REVIEW,
    PERMISSIONS.FINANCIAL.VIEW_ALL,
    PERMISSIONS.DASHBOARD.ADMIN,
  ],
  
  JOB_POSTER: [
    PERMISSIONS.JOB.CREATE,
    PERMISSIONS.JOB.VIEW_OWN,
    PERMISSIONS.JOB.EDIT_OWN,
    PERMISSIONS.JOB.DELETE_OWN,
  ],
  
  JOB_WORKER: [
    PERMISSIONS.JOB.VIEW_ALL,
    PERMISSIONS.JOB.CLAIM,
    PERMISSIONS.JOB.STATUS_COMPLETE,
  ],
  
  SELF_SERVICE: [
    PERMISSIONS.USER.VIEW_OWN,
    PERMISSIONS.USER.EDIT_OWN,
    PERMISSIONS.DOCUMENT.UPLOAD_OWN,
    PERMISSIONS.DOCUMENT.VIEW_OWN,
    PERMISSIONS.FINANCIAL.VIEW_OWN,
  ],
} as const;

/**
 * Helper to check if a user should have access based on multiple permission checks
 */
export const checkPermissionAccess = (
  userPermissions: string[],
  requiredPermissions: string[],
  requireAll = false
): boolean => {
  if (requireAll) {
    return requiredPermissions.every(p => userPermissions.includes(p));
  }
  return requiredPermissions.some(p => userPermissions.includes(p));
};
