import { supabase } from "@/integrations/supabase/client";

export interface TaskFormSchema {
  layout?: { columns?: number };
  fields: Array<{
    label: string;
    name: string;
    type: "text" | "number" | "textarea" | "select" | "checkbox" | "date" | "file" | "link";
    required?: boolean;
    options?: string[];
    placeholder?: string;
    url?: string;
  }>;
}

/**
 * Fetch a task by ID
 */
export async function fetchTask(taskId: string) {
  const { data, error } = await supabase
    .from("tasks" as any)
    .select("*")
    .eq("id", taskId)
    .single();

  if (error) throw error;
  return data;
}

/**
 * Fetch all task responses for a specific task and user
 */
export async function fetchTaskResponses(taskId: string, userId: string) {
  const { data, error } = await supabase
    .from("task_responses" as any)
    .select("*")
    .eq("task_id", taskId)
    .eq("user_id", userId);

  if (error) throw error;
  return data;
}

/**
 * Upsert a task response
 */
export async function upsertTaskResponse(
  taskId: string,
  userId: string,
  fieldName: string,
  fieldLabel: string,
  fieldType: string,
  fieldValue: string,
  uploadedFileUrl?: string
) {
  const { error } = await supabase.from("task_responses" as any).upsert(
    {
      task_id: taskId,
      user_id: userId,
      field_name: fieldName,
      field_label: fieldLabel,
      field_type: fieldType,
      field_value: fieldValue,
      uploaded_file_url: uploadedFileUrl,
      updated_at: new Date().toISOString(),
    },
    {
      onConflict: "task_id,user_id,field_name",
    }
  );

  if (error) throw error;
}

/**
 * Upload a file to task_uploads bucket
 */
export async function uploadTaskFile(
  taskId: string,
  userId: string,
  fieldName: string,
  file: File
) {
  const fileExt = file.name.split(".").pop();
  const fileName = `${fieldName}_${Date.now()}.${fileExt}`;
  const filePath = `${taskId}/${userId}/${fileName}`;

  const { error: uploadError } = await supabase.storage
    .from("task_uploads")
    .upload(filePath, file, {
      cacheControl: "3600",
      upsert: false,
    });

  if (uploadError) throw uploadError;

  const { data } = supabase.storage
    .from("task_uploads")
    .getPublicUrl(filePath);

  return data.publicUrl;
}

/**
 * Mark task as completed
 */
export async function completeTask(taskId: string) {
  const { error } = await supabase
    .from("tasks" as any)
    .update({
      status: "Completed",
      updated_at: new Date().toISOString(),
    })
    .eq("id", taskId);

  if (error) throw error;
}

/**
 * Sample form schemas for different roles
 */
export const SAMPLE_SCHEMAS: Record<string, TaskFormSchema> = {
  driver_vehicle: {
    layout: { columns: 2 },
    fields: [
      { label: "Vehicle Make", name: "vehicle_make", type: "text", required: true },
      { label: "Vehicle Model", name: "vehicle_model", type: "text", required: true },
      { label: "Year", name: "vehicle_year", type: "number", required: true },
      { label: "License Plate", name: "license_plate", type: "text", required: true },
      { label: "VIN", name: "vin", type: "text", required: true },
      { label: "Registration (PDF/Image)", name: "registration_doc", type: "file", required: true },
      { label: "Insurance Certificate", name: "insurance_doc", type: "file", required: true },
    ],
  },
  driver_license: {
    layout: { columns: 2 },
    fields: [
      { label: "Driver License Number", name: "license_number", type: "text", required: true },
      { label: "License State", name: "license_state", type: "text", required: true },
      { label: "License Expiration Date", name: "license_expiry", type: "date", required: true },
      { label: "Upload License Front", name: "license_front", type: "file", required: true },
      { label: "Upload License Back", name: "license_back", type: "file", required: true },
      { label: "Agree to Terms", name: "agree_terms", type: "checkbox", required: true },
    ],
  },
  shipper_business: {
    layout: { columns: 2 },
    fields: [
      { label: "Business Name", name: "business_name", type: "text", required: true },
      { label: "Tax ID (EIN)", name: "ein", type: "text", required: true },
      { label: "Business Address", name: "business_address", type: "textarea", required: true },
      { label: "Phone Number", name: "phone", type: "text", required: true },
      { label: "Upload W-9", name: "w9", type: "file", required: true },
      { label: "Business License", name: "business_license", type: "file" },
      { label: "Agree to Terms", name: "agree_terms", type: "checkbox", required: true },
    ],
  },
  vendor_compliance: {
    layout: { columns: 2 },
    fields: [
      { label: "Store Name", name: "store_name", type: "text", required: true },
      { label: "Store Type", name: "store_type", type: "select", required: true, options: ["Restaurant", "Grocery", "Retail", "Other"] },
      { label: "Business License", name: "business_license", type: "file", required: true },
      { label: "Health Certificate", name: "health_cert", type: "file" },
      { label: "Proof of Insurance", name: "insurance", type: "file", required: true },
      { label: "Agree to Terms", name: "agree_terms", type: "checkbox", required: true },
    ],
  },
  carrier_authority: {
    layout: { columns: 2 },
    fields: [
      { label: "MC Number", name: "mc_number", type: "text", required: true },
      { label: "DOT Number", name: "dot_number", type: "text", required: true },
      { label: "Company Name", name: "company_name", type: "text", required: true },
      { label: "Operating Authority Document", name: "authority_doc", type: "file", required: true },
      { label: "Certificate of Insurance", name: "insurance_cert", type: "file", required: true },
      { label: "Fleet Size", name: "fleet_size", type: "number", required: true },
      { label: "Service Areas", name: "service_areas", type: "textarea" },
    ],
  },
  broker_registration: {
    layout: { columns: 2 },
    fields: [
      { label: "Broker Name", name: "broker_name", type: "text", required: true },
      { label: "MC Authority Number", name: "mc_authority", type: "text", required: true },
      { label: "Bond Amount", name: "bond_amount", type: "number", required: true },
      { label: "Upload Bond Certificate", name: "bond_cert", type: "file", required: true },
      { label: "Business License", name: "business_license", type: "file", required: true },
      { label: "Years in Business", name: "years_in_business", type: "number" },
      { label: "Agree to Broker Terms", name: "agree_terms", type: "checkbox", required: true },
    ],
  },
  review_platform_guidelines: {
    layout: { columns: 1 },
    fields: [
      { label: "View Platform Guidelines", name: "guidelines_link", type: "link", url: "/get-public-policy-url" },
      { label: "I have reviewed the complete platform guidelines document", name: "guidelines_reviewed", type: "checkbox", required: true },
      { label: "I understand the code of conduct and behavioral expectations", name: "understand_conduct", type: "checkbox", required: true },
      { label: "I understand the safety and security requirements", name: "understand_safety", type: "checkbox", required: true },
      { label: "I understand the compliance and regulatory requirements", name: "understand_compliance", type: "checkbox", required: true },
      { label: "I understand the data privacy and confidentiality policies", name: "understand_data_privacy", type: "checkbox", required: true },
      { label: "I acknowledge that I have read, understood, and agree to comply with all platform guidelines", name: "guidelines_acceptance", type: "checkbox", required: true },
      { label: "I understand that violations may result in account suspension or termination", name: "violation_consequences", type: "checkbox", required: true },
      { label: "Full Legal Name", name: "full_name", type: "text", required: true, placeholder: "Enter your full legal name" },
      { label: "Date of Acceptance", name: "acceptance_date", type: "date", required: true },
    ],
  },
};
