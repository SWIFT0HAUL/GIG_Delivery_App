import { supabase } from '@/integrations/supabase/client';

// Demo account credentials
export const DEMO_ACCOUNTS = {
  driver: {
    email: 'demo.driver@haulee.com',
    password: 'Demo123!@#',
    role: 'driver'
  },
  shipper: {
    email: 'demo.shipper@haulee.com',
    password: 'Demo123!@#',
    role: 'shipper'
  },
  carrier: {
    email: 'demo.carrier@haulee.com',
    password: 'Demo123!@#',
    role: 'carrier'
  },
  broker: {
    email: 'demo.broker@haulee.com',
    password: 'Demo123!@#',
    role: 'broker'
  },
  vendor: {
    email: 'demo.vendor@haulee.com',
    password: 'Demo123!@#',
    role: 'vendor_merchant'
  },
  admin: {
    email: 'demo.admin@haulee.com',
    password: 'Demo123!@#',
    role: 'admin'
  }
} as const;

export type DemoRole = keyof typeof DEMO_ACCOUNTS;

/**
 * Login with a demo account
 * @param role The role to login as
 */
export async function loginWithDemoAccount(role: DemoRole) {
  const account = DEMO_ACCOUNTS[role];
  
  if (!account) {
    throw new Error(`Invalid demo role: ${role}`);
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email: account.email,
    password: account.password,
  });

  if (error) {
    console.error('Demo login error:', error);
    throw error;
  }

  return data;
}

/**
 * Check if the current user is a demo account
 */
export async function isDemoAccount(): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  
  if (!user?.email) return false;
  
  const demoEmails = Object.values(DEMO_ACCOUNTS).map(acc => acc.email) as string[];
  return demoEmails.includes(user.email);
}
