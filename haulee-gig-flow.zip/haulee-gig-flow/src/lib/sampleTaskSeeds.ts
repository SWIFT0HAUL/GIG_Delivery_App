import { supabase } from "@/integrations/supabase/client";

/**
 * Sample task form schemas for seeding the database
 * These can be inserted by admins to test the dynamic task form system
 */
export const SAMPLE_TASK_SEEDS = [
  {
    task_name: "Driver License Verification",
    task_role: "driver",
    task_category: "Compliance",
    task_description: "Upload and verify your driver's license for platform approval",
    status: "Pending",
    task_form_schema: {
      layout: { columns: 2 },
      fields: [
        { label: "Driver License Number", name: "license_number", type: "text", required: true },
        { label: "License State", name: "license_state", type: "text", required: true },
        { label: "License Expiration Date", name: "license_expiry", type: "date", required: true },
        { label: "Upload License Front", name: "license_front", type: "file", required: true },
        { label: "Upload License Back", name: "license_back", type: "file", required: true },
        { label: "I certify this information is accurate", name: "agree_terms", type: "checkbox", required: true }
      ]
    }
  },
  {
    task_name: "Vehicle Registration",
    task_role: "driver",
    task_category: "Vehicle",
    task_description: "Register your vehicle with required documentation",
    status: "Pending",
    task_form_schema: {
      layout: { columns: 2 },
      fields: [
        { label: "Vehicle Make", name: "vehicle_make", type: "text", required: true },
        { label: "Vehicle Model", name: "vehicle_model", type: "text", required: true },
        { label: "Year", name: "vehicle_year", type: "number", required: true },
        { label: "License Plate", name: "license_plate", type: "text", required: true },
        { label: "VIN", name: "vin", type: "text", required: true },
        { label: "Registration Document (PDF/Image)", name: "registration_doc", type: "file", required: true },
        { label: "Insurance Certificate", name: "insurance_doc", type: "file", required: true }
      ]
    }
  },
  {
    task_name: "Business Information",
    task_role: "shipper",
    task_category: "Onboarding",
    task_description: "Complete your business profile and upload required tax documents",
    status: "Pending",
    task_form_schema: {
      layout: { columns: 2 },
      fields: [
        { label: "Business Name", name: "business_name", type: "text", required: true },
        { label: "Tax ID (EIN)", name: "ein", type: "text", required: true },
        { label: "Business Address", name: "business_address", type: "textarea", required: true },
        { label: "Phone Number", name: "phone", type: "text", required: true },
        { label: "Upload W-9", name: "w9", type: "file", required: true },
        { label: "Business License (Optional)", name: "business_license", type: "file", required: false },
        { label: "I agree to terms and conditions", name: "agree_terms", type: "checkbox", required: true }
      ]
    }
  },
  {
    task_name: "Store Compliance",
    task_role: "vendor",
    task_category: "Compliance",
    task_description: "Submit required business licenses and certifications",
    status: "Pending",
    task_form_schema: {
      layout: { columns: 2 },
      fields: [
        { label: "Store Name", name: "store_name", type: "text", required: true },
        { 
          label: "Store Type", 
          name: "store_type", 
          type: "select", 
          required: true, 
          options: ["Restaurant", "Grocery", "Retail", "Pharmacy", "Other"] 
        },
        { label: "Business License", name: "business_license", type: "file", required: true },
        { label: "Health Certificate", name: "health_cert", type: "file", required: false },
        { label: "Proof of Insurance", name: "insurance", type: "file", required: true },
        { label: "I agree to vendor terms", name: "agree_terms", type: "checkbox", required: true }
      ]
    }
  },
  {
    task_name: "Carrier Authority Documentation",
    task_role: "carrier",
    task_category: "Authority",
    task_description: "Verify your carrier authority and operating credentials",
    status: "Pending",
    task_form_schema: {
      layout: { columns: 2 },
      fields: [
        { label: "MC Number", name: "mc_number", type: "text", required: true },
        { label: "DOT Number", name: "dot_number", type: "text", required: true },
        { label: "Company Name", name: "company_name", type: "text", required: true },
        { label: "Operating Authority Document", name: "authority_doc", type: "file", required: true },
        { label: "Certificate of Insurance", name: "insurance_cert", type: "file", required: true },
        { label: "Fleet Size", name: "fleet_size", type: "number", required: true },
        { label: "Service Areas", name: "service_areas", type: "textarea", required: false }
      ]
    }
  },
  {
    task_name: "Broker Registration",
    task_role: "broker",
    task_category: "Registration",
    task_description: "Complete broker registration with bond and authority documents",
    status: "Pending",
    task_form_schema: {
      layout: { columns: 2 },
      fields: [
        { label: "Broker Name", name: "broker_name", type: "text", required: true },
        { label: "MC Authority Number", name: "mc_authority", type: "text", required: true },
        { label: "Bond Amount", name: "bond_amount", type: "number", required: true },
        { label: "Upload Bond Certificate", name: "bond_cert", type: "file", required: true },
        { label: "Business License", name: "business_license", type: "file", required: true },
        { label: "Years in Business", name: "years_in_business", type: "number", required: false },
        { label: "I agree to broker terms and conditions", name: "agree_terms", type: "checkbox", required: true }
      ]
    }
  }
];

/**
 * Helper function to seed sample tasks (admin only)
 */
export async function seedSampleTasks() {
  try {
    const { data, error } = await supabase
      .from('tasks' as any)
      .insert(SAMPLE_TASK_SEEDS);

    if (error) throw error;

    console.log('✅ Sample tasks seeded successfully');
    return { success: true, data };
  } catch (error: any) {
    console.error('❌ Error seeding sample tasks:', error);
    return { success: false, error: error.message };
  }
}
