type CrossTabMessage = {
  type: 'LOGOUT' | 'ROLE_CHANGE' | 'SESSION_UPDATE' | 'USER_DELETED' | 'FORCE_RELOAD';
  payload?: any;
  timestamp: number;
  tabId: string;
};

const TAB_ID = `tab_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
const CHANNEL_NAME = 'platform_sync';

class CrossTabSync {
  private channel: BroadcastChannel | null = null;
  private listeners: Map<string, Set<(message: CrossTabMessage) => void>> = new Map();
  private useLocalStorageFallback = false;

  constructor() {
    if (typeof BroadcastChannel !== 'undefined') {
      this.channel = new BroadcastChannel(CHANNEL_NAME);
      this.channel.onmessage = (event) => {
        this.handleMessage(event.data);
      };
    } else {
      // Fallback for browsers without BroadcastChannel
      this.useLocalStorageFallback = true;
      window.addEventListener('storage', (event) => {
        if (event.key === CHANNEL_NAME && event.newValue) {
          try {
            const message = JSON.parse(event.newValue);
            this.handleMessage(message);
          } catch (error) {
            console.error('Error parsing cross-tab message:', error);
          }
        }
      });
    }
  }

  private handleMessage(message: CrossTabMessage) {
    // Ignore messages from this tab
    if (message.tabId === TAB_ID) return;

    console.log('📡 Cross-tab message received:', message.type);

    const listeners = this.listeners.get(message.type);
    if (listeners) {
      listeners.forEach(listener => {
        try {
          listener(message);
        } catch (error) {
          console.error('Error in cross-tab listener:', error);
        }
      });
    }
  }

  send(type: CrossTabMessage['type'], payload?: any) {
    const message: CrossTabMessage = {
      type,
      payload,
      timestamp: Date.now(),
      tabId: TAB_ID,
    };

    if (this.channel) {
      this.channel.postMessage(message);
    } else if (this.useLocalStorageFallback) {
      localStorage.setItem(CHANNEL_NAME, JSON.stringify(message));
      // Clear immediately to allow repeated messages
      setTimeout(() => localStorage.removeItem(CHANNEL_NAME), 100);
    }
  }

  on(type: CrossTabMessage['type'], listener: (message: CrossTabMessage) => void) {
    if (!this.listeners.has(type)) {
      this.listeners.set(type, new Set());
    }
    this.listeners.get(type)!.add(listener);

    return () => {
      const listeners = this.listeners.get(type);
      if (listeners) {
        listeners.delete(listener);
        if (listeners.size === 0) {
          this.listeners.delete(type);
        }
      }
    };
  }

  destroy() {
    if (this.channel) {
      this.channel.close();
    }
    this.listeners.clear();
  }
}

export const crossTabSync = new CrossTabSync();
