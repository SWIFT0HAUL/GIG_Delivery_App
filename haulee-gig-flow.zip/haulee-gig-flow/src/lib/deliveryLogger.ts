import { supabase } from '@/integrations/supabase/client';
import { LocationCoordinates } from './locationUtils';

export interface DeliveryLogEntry {
  assignmentId: string;
  jobId: string;
  actionType: 'pickup' | 'dropoff';
  driverLocation: LocationCoordinates;
  targetLocation: LocationCoordinates;
  distanceMeters: number;
  distanceYards: number;
  withinRadius: boolean;
  areaType: string;
  allowedRadiusMeters: number;
  success: boolean;
  failureReason?: string;
}

/**
 * Log delivery action attempt to database
 */
export async function logDeliveryAction(entry: DeliveryLogEntry): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) throw new Error('Not authenticated');

    // Log to job_assignments table as metadata
    const logData = {
      timestamp: new Date().toISOString(),
      action_type: entry.actionType,
      driver_location: { lat: entry.driverLocation.lat, lng: entry.driverLocation.lng },
      target_location: { lat: entry.targetLocation.lat, lng: entry.targetLocation.lng },
      distance_meters: entry.distanceMeters,
      distance_yards: entry.distanceYards,
      within_radius: entry.withinRadius,
      area_type: entry.areaType,
      allowed_radius_meters: entry.allowedRadiusMeters,
      success: entry.success,
      failure_reason: entry.failureReason,
    };

    // Update the assignment with log metadata
    const { error } = await supabase
      .from('job_assignments')
      .update({
        pickup_photo_url: entry.actionType === 'pickup' 
          ? JSON.stringify(logData) 
          : undefined,
      })
      .eq('id', entry.assignmentId);

    if (error) {
      console.error('Failed to log delivery action:', error);
    }

    // Also log to audit_logs for tracking
    await supabase.from('audit_logs').insert([{
      user_id: user.id,
      action: `DELIVERY_${entry.actionType.toUpperCase()}_${entry.success ? 'SUCCESS' : 'FAILURE'}`,
      entity_type: 'job_assignments',
      entity_id: entry.assignmentId,
      details: logData as any,
    }]);
  } catch (error) {
    console.error('Error logging delivery action:', error);
  }
}

/**
 * Get failed attempts count for an assignment
 */
export async function getFailedAttemptsCount(assignmentId: string): Promise<number> {
  try {
    const { data, error } = await supabase
      .from('audit_logs')
      .select('id')
      .eq('entity_id', assignmentId)
      .like('action', 'DELIVERY_%_FAILURE');

    if (error) throw error;
    return data?.length || 0;
  } catch (error) {
    console.error('Error getting failed attempts:', error);
    return 0;
  }
}
