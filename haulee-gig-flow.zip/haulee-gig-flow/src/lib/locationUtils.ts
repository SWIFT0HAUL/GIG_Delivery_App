// Location classification and distance utilities for delivery radius enforcement

export type AreaType = 'urban' | 'suburban' | 'rural';
export type ActionType = 'pickup' | 'dropoff';

export interface LocationCoordinates {
  lat: number;
  lng: number;
}

export interface RadiusConfig {
  pickup: {
    urban: number;
    suburban: number;
    rural: number;
  };
  dropoff: {
    urban: number;
    suburban: number;
    rural: number;
  };
}

// Radius rules in meters
export const RADIUS_CONFIG: RadiusConfig = {
  pickup: {
    urban: 12,      // 5-12 meters
    suburban: 25,   // 20-25 meters
    rural: 25,      // 20-25 meters
  },
  dropoff: {
    urban: 20,      // 10-20 meters
    suburban: 40,   // 30-40 meters
    rural: 40,      // 30-40 meters
  },
};

/**
 * Calculate distance between two coordinates using Haversine formula
 * @returns distance in meters
 */
export function calculateDistance(
  coord1: LocationCoordinates,
  coord2: LocationCoordinates
): number {
  const R = 6371e3; // Earth's radius in meters
  const φ1 = (coord1.lat * Math.PI) / 180;
  const φ2 = (coord2.lat * Math.PI) / 180;
  const Δφ = ((coord2.lat - coord1.lat) * Math.PI) / 180;
  const Δλ = ((coord2.lng - coord1.lng) * Math.PI) / 180;

  const a =
    Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
    Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

  return R * c; // Distance in meters
}

/**
 * Convert meters to yards
 */
export function metersToYards(meters: number): number {
  return meters * 1.09361;
}

/**
 * Classify location as urban, suburban, or rural based on address and coordinates
 * This is a simplified classification - in production, you'd use Census data or external APIs
 */
export async function classifyLocation(
  address: string,
  coordinates: LocationCoordinates
): Promise<AreaType> {
  // Simple heuristic based on address keywords
  const addressLower = address.toLowerCase();
  
  // Urban indicators
  const urbanKeywords = ['city', 'downtown', 'metro', 'avenue', 'plaza', 'street', 'apt', 'suite', 'floor'];
  const isUrban = urbanKeywords.some(keyword => addressLower.includes(keyword));
  
  if (isUrban) {
    return 'urban';
  }
  
  // Rural indicators
  const ruralKeywords = ['rural', 'county', 'farm', 'ranch', 'highway', 'route', 'rd', 'road'];
  const isRural = ruralKeywords.some(keyword => addressLower.includes(keyword));
  
  if (isRural) {
    return 'rural';
  }
  
  // Default to suburban
  return 'suburban';
}

/**
 * Get the allowed radius for a given action and area type
 */
export function getAllowedRadius(actionType: ActionType, areaType: AreaType): number {
  return RADIUS_CONFIG[actionType][areaType];
}

/**
 * Check if driver is within allowed radius
 */
export function isWithinRadius(
  driverLocation: LocationCoordinates,
  targetLocation: LocationCoordinates,
  actionType: ActionType,
  areaType: AreaType
): boolean {
  const distance = calculateDistance(driverLocation, targetLocation);
  const allowedRadius = getAllowedRadius(actionType, areaType);
  return distance <= allowedRadius;
}

/**
 * Format distance for display
 */
export function formatDistance(meters: number): string {
  const yards = metersToYards(meters);
  return `${Math.round(yards)} yards`;
}
