/**
 * Utility functions for exporting data to various formats
 */

/**
 * Export data to CSV format
 */
export const exportToCSV = (data: any[], filename: string) => {
  if (!data || data.length === 0) {
    throw new Error('No data to export');
  }

  // Get headers from first object
  const headers = Object.keys(data[0]);
  
  // Create CSV content
  const csvContent = [
    // Header row
    headers.join(','),
    // Data rows
    ...data.map(row => 
      headers.map(header => {
        const value = row[header];
        // Handle different data types
        if (value === null || value === undefined) return '';
        if (typeof value === 'object') return `"${JSON.stringify(value).replace(/"/g, '""')}"`;
        if (typeof value === 'string' && value.includes(',')) return `"${value.replace(/"/g, '""')}"`;
        return value;
      }).join(',')
    )
  ].join('\n');

  // Create blob and download
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  link.setAttribute('href', url);
  link.setAttribute('download', `${filename}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  URL.revokeObjectURL(url);
};

/**
 * Format job data for export
 */
export const formatJobsForExport = (jobs: any[]) => {
  return jobs.map(job => ({
    'Job ID': job.id.slice(0, 8),
    'Title': job.title || 'N/A',
    'Type': job.job_type || 'N/A',
    'Status': job.status,
    'Pickup Address': getLocationString(job.pickup_location),
    'Delivery Address': getLocationString(job.delivery_location),
    'Pay Amount': job.pay_amount || 0,
    'Distance (miles)': job.distance_miles || 'N/A',
    'Created At': new Date(job.created_at).toLocaleString(),
    'Updated At': new Date(job.updated_at).toLocaleString(),
  }));
};

/**
 * Helper to extract location string from location object
 */
const getLocationString = (location: any): string => {
  if (!location) return 'N/A';
  if (typeof location === 'string') return location;
  if (typeof location === 'object') {
    const loc = location as any;
    return `${loc.address || ''}, ${loc.city || ''}, ${loc.state || ''} ${loc.zip || ''}`.trim();
  }
  return 'N/A';
};

/**
 * Export jobs with filtering
 */
export const exportJobs = async (
  jobs: any[],
  filters: {
    status?: string;
    dateRange?: string;
    roleFilter?: string;
  } = {}
) => {
  let filteredJobs = [...jobs];

  // Apply filters
  if (filters.status && filters.status !== 'all') {
    filteredJobs = filteredJobs.filter(job => job.status === filters.status);
  }

  if (filters.dateRange && filters.dateRange !== 'all') {
    const now = new Date();
    const filterDate = new Date();
    
    switch (filters.dateRange) {
      case 'today':
        filterDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        filterDate.setDate(now.getDate() - 7);
        break;
      case 'month':
        filterDate.setMonth(now.getMonth() - 1);
        break;
    }
    
    filteredJobs = filteredJobs.filter(job => 
      new Date(job.created_at) >= filterDate
    );
  }

  // Format and export
  const formattedData = formatJobsForExport(filteredJobs);
  const timestamp = new Date().toISOString().split('T')[0];
  exportToCSV(formattedData, `jobs-export-${timestamp}`);
  
  return filteredJobs.length;
};
