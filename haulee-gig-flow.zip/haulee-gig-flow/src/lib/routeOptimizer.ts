/**
 * Advanced Route Optimization with Multi-Stop Sequencing
 * Tries different stop sequences and validates with actual travel times
 */

export interface JobTimeWindow {
  id: string;
  title: string;
  pickupTime: Date;
  dropoffTime: Date;
  distanceMiles: number;
  loadUnloadMinutes?: number;
  pickup_location: any;
  delivery_location: any;
}

export interface Stop {
  jobId: string;
  jobTitle: string;
  type: 'pickup' | 'dropoff';
  location: any;
  scheduledTime: Date;
  arrivalTime?: Date; // Actual calculated arrival time
}

export interface VehicleRoute {
  vehicleId: number;
  stops: Stop[];
  totalDistance: number;
  totalDuration: number;
  sequence: string; // Description of sequence tried
}

export interface RouteOptimizationResult {
  routes: VehicleRoute[];
  infeasibleJobs: JobTimeWindow[];
  attemptedSequences?: number;
}

/**
 * Calculate straight-line distance between two coordinates (Haversine)
 * Returns distance in miles
 */
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 3959; // Earth's radius in miles
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) *
    Math.sin(dLon / 2) * Math.sin(dLon / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function toRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

/**
 * Extract coordinates from location object
 */
function getCoordinates(location: any): { lat: number; lng: number } | null {
  if (!location) return null;
  
  if (location.coordinates) {
    return {
      lat: location.coordinates.lat || location.coordinates.latitude,
      lng: location.coordinates.lng || location.coordinates.longitude
    };
  }
  
  if (location.lat && location.lng) {
    return { lat: location.lat, lng: location.lng };
  }
  
  if (location.latitude && location.longitude) {
    return { lat: location.latitude, lng: location.longitude };
  }
  
  return null;
}

/**
 * Estimate travel time between two stops (using straight-line distance)
 * Returns minutes
 */
function estimateTravelTime(from: any, to: any): number {
  const fromCoords = getCoordinates(from);
  const toCoords = getCoordinates(to);
  
  if (!fromCoords || !toCoords) {
    return 15; // Default fallback
  }
  
  const distanceMiles = calculateDistance(
    fromCoords.lat, fromCoords.lng,
    toCoords.lat, toCoords.lng
  );
  
  // Assume 30 mph average speed in city + 5 min buffer per stop
  const travelMinutes = (distanceMiles / 30) * 60 + 5;
  return Math.ceil(travelMinutes);
}

/**
 * Generate all possible stop sequences for given jobs
 * For 2 jobs, this generates sequences like:
 * - P1 → D1 → P2 → D2
 * - P1 → P2 → D1 → D2
 * - P1 → P2 → D2 → D1
 * - P2 → P1 → D1 → D2
 * etc.
 */
function generateStopSequences(jobs: JobTimeWindow[]): Stop[][] {
  const sequences: Stop[][] = [];
  
  // For simplicity, we'll try key permutations for 2-3 jobs
  // For more jobs, this becomes computationally expensive
  
  if (jobs.length === 1) {
    // Only one sequence: pickup then delivery
    const job = jobs[0];
    sequences.push([
      { jobId: job.id, jobTitle: job.title, type: 'pickup', location: job.pickup_location, scheduledTime: job.pickupTime },
      { jobId: job.id, jobTitle: job.title, type: 'dropoff', location: job.delivery_location, scheduledTime: job.dropoffTime }
    ]);
  } else if (jobs.length === 2) {
    const [j1, j2] = jobs;
    
    // Sequence 1: P1 → D1 → P2 → D2
    sequences.push([
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: j1.pickupTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: j1.dropoffTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: j2.pickupTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: j2.dropoffTime }
    ]);
    
    // Sequence 2: P1 → P2 → D1 → D2
    sequences.push([
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: j1.pickupTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: j2.pickupTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: j1.dropoffTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: j2.dropoffTime }
    ]);
    
    // Sequence 3: P1 → P2 → D2 → D1
    sequences.push([
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: j1.pickupTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: j2.pickupTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: j2.dropoffTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: j1.dropoffTime }
    ]);
    
    // Sequence 4: P2 → P1 → D1 → D2
    sequences.push([
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: j2.pickupTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: j1.pickupTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: j1.dropoffTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: j2.dropoffTime }
    ]);
    
    // Sequence 5: P2 → P1 → D2 → D1
    sequences.push([
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: j2.pickupTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: j1.pickupTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: j2.dropoffTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: j1.dropoffTime }
    ]);
    
    // Sequence 6: P2 → D2 → P1 → D1
    sequences.push([
      { jobId: j2.id, jobTitle: j2.title, type: 'pickup', location: j2.pickup_location, scheduledTime: j2.pickupTime },
      { jobId: j2.id, jobTitle: j2.title, type: 'dropoff', location: j2.delivery_location, scheduledTime: j2.dropoffTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'pickup', location: j1.pickup_location, scheduledTime: j1.pickupTime },
      { jobId: j1.id, jobTitle: j1.title, type: 'dropoff', location: j1.delivery_location, scheduledTime: j1.dropoffTime }
    ]);
  } else {
    // For 3+ jobs, just try pickup-all-first then deliver-all
    const pickupStops: Stop[] = jobs.map(j => ({
      jobId: j.id,
      jobTitle: j.title,
      type: 'pickup',
      location: j.pickup_location,
      scheduledTime: j.pickupTime
    }));
    
    const deliveryStops: Stop[] = jobs.map(j => ({
      jobId: j.id,
      jobTitle: j.title,
      type: 'dropoff',
      location: j.delivery_location,
      scheduledTime: j.dropoffTime
    }));
    
    sequences.push([...pickupStops, ...deliveryStops]);
  }
  
  return sequences;
}

/**
 * Validate if a stop sequence is feasible given time windows
 * Calculates actual arrival times based on travel time estimates
 */
function validateSequence(sequence: Stop[], startTime: Date): { valid: boolean; reason?: string; stops?: Stop[] } {
  if (sequence.length === 0) {
    return { valid: false, reason: 'Empty sequence' };
  }
  
  let currentTime = new Date(startTime);
  const validatedStops: Stop[] = [];
  const LOAD_UNLOAD_MINUTES = 10; // Time to load/unload at each stop
  
  for (let i = 0; i < sequence.length; i++) {
    const stop = sequence[i];
    
    // Calculate travel time from previous stop (if any)
    if (i > 0) {
      const travelMinutes = estimateTravelTime(sequence[i - 1].location, stop.location);
      currentTime = new Date(currentTime.getTime() + travelMinutes * 60 * 1000);
    }
    
    // Add load/unload time
    currentTime = new Date(currentTime.getTime() + LOAD_UNLOAD_MINUTES * 60 * 1000);
    
    // Check if we arrive too early (before scheduled pickup time)
    if (stop.type === 'pickup' && currentTime < stop.scheduledTime) {
      // We're early, wait until scheduled time
      currentTime = new Date(stop.scheduledTime);
    }
    
    // Check if we arrive too late (after scheduled delivery time)
    if (stop.type === 'dropoff' && currentTime > stop.scheduledTime) {
      return {
        valid: false,
        reason: `Cannot complete delivery for "${stop.jobTitle}" by ${stop.scheduledTime.toLocaleTimeString()}. Arrival: ${currentTime.toLocaleTimeString()}`
      };
    }
    
    validatedStops.push({
      ...stop,
      arrivalTime: new Date(currentTime)
    });
  }
  
  return { valid: true, stops: validatedStops };
}

/**
 * Optimize routes by trying different stop sequences
 */
export function optimizeRoutes(jobs: JobTimeWindow[], vehicleCount: number = 1): RouteOptimizationResult {
  if (jobs.length === 0) {
    return { routes: [], infeasibleJobs: [], attemptedSequences: 0 };
  }
  
  // Sort jobs by earliest pickup time to start from first job
  const sortedJobs = [...jobs].sort((a, b) => a.pickupTime.getTime() - b.pickupTime.getTime());
  const startTime = sortedJobs[0].pickupTime;
  
  // Generate possible sequences
  const sequences = generateStopSequences(sortedJobs);
  console.log(`[RouteOptimizer] Generated ${sequences.length} possible sequences for ${jobs.length} jobs`);
  
  // Try each sequence and find the first valid one
  let bestRoute: VehicleRoute | null = null;
  
  for (let i = 0; i < sequences.length; i++) {
    const sequence = sequences[i];
    const validation = validateSequence(sequence, startTime);
    
    if (validation.valid && validation.stops) {
      // Calculate total distance and duration
      let totalDistance = 0;
      let totalDuration = 0;
      
      for (let j = 0; j < validation.stops.length - 1; j++) {
        const from = validation.stops[j];
        const to = validation.stops[j + 1];
        
        const fromCoords = getCoordinates(from.location);
        const toCoords = getCoordinates(to.location);
        
        if (fromCoords && toCoords) {
          totalDistance += calculateDistance(fromCoords.lat, fromCoords.lng, toCoords.lat, toCoords.lng);
        }
        
        totalDuration += estimateTravelTime(from.location, to.location);
      }
      
      // Generate sequence description
      const sequenceDesc = validation.stops.map(s => `${s.type === 'pickup' ? 'P' : 'D'}(${s.jobTitle})`).join(' → ');
      
      bestRoute = {
        vehicleId: 1,
        stops: validation.stops,
        totalDistance,
        totalDuration,
        sequence: sequenceDesc
      };
      
      console.log(`[RouteOptimizer] Found valid sequence #${i + 1}: ${sequenceDesc}`);
      break;
    } else {
      console.log(`[RouteOptimizer] Sequence #${i + 1} invalid: ${validation.reason}`);
    }
  }
  
  if (bestRoute) {
    return {
      routes: [bestRoute],
      infeasibleJobs: [],
      attemptedSequences: sequences.length
    };
  }
  
  // No valid sequence found
  return {
    routes: [],
    infeasibleJobs: sortedJobs,
    attemptedSequences: sequences.length
  };
}
