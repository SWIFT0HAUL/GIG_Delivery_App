/**
 * Geocoding utilities for address and place ID lookups with caching
 */
import { supabase } from '@/integrations/supabase/client';

const SUPABASE_PROJECT_ID = 'cqoydkxlonzobykwjcin';
const GEOCODE_ENDPOINT = `https://${SUPABASE_PROJECT_ID}.supabase.co/functions/v1/geocode`;

// Cache configuration
const CACHE_KEY_PREFIX = 'geocode_cache_';
const CACHE_EXPIRY_MS = 24 * 60 * 60 * 1000; // 24 hours

export interface GeocodeResult {
  address: string;
  lat: number;
  lng: number;
}

interface CachedGeocodeResult extends GeocodeResult {
  timestamp: number;
}

/**
 * Get cached geocoding result
 */
function getCachedResult(key: string): GeocodeResult | null {
  try {
    const cached = localStorage.getItem(CACHE_KEY_PREFIX + key);
    if (!cached) return null;

    const parsed: CachedGeocodeResult = JSON.parse(cached);
    const age = Date.now() - parsed.timestamp;

    // Check if cache is still valid
    if (age > CACHE_EXPIRY_MS) {
      localStorage.removeItem(CACHE_KEY_PREFIX + key);
      return null;
    }

    return {
      address: parsed.address,
      lat: parsed.lat,
      lng: parsed.lng
    };
  } catch {
    return null;
  }
}

/**
 * Cache geocoding result
 */
function setCachedResult(key: string, result: GeocodeResult): void {
  try {
    const cached: CachedGeocodeResult = {
      ...result,
      timestamp: Date.now()
    };
    localStorage.setItem(CACHE_KEY_PREFIX + key, JSON.stringify(cached));
  } catch (error) {
    // Silently fail if localStorage is full or unavailable
    console.warn('Failed to cache geocoding result:', error);
  }
}

/**
 * Generate cache key from input
 */
function generateCacheKey(input: string): string {
  return input.toLowerCase().trim().replace(/\s+/g, '_');
}

async function getMapboxToken(): Promise<string | null> {
  try {
    const { data, error } = await supabase.functions.invoke('get-mapbox-token');
    if (error) return null;
    if (typeof data === 'string') return data as string;
    return (data as any)?.token || (data as any)?.mapbox_token || (data as any)?.mapboxToken || null;
  } catch {
    return null;
  }
}

async function mapboxGeocodeAddress(address: string) {
  const token = await getMapboxToken();
  if (!token) throw new Error('Mapbox token not available');
  const url = `https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?limit=1&access_token=${encodeURIComponent(token)}`;
  const resp = await fetch(url);
  if (!resp.ok) throw new Error(`Mapbox geocoding failed: ${resp.status} ${resp.statusText}`);
  const json = await resp.json();
  const feature = json?.features?.[0];
  if (!feature?.center || !feature?.place_name) throw new Error('Invalid Mapbox geocoding response');
  const [lng, lat] = feature.center;
  return { lat, lng, address: feature.place_name } as GeocodeResult;
}

/**
 * Get coordinates and formatted address from a Place ID or OSM ID
 * @param placeId - Place ID or OSM ID
 * @returns Promise with address and coordinates
 */
export async function geocodeByPlaceId(placeId: string): Promise<GeocodeResult> {
  if (!placeId || typeof placeId !== 'string') {
    throw new Error('Valid place ID is required');
  }

  // Check cache first
  const cacheKey = generateCacheKey(`place_${placeId}`);
  const cached = getCachedResult(cacheKey);
  if (cached) {
    console.log('Using cached result for place ID:', placeId);
    return cached;
  }

  // Try edge function first, but gracefully fallback on errors or rate limits
  try {
    const url = `${GEOCODE_ENDPOINT}?place_id=${encodeURIComponent(placeId)}`;
    const response = await fetch(url);
    if (response.ok) {
      const json = await response.json();
      if (json.lat && json.lng && json.address) {
        const result = { lat: json.lat, lng: json.lng, address: json.address };
        // Cache the successful result
        setCachedResult(cacheKey, result);
        return result;
      }
    }
  } catch {
    // ignore and fallback to Mapbox
  }

  // Fallback: treat placeId as a free-text query for Mapbox
  const fallback = await mapboxGeocodeAddress(placeId);
  setCachedResult(cacheKey, fallback);
  return fallback;
}

/**
 * Get coordinates and formatted address from an address string
 * @param address - Address string (e.g., "1600 Amphitheatre Parkway, Mountain View, CA")
 * @returns Promise with address and coordinates
 */
export async function geocodeByAddress(address: string): Promise<GeocodeResult> {
  if (!address || typeof address !== 'string') {
    throw new Error('Valid address is required');
  }

  // Validate and limit address length
  const trimmedAddress = address.trim();
  if (trimmedAddress.length < 5) {
    throw new Error('Address too short');
  }
  
  const validatedAddress = trimmedAddress.slice(0, 500);

  // Check cache first
  const cacheKey = generateCacheKey(`addr_${validatedAddress}`);
  const cached = getCachedResult(cacheKey);
  if (cached) {
    console.log('Using cached result for address:', validatedAddress);
    return cached;
  }

  // First try our LocationIQ-backed edge function
  try {
    const url = `${GEOCODE_ENDPOINT}?address=${encodeURIComponent(validatedAddress)}`;
    const response = await fetch(url);
    if (response.ok) {
      const json = await response.json();
      if (json.lat && json.lng && json.address) {
        const result = { lat: json.lat, lng: json.lng, address: json.address };
        // Cache the successful result
        setCachedResult(cacheKey, result);
        return result;
      }
    }
  } catch {
    // ignore and fallback to Mapbox
  }

  // Fallback to Mapbox geocoding
  const mapboxResult = await mapboxGeocodeAddress(validatedAddress);
  // Cache the Mapbox result too
  setCachedResult(cacheKey, mapboxResult);
  return mapboxResult;
}
