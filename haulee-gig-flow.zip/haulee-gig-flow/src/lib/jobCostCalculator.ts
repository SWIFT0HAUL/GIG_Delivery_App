// Calculate job cost based on distance, weight, vehicle type, and market analysis
export const calculateJobCost = (params: {
  distanceMiles: number;
  weight?: number;
  vehicleType?: string;
  createdDate?: Date;
}): number => {
  const { distanceMiles, weight = 0, vehicleType = 'Car/SUV', createdDate = new Date() } = params;
  
  // Base rates per mile by vehicle type
  const baseRates: Record<string, number> = {
    'Bike/Moto': 1.5,
    'Car/SUV': 2.0,
    'Cargo Van/Pick Up Truck': 2.5,
    'Box Truck (all sizes)': 3.5,
    'Dry Van': 4.0,
    'Flatbed': 4.5,
  };
  
  const baseRate = baseRates[vehicleType] || 2.0;
  
  // Distance-based cost
  let distanceCost = distanceMiles * baseRate;
  
  // Weight surcharge (per 100 lbs)
  const weightSurcharge = (weight / 100) * 5;
  
  // Market analysis multiplier based on day of week and month
  const dayOfWeek = createdDate.getDay();
  const month = createdDate.getMonth();
  
  // Higher rates on weekends and peak seasons (Nov-Dec)
  let marketMultiplier = 1.0;
  if (dayOfWeek === 0 || dayOfWeek === 6) marketMultiplier += 0.15; // Weekend
  if (month === 10 || month === 11) marketMultiplier += 0.10; // Holiday season
  
  // Calculate total
  let totalCost = (distanceCost + weightSurcharge) * marketMultiplier;
  
  // Minimum charge
  const minimumCharge = 25;
  totalCost = Math.max(totalCost, minimumCharge);
  
  return Math.round(totalCost * 100) / 100; // Round to 2 decimals
};
