/**
 * Google Directions API utilities
 */

const SUPABASE_PROJECT_ID = 'cqoydkxlonzobykwjcin';
const DIRECTIONS_ENDPOINT = `https://${SUPABASE_PROJECT_ID}.supabase.co/functions/v1/directions`;

export type TravelMode = 'driving' | 'walking' | 'bicycling' | 'transit';

export interface DirectionsParams {
  origin: string; // Address or "lat,lng"
  destination: string; // Address or "lat,lng"
  mode?: TravelMode;
  waypoints?: string[]; // Array of addresses or coordinates
  departureTime?: 'now' | number; // Unix timestamp or "now"
  trafficModel?: 'best_guess' | 'pessimistic' | 'optimistic';
}

export interface DirectionsRoute {
  summary: string;
  legs: Array<{
    distance: { text: string; value: number };
    duration: { text: string; value: number };
    duration_in_traffic?: { text: string; value: number };
    start_address: string;
    end_address: string;
    start_location: { lat: number; lng: number };
    end_location: { lat: number; lng: number };
    steps: Array<{
      distance: { text: string; value: number };
      duration: { text: string; value: number };
      html_instructions: string;
      travel_mode: string;
      start_location: { lat: number; lng: number };
      end_location: { lat: number; lng: number };
    }>;
  }>;
  overview_polyline: { points: string };
  warnings: string[];
  waypoint_order: number[];
}

export interface DirectionsResult {
  routes: DirectionsRoute[];
  status: string;
  geocoded_waypoints?: Array<{
    geocoder_status: string;
    place_id: string;
    types: string[];
  }>;
}

/**
 * Get directions between two locations
 */
export async function getDirections(
  params: DirectionsParams
): Promise<DirectionsResult> {
  const { origin, destination, mode, waypoints, departureTime, trafficModel } = params;

  // Validate inputs
  if (!origin || typeof origin !== 'string') {
    throw new Error('Valid origin is required');
  }
  if (!destination || typeof destination !== 'string') {
    throw new Error('Valid destination is required');
  }

  // Build URL with parameters
  const url = new URL(DIRECTIONS_ENDPOINT);
  url.searchParams.append('origin', origin);
  url.searchParams.append('destination', destination);

  if (mode) {
    url.searchParams.append('mode', mode);
  }

  if (waypoints && waypoints.length > 0) {
    // Format waypoints as pipe-separated string
    const waypointsString = waypoints.map(wp => `via:${wp}`).join('|');
    url.searchParams.append('waypoints', waypointsString);
  }

  if (departureTime) {
    url.searchParams.append('departure_time', departureTime.toString());
  }

  if (trafficModel) {
    url.searchParams.append('traffic_model', trafficModel);
  }

  const response = await fetch(url.toString());

  if (!response.ok) {
    throw new Error(`Directions API failed: ${response.status} ${response.statusText}`);
  }

  const json = await response.json();

  if (json.status !== 'OK') {
    throw new Error(`Directions error: ${json.status} - ${json.error_message || 'Unknown error'}`);
  }

  return json;
}

/**
 * Calculate total distance and duration from directions result
 */
export function calculateTotals(result: DirectionsResult): {
  totalDistance: number; // meters
  totalDuration: number; // seconds
  totalDistanceText: string;
  totalDurationText: string;
} {
  if (!result.routes || result.routes.length === 0) {
    return {
      totalDistance: 0,
      totalDuration: 0,
      totalDistanceText: '0 km',
      totalDurationText: '0 mins',
    };
  }

  const route = result.routes[0];
  let totalDistance = 0;
  let totalDuration = 0;

  route.legs.forEach(leg => {
    totalDistance += leg.distance.value;
    totalDuration += leg.duration.value;
  });

  return {
    totalDistance,
    totalDuration,
    totalDistanceText: `${(totalDistance / 1000).toFixed(1)} km`,
    totalDurationText: `${Math.round(totalDuration / 60)} mins`,
  };
}

/**
 * Extract polyline points for map rendering
 */
export function getPolyline(result: DirectionsResult): string | null {
  if (!result.routes || result.routes.length === 0) {
    return null;
  }
  return result.routes[0].overview_polyline.points;
}
