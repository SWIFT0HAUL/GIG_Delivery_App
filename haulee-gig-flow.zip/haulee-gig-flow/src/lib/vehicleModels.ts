/**
 * Vehicle Make and Model mappings
 * Common models for each manufacturer
 */

export const VEHICLE_MODELS: Record<string, string[]> = {
  "Acura": ["ILX", "TLX", "RLX", "MDX", "RDX", "NSX", "Other"],
  "Alfa Romeo": ["Giulia", "Stelvio", "4C", "Other"],
  "Audi": ["A3", "A4", "A5", "A6", "A7", "A8", "Q3", "Q5", "Q7", "Q8", "e-tron", "R8", "TT", "Other"],
  "BMW": ["2 Series", "3 Series", "4 Series", "5 Series", "6 Series", "7 Series", "8 Series", "X1", "X2", "X3", "X4", "X5", "X6", "X7", "Z4", "i3", "i4", "iX", "Other"],
  "Buick": ["Enclave", "Encore", "Encore GX", "Envision", "Other"],
  "Cadillac": ["CT4", "CT5", "XT4", "XT5", "XT6", "Escalade", "Other"],
  "Chevrolet": ["Spark", "Sonic", "Cruze", "Malibu", "Impala", "Camaro", "Corvette", "Trax", "Equinox", "Blazer", "Traverse", "Tahoe", "Suburban", "Silverado 1500", "Silverado 2500HD", "Silverado 3500HD", "Colorado", "Other"],
  "Chevrolet Commercial": ["Express Cargo Van", "Silverado 2500HD", "Silverado 3500HD", "Low Cab Forward", "Other"],
  "Chrysler": ["300", "Pacifica", "Voyager", "Other"],
  "Dodge": ["Charger", "Challenger", "Durango", "Journey", "Grand Caravan", "Ram 1500", "Ram 2500", "Ram 3500", "Other"],
  "FIAT": ["500", "500X", "124 Spider", "Other"],
  "Ford": ["Fiesta", "Focus", "Fusion", "Mustang", "EcoSport", "Escape", "Edge", "Explorer", "Expedition", "F-150", "F-250", "F-350", "Ranger", "Bronco", "Bronco Sport", "Maverick", "Other"],
  "Ford Commercial": ["Transit Connect", "Transit Cargo Van", "Transit Passenger Van", "Transit Cutaway", "E-Series", "F-450", "F-550", "F-650", "F-750", "Other"],
  "Freightliner": ["Cascadia", "M2 106", "M2 112", "Business Class M2", "Sprinter Cargo Van", "Sprinter Crew Van", "114SD", "122SD", "Other"],
  "Genesis": ["G70", "G80", "G90", "GV60", "GV70", "GV80", "Other"],
  "GMC": ["Terrain", "Acadia", "Yukon", "Yukon XL", "Sierra 1500", "Sierra 2500HD", "Sierra 3500HD", "Canyon", "Other"],
  "GMC Commercial": ["Savana Cargo Van", "Savana Passenger Van", "Sierra 2500HD", "Sierra 3500HD", "Other"],
  "Hino": ["155", "195", "258ALP", "268", "338", "358", "L Series", "XL Series", "Other"],
  "Honda": ["Fit", "Civic", "Accord", "Insight", "Clarity", "CR-V", "HR-V", "Passport", "Pilot", "Odyssey", "Ridgeline", "Other"],
  "Hyundai": ["Accent", "Elantra", "Sonata", "Ioniq", "Venue", "Kona", "Tucson", "Santa Fe", "Palisade", "Other"],
  "INFINITI": ["Q50", "Q60", "QX50", "QX55", "QX60", "QX80", "Other"],
  "International": ["HX Series", "HV Series", "LT Series", "RH Series", "MV Series", "CV Series", "Other"],
  "Isuzu": ["D-Max", "MU-X", "Other"],
  "Isuzu Commercial": ["NPR", "NPR-HD", "NQR", "NRR", "FTR", "FVR", "Other"],
  "Jaguar": ["XE", "XF", "XJ", "F-Type", "E-Pace", "F-Pace", "I-Pace", "Other"],
  "Jeep": ["Renegade", "Compass", "Cherokee", "Grand Cherokee", "Wrangler", "Gladiator", "Wagoneer", "Grand Wagoneer", "Other"],
  "Kenworth": ["T270", "T370", "T380", "T480", "T680", "T880", "W900", "Other"],
  "Kia": ["Rio", "Forte", "K5", "Stinger", "Soul", "Seltos", "Sportage", "Sorento", "Telluride", "Carnival", "Other"],
  "Land Rover": ["Range Rover Evoque", "Range Rover Velar", "Range Rover Sport", "Range Rover", "Discovery Sport", "Discovery", "Defender", "Other"],
  "Lexus": ["IS", "ES", "GS", "LS", "RC", "LC", "UX", "NX", "RX", "GX", "LX", "Other"],
  "Lincoln": ["Corsair", "Nautilus", "Aviator", "Navigator", "Other"],
  "Mack": ["Anthem", "Granite", "LR", "MD", "Pinnacle", "TerraPro", "Other"],
  "Maserati": ["Ghibli", "Quattroporte", "Levante", "MC20", "Other"],
  "Mazda": ["Mazda3", "Mazda6", "MX-5 Miata", "CX-3", "CX-30", "CX-5", "CX-9", "CX-50", "Other"],
  "Mercedes-Benz": ["A-Class", "C-Class", "E-Class", "S-Class", "CLA", "CLS", "GLA", "GLB", "GLC", "GLE", "GLS", "G-Class", "SL", "AMG GT", "EQB", "EQC", "EQE", "EQS", "Other"],
  "Mercedes-Benz Commercial": ["Sprinter Cargo Van", "Sprinter Crew Van", "Sprinter Passenger Van", "Metris Cargo Van", "Metris Passenger Van", "Other"],
  "MINI": ["Cooper", "Cooper Clubman", "Cooper Countryman", "Other"],
  "Mitsubishi": ["Mirage", "Mirage G4", "Eclipse Cross", "Outlander", "Outlander Sport", "Other"],
  "Mitsubishi Fuso": ["Canter FE", "Canter FEC", "FE Series", "FG Series", "Other"],
  "Nissan": ["Versa", "Sentra", "Altima", "Maxima", "GT-R", "370Z", "Kicks", "Rogue Sport", "Rogue", "Murano", "Pathfinder", "Armada", "Frontier", "Titan", "Other"],
  "Nissan Commercial": ["NV Cargo", "NV Passenger", "NV200", "Titan XD", "Other"],
  "Peterbilt": ["220", "325", "330", "337", "348", "365", "367", "389", "520", "567", "579", "589", "Other"],
  "Porsche": ["718 Cayman", "718 Boxster", "911", "Panamera", "Macan", "Cayenne", "Taycan", "Other"],
  "Ram": ["1500", "2500", "3500", "ProMaster", "ProMaster City", "Other"],
  "Ram Commercial": ["ProMaster Cargo Van", "ProMaster Window Van", "ProMaster Cutaway", "ProMaster City", "2500", "3500", "4500", "5500", "Other"],
  "Subaru": ["Impreza", "Legacy", "WRX", "BRZ", "Crosstrek", "Forester", "Outback", "Ascent", "Other"],
  "Tesla": ["Model 3", "Model S", "Model X", "Model Y", "Cybertruck", "Roadster", "Other"],
  "Toyota": ["Yaris", "Corolla", "Camry", "Avalon", "Prius", "86", "GR Supra", "C-HR", "RAV4", "Venza", "Highlander", "4Runner", "Sequoia", "Land Cruiser", "Tacoma", "Tundra", "Sienna", "Other"],
  "Volkswagen": ["Jetta", "Passat", "Arteon", "Golf", "GTI", "ID.4", "Taos", "Tiguan", "Atlas", "Atlas Cross Sport", "Other"],
  "Volvo": ["S60", "S90", "V60", "V90", "XC40", "XC60", "XC90", "C40", "Other"],
  "Volvo Trucks": ["VNL", "VNR", "VHD", "VAH", "Other"],
  "Western Star": ["4700", "4800", "4900", "5700XE", "6900XD", "Other"],
  "Other": ["Other"]
};

export function getModelsForMake(make: string): string[] {
  return VEHICLE_MODELS[make] || ["Other"];
}
