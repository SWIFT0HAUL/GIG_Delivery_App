export interface VehicleType {
  name: string;
  capacity: string;
}

export interface VehicleCategory {
  id: number;
  name: string;
  icon: string;
  description: string;
  vehicle_types: VehicleType[];
}

export const VEHICLE_CATEGORIES: VehicleCategory[] = [
  {
    id: 1,
    name: "Courier & Small Parcel Delivery",
    icon: "🚴",
    description: "For small packages, documents, and fast city deliveries.",
    vehicle_types: [
      { name: "Bicycle", capacity: "0–10 kg" },
      { name: "Electric Bike (E-Bike)", capacity: "0–15 kg" },
      { name: "Scooter / Moped", capacity: "0–20 kg" },
      { name: "Motorcycle", capacity: "0–25 kg" },
      { name: "Compact Car", capacity: "0–100 kg" },
      { name: "Sedan", capacity: "0–150 kg" },
      { name: "Hatchback", capacity: "0–150 kg" }
    ]
  },
  {
    id: 2,
    name: "Household & Furniture Moving",
    icon: "🚐",
    description: "For furniture, appliances, and residential moving jobs.",
    vehicle_types: [
      { name: "SUV", capacity: "0.5–1 ton" },
      { name: "Crossover", capacity: "0.5–1 ton" },
      { name: "Minivan", capacity: "0.5–1.5 ton" },
      { name: "Passenger Van", capacity: "0.5–2 ton" },
      { name: "Cargo Van (Small/Medium)", capacity: "1–2 ton" },
      { name: "Pickup Truck (Double Cab)", capacity: "1–2 ton" },
      { name: "Box Truck (10–16 ft)", capacity: "2–4 ton" },
      { name: "Moving Truck", capacity: "Up to 5 ton" }
    ]
  },
  {
    id: 3,
    name: "Freight & Logistics Transport",
    icon: "🚚",
    description: "For palletized freight, warehouse distribution, and long-distance transport.",
    vehicle_types: [
      { name: "Cargo Van (Large)", capacity: "2–3 ton" },
      { name: "Box Truck (16–26 ft)", capacity: "4–10 ton" },
      { name: "Flatbed Truck", capacity: "5–15 ton" },
      { name: "Pickup Truck (Single Cab)", capacity: "1–2 ton" },
      { name: "Stake Truck", capacity: "5–10 ton" },
      { name: "Curtain Side Truck", capacity: "8–12 ton" },
      { name: "Trailer Truck (Semi)", capacity: "10–25 ton" },
      { name: "Tractor-Trailer (18-Wheeler)", capacity: "25–35 ton" },
      { name: "Container Truck", capacity: "20–35 ton" }
    ]
  },
  {
    id: 4,
    name: "Construction & Industrial Hauling",
    icon: "🏗️",
    description: "For construction materials, heavy machinery, and industrial loads.",
    vehicle_types: [
      { name: "Dump Truck", capacity: "10–20 ton" },
      { name: "Flatbed Truck", capacity: "10–20 ton" },
      { name: "Lowboy Trailer", capacity: "15–40 ton" },
      { name: "Crane Truck", capacity: "20–40 ton" },
      { name: "Heavy Equipment Transporter", capacity: "25–50 ton" },
      { name: "Logging Truck", capacity: "15–30 ton" }
    ]
  },
  {
    id: 5,
    name: "Specialized / Temperature-Controlled Delivery",
    icon: "🚛",
    description: "For perishable, liquid, or temperature-sensitive goods.",
    vehicle_types: [
      { name: "Refrigerated Van", capacity: "1–2 ton" },
      { name: "Refrigerated Truck", capacity: "3–10 ton" },
      { name: "Tanker Truck (Fuel / Water)", capacity: "10–25 ton" },
      { name: "Car Carrier", capacity: "5–10 vehicles" }
    ]
  }
];

// Flat list of all vehicle types for simple dropdowns
export const ALL_VEHICLE_TYPES = VEHICLE_CATEGORIES.flatMap(category => 
  category.vehicle_types.map(vehicle => ({
    value: vehicle.name,
    label: `${vehicle.name} (${vehicle.capacity})`,
    category: category.name
  }))
);

// Standard vehicle colors used across the platform
export const VEHICLE_COLORS = [
  "Beige", "Black", "Blue", "Bronze", "Brown", "Burgundy", 
  "Charcoal", "Copper", "Cream", "Gold", "Gray", "Green", 
  "Ivory", "Maroon", "Navy", "Orange", "Pearl", "Purple", 
  "Red", "Silver", "Tan", "Teal", "White", "Yellow"
];

// Get vehicle types by category
export const getVehicleTypesByCategory = (categoryId: number): VehicleType[] => {
  const category = VEHICLE_CATEGORIES.find(c => c.id === categoryId);
  return category ? category.vehicle_types : [];
};
