import { LiveViewMap } from '@/components/maps/LiveViewMap';

const LiveView = () => {
  return (
    <div className="container mx-auto p-6">
      <LiveViewMap />
    </div>
  );
};

export default LiveView;
