import { SystemAccessGuard } from "@/components/access";
import AdminDashboard from "./AdminDashboard";

export default function AdminDashboardGuarded() {
  return (
    <SystemAccessGuard 
      requireAdmin 
      requireApproval 
      showAlert 
      redirectOnFail="/dashboard"
    >
      <AdminDashboard />
    </SystemAccessGuard>
  );
}
