import { TaskCenterDashboard } from '@/components/task-center/TaskCenterDashboard';
import { TaskListTable } from '@/components/task-center/TaskListTable';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

const AdminTaskCenter = () => {
  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
            Admin Task Center
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage all operational tasks and workflows
          </p>
        </div>
        <Button className="bg-gradient-to-r from-primary to-primary/80">
          <Plus className="h-4 w-4 mr-2" />
          Create Task
        </Button>
      </div>

      {/* Dashboard Stats */}
      <TaskCenterDashboard />

      {/* Task List */}
      <TaskListTable />
    </div>
  );
};

export default AdminTaskCenter;
