import { PlatformSettingsPage } from "@/components/admin/PlatformSettingsPage";

const Settings = () => {
  return <PlatformSettingsPage />;
};

export default Settings;
