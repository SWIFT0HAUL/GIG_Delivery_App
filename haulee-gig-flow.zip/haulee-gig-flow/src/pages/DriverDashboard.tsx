import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Package, DollarSign, MapPin, Clock, FileText, MessageSquare, HelpCircle, User, Star, Calendar, AlertTriangle, Lock, Unlock } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Header } from '@/components/dashboard/Header';
import { DashboardTopCard } from '@/components/dashboard/DashboardTopCard';
import { BottomNav } from '@/components/dashboard/BottomNav';
import { PickUpNowWidget } from '@/components/driver/widgets/PickUpNowWidget';
import { ScheduledJobsWidget } from '@/components/driver/widgets/ScheduledJobsWidget';
import { EarningsOverviewWidget } from '@/components/driver/widgets/EarningsOverviewWidget';
import { ActiveJobsWidget } from '@/components/driver/widgets/ActiveJobsWidget';

import { DriverJobs } from '@/components/driver/DriverJobs';
import { DriverEarnings } from '@/components/driver/DriverEarnings';
import { DriverRatings } from '@/components/driver/DriverRatings';
import { DriverNotifications } from '@/components/driver/DriverNotifications';
import { DriverProfile } from '@/components/driver/DriverProfile';
import { DriverDisputes } from '@/components/driver/DriverDisputes';
import { useLanguageSync } from '@/hooks/useLanguageSync';
import { SafeModeProvider, useSafeMode } from '@/contexts/SafeModeContext';

function DriverDashboardContent() {
  const { t } = useTranslation();
  useLanguageSync(); // Sync language preference from database
  const { user } = useAuth();
  const { isSafeModeActive, toggleSafeMode } = useSafeMode();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [activeJobsSubTab, setActiveJobsSubTab] = useState('planned');
  const [navigateToActiveJobs, setNavigateToActiveJobs] = useState(false);

  useEffect(() => {
    if (navigateToActiveJobs && activeTab === 'jobs') {
      setActiveJobsSubTab('active');
      setNavigateToActiveJobs(false);
    }
  }, [navigateToActiveJobs, activeTab]);

  const companyName = user?.user_metadata?.company_name || user?.user_metadata?.first_name || user?.email?.split('@')[0] || 'Driver';

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="container mx-auto px-3 sm:px-4 py-3 sm:py-4 md:py-6 lg:py-8 pb-[calc(env(safe-area-inset-bottom)+80px)] md:pb-6 overflow-y-auto scrollbar-hide md:scrollbar-visible flex-1">
        {/* Safe Mode Banner */}
        {isSafeModeActive && (
          <Alert className="border-amber-500/50 bg-amber-500/10 mb-4">
            <Lock className="h-4 w-4 text-amber-500" />
            <AlertDescription className="text-amber-700 dark:text-amber-400">
              <strong>Safe Mode Active:</strong> All actions are disabled. You can only view data.
            </AlertDescription>
          </Alert>
        )}

        {/* Safe Mode Toggle */}
        <div className="flex justify-end mb-4">
          <Button
            variant={isSafeModeActive ? "default" : "outline"}
            size="sm"
            onClick={toggleSafeMode}
            className="gap-2"
          >
            {isSafeModeActive ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
            {isSafeModeActive ? 'Disable Safe Mode' : 'Enable Safe Mode'}
          </Button>
        </div>

        {/* Navigation Tabs - Desktop Only */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-3 sm:space-y-4 md:space-y-6">
          <div className="relative hidden md:block">
            <TabsList className="w-full inline-flex h-auto p-1 overflow-x-auto overflow-y-hidden scrollbar-hide">
              <TabsTrigger value="dashboard" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <Package className="h-3 w-3 md:h-4 md:w-4" />
                <span>Dashboard</span>
              </TabsTrigger>
              <TabsTrigger value="jobs" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <MapPin className="h-3 w-3 md:h-4 md:w-4" />
                <span>Jobs</span>
              </TabsTrigger>
              <TabsTrigger value="earnings" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <DollarSign className="h-3 w-3 md:h-4 md:w-4" />
                <span>{t('driver.dashboard.earnings')}</span>
              </TabsTrigger>
              <TabsTrigger value="history" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <Clock className="h-3 w-3 md:h-4 md:w-4" />
                <span>{t('driver.dashboard.history')}</span>
              </TabsTrigger>
              <TabsTrigger value="messages" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <MessageSquare className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden lg:inline">Messages</span>
                <span className="lg:hidden">Msgs</span>
              </TabsTrigger>
              <TabsTrigger value="documents" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <FileText className="h-3 w-3 md:h-4 md:w-4" />
                <span className="hidden lg:inline">Documents</span>
                <span className="lg:hidden">Docs</span>
              </TabsTrigger>
              <TabsTrigger value="support" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <HelpCircle className="h-3 w-3 md:h-4 md:w-4" />
                <span>Support</span>
              </TabsTrigger>
              <TabsTrigger value="ratings" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <Star className="h-3 w-3 md:h-4 md:w-4" />
                <span>{t('driver.dashboard.ratings')}</span>
              </TabsTrigger>
              <TabsTrigger value="disputes" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <AlertTriangle className="h-3 w-3 md:h-4 md:w-4" />
                <span>{t('driver.dashboard.disputes')}</span>
              </TabsTrigger>
              <TabsTrigger value="profile" className="flex-shrink-0 gap-1 sm:gap-2 text-xs md:text-sm px-2 md:px-3">
                <User className="h-3 w-3 md:h-4 md:w-4" />
                <span>{t('driver.dashboard.profile')}</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Dashboard Tab with Sub-sections */}
          <TabsContent value="dashboard" className="space-y-3 sm:space-y-4 md:space-y-6">
            {/* Top Card */}
            <DashboardTopCard
              companyName={companyName}
              motivationalText="Drive safely, earn confidently"
              showOnlineToggle={!isSafeModeActive}
              avatarUrl={user?.user_metadata?.avatar_url}
            />
            
            <Tabs defaultValue="pickup" className="space-y-2 sm:space-y-3 md:space-y-4">
              <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-9 sm:h-10">
                <TabsTrigger value="pickup" className="text-xs sm:text-sm px-1 sm:px-2">{t('driver.widgets.pickUpNow')}</TabsTrigger>
                <TabsTrigger value="scheduled" className="text-xs sm:text-sm px-1 sm:px-2">{t('driver.jobs.scheduled')}</TabsTrigger>
                <TabsTrigger value="routes" className="text-xs sm:text-sm px-1 sm:px-2">{t('driver.jobs.route')}</TabsTrigger>
              </TabsList>

              <TabsContent value="pickup">
                <div className="grid gap-3.5 sm:gap-4.5 md:gap-7 md:grid-cols-2">
                  <PickUpNowWidget />
                  <div className="space-y-3.5 sm:space-y-4.5 md:space-y-7">
                    <ActiveJobsWidget 
                      onJobClick={(jobId) => {
                        setNavigateToActiveJobs(true);
                        setActiveTab('jobs');
                      }}
                    />
                    <EarningsOverviewWidget />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="scheduled">
                <ScheduledJobsWidget />
              </TabsContent>

              <TabsContent value="routes">
                <Card className="p-3.5 sm:p-4.5 md:p-7">
                  <h3 className="text-sm sm:text-base md:text-lg font-semibold mb-3 sm:mb-4">{t('driver.jobs.routeManagement')}</h3>
                  <p className="text-xs sm:text-sm md:text-base text-muted-foreground">Route planning and history will appear here</p>
                </Card>
              </TabsContent>
            </Tabs>
          </TabsContent>

          {/* My Jobs Tab with Sub-sections */}
          <TabsContent value="jobs" className="">
            <div className="space-y-4 sm:space-y-6">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold">{t('driver.dashboard.availableJobs')}</h2>
                <p className="text-sm text-muted-foreground">Manage your delivery jobs</p>
              </div>

              <Tabs value={activeJobsSubTab} onValueChange={setActiveJobsSubTab} className="space-y-4 sm:space-y-6">
                <div className="sticky top-0 bg-background z-10 pb-2">
                  <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-9 sm:h-10">
                    <TabsTrigger value="planned" className="text-xs sm:text-sm px-1 sm:px-2">{t('driver.jobs.planned')}</TabsTrigger>
                    <TabsTrigger value="active" className="text-xs sm:text-sm px-1 sm:px-2">{t('driver.jobs.myJobs')}</TabsTrigger>
                    <TabsTrigger value="completed" className="text-xs sm:text-sm px-1 sm:px-2">{t('driver.jobs.completedJobs')}</TabsTrigger>
                  </TabsList>
                </div>

                <TabsContent value="planned" className="space-y-3.5 sm:space-y-4.5">
                  <div className="grid gap-3.5 sm:gap-4.5">
                    <Card className="p-3.5 sm:p-4.5 md:p-7">
                      <h3 className="text-base sm:text-lg font-semibold flex items-center gap-2 mb-3 sm:mb-4">
                        <Calendar className="h-4 w-4 sm:h-5 sm:w-5" />
                        Scheduled Delivery
                      </h3>
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center gap-2 text-xs sm:text-sm">
                            <Clock className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                            <span>Tomorrow at 10:00 AM</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                            <MapPin className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span>123 Main St → 456 Oak Ave</span>
                          </div>
                        </div>
                        <Badge variant="default">Confirmed</Badge>
                      </div>
                    </Card>

                    <Card className="p-3.5 sm:p-4.5 md:p-7">
                      <h3 className="text-base sm:text-lg font-semibold flex items-center gap-2 mb-3 sm:mb-4">
                        <Calendar className="h-4 w-4 sm:h-5 sm:w-5" />
                        Weekend Pickup
                      </h3>
                      <div className="flex items-start justify-between gap-2">
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center gap-2 text-xs sm:text-sm">
                            <Clock className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                            <span>Saturday at 2:00 PM</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs sm:text-sm text-muted-foreground">
                            <MapPin className="h-3 w-3 sm:h-4 sm:w-4" />
                            <span>789 Pine Rd → 321 Elm St</span>
                          </div>
                        </div>
                        <Badge variant="secondary">Pending</Badge>
                      </div>
                    </Card>
                  </div>
                </TabsContent>

                <TabsContent value="active" className="space-y-3.5 sm:space-y-4.5">
                  <DriverJobs />
                </TabsContent>

                <TabsContent value="completed" className="space-y-3.5 sm:space-y-4.5">
                  <div className="grid gap-3.5 sm:gap-4.5">
                    <Card className="p-3.5 sm:p-4.5 md:p-7">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-base sm:text-lg font-semibold">Grocery Delivery</h3>
                        <Badge variant="secondary">$45.00</Badge>
                      </div>
                      <p className="text-xs sm:text-sm text-muted-foreground mb-4">Completed 2 hours ago</p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs sm:text-sm">
                          <span>Distance:</span>
                          <span>4.2 miles</span>
                        </div>
                        <div className="flex items-center justify-between text-xs sm:text-sm">
                          <span>Duration:</span>
                          <span>1h 15m</span>
                        </div>
                        <div className="flex items-center justify-between text-xs sm:text-sm">
                          <span>Rating:</span>
                          <span>⭐⭐⭐⭐⭐</span>
                        </div>
                      </div>
                    </Card>

                    <Card className="p-3.5 sm:p-4.5 md:p-7">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-base sm:text-lg font-semibold">Package Delivery</h3>
                        <Badge variant="secondary">$30.00</Badge>
                      </div>
                      <p className="text-xs sm:text-sm text-muted-foreground mb-4">Completed yesterday</p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs sm:text-sm">
                          <span>Distance:</span>
                          <span>6.1 miles</span>
                        </div>
                        <div className="flex items-center justify-between text-xs sm:text-sm">
                          <span>Duration:</span>
                          <span>2h 30m</span>
                        </div>
                        <div className="flex items-center justify-between text-xs sm:text-sm">
                          <span>Rating:</span>
                          <span>⭐⭐⭐⭐</span>
                        </div>
                      </div>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </TabsContent>

          <TabsContent value="earnings" className="">
            <DriverEarnings />
          </TabsContent>

          <TabsContent value="history" className="">
            <Card>
              <CardHeader className="p-3 sm:p-4 md:p-6">
                <CardTitle className="text-sm sm:text-base md:text-lg">Job History</CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6">
                <p className="text-xs sm:text-sm md:text-base text-muted-foreground">Your completed jobs and history will appear here</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages" className="">
            <Card>
              <CardHeader className="p-3 sm:p-4 md:p-6">
                <CardTitle className="text-sm sm:text-base md:text-lg">Messages</CardTitle>
              </CardHeader>
              <CardContent className="p-3 sm:p-4 md:p-6">
                <p className="text-xs sm:text-sm md:text-base text-muted-foreground">Your messages and communications will appear here</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents" className="">
            <Card className="p-3.5 sm:p-4.5 md:p-7">
              <h3 className="text-sm sm:text-base md:text-lg font-semibold mb-3 sm:mb-4">Documents Center</h3>
              <p className="text-xs sm:text-sm md:text-base text-muted-foreground">Your documents, licenses, and certifications will appear here</p>
            </Card>
          </TabsContent>

          <TabsContent value="support" className="">
            <Card className="p-3.5 sm:p-4.5 md:p-7">
              <h3 className="text-sm sm:text-base md:text-lg font-semibold mb-3 sm:mb-4">Support</h3>
              <p className="text-xs sm:text-sm md:text-base text-muted-foreground">Get help and support for your account</p>
            </Card>
          </TabsContent>

          <TabsContent value="ratings" className="">
            <DriverRatings />
          </TabsContent>

          <TabsContent value="disputes" className="">
            <DriverDisputes />
          </TabsContent>

          <TabsContent value="profile" className="">
            <DriverProfile />
          </TabsContent>
        </Tabs>
      </main>

      {/* Mobile Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}

export default function DriverDashboard() {
  return (
    <SafeModeProvider>
      <DriverDashboardContent />
    </SafeModeProvider>
  );
}