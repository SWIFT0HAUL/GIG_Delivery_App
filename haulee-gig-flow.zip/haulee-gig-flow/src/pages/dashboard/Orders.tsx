import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Package } from 'lucide-react';
import { Permission } from '@/hooks/useRBACMenu';

interface DashboardOrdersProps {
  permissions: Permission[];
}

export const DashboardOrders: React.FC<DashboardOrdersProps> = ({ permissions }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Package className="h-8 w-8" />
          Orders
        </h1>
        <p className="text-muted-foreground">Manage all orders and shipments</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Order Management</CardTitle>
          <CardDescription>View and track all orders</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Order management features coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
};