import { LeafletTrackingMap } from '@/components/maps/LeafletTrackingMap';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation } from 'lucide-react';

export default function LiveTracking() {
  const handleRecenter = () => {
    window.location.reload(); // Simple recenter by reloading
  };

  return (
    <div className="min-h-screen bg-background p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Live Tracking</h1>
          <p className="text-sm text-muted-foreground">Real-time location monitoring</p>
        </div>
        <Button onClick={handleRecenter} variant="outline" size="sm">
          <Navigation className="w-4 h-4 mr-2" />
          Recenter
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Your Current Location
          </CardTitle>
        </CardHeader>
        <CardContent>
          <LeafletTrackingMap 
            className="h-[70vh] w-full rounded-lg"
            showAccuracy={true}
            autoCenter={true}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tracking Info</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-muted-foreground">Update Frequency:</span>
            <span className="font-medium">Real-time</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">High Accuracy:</span>
            <span className="font-medium">Enabled</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">Location Source:</span>
            <span className="font-medium">GPS</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
