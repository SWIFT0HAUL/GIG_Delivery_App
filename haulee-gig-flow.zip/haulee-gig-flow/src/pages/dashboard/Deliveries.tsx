import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Truck } from 'lucide-react';
import { Permission } from '@/hooks/useRBACMenu';

interface DashboardDeliveriesProps {
  permissions: Permission[];
}

export const DashboardDeliveries: React.FC<DashboardDeliveriesProps> = ({ permissions }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Truck className="h-8 w-8" />
          Deliveries
        </h1>
        <p className="text-muted-foreground">Track and manage deliveries</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Delivery Tracking</CardTitle>
          <CardDescription>Monitor all active deliveries</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Delivery tracking features coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
};