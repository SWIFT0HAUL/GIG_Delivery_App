import React from 'react';
import { AvailableJobsWidget } from '@/components/driver/widgets/AvailableJobsWidget';

export const DriverAvailableJobs: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Main Scrollable Content */}
      <main className="flex-1 overflow-y-auto pb-[80px] md:pb-4">
        <AvailableJobsWidget />
      </main>
    </div>
  );
};
