import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText } from 'lucide-react';
import { Permission } from '@/hooks/useRBACMenu';

interface DashboardReportsProps {
  permissions: Permission[];
}

export const DashboardReports: React.FC<DashboardReportsProps> = ({ permissions }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <FileText className="h-8 w-8" />
          Reports & Analytics
        </h1>
        <p className="text-muted-foreground">View detailed reports and insights</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Analytics Dashboard</CardTitle>
          <CardDescription>Comprehensive platform analytics</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Analytics and reporting features coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
};