import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DashboardTopCard } from '@/components/dashboard/DashboardTopCard';
import { EarningsOverviewWidget } from '@/components/driver/widgets/EarningsOverviewWidget';


import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export const DriverHome: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const companyName = user?.user_metadata?.company_name || user?.user_metadata?.first_name || user?.email?.split('@')[0] || 'Driver';

  return (
    <div className="space-y-4 w-full max-w-full overflow-x-hidden">
      {/* Top Card */}
      <DashboardTopCard
        companyName={companyName}
        motivationalText="Drive safely, earn confidently"
        avatarUrl={user?.user_metadata?.avatar_url}
      />

      {/* Dashboard Overview */}
      <div className="flex flex-col xl:grid xl:grid-cols-2 gap-3 w-full max-w-full">
        <EarningsOverviewWidget />
        <Card className="p-3 w-full max-w-full">
          <CardHeader className="p-0 pb-3">
            <CardTitle className="text-sm font-medium">Quick Stats</CardTitle>
          </CardHeader>
          <CardContent className="p-0 grid grid-cols-2 gap-3">
            <div>
              <p className="text-xl font-bold">8</p>
              <p className="text-xs text-muted-foreground">Jobs Today</p>
            </div>
            <div>
              <p className="text-xl font-bold">4.8</p>
              <p className="text-xs text-muted-foreground">Avg Rating</p>
            </div>
          </CardContent>
        </Card>
      </div>

      
    </div>
  );
};
