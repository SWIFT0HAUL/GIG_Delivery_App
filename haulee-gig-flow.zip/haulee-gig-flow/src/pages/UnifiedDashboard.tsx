import React, { useRef, useEffect } from "react";
import { useRBACMenu } from "@/hooks/useRBACMenu";
import { useUserRole } from "@/hooks/useUserRole";
import { Sidebar } from "@/components/dashboard/Sidebar";
import { Header } from "@/components/dashboard/Header";
import { NoPermissions } from "@/components/dashboard/NoPermissions";
import { Skeleton } from "@/components/ui/skeleton";
import { Routes, Route, Navigate, useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BottomNav } from "@/components/dashboard/BottomNav";
import { StickyHorizontalScrollbar } from "@/components/dashboard/StickyHorizontalScrollbar";

// Generic Dashboard pages
import { DashboardHome } from "./dashboard/Home";
import { DashboardUsers } from "./dashboard/Users";
import { DashboardOrders } from "./dashboard/Orders";
import { DashboardDeliveries } from "./dashboard/Deliveries";
import { DashboardReports } from "./dashboard/Reports";

// Role-specific dashboard home pages
import { DriverHome } from "./dashboard/DriverHome";
import { DriverAvailableJobs } from "./dashboard/DriverAvailableJobs";

// Driver components
import { DriverJobs } from "@/components/driver/DriverJobs";
import { DriverEarnings } from "@/components/driver/DriverEarnings";
import { DriverRatings } from "@/components/driver/DriverRatings";
import { DriverProfile } from "@/components/driver/DriverProfile";
import { DriverSchedule } from "@/components/driver/DriverSchedule";
import { DriverHistory } from "@/components/driver/DriverHistory";
import { DriverExpenses } from "@/components/driver/DriverExpenses";
import { DriverDisputes } from "@/components/driver/DriverDisputes";
import LiveTracking from "./dashboard/LiveTracking";

// Admin/Super Admin components
import { SuperAdminUserManager } from "@/components/admin/SuperAdminUserManager";
import { SuperAdminSystemSettings } from "@/components/admin/SuperAdminSystemSettings";
import { SuperAdminAuditLogs } from "@/components/admin/SuperAdminAuditLogs";
import { SuperAdminPanel } from "@/components/admin/SuperAdminPanel";
import { UserManagement } from "@/components/admin/UserManagement";
import { TasksManagement } from "@/components/admin/TasksManagement";
import { KYCManagement } from "@/components/admin/KYCManagement";
import { TimesheetManagement } from "@/components/admin/TimesheetManagement";
import FinanceAccounting from "@/components/admin/FinanceAccounting";
import { W9Management } from "@/components/admin/W9Management";
import { PlatformSettings } from "@/components/admin/PlatformSettings";
import { DocumentationCenter } from "@/components/admin/DocumentationCenter";
import { RoleManagement } from "@/components/admin/RoleManagement";
import { PermissionManagement } from "@/components/admin/PermissionManagement";
import MenuManagement from "@/components/admin/MenuManagement";
import { SubRolePermissionsMatrix } from "@/components/admin/SubRolePermissionsMatrix";
import { RoleSubRoleRelationships } from "@/components/admin/RoleSubRoleRelationships";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { JobsManagement } from "@/pages/admin/JobsManagement";

import { PlatformIntegrations } from "@/components/admin/PlatformIntegrations";
import { ChecklistManagement } from "@/pages/ChecklistManagement";
import { SafeModeProvider } from '@/contexts/SafeModeContext';

const UnifiedDashboardContent: React.FC = () => {
  const { menus, permissions, loading, error } = useRBACMenu();
  const { profile, loading: roleLoading, hasSuperAdminAccess } = useUserRole();
  const navigate = useNavigate();
  const mainRef = useRef<HTMLDivElement>(null);

  // Redirect super admins to app admin dashboard
  useEffect(() => {
    if (!roleLoading && hasSuperAdminAccess()) {
      navigate('/admin-dashboard', { replace: true });
    }
  }, [roleLoading, hasSuperAdminAccess, navigate]);

  const isDriver = profile?.role_name === "driver";
  const isAdmin = profile?.role_name === "admin" || profile?.role_name === "super_admin";

  const handleBottomNavChange = (tab: string) => {
  const routeMap: Record<string, string> = {
    dashboard: "driver-home",
    available: "available-jobs",
    jobs: "my-jobs",
    tracking: "live-tracking",
    earnings: "driver-earnings",
    disputes: "driver-disputes",
    profile: "driver-profile",
  };
  navigate(routeMap[tab] || tab);
};

  // Get active tab from current path
const getCurrentTab = () => {
  const path = window.location.pathname.split("/").pop() || "";
  const tabMap: Record<string, string> = {
    "driver-home": "dashboard",
    "available-jobs": "available",
    "my-jobs": "jobs",
    "live-tracking": "tracking",
    "driver-earnings": "earnings",
    "driver-disputes": "disputes",
    "driver-profile": "profile",
  };
  return tabMap[path] || "dashboard";
};

  // Driver menu items
  const driverMenus = [
    { id: "1", name: "Dashboard", path: "driver-home", icon: "Home", category: "Main", display_order: 1, is_active: true },
    { id: "2", name: "My Jobs", path: "my-jobs", icon: "Truck", category: "Main", display_order: 2, is_active: true },
    { id: "3", name: "Available Jobs", path: "available-jobs", icon: "Search", category: "Main", display_order: 3, is_active: true },
    { id: "3.5", name: "Live Tracking", path: "live-tracking", icon: "Navigation", category: "Main", display_order: 3.5, is_active: true },
    { id: "4", name: "Earnings", path: "driver-earnings", icon: "DollarSign", category: "Financial", display_order: 4, is_active: true },
    { id: "5", name: "Schedule", path: "driver-schedule", icon: "Calendar", category: "Planning", display_order: 5, is_active: true },
    { id: "7", name: "History", path: "driver-history", icon: "History", category: "Records", display_order: 7, is_active: true },
    { id: "8", name: "Ratings", path: "driver-ratings", icon: "Star", category: "Records", display_order: 8, is_active: true },
    { id: "9", name: "Documents", path: "driver-documents", icon: "FileText", category: "Account", display_order: 9, is_active: true },
    { id: "10", name: "Vehicle", path: "driver-vehicle", icon: "Car", category: "Account", display_order: 10, is_active: true },
    { id: "11", name: "Expenses", path: "driver-expenses", icon: "Receipt", category: "Financial", display_order: 11, is_active: true },
    { id: "12", name: "Settings", path: "driver-profile", icon: "User", category: "Account", display_order: 12, is_active: true },
  ];

  if (loading || roleLoading) {
    return (
      <div className="min-h-screen flex">
        <div className="w-64 border-r p-4">
          <Skeleton className="h-8 w-full mb-4" />
          <Skeleton className="h-10 w-full mb-2" />
          <Skeleton className="h-10 w-full mb-2" />
          <Skeleton className="h-10 w-full mb-2" />
        </div>
        <div className="flex-1">
          <Skeleton className="h-16 w-full" />
          <div className="p-6">
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  // Admin and Super Admin have full access; only non-driver users without menus see NoPermissions
  if (!isAdmin && !isDriver && (error || menus.length === 0)) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <NoPermissions />
      </div>
    );
  }

  // Determine default route based on current path and role
  const getDefaultRoute = () => {
    const currentPath = window.location.pathname;

    // Map roles to their dashboard home pages
    const roleRoutes: Record<string, string> = {
      driver: "driver-home",
      admin: "admin-jobs",
      super_admin: "admin-jobs",
    };

    // If we have a role, use the role-specific default
    if (profile?.role_name && roleRoutes[profile.role_name]) {
      return roleRoutes[profile.role_name];
    }

    // Fallback to generic home
    return "home";
  };

  // Placeholder component for features under development
  const PlaceholderPage: React.FC<{ title: string; description?: string }> = ({ title, description }) => (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">
          {description || "This section is under development and will be available soon."}
        </p>
      </CardContent>
    </Card>
  );

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Sidebar - Hidden on mobile, visible on tablet and desktop */}
      <Sidebar menus={isDriver ? driverMenus : menus} />

      {/* Main content area with left margin on tablet and desktop only */}
      <div className="flex-1 flex flex-col md:ml-64 overflow-hidden">
        <Header />
        <main ref={mainRef} className="flex-1 py-3 sm:py-4 md:py-6 bg-muted/30 overflow-y-auto scrollbar-hide md:scrollbar-visible pb-20 md:pb-6">
          <div className="max-w-7xl mx-auto px-3 sm:px-4 space-y-6">
            <Routes>
            {/* Generic pages */}
            <Route path="home" element={<DashboardHome permissions={permissions} />} />
            <Route path="users" element={<DashboardUsers permissions={permissions} />} />
            <Route path="orders" element={<DashboardOrders permissions={permissions} />} />
            <Route path="deliveries" element={<DashboardDeliveries permissions={permissions} />} />
            <Route path="reports" element={<DashboardReports permissions={permissions} />} />

            {/* Driver Routes */}
            <Route path="driver-home" element={<DriverHome />} />
            <Route path="my-jobs" element={<DriverJobs />} />
            <Route path="available-jobs" element={<DriverAvailableJobs />} />
            <Route path="live-tracking" element={<LiveTracking />} />
            {/* Legacy redirects */}
            <Route path="driver-jobs" element={<Navigate to="/driver-dashboard/my-jobs" replace />} />
            <Route path="driver-available-jobs" element={<Navigate to="/driver-dashboard/available-jobs" replace />} />
            <Route path="driver-active-jobs" element={<Navigate to="/driver-dashboard/my-jobs" replace />} />
            <Route path="driver-history" element={<DriverHistory />} />
            <Route path="driver-earnings" element={<DriverEarnings />} />
            <Route path="driver-schedule" element={<DriverSchedule />} />
            <Route path="driver-ratings" element={<DriverRatings />} />
            <Route
              path="driver-documents"
              element={<PlaceholderPage title="Documents" description="License, insurance, and certifications" />}
            />
            <Route path="driver-vehicle" element={<PlaceholderPage title="Vehicle Information" />} />
            <Route
              path="driver-routes"
              element={<PlaceholderPage title="Route Planner" description="Plan and optimize your routes" />}
            />
            <Route path="driver-expenses" element={<DriverExpenses />} />
            <Route path="driver-profile" element={<DriverProfile />} />

            {/* Admin/Super Admin Routes - CORE */}
            <Route
              path="admin-dashboard"
              element={
                <PlaceholderPage title="Admin Dashboard" description="Overview of system metrics and activity" />
              }
            />
            <Route path="admin-users" element={<UserManagement />} />
            <Route path="admin-jobs" element={<JobsManagement />} />
            <Route path="admin-kyc" element={<KYCManagement />} />
            <Route
              path="admin-rbac"
              element={
                <Tabs defaultValue="permissions" className="w-full">
                  <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="permissions">Permissions</TabsTrigger>
                    <TabsTrigger value="roles">Roles</TabsTrigger>
                    <TabsTrigger value="subrole-matrix">SubRole Matrix</TabsTrigger>
                    <TabsTrigger value="relationships">Role Relationships</TabsTrigger>
                    <TabsTrigger value="menus">Menu Management</TabsTrigger>
                  </TabsList>
                  <TabsContent value="permissions">
                    <PermissionManagement />
                  </TabsContent>
                  <TabsContent value="roles">
                    <RoleManagement />
                  </TabsContent>
                  <TabsContent value="subrole-matrix">
                    <SubRolePermissionsMatrix />
                  </TabsContent>
                  <TabsContent value="relationships">
                    <RoleSubRoleRelationships />
                  </TabsContent>
                  <TabsContent value="menus">
                    <MenuManagement />
                  </TabsContent>
                </Tabs>
              }
            />
            <Route path="admin-timesheet" element={<TimesheetManagement />} />
            <Route path="admin-super" element={<SuperAdminPanel />} />

            {/* Admin/Super Admin Routes - CONTENT */}
            <Route path="admin-content" element={<DocumentationCenter />} />
            <Route path="admin-tasks" element={<TasksManagement />} />
            <Route path="admin-checklists" element={<ChecklistManagement />} />

            {/* Admin/Super Admin Routes - FINANCIALS */}
            <Route path="admin-finance" element={<FinanceAccounting />} />
            <Route path="admin-w9" element={<W9Management />} />

            {/* Admin/Super Admin Routes - PLATFORM */}
            <Route path="admin-settings" element={<PlatformSettings />} />
            <Route
              path="admin-advanced-settings"
              element={<PlaceholderPage title="Advanced Settings" description="Advanced system configuration and developer options" />}
            />
            <Route
              path="admin-data"
              element={<PlaceholderPage title="Data Management" description="Manage platform data and exports" />}
            />
            <Route path="admin-integrations" element={<PlatformIntegrations />} />
            
            {/* Settings route for consistency */}
            <Route path="settings" element={<PlatformSettings />} />

            {/* Admin/Super Admin Routes - MONITORING & SUPPORT */}
            <Route
              path="admin-support"
              element={
                <PlaceholderPage title="Support Center" description="Manage user support tickets and inquiries" />
              }
            />
            <Route
              path="admin-notifications"
              element={<PlaceholderPage title="Notification Management" description="Manage platform notifications" />}
            />
            <Route
              path="admin-maintenance"
              element={
                <PlaceholderPage title="System Maintenance" description="System maintenance and health checks" />
              }
            />

            {/* Legacy/Generic Routes */}
            <Route path="jobs" element={<DriverJobs />} />
            <Route path="earnings" element={<DriverEarnings />} />
<Route path="ratings" element={<DriverRatings />} />
<Route path="driver-disputes" element={<DriverDisputes />} />
<Route path="profile" element={<DriverProfile />} />
            <Route path="history" element={<PlaceholderPage title="History" />} />
            <Route path="messages" element={<PlaceholderPage title="Messages" />} />
            <Route path="documents" element={<PlaceholderPage title="Documents" />} />
            <Route path="support" element={<Navigate to="/support" replace />} />
            <Route path="notifications" element={<Navigate to="/notifications" replace />} />

            <Route path="*" element={<Navigate to={getDefaultRoute()} replace />} />
            </Routes>
          </div>
        </main>
        <StickyHorizontalScrollbar targetRef={mainRef} />
      </div>

      {/* Bottom Navigation - Only show for drivers on mobile */}
      {isDriver && <BottomNav activeTab={getCurrentTab()} onTabChange={handleBottomNavChange} />}
    </div>
  );
};

export const UnifiedDashboard: React.FC = () => {
  return (
    <SafeModeProvider>
      <UnifiedDashboardContent />
    </SafeModeProvider>
  );
};
