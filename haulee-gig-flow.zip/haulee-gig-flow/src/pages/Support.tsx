import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { HelpCircle, Send, Ticket, Clock, CheckCircle2, XCircle, MessageSquare, Paperclip, User, Phone, X } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import DriverSupportChat from '@/components/support/DriverSupportChat';
interface SupportTicket {
  id: string;
  user_id: string;
  role: string;
  category: string;
  subject: string;
  message: string;
  status: 'open' | 'in_progress' | 'resolved' | 'closed';
  assigned_to: string | null;
  file_path: string | null;
  created_at: string;
  updated_at: string;
}
interface TicketReply {
  id: string;
  ticket_id: string;
  user_id: string;
  message: string;
  is_admin_reply: boolean;
  file_path: string | null;
  created_at: string;
}
const getCategoryOptions = (role: string) => {
  const commonCategories = ['Technical Issue', 'Account Management', 'Billing & Payments', 'General Inquiry', 'Feature Request', 'Bug Report'];
  const roleSpecificCategories: Record<string, string[]> = {
    carrier: ['Dispatch Issues', 'Fleet Management', 'Delivery Problems'],
    driver: ['Vehicle Issues', 'Route Problems', 'Payment Disputes', 'Job Assignment'],
    vendor_merchant: ['Inventory', 'Product Listing', 'Payout Issues'],
    shipper: ['Shipment Tracking', 'Delivery Status', 'Quote Request'],
    broker: ['Contract Issues', 'Client Management', 'Compliance']
  };
  return [...commonCategories, ...(roleSpecificCategories[role] || [])];
};
const getStatusIcon = (status: string) => {
  switch (status) {
    case 'open':
      return <Clock className="h-4 w-4" />;
    case 'in_progress':
      return <MessageSquare className="h-4 w-4" />;
    case 'resolved':
      return <CheckCircle2 className="h-4 w-4" />;
    case 'closed':
      return <XCircle className="h-4 w-4" />;
    default:
      return <Ticket className="h-4 w-4" />;
  }
};
const getStatusColor = (status: string) => {
  switch (status) {
    case 'open':
      return 'bg-blue-500/10 text-blue-500 border-blue-500/20';
    case 'in_progress':
      return 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20';
    case 'resolved':
      return 'bg-green-500/10 text-green-500 border-green-500/20';
    case 'closed':
      return 'bg-gray-500/10 text-gray-500 border-gray-500/20';
    default:
      return 'bg-muted text-muted-foreground';
  }
};
export default function Support() {
  const navigate = useNavigate();
  const {
    user
  } = useAuth();
  const {
    profile
  } = useUserRole();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [ticketReplies, setTicketReplies] = useState<TicketReply[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('submit');
  const [replyMessage, setReplyMessage] = useState('');
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({
    category: '',
    subject: '',
    message: ''
  });
  useEffect(() => {
    if (user?.id && profile?.role_name) {
      fetchTickets();
      setupRealtimeSubscription();
    }
  }, [user?.id, profile?.role_name]);
  useEffect(() => {
    if (selectedTicket) {
      fetchTicketReplies(selectedTicket.id);
    }
  }, [selectedTicket]);
  const fetchTickets = async () => {
    try {
      setLoading(true);
      const {
        data,
        error
      } = await (supabase as any).from('support_tickets').select('*').eq('user_id', user!.id).order('created_at', {
        ascending: false
      });
      if (error) throw error;
      setTickets(data || []);
    } catch (error) {
      console.error('Error fetching tickets:', error);
      toast.error('Failed to load support tickets');
    } finally {
      setLoading(false);
    }
  };
  const fetchTicketReplies = async (ticketId: string) => {
    try {
      const {
        data,
        error
      } = await (supabase as any).from('support_ticket_replies').select('*').eq('ticket_id', ticketId).order('created_at', {
        ascending: true
      });
      if (error) throw error;
      setTicketReplies(data || []);
    } catch (error) {
      console.error('Error fetching replies:', error);
      toast.error('Failed to load ticket replies');
    }
  };
  const setupRealtimeSubscription = () => {
    const ticketsChannel = supabase.channel('tickets-changes').on('postgres_changes', {
      event: '*',
      schema: 'public',
      table: 'support_tickets',
      filter: `user_id=eq.${user!.id}`
    }, (payload: any) => {
      if (payload.eventType === 'INSERT') {
        setTickets(prev => [payload.new as SupportTicket, ...prev]);
      } else if (payload.eventType === 'UPDATE') {
        setTickets(prev => prev.map(t => t.id === payload.new.id ? payload.new as SupportTicket : t));
        if (selectedTicket?.id === payload.new.id) {
          setSelectedTicket(payload.new as SupportTicket);
        }
      }
    }).subscribe();
    const repliesChannel = supabase.channel('replies-changes').on('postgres_changes', {
      event: 'INSERT',
      schema: 'public',
      table: 'support_ticket_replies'
    }, (payload: any) => {
      if (selectedTicket && payload.new.ticket_id === selectedTicket.id) {
        setTicketReplies(prev => [...prev, payload.new as TicketReply]);
      }
    }).subscribe();
    return () => {
      supabase.removeChannel(ticketsChannel);
      supabase.removeChannel(repliesChannel);
    };
  };
  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.category || !formData.subject || !formData.message) {
      toast.error('Please fill in all required fields');
      return;
    }
    try {
      const {
        error
      } = await (supabase as any).from('support_tickets').insert({
        user_id: user!.id,
        role: profile!.role_name!,
        category: formData.category,
        subject: formData.subject,
        message: formData.message,
        file_path: uploadedFile
      });
      if (error) throw error;
      toast.success('Support ticket submitted successfully');
      setFormData({
        category: '',
        subject: '',
        message: ''
      });
      setUploadedFile(null);
      setActiveTab('tickets');
      fetchTickets();
    } catch (error) {
      console.error('Error submitting ticket:', error);
      toast.error('Failed to submit support ticket');
    }
  };
  const handleSendReply = async () => {
    if (!replyMessage.trim() || !selectedTicket) return;
    try {
      const {
        error
      } = await (supabase as any).from('support_ticket_replies').insert({
        ticket_id: selectedTicket.id,
        user_id: user!.id,
        message: replyMessage,
        is_admin_reply: false
      });
      if (error) throw error;
      setReplyMessage('');
      toast.success('Reply sent');
    } catch (error) {
      console.error('Error sending reply:', error);
      toast.error('Failed to send reply');
    }
  };
  const openTickets = tickets.filter(t => t.status === 'open' || t.status === 'in_progress');
  const resolvedTickets = tickets.filter(t => t.status === 'resolved' || t.status === 'closed');

  // Check if user is driver or carrier
  const isDriverOrCarrier = profile?.role_name === 'driver' || profile?.role_name === 'carrier';

  // Get dashboard path based on user role
  const getDashboardPath = () => {
    const roleName = profile?.role_name;
    if (!roleName) return '/dashboard';
    switch (roleName) {
      case 'driver':
        return '/driver-dashboard/driver-home';
      case 'shipper':
        return '/shipper-dashboard/shipper-home';
      case 'broker':
        return '/broker-dashboard/broker-home';
      case 'carrier':
        return '/carrier-dashboard/carrier-home';
      case 'vendor':
        return '/vendor-dashboard/vendor-home';
      case 'admin':
      case 'super_admin':
        return '/admin';
      default:
        return '/dashboard';
    }
  };
  return <div className="container mx-auto p-4 md:p-6 max-w-6xl">
      <div className="mb-6 flex items-start justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
            <HelpCircle className="h-8 w-8" />
            Support Center
          </h1>
          <p className="text-muted-foreground mt-1 text-sm">
            Get help with any issues or questions you have
          </p>
        </div>
        <Button variant="ghost" size="icon" onClick={() => navigate(getDashboardPath())} className="shrink-0">
          <X className="h-5 w-5" />
        </Button>
      </div>

      {/* Driver/Carrier Live Support Section */}
      {isDriverOrCarrier && <div className="mb-6">
          <Card className="border-primary/20 bg-primary/5">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Phone className="h-5 w-5 text-primary" />
                <CardTitle>Driver Support - Live Chat & Call</CardTitle>
              </div>
              <CardDescription>
                Get immediate help from our driver support team
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DriverSupportChat />
            </CardContent>
          </Card>
        </div>}

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3 mb-6">
          <TabsTrigger value="submit">Submit Ticket</TabsTrigger>
          <TabsTrigger value="tickets">
            My Tickets ({openTickets.length})
          </TabsTrigger>
          <TabsTrigger value="resolved">
            Resolved ({resolvedTickets.length})
          </TabsTrigger>
        </TabsList>

        {/* Submit Ticket Tab */}
        <TabsContent value="submit">
          <Card>
            <CardHeader>
              <CardTitle>Submit a Support Ticket</CardTitle>
              <CardDescription>
                Describe your issue and we'll get back to you as soon as possible
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmitTicket} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select value={formData.category} onValueChange={value => setFormData({
                  ...formData,
                  category: value
                })}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {getCategoryOptions(profile?.role_name || '').map(category => <SelectItem key={category} value={category}>
                          {category}
                        </SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="subject">Subject *</Label>
                  <Input id="subject" placeholder="Brief description of your issue" value={formData.subject} onChange={e => setFormData({
                  ...formData,
                  subject: e.target.value
                })} required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="message">Message *</Label>
                  <Textarea id="message" placeholder="Provide detailed information about your issue..." className="min-h-[150px]" value={formData.message} onChange={e => setFormData({
                  ...formData,
                  message: e.target.value
                })} required />
                </div>

                <div className="space-y-2">
                  <Label>Attachment (Optional)</Label>
                  <Input type="file" accept="image/*,.pdf,.doc,.docx" onChange={e => {
                  const file = e.target.files?.[0];
                  if (file) {
                    // Simple file handling - in production, upload to storage
                    setUploadedFile(file.name);
                  }
                }} />
                </div>

                <Button type="submit" className="w-full">
                  <Send className="h-4 w-4 mr-2" />
                  Submit Ticket
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* My Tickets Tab */}
        <TabsContent value="tickets" className="space-y-4">
          {loading ? <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Loading tickets...</p>
              </CardContent>
            </Card> : openTickets.length === 0 ? <Card>
              <CardContent className="p-8 text-center">
                <Ticket className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No open tickets</p>
              </CardContent>
            </Card> : openTickets.map(ticket => <Card key={ticket.id} className="cursor-pointer hover:shadow-md transition-all" onClick={() => setSelectedTicket(ticket)}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-2">
                        <CardTitle className="text-lg">{ticket.subject}</CardTitle>
                        <Badge variant="outline" className={cn("text-xs", getStatusColor(ticket.status))}>
                          {getStatusIcon(ticket.status)}
                          <span className="ml-1 capitalize">{ticket.status.replace('_', ' ')}</span>
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {ticket.category}
                        </Badge>
                      </div>
                      <CardDescription>
                        Ticket #{ticket.id.slice(0, 8)} • Created {formatDistanceToNow(new Date(ticket.created_at), {
                    addSuffix: true
                  })}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {ticket.message}
                  </p>
                </CardContent>
              </Card>)}
        </TabsContent>

        {/* Resolved Tab */}
        <TabsContent value="resolved" className="space-y-4">
          {resolvedTickets.length === 0 ? <Card>
              <CardContent className="p-8 text-center">
                <CheckCircle2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No resolved tickets</p>
              </CardContent>
            </Card> : resolvedTickets.map(ticket => <Card key={ticket.id} className="cursor-pointer hover:shadow-md transition-all" onClick={() => setSelectedTicket(ticket)}>
                <CardHeader>
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-2">
                        <CardTitle className="text-lg">{ticket.subject}</CardTitle>
                        <Badge variant="outline" className={cn("text-xs", getStatusColor(ticket.status))}>
                          {getStatusIcon(ticket.status)}
                          <span className="ml-1 capitalize">{ticket.status}</span>
                        </Badge>
                      </div>
                      <CardDescription>
                        Resolved {formatDistanceToNow(new Date(ticket.updated_at), {
                    addSuffix: true
                  })}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>)}
        </TabsContent>
      </Tabs>

      {/* Ticket Detail Dialog */}
      <Dialog open={!!selectedTicket} onOpenChange={() => setSelectedTicket(null)}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <div className="flex items-start justify-between gap-4">
              <div>
                <DialogTitle className="text-xl">{selectedTicket?.subject}</DialogTitle>
                <DialogDescription className="mt-1">
                  Ticket #{selectedTicket?.id.slice(0, 8)} • {selectedTicket?.category}
                </DialogDescription>
              </div>
              <Badge variant="outline" className={cn("text-xs", getStatusColor(selectedTicket?.status || ''))}>
                {getStatusIcon(selectedTicket?.status || '')}
                <span className="ml-1 capitalize">{selectedTicket?.status.replace('_', ' ')}</span>
              </Badge>
            </div>
          </DialogHeader>

          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-4">
              {/* Original Message */}
              <div className="bg-accent/30 p-4 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <User className="h-4 w-4" />
                  <span className="font-medium">You</span>
                  <span className="text-xs text-muted-foreground">
                    {selectedTicket && formatDistanceToNow(new Date(selectedTicket.created_at), {
                    addSuffix: true
                  })}
                  </span>
                </div>
                <p className="text-sm">{selectedTicket?.message}</p>
                {selectedTicket?.file_path && <div className="mt-2 flex items-center gap-2 text-sm text-muted-foreground">
                    <Paperclip className="h-4 w-4" />
                    <span>Attachment included</span>
                  </div>}
              </div>

              {/* Replies */}
              {ticketReplies.map(reply => <div key={reply.id} className={cn("p-4 rounded-lg", reply.is_admin_reply ? "bg-primary/5" : "bg-accent/30")}>
                  <div className="flex items-center gap-2 mb-2">
                    <User className="h-4 w-4" />
                    <span className="font-medium">
                      {reply.is_admin_reply ? 'Support Team' : 'You'}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatDistanceToNow(new Date(reply.created_at), {
                    addSuffix: true
                  })}
                    </span>
                  </div>
                  <p className="text-sm">{reply.message}</p>
                </div>)}
            </div>
          </ScrollArea>

          {selectedTicket?.status !== 'closed' && selectedTicket?.status !== 'resolved' && <>
              <Separator />
              <div className="space-y-3">
                <Textarea placeholder="Type your reply..." value={replyMessage} onChange={e => setReplyMessage(e.target.value)} className="min-h-[80px]" />
                <Button onClick={handleSendReply} className="w-full">
                  <Send className="h-4 w-4 mr-2" />
                  Send Reply
                </Button>
              </div>
            </>}
        </DialogContent>
      </Dialog>
    </div>;
}