import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Search, Plus, Download, Filter, MoreHorizontal, Lock, Unlock } from 'lucide-react';
import { JobsOverview } from '@/components/admin/jobs/JobsOverview';
import { AllJobsTable } from '@/components/admin/jobs/AllJobsTable';
import { DispatchAssignment } from '@/components/admin/jobs/DispatchAssignment';
import { LiveTracking } from '@/components/admin/jobs/LiveTracking';
import { DisputesIssues } from '@/components/admin/jobs/DisputesIssues';
import { ReportsInsights } from '@/components/admin/jobs/ReportsInsights';
import RouteMonitor from '@/components/job/RouteMonitor';
import { JobCreateDialog } from '@/components/admin/jobs/JobCreateDialog';
import { BulkJobActions } from '@/components/admin/jobs/BulkJobActions';
import { Alert, AlertDescription } from '@/components/ui/alert';

import { JobTypeSelectionModal } from '@/components/admin/jobs/JobTypeSelectionModal';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { exportJobs } from '@/lib/exportUtils';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Package, Truck, Briefcase, Store } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import JobForm from '@/components/job/JobForm';
import { ShipperCreateJob } from '@/components/shipper/ShipperCreateJob';
import { BrokerPostLoads } from '@/components/broker/BrokerPostLoads';
import VendorDeliveryScheduling from '@/components/vendor/VendorDeliveryScheduling';

export const JobsManagement = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isReadOnlyMode, setIsReadOnlyMode] = useState(false);

  // Mark first login as completed when admin visits job management
  useEffect(() => {
    const markFirstLoginComplete = async () => {
      if (!user?.id) return;
      
      try {
        const { data: profile } = await supabase
          .from('profiles')
          .select('first_login_completed, role_key')
          .eq('id', user.id)
          .single();

        if (profile?.role_key === 'admin' && !profile?.first_login_completed) {
          await supabase
            .from('profiles')
            .update({ first_login_completed: true })
            .eq('id', user.id);
          
          console.log('✅ First login marked as complete');
        }
      } catch (error) {
        console.error('Error marking first login:', error);
      }
    };

    markFirstLoginComplete();
  }, [user?.id]);
  const [dateRange, setDateRange] = useState('all');
  const [jobTypeSelectionOpen, setJobTypeSelectionOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [bulkActionsOpen, setBulkActionsOpen] = useState(false);
  const [selectedJobIds, setSelectedJobIds] = useState<string[]>([]);
  const [generalFormOpen, setGeneralFormOpen] = useState(false);
  const [shipperFormOpen, setShipperFormOpen] = useState(false);
  const [brokerFormOpen, setBrokerFormOpen] = useState(false);
  const [vendorFormOpen, setVendorFormOpen] = useState(false);

  const handleJobTypeSelection = (type: 'admin' | 'general' | 'shipper' | 'broker' | 'vendor') => {
    switch (type) {
      case 'admin':
        setCreateDialogOpen(true);
        break;
      case 'general':
        setGeneralFormOpen(true);
        break;
      case 'shipper':
        setShipperFormOpen(true);
        break;
      case 'broker':
        setBrokerFormOpen(true);
        break;
      case 'vendor':
        setVendorFormOpen(true);
        break;
    }
  };

  // Fetch all jobs for export
  const { data: allJobs } = useQuery({
    queryKey: ['jobs-export'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    }
  });

  const handleExport = async () => {
    try {
      if (!allJobs || allJobs.length === 0) {
        toast({
          title: 'No Data',
          description: 'There are no jobs to export.',
          variant: 'destructive',
        });
        return;
      }

      const count = await exportJobs(allJobs, {
        status: roleFilter !== 'all' ? roleFilter : undefined,
        dateRange: dateRange !== 'all' ? dateRange : undefined,
      });

      toast({
        title: 'Export Successful',
        description: `Exported ${count} job(s) to CSV file.`,
      });
    } catch (error: any) {
      toast({
        title: 'Export Failed',
        description: error.message || 'Failed to export jobs.',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Read-Only Mode Banner */}
      {isReadOnlyMode && (
        <Alert className="border-amber-500/50 bg-amber-500/10">
          <Lock className="h-4 w-4 text-amber-500" />
          <AlertDescription className="text-amber-700 dark:text-amber-400">
            <strong>Read-Only Mode Active:</strong> All modification actions are disabled. You can only view data.
          </AlertDescription>
        </Alert>
      )}

      {/* Section Header */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Jobs Management</h1>
            <p className="text-muted-foreground mt-1">
              Monitor, assign, and analyze all jobs across the platform.
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="secondary"
              size="sm"
              onClick={async () => {
                const { data, error } = await supabase.rpc('check_my_role');
                console.log('Full data:', data);
                console.log('Error:', error);
                toast({
                  title: 'Role Check',
                  description: data?.[0] ? `You are: ${data[0].role_key} (Super Admin: ${data[0].is_super_admin})` : 'No role data',
                });
              }}
            >
              Check My Role
            </Button>
            <Button
              variant={isReadOnlyMode ? "default" : "outline"}
              size="sm"
              onClick={() => setIsReadOnlyMode(!isReadOnlyMode)}
              className="gap-2"
            >
              {isReadOnlyMode ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
              {isReadOnlyMode ? 'Disable Read-Only' : 'Enable Read-Only'}
            </Button>
          </div>
        </div>

        {/* Header Tools */}
        <div className="flex flex-wrap gap-3 items-center">
          {/* Search Bar */}
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by Job ID, Customer, Location..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>

          {/* Date Filter */}
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Date Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="today">Today</SelectItem>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="custom">Custom Range</SelectItem>
            </SelectContent>
          </Select>

          {/* Role Filter */}
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[160px]">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="driver">Driver</SelectItem>
              <SelectItem value="shipper">Shipper</SelectItem>
              <SelectItem value="vendor">Vendor</SelectItem>
              <SelectItem value="broker">Broker</SelectItem>
              <SelectItem value="carrier">Carrier</SelectItem>
            </SelectContent>
          </Select>

          {/* Status Filter - moved from AllJobsTable */}
          {activeTab === 'all-jobs' && (
            <>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground border shadow-lg z-[200]">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="posted">Posted</SelectItem>
                  <SelectItem value="planned">Planned</SelectItem>
                  <SelectItem value="scheduled">Scheduled</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="in_transit">In Transit</SelectItem>
                  <SelectItem value="picked_up">Picked Up</SelectItem>
                  <SelectItem value="on_hold">On Hold</SelectItem>
                  <SelectItem value="delayed">Delayed</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                  <SelectItem value="archived">Archived</SelectItem>
                </SelectContent>
              </Select>

              <Button 
                variant="outline" 
                size="sm" 
                disabled={isReadOnlyMode}
                onClick={async () => {
                  try {
                    const { data: { session } } = await supabase.auth.getSession();
                    const { data, error } = await supabase.functions.invoke('backfill-job-durations', {
                      body: { status: 'pending', limit: 200 },
                      headers: session?.access_token ? { Authorization: `Bearer ${session.access_token}` } : undefined,
                    });
                    if (error) throw error;
                    toast({ title: 'Success', description: `Updated ${data?.updated ?? 0} jobs` });
                  } catch (e: any) {
                    toast({ title: 'Error', description: e.message || 'Failed to recalculate durations', variant: 'destructive' });
                  }
                }}
              >
                Recalc Durations
              </Button>
            </>
          )}

          {/* Quick Actions */}
          <div className="flex gap-2">
            <Button 
              variant="default" 
              size="sm" 
              onClick={() => setJobTypeSelectionOpen(true)}
              disabled={isReadOnlyMode}
            >
              <Plus className="h-4 w-4 mr-2" />
              Create Job
            </Button>
            <Button variant="outline" size="sm" onClick={handleExport}>
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-8 lg:w-auto lg:inline-grid">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="all-jobs">All Jobs</TabsTrigger>
          <TabsTrigger value="forms">Job Forms</TabsTrigger>
          <TabsTrigger value="dispatch">Dispatch & Assignment</TabsTrigger>
          <TabsTrigger value="route-monitor">Route Monitor</TabsTrigger>
          <TabsTrigger value="tracking">Tracking (Live)</TabsTrigger>
          <TabsTrigger value="disputes">Disputes & Issues</TabsTrigger>
          <TabsTrigger value="reports">Reports & Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <JobsOverview filters={{ searchQuery, roleFilter, dateRange }} />
        </TabsContent>

        <TabsContent value="all-jobs" className="mt-6">
          <AllJobsTable 
            filters={{ searchQuery, roleFilter, dateRange, statusFilter }}
            selectedJobIds={selectedJobIds}
            onSelectionChange={setSelectedJobIds}
            onBulkActionsClick={() => !isReadOnlyMode && setBulkActionsOpen(true)}
          />
        </TabsContent>

        <TabsContent value="forms" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Admin Job Form */}
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => !isReadOnlyMode && setCreateDialogOpen(true)}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <FileText className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg">Admin Job Form</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Create and manage jobs with full administrative controls. Includes dispatch, assignment, and detailed configuration options.
                </CardDescription>
                <Button 
                  className="w-full mt-4" 
                  onClick={() => setCreateDialogOpen(true)}
                  disabled={isReadOnlyMode}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Open Admin Form
                </Button>
              </CardContent>
            </Card>

            {/* General Job Form */}
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => !isReadOnlyMode && setGeneralFormOpen(true)}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Package className="h-6 w-6 text-blue-500" />
                  </div>
                  <CardTitle className="text-lg">General Job Form</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Standard job creation form with essential fields including pickup/delivery locations, times, and signature requirements.
                </CardDescription>
                <Button 
                  className="w-full mt-4" 
                  variant="outline" 
                  onClick={() => setGeneralFormOpen(true)}
                  disabled={isReadOnlyMode}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Open General Form
                </Button>
              </CardContent>
            </Card>

            {/* Shipper Job Form */}
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setShipperFormOpen(true)}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <Truck className="h-6 w-6 text-green-500" />
                  </div>
                  <CardTitle className="text-lg">Shipper Job Form</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Shipper-specific job creation form optimized for shipping and delivery operations with location tracking.
                </CardDescription>
                <Button className="w-full mt-4" variant="outline" onClick={() => setShipperFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Open Shipper Form
                </Button>
              </CardContent>
            </Card>

            {/* Broker Load Form */}
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setBrokerFormOpen(true)}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-500/10 rounded-lg">
                    <Briefcase className="h-6 w-6 text-orange-500" />
                  </div>
                  <CardTitle className="text-lg">Broker Load Form</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Broker load posting form for creating delivery gigs and managing carrier assignments with rate management.
                </CardDescription>
                <Button className="w-full mt-4" variant="outline" onClick={() => setBrokerFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Open Broker Form
                </Button>
              </CardContent>
            </Card>

            {/* Vendor Delivery Gig Form */}
            <Card className="hover:shadow-lg transition-shadow cursor-pointer" onClick={() => setVendorFormOpen(true)}>
              <CardHeader>
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-purple-500/10 rounded-lg">
                    <Store className="h-6 w-6 text-purple-500" />
                  </div>
                  <CardTitle className="text-lg">Vendor Delivery Gig Form</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Vendor-specific delivery gig creation form for posting delivery jobs with pickup/delivery locations and pay details.
                </CardDescription>
                <Button className="w-full mt-4" variant="outline" onClick={() => setVendorFormOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Open Vendor Form
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="dispatch" className="mt-6">
          <DispatchAssignment filters={{ searchQuery, roleFilter, dateRange }} />
        </TabsContent>

        <TabsContent value="route-monitor" className="mt-6">
          <RouteMonitor filters={{ search: searchQuery, status: roleFilter, assignedUser: 'all' }} />
        </TabsContent>

        <TabsContent value="tracking" className="mt-6">
          <LiveTracking filters={{ searchQuery, roleFilter, dateRange }} />
        </TabsContent>

        <TabsContent value="disputes" className="mt-6">
          <DisputesIssues filters={{ searchQuery, roleFilter, dateRange }} />
        </TabsContent>

        <TabsContent value="reports" className="mt-6">
          <ReportsInsights filters={{ searchQuery, roleFilter, dateRange }} />
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <JobTypeSelectionModal
        open={jobTypeSelectionOpen}
        onOpenChange={setJobTypeSelectionOpen}
        onSelectJobType={handleJobTypeSelection}
      />

      <JobCreateDialog 
        open={createDialogOpen} 
        onOpenChange={setCreateDialogOpen}
        onJobCreated={() => setActiveTab('all-jobs')}
      />

      <BulkJobActions
        open={bulkActionsOpen}
        onOpenChange={setBulkActionsOpen}
        selectedJobIds={selectedJobIds}
        onComplete={() => setSelectedJobIds([])}
      />

      {/* General Job Form Dialog */}
      <Dialog open={generalFormOpen} onOpenChange={setGeneralFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>General Job Form</DialogTitle>
          </DialogHeader>
          <JobForm />
        </DialogContent>
      </Dialog>

      {/* Shipper Job Form Dialog */}
      <Dialog open={shipperFormOpen} onOpenChange={setShipperFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Shipper Job Form</DialogTitle>
          </DialogHeader>
          <ShipperCreateJob />
        </DialogContent>
      </Dialog>

      {/* Broker Load Form Dialog */}
      <Dialog open={brokerFormOpen} onOpenChange={setBrokerFormOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Broker Load Posting Form</DialogTitle>
          </DialogHeader>
          <BrokerPostLoads />
        </DialogContent>
      </Dialog>

      {/* Vendor Delivery Gig Form Dialog */}
      <Dialog open={vendorFormOpen} onOpenChange={setVendorFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Vendor Delivery Gig Form</DialogTitle>
          </DialogHeader>
          <VendorDeliveryScheduling />
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default JobsManagement;
