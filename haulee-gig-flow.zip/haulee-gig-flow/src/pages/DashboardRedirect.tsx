import React from "react";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useSystemAccessValidation } from "@/hooks/useSystemAccessValidation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";

export default function DashboardRedirect() {
  const { user, loading, redirectUser } = useAuth();
  const { isApproved, isSuperAdmin } = useSystemAccessValidation();
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    if (loading) return;
    
    const run = async () => {
      if (!user) {
        navigate("/auth", { replace: true });
        return;
      }

      // Check if user is approved (super admins bypass)
      if (!isSuperAdmin && !isApproved) {
        navigate("/onboarding", { replace: true });
        return;
      }

      try {
        // Use centralized redirectUser function from AuthContext
        // This ensures consistent redirection logic across the entire platform
        await redirectUser(user);
      } catch (error) {
        console.error('Error redirecting user:', error);
        navigate("/onboarding", { replace: true });
      } finally {
        setChecking(false);
      }
    };

    run();
  }, [user, loading, redirectUser, navigate, isApproved, isSuperAdmin]);

  return (
    <div className="min-h-screen flex items-center justify-center">
      <Card className="w-96">
        <CardHeader>
          <CardTitle>Preparing your dashboard</CardTitle>
          <CardDescription>Just a second while we set things up…</CardDescription>
        </CardHeader>
        <CardContent className="flex items-center justify-center p-6">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    </div>
  );
}
