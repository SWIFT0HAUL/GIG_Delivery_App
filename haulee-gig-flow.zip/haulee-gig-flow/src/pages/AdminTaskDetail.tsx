import { TaskDetailPage } from '@/components/task-center/TaskDetailPage';

const AdminTaskDetail = () => {
  return <TaskDetailPage />;
};

export default AdminTaskDetail;
