import React, { useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { useNavigate, Routes, Route, Navigate } from 'react-router-dom';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminHeader from '@/components/admin/AdminHeader';
import { StickyHorizontalScrollbar } from '@/components/dashboard/StickyHorizontalScrollbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { UserManagement } from '@/components/admin/UserManagement';
import { PermissionManagement } from '@/components/admin/PermissionManagement';
import { RoleManagement } from '@/components/admin/RoleManagement';
import { SubRolePermissionsMatrix } from '@/components/admin/SubRolePermissionsMatrix';
import { RoleSubRoleRelationships } from '@/components/admin/RoleSubRoleRelationships';
import MenuManagement from '@/components/admin/MenuManagement';
import { ApprovalsManagement } from '@/components/admin/ApprovalsManagement';
import { PlatformSettings } from '@/components/admin/PlatformSettings';
import { PlatformIntegrations } from '@/components/admin/PlatformIntegrations';
import FinanceAccounting from '@/components/admin/FinanceAccounting';
import { UnifiedAdvancedSettings } from '@/components/admin/UnifiedAdvancedSettings';
import { TimesheetManagement } from '@/components/admin/TimesheetManagement';
import { KYCManagement } from '@/components/admin/KYCManagement';
import { TasksManagement } from '@/components/admin/TasksManagement';
import { W9Management } from '@/components/admin/W9Management';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ChecklistManagement } from '@/pages/ChecklistManagement';
import NotificationCenterPage from '@/pages/NotificationCenter';
import { JobsManagement } from '@/pages/admin/JobsManagement';
import { SuperAdminPanel } from '@/components/admin/SuperAdminPanel';
import { JobClaimAuthorizationManager } from '@/components/admin/JobClaimAuthorizationManager';
import { AdminDashboardOverview } from '@/components/admin/AdminDashboardOverview';
import { KPIDashboard } from '@/components/admin/KPIDashboard';
import { cn } from '@/lib/utils';
const AdminDashboard = () => {
  const {
    user,
    signOut
  } = useAuth();
  const {
    profile,
    loading,
    hasAdminAccess,
    hasSuperAdminAccess
  } = useUserRole();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = React.useState(false); // Closed by default on mobile
  const mainRef = useRef<HTMLDivElement>(null);

  // Super admins stay here, regular admins go to unified dashboard
  useEffect(() => {
    if (!loading) {
      if (!hasAdminAccess()) {
        navigate('/');
      } else if (!hasSuperAdminAccess()) {
        // Regular admins use unified dashboard
        navigate('/dashboard', {
          replace: true
        });
      }
    }
  }, [loading, hasAdminAccess, hasSuperAdminAccess, navigate]);
  useEffect(() => {
    if (user) {
      console.log('Admin Dashboard accessed by:', user.id);
    }
  }, [user]);
  if (loading) {
    return <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground">Loading admin panel...</p>
        </div>
      </div>;
  }

  // Only super admins should reach here
  if (!hasSuperAdminAccess()) {
    return null;
  }
  const PlaceholderPage: React.FC<{
    title: string;
    description?: string;
  }> = ({
    title,
    description
  }) => <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">
          {description || "This section is under development and will be available soon."}
        </p>
      </CardContent>
    </Card>;
  return <div className="min-h-screen bg-background">
      <AdminSidebar sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} />
      
      <div className={cn("flex flex-col h-screen transition-all duration-300", sidebarOpen ? "lg:ml-64" : "lg:ml-0")}>
        <AdminHeader user={user} sidebarOpen={sidebarOpen} setSidebarOpen={setSidebarOpen} signOut={signOut} />

        <main ref={mainRef} className="flex-1 py-8 overflow-y-auto overflow-x-auto scrollbar-visible pb-6">
          <div className="container mx-auto px-4 space-y-6">
            <Routes>
            {/* CORE Routes */}
            <Route path="dashboard" element={<KPIDashboard />} />
            <Route path="users" element={<UserManagement />} />
            <Route path="jobs" element={<JobsManagement />} />
            <Route path="job-auth-requests" element={<JobClaimAuthorizationManager />} />
            <Route path="kyc" element={<KYCManagement />} />
            <Route path="rbac" element={<Tabs defaultValue="permissions" className="w-full">
                  <TabsList className="grid w-full grid-cols-5">
                    <TabsTrigger value="permissions">Permissions</TabsTrigger>
                    <TabsTrigger value="roles">Roles</TabsTrigger>
                    <TabsTrigger value="subrole-matrix">SubRole Matrix</TabsTrigger>
                    <TabsTrigger value="relationships">Role Relationships</TabsTrigger>
                    <TabsTrigger value="menus">Menu Management</TabsTrigger>
                  </TabsList>
                  <TabsContent value="permissions">
                    <PermissionManagement />
                  </TabsContent>
                  <TabsContent value="roles">
                    <RoleManagement />
                  </TabsContent>
                  <TabsContent value="subrole-matrix">
                    <SubRolePermissionsMatrix />
                  </TabsContent>
                  <TabsContent value="relationships">
                    <RoleSubRoleRelationships />
                  </TabsContent>
                  <TabsContent value="menus">
                    <MenuManagement />
                  </TabsContent>
                </Tabs>} />
            <Route path="timesheet" element={<TimesheetManagement />} />
            <Route path="super" element={<SuperAdminPanel />} />

            {/* CONTENT Routes */}
            <Route path="content" element={<PlaceholderPage title="Content Management" />} />
            <Route path="tasks" element={<TasksManagement />} />
            <Route path="checklists" element={<ChecklistManagement />} />

            {/* FINANCIALS Routes */}
            <Route path="finance" element={<FinanceAccounting />} />
            <Route path="w9" element={<W9Management />} />

            {/* PLATFORM Routes */}
            <Route path="settings" element={<UnifiedAdvancedSettings />} />
            <Route path="advanced-settings" element={<UnifiedAdvancedSettings />} />
            <Route path="data" element={<PlaceholderPage title="Data Management" />} />
            <Route path="integrations" element={<PlatformIntegrations />} />

            {/* SECURITY Routes */}
            <Route path="audit" element={<PlaceholderPage title="Audit Logs" />} />
            <Route path="system-control" element={<PlaceholderPage title="System Control" />} />
            <Route path="nav-audit" element={<PlaceholderPage title="Navigation Audit" />} />

            {/* MONITORING & SUPPORT Routes */}
            <Route path="notifications" element={<NotificationCenterPage />} />
            <Route path="support" element={<PlaceholderPage title="Support Center" />} />
            <Route path="maintenance" element={<PlaceholderPage title="Maintenance" />} />

            {/* Default redirect */}
            <Route path="*" element={<Navigate to="jobs" replace />} />
            </Routes>
          </div>
        </main>
        <StickyHorizontalScrollbar targetRef={mainRef} />
      </div>
    </div>;
};
export default AdminDashboard;