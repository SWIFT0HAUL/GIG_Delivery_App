import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CheckCircle2, Clock, ListTodo, UserCheck, Mail, Shield, FileText, Search, Filter, Calendar, AlertCircle, Play, Check, Sparkles, LogOut } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { useOnboardingProgress } from '@/hooks/useOnboardingProgress';
import { TaskWorkspaceModal } from '@/components/TaskWorkspaceModal';

interface RedirectStep {
  step_number: number;
  step_name: string;
  step_description: string;
  path: string;
  is_optional: boolean;
}

interface Task {
  id: string;
  task_id: string;
  name: string;
  description: string;
  status: string;
  approval_status: string;
  category: string;
  created_at?: string;
  updated_at?: string;
  completed_at?: string;
  required?: boolean;
  custom_link?: string;
  redirect_path?: RedirectStep[];
  task_form_schema?: any;
  approved_by?: string | null;
  rejection_reason?: string | null;
  assignment_id?: string;
}

export default function StatusAndTasksPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { updateProgress } = useOnboardingProgress();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [accountStatus, setAccountStatus] = useState<string>('pending');
  const [isApproved, setIsApproved] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [currentWorkingTask, setCurrentWorkingTask] = useState<Task | null>(null);
  const [hasInteractedWithWorkspace, setHasInteractedWithWorkspace] = useState(false);

  useEffect(() => {
    if (user) {
      fetchTasks();
      fetchAccountStatus();
      
      // Set up real-time subscription for profile changes
      console.log('🔌 Setting up real-time subscription for user:', user.id);
      const channel = supabase
        .channel('profile-status-changes')
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'profiles',
            filter: `id=eq.${user.id}`,
          },
          (payload) => {
            console.log('🔔 Profile status updated in real-time:', payload);
            const newProfile = payload.new as any;
            
            // Update local state immediately
            setIsApproved(newProfile.is_approved || false);
            setIsActive(newProfile.is_active || false);
            
            // Show toast notification for status change
            if (newProfile.is_approved && !newProfile.is_active) {
              console.log('✅ User approved! Showing congratulations screen');
              toast({
                title: "🎉 Account Approved!",
                description: "Your account has been approved. Dashboard activation is pending.",
              });
            }
            
            // If user was just activated, redirect to dashboard
            if (newProfile.is_active === true && newProfile.is_approved === true) {
              console.log('✅ User activated! Redirecting to dashboard...');
              toast({
                title: "🚀 Dashboard Activated!",
                description: "Redirecting to your dashboard now...",
              });
              
              const roleToDashboard: Record<string, string> = {
                vendor: "/vendor-dashboard",
                vendor_merchant: "/vendor-dashboard",
                shipper: "/shipper-dashboard", 
                carrier: "/carrier-dashboard",
                driver: "/driver-dashboard",
                broker: "/broker-dashboard",
                admin: "/dashboard/admin-users",
                super_admin: "/dashboard/admin-users",
              };
              const target = roleToDashboard[newProfile.role_key] || "/dashboard";
              
              setTimeout(() => {
                navigate(target, { replace: true });
              }, 1000);
            }
          }
        )
        .subscribe((status) => {
          console.log('📡 Real-time subscription status:', status);
          if (status === 'SUBSCRIBED') {
            console.log('✅ Real-time monitoring active!');
          }
        });
      
      // Cleanup subscription on unmount
      return () => {
        console.log('🔌 Cleaning up real-time subscription');
        supabase.removeChannel(channel);
      };
    }
  }, [user, navigate]);

  const fetchAccountStatus = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('is_approved, is_active, onboarding_complete, role_key')
        .eq('id', user?.id)
        .single();

      if (error) throw error;
      
      // Cast to any to handle new fields not yet in types
      const profile = data as any;
      
      setIsApproved(profile?.is_approved || false);
      setIsActive(profile?.is_active || false);
      
      // If user is active, redirect to their dashboard
      if (profile?.is_active === true) {
        const roleToDashboard: Record<string, string> = {
          vendor: "/vendor-dashboard",
          vendor_merchant: "/vendor-dashboard",
          shipper: "/shipper-dashboard", 
          carrier: "/carrier-dashboard",
          driver: "/driver-dashboard",
          broker: "/broker-dashboard",
          admin: "/dashboard/admin-users",
          super_admin: "/dashboard/admin-users",
        };
        const target = roleToDashboard[profile.role_key] || "/dashboard";
        navigate(target, { replace: true });
        return;
      }
      
      // Set simplified account status based on approval
      setAccountStatus(profile?.is_approved === true ? 'approved' : 'pending');
    } catch (error) {
      console.error('Error fetching account status:', error);
    }
  };

  const fetchTasks = async () => {
    try {
      const { data: assignments, error } = await supabase
        .from('task_assignments')
        .select(`
          id,
          status,
          approval_status,
          completed_at,
          created_at,
          updated_at,
          task_id,
          approved_by,
          rejection_reason,
          custom_tasks (
            id,
            name,
            description,
            category,
            required,
            custom_link,
            redirect_path,
            task_form_schema
          )
        `)
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formattedTasks: Task[] = (assignments || []).map((assignment: any) => ({
        id: assignment.task_id, // Use task_id as id for TaskWorkspaceModal
        task_id: assignment.task_id,
        name: assignment.custom_tasks?.name || 'Task',
        description: assignment.custom_tasks?.description || '',
        status: assignment.status,
        approval_status: assignment.approval_status,
        category: assignment.custom_tasks?.category || 'General',
        created_at: assignment.created_at,
        updated_at: assignment.updated_at,
        completed_at: assignment.completed_at,
        required: assignment.custom_tasks?.required || false,
        custom_link: assignment.custom_tasks?.custom_link,
        redirect_path: assignment.custom_tasks?.redirect_path,
        task_form_schema: assignment.custom_tasks?.task_form_schema,
        approved_by: assignment.approved_by,
        rejection_reason: assignment.rejection_reason,
        assignment_id: assignment.id // Keep assignment ID for updates
      }));

      // Deduplicate tasks by task_id, keeping the most recent assignment
      const uniqueTasks = formattedTasks.reduce((acc, task) => {
        const existing = acc.find(t => t.task_id === task.task_id);
        if (!existing) {
          acc.push(task);
        }
        return acc;
      }, [] as Task[]);

      setTasks(uniqueTasks);
      // Refresh status after tasks update
      await fetchAccountStatus();
    } catch (error) {
      console.error('Error fetching tasks:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleStartTask = async (task: Task) => {
    try {
      const { error } = await supabase
        .from('task_assignments')
        .update({ 
          status: 'in_progress',
          updated_at: new Date().toISOString()
        })
        .eq('id', task.assignment_id || task.id);

      if (error) throw error;

      // Open workspace modal
      setCurrentWorkingTask(task);
      setHasInteractedWithWorkspace(false);
      setWorkspaceOpen(true);

      toast({
        title: "Task Started",
        description: `You've started working on "${task.name}"`,
      });

      await fetchTasks();
    } catch (error) {
      console.error('Error starting task:', error);
      toast({
        title: "Error",
        description: "Failed to start task. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleOpenWorkspace = (task: Task) => {
    setCurrentWorkingTask(task);
    setHasInteractedWithWorkspace(false);
    setWorkspaceOpen(true);
  };

  const handleWorkspaceInteraction = () => {
    setHasInteractedWithWorkspace(true);
  };

  const handleCompleteTask = async () => {
    if (!currentWorkingTask) return;

    try {
      const { data: updatedByTask, error: updateErr1 } = await supabase
        .from('task_assignments')
        .update({ 
          status: 'completed',
          completed_at: new Date().toISOString(),
          approval_status: 'pending_approval',
          updated_at: new Date().toISOString()
        })
        .eq('task_id', currentWorkingTask.task_id)
        .eq('user_id', user?.id)
        .select('id');

      // Fallback: update by assignment_id if no rows matched
      let updateErr = updateErr1;
      if (!updateErr1 && (!updatedByTask || updatedByTask.length === 0) && currentWorkingTask.assignment_id) {
        const { error: updateErr2 } = await supabase
          .from('task_assignments')
          .update({ 
            status: 'completed',
            completed_at: new Date().toISOString(),
            approval_status: 'pending_approval',
            updated_at: new Date().toISOString()
          })
          .eq('id', currentWorkingTask.assignment_id);
        updateErr = updateErr2 || null;
      }

      if (updateErr) throw updateErr;

      // Update onboarding progress
      await updateProgress('task_completion', false);

      // Close workspace
      setWorkspaceOpen(false);
      setCurrentWorkingTask(null);
      setHasInteractedWithWorkspace(false);

      toast({
        title: "Task completed successfully!",
        description: `"${currentWorkingTask.name}" is awaiting admin approval`,
      });

      await fetchTasks();
    } catch (error) {
      console.error('Error completing task:', error);
      toast({
        title: "Error",
        description: "Failed to complete task. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Logged out successfully",
        description: "You have been signed out.",
      });
      navigate('/auth', { replace: true });
    } catch (error) {
      console.error('Error logging out:', error);
      toast({
        title: "Error",
        description: "Failed to log out. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Filter and search logic
  const filteredTasks = tasks.filter(task => {
    const matchesSearch = task.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         task.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || task.status === statusFilter;
    const matchesCategory = categoryFilter === 'all' || task.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesCategory;
  });

  const completedTasks = tasks.filter(t => t.status === 'completed');
  const pendingTasks = tasks.filter(t => t.status === 'pending');
  const inProgressTasks = tasks.filter(t => t.status === 'in_progress');

  // Get unique categories
  const categories = Array.from(new Set(tasks.map(t => t.category)));

  const getStatusBadge = (status: string, approvalStatus?: string, approvedBy?: string | null) => {
    if (status === 'completed' && approvalStatus === 'pending_approval') {
      return (
        <Badge variant="secondary" className="gap-1">
          <Clock className="w-3 h-3" />
          Awaiting Admin Approval
        </Badge>
      );
    }

    if (status === 'completed' && approvalStatus === 'approved') {
      // If approved_by exists, it was admin approved; otherwise it's just user completed
      if (approvedBy) {
        return (
          <Badge variant="default" className="gap-1">
            <CheckCircle2 className="w-3 h-3" />
            Approved
          </Badge>
        );
      } else {
        return (
          <Badge variant="default" className="gap-1">
            <CheckCircle2 className="w-3 h-3" />
            Complete
          </Badge>
        );
      }
    }

    const variants: Record<string, any> = {
      pending: { variant: 'secondary', icon: Clock, label: 'Pending', color: 'text-amber-600' },
      completed: { variant: 'default', icon: CheckCircle2, label: 'Completed', color: 'text-green-600' },
      in_progress: { variant: 'outline', icon: ListTodo, label: 'In Progress', color: 'text-blue-600' }
    };
    
    const config = variants[status] || variants.pending;
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className="gap-1">
        <Icon className="w-3 h-3" />
        {config.label}
      </Badge>
    );
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/20',
      in_progress: 'border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-950/20',
      completed: 'border-green-200 dark:border-green-800 bg-green-50 dark:bg-green-950/20'
    };
    return colors[status] || colors.pending;
  };

  const getAccountStatusBadge = () => {
    const statusConfig: Record<string, { label: string; variant: any; icon: any }> = {
      pending: { label: 'Application Pending', variant: 'secondary', icon: Clock },
      under_review: { label: 'Under Review', variant: 'outline', icon: FileText },
      task_assigned: { label: 'Task Assigned', variant: 'outline', icon: ListTodo },
      action_required: { label: 'Action Required', variant: 'destructive', icon: AlertCircle },
      needs_attention: { label: 'Needs Attention', variant: 'destructive', icon: AlertCircle },
      approved: { label: 'Active', variant: 'default', icon: CheckCircle2 },
      rejected: { label: 'Application Rejected', variant: 'destructive', icon: Shield }
    };
    
    const config = statusConfig[accountStatus] || statusConfig.pending;
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className="gap-2 px-4 py-2 text-sm">
        <Icon className="w-4 h-4" />
        {config.label}
      </Badge>
    );
  };

  // If user is approved but not active, show congratulatory message
  // This applies to ALL roles: Driver, Carrier, Shipper, Broker, Vendor, etc.
  if (isApproved && !isActive) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center py-4 sm:py-8 px-3 sm:px-4 overflow-x-hidden">
        <div className="container mx-auto max-w-4xl w-full">
          {/* Header with Logout */}
          <div className="flex justify-end mb-4 sm:mb-6">
            <Button
              variant="outline"
              onClick={handleLogout}
              className="gap-2 h-10 sm:h-11"
              size="sm"
            >
              <LogOut className="w-4 h-4" />
              <span className="hidden sm:inline">Logout</span>
            </Button>
          </div>

          {/* Three Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4 md:gap-6 mb-4 sm:mb-6">
            {/* Card 1: Congratulations */}
            <Card className="border-2 border-primary/20">
              <CardContent className="pt-4 sm:pt-6 pb-4 sm:pb-6">
                <div className="text-center">
                  <div className="text-3xl sm:text-4xl md:text-5xl mb-2 sm:mb-3">🎉</div>
                  <h2 className="text-sm sm:text-base md:text-lg font-bold mb-1 sm:mb-2">
                    Congratulations!
                  </h2>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Your application has been approved
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Card 2: Account Status */}
            <Card className="border-2 border-green-500/20 bg-green-50/50 dark:bg-green-950/20">
              <CardContent className="pt-4 sm:pt-6 pb-4 sm:pb-6">
                <div className="text-center">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 mx-auto mb-2 sm:mb-3 rounded-full bg-green-500 flex items-center justify-center">
                    <Check className="w-5 h-5 sm:w-6 sm:h-6 md:w-7 md:h-7 text-white" />
                  </div>
                  <h3 className="text-xs sm:text-sm md:text-base font-semibold mb-1 sm:mb-2 text-green-700 dark:text-green-300">
                    Application Approved
                  </h3>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Your account is verified and ready
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Card 3: Next Steps */}
            <Card className="border-2 border-amber-500/20 bg-amber-50/50 dark:bg-amber-950/20">
              <CardContent className="pt-4 sm:pt-6 pb-4 sm:pb-6">
                <div className="text-center">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-14 md:h-14 mx-auto mb-2 sm:mb-3 rounded-full bg-amber-500 flex items-center justify-center animate-pulse">
                    <Clock className="w-5 h-5 sm:w-6 sm:h-6 md:w-7 md:h-7 text-white" />
                  </div>
                  <h3 className="text-xs sm:text-sm md:text-base font-semibold mb-1 sm:mb-2 text-amber-700 dark:text-amber-300">
                    Activation Pending
                  </h3>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Dashboard access coming soon
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Additional Info Card */}
          <Card className="border-2">
            <CardContent className="pt-4 sm:pt-6 pb-4 sm:pb-6">
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-start gap-2 sm:gap-3">
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs sm:text-sm font-semibold mb-1">Email Notification</h4>
                    <p className="text-xs sm:text-sm text-muted-foreground">
                      You'll receive an email at <span className="font-medium text-foreground">{user?.email}</span> when your dashboard is ready.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2 sm:gap-3">
                  <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <h4 className="text-xs sm:text-sm font-semibold mb-1">Real-Time Updates</h4>
                    <p className="text-xs sm:text-sm text-muted-foreground">
                      Keep this page open! You'll be automatically redirected to your dashboard the moment it's activated.
                    </p>
                  </div>
                </div>

                <div className="text-center pt-3 sm:pt-4 border-t">
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    Thank you for your patience. We're excited to have you on board! 🚀
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-6 sm:py-8 md:py-12 overflow-x-hidden">
      <div className="container mx-auto px-3 sm:px-4 max-w-7xl">
        {/* Header with Logout */}
        <div className="flex justify-between items-center mb-4 sm:mb-6">
          <div>
            <h1 className="text-xl sm:text-2xl md:text-3xl font-bold">Status & Tasks</h1>
            <p className="text-xs sm:text-sm text-muted-foreground">Track your onboarding progress</p>
          </div>
          <Button
            variant="outline"
            onClick={handleLogout}
            className="gap-2 h-9 sm:h-10"
            size="sm"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </Button>
        </div>

        <div className="grid gap-4 sm:gap-6">
          {/* Card 1: Account Status */}
          <Card className="border-2">
            <CardContent className="pt-4 sm:pt-6">
              <div className="flex items-center gap-2 sm:gap-3 mb-3 sm:mb-4">
                <UserCheck className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
                <h2 className="text-base sm:text-lg md:text-xl font-bold">Account Status</h2>
              </div>
              
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center justify-between py-2 sm:py-3 border-b">
                  <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
                    <Mail className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground flex-shrink-0" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium">Email</p>
                      <p className="text-xs sm:text-sm text-muted-foreground truncate">{user?.email}</p>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-2 sm:py-3 gap-3">
                  <div className="flex items-start gap-2 sm:gap-3 flex-1 min-w-0">
                    <Shield className="w-3 h-3 sm:w-4 sm:h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs sm:text-sm font-medium">Application Status</p>
                      <p className="text-xs sm:text-xs text-muted-foreground mt-1 break-words">
                        {accountStatus === 'pending' && 'Awaiting initial review by admin'}
                        {accountStatus === 'under_review' && 'Your application is being reviewed'}
                        {accountStatus === 'task_assigned' && 'You have a pending task to complete'}
                        {accountStatus === 'action_required' && 'Please complete the required actions'}
                        {accountStatus === 'needs_attention' && 'Immediate action required'}
                        {accountStatus === 'approved' && 'Your account is active and ready'}
                        {accountStatus === 'rejected' && 'Application rejected. Check email for details'}
                      </p>
                    </div>
                  </div>
                  <div className="sm:flex-shrink-0">
                    {getAccountStatusBadge()}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Card 2: Stats Overview */}
          <Card className="border-2">
            <CardContent className="pt-4 sm:pt-6">
              <h2 className="text-base sm:text-lg md:text-xl font-bold mb-3 sm:mb-4">Tasks Overview</h2>
              <div className="grid grid-cols-3 gap-2 sm:gap-4">
                <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-950/20 dark:to-green-900/20 border-2 border-green-200 dark:border-green-800 rounded-lg p-3 sm:p-4">
                  <div className="flex flex-col items-center text-center">
                    <CheckCircle2 className="w-6 h-6 sm:w-8 sm:h-8 text-green-500 mb-1 sm:mb-2" />
                    <p className="text-xs sm:text-sm font-medium text-muted-foreground mb-0.5">Completed</p>
                    <p className="text-xl sm:text-2xl md:text-3xl font-bold text-green-700 dark:text-green-400">{completedTasks.length}</p>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-blue-50 to-blue-100 dark:from-blue-950/20 dark:to-blue-900/20 border-2 border-blue-200 dark:border-blue-800 rounded-lg p-3 sm:p-4">
                  <div className="flex flex-col items-center text-center">
                    <ListTodo className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500 mb-1 sm:mb-2" />
                    <p className="text-xs sm:text-sm font-medium text-muted-foreground mb-0.5">In Progress</p>
                    <p className="text-xl sm:text-2xl md:text-3xl font-bold text-blue-700 dark:text-blue-400">{inProgressTasks.length}</p>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-950/20 dark:to-amber-900/20 border-2 border-amber-200 dark:border-amber-800 rounded-lg p-3 sm:p-4">
                  <div className="flex flex-col items-center text-center">
                    <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-amber-500 mb-1 sm:mb-2" />
                    <p className="text-xs sm:text-sm font-medium text-muted-foreground mb-0.5">Pending</p>
                    <p className="text-xl sm:text-2xl md:text-3xl font-bold text-amber-700 dark:text-amber-400">{pendingTasks.length}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Card 3: Tasks List */}
          <Card className="border-2">
            <CardContent className="pt-4 sm:pt-6">
              <h2 className="text-base sm:text-lg md:text-xl font-bold mb-3 sm:mb-4">Your Tasks</h2>

              {/* Filters and Search */}
              <div className="space-y-3 sm:space-y-4 mb-4 sm:mb-6">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-2.5 sm:top-3 h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tasks..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-8 sm:pl-9 h-8 sm:h-10 text-xs sm:text-sm"
                  />
                </div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-48 h-8 sm:h-10 text-xs sm:text-sm">
                      <Filter className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                    <SelectTrigger className="w-full sm:w-48 h-8 sm:h-10 text-xs sm:text-sm">
                      <FileText className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                      <SelectValue placeholder="Filter by category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

          {/* Task Tabs */}
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 mb-4 sm:mb-6 h-auto">
              <TabsTrigger value="all" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-2">
                <span className="hidden sm:inline">All Tasks</span>
                <span className="sm:hidden">All</span>
                <Badge variant="secondary" className="ml-1 text-xs px-1.5">{tasks.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="pending" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-2">
                <span className="hidden sm:inline">Pending</span>
                <span className="sm:hidden">Pend</span>
                <Badge variant="secondary" className="ml-1 text-xs px-1.5">{pendingTasks.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="in_progress" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-2">
                <span className="hidden sm:inline">In Progress</span>
                <span className="sm:hidden">Active</span>
                <Badge variant="secondary" className="ml-1 text-xs px-1.5">{inProgressTasks.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="completed" className="gap-1 sm:gap-2 text-xs sm:text-sm py-2 sm:py-2.5 px-2">
                <span className="hidden sm:inline">Completed</span>
                <span className="sm:hidden">Done</span>
                <Badge variant="secondary" className="ml-1 text-xs px-1.5">{completedTasks.length}</Badge>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-3 sm:space-y-4">
              {loading ? (
                <div className="py-8 sm:py-12 text-center">
                  <p className="text-xs sm:text-sm text-muted-foreground">Loading tasks...</p>
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="py-8 sm:py-12 text-center">
                  <ListTodo className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 text-muted-foreground" />
                  <p className="text-sm sm:text-base font-semibold mb-1 sm:mb-2">No tasks found</p>
                  <p className="text-xs sm:text-sm text-muted-foreground">
                    {searchQuery || statusFilter !== 'all' || categoryFilter !== 'all'
                      ? 'Try adjusting your filters'
                      : 'Tasks will appear here once assigned'}
                  </p>
                </div>
              ) : (
                <div className="space-y-1.5 sm:space-y-2">
                  {filteredTasks.map((task) => {
                    const isCompleted = task.status === 'completed' && task.approval_status === 'approved';
                    const isPendingApproval = task.status === 'completed' && task.approval_status === 'pending_approval';
                    const isRejected = task.approval_status === 'rejected';
                    const isDisabled = isCompleted || isPendingApproval;

                    return (
                      <div key={task.id} className={`border rounded-lg p-1.5 sm:p-2 transition-all ${getStatusColor(task.status)} ${isDisabled ? 'opacity-75' : 'hover:shadow-md'}`}>
                        <div className="flex flex-col gap-0.5 sm:gap-1">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1 sm:gap-1.5 mb-0.5 flex-wrap">
                              {isCompleted && <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-green-600" />}
                              <h3 className="font-semibold text-[10px] sm:text-xs break-words flex-1 leading-tight">{task.name}</h3>
                              <div className="scale-75 origin-right">
                                {getStatusBadge(task.status, task.approval_status, task.approved_by)}
                              </div>
                            </div>
                            {task.description && (
                              <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-1 break-words leading-snug line-clamp-1">
                                {task.description}
                              </p>
                            )}
                            {isRejected && task.rejection_reason && (
                              <div className="bg-destructive/10 border border-destructive/20 rounded p-1 mb-1">
                                <div className="flex items-start gap-1">
                                  <AlertCircle className="w-2.5 h-2.5 text-destructive mt-0.5 flex-shrink-0" />
                                  <div className="min-w-0 flex-1">
                                    <p className="font-semibold text-[9px] text-destructive">Task Rejected</p>
                                    <p className="text-[8px] text-destructive/80 break-words">{task.rejection_reason}</p>
                                  </div>
                                </div>
                              </div>
                            )}
                            <div className="flex flex-wrap items-center gap-1 text-[8px] text-muted-foreground mb-1">
                              <Badge variant="outline" className="gap-0.5 text-[8px] h-4 px-1">
                                <FileText className="w-2 h-2" />
                                {task.category}
                              </Badge>
                              {task.created_at && (
                                <div className="flex items-center gap-0.5">
                                  <Calendar className="w-2 h-2" />
                                  <span>Created {new Date(task.created_at).toLocaleDateString()}</span>
                                </div>
                              )}
                            </div>
                            {!isDisabled && (
                              <div className="flex gap-1">
                                {task.status === 'pending' && (
                                  <Button
                                    size="sm"
                                    onClick={() => {
                                      handleStartTask(task);
                                      navigate(`/task-form?id=${task.task_id}`);
                                    }}
                                    className="gap-1 h-6 text-[10px] flex-1 sm:flex-initial px-2"
                                  >
                                    <Play className="w-2.5 h-2.5" />
                                    Start Task
                                  </Button>
                                )}
                                {task.status === 'in_progress' && (
                                  <Button
                                    size="sm"
                                    onClick={() => navigate(`/task-form?id=${task.task_id}`)}
                                    variant="outline"
                                    className="gap-1 h-6 text-[10px] flex-1 sm:flex-initial px-2"
                                  >
                                    <FileText className="w-2.5 h-2.5" />
                                    <span className="hidden sm:inline">Continue</span>
                                    <span className="sm:hidden">Continue</span>
                                  </Button>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="pending">
              <div className="space-y-1.5 sm:space-y-2">
                {pendingTasks.length === 0 ? (
                  <div className="py-8 sm:py-12 text-center">
                    <Clock className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 text-muted-foreground" />
                    <p className="text-xs sm:text-sm text-muted-foreground">No pending tasks</p>
                  </div>
                ) : (
                  pendingTasks.map((task) => {
                    const isRejected = task.approval_status === 'rejected';
                    
                    return (
                      <div key={task.id} className={`border rounded-lg p-1.5 sm:p-2 hover:shadow-md transition-all ${getStatusColor(task.status)}`}>
                          <div className="flex flex-col gap-0.5 sm:gap-1">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1 sm:gap-1.5 mb-0.5 flex-wrap">
                                <h3 className="font-semibold text-[10px] sm:text-xs break-words flex-1 leading-tight">{task.name}</h3>
                                <div className="scale-75 origin-right">
                                  {getStatusBadge(task.status, task.approval_status)}
                                </div>
                              </div>
                              {task.description && (
                                <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-1 break-words leading-snug line-clamp-1">{task.description}</p>
                              )}
                              {isRejected && task.rejection_reason && (
                                <div className="bg-destructive/10 border border-destructive/20 rounded p-1 mb-1">
                                  <div className="flex items-start gap-1">
                                    <AlertCircle className="w-2.5 h-2.5 text-destructive mt-0.5 flex-shrink-0" />
                                    <div className="min-w-0 flex-1">
                                      <p className="font-semibold text-[9px] text-destructive">Task Rejected</p>
                                      <p className="text-[8px] text-destructive/80 break-words">{task.rejection_reason}</p>
                                    </div>
                                  </div>
                                </div>
                              )}
                              <Badge variant="outline" className="mb-1 text-[8px] h-4 px-1">{task.category}</Badge>
                              <Button
                                size="sm"
                                onClick={() => {
                                  handleStartTask(task);
                                  navigate(`/task-form?id=${task.task_id}`);
                                }}
                                className="gap-1 h-6 text-[10px] w-full sm:w-auto px-2"
                              >
                                <Play className="w-2.5 h-2.5" />
                                Start Task
                              </Button>
                            </div>
                          </div>
                      </div>
                    );
                  })
                )}
              </div>
            </TabsContent>

            <TabsContent value="in_progress">
              <div className="space-y-1.5 sm:space-y-2">
                {inProgressTasks.length === 0 ? (
                  <div className="py-8 sm:py-12 text-center">
                    <AlertCircle className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 text-muted-foreground" />
                    <p className="text-xs sm:text-sm text-muted-foreground">No tasks in progress</p>
                  </div>
                ) : (
                  inProgressTasks.map((task) => {
                    const isRejected = task.approval_status === 'rejected';
                    
                    return (
                      <div key={task.id} className={`border rounded-lg p-1.5 sm:p-2 hover:shadow-md transition-all ${getStatusColor(task.status)}`}>
                          <div className="flex flex-col gap-0.5 sm:gap-1">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1 sm:gap-1.5 mb-0.5 flex-wrap">
                                <h3 className="font-semibold text-[10px] sm:text-xs break-words flex-1 leading-tight">{task.name}</h3>
                                <div className="scale-75 origin-right">
                                  {getStatusBadge(task.status, task.approval_status)}
                                </div>
                              </div>
                              {task.description && (
                                <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-1 break-words leading-snug line-clamp-1">{task.description}</p>
                              )}
                              {isRejected && task.rejection_reason && (
                                <div className="bg-destructive/10 border border-destructive/20 rounded p-1 mb-1">
                                  <div className="flex items-start gap-1">
                                    <AlertCircle className="w-2.5 h-2.5 text-destructive mt-0.5 flex-shrink-0" />
                                    <div className="min-w-0 flex-1">
                                      <p className="font-semibold text-[9px] text-destructive">Task Rejected</p>
                                      <p className="text-[8px] text-destructive/80 break-words">{task.rejection_reason}</p>
                                    </div>
                                  </div>
                                </div>
                              )}
                              <Badge variant="outline" className="mb-1 text-[8px] h-4 px-1">{task.category}</Badge>
                              <Button
                                size="sm"
                                onClick={() => navigate(`/task-form?id=${task.task_id}`)}
                                variant="outline"
                                className="gap-1 h-6 text-[10px] w-full sm:w-auto px-2"
                              >
                                <FileText className="w-2.5 h-2.5" />
                                <span className="hidden sm:inline">Continue</span>
                                <span className="sm:hidden">Continue</span>
                              </Button>
                            </div>
                          </div>
                      </div>
                    );
                  })
                )}
              </div>
            </TabsContent>

            <TabsContent value="completed">
              <div className="space-y-1.5 sm:space-y-2">
                {completedTasks.length === 0 ? (
                  <div className="py-8 sm:py-12 text-center">
                    <CheckCircle2 className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4 text-muted-foreground" />
                    <p className="text-xs sm:text-sm text-muted-foreground">No completed tasks yet</p>
                  </div>
                ) : (
                  completedTasks.map((task) => {
                    const isApproved = task.approval_status === 'approved';
                    
                    return (
                      <div key={task.id} className={`border rounded-lg p-1.5 sm:p-2 ${getStatusColor(task.status)} opacity-75`}>
                          <div className="flex flex-col gap-0.5 sm:gap-1">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1 sm:gap-1.5 mb-0.5 flex-wrap">
                                <CheckCircle2 className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-green-600 flex-shrink-0" />
                                <h3 className="font-semibold text-[10px] sm:text-xs break-words flex-1 leading-tight">{task.name}</h3>
                                <div className="scale-75 origin-right">
                                  {getStatusBadge(task.status, task.approval_status)}
                                </div>
                              </div>
                              {task.description && (
                                <p className="text-[9px] sm:text-[10px] text-muted-foreground mb-1 break-words leading-snug line-clamp-1">{task.description}</p>
                              )}
                              <div className="flex flex-wrap items-center gap-1">
                                <Badge variant="outline" className="text-[8px] h-4 px-1">{task.category}</Badge>
                                {task.completed_at && (
                                  <span className="text-[8px] text-muted-foreground">
                                    Completed {new Date(task.completed_at).toLocaleDateString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                      </div>
                    );
                  })
                )}
              </div>
            </TabsContent>
          </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Task Workspace Modal */}
        {currentWorkingTask && (
          <TaskWorkspaceModal
            open={workspaceOpen}
            onOpenChange={setWorkspaceOpen}
            task={currentWorkingTask}
            onComplete={handleCompleteTask}
            canComplete={hasInteractedWithWorkspace}
            onInteraction={handleWorkspaceInteraction}
            onTaskAutoCompleted={async () => {
              await fetchTasks();
              setWorkspaceOpen(false);
              setCurrentWorkingTask(null);
            }}
          />
        )}
      </div>
    </div>
  );
}