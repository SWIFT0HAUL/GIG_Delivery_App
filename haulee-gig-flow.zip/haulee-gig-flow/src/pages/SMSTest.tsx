import { useState } from 'react';
import { PhoneVerification } from '@/components/auth/PhoneVerification';
import { useTwilioSMS } from '@/hooks/useTwilioSMS';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Phone, MessageSquare, Shield, CheckCircle } from 'lucide-react';
import { formatPhoneNumber } from '@/lib/smsUtils';

export default function SMSTest() {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [customMessage, setCustomMessage] = useState('');
  const [verifiedPhone, setVerifiedPhone] = useState<string | null>(null);
  
  const { sendSMS, sendVerificationCode, sendMFACode, sendNotification, sending } = useTwilioSMS();

  const handleQuickTest = async () => {
    if (!phoneNumber) return;
    const formatted = formatPhoneNumber(phoneNumber);
    await sendNotification(formatted, 'Hello from Haulee! This is a test notification.');
  };

  const handleSendVerification = async () => {
    if (!phoneNumber) return;
    const formatted = formatPhoneNumber(phoneNumber);
    await sendVerificationCode(formatted, '123456');
  };

  const handleSendMFA = async () => {
    if (!phoneNumber) return;
    const formatted = formatPhoneNumber(phoneNumber);
    await sendMFACode(formatted, '987654');
  };

  const handleSendCustom = async () => {
    if (!phoneNumber || !customMessage) return;
    const formatted = formatPhoneNumber(phoneNumber);
    await sendSMS({
      to: formatted,
      message: customMessage,
      type: 'notification'
    });
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-background via-background to-muted/20 p-4 sm:p-6 lg:p-8">
      <div className="container max-w-6xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold">Twilio SMS Integration Test</h1>
          <p className="text-muted-foreground">
            Test your SMS functionality and phone verification
          </p>
        </div>

        <Tabs defaultValue="quick" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="quick">
              <Phone className="h-4 w-4 mr-2" />
              Quick Test
            </TabsTrigger>
            <TabsTrigger value="verification">
              <Shield className="h-4 w-4 mr-2" />
              Full Verification
            </TabsTrigger>
            <TabsTrigger value="templates">
              <MessageSquare className="h-4 w-4 mr-2" />
              Message Templates
            </TabsTrigger>
          </TabsList>

          {/* Quick Test Tab */}
          <TabsContent value="quick" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Quick SMS Test</CardTitle>
                <CardDescription>
                  Send a test SMS to verify your Twilio integration is working
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phone-quick">Your Phone Number</Label>
                  <Input
                    id="phone-quick"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                  <p className="text-sm text-muted-foreground">
                    Use your actual phone number to receive test messages
                  </p>
                </div>
                <Button 
                  onClick={handleQuickTest} 
                  className="w-full"
                  disabled={sending || !phoneNumber}
                >
                  {sending ? 'Sending...' : 'Send Test SMS'}
                </Button>
              </CardContent>
            </Card>

            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">How It Works</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex items-start gap-2">
                    <div className="bg-primary/10 text-primary rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">1</div>
                    <p>Your phone number is formatted to E.164 standard (+15551234567)</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="bg-primary/10 text-primary rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">2</div>
                    <p>Request is sent to Supabase Edge Function with authentication</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="bg-primary/10 text-primary rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">3</div>
                    <p>Edge function securely calls Twilio API with your credentials</p>
                  </div>
                  <div className="flex items-start gap-2">
                    <div className="bg-primary/10 text-primary rounded-full w-6 h-6 flex items-center justify-center flex-shrink-0 mt-0.5">4</div>
                    <p>Twilio sends SMS and returns delivery status</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Check Results</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      Monitor your SMS delivery and debug any issues:
                    </p>
                    <div className="flex flex-col gap-2">
                      <Button variant="outline" size="sm" asChild>
                        <a 
                          href="https://supabase.com/dashboard/project/cqoydkxlonzobykwjcin/functions/send-sms/logs" 
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          View Edge Function Logs
                        </a>
                      </Button>
                      <Button variant="outline" size="sm" asChild>
                        <a 
                          href="https://console.twilio.com/us1/monitor/logs/sms" 
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          View Twilio Console
                        </a>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Full Verification Tab */}
          <TabsContent value="verification" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Complete Phone Verification Flow</CardTitle>
                <CardDescription>
                  Test the full verification experience with code generation and validation
                </CardDescription>
              </CardHeader>
              <CardContent>
                {verifiedPhone ? (
                  <div className="text-center py-8 space-y-4">
                    <CheckCircle className="h-16 w-16 text-green-500 mx-auto" />
                    <div>
                      <h3 className="text-xl font-semibold">Phone Verified!</h3>
                      <p className="text-muted-foreground">{verifiedPhone}</p>
                    </div>
                    <Button onClick={() => setVerifiedPhone(null)}>
                      Test Again
                    </Button>
                  </div>
                ) : (
                  <PhoneVerification
                    onVerified={(phone) => setVerifiedPhone(phone)}
                    title="Test Phone Verification"
                    description="This is how your users will verify their phone numbers"
                  />
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Message Templates Tab */}
          <TabsContent value="templates" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Test Message Templates</CardTitle>
                <CardDescription>
                  Try different types of messages your app can send
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="phone-templates">Phone Number</Label>
                  <Input
                    id="phone-templates"
                    type="tel"
                    placeholder="+1 (555) 123-4567"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>

                <div className="grid gap-3">
                  <Button
                    onClick={handleSendVerification}
                    variant="outline"
                    className="justify-start"
                    disabled={sending || !phoneNumber}
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Verification Code (123456)
                  </Button>
                  
                  <Button
                    onClick={handleSendMFA}
                    variant="outline"
                    className="justify-start"
                    disabled={sending || !phoneNumber}
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    MFA Code (987654)
                  </Button>

                  <div className="space-y-2 pt-4 border-t">
                    <Label htmlFor="custom-message">Custom Message</Label>
                    <Input
                      id="custom-message"
                      placeholder="Enter your custom message"
                      value={customMessage}
                      onChange={(e) => setCustomMessage(e.target.value)}
                    />
                    <Button
                      onClick={handleSendCustom}
                      className="w-full"
                      disabled={sending || !phoneNumber || !customMessage}
                    >
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Send Custom Message
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <Card className="bg-muted/50">
          <CardHeader>
            <CardTitle className="text-lg">Integration Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Twilio credentials configured</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Edge function deployed</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>React hooks ready</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                <span>Verification component available</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
