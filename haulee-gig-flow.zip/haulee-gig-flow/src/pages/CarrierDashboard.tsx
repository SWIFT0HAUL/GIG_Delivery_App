import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { DispatchProvider } from '@/contexts/DispatchContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Truck, Users, DollarSign, Package, ArrowLeft, 
  LayoutDashboard, Briefcase, FileText, Wrench, 
  Shield, BarChart3, FileSignature, Bell, UserCircle,
  Calendar, Menu, X, AlertTriangle, CheckCircle, Clock
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { CarrierJobs } from '@/components/carrier/CarrierJobs';
import Fleet from '@/pages/Fleet';
import { CarrierEarnings } from '@/components/carrier/CarrierEarnings';
import { CarrierContracts } from '@/components/carrier/CarrierContracts';
import { CarrierNotifications } from '@/components/carrier/CarrierNotifications';
import { CarrierProfile } from '@/components/carrier/CarrierProfile';
import { CarrierDrivers } from '@/components/carrier/CarrierDrivers';
import { CarrierDispatch } from '@/components/carrier/CarrierDispatch';
import { CarrierInvoices } from '@/components/carrier/CarrierInvoices';
import { CarrierMaintenance } from '@/components/carrier/CarrierMaintenance';
import { CarrierCompliance } from '@/components/carrier/CarrierCompliance';
import { CarrierAnalytics } from '@/components/carrier/CarrierAnalytics';
import { CarrierDisputes } from '@/components/carrier/CarrierDisputes';
import { DashboardTopCard } from '@/components/dashboard/DashboardTopCard';
import { StickyHorizontalScrollbar } from '@/components/dashboard/StickyHorizontalScrollbar';
import { cn } from '@/lib/utils';

export default function CarrierDashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [accountNumber, setAccountNumber] = useState<string>('');
  const mainRef = useRef<HTMLDivElement>(null);
  
  const companyName = user?.user_metadata?.company_name || user?.user_metadata?.first_name || user?.email?.split('@')[0] || 'Carrier';

  useEffect(() => {
    const fetchAccountNumber = async () => {
      if (user?.id) {
        const { data, error } = await supabase
          .from('user_account_number')
          .select('account_number')
          .eq('user_id', user.id)
          .single();
        
        if (data && !error) {
          setAccountNumber(data.account_number);
        }
      }
    };
    fetchAccountNumber();
  }, [user?.id]);

  // Fetch dashboard statistics
  const { data: stats } = useQuery({
    queryKey: ['carrier-dashboard-stats', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      try {
        // Fetch active jobs count
        const { data: activeJobs } = await supabase
          .from('jobs')
          .select('id, status, pay_amount, title, pickup_location, delivery_location, created_at')
          .eq('carrier_id', user.id)
          .or('status.eq.assigned,status.eq.claimed,status.eq.on_hold');
        
        const jobsCount = activeJobs?.length || 0;
        
        // Fetch fleet data
        const { data: vehicles } = await supabase
          .from('vehicles')
          .select('status')
          .eq('carrier_id', user.id);
        
        const fleetCount = vehicles?.length || 0;
        const activeVehicles = vehicles?.filter((v: any) => v.status === 'active' || v.status === 'on_route').length || 0;
        const maintenanceVehicles = vehicles?.filter((v: any) => v.status === 'maintenance').length || 0;
        
        // Fetch drivers - simplified for now
        const driversCount = 0; // Will be implemented once profiles table is properly configured
        
        // Calculate revenue (completed jobs this month)
        const startOfMonth = new Date();
        startOfMonth.setDate(1);
        startOfMonth.setHours(0, 0, 0, 0);
        
        const { data: completedJobs } = await supabase
          .from('jobs')
          .select('pay_amount')
          .eq('carrier_id', user.id)
          .eq('status', 'completed')
          .gte('completed_at', startOfMonth.toISOString());
        
        const revenue = completedJobs?.reduce((sum: number, job: any) => sum + (job.pay_amount || 0), 0) || 0;
        
        return {
          jobsCount,
          fleetCount,
          driversCount,
          revenue,
          activeVehicles,
          maintenanceVehicles,
          activeDrivers: Math.floor(driversCount * 0.85),
          offDutyDrivers: Math.ceil(driversCount * 0.15),
          recentJobs: activeJobs?.slice(0, 3) || []
        };
      } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        return {
          jobsCount: 0,
          fleetCount: 0,
          driversCount: 0,
          revenue: 0,
          activeVehicles: 0,
          maintenanceVehicles: 0,
          activeDrivers: 0,
          offDutyDrivers: 0,
          recentJobs: []
        };
      }
    },
    enabled: !!user?.id,
    refetchInterval: 30000,
  });

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'jobs', label: 'Jobs', icon: Briefcase },
    { id: 'fleet', label: 'Fleet', icon: Truck },
    { id: 'drivers', label: 'Drivers', icon: Users },
    { id: 'dispatch', label: 'Dispatch', icon: Calendar },
    { id: 'earnings', label: 'Earnings', icon: DollarSign },
    { id: 'invoices', label: 'Invoices', icon: FileText },
    { id: 'maintenance', label: 'Maintenance', icon: Wrench },
    { id: 'compliance', label: 'Compliance', icon: Shield },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
    { id: 'contracts', label: 'Contracts', icon: FileSignature },
    { id: 'disputes', label: 'Disputes', icon: AlertTriangle },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'profile', label: 'Settings', icon: UserCircle },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <>
            <DashboardTopCard
              companyName={companyName}
              motivationalText="Manage your fleet efficiently"
              showOnlineToggle={true}
              avatarUrl={user?.user_metadata?.avatar_url}
            />
            
            {/* Stats Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mt-6">
              <Card className="border-l-4 border-l-blue-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Jobs</CardTitle>
                  <Package className="h-4 w-4 text-blue-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">{stats?.jobsCount || 0}</div>
                  <p className="text-xs text-muted-foreground">Currently in progress</p>
                </CardContent>
              </Card>
              <Card className="border-l-4 border-l-purple-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Fleet Size</CardTitle>
                  <Truck className="h-4 w-4 text-purple-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">{stats?.fleetCount || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats?.activeVehicles || 0} active, {stats?.maintenanceVehicles || 0} maintenance
                  </p>
                </CardContent>
              </Card>
              <Card className="border-l-4 border-l-orange-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Drivers</CardTitle>
                  <Users className="h-4 w-4 text-orange-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">{stats?.driversCount || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {stats?.activeDrivers || 0} online, {stats?.offDutyDrivers || 0} offline
                  </p>
                </CardContent>
              </Card>
              <Card className="border-l-4 border-l-green-500">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">This Month Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-green-600" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">
                    ${stats?.revenue?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
                  </div>
                  <p className="text-xs text-muted-foreground">From completed jobs</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Fleet Status</CardTitle>
                  <CardDescription>Current status of your vehicles</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-3 rounded-lg bg-green-500/5 border border-green-500/20">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm font-medium">Active / On Route</span>
                      </div>
                      <span className="text-sm font-bold text-green-600">{stats?.activeVehicles || 0} vehicles</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-yellow-500/5 border border-yellow-500/20">
                      <div className="flex items-center space-x-3">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm font-medium">Maintenance</span>
                      </div>
                      <span className="text-sm font-bold text-yellow-600">{stats?.maintenanceVehicles || 0} vehicles</span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50 border">
                      <div className="flex items-center space-x-3">
                        <Truck className="h-4 w-4 text-muted-foreground" />
                        <span className="text-sm font-medium">Total Fleet</span>
                      </div>
                      <span className="text-sm font-bold">{stats?.fleetCount || 0} vehicles</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Jobs</CardTitle>
                  <CardDescription>Latest job activity</CardDescription>
                </CardHeader>
                <CardContent>
                  {stats?.recentJobs && stats.recentJobs.length > 0 ? (
                    <div className="space-y-4">
                      {stats.recentJobs.map((job: any) => {
                        const pickupLoc = job.pickup_location as any;
                        const deliveryLoc = job.delivery_location as any;
                        return (
                          <div key={job.id} className="flex items-start space-x-3 p-3 rounded-lg border">
                            <div className="flex-shrink-0 mt-1">
                              {job.status === 'completed' ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : job.status === 'assigned' ? (
                                <Truck className="h-4 w-4 text-blue-600" />
                              ) : (
                                <Clock className="h-4 w-4 text-yellow-600" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate">{job.title || 'Untitled Job'}</p>
                              <p className="text-xs text-muted-foreground truncate">
                                {pickupLoc?.city}, {pickupLoc?.state} → {deliveryLoc?.city}, {deliveryLoc?.state}
                              </p>
                            </div>
                            <Badge 
                              variant={
                                job.status === 'completed' ? 'default' : 
                                job.status === 'assigned' ? 'secondary' : 
                                'outline'
                              }
                              className={
                                job.status === 'completed' ? 'bg-green-600' : 
                                job.status === 'assigned' ? 'bg-blue-600' : 
                                ''
                              }
                            >
                              ${job.pay_amount?.toFixed(0)}
                            </Badge>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-muted-foreground">
                      <Package className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">No recent jobs</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </>
        );
      case 'jobs':
        return <CarrierJobs />;
      case 'fleet':
        return <Fleet />;
      case 'drivers':
        return <CarrierDrivers />;
      case 'dispatch':
        return <CarrierDispatch />;
      case 'earnings':
        return <CarrierEarnings />;
      case 'invoices':
        return <CarrierInvoices />;
      case 'maintenance':
        return <CarrierMaintenance />;
      case 'compliance':
        return <CarrierCompliance />;
      case 'analytics':
        return <CarrierAnalytics />;
      case 'contracts':
        return <CarrierContracts />;
      case 'disputes':
        return <CarrierDisputes />;
      case 'notifications':
        return <CarrierNotifications />;
      case 'profile':
        return <CarrierProfile />;
      default:
        return null;
    }
  };

  return (
    <DispatchProvider>
      <div className="h-screen bg-background flex overflow-hidden">
        {/* Mobile Sidebar Overlay */}
        {sidebarOpen && (
          <div 
            className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:sticky top-0 left-0 z-50 h-screen w-64 border-r bg-card transition-transform duration-300 lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="h-[72px] px-6 border-b flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Haulee</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Menu Items */}
          <ScrollArea className="flex-1 px-3 py-4">
            <div className="space-y-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start gap-3",
                      isActive && "bg-primary text-primary-foreground"
                    )}
                    onClick={() => {
                      setActiveSection(item.id);
                      setSidebarOpen(false);
                    }}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                );
              })}
            </div>
          </ScrollArea>

          {/* Sidebar Footer */}
          <div className="p-4 border-t">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-sm font-medium text-primary">
                  {companyName.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{companyName}</p>
                <p className="text-xs text-muted-foreground">
                  {accountNumber ? `#${accountNumber}` : 'Loading...'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-card border-b h-[72px]">
          <div className="flex items-center gap-4 px-4 sm:px-6 lg:px-8 h-full">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl sm:text-2xl font-bold text-foreground truncate">
                {menuItems.find(item => item.id === activeSection)?.label || 'Carrier Dashboard'}
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block">
                Manage your fleet and shipments
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(-1)}
                className="hidden sm:flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={signOut}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main ref={mainRef} className="flex-1 overflow-auto scrollbar-visible">
          <div className="max-w-7xl mx-auto py-4 sm:py-8">
            <div className="space-y-4 md:space-y-6">
              {renderContent()}
            </div>
          </div>
        </main>
        <StickyHorizontalScrollbar targetRef={mainRef} />
      </div>
    </div>
    </DispatchProvider>
  );
}
