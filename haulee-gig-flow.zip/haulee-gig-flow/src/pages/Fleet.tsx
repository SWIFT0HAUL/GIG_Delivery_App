import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin, Fuel, Calendar, Plus, MoreVertical } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const Fleet = () => {
  const { user } = useAuth();
  const [vehicles, setVehicles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-green-100 text-green-800';
      case 'On Route': return 'bg-blue-100 text-blue-800';
      case 'Maintenance': return 'bg-yellow-100 text-yellow-800';
      case 'Inactive': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isAssignOpen, setIsAssignOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isMaintenanceOpen, setIsMaintenanceOpen] = useState(false);
  const [isRemoveOpen, setIsRemoveOpen] = useState(false);
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<any>(null);
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const [maintenanceDate, setMaintenanceDate] = useState<string>('');
  const [maintenanceType, setMaintenanceType] = useState<string>('');
  
  const [newVehicle, setNewVehicle] = useState({
    name: '',
    type: '',
    plate: '',
    status: 'inactive',
    location: '',
    mileage: '',
    next_maintenance: '',
    driver: 'Unassigned',
    capacity: '',
    vin: '',
    model: ''
  });

  const availableDrivers = ['John Smith', 'Sarah Johnson', 'Robert Kim', 'Jessica Lee'];

  useEffect(() => {
    fetchVehicles();
  }, [user]);

  const fetchVehicles = async () => {
    if (!user) return;
    
    setLoading(true);
    const { data, error } = await supabase
      .from('vehicles')
      .select('*')
      .eq('carrier_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      toast.error('Failed to load vehicles', { description: error.message });
    } else {
      setVehicles(data || []);
    }
    setLoading(false);
  };

  const handleAddVehicle = async () => {
    if (!user) return;
    
    if (!newVehicle.name || !newVehicle.type || !newVehicle.plate) {
      toast.error('Missing required fields', { description: 'Please fill in name, type, and plate number' });
      return;
    }

    const { data, error } = await supabase
      .from('vehicles')
      .insert([{
        ...newVehicle,
        carrier_id: user.id,
        next_maintenance: newVehicle.next_maintenance || null
      }])
      .select();

    if (error) {
      toast.error('Failed to add vehicle', { description: error.message });
    } else {
      toast.success('Vehicle added successfully');
      setIsAddOpen(false);
      setNewVehicle({
        name: '',
        type: '',
        plate: '',
        status: 'inactive',
        location: '',
        mileage: '',
        next_maintenance: '',
        driver: 'Unassigned',
        capacity: '',
        vin: '',
        model: ''
      });
      fetchVehicles();
    }
  };

  const handleTrackVehicle = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsTrackingOpen(true);
  };

  const handleViewDetails = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsDetailsOpen(true);
  };

  const handleAssignDriver = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsAssignOpen(true);
  };

  const handleConfirmAssignment = () => {
    if (selectedVehicle && selectedDriver) {
      toast.success('Driver assigned successfully', {
        description: `${selectedDriver} has been assigned to ${selectedVehicle.name}`,
      });
      setIsAssignOpen(false);
      setSelectedDriver('');
    }
  };

  const handleEditVehicle = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsEditOpen(true);
  };

  const handleViewHistory = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsHistoryOpen(true);
  };

  const handleScheduleMaintenance = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsMaintenanceOpen(true);
  };

  const handleRemoveVehicle = (vehicle: any) => {
    setSelectedVehicle(vehicle);
    setIsRemoveOpen(true);
  };

  const handleConfirmMaintenance = async () => {
    if (!selectedVehicle || !maintenanceDate || !maintenanceType) {
      toast.error('All fields are required', {
        description: 'Please select a maintenance type and date',
      });
      return;
    }

    if (!user?.id) {
      toast.error('Not authenticated', {
        description: 'Please log in to schedule maintenance',
      });
      return;
    }

    const { error } = await supabase
      .from('maintenance_schedules')
      .insert({
        vehicle_id: selectedVehicle.id,
        user_id: user.id,
        maintenance_type: maintenanceType,
        scheduled_date: maintenanceDate,
        status: 'scheduled',
      });

    if (error) {
      toast.error('Failed to schedule maintenance', { description: error.message });
      return;
    }

    toast.success('Maintenance scheduled', {
      description: `${maintenanceType} scheduled for ${selectedVehicle.name} on ${maintenanceDate}`,
    });
    
    setIsMaintenanceOpen(false);
    setMaintenanceDate('');
    setMaintenanceType('');
    setSelectedVehicle(null);
  };

  const handleConfirmRemove = async () => {
    if (!selectedVehicle) return;

    const { error } = await supabase
      .from('vehicles')
      .delete()
      .eq('id', selectedVehicle.id);

    if (error) {
      toast.error('Failed to remove vehicle', { description: error.message });
    } else {
      toast.success('Vehicle removed', {
        description: `${selectedVehicle.name} has been removed from the fleet`,
      });
      setIsRemoveOpen(false);
      setSelectedVehicle(null);
      fetchVehicles();
    }
  };

  const handleSaveEdit = () => {
    if (selectedVehicle) {
      toast.success('Vehicle updated', {
        description: `${selectedVehicle.name} has been updated successfully`,
      });
      setIsEditOpen(false);
    }
  };

  return (
    <div className="container mx-auto px-6 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Fleet Management</h1>
          <p className="text-muted-foreground">
            Monitor and manage your vehicle fleet
          </p>
        </div>
        <Button onClick={() => setIsAddOpen(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add Vehicle
        </Button>
      </div>

      {/* Fleet Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Vehicles</CardTitle>
            <Truck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">All registered vehicles</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <Badge className="bg-green-100 text-green-800">Active</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Currently operational</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Maintenance Due</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Fuel Efficiency</CardTitle>
            <Fuel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8.5</div>
            <p className="text-xs text-muted-foreground">MPG across fleet</p>
          </CardContent>
        </Card>
      </div>

      {/* Vehicle List */}
      <div className="grid gap-6">
        {loading ? (
          <Card>
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">Loading vehicles...</p>
            </CardContent>
          </Card>
        ) : vehicles.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center">
              <Truck className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg font-medium mb-2">No vehicles yet</p>
              <p className="text-sm text-muted-foreground mb-4">Add your first vehicle to get started</p>
              <Button onClick={() => setIsAddOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Vehicle
              </Button>
            </CardContent>
          </Card>
        ) : vehicles.map((vehicle) => (
          <Card key={vehicle.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div className="flex items-start space-x-4">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Truck className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">{vehicle.name}</CardTitle>
                    <CardDescription>
                      {vehicle.type} • {vehicle.plate} {vehicle.capacity && `• ${vehicle.capacity}`}
                    </CardDescription>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge className={getStatusColor(vehicle.status)}>
                    {vehicle.status}
                  </Badge>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-48 bg-background z-50 border border-border">
                      <DropdownMenuItem onClick={() => handleEditVehicle(vehicle)}>Edit Vehicle</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleViewHistory(vehicle)}>View History</DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleScheduleMaintenance(vehicle)}>Schedule Maintenance</DropdownMenuItem>
                      <DropdownMenuItem className="text-destructive" onClick={() => handleRemoveVehicle(vehicle)}>Remove Vehicle</DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Current Location</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{vehicle.location}</p>
                </div>
                
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Fuel className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Mileage & Driver</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{vehicle.mileage}</p>
                  <p className="text-sm text-muted-foreground">Driver: {vehicle.driver}</p>
                </div>
                
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">Next Maintenance</span>
                  </div>
                  <p className="text-sm text-muted-foreground">{vehicle.next_maintenance || 'Not scheduled'}</p>
                </div>
              </div>
              
              <div className="flex space-x-2 mt-4">
                <Button size="sm" variant="outline" onClick={() => handleTrackVehicle(vehicle)}>Track Vehicle</Button>
                <Button size="sm" variant="outline" onClick={() => handleViewDetails(vehicle)}>View Details</Button>
                <Button size="sm" variant="outline" onClick={() => handleAssignDriver(vehicle)}>Assign Driver</Button>
              </div>
            </CardContent>
          </Card>
          ))}
      </div>

    {/* Add Vehicle Dialog */}
    <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Add New Vehicle</DialogTitle>
          <DialogDescription>Enter vehicle information to add to your fleet</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Vehicle Name *</Label>
              <Input
                id="name"
                placeholder="e.g., Truck #001"
                value={newVehicle.name}
                onChange={(e) => setNewVehicle({ ...newVehicle, name: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Type *</Label>
              <Select value={newVehicle.type} onValueChange={(value) => setNewVehicle({ ...newVehicle, type: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type..." />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="Box Truck">Box Truck</SelectItem>
                  <SelectItem value="Cargo Van">Cargo Van</SelectItem>
                  <SelectItem value="Flatbed">Flatbed</SelectItem>
                  <SelectItem value="Refrigerated">Refrigerated</SelectItem>
                  <SelectItem value="Semi Truck">Semi Truck</SelectItem>
                  <SelectItem value="Pickup Truck">Pickup Truck</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="plate">License Plate *</Label>
              <Input
                id="plate"
                placeholder="e.g., ABC-1234"
                value={newVehicle.plate}
                onChange={(e) => setNewVehicle({ ...newVehicle, plate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={newVehicle.status} onValueChange={(value) => setNewVehicle({ ...newVehicle, status: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="on_route">On Route</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="vin">VIN</Label>
              <Input
                id="vin"
                placeholder="Vehicle Identification Number"
                value={newVehicle.vin}
                onChange={(e) => setNewVehicle({ ...newVehicle, vin: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="model">Model</Label>
              <Input
                id="model"
                placeholder="e.g., Ford F-150"
                value={newVehicle.model}
                onChange={(e) => setNewVehicle({ ...newVehicle, model: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="capacity">Capacity</Label>
              <Input
                id="capacity"
                placeholder="e.g., 3,500 lbs"
                value={newVehicle.capacity}
                onChange={(e) => setNewVehicle({ ...newVehicle, capacity: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="mileage">Current Mileage</Label>
              <Input
                id="mileage"
                placeholder="e.g., 45,230 miles"
                value={newVehicle.mileage}
                onChange={(e) => setNewVehicle({ ...newVehicle, mileage: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location</Label>
              <Input
                id="location"
                placeholder="e.g., Downtown Depot"
                value={newVehicle.location}
                onChange={(e) => setNewVehicle({ ...newVehicle, location: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="driver">Driver</Label>
              <Input
                id="driver"
                placeholder="Driver name"
                value={newVehicle.driver}
                onChange={(e) => setNewVehicle({ ...newVehicle, driver: e.target.value })}
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label htmlFor="next_maintenance">Next Maintenance Date</Label>
              <Input
                id="next_maintenance"
                type="date"
                value={newVehicle.next_maintenance}
                onChange={(e) => setNewVehicle({ ...newVehicle, next_maintenance: e.target.value })}
              />
            </div>
          </div>
          <div className="flex gap-2 pt-4">
            <Button variant="outline" className="flex-1" onClick={() => setIsAddOpen(false)}>Cancel</Button>
            <Button className="flex-1" onClick={handleAddVehicle}>Add Vehicle</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

    {/* Track Vehicle Dialog */}
    <Dialog open={isTrackingOpen} onOpenChange={setIsTrackingOpen}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="text-2xl">Track Vehicle</DialogTitle>
          <DialogDescription>
            Real-time tracking for {selectedVehicle?.name}
          </DialogDescription>
        </DialogHeader>
        {selectedVehicle && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <p className="text-sm"><span className="font-medium">Type:</span> {selectedVehicle.type}</p>
                <p className="text-sm"><span className="font-medium">Plate:</span> {selectedVehicle.plate}</p>
                <p className="text-sm"><span className="font-medium">Status:</span> {selectedVehicle.status}</p>
              </div>
              <div className="p-4 border rounded-lg">
                <p className="text-sm"><span className="font-medium">Driver:</span> {selectedVehicle.driver}</p>
                <p className="text-sm"><span className="font-medium">Location:</span> {selectedVehicle.location}</p>
              </div>
            </div>
            <div className="bg-muted/50 rounded-lg p-8 text-center border-2 border-dashed">
              <MapPin className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
              <p className="text-sm font-medium mb-1">Live Tracking Map</p>
              <p className="text-xs text-muted-foreground">Real-time GPS tracking will be displayed here</p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    {/* View Details Dialog */}
    <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">{selectedVehicle?.name}</DialogTitle>
          <DialogDescription>Complete vehicle information</DialogDescription>
        </DialogHeader>
        {selectedVehicle && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><p className="text-sm font-medium text-muted-foreground">Type</p><p>{selectedVehicle.type}</p></div>
              <div><p className="text-sm font-medium text-muted-foreground">Plate</p><p>{selectedVehicle.plate}</p></div>
              <div><p className="text-sm font-medium text-muted-foreground">Mileage</p><p>{selectedVehicle.mileage}</p></div>
              <div><p className="text-sm font-medium text-muted-foreground">Next Maintenance</p><p>{selectedVehicle.nextMaintenance}</p></div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    {/* Assign Driver Dialog */}
    <Dialog open={isAssignOpen} onOpenChange={setIsAssignOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Assign Driver</DialogTitle>
          <DialogDescription>Select a driver for {selectedVehicle?.name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <label className="text-sm font-medium">Select Driver</label>
          <Select value={selectedDriver} onValueChange={setSelectedDriver}>
            <SelectTrigger>
              <SelectValue placeholder="Choose a driver..." />
            </SelectTrigger>
            <SelectContent className="bg-background z-50">
              {availableDrivers.map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex gap-2 pt-2">
            <Button variant="outline" className="flex-1" onClick={() => { setIsAssignOpen(false); setSelectedDriver(''); }}>Cancel</Button>
            <Button className="flex-1" disabled={!selectedDriver} onClick={handleConfirmAssignment}>Confirm</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

    {/* Edit Vehicle Dialog */}
    <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="text-2xl">Edit Vehicle</DialogTitle>
          <DialogDescription>Update vehicle information</DialogDescription>
        </DialogHeader>
        {selectedVehicle && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Vehicle Name</label>
                <input type="text" defaultValue={selectedVehicle.name} className="w-full p-2 border rounded-md bg-background" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Type</label>
                <input type="text" defaultValue={selectedVehicle.type} className="w-full p-2 border rounded-md bg-background" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">License Plate</label>
                <input type="text" defaultValue={selectedVehicle.plate} className="w-full p-2 border rounded-md bg-background" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Status</label>
                <Select defaultValue={selectedVehicle.status}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="On Route">On Route</SelectItem>
                    <SelectItem value="Maintenance">Maintenance</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Capacity</label>
                <input type="text" defaultValue={selectedVehicle.capacity} className="w-full p-2 border rounded-md bg-background" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Location</label>
                <input type="text" defaultValue={selectedVehicle.location} className="w-full p-2 border rounded-md bg-background" />
              </div>
            </div>
            <div className="flex gap-2 pt-4">
              <Button variant="outline" className="flex-1" onClick={() => setIsEditOpen(false)}>Cancel</Button>
              <Button className="flex-1" onClick={handleSaveEdit}>Save Changes</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    {/* View History Dialog */}
    <Dialog open={isHistoryOpen} onOpenChange={setIsHistoryOpen}>
      <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">Vehicle History</DialogTitle>
          <DialogDescription>Maintenance and route history for {selectedVehicle?.name}</DialogDescription>
        </DialogHeader>
        {selectedVehicle && (
          <div className="space-y-6">
            <div>
              <h3 className="font-semibold mb-3">Maintenance History</h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 border rounded-lg">
                  <div className="p-2 bg-primary/10 rounded">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Oil Change</p>
                    <p className="text-sm text-muted-foreground">January 15, 2024</p>
                    <p className="text-xs text-muted-foreground mt-1">Service Center A - $85.00</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 p-3 border rounded-lg">
                  <div className="p-2 bg-primary/10 rounded">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Tire Rotation</p>
                    <p className="text-sm text-muted-foreground">December 10, 2023</p>
                    <p className="text-xs text-muted-foreground mt-1">Service Center B - $45.00</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 p-3 border rounded-lg">
                  <div className="p-2 bg-primary/10 rounded">
                    <Calendar className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Brake Inspection</p>
                    <p className="text-sm text-muted-foreground">November 5, 2023</p>
                    <p className="text-xs text-muted-foreground mt-1">Service Center A - $120.00</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Route History</h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3 p-3 border rounded-lg">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded">
                    <MapPin className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Route #1234</p>
                    <p className="text-sm text-muted-foreground">Downtown → Warehouse District</p>
                    <p className="text-xs text-muted-foreground mt-1">Completed: Jan 18, 2024 • 45 miles</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3 p-3 border rounded-lg">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded">
                    <MapPin className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">Route #1233</p>
                    <p className="text-sm text-muted-foreground">Suburb Area → Downtown</p>
                    <p className="text-xs text-muted-foreground mt-1">Completed: Jan 17, 2024 • 32 miles</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    {/* Schedule Maintenance Dialog */}
    <Dialog open={isMaintenanceOpen} onOpenChange={setIsMaintenanceOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Schedule Maintenance</DialogTitle>
          <DialogDescription>Schedule maintenance for {selectedVehicle?.name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Service Type</label>
            <Select value={maintenanceType} onValueChange={setMaintenanceType}>
              <SelectTrigger>
                <SelectValue placeholder="Select service type..." />
              </SelectTrigger>
              <SelectContent className="bg-background z-50">
                <SelectItem value="Oil Change">Oil Change</SelectItem>
                <SelectItem value="Tire Rotation">Tire Rotation</SelectItem>
                <SelectItem value="Brake Inspection">Brake Inspection</SelectItem>
                <SelectItem value="General Inspection">General Inspection</SelectItem>
                <SelectItem value="Engine Service">Engine Service</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium">Date</label>
            <input 
              type="date" 
              value={maintenanceDate} 
              onChange={(e) => setMaintenanceDate(e.target.value)}
              className="w-full p-2 border rounded-md bg-background" 
            />
          </div>
          <div className="flex gap-2 pt-2">
            <Button variant="outline" className="flex-1" onClick={() => { setIsMaintenanceOpen(false); setMaintenanceDate(''); setMaintenanceType(''); }}>Cancel</Button>
            <Button className="flex-1" disabled={!maintenanceDate || !maintenanceType} onClick={handleConfirmMaintenance}>Schedule</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>

    {/* Remove Vehicle Dialog */}
    <Dialog open={isRemoveOpen} onOpenChange={setIsRemoveOpen}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-2xl">Remove Vehicle</DialogTitle>
          <DialogDescription>Are you sure you want to remove this vehicle?</DialogDescription>
        </DialogHeader>
        {selectedVehicle && (
          <div className="space-y-4">
            <div className="p-4 border rounded-lg bg-muted/50">
              <p className="font-medium mb-2">{selectedVehicle.name}</p>
              <p className="text-sm text-muted-foreground">{selectedVehicle.type} • {selectedVehicle.plate}</p>
              <p className="text-sm text-muted-foreground">Driver: {selectedVehicle.driver}</p>
            </div>
            <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg">
              <p className="text-sm text-destructive">This action cannot be undone. The vehicle will be permanently removed from your fleet.</p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="flex-1" onClick={() => setIsRemoveOpen(false)}>Cancel</Button>
              <Button variant="destructive" className="flex-1" onClick={handleConfirmRemove}>Remove Vehicle</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>

    </div>
  );
};

export default Fleet;