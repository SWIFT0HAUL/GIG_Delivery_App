import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Briefcase, 
  Users, 
  DollarSign, 
  Bell, 
  ArrowLeft,
  TrendingUp,
  Calendar,
  CheckCircle,
  Clock,
  Menu,
  X,
  Home,
  Clipboard,
  FileText,
  CreditCard,
  BarChart3,
  MessageSquare,
  UserCircle,
  Shield,
  HandshakeIcon,
  AlertTriangle
} from 'lucide-react';
import { BrokerJobs } from '@/components/broker/BrokerJobs';
import { BrokerClients } from '@/components/broker/BrokerClients';
import { BrokerPayments } from '@/components/broker/BrokerPayments';
import { BrokerNotifications } from '@/components/broker/BrokerNotifications';
import { BrokerProfile } from '@/components/broker/BrokerProfile';
import { BrokerLoadBoard } from '@/components/broker/BrokerLoadBoard';
import { BrokerPostLoads } from '@/components/broker/BrokerPostLoads';
import { BrokerLoadHistory } from '@/components/broker/BrokerLoadHistory';
import { BrokerCarriers } from '@/components/broker/BrokerCarriers';
import { BrokerRateManagement } from '@/components/broker/BrokerRateManagement';
import { BrokerDispatch } from '@/components/broker/BrokerDispatch';
import { BrokerInvoicing } from '@/components/broker/BrokerInvoicing';
import { BrokerMarginAnalysis } from '@/components/broker/BrokerMarginAnalysis';
import { BrokerContracts } from '@/components/broker/BrokerContracts';
import { BrokerCompliance } from '@/components/broker/BrokerCompliance';
import { BrokerCreditManagement } from '@/components/broker/BrokerCreditManagement';
import { BrokerAnalytics } from '@/components/broker/BrokerAnalytics';
import { BrokerMessages } from '@/components/broker/BrokerMessages';
import { BrokerDisputes } from '@/components/broker/BrokerDisputes';
import { DashboardTopCard } from '@/components/dashboard/DashboardTopCard';
import { StickyHorizontalScrollbar } from '@/components/dashboard/StickyHorizontalScrollbar';
import { cn } from '@/lib/utils';

export default function BrokerDashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [accountNumber, setAccountNumber] = useState<string>('');
  const mainRef = useRef<HTMLDivElement>(null);
  
  const companyName = user?.user_metadata?.company_name || user?.user_metadata?.first_name || user?.email?.split('@')[0] || 'Broker';

  useEffect(() => {
    const fetchAccountNumber = async () => {
      if (user?.id) {
        const { data, error } = await supabase
          .from('user_account_number')
          .select('account_number')
          .eq('user_id', user.id)
          .single();
        
        if (data && !error) {
          setAccountNumber(data.account_number);
        }
      }
    };
    fetchAccountNumber();
  }, [user?.id]);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'load-board', label: 'Load Board', icon: Clipboard },
    { id: 'post-loads', label: 'Post Loads', icon: FileText },
    { id: 'jobs', label: 'Active Loads', icon: Briefcase },
    { id: 'history', label: 'Load History', icon: Calendar },
    { id: 'carriers', label: 'Carrier Network', icon: Users },
    { id: 'clients', label: 'Shipper Clients', icon: HandshakeIcon },
    { id: 'rate-management', label: 'Rate Management', icon: DollarSign },
    { id: 'dispatch', label: 'Dispatch & Operations', icon: TrendingUp },
    { id: 'invoicing', label: 'Invoicing & Billing', icon: FileText },
    { id: 'payments', label: 'Payments & Collections', icon: CreditCard },
    { id: 'margin', label: 'Margin Analysis', icon: BarChart3 },
    { id: 'contracts', label: 'Contracts & Agreements', icon: FileText },
    { id: 'compliance', label: 'Carrier Compliance', icon: Shield },
    { id: 'credit', label: 'Credit Management', icon: CreditCard },
    { id: 'analytics', label: 'Analytics & Reports', icon: BarChart3 },
    { id: 'disputes', label: 'Disputes', icon: AlertTriangle },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'profile', label: 'Settings', icon: UserCircle },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <>
            <DashboardTopCard
              companyName={companyName}
              motivationalText="Grow your brokerage business with Haulee"
              showOnlineToggle={false}
              avatarUrl={user?.user_metadata?.avatar_url}
            />
            
            {/* Stats Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mt-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Loads</CardTitle>
                  <Briefcase className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">24</div>
                  <p className="text-xs text-muted-foreground">+3 from last week</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Clients</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">87</div>
                  <p className="text-xs text-muted-foreground">+12% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Earnings</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">$12,340</div>
                  <p className="text-xs text-muted-foreground">+8% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
                  <Clock className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">7</div>
                  <p className="text-xs text-muted-foreground">Awaiting approval</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Load Status</CardTitle>
                  <CardDescription>Current load breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">In Transit</span>
                      </div>
                      <span className="text-sm font-medium">12 loads</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm">Pending Assignment</span>
                      </div>
                      <span className="text-sm font-medium">7 loads</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm">Delivered Today</span>
                      </div>
                      <span className="text-sm font-medium">5 loads</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest load updates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Load #LD-1234 Delivered</p>
                        <p className="text-xs text-muted-foreground">Chicago to NYC - 1 hour ago</p>
                      </div>
                      <Badge variant="secondary">Complete</Badge>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Load #LD-1235 Assigned</p>
                        <p className="text-xs text-muted-foreground">LA to Denver - 2 hours ago</p>
                      </div>
                      <Badge variant="outline">In Transit</Badge>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Load #LD-1236 Posted</p>
                        <p className="text-xs text-muted-foreground">Miami to Atlanta - 3 hours ago</p>
                      </div>
                      <Badge variant="outline">Pending</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        );
      case 'load-board':
        return <BrokerLoadBoard />;
      case 'post-loads':
        return <BrokerPostLoads />;
      case 'jobs':
        return <BrokerJobs />;
      case 'history':
        return <BrokerLoadHistory />;
      case 'carriers':
        return <BrokerCarriers />;
      case 'clients':
        return <BrokerClients />;
      case 'rate-management':
        return <BrokerRateManagement />;
      case 'dispatch':
        return <BrokerDispatch />;
      case 'invoicing':
        return <BrokerInvoicing />;
      case 'payments':
        return <BrokerPayments />;
      case 'margin':
        return <BrokerMarginAnalysis />;
      case 'contracts':
        return <BrokerContracts />;
      case 'compliance':
        return <BrokerCompliance />;
      case 'credit':
        return <BrokerCreditManagement />;
      case 'analytics':
        return <BrokerAnalytics />;
      case 'disputes':
        return <BrokerDisputes />;
      case 'messages':
        return <BrokerMessages />;
      case 'notifications':
        return <BrokerNotifications />;
      case 'profile':
        return <BrokerProfile />;
      default:
        return null;
    }
  };

  return (
    <div className="h-screen bg-background flex overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:sticky top-0 left-0 z-50 h-screen w-64 border-r bg-card transition-transform duration-300 lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="h-[72px] px-6 border-b flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Briefcase className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Haulee</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Menu Items */}
          <ScrollArea className="flex-1 px-3 py-4">
            <div className="space-y-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start gap-3",
                      isActive && "bg-primary text-primary-foreground"
                    )}
                    onClick={() => {
                      setActiveSection(item.id);
                      setSidebarOpen(false);
                    }}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                );
              })}
            </div>
          </ScrollArea>

          {/* Sidebar Footer */}
          <div className="p-4 border-t">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-sm font-medium text-primary">
                  {companyName.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{companyName}</p>
                <p className="text-xs text-muted-foreground">
                  {accountNumber ? `#${accountNumber}` : 'Loading...'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-card border-b h-[72px]">
          <div className="flex items-center gap-4 px-4 sm:px-6 lg:px-8 h-full">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl sm:text-2xl font-bold text-foreground truncate">
                {menuItems.find(item => item.id === activeSection)?.label || 'Broker Dashboard'}
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block">
                Manage loads, carriers, and clients
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(-1)}
                className="hidden sm:flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={signOut}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main ref={mainRef} className="flex-1 overflow-auto scrollbar-visible">
          <div className="max-w-7xl mx-auto py-4 sm:py-8">
            <div className="space-y-4 md:space-y-6">
              {renderContent()}
            </div>
          </div>
        </main>
        <StickyHorizontalScrollbar targetRef={mainRef} />
      </div>
    </div>
  );
}
