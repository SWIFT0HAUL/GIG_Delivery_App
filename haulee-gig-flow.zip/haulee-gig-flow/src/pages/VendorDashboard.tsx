import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Store, ShoppingBag, DollarSign, TrendingUp, ArrowLeft, 
  Home, Archive, BookOpen, ShoppingCart, History, 
  Calendar, Route, Users, Sparkles, Tag, 
  CreditCard, BarChart3, Boxes, AlertCircle, 
  Star, MessageSquare, Bell, UserCircle, Menu, X
} from 'lucide-react';
import { VendorDashboardHome } from '@/pages/dashboard/VendorDashboardHome';
import { VendorInventory } from '@/components/vendor/VendorInventory';
import { VendorPayouts } from '@/components/vendor/VendorPayouts';
import { VendorPromotions } from '@/components/vendor/VendorPromotions';
import { VendorNotifications } from '@/components/vendor/VendorNotifications';
import { VendorProfile } from '@/components/vendor/VendorProfile';
import { VendorJobs } from '@/components/vendor/VendorJobs';
import VendorCatalog from '@/components/vendor/VendorCatalog';
import VendorOrders from '@/components/vendor/VendorOrders';
import VendorActiveOrders from '@/components/vendor/VendorActiveOrders';
import VendorOrderHistory from '@/components/vendor/VendorOrderHistory';
import VendorDeliveryScheduling from '@/components/vendor/VendorDeliveryScheduling';
import VendorRoutes from '@/components/vendor/VendorRoutes';
import VendorCustomers from '@/components/vendor/VendorCustomers';
import VendorPricing from '@/components/vendor/VendorPricing';
import VendorEarnings from '@/components/vendor/VendorEarnings';
import VendorAnalytics from '@/components/vendor/VendorAnalytics';
import VendorSuppliers from '@/components/vendor/VendorSuppliers';
import VendorStock from '@/components/vendor/VendorStock';
import VendorReviews from '@/components/vendor/VendorReviews';
import VendorMessages from '@/components/vendor/VendorMessages';
import { VendorDisputes } from '@/components/vendor/VendorDisputes';
import { DashboardTopCard } from '@/components/dashboard/DashboardTopCard';
import { StickyHorizontalScrollbar } from '@/components/dashboard/StickyHorizontalScrollbar';
import { cn } from '@/lib/utils';

export default function VendorDashboard() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [accountNumber, setAccountNumber] = useState<string>('');
  const mainRef = useRef<HTMLDivElement>(null);
  
  const companyName = user?.user_metadata?.company_name || user?.user_metadata?.business_name || user?.user_metadata?.first_name || user?.email?.split('@')[0] || 'Vendor';

  useEffect(() => {
    const fetchAccountNumber = async () => {
      if (user?.id) {
        const { data, error } = await supabase
          .from('user_account_number')
          .select('account_number')
          .eq('user_id', user.id)
          .single();
        
        if (data && !error) {
          setAccountNumber(data.account_number);
        }
      }
    };
    fetchAccountNumber();
  }, [user?.id]);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'inventory', label: 'Inventory Management', icon: Archive },
    { id: 'catalog', label: 'Product Catalog', icon: BookOpen },
    { id: 'orders', label: 'Order Management', icon: ShoppingBag },
    { id: 'active-orders', label: 'Active Orders', icon: ShoppingCart },
    { id: 'order-history', label: 'Order History', icon: History },
    { id: 'delivery', label: 'Delivery Scheduling', icon: Calendar },
    { id: 'routes', label: 'Route Planning', icon: Route },
    { id: 'customers', label: 'Customer Management', icon: Users },
    { id: 'promotions', label: 'Promotions & Discounts', icon: Sparkles },
    { id: 'pricing', label: 'Pricing Management', icon: Tag },
    { id: 'payouts', label: 'Payment & Payouts', icon: CreditCard },
    { id: 'earnings', label: 'Revenue & Earnings', icon: DollarSign },
    { id: 'analytics', label: 'Sales Analytics', icon: BarChart3 },
    { id: 'suppliers', label: 'Supplier Management', icon: Boxes },
    { id: 'stock', label: 'Stock Alerts', icon: AlertCircle },
    { id: 'reviews', label: 'Reviews & Ratings', icon: Star },
    { id: 'disputes', label: 'Disputes', icon: AlertCircle },
    { id: 'messages', label: 'Messages', icon: MessageSquare },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'profile', label: 'Settings', icon: UserCircle },
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return (
          <>
            <DashboardTopCard
              companyName={companyName}
              motivationalText="Grow your business with Haulee"
              showOnlineToggle={false}
              avatarUrl={user?.user_metadata?.avatar_url}
            />
            
            {/* Stats Overview */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6 mt-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Orders</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">12</div>
                  <p className="text-xs text-muted-foreground">+2 from yesterday</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Today's Revenue</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">$892</div>
                  <p className="text-xs text-muted-foreground">+15% from yesterday</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Customers</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">156</div>
                  <p className="text-xs text-muted-foreground">12 new this month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Monthly Growth</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-xl sm:text-2xl font-bold">+18%</div>
                  <p className="text-xs text-muted-foreground">vs last month</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6 mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Order Status</CardTitle>
                  <CardDescription>Current order breakdown</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                        <span className="text-sm">Preparing</span>
                      </div>
                      <span className="text-sm font-medium">5 orders</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                        <span className="text-sm">Ready for Pickup</span>
                      </div>
                      <span className="text-sm font-medium">3 orders</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                        <span className="text-sm">In Transit</span>
                      </div>
                      <span className="text-sm font-medium">4 orders</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Orders</CardTitle>
                  <CardDescription>Latest order activity</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Order #ORD-102</p>
                        <p className="text-xs text-muted-foreground">4 items • $45.50</p>
                      </div>
                      <Badge variant="default">Delivered</Badge>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Order #ORD-103</p>
                        <p className="text-xs text-muted-foreground">2 items • $28.99</p>
                      </div>
                      <Badge variant="secondary">Preparing</Badge>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">Order #ORD-104</p>
                        <p className="text-xs text-muted-foreground">6 items • $67.80</p>
                      </div>
                      <Badge variant="outline">Ready</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </>
        );
      case 'inventory':
        return <VendorInventory />;
      case 'catalog':
        return <VendorCatalog />;
      case 'orders':
        return <VendorOrders />;
      case 'active-orders':
        return <VendorActiveOrders />;
      case 'order-history':
        return <VendorOrderHistory />;
      case 'delivery':
        return <VendorDeliveryScheduling />;
      case 'routes':
        return <VendorRoutes />;
      case 'customers':
        return <VendorCustomers />;
      case 'promotions':
        return <VendorPromotions />;
      case 'pricing':
        return <VendorPricing />;
      case 'payouts':
        return <VendorPayouts />;
      case 'earnings':
        return <VendorEarnings />;
      case 'analytics':
        return <VendorAnalytics />;
      case 'suppliers':
        return <VendorSuppliers />;
      case 'stock':
        return <VendorStock />;
      case 'reviews':
        return <VendorReviews />;
      case 'disputes':
        return <VendorDisputes />;
      case 'messages':
        return <VendorMessages />;
      case 'notifications':
        return <VendorNotifications />;
      case 'profile':
        return <VendorProfile />;
      case 'jobs':
        return <VendorJobs />;
      default:
        return null;
    }
  };

  return (
    <div className="h-screen bg-background flex overflow-hidden">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed lg:sticky top-0 left-0 z-50 h-screen w-64 border-r bg-card transition-transform duration-300 lg:translate-x-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="flex flex-col h-full">
          {/* Sidebar Header */}
          <div className="h-[72px] px-6 border-b flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Store className="h-6 w-6 text-primary" />
              <span className="text-xl font-bold">Haulee</span>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          {/* Menu Items */}
          <ScrollArea className="flex-1 px-3 py-4">
            <div className="space-y-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <Button
                    key={item.id}
                    variant={isActive ? "default" : "ghost"}
                    className={cn(
                      "w-full justify-start gap-3",
                      isActive && "bg-primary text-primary-foreground"
                    )}
                    onClick={() => {
                      setActiveSection(item.id);
                      setSidebarOpen(false);
                    }}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label}</span>
                  </Button>
                );
              })}
            </div>
          </ScrollArea>

          {/* Sidebar Footer */}
          <div className="p-4 border-t">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                <span className="text-sm font-medium text-primary">
                  {companyName.charAt(0).toUpperCase()}
                </span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{companyName}</p>
                <p className="text-xs text-muted-foreground">
                  {accountNumber ? `#${accountNumber}` : 'Loading...'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Header */}
        <header className="sticky top-0 z-30 bg-card border-b h-[72px]">
          <div className="flex items-center gap-4 px-4 sm:px-6 lg:px-8 h-full">
            <Button
              variant="ghost"
              size="icon"
              className="lg:hidden"
              onClick={() => setSidebarOpen(true)}
            >
              <Menu className="h-5 w-5" />
            </Button>
            <div className="flex-1 min-w-0">
              <h1 className="text-xl sm:text-2xl font-bold text-foreground truncate">
                {menuItems.find(item => item.id === activeSection)?.label || 'Vendor Dashboard'}
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground hidden sm:block">
                Manage your store and deliveries
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate(-1)}
                className="hidden sm:flex items-center gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={signOut}
              >
                Sign Out
              </Button>
            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main ref={mainRef} className="flex-1 overflow-auto scrollbar-visible">
          <div className="max-w-7xl mx-auto py-4 sm:py-8">
            <div className="space-y-4 md:space-y-6">
              {renderContent()}
            </div>
          </div>
        </main>
        <StickyHorizontalScrollbar targetRef={mainRef} />
      </div>
    </div>
  );
}