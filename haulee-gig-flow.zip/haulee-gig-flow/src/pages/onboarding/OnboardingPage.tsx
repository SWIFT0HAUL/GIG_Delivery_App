import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StepProgress } from '@/components/onboarding/StepProgress';
import { ReviewStep } from '@/components/onboarding/ReviewStep';
import { UnifiedKYCForm } from '@/components/onboarding/UnifiedKYCForm';
import { OnboardingProvider, useOnboarding, OnboardingRole } from '@/components/onboarding/OnboardingProvider';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, ArrowRight, LogOut } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

// Simplified onboarding schema - Single KYC step + Review
const ONBOARDING_SCHEMA = {
  admin: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  driver: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  carrier: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  broker: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  shipper: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  vendor: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  vendor_merchant: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  },
  merchant: {
    steps: [
      {
        step: 1,
        title: "Initial Application - Basic KYC",
        type: "unified_kyc",
        fields: [],
        description: "Complete your identity verification and basic information"
      },
      {
        step: 2,
        title: "Review & Confirm",
        type: "review",
        fields: "all_previous",
        description: "Review all information before submitting"
      }
    ]
  }
};

function OnboardingContent() {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { 
    currentStep, 
    totalSteps, 
    role, 
    formData, 
    setCurrentStep, 
    updateFormData, 
    submitOnboarding,
    setRole
  } = useOnboarding();

  const [stepData, setStepData] = useState<any>({});
  const [errors, setErrors] = useState<any>({});
  const [autoFillData, setAutoFillData] = useState<any>({});

  // Set role from URL params or user metadata and pre-fill data
  useEffect(() => {
    const fetchAccountNumber = async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('user_account_number')
        .select('account_number')
        .eq('user_id', user.id)
        .single();
      
      if (error) {
        console.error('Error fetching account number:', error);
        return null;
      }
      
      return data?.account_number;
    };

    const urlParams = new URLSearchParams(window.location.search);
    const roleParam = urlParams.get('role') as OnboardingRole;
    
    if (roleParam && ['driver', 'carrier', 'broker', 'shipper', 'vendor_merchant', 'merchant', 'admin'].includes(roleParam)) {
      let schemaRole = roleParam;
      if (roleParam === 'merchant') {
        schemaRole = 'vendor_merchant'; // Map merchant to vendor_merchant schema
      }
      setRole(schemaRole as OnboardingRole);
      
      // Store auto-fill data from user metadata
      const autoFill: any = {};
      if (user?.email) {
        autoFill.email = user.email;
        autoFill.email_address = user.email;
      }
      if (user?.user_metadata?.company_name) {
        autoFill.legal_company_name = user.user_metadata.company_name;
        autoFill.company_name = user.user_metadata.company_name;
      }
      
      // Fetch and set account number for admin role
      if (schemaRole === 'admin') {
        fetchAccountNumber().then(accountNumber => {
          if (accountNumber) {
            autoFill.employee_id = accountNumber;
            setAutoFillData({ ...autoFill });
            setStepData(prev => ({ ...prev, ...autoFill }));
          }
        });
      } else {
        setAutoFillData(autoFill);
        setStepData(prev => ({ ...prev, ...autoFill }));
      }
    } else if (user?.user_metadata?.role) {
      const userRole = user.user_metadata.role;
      let schemaRole = userRole;
      if (userRole === 'merchant') {
        schemaRole = 'vendor_merchant';
      }
      setRole(schemaRole as OnboardingRole);
      
      // Store auto-fill data from user metadata
      const autoFill: any = {};
      if (user?.email) {
        autoFill.email = user.email;
        autoFill.email_address = user.email;
      }
      if (user?.user_metadata?.company_name) {
        autoFill.legal_company_name = user.user_metadata.company_name;
        autoFill.company_name = user.user_metadata.company_name;
      }
      
      // Fetch and set account number for admin role
      if (schemaRole === 'admin') {
        fetchAccountNumber().then(accountNumber => {
          if (accountNumber) {
            autoFill.employee_id = accountNumber;
            setAutoFillData({ ...autoFill });
            setStepData(prev => ({ ...prev, ...autoFill }));
          }
        });
      } else {
        setAutoFillData(autoFill);
        setStepData(prev => ({ ...prev, ...autoFill }));
      }
    } else {
      navigate('/auth');
    }
  }, [user, setRole, navigate]);

  if (!role) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    );
  }

  const schema = ONBOARDING_SCHEMA[role];
  
  if (!schema || !schema.steps) {
    console.error('Invalid role or schema not found:', role);
    navigate('/auth');
    return <div>Redirecting...</div>;
  }

  const currentStepData = schema.steps[currentStep - 1];
  const stepTitles = schema.steps.map(step => step.title);

  // Safety check: if currentStepData is undefined, show loading
  // Don't reset step during render to avoid infinite loops
  if (!currentStepData && currentStep <= totalSteps) {
    console.warn('Step data not ready yet, currentStep:', currentStep);
    return <div>Loading step...</div>;
  }

  const validateStep = () => {
    const errors: any = {};
    
    // No validation needed for unified KYC (auto-saves) or review step
    if (currentStepData.type === 'review' || currentStepData.type === 'unified_kyc') {
      return {};
    }

    return errors;
  };
  const handleNext = () => {
    const stepErrors = validateStep();
    setErrors(stepErrors);

    if (Object.keys(stepErrors).length === 0) {
      updateFormData(stepData);
      if (currentStep < totalSteps) {
        // Clear local step data before moving to next step
        setStepData({});
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setStepData({});
      setCurrentStep(currentStep - 1);
    } else {
      // On step 1, go back to auth/role selection
      navigate('/auth');
    }
  };

  const handleEditStep = (step: number) => {
    setStepData({});
    setCurrentStep(step);
  };

  const handleSubmit = async () => {
    const success = await submitOnboarding();
    if (success) {
      // Redirect to status and tasks page after successful submission
      navigate('/status-and-tasks', { replace: true });
    }
  };

  const handleFieldChange = (fieldLabel: string, value: any) => {
    const fieldKey = fieldLabel.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
    setStepData({ ...stepData, [fieldKey]: value });
    
    // Clear error for this field
    if (errors[fieldKey]) {
      setErrors({ ...errors, [fieldKey]: undefined });
    }
  };

  // Redirect to status page after submission
  if (currentStep > totalSteps) {
    navigate('/status-and-tasks', { replace: true });
    return null;
  }

  return (
    <div className="min-h-screen bg-background py-4 sm:py-8 px-2 sm:px-4">
      <div className="container mx-auto max-w-4xl">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-4 sm:mb-6 gap-3">
          <div className="flex-1">
            <StepProgress 
              currentStep={currentStep} 
              totalSteps={totalSteps} 
              stepTitles={stepTitles}
            />
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={signOut}
            className="flex items-center gap-2 self-start sm:self-auto min-h-[36px] text-xs sm:text-sm"
          >
            <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
            Sign Out
          </Button>
        </div>

        <Card className="border shadow-sm">
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-lg sm:text-xl lg:text-2xl">{currentStepData.title}</CardTitle>
            {currentStepData.description && (
              <p className="text-xs sm:text-sm text-muted-foreground mt-2">{currentStepData.description}</p>
            )}
          </CardHeader>
          <CardContent className="p-4 sm:p-6">
            {currentStepData.type === 'review' ? (
              <ReviewStep
                onEditStep={handleEditStep}
                stepTitles={stepTitles}
                onSubmit={handleSubmit}
                onboardingSchema={ONBOARDING_SCHEMA}
              />
            ) : currentStepData.type === 'unified_kyc' ? (
              <div className="space-y-4 sm:space-y-6">
                <UnifiedKYCForm />
                <div className="flex flex-col sm:flex-row sm:justify-between pt-4 sm:pt-6 gap-3 border-t">
                  <Button
                    variant="outline"
                    onClick={handlePrevious}
                    className="w-full sm:w-auto order-2 sm:order-1 min-h-[44px] text-sm"
                  >
                    <ArrowLeft className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                    Back to Role Selection
                  </Button>
                  
                  <Button 
                    onClick={handleNext}
                    className="w-full sm:w-auto order-1 sm:order-2 min-h-[44px] text-sm"
                  >
                    Continue to Review
                    <ArrowRight className="w-3 h-3 sm:w-4 sm:h-4 ml-2" />
                  </Button>
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function OnboardingPage() {
  return (
    <OnboardingProvider>
      <OnboardingContent />
    </OnboardingProvider>
  );
}