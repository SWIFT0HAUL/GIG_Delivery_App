import { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Loader2, AlertCircle, ArrowLeft, CheckCircle2 } from 'lucide-react';

export default function TaskWorkspace() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const taskName = searchParams.get('taskName');
  const stepName = searchParams.get('step');
  const originalPath = searchParams.get('path');

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }

    // Prevent navigation away during task completion
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = '';
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [user, navigate]);

  const handleExitToTasks = () => {
    navigate('/status-and-tasks');
  };

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Locked header - no dashboard navigation */}
      <div className="border-b bg-card sticky top-0 z-50 shadow-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleExitToTasks}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back to Tasks
              </Button>
              <div className="h-6 w-px bg-border" />
              <div>
                <h1 className="text-lg font-semibold">Task Workspace</h1>
                {taskName && (
                  <p className="text-sm text-muted-foreground">{taskName}</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Isolated task content */}
      <div className="container mx-auto px-4 py-8">
        <Card className="max-w-4xl mx-auto">
          <div className="p-6 space-y-6">
            {/* Header */}
            <div className="flex items-start gap-4 pb-4 border-b">
              <div className="p-3 bg-primary/10 rounded-lg">
                <AlertCircle className="h-6 w-6 text-primary" />
              </div>
              <div className="flex-1">
                <h2 className="text-xl font-semibold mb-2">Dashboard Access Restricted</h2>
                <p className="text-muted-foreground">
                  You're currently working on required tasks. Full dashboard access will be granted once all tasks are completed and approved.
                </p>
              </div>
            </div>

            {/* Current Step Info */}
            {stepName && (
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-primary" />
                  <h3 className="font-semibold text-lg">Current Step</h3>
                </div>
                <Card className="bg-muted/50 border-primary/20">
                  <div className="p-4 space-y-2">
                    <p className="font-medium">{stepName}</p>
                    {originalPath && (
                      <p className="text-sm text-muted-foreground font-mono">
                        Requires: {originalPath}
                      </p>
                    )}
                  </div>
                </Card>
              </div>
            )}

            {/* Instructions */}
            <div className="space-y-4 pt-4 border-t">
              <h3 className="font-semibold">What You Need to Do:</h3>
              <ol className="space-y-3 text-sm text-muted-foreground list-decimal list-inside">
                <li>Complete the required task step described above</li>
                <li>Return to the Tasks page to mark the task as complete</li>
                <li>Wait for admin approval</li>
                <li>Once all tasks are approved, full dashboard access will be granted</li>
              </ol>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4 border-t">
              <Button
                onClick={handleExitToTasks}
                variant="default"
                className="flex-1"
              >
                Return to Tasks
              </Button>
            </div>

            {/* Important Notice */}
            <Card className="bg-amber-50 dark:bg-amber-950/20 border-amber-200">
              <div className="p-4">
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  <strong>Important:</strong> Dashboard features are locked during onboarding. This ensures you complete all required steps before accessing the platform.
                </p>
              </div>
            </Card>
          </div>
        </Card>
      </div>
    </div>
  );
}
