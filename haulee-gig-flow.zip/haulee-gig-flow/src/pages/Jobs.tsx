import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useUserRole } from '@/hooks/useUserRole';
import { useJobPermissions } from '@/hooks/useJobPermissions';
import { usePermissions } from '@/hooks/usePermissions';
import { 
  Search, Filter, Calendar as CalendarIcon, Download, Plus, 
  BarChart3, MessageSquare, Users, ClipboardList, RefreshCw,
  AlertCircle, CheckCircle, Lock, Package, PlayCircle, XCircle,
  Clock, AlertTriangle
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import JobOverview from '@/components/job/JobOverview';
import JobList from '@/components/job/JobList';
import JobForm from '@/components/job/JobForm';
import AssignmentScheduler from '@/components/job/AssignmentScheduler';
import JobMessaging from '@/components/job/JobMessaging';
import JobMetrics from '@/components/job/JobMetrics';
import RouteMonitor from '@/components/job/RouteMonitor';

const Jobs = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  
  // Use centralized hooks - SINGLE SOURCE OF TRUTH
  const { profile, isAdmin, isSuperAdmin } = useUserRole();
  const { permissions: jobPermissions, loading: permissionsLoading, isBroker } = useJobPermissions();
  const { hasPermission, hasAnyPermission } = usePermissions();
  
  const [dateRange, setDateRange] = useState<Date | undefined>(undefined);
  const [dateRangeOpen, setDateRangeOpen] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [jobTypeFilter, setJobTypeFilter] = useState<string>('all');
  const [assignedUserFilter, setAssignedUserFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeTab, setActiveTab] = useState<string>('job-list');
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);

  // Set default tab based on role
  useEffect(() => {
    if (!profile) return;
    
    console.log('🔍 Tab visibility debug:', {
      isAdmin: isAdmin(),
      isSuperAdmin: isSuperAdmin(),
      isBroker: isBroker(),
      roleName: profile?.role_name,
      shouldShowRouteTab: isAdmin() || isBroker()
    });
    
    if (isAdmin() || isSuperAdmin()) {
      setActiveTab('overview');
    } else {
      setActiveTab('job-list');
    }
  }, [profile, isAdmin, isSuperAdmin, isBroker]);

  const exportData = async () => {
    setIsRefreshing(true);
    try {
      // Mock export functionality - in real app, this would generate and download a file
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: "Export Successful",
        description: "Job data has been exported successfully.",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export job data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const clearFilters = () => {
    setSearchQuery('');
    setStatusFilter('all');
    setJobTypeFilter('all');
    setAssignedUserFilter('all');
    setDateRange(undefined);
    toast({
      title: "Filters Cleared",
      description: "All filters have been reset.",
    });
  };

  // Show loading state
  if (permissionsLoading || !profile) {
    return (
      <div className="container mx-auto px-6 py-8 space-y-8">
        <div className="space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
        </div>
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {[...Array(5)].map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          </CardContent>
        </Card>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  // Get userRole for display purposes
  const userRole = profile.role_name || 'driver';

  return (
      <div className="w-full flex justify-center pr-6 pl-10 py-8">
        <div className="w-full max-w-7xl space-y-8">
      {/* Header */}
      <div className="space-y-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-foreground">Job Management</h1>
              <Badge variant={userRole === 'super_admin' ? 'default' : 'secondary'} className="capitalize">
                {userRole === 'super_admin' ? 'Super Admin' : userRole}
              </Badge>
            </div>
            <p className="text-muted-foreground">
              Comprehensive job management and tracking system for all platform operations
            </p>
            {userRole === 'super_admin' && (
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  You have super admin access to all job management features.
                </AlertDescription>
              </Alert>
            )}
          </div>
          <div className="flex items-center space-x-2">
            <Button 
              variant="outline" 
              onClick={clearFilters}
              disabled={isRefreshing}
            >
              <RefreshCw className={cn("h-4 w-4 mr-2", isRefreshing && "animate-spin")} />
              Clear Filters
            </Button>
            <Button onClick={exportData} disabled={isRefreshing}>
              <Download className="h-4 w-4 mr-2" />
              {isRefreshing ? 'Exporting...' : 'Export'}
            </Button>
          </div>
        </div>

        {/* Global Filters */}
        <Card className="border-2 border-dashed border-muted hover:border-primary/50 transition-colors">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Filter className="h-5 w-5" />
                Global Filters & Search
              </CardTitle>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>Filtering jobs</span>
                {(searchQuery || statusFilter || jobTypeFilter || assignedUserFilter || dateRange) && (
                  <Badge variant="secondary" className="text-xs">
                    Filters Active
                  </Badge>
                )}
              </div>
            </div>
            <CardDescription>
              Use these filters to narrow down the job list and find specific jobs quickly
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {/* Search */}
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <Search className="h-3 w-3" />
                  Search Jobs
                </label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                  <Input
                    placeholder="Job ID, title, client..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Status Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <AlertCircle className="h-3 w-3" />
                  Status
                </label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-yellow-500" />
                        Pending
                      </div>
                    </SelectItem>
                    <SelectItem value="planned">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-purple-500" />
                        Planned
                      </div>
                    </SelectItem>
                    <SelectItem value="scheduled">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-blue-500" />
                        Scheduled
                      </div>
                    </SelectItem>
                    <SelectItem value="posted">
                      <div className="flex items-center gap-2">
                        <PlayCircle className="h-4 w-4 text-cyan-500" />
                        Posted
                      </div>
                    </SelectItem>
                    <SelectItem value="assigned">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-indigo-500" />
                        Assigned
                      </div>
                    </SelectItem>
                    <SelectItem value="in_progress">
                      <div className="flex items-center gap-2">
                        <PlayCircle className="h-4 w-4 text-blue-500" />
                        In Progress
                      </div>
                    </SelectItem>
                    <SelectItem value="picked_up">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-teal-500" />
                        Picked Up
                      </div>
                    </SelectItem>
                    <SelectItem value="delayed">
                      <div className="flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4 text-orange-500" />
                        Delayed
                      </div>
                    </SelectItem>
                    <SelectItem value="delivered">
                      <div className="flex items-center gap-2">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        Delivered
                      </div>
                    </SelectItem>
                    <SelectItem value="cancelled">
                      <div className="flex items-center gap-2">
                        <XCircle className="h-4 w-4 text-gray-500" />
                        Cancelled
                      </div>
                    </SelectItem>
                    <SelectItem value="archived">
                      <div className="flex items-center gap-2">
                        <XCircle className="h-4 w-4 text-slate-500" />
                        Archived
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Job Type Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <Package className="h-3 w-3" />
                  Job Type
                </label>
                <Select value={jobTypeFilter} onValueChange={setJobTypeFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="delivery">Delivery</SelectItem>
                    <SelectItem value="pickup">Pickup</SelectItem>
                    <SelectItem value="transport">Transport</SelectItem>
                    <SelectItem value="logistics">Logistics</SelectItem>
                    <SelectItem value="warehousing">Warehousing</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Assigned User Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  Assigned To
                </label>
                <Select value={assignedUserFilter} onValueChange={setAssignedUserFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="Any user" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Users</SelectItem>
                    <SelectItem value="mike-driver">Mike Driver</SelectItem>
                    <SelectItem value="lisa-carrier">Lisa Carrier</SelectItem>
                    <SelectItem value="david-vendor">David Vendor</SelectItem>
                    <SelectItem value="steve-driver">Steve Driver</SelectItem>
                    <SelectItem value="carol-carrier">Carol Carrier</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Date Range Filter */}
              <div className="space-y-2">
                <label className="text-sm font-medium flex items-center gap-1">
                  <CalendarIcon className="h-3 w-3" />
                  Date Range
                </label>
                <Popover open={dateRangeOpen} onOpenChange={setDateRangeOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateRange && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateRange ? format(dateRange, "MMM dd, yyyy") : "Any date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={dateRange}
                      onSelect={(date) => {
                        setDateRange(date);
                        setDateRangeOpen(false);
                      }}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Navigation Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <div className="flex flex-col space-y-4">
          {/* Dynamic Tab List based on permissions */}
          <TabsList className={cn(
            "grid w-full",
            isAdmin() || isBroker() ? "grid-cols-7" : "grid-cols-3"
          )}>
            {/* Overview - Admin/Broker only */}
            {(isAdmin() || isBroker()) && (
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">Overview</span>
              </TabsTrigger>
            )}
            
            {/* Job List - Everyone */}
            <TabsTrigger value="job-list" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              <span className="hidden sm:inline">Job List</span>
            </TabsTrigger>

            {/* Route Monitor - Admin/Broker only */}
            {(isAdmin() || isBroker()) && (
              <TabsTrigger value="route-monitor" className="flex items-center gap-2">
                <Package className="h-4 w-4" />
                <span className="hidden sm:inline">Route Monitor</span>
              </TabsTrigger>
            )}
            
            {/* Create Job - Admin only */}
            {isAdmin() && (
              <TabsTrigger value="create-job" className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">Create Job</span>
              </TabsTrigger>
            )}
            
            {/* Assignment - Admin/Broker only */}
            {(isAdmin() || isBroker()) && (
              <TabsTrigger value="assignment" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">Assignment</span>
              </TabsTrigger>
            )}
            
            {/* Messages - Everyone */}
            <TabsTrigger value="messages" className="flex items-center gap-2">
              <MessageSquare className="h-4 w-4" />
              <span className="hidden sm:inline">Messages</span>
            </TabsTrigger>
            
            {/* KPIs - Admin/Broker only */}
            {(isAdmin() || isBroker()) && (
              <TabsTrigger value="kpis" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                <span className="hidden sm:inline">KPIs</span>
              </TabsTrigger>
            )}
          </TabsList>

          {/* Permission indicators */}
          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <CheckCircle className="h-3 w-3 text-green-500" />
              <span>Full access to Job List & Messages</span>
            </div>
            {(isAdmin() || isBroker()) && (
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-blue-500" />
                <span>Management access to Overview, Assignment & KPIs</span>
              </div>
            )}
            {isAdmin() && (
              <div className="flex items-center gap-1">
                <CheckCircle className="h-3 w-3 text-purple-500" />
                <span>Admin access to Create Job</span>
              </div>
            )}
          </div>
        </div>

        {/* Tab Contents */}
        {/* Overview Tab - Admin/Broker Only */}
        {(isAdmin() || isBroker()) && (
          <TabsContent value="overview" className="space-y-6">
            <JobOverview 
              filters={{
                search: searchQuery,
                status: statusFilter,
                jobType: jobTypeFilter,
                assignedUser: assignedUserFilter,
                dateRange: dateRange
              }}
            />
          </TabsContent>
        )}

        {/* Job List Tab - Everyone */}
        <TabsContent value="job-list" className="space-y-6">
          <JobList 
            userRole={userRole}
            filters={{
              search: searchQuery,
              status: statusFilter,
              jobType: jobTypeFilter,
              assignedUser: assignedUserFilter,
              dateRange: dateRange
            }}
          />
        </TabsContent>

        {/* Create Job Tab - Admin Only */}
        {isAdmin() && (
          <TabsContent value="create-job" className="space-y-6">
            <JobForm />
          </TabsContent>
        )}

        {/* Assignment Tab - Admin/Broker Only */}
        {(isAdmin() || isBroker()) && (
          <TabsContent value="assignment" className="space-y-6">
            <AssignmentScheduler />
          </TabsContent>
        )}

        {/* Messages Tab - Everyone */}
        <TabsContent value="messages" className="space-y-6">
          <JobMessaging userRole={userRole} />
        </TabsContent>

        {/* KPIs Tab - Admin/Broker Only */}
        {(isAdmin() || isBroker()) && (
          <TabsContent value="kpis" className="space-y-6">
            <JobMetrics />
          </TabsContent>
        )}

        {/* Route Monitor Tab - Admin/Broker Only */}
        {(isAdmin() || isBroker()) && (
          <TabsContent value="route-monitor" className="space-y-6">
            <RouteMonitor 
              filters={{
                search: searchQuery,
                status: statusFilter,
                assignedUser: assignedUserFilter
              }}
            />
          </TabsContent>
        )}

        {/* Access Denied Fallback for protected tabs */}
        {!isAdmin() && !isBroker() && ['overview', 'create-job', 'assignment', 'kpis', 'route-monitor'].includes(activeTab) && (
          <TabsContent value={activeTab} className="space-y-6">
            <Card>
              <CardContent className="p-8 text-center">
                <Lock className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg font-semibold mb-2">Access Restricted</h3>
                <p className="text-muted-foreground mb-4">
                  You don't have permission to access this feature. Contact your administrator for access.
                </p>
                <Badge variant="outline" className="capitalize">
                  Current Role: {userRole}
                </Badge>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>
      </div>
    </div>
  );
};

export default Jobs;