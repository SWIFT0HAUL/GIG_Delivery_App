import React, { useState, useEffect } from 'react';
import { marked } from 'marked';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DocumentExporter } from '@/components/DocumentExporter';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function DocumentationViewer() {
  const [markdownContent, setMarkdownContent] = useState('');
  const [htmlContent, setHtmlContent] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    // Fetch the documentation file
    fetch('/PROJECT_DOCUMENTATION.md')
      .then(response => response.text())
      .then(async (text) => {
        setMarkdownContent(text);
        // Convert to HTML for display
        marked.setOptions({
          breaks: true,
          gfm: true,
        });
        const html = await marked.parse(text);
        setHtmlContent(html);
      })
      .catch(error => {
        console.error('Error loading documentation:', error);
      });
  }, []);

  return (
    <div className="min-h-screen bg-background p-4 md:p-8">
      <div className="max-w-5xl mx-auto">
        <Card>
          <CardHeader className="space-y-4">
            <div className="flex items-center justify-between">
              <Button
                variant="ghost"
                onClick={() => navigate(-1)}
                className="gap-2"
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
              <DocumentExporter
                markdownContent={markdownContent}
                fileName="Haulee_Platform_Documentation"
              />
            </div>
            <CardTitle className="text-3xl">Platform Documentation</CardTitle>
          </CardHeader>
          
          <CardContent>
            <div 
              className="prose prose-slate max-w-none dark:prose-invert
                prose-headings:text-primary
                prose-h1:border-b-2 prose-h1:border-accent prose-h1:pb-2
                prose-h2:border-b prose-h2:border-border prose-h2:pb-2
                prose-a:text-primary prose-a:no-underline hover:prose-a:underline
                prose-code:bg-muted prose-code:px-1 prose-code:py-0.5 prose-code:rounded
                prose-pre:bg-muted
                prose-blockquote:border-l-accent
                prose-strong:text-foreground
                prose-table:border-collapse
                prose-th:bg-muted prose-th:border prose-th:border-border
                prose-td:border prose-td:border-border"
              dangerouslySetInnerHTML={{ __html: htmlContent }}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
