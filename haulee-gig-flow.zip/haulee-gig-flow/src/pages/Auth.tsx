import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Truck, Package, Shield, Users, Building, ArrowLeft, Eye, EyeOff } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ForcePasswordChangeModal } from "@/components/ForcePasswordChangeModal";
import { loginWithDemoAccount } from "@/lib/demo";
import { Separator } from "@/components/ui/separator";


interface Role {
  id: string;
  name: string;
  description: string | null;
}

const Auth = () => {
  const navigate = useNavigate();
  const { signUp, signIn, user, loading, redirectUser } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    firstName: "",
    lastName: "",
    phone: "",
    role: "",
    companyName: ""
  });

  const urlParams = new URLSearchParams(window.location.search);
  const tabFromUrl = urlParams.get('tab');
  const [defaultTab] = useState(tabFromUrl || "signin");
  const [showVerificationSuccess, setShowVerificationSuccess] = useState<boolean>(false);
  const [availableRoles, setAvailableRoles] = useState<Role[]>([]);
  const [rolesLoading, setRolesLoading] = useState(true);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState("");
  const [resetLoading, setResetLoading] = useState(false);
  const [loadingPolicy, setLoadingPolicy] = useState(false);
  const [agreeToPolicies, setAgreeToPolicies] = useState(false);
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(false);
  const [showPasswordResetDialog, setShowPasswordResetDialog] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [resetPasswordLoading, setResetPasswordLoading] = useState(false);
  const [showSignInPassword, setShowSignInPassword] = useState(false);
  const [showSignUpPassword, setShowSignUpPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmNewPassword, setShowConfirmNewPassword] = useState(false);
  const [demoLoading, setDemoLoading] = useState(false);

  const getRoleIcon = (roleName: string) => {
    const iconMap: { [key: string]: JSX.Element } = {
      vendor_merchant: <Building className="h-5 w-5" />,
      carrier: <Truck className="h-5 w-5" />,
      shipper: <Package className="h-5 w-5" />,
      driver: <Users className="h-5 w-5" />,
      broker: <Shield className="h-5 w-5" />,
    };
    return iconMap[roleName] || <Users className="h-5 w-5" />;
  };

  const formatRoleName = (name: string) => {
    const nameMap: { [key: string]: string } = {
      vendor_merchant: "Vendor",
      carrier: "Carrier",
      shipper: "Shipper",
      driver: "Driver",
      broker: "Broker",
    };
    return nameMap[name] || name.charAt(0).toUpperCase() + name.slice(1);
  };

  const getRoleDescription = (roleName: string) => {
    const descriptions: { [key: string]: string } = {
      vendor_merchant: "Vendor/Merchant to post jobs",
      carrier: "Transport goods with your fleet",
      shipper: "Send packages and manage logistics",
      driver: "Drive and deliver goods",
      broker: "Connect shippers with carriers",
    };
    return descriptions[roleName] || "Access the platform";
  };

  // Fetch available roles for signup (excluding admin/super_admin roles)
  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const { data, error } = await supabase
          .from('roles')
          .select('id, role_key, description')
          .not('role_key', 'in', '(admin,super_admin)')
          .eq('is_active', true)
          .order('role_key');

        if (error) throw error;
        
        const rolesData: Role[] = (data || []).map((role: any) => ({
          id: role.id,
          name: role.role_key,
          description: getRoleDescription(role.role_key)
        }));
        
        setAvailableRoles(rolesData);
      } catch (error) {
        console.error('Error fetching roles:', error);
        toast({
          title: "Error",
          description: "Failed to load available roles.",
          variant: "destructive",
        });
      } finally {
        setRolesLoading(false);
      }
    };

    fetchRoles();
  }, []);

  // Redirect if user is authenticated - AuthContext handles all redirects
  useEffect(() => {
    if (user && !loading) {
      // AuthContext's onAuthStateChange will handle the redirection
    }
  }, [user, loading]);

  // Detect force password change requirement
  useEffect(() => {
    const checkPasswordChangeRequired = () => {
      // Check if user has force_password_change in metadata
      const forcePasswordChange = user?.user_metadata?.force_password_change;
      if (forcePasswordChange === true || forcePasswordChange === 'true') {
        setShowPasswordChangeModal(true);
      } else {
        setShowPasswordChangeModal(false);
      }
    };

    checkPasswordChangeRequired();
  }, [user]);

  // Show success message for email verification
  useEffect(() => {
    if (showVerificationSuccess && !loading) {
      toast({
        title: "Email verified!",
        description: "Redirecting to your dashboard...",
      });
      setShowVerificationSuccess(false);
      window.history.replaceState({}, document.title, window.location.pathname);
      // AuthContext handles the actual redirect
    }
  }, [showVerificationSuccess, loading]);

  // Detect password reset flow from email link
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const isReset = urlParams.get('reset') === 'true';
    
    if (isReset) {
      // User clicked reset link from email, show password reset dialog
      setShowPasswordResetDialog(true);
    }
  }, []);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!formData.email || !formData.password) {
      toast({
        title: "Missing Information",
        description: "Please enter both email and password.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    try {
      const result = await signIn(formData.email, formData.password);
      
      // Check for email confirmation error specifically
      if (result?.error) {
        if (result.error.message === "Email not confirmed") {
          toast({
            title: "Email Not Confirmed",
            description: "Please check your email and click the confirmation link before signing in.",
            variant: "destructive",
          });
        } else if (result.error.message === "Invalid login credentials") {
          toast({
            title: "Invalid Credentials",
            description: "The email or password you entered is incorrect.",
            variant: "destructive",
          });
        }
      }
      // AuthContext handles all successful redirection via onAuthStateChange
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetLoading(true);

    if (!resetEmail) {
      toast({
        title: "Missing Email",
        description: "Please enter your email address.",
        variant: "destructive",
      });
      setResetLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(resetEmail, {
        redirectTo: `${window.location.origin}/auth?reset=true`,
      });

      if (error) throw error;

      toast({
        title: "Reset Email Sent",
        description: "Check your email for a password reset link.",
      });

      setShowForgotPassword(false);
      setResetEmail("");
    } catch (error: any) {
      console.error('Password reset error:', error);
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to send reset email. Please try again.",
        variant: "destructive",
      });
    } finally {
      setResetLoading(false);
    }
  };

  const handlePasswordReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetPasswordLoading(true);

    if (!newPassword || !confirmNewPassword) {
      toast({
        title: "Missing Information",
        description: "Please enter both password fields.",
        variant: "destructive",
      });
      setResetPasswordLoading(false);
      return;
    }

    if (newPassword !== confirmNewPassword) {
      toast({
        title: "Password Mismatch",
        description: "Passwords do not match.",
        variant: "destructive",
      });
      setResetPasswordLoading(false);
      return;
    }

    if (newPassword.length < 6) {
      toast({
        title: "Password Too Short",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      });
      setResetPasswordLoading(false);
      return;
    }

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });

      if (error) throw error;

      toast({
        title: "Password Updated",
        description: "Your password has been successfully reset. Please sign in with your new password.",
      });

      // Close dialog and clean up
      setShowPasswordResetDialog(false);
      setNewPassword("");
      setConfirmNewPassword("");
      
      // Remove reset parameter from URL
      window.history.replaceState({}, document.title, window.location.pathname);
    } catch (error: any) {
      console.error('Password update error:', error);
      toast({
        title: "Reset Failed",
        description: error.message || "Failed to reset password. Please try again.",
        variant: "destructive",
      });
    } finally {
      setResetPasswordLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    if (!formData.email || !formData.password || !formData.confirmPassword || 
        !formData.firstName || !formData.lastName || !formData.phone || !formData.role) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    if (formData.password !== formData.confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "Passwords do not match. Please try again.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    if (formData.password.length < 6) {
      toast({
        title: "Password Too Short",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    try {

      const { error } = await signUp({
        email: formData.email,
        password: formData.password,
        full_name: `${formData.firstName} ${formData.lastName}`,
        phone: formData.phone,
        role: formData.role,
        company_name: formData.companyName,
        first_name: formData.firstName,
        last_name: formData.lastName
      });

      if (!error) {
        // Reset form on success
        setFormData({
          email: "",
          password: "",
          confirmPassword: "",
          firstName: "",
          lastName: "",
          phone: "",
          role: "",
          companyName: ""
        });
        
        // Show confirmation message and redirect with query flag
        toast({
          title: "Account created!",
          description: "Please check your email to confirm your account.",
        });
        
        // Redirect to auth page with confirmed flag to start polling
        navigate('/auth?confirmed=1');
      } else {
        toast({
          title: "Sign Up Failed",
          description: error.message,
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Sign up error:', error);
      toast({
        title: "Error",
        description: "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setDemoLoading(true);
    try {
      await loginWithDemoAccount('driver');
      toast({
        title: "Demo Mode Active",
        description: "You're viewing the platform with a demo driver account.",
      });
    } catch (error) {
      console.error('Demo login failed:', error);
      toast({
        title: "Demo Login Failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    } finally {
      setDemoLoading(false);
    }
  };

  const selectedRole = availableRoles.find(role => role.name === formData.role);

  const handleViewPolicies = async () => {
    if (loadingPolicy) return;
    setLoadingPolicy(true);
    
    // Open window immediately to avoid popup blocker
    const newWindow = window.open('about:blank', '_blank', 'noopener,noreferrer');
    
    try {
      const { data, error } = await supabase.functions.invoke('get-public-policy-url', {
        method: 'GET',
      });

      if (error || !data?.url) {
        throw new Error(error?.message || 'No URL returned');
      }

      // Update the window location with the actual URL
      if (newWindow) {
        newWindow.location.href = data.url;
      }
    } catch (error) {
      console.error('Error fetching policies document:', error);
      // Close the blank window if there was an error
      if (newWindow) {
        newWindow.close();
      }
      toast({
        title: "Error",
        description: "Failed to load the policies document.",
        variant: "destructive",
      });
    } finally {
      setLoadingPolicy(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center py-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-3 sm:mb-6">
          <div className="flex items-center justify-center space-x-2 mb-2 sm:mb-3">
            <div className="bg-gradient-to-r from-primary to-accent p-1.5 sm:p-2 rounded-lg">
              <Truck className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
            </div>
            <span className="text-lg sm:text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Haulee
            </span>
          </div>
          <h1 className="text-base sm:text-xl font-bold text-foreground mb-1">Welcome to the Platform</h1>
          <p className="text-xs sm:text-sm text-muted-foreground">Join thousands of logistics professionals</p>
        </div>

        <Tabs defaultValue={defaultTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="signin">Sign In</TabsTrigger>
            <TabsTrigger value="signup">Sign Up</TabsTrigger>
          </TabsList>

          {/* Sign In Tab */}
          <TabsContent value="signin">
            <Card>
              <CardHeader className="pb-3 sm:pb-6">
                <CardTitle className="text-base sm:text-lg">Sign In</CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Enter your credentials to access your account
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <form onSubmit={handleSignIn} className="space-y-3 sm:space-y-4">
                  <div className="space-y-1.5 sm:space-y-2">
                    <Label htmlFor="signin-email" className="text-xs sm:text-sm">Email</Label>
                    <Input
                      id="signin-email"
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="h-9 sm:h-10 text-sm"
                      required
                    />
                  </div>
                  <div className="space-y-1.5 sm:space-y-2">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="signin-password" className="text-xs sm:text-sm">Password</Label>
                      <button
                        type="button"
                        onClick={() => setShowForgotPassword(true)}
                        className="text-xs sm:text-sm text-primary hover:underline"
                      >
                        Forgot Password?
                      </button>
                    </div>
                    <div className="relative">
                      <Input
                        id="signin-password"
                        type={showSignInPassword ? "text" : "password"}
                        placeholder="Enter your password"
                        value={formData.password}
                        onChange={(e) => handleInputChange("password", e.target.value)}
                        className="h-9 sm:h-10 text-sm pr-10"
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowSignInPassword(!showSignInPassword)}
                        tabIndex={-1}
                      >
                        {showSignInPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <Button type="submit" className="w-full h-9 sm:h-10 text-sm" disabled={isLoading}>
                    {isLoading ? "Signing In..." : "Sign In"}
                  </Button>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <Separator />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">Or</span>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Button
                      type="button"
                      variant="outline"
                      className="w-full h-9 sm:h-10 text-sm"
                      onClick={handleDemoLogin}
                      disabled={demoLoading}
                    >
                      {demoLoading ? "Loading..." : "Try Demo Account"}
                    </Button>
                    <Button
                      type="button"
                      variant="ghost"
                      className="w-full h-9 sm:h-10 text-sm"
                      onClick={() => navigate('/showcase')}
                    >
                      View All Demo Roles
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Sign Up Tab */}
          <TabsContent value="signup">
            <Card>
              <CardHeader className="pb-2 sm:pb-4">
                <CardTitle className="text-base sm:text-lg">Create Account</CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Join Haulee and start growing your logistics business
                </CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                <form onSubmit={handleSignUp} className="space-y-2.5 sm:space-y-3">
                  {/* Personal Information */}
                  <div className="grid grid-cols-2 gap-2 sm:gap-3">
                    <div className="space-y-1 sm:space-y-1.5">
                      <Label htmlFor="first-name" className="text-xs sm:text-sm">First Name</Label>
                      <Input
                        id="first-name"
                        placeholder="John"
                        value={formData.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                        className="h-8 sm:h-9 text-sm"
                        required
                      />
                    </div>
                    <div className="space-y-1 sm:space-y-1.5">
                      <Label htmlFor="last-name" className="text-xs sm:text-sm">Last Name</Label>
                      <Input
                        id="last-name"
                        placeholder="Doe"
                        value={formData.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                        className="h-8 sm:h-9 text-sm"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-1 sm:space-y-1.5">
                    <Label htmlFor="signup-email" className="text-xs sm:text-sm">Email</Label>
                    <Input
                      id="signup-email"
                      type="email"
                      placeholder="john@example.com"
                      value={formData.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                      className="h-8 sm:h-9 text-sm"
                      required
                    />
                  </div>

                  <div className="space-y-1 sm:space-y-1.5">
                    <Label htmlFor="phone" className="text-xs sm:text-sm">Phone Number</Label>
                    <Input
                      id="phone"
                      type="tel"
                      placeholder="+1 (555) 123-4567"
                      value={formData.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                      className="h-8 sm:h-9 text-sm"
                      required
                    />
                  </div>

                  {/* Role Selection */}
                  <div className="space-y-1 sm:space-y-1.5">
                    <Label htmlFor="role" className="text-xs sm:text-sm">Account Type *</Label>
                    <Select 
                      onValueChange={(value) => handleInputChange("role", value)} 
                      required 
                      disabled={rolesLoading}
                      value={formData.role}
                    >
                      <SelectTrigger className="w-full bg-background h-8 sm:h-9 text-sm">
                        <SelectValue placeholder={rolesLoading ? "Loading..." : "Choose role"} />
                      </SelectTrigger>
                      <SelectContent 
                        className="bg-background border-2 border-border shadow-2xl z-[100]"
                        position="popper"
                        sideOffset={5}
                      >
                        {availableRoles.map((role) => (
                          <SelectItem 
                            key={role.id} 
                            value={role.name}
                            className="cursor-pointer hover:bg-accent focus:bg-accent py-1.5 sm:py-2"
                          >
                            <div className="flex items-center gap-2">
                              <div className="text-primary">
                                {getRoleIcon(role.name)}
                              </div>
                              <div className="flex-1">
                                <div className="font-medium text-xs sm:text-sm text-foreground">{formatRoleName(role.name)}</div>
                                <div className="text-[10px] sm:text-xs text-muted-foreground">
                                  {role.description}
                                </div>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Role-specific field */}
                  {formData.role && formData.role !== "driver" && (
                    <div className="space-y-1 sm:space-y-1.5">
                      <Label htmlFor="company-name" className="text-xs sm:text-sm">Company Name</Label>
                      <Input
                        id="company-name"
                        placeholder="Your company name"
                        value={formData.companyName}
                        onChange={(e) => handleInputChange("companyName", e.target.value)}
                        className="h-8 sm:h-9 text-sm"
                      />
                    </div>
                  )}

                  {/* Selected Role Preview - Compact on mobile */}
                  {selectedRole && (
                    <div className="p-2 sm:p-3 border border-primary/20 rounded-lg bg-primary/5">
                      <div className="flex items-center space-x-2 mb-1">
                        <div className="text-primary scale-75 sm:scale-100">{getRoleIcon(selectedRole.name)}</div>
                        <h4 className="font-semibold text-xs sm:text-sm text-primary">{formatRoleName(selectedRole.name)}</h4>
                      </div>
                      <p className="text-[10px] sm:text-xs text-muted-foreground">{selectedRole.description}</p>
                    </div>
                  )}

                  <div className="space-y-1 sm:space-y-1.5">
                    <Label htmlFor="signup-password" className="text-xs sm:text-sm">Password</Label>
                    <div className="relative">
                      <Input
                        id="signup-password"
                        type={showSignUpPassword ? "text" : "password"}
                        placeholder="Create password"
                        value={formData.password}
                        onChange={(e) => handleInputChange("password", e.target.value)}
                        className="h-8 sm:h-9 text-sm pr-10"
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowSignUpPassword(!showSignUpPassword)}
                        tabIndex={-1}
                      >
                        {showSignUpPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-1 sm:space-y-1.5">
                    <Label htmlFor="confirm-password" className="text-xs sm:text-sm">Confirm Password</Label>
                    <div className="relative">
                      <Input
                        id="confirm-password"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Confirm password"
                        value={formData.confirmPassword}
                        onChange={(e) => handleInputChange("confirmPassword", e.target.value)}
                        className="h-8 sm:h-9 text-sm pr-10"
                        required
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                        tabIndex={-1}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4 text-muted-foreground" />
                        ) : (
                          <Eye className="h-4 w-4 text-muted-foreground" />
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* Terms and Conditions Checkbox */}
                  <div className="flex items-start space-x-2 pt-1">
                    <Checkbox 
                      id="agree-policies" 
                      checked={agreeToPolicies}
                      onCheckedChange={(checked) => setAgreeToPolicies(checked as boolean)}
                      className="mt-0.5"
                    />
                    <Label 
                      htmlFor="agree-policies" 
                      className="text-[10px] sm:text-xs leading-tight cursor-pointer"
                    >
                      I agree to the{" "}
                      <button
                        type="button"
                        onClick={handleViewPolicies}
                        disabled={loadingPolicy}
                        className="text-primary hover:underline font-medium disabled:opacity-50"
                      >
                        Terms & Policies
                      </button>
                    </Label>
                  </div>

                  <Button type="submit" className="w-full h-8 sm:h-9 text-sm" disabled={isLoading || !agreeToPolicies}>
                    {isLoading ? "Creating..." : "Create Account"}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Forgot Password Dialog */}
        <Dialog open={showForgotPassword} onOpenChange={setShowForgotPassword}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Reset Password</DialogTitle>
              <DialogDescription>
                Enter your email address and we'll send you a link to reset your password.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="reset-email">Email</Label>
                <Input
                  id="reset-email"
                  type="email"
                  placeholder="your@email.com"
                  value={resetEmail}
                  onChange={(e) => setResetEmail(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={resetLoading}>
                {resetLoading ? "Sending..." : "Send Reset Link"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Password Reset Dialog (from email link) */}
        <Dialog open={showPasswordResetDialog} onOpenChange={setShowPasswordResetDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Set New Password</DialogTitle>
              <DialogDescription>
                Please enter your new password below.
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handlePasswordReset} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="new-password">New Password</Label>
                <Input
                  id="new-password"
                  type="password"
                  placeholder="Enter new password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="confirm-new-password">Confirm New Password</Label>
                <Input
                  id="confirm-new-password"
                  type="password"
                  placeholder="Confirm new password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full" disabled={resetPasswordLoading}>
                {resetPasswordLoading ? "Resetting..." : "Reset Password"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>

        {/* Force Password Change Modal - Blocking */}
        <ForcePasswordChangeModal 
          open={showPasswordChangeModal}
          onPasswordChanged={() => {
            // After password change, user is signed out and redirected to /auth
            navigate('/auth');
          }}
        />

        {/* Footer */}
        <div className="text-center mt-2 sm:mt-4 text-[10px] sm:text-xs text-muted-foreground pb-2">
          <p>
            By signing up, you agree to our{" "}
            <button
              type="button"
              onClick={handleViewPolicies}
              disabled={loadingPolicy}
              className="text-primary hover:underline font-medium disabled:opacity-50"
            >
              Terms & Policies
            </button>
            .
          </p>
        </div>
      </div>
    </div>
  );
};

export default Auth;
