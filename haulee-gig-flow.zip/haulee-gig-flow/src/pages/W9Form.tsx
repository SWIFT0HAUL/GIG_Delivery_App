import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { FileText, Download, CheckCircle } from "lucide-react";

export default function W9Form() {
  const navigate = useNavigate();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    taxpayerName: "",
    businessName: "",
    tinType: "EIN" as "SSN" | "EIN",
    tin: "",
    address: "",
    city: "",
    state: "",
    zip: "",
  });

  useEffect(() => {
    checkExistingW9();
  }, []);

  const checkExistingW9 = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("w9_forms")
      .select("status, approved_at")
      .eq("user_id", user.id)
      .order("submitted_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data?.approved_at) {
      setIsCompleted(true);
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const signatureData = canvas.toDataURL("image/png");
    
    // Check if signature is empty
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const isEmpty = !imageData.data.some(channel => channel !== 0);
    
    if (isEmpty) {
      toast.error("Please provide your signature");
      return;
    }

    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Call edge function to generate PDF
      const { data, error } = await supabase.functions.invoke("generate-w9-pdf", {
        body: {
          ...formData,
          signatureData,
          userId: user.id,
        },
      });

      if (error) throw error;

      setIsCompleted(true);
      setPdfUrl(data.pdfUrl);
      toast.success("W-9 form submitted successfully!");
    } catch (error: any) {
      console.error("Error submitting W-9:", error);
      toast.error(error.message || "Failed to submit W-9 form");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = async () => {
    if (!pdfUrl) return;
    
    try {
      const { data, error } = await supabase.storage
        .from("w9-forms")
        .download(pdfUrl.replace("w9-forms/", ""));

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = "W-9_Form.pdf";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error: any) {
      console.error("Error downloading W-9:", error);
      toast.error("Failed to download W-9 form");
    }
  };

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-background p-8">
        <div className="max-w-2xl mx-auto">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <CheckCircle className="h-8 w-8 text-green-500" />
                <CardTitle>W-9 Form Completed Successfully</CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Your W-9 form has been completed and saved. You can download it at any time.
              </p>
              <div className="flex gap-3">
                <Button onClick={handleDownload} className="gap-2">
                  <Download className="h-4 w-4" />
                  Download My W-9
                </Button>
                <Button variant="outline" onClick={() => navigate(-1)}>
                  Back to Onboarding
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-3xl mx-auto">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <FileText className="h-6 w-6" />
              <CardTitle>Complete W-9 Form</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <Label htmlFor="taxpayerName">Taxpayer Name *</Label>
                  <Input
                    id="taxpayerName"
                    required
                    value={formData.taxpayerName}
                    onChange={(e) => setFormData({ ...formData, taxpayerName: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="businessName">Business Name (if different)</Label>
                  <Input
                    id="businessName"
                    value={formData.businessName}
                    onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                  />
                </div>

                <div>
                  <Label>Tax Identification Number Type *</Label>
                  <RadioGroup
                    value={formData.tinType}
                    onValueChange={(value) => setFormData({ ...formData, tinType: value as "SSN" | "EIN" })}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="SSN" id="ssn" />
                      <Label htmlFor="ssn" className="font-normal">Social Security Number (SSN)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="EIN" id="ein" />
                      <Label htmlFor="ein" className="font-normal">Employer Identification Number (EIN)</Label>
                    </div>
                  </RadioGroup>
                </div>

                <div>
                  <Label htmlFor="tin">{formData.tinType} *</Label>
                  <Input
                    id="tin"
                    required
                    placeholder={formData.tinType === "SSN" ? "XXX-XX-XXXX" : "XX-XXXXXXX"}
                    value={formData.tin}
                    onChange={(e) => setFormData({ ...formData, tin: e.target.value })}
                  />
                </div>

                <div>
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    required
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="city">City *</Label>
                    <Input
                      id="city"
                      required
                      value={formData.city}
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="state">State *</Label>
                    <Input
                      id="state"
                      required
                      value={formData.state}
                      onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="zip">ZIP Code *</Label>
                    <Input
                      id="zip"
                      required
                      value={formData.zip}
                      onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                    />
                  </div>
                </div>

                <div>
                  <Label>Signature *</Label>
                  <div className="space-y-2">
                    <canvas
                      ref={canvasRef}
                      width={600}
                      height={150}
                      className="border rounded-md w-full cursor-crosshair bg-white"
                      onMouseDown={startDrawing}
                      onMouseMove={draw}
                      onMouseUp={stopDrawing}
                      onMouseLeave={stopDrawing}
                    />
                    <Button type="button" variant="outline" size="sm" onClick={clearSignature}>
                      Clear Signature
                    </Button>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? "Submitting..." : "Submit W-9"}
                </Button>
                <Button type="button" variant="outline" onClick={() => navigate(-1)}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
