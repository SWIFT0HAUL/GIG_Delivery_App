import React, { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { 
  Truck, 
  Package, 
  Users, 
  Building, 
  BarChart3, 
  Settings, 
  TrendingUp, 
  TrendingDown, 
  Clock, 
  DollarSign, 
  MapPin, 
  Shield,
  Activity,
  Target,
  Zap,
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle,
  UserX
} from "lucide-react";
import { StickyHorizontalScrollbar } from "@/components/dashboard/StickyHorizontalScrollbar";

const Dashboard = () => {
  const [activeTab, setActiveTab] = useState("users");
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const mainRef = useRef<HTMLDivElement>(null);

  const handleCardClick = (cardId: string) => {
    setSelectedCard(selectedCard === cardId ? null : cardId);
  };

  // Platform overview stats
  const platformStats = [
    {
      title: "Total Jobs Posted",
      value: "2,847",
      change: "+12.5%",
      trend: "up",
      icon: Package,
      color: "bg-primary",
      textColor: "text-primary-foreground"
    },
    {
      title: "Active Drivers",
      value: "834",
      change: "+8.2%",
      trend: "up", 
      icon: Users,
      color: "bg-accent",
      textColor: "text-accent-foreground"
    },
    {
      title: "Revenue Generated",
      value: "$127.4K",
      change: "+15.3%",
      trend: "up",
      icon: DollarSign,
      color: "bg-secondary", 
      textColor: "text-secondary-foreground"
    },
    {
      title: "Completion Rate",
      value: "94.2%",
      change: "-2.1%",
      trend: "down",
      icon: Target,
      color: "bg-muted",
      textColor: "text-muted-foreground"
    }
  ];

  // Role-specific metrics
  const roleMetrics = {
    shipper: [
      { title: "Jobs Posted", value: "156", icon: Package, color: "text-blue-600" },
      { title: "Avg Response Time", value: "2.4h", icon: Clock, color: "text-green-600" },
      { title: "Success Rate", value: "96%", icon: Target, color: "text-purple-600" }
    ],
    driver: [
      { title: "Jobs Completed", value: "89", icon: Truck, color: "text-blue-600" },
      { title: "Earnings This Month", value: "$3,240", icon: DollarSign, color: "text-green-600" },
      { title: "Rating", value: "4.8", icon: Shield, color: "text-purple-600" }
    ],
    carrier: [
      { title: "Active Vehicles", value: "24", icon: Truck, color: "text-blue-600" },
      { title: "Total Revenue", value: "$45,600", icon: DollarSign, color: "text-green-600" },
      { title: "Fleet Efficiency", value: "92%", icon: Activity, color: "text-purple-600" }
    ],
    vendor: [
      { title: "Products Listed", value: "342", icon: Package, color: "text-blue-600" },
      { title: "Monthly Sales", value: "$18,750", icon: DollarSign, color: "text-green-600" },
      { title: "Customer Rating", value: "4.7", icon: Shield, color: "text-purple-600" }
    ],
    broker: [
      { title: "Deals Brokered", value: "278", icon: Building, color: "text-blue-600" },
      { title: "Commission Earned", value: "$12,800", icon: DollarSign, color: "text-green-600" },
      { title: "Client Satisfaction", value: "4.9", icon: Shield, color: "text-purple-600" }
    ]
  };

  const quickActions = [
    {
      title: "Post New Job",
      description: "Create a delivery request instantly",
      icon: Package,
      color: "bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700",
      action: "Create Job"
    },
    {
      title: "Browse Available Jobs", 
      description: "Find opportunities in your area",
      icon: Truck,
      color: "bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700", 
      action: "Browse Jobs"
    },
    {
      title: "Manage Network",
      description: "Connect with trusted partners",
      icon: Users,
      color: "bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700",
      action: "View Network"
    },
    {
      title: "Analytics Dashboard",
      description: "Track performance and insights",
      icon: BarChart3,
      color: "bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700",
      action: "View Analytics"
    }
  ];

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      <div ref={mainRef} className="container mx-auto px-6 py-8 overflow-y-auto scrollbar-visible flex-1 space-y-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-foreground to-muted-foreground bg-clip-text text-transparent mb-2">
            Platform Dashboard
          </h1>
          <p className="text-muted-foreground text-lg">
            Your comprehensive logistics command center
          </p>
        </div>

        {/* Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
          <TabsList className="grid w-full grid-cols-6 mb-6">
            <TabsTrigger value="users" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="shipper" className="flex items-center gap-2">
              <Package className="h-4 w-4" />
              Shipper
            </TabsTrigger>
            <TabsTrigger value="driver" className="flex items-center gap-2">
              <Truck className="h-4 w-4" />
              Driver
            </TabsTrigger>
            <TabsTrigger value="carrier" className="flex items-center gap-2">
              <Building className="h-4 w-4" />
              Carrier
            </TabsTrigger>
            <TabsTrigger value="vendor_merchant" className="flex items-center gap-2">
              <Shield className="h-4 w-4" />
              Vendor
            </TabsTrigger>
            <TabsTrigger value="broker" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Broker
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="users">
            {/* User Statistics Section */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" />
                User Statistics
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('total-users')}
                >
                  <div className="bg-primary p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Users className="h-8 w-8 text-primary-foreground" />
                        <div>
                          <div className="text-2xl font-bold text-primary-foreground">
                            1,247
                          </div>
                          <p className="text-sm text-primary-foreground opacity-90">
                            Total Users
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-background/20 text-primary-foreground border-0 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +5.2%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-primary-foreground hover:bg-background/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'total-users' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-muted rounded-lg flex items-center justify-center">
                        <BarChart3 className="h-6 w-6 text-muted-foreground" />
                        <span className="ml-2 text-xs text-muted-foreground">User Growth Chart</span>
                      </div>
                    </div>
                  )}
                </Card>

                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('active-users')}
                >
                  <div className="bg-accent p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <CheckCircle className="h-8 w-8 text-accent-foreground" />
                        <div>
                          <div className="text-2xl font-bold text-accent-foreground">
                            1,089
                          </div>
                          <p className="text-sm text-accent-foreground opacity-90">
                            Active Users
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-background/20 text-accent-foreground border-0 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +8.1%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-accent-foreground hover:bg-background/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'active-users' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-muted rounded-lg flex items-center justify-center">
                        <Activity className="h-6 w-6 text-muted-foreground" />
                        <span className="ml-2 text-xs text-muted-foreground">Activity Chart</span>
                      </div>
                    </div>
                  )}
                </Card>

                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('pending-users')}
                >
                  <div className="bg-secondary p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Clock className="h-8 w-8 text-secondary-foreground" />
                        <div>
                          <div className="text-2xl font-bold text-secondary-foreground">
                            128
                          </div>
                          <p className="text-sm text-secondary-foreground opacity-90">
                            Pending Users
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="outline" className="border-secondary-foreground/20 text-secondary-foreground text-xs">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          -2.3%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-secondary-foreground hover:bg-secondary-foreground/10 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'pending-users' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-muted rounded-lg flex items-center justify-center">
                        <Clock className="h-6 w-6 text-muted-foreground" />
                        <span className="ml-2 text-xs text-muted-foreground">Pending Timeline</span>
                      </div>
                    </div>
                  )}
                </Card>

                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('inactive-users')}
                >
                  <div className="bg-destructive p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <UserX className="h-8 w-8 text-destructive-foreground" />
                        <div>
                          <div className="text-2xl font-bold text-destructive-foreground">
                            30
                          </div>
                          <p className="text-sm text-destructive-foreground opacity-90">
                            Inactive Users
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-background/20 text-destructive-foreground border-0 text-xs">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          -1.2%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-destructive-foreground hover:bg-background/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'inactive-users' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-muted rounded-lg flex items-center justify-center">
                        <TrendingDown className="h-6 w-6 text-muted-foreground" />
                        <span className="ml-2 text-xs text-muted-foreground">Inactive Trend</span>
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            </div>

            {/* Jobs & Operations Section */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
                <Package className="h-4 w-4 text-primary" />
                Jobs & Operations
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('total-jobs')}
                >
                  <div className="bg-gradient-to-r from-indigo-500 to-indigo-600 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Package className="h-8 w-8 text-indigo-50" />
                        <div>
                          <div className="text-2xl font-bold text-indigo-50">
                            2,847
                          </div>
                          <p className="text-sm text-indigo-50 opacity-90">
                            Total Jobs Posted
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-white/20 text-white border-0 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +12.5%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-indigo-50 hover:bg-white/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'total-jobs' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-gradient-to-r from-indigo-100 to-indigo-200 rounded-lg flex items-center justify-center">
                        <BarChart3 className="h-6 w-6 text-indigo-600" />
                        <span className="ml-2 text-xs text-indigo-700">Job Posting Trends</span>
                      </div>
                    </div>
                  )}
                </Card>

                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('jobs-completed')}
                >
                  <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Zap className="h-8 w-8 text-emerald-50" />
                        <div>
                          <div className="text-2xl font-bold text-emerald-50">
                            1,892
                          </div>
                          <p className="text-sm text-emerald-50 opacity-90">
                            Jobs Completed
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-white/20 text-white border-0 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +3.2%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-emerald-50 hover:bg-white/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'jobs-completed' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-gradient-to-r from-emerald-100 to-emerald-200 rounded-lg flex items-center justify-center">
                        <CheckCircle className="h-6 w-6 text-emerald-600" />
                        <span className="ml-2 text-xs text-emerald-700">Completion Rate</span>
                      </div>
                    </div>
                  )}
                </Card>

                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('active-jobs')}
                >
                  <div className="bg-gradient-to-r from-pink-500 to-pink-600 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Clock className="h-8 w-8 text-pink-50" />
                        <div>
                          <div className="text-2xl font-bold text-pink-50">
                            456
                          </div>
                          <p className="text-sm text-pink-50 opacity-90">
                            My Jobs
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-white/20 text-white border-0 text-xs">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +8.7%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-pink-50 hover:bg-white/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'active-jobs' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-gradient-to-r from-pink-100 to-pink-200 rounded-lg flex items-center justify-center">
                        <Activity className="h-6 w-6 text-pink-600" />
                        <span className="ml-2 text-xs text-pink-700">Real-time Jobs</span>
                      </div>
                    </div>
                  )}
                </Card>

                <Card 
                  className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0 cursor-pointer hover-scale"
                  onClick={() => handleCardClick('completion-rate')}
                >
                  <div className="bg-gradient-to-r from-teal-500 to-teal-600 p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Target className="h-8 w-8 text-teal-50" />
                        <div>
                          <div className="text-2xl font-bold text-teal-50">
                            94.2%
                          </div>
                          <p className="text-sm text-teal-50 opacity-90">
                            Completion Rate
                          </p>
                        </div>
                      </div>
                      <div className="flex flex-col items-end gap-2">
                        <Badge variant="secondary" className="bg-white/20 text-white border-0 text-xs">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          -2.1%
                        </Badge>
                        <Button variant="ghost" size="sm" className="text-teal-50 hover:bg-white/20 h-6 text-xs">
                          View Graph
                        </Button>
                      </div>
                    </div>
                  </div>
                  {selectedCard === 'completion-rate' && (
                    <div className="p-4 bg-muted/50 animate-fade-in">
                      <div className="h-24 bg-gradient-to-r from-teal-100 to-teal-200 rounded-lg flex items-center justify-center">
                        <Target className="h-6 w-6 text-teal-600" />
                        <span className="ml-2 text-xs text-teal-700">Success Metrics</span>
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            </div>

            {/* Financial Performance Section */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-primary" />
                Financial Performance
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-violet-500 to-violet-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <DollarSign className="h-8 w-8 text-violet-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +15.3%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-violet-50 mb-1">
                        $127.4K
                      </div>
                      <p className="text-sm text-violet-50 opacity-90">
                        Total Revenue
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-amber-500 to-amber-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <TrendingUp className="h-8 w-8 text-amber-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +22.4%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-amber-50 mb-1">
                        $38.2K
                      </div>
                      <p className="text-sm text-amber-50 opacity-90">
                        Monthly Revenue
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-rose-500 to-rose-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Activity className="h-8 w-8 text-rose-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +5.8%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-rose-50 mb-1">
                        $12.7K
                      </div>
                      <p className="text-sm text-rose-50 opacity-90">
                        Platform Fees
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-slate-500 to-slate-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <TrendingDown className="h-8 w-8 text-slate-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          -3.1%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-slate-50 mb-1">
                        $2.8K
                      </div>
                      <p className="text-sm text-slate-50 opacity-90">
                        Monthly Costs
                      </p>
                    </CardContent>
                  </div>
                </Card>
              </div>
            </div>

            {/* Fleet & Vehicles Section */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Truck className="h-5 w-5 text-primary" />
                Fleet & Vehicles
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-cyan-500 to-cyan-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Truck className="h-8 w-8 text-cyan-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +8.2%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-cyan-50 mb-1">
                        834
                      </div>
                      <p className="text-sm text-cyan-50 opacity-90">
                        Active Drivers
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-lime-500 to-lime-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Building className="h-8 w-8 text-lime-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +12.1%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-lime-50 mb-1">
                        156
                      </div>
                      <p className="text-sm text-lime-50 opacity-90">
                        Carrier Companies
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <MapPin className="h-8 w-8 text-orange-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +6.7%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-orange-50 mb-1">
                        1,247
                      </div>
                      <p className="text-sm text-orange-50 opacity-90">
                        Registered Vehicles
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-sky-500 to-sky-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Activity className="h-8 w-8 text-sky-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +4.3%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-sky-50 mb-1">
                        87.4%
                      </div>
                      <p className="text-sm text-sky-50 opacity-90">
                        Fleet Utilization
                      </p>
                    </CardContent>
                  </div>
                </Card>
              </div>
            </div>

            {/* Platform Health Section */}
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                Platform Health
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Shield className="h-8 w-8 text-emerald-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +1.2%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-emerald-50 mb-1">
                        99.8%
                      </div>
                      <p className="text-sm text-emerald-50 opacity-90">
                        System Uptime
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Zap className="h-8 w-8 text-indigo-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          -15ms
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-indigo-50 mb-1">
                        245ms
                      </div>
                      <p className="text-sm text-indigo-50 opacity-90">
                        Avg Response Time
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-purple-500 to-purple-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Target className="h-8 w-8 text-purple-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowUpRight className="h-3 w-3 mr-1" />
                          +0.8%
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-purple-50 mb-1">
                        4.6
                      </div>
                      <p className="text-sm text-purple-50 opacity-90">
                        Platform Rating
                      </p>
                    </CardContent>
                  </div>
                </Card>

                <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 border-0">
                  <div className="bg-gradient-to-br from-red-500 to-red-600 p-6">
                    <CardHeader className="p-0 pb-4">
                      <div className="flex items-center justify-between">
                        <Settings className="h-8 w-8 text-red-50" />
                        <Badge variant="secondary" className="bg-white/20 text-white border-0">
                          <ArrowDownRight className="h-3 w-3 mr-1" />
                          -12
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="text-3xl font-bold text-red-50 mb-1">
                        3
                      </div>
                      <p className="text-sm text-red-50 opacity-90">
                        Open Issues
                      </p>
                    </CardContent>
                  </div>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Role-specific tabs */}
          {Object.entries(roleMetrics).map(([role, metrics]) => (
            <TabsContent key={role} value={role}>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                {metrics.map((metric, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{metric.title}</CardTitle>
                      <metric.icon className={`h-4 w-4 ${metric.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">{metric.value}</div>
                      <p className="text-xs text-muted-foreground capitalize">
                        {role} specific metric
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Role-specific actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="capitalize">{role} Dashboard</CardTitle>
                  <CardDescription>
                    Specialized tools and metrics for {role} operations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Button className="h-20 flex flex-col gap-2">
                      <Package className="h-6 w-6" />
                      Manage {role === 'shipper' ? 'Jobs' : role === 'driver' ? 'Deliveries' : role === 'carrier' ? 'Fleet' : 'Deals'}
                    </Button>
                    <Button variant="outline" className="h-20 flex flex-col gap-2">
                      <BarChart3 className="h-6 w-6" />
                      View {role} Analytics
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          ))}
        </Tabs>
      </div>
      <StickyHorizontalScrollbar targetRef={mainRef} />
    </div>
  );
};

export default Dashboard;