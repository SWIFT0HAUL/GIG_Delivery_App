import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, Package, Users, Shield, Building, TrendingUp, Clock, MapPin, CheckCircle, ArrowRight, Zap, BarChart3 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { loginWithDemoAccount } from '@/lib/demo';
import { toast } from '@/hooks/use-toast';

const Showcase = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = React.useState<string | null>(null);

  const handleDemoLogin = async (role: 'driver' | 'shipper' | 'carrier' | 'broker' | 'vendor' | 'admin') => {
    setLoading(role);
    try {
      await loginWithDemoAccount(role);
      toast({
        title: "Welcome to Demo Mode",
        description: `You're now viewing the platform as a ${role}.`,
      });
    } catch (error) {
      console.error('Demo login failed:', error);
      toast({
        title: "Demo Login Failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    } finally {
      setLoading(null);
    }
  };

  const demoRoles: Array<{
    role: 'driver' | 'shipper' | 'carrier' | 'broker' | 'vendor' | 'admin';
    title: string;
    icon: typeof Users;
    description: string;
    features: string[];
    color: string;
  }> = [
    {
      role: 'driver' as const,
      title: 'Driver',
      icon: Users,
      description: 'Access available jobs, track deliveries, and manage earnings',
      features: ['Job board', 'Delivery tracking', 'Earnings dashboard', 'Route optimization'],
      color: 'from-blue-500 to-blue-600'
    },
    {
      role: 'shipper' as const,
      title: 'Shipper',
      icon: Package,
      description: 'Create shipments, track deliveries, and manage logistics',
      features: ['Create jobs', 'Track shipments', 'Manage carriers', 'Analytics dashboard'],
      color: 'from-green-500 to-green-600'
    },
    {
      role: 'carrier' as const,
      title: 'Carrier',
      icon: Truck,
      description: 'Manage fleet, assign drivers, and track company performance',
      features: ['Fleet management', 'Driver assignment', 'Revenue tracking', 'Performance metrics'],
      color: 'from-orange-500 to-orange-600'
    },
    {
      role: 'broker' as const,
      title: 'Broker',
      icon: Shield,
      description: 'Connect shippers with carriers and manage logistics operations',
      features: ['Matchmaking', 'Commission tracking', 'Network management', 'Deal pipeline'],
      color: 'from-purple-500 to-purple-600'
    },
    {
      role: 'vendor' as const,
      title: 'Vendor',
      icon: Building,
      description: 'Post delivery jobs and manage vendor operations',
      features: ['Job posting', 'Vendor catalog', 'Order management', 'Supplier network'],
      color: 'from-pink-500 to-pink-600'
    },
    {
      role: 'admin' as const,
      title: 'Admin',
      icon: Shield,
      description: 'Full platform administration and system management',
      features: ['User management', 'System settings', 'Analytics', 'Platform configuration'],
      color: 'from-red-500 to-red-600'
    }
  ];

  const platformFeatures = [
    {
      icon: Zap,
      title: 'Real-time Tracking',
      description: 'Track all deliveries in real-time with GPS integration'
    },
    {
      icon: BarChart3,
      title: 'Analytics Dashboard',
      description: 'Comprehensive analytics and reporting for all users'
    },
    {
      icon: MapPin,
      title: 'Route Optimization',
      description: 'AI-powered route planning for efficient deliveries'
    },
    {
      icon: CheckCircle,
      title: 'Automated Workflows',
      description: 'Streamlined processes from booking to delivery'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="bg-gradient-to-r from-primary to-accent p-2 rounded-lg">
              <Truck className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Haulee
            </span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" onClick={() => navigate('/auth')}>
              Sign In
            </Button>
            <Button onClick={() => navigate('/auth?tab=signup')}>
              Get Started
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <Badge className="mb-4" variant="secondary">
          <Zap className="h-3 w-3 mr-1" />
          Live Demo Available
        </Badge>
        <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
          The Future of Logistics
        </h1>
        <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
          Experience our comprehensive logistics platform from any perspective. Try a demo account to see how we're revolutionizing freight management.
        </p>
        <div className="flex items-center justify-center gap-4 flex-wrap">
          <Button size="lg" onClick={() => navigate('/auth?tab=signup')} className="gap-2">
            Start Free Trial
            <ArrowRight className="h-4 w-4" />
          </Button>
          <Button size="lg" variant="outline" onClick={() => document.getElementById('demo-accounts')?.scrollIntoView({ behavior: 'smooth' })}>
            Try Demo Accounts
          </Button>
        </div>
      </section>

      {/* Platform Features */}
      <section className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Platform Features</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Built for efficiency, designed for scale, trusted by logistics professionals
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {platformFeatures.map((feature, index) => (
            <Card key={index} className="border-2 hover:border-primary transition-colors">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Demo Accounts Section */}
      <section id="demo-accounts" className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <Badge className="mb-4" variant="secondary">
            <Users className="h-3 w-3 mr-1" />
            Interactive Demos
          </Badge>
          <h2 className="text-3xl font-bold mb-4">Try Any Role</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore the platform from different perspectives. Each demo account is pre-loaded with sample data.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {demoRoles.map((demo) => {
            const Icon = demo.icon;
            return (
              <Card key={demo.role} className="group hover:shadow-lg transition-all duration-300 border-2 hover:border-primary">
                <CardHeader>
                  <div className={`h-14 w-14 rounded-xl bg-gradient-to-br ${demo.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon className="h-7 w-7 text-white" />
                  </div>
                  <CardTitle className="text-xl">{demo.title}</CardTitle>
                  <CardDescription>{demo.description}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Key Features:</p>
                    <ul className="space-y-1">
                      {demo.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center text-sm">
                          <CheckCircle className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <Button 
                    className="w-full" 
                    onClick={() => handleDemoLogin(demo.role)}
                    disabled={loading === demo.role}
                  >
                    {loading === demo.role ? 'Loading...' : `Try ${demo.title} Demo`}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-16">
        <Card className="bg-gradient-to-r from-primary/10 via-accent/10 to-primary/10 border-2 border-primary/20">
          <CardContent className="p-12 text-center">
            <h2 className="text-3xl font-bold mb-4">Ready to Transform Your Logistics?</h2>
            <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of logistics professionals already using our platform to streamline their operations
            </p>
            <div className="flex items-center justify-center gap-4 flex-wrap">
              <Button size="lg" onClick={() => navigate('/auth?tab=signup')}>
                Create Free Account
              </Button>
              <Button size="lg" variant="outline" onClick={() => navigate('/auth')}>
                Sign In
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Footer */}
      <footer className="border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>© 2025 Haulee. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Showcase;
