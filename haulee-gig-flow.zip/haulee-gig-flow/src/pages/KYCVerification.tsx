import { KYCSubmissionForm } from '@/components/kyc/KYCSubmissionForm';

export default function KYCVerification() {
  return (
    <div className="container mx-auto px-6 py-8">
      <KYCSubmissionForm />
    </div>
  );
}
