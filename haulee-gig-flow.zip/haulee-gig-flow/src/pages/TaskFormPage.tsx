import { useNavigate, useSearchParams } from "react-router-dom";
import { DynamicTaskForm } from "@/components/tasks/DynamicTaskForm";
import { TaskAccessGuard } from "@/components/access";

export default function TaskFormPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const taskId = searchParams.get("id");

  const handleBack = () => {
    navigate(-1);
  };

  if (!taskId) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-muted-foreground">No task ID provided</p>
        </div>
      </div>
    );
  }

  return (
    <TaskAccessGuard taskId={taskId} action="view">
      <div className="min-h-screen w-full overflow-x-hidden">
        <div className="container max-w-4xl mx-auto p-4 sm:p-6 lg:p-8">
          <DynamicTaskForm taskId={taskId} onBack={handleBack} />
        </div>
      </div>
    </TaskAccessGuard>
  );
}
