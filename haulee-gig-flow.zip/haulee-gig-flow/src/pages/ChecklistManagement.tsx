import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ChecklistSummaryReport } from '@/components/admin/ChecklistSummaryReport';
import { DocumentationCenter } from '@/components/admin/DocumentationCenter';
import { ClipboardCheck, FileText } from 'lucide-react';

export const ChecklistManagement: React.FC = () => {
  return (
    <div className="container mx-auto py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Checklist Management</h1>
        <p className="text-muted-foreground mt-2">
          Manage user approval checklists, pre-activation checklists, and Standard Operating Procedures (SOPs)
        </p>
      </div>

      <Tabs defaultValue="checklists" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
          <TabsTrigger value="checklists" className="flex items-center gap-2">
            <ClipboardCheck className="h-4 w-4" />
            Checklists
          </TabsTrigger>
          <TabsTrigger value="sops" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            SOPs & Docs
          </TabsTrigger>
        </TabsList>

        <TabsContent value="checklists" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Checklist Summary Report</CardTitle>
              <CardDescription>
                View and manage all user approval and pre-activation checklists
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ChecklistSummaryReport />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sops" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Documentation Center</CardTitle>
              <CardDescription>
                Manage Standard Operating Procedures (SOPs), policies, tutorials, and release notes
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DocumentationCenter />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ChecklistManagement;
