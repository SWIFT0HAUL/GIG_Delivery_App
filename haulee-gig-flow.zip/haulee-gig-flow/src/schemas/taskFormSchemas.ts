/**
 * Task Form Schemas
 * Defines multi-step forms for various task types across the platform
 */

export const DRIVER_LICENSE_FORM = [
  {
    step_number: 1,
    step_name: "Requirements",
    step_description: "Before uploading, ensure your driver's license is valid, not expired, and clearly visible.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Upload License Front",
    step_description: "Upload a clear photo of the front of your driver's license",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "license_front",
        field_type: "file_upload",
        field_label: "Driver License (Front)",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "driver-licenses"
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Upload License Back",
    step_description: "Upload a clear photo of the back of your driver's license",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "license_back",
        field_type: "file_upload",
        field_label: "Driver License (Back)",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "driver-licenses"
      }
    ]
  },
  {
    step_number: 4,
    step_name: "License Information",
    step_description: "Enter your driver's license details",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "license_number",
        field_type: "text",
        field_label: "License Number",
        required: true,
        placeholder: "Enter your license number"
      },
      {
        field_name: "license_state",
        field_type: "text",
        field_label: "Issuing State",
        required: true,
        placeholder: "e.g., CA, NY, TX"
      },
      {
        field_name: "license_expiry",
        field_type: "date",
        field_label: "Expiration Date",
        required: true
      }
    ]
  }
];

export const INSURANCE_FORM = [
  {
    step_number: 1,
    step_name: "Insurance Requirements",
    step_description: "Review the required insurance coverage amounts and policy types.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Upload Insurance Certificate",
    step_description: "Upload your current insurance certificate or declaration page",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "insurance_certificate",
        field_type: "file_upload",
        field_label: "Insurance Certificate",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "insurance"
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Insurance Details",
    step_description: "Provide your insurance policy information",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "insurance_provider",
        field_type: "select",
        field_label: "Insurance Provider",
        required: true,
        options: [
          "State Farm", "Geico", "Progressive", "Allstate", "USAA",
          "Liberty Mutual", "Farmers", "Nationwide", "American Family",
          "Travelers", "AAA", "Mercury", "Safeco", "The Hartford",
          "Esurance", "MetLife", "Kemper", "The General", "Bristol West",
          "Dairyland", "National General", "Other"
        ]
      },
      {
        field_name: "policy_number",
        field_type: "text",
        field_label: "Policy Number",
        required: true,
        placeholder: "Enter your policy number"
      },
      {
        field_name: "policy_expiry",
        field_type: "date",
        field_label: "Policy Expiration Date",
        required: true
      },
      {
        field_name: "coverage_amount",
        field_type: "number",
        field_label: "Coverage Amount ($)",
        required: true,
        placeholder: "Enter coverage amount"
      }
    ]
  }
];

export const VEHICLE_REGISTRATION_FORM = [
  {
    step_number: 1,
    step_name: "Vehicle Registration Requirements",
    step_description: "Your vehicle registration must be current and match your vehicle information.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Upload Registration",
    step_description: "Upload a clear photo of your vehicle registration document",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "registration_document",
        field_type: "file_upload",
        field_label: "Registration Document",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "vehicle-registration"
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Vehicle Information",
    step_description: "Enter your vehicle details",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "vin",
        field_type: "text",
        field_label: "VIN (Vehicle Identification Number)",
        required: true,
        placeholder: "17-character VIN"
      },
      {
        field_name: "license_plate",
        field_type: "text",
        field_label: "License Plate Number",
        required: true,
        placeholder: "Enter license plate"
      },
      {
        field_name: "vehicle_make",
        field_type: "select",
        field_label: "Make",
        required: true,
        options: [
          "Acura", "Alfa Romeo", "Audi", "BMW", "Buick", "Cadillac", 
          "Chevrolet", "Chevrolet Commercial", "Chrysler", "Dodge", "FIAT", 
          "Ford", "Ford Commercial", "Freightliner", "Genesis", "GMC", 
          "GMC Commercial", "Hino", "Honda", "Hyundai", "INFINITI", 
          "International", "Isuzu", "Isuzu Commercial", "Jaguar", "Jeep", 
          "Kenworth", "Kia", "Land Rover", "Lexus", "Lincoln", "Mack", 
          "Maserati", "Mazda", "Mercedes-Benz", "Mercedes-Benz Commercial", 
          "MINI", "Mitsubishi", "Mitsubishi Fuso", "Nissan", 
          "Nissan Commercial", "Peterbilt", "Porsche", "Ram", 
          "Ram Commercial", "Subaru", "Tesla", "Toyota", "Volkswagen", 
          "Volvo", "Volvo Trucks", "Western Star", "Other"
        ]
      },
      {
        field_name: "vehicle_model",
        field_type: "text",
        field_label: "Model",
        required: true,
        placeholder: "e.g., F-150, Camry"
      },
      {
        field_name: "vehicle_year",
        field_type: "number",
        field_label: "Year",
        required: true,
        placeholder: "e.g., 2020"
      }
    ]
  }
];

export const BACKGROUND_CHECK_FORM = [
  {
    step_number: 1,
    step_name: "Background Check Consent",
    step_description: "Review and consent to the background check process.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Personal Information",
    step_description: "Provide information required for background check",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "full_legal_name",
        field_type: "text",
        field_label: "Full Legal Name",
        required: true,
        placeholder: "As it appears on government ID"
      },
      {
        field_name: "date_of_birth",
        field_type: "date",
        field_label: "Date of Birth",
        required: true
      },
      {
        field_name: "ssn_last_four",
        field_type: "text",
        field_label: "Last 4 digits of SSN",
        required: true,
        placeholder: "XXXX"
      },
      {
        field_name: "current_address",
        field_type: "textarea",
        field_label: "Current Address",
        required: true,
        placeholder: "Full street address"
      }
    ]
  }
];

export const BANK_ACCOUNT_FORM = [
  {
    step_number: 1,
    step_name: "Bank Account Setup",
    step_description: "Set up your bank account for direct deposit payments.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Account Details",
    step_description: "Enter your bank account information",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "account_holder_name",
        field_type: "text",
        field_label: "Account Holder Name",
        required: true,
        placeholder: "Name on bank account"
      },
      {
        field_name: "bank_name",
        field_type: "text",
        field_label: "Bank Name",
        required: true,
        placeholder: "e.g., Chase, Bank of America"
      },
      {
        field_name: "routing_number",
        field_type: "text",
        field_label: "Routing Number",
        required: true,
        placeholder: "9-digit routing number"
      },
      {
        field_name: "account_number",
        field_type: "text",
        field_label: "Account Number",
        required: true,
        placeholder: "Account number"
      },
      {
        field_name: "account_type",
        field_type: "select",
        field_label: "Account Type",
        required: true,
        options: ["Checking", "Savings"]
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Verify Account",
    step_description: "Upload a voided check or bank statement for verification",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "bank_verification",
        field_type: "file_upload",
        field_label: "Voided Check or Bank Statement",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "bank-verification"
      }
    ]
  }
];

export const PAYMENT_METHOD_FORM = [
  {
    step_number: 1,
    step_name: "Payment Method Setup",
    step_description: "Add a payment method to make payments on the platform. Your payment information will be encrypted and stored securely.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Profile Photo",
    step_description: "Upload a profile photo for identity verification",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "profile_photo",
        field_type: "file_upload",
        field_label: "Profile Photo",
        required: true,
        accept: "image/*",
        bucket_name: "kyc-documents",
        folder: "profile-photos"
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Choose Payment Type",
    step_description: "Select your preferred payment method",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "payment_type",
        field_type: "select",
        field_label: "Payment Method Type",
        required: true,
        options: ["Credit Card", "Debit Card", "Bank Account (ACH)"]
      }
    ]
  },
  {
    step_number: 4,
    step_name: "Card Information",
    step_description: "Enter your card details (all information is encrypted)",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    conditional_display: {
      field: "payment_type",
      values: ["Credit Card", "Debit Card"]
    },
    fields: [
      {
        field_name: "cardholder_name",
        field_type: "text",
        field_label: "Cardholder Name",
        required: true,
        placeholder: "Name as it appears on card"
      },
      {
        field_name: "card_number",
        field_type: "text",
        field_label: "Card Number",
        required: true,
        placeholder: "1234 5678 9012 3456",
        validation: {
          pattern: "^[0-9]{13,19}$",
          message: "Please enter a valid card number"
        }
      },
      {
        field_name: "expiry_date",
        field_type: "text",
        field_label: "Expiration Date",
        required: true,
        placeholder: "MM/YY",
        validation: {
          pattern: "^(0[1-9]|1[0-2])\\/([0-9]{2})$",
          message: "Format: MM/YY"
        }
      },
      {
        field_name: "cvv",
        field_type: "text",
        field_label: "CVV",
        required: true,
        placeholder: "123",
        validation: {
          pattern: "^[0-9]{3,4}$",
          message: "3 or 4 digits"
        }
      },
      {
        field_name: "billing_zip",
        field_type: "text",
        field_label: "Billing ZIP Code",
        required: true,
        placeholder: "12345"
      }
    ]
  },
  {
    step_number: 5,
    step_name: "Bank Account Information",
    step_description: "Enter your bank account details for ACH payments",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    conditional_display: {
      field: "payment_type",
      values: ["Bank Account (ACH)"]
    },
    fields: [
      {
        field_name: "account_holder_name",
        field_type: "text",
        field_label: "Account Holder Name",
        required: true,
        placeholder: "Name on bank account"
      },
      {
        field_name: "bank_name",
        field_type: "text",
        field_label: "Bank Name",
        required: true,
        placeholder: "e.g., Chase, Bank of America"
      },
      {
        field_name: "routing_number",
        field_type: "text",
        field_label: "Routing Number",
        required: true,
        placeholder: "9-digit routing number",
        validation: {
          pattern: "^[0-9]{9}$",
          message: "Must be exactly 9 digits"
        }
      },
      {
        field_name: "account_number",
        field_type: "text",
        field_label: "Account Number",
        required: true,
        placeholder: "Account number"
      },
      {
        field_name: "account_type",
        field_type: "select",
        field_label: "Account Type",
        required: true,
        options: ["Checking", "Savings"]
      }
    ]
  },
  {
    step_number: 6,
    step_name: "Billing Address",
    step_description: "Provide your billing address",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "billing_address",
        field_type: "text",
        field_label: "Street Address",
        required: true,
        placeholder: "123 Main St"
      },
      {
        field_name: "billing_city",
        field_type: "text",
        field_label: "City",
        required: true,
        placeholder: "City"
      },
      {
        field_name: "billing_state",
        field_type: "text",
        field_label: "State",
        required: true,
        placeholder: "State"
      },
      {
        field_name: "billing_zip_full",
        field_type: "text",
        field_label: "ZIP Code",
        required: true,
        placeholder: "12345"
      }
    ]
  },
  {
    step_number: 7,
    step_name: "Confirm & Agree",
    step_description: "Review and confirm your payment method",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "agree_to_terms",
        field_type: "checkbox",
        field_label: "I authorize the platform to charge this payment method for services rendered",
        required: true
      },
      {
        field_name: "save_for_future",
        field_type: "checkbox",
        field_label: "Save this payment method for future transactions",
        required: false
      }
    ]
  }
];

export const EMERGENCY_CONTACT_FORM = [
  {
    step_number: 1,
    step_name: "Emergency Contact",
    step_description: "Provide emergency contact information for safety purposes.",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "emergency_name",
        field_type: "text",
        field_label: "Contact Name",
        required: true,
        placeholder: "Full name"
      },
      {
        field_name: "emergency_relationship",
        field_type: "text",
        field_label: "Relationship",
        required: true,
        placeholder: "e.g., Spouse, Parent, Sibling"
      },
      {
        field_name: "emergency_phone",
        field_type: "text",
        field_label: "Phone Number",
        required: true,
        placeholder: "(555) 555-5555"
      },
      {
        field_name: "emergency_email",
        field_type: "text",
        field_label: "Email Address",
        required: false,
        placeholder: "email@example.com"
      }
    ]
  }
];

export const SAFETY_TRAINING_FORM = [
  {
    step_number: 1,
    step_name: "Safety Training Overview",
    step_description: "Complete the safety training modules and assessments.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Training Completion",
    step_description: "Confirm completion of all safety training modules",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "training_completed",
        field_type: "checkbox",
        field_label: "I have completed all required safety training modules",
        required: true
      },
      {
        field_name: "training_certificate",
        field_type: "file_upload",
        field_label: "Training Certificate (if applicable)",
        required: false,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "training"
      }
    ]
  }
];

export const CARRIER_AUTHORITY_FORM = [
  {
    step_number: 1,
    step_name: "MC Number Requirements",
    step_description: "Your Motor Carrier (MC) number must be active and in good standing.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Authority Details",
    step_description: "Enter your carrier authority information",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "mc_number",
        field_type: "text",
        field_label: "MC Number",
        required: true,
        placeholder: "MC-XXXXXX"
      },
      {
        field_name: "dot_number",
        field_type: "text",
        field_label: "DOT Number",
        required: true,
        placeholder: "DOT number"
      },
      {
        field_name: "operating_authority_doc",
        field_type: "file_upload",
        field_label: "Operating Authority Document",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "carrier-authority"
      }
    ]
  }
];

export const REVIEW_PLATFORM_GUIDELINES_FORM = [
  {
    step_number: 1,
    step_name: "Platform Guidelines Overview",
    step_description: "Review the complete platform guidelines to understand policies, standards, and expectations for all platform users.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Access Guidelines Document",
    step_description: "Download and review the complete platform guidelines document",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "guidelines_link",
        field_type: "link",
        field_label: "View Platform Guidelines",
        required: false,
        url: "/get-public-policy-url"
      },
      {
        field_name: "guidelines_reviewed",
        field_type: "checkbox",
        field_label: "I have reviewed the complete platform guidelines document",
        required: true
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Understanding Key Policies",
    step_description: "Confirm your understanding of key platform policies",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "understand_conduct",
        field_type: "checkbox",
        field_label: "I understand the code of conduct and behavioral expectations",
        required: true
      },
      {
        field_name: "understand_safety",
        field_type: "checkbox",
        field_label: "I understand the safety and security requirements",
        required: true
      },
      {
        field_name: "understand_compliance",
        field_type: "checkbox",
        field_label: "I understand the compliance and regulatory requirements",
        required: true
      },
      {
        field_name: "understand_data_privacy",
        field_type: "checkbox",
        field_label: "I understand the data privacy and confidentiality policies",
        required: true
      }
    ]
  },
  {
    step_number: 4,
    step_name: "Acknowledgment & Acceptance",
    step_description: "Formally acknowledge and accept the platform guidelines",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "guidelines_acceptance",
        field_type: "checkbox",
        field_label: "I acknowledge that I have read, understood, and agree to comply with all platform guidelines",
        required: true
      },
      {
        field_name: "violation_consequences",
        field_type: "checkbox",
        field_label: "I understand that violations may result in account suspension or termination",
        required: true
      },
      {
        field_name: "full_name",
        field_type: "text",
        field_label: "Full Legal Name",
        required: true,
        placeholder: "Enter your full legal name"
      },
      {
        field_name: "acceptance_date",
        field_type: "date",
        field_label: "Date of Acceptance",
        required: true
      }
    ]
  }
];

export const SHIPPER_AGREEMENT_FORM = [
  {
    step_number: 1,
    step_name: "Service Agreement",
    step_description: "Review the shipper service agreement and terms.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Accept Agreement",
    step_description: "Accept the terms and conditions",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "agreement_accepted",
        field_type: "checkbox",
        field_label: "I have read and accept the Shipper Service Agreement",
        required: true
      },
      {
        field_name: "authorized_signatory",
        field_type: "text",
        field_label: "Authorized Signatory Name",
        required: true,
        placeholder: "Full legal name"
      },
      {
        field_name: "signatory_title",
        field_type: "text",
        field_label: "Title/Position",
        required: true,
        placeholder: "e.g., CEO, Operations Manager"
      },
      {
        field_name: "signature_date",
        field_type: "date",
        field_label: "Signature Date",
        required: true
      }
    ]
  }
];

export const BUSINESS_LICENSE_FORM = [
  {
    step_number: 1,
    step_name: "Business License Requirements",
    step_description: "Upload your valid business license or registration certificate.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Upload License",
    step_description: "Upload your business license document",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "business_license",
        field_type: "file_upload",
        field_label: "Business License",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "business-licenses"
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Business Information",
    step_description: "Enter your business details",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "business_legal_name",
        field_type: "text",
        field_label: "Legal Business Name",
        required: true,
        placeholder: "Official registered name"
      },
      {
        field_name: "ein",
        field_type: "text",
        field_label: "EIN (Employer Identification Number)",
        required: true,
        placeholder: "XX-XXXXXXX"
      },
      {
        field_name: "license_number",
        field_type: "text",
        field_label: "License Number",
        required: true,
        placeholder: "License number"
      },
      {
        field_name: "license_expiry",
        field_type: "date",
        field_label: "License Expiration Date",
        required: true
      }
    ]
  }
];

export const VEHICLE_INSPECTION_FORM = [
  {
    step_number: 1,
    step_name: "Inspection Requirements",
    step_description: "Your vehicle must pass a safety inspection within the last 12 months.",
    step_type: "informational",
    path: "",
    is_optional: false
  },
  {
    step_number: 2,
    step_name: "Upload Inspection Certificate",
    step_description: "Upload your current vehicle inspection certificate",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "inspection_certificate",
        field_type: "file_upload",
        field_label: "Inspection Certificate",
        required: true,
        accept: "image/*,.pdf",
        bucket_name: "kyc-documents",
        folder: "vehicle-inspections"
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Inspection Details",
    step_description: "Enter inspection information",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "inspection_date",
        field_type: "date",
        field_label: "Inspection Date",
        required: true
      },
      {
        field_name: "inspection_expiry",
        field_type: "date",
        field_label: "Expiration Date",
        required: true
      },
      {
        field_name: "inspection_facility",
        field_type: "text",
        field_label: "Inspection Facility",
        required: true,
        placeholder: "Name of inspection facility"
      }
    ]
  }
];

export const PROFILE_COMPLETION_FORM = [
  {
    step_number: 1,
    step_name: "Profile Photo",
    step_description: "Upload a profile photo for your account",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "profile_photo",
        field_type: "file_upload",
        field_label: "Profile Photo",
        required: true,
        accept: "image/*",
        bucket_name: "kyc-documents",
        folder: "profile-photos"
      }
    ]
  },
  {
    step_number: 2,
    step_name: "Personal Information",
    step_description: "Complete your personal information",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "full_name",
        field_type: "text",
        field_label: "Full Name",
        required: true,
        placeholder: "Enter your full name"
      },
      {
        field_name: "phone_number",
        field_type: "text",
        field_label: "Phone Number",
        required: true,
        placeholder: "(555) 123-4567"
      },
      {
        field_name: "date_of_birth",
        field_type: "date",
        field_label: "Date of Birth",
        required: true
      }
    ]
  },
  {
    step_number: 3,
    step_name: "Address",
    step_description: "Enter your current address",
    step_type: "data_collection",
    path: "",
    is_optional: false,
    fields: [
      {
        field_name: "street_address",
        field_type: "text",
        field_label: "Street Address",
        required: true,
        placeholder: "123 Main St"
      },
      {
        field_name: "city",
        field_type: "text",
        field_label: "City",
        required: true,
        placeholder: "City"
      },
      {
        field_name: "state",
        field_type: "text",
        field_label: "State",
        required: true,
        placeholder: "State"
      },
      {
        field_name: "zip_code",
        field_type: "text",
        field_label: "ZIP Code",
        required: true,
        placeholder: "12345"
      }
    ]
  }
];

// Helper function to get form schema by task name
export const getTaskFormSchema = (taskName: string): any[] | null => {
  const formMap: Record<string, any[]> = {
    "Upload Driver License": DRIVER_LICENSE_FORM,
    "Driver License Upload": DRIVER_LICENSE_FORM,
    "Provide Proof of Insurance": INSURANCE_FORM,
    "Insurance Certificate": INSURANCE_FORM,
    "Upload Vehicle Registration": VEHICLE_REGISTRATION_FORM,
    "Vehicle Registration": VEHICLE_REGISTRATION_FORM,
    "Complete Background Check": BACKGROUND_CHECK_FORM,
    "Background Check Consent": BACKGROUND_CHECK_FORM,
    "Set Up Bank Account": BANK_ACCOUNT_FORM,
    "Bank Account Setup": BANK_ACCOUNT_FORM,
    "Add Emergency Contact": EMERGENCY_CONTACT_FORM,
    "Emergency Contact Information": EMERGENCY_CONTACT_FORM,
    "Complete Safety Training": SAFETY_TRAINING_FORM,
    "Safety Training": SAFETY_TRAINING_FORM,
    "Verify Carrier Authority": CARRIER_AUTHORITY_FORM,
    "MC Authority Verification": CARRIER_AUTHORITY_FORM,
    "Sign Shipper Agreement": SHIPPER_AGREEMENT_FORM,
    "Shipper Service Agreement": SHIPPER_AGREEMENT_FORM,
    "Upload Business License": BUSINESS_LICENSE_FORM,
    "Business License Verification": BUSINESS_LICENSE_FORM,
    "Vehicle Inspection Certificate": VEHICLE_INSPECTION_FORM,
    "Upload Inspection Report": VEHICLE_INSPECTION_FORM,
    "Review Platform Guidelines": REVIEW_PLATFORM_GUIDELINES_FORM,
    "Platform Guidelines Review": REVIEW_PLATFORM_GUIDELINES_FORM,
    "Add Payment Method": PAYMENT_METHOD_FORM,
    "Payment Method Setup": PAYMENT_METHOD_FORM,
    "Complete Profile Information": PROFILE_COMPLETION_FORM,
    "Profile Completion": PROFILE_COMPLETION_FORM,
  };
  
  return formMap[taskName] || null;
};

// Export all schemas
export const TASK_FORM_SCHEMAS = {
  DRIVER_LICENSE_FORM,
  INSURANCE_FORM,
  VEHICLE_REGISTRATION_FORM,
  BACKGROUND_CHECK_FORM,
  BANK_ACCOUNT_FORM,
  PAYMENT_METHOD_FORM,
  EMERGENCY_CONTACT_FORM,
  SAFETY_TRAINING_FORM,
  CARRIER_AUTHORITY_FORM,
  SHIPPER_AGREEMENT_FORM,
  BUSINESS_LICENSE_FORM,
  VEHICLE_INSPECTION_FORM,
  REVIEW_PLATFORM_GUIDELINES_FORM,
  PROFILE_COMPLETION_FORM,
};
