import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "./integrations/supabase/client";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BrowserRouter, Routes, Route, useNavigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ForcePasswordChangeModal } from "@/components/ForcePasswordChangeModal";
import { PlatformSettingsProvider } from "@/contexts/PlatformSettingsContext";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Auth from "./pages/Auth";
import NotFound from "./pages/NotFound";
import AdminDashboard from "./pages/AdminDashboard";
import VendorDashboard from "./pages/VendorDashboard";
import CarrierDashboard from "./pages/CarrierDashboard";
import BrokerDashboard from "./pages/BrokerDashboard";
import Fleet from "./pages/Fleet";
import Settings from "./pages/Settings";
import Jobs from "./pages/Jobs";
import LiveView from "./pages/LiveView";
import OnboardingPage from "./pages/onboarding/OnboardingPage";
import StatusAndTasksPage from "./pages/StatusAndTasksPage";
import DashboardRedirect from "./pages/DashboardRedirect";
import W9Form from "./pages/W9Form";
import TaskWorkspace from "./pages/TaskWorkspace";
import TaskFormPage from "./pages/TaskFormPage";
import Support from "./pages/Support";
import Notifications from "./pages/Notifications";
import NotificationCenter from "./pages/NotificationCenter";
import SMSTest from "./pages/SMSTest";
import { UnifiedDashboard } from "./pages/UnifiedDashboard";
import ShipperDashboard from "./pages/ShipperDashboard";
import DocumentationViewer from "./pages/DocumentationViewer";
import Showcase from "./pages/Showcase";
import { GlobalCustomizationWrapper } from "./components/GlobalCustomizationWrapper";
import { RoutePersistence } from "./components/RoutePersistence";
import { PlatformEventsProvider } from "./contexts/PlatformEventsContext";
import { PlatformEventsHandler } from "./components/PlatformEventsHandler";
import { NotificationProvider } from "./components/notifications/NotificationProvider";

// Removed fetchProfiles function for security -
// profiles are no longer publicly accessible

// Removed ProfilesList component for security - 
// public profiles list was a privacy violation

function PasswordChangeGuard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [showPasswordChangeModal, setShowPasswordChangeModal] = useState(false);

  useEffect(() => {
    const forcePasswordChange = user?.user_metadata?.force_password_change;
    if (forcePasswordChange === true || forcePasswordChange === 'true') {
      setShowPasswordChangeModal(true);
    } else {
      setShowPasswordChangeModal(false);
    }
  }, [user]);

  return (
    <ForcePasswordChangeModal 
      open={showPasswordChangeModal}
      onPasswordChanged={() => {
        setShowPasswordChangeModal(false);
        navigate('/auth');
      }}
    />
  );
}

const App = () => {
  return (
    <BrowserRouter>
      <PlatformEventsProvider>
        <AuthProvider>
          <NotificationProvider>
            <PlatformSettingsProvider>
              <GlobalCustomizationWrapper>
                <TooltipProvider>
                  <Toaster />
                  <SonnerToaster />
                  <PlatformEventsHandler />
                  <RoutePersistence />
                  <PasswordChangeGuard />
                  <Routes>
                    <Route path="/" element={<Auth />} />
                    <Route path="/auth" element={<Auth />} />
                    
                    {/* Unified RBAC Dashboard - All roles use this */}
                    <Route path="/dashboard/*" element={<UnifiedDashboard />} />
                    
                    {/* Legacy routes redirect to unified dashboard */}
                    <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
                    
                    {/* Protected Admin Dashboard - Separate UI */}
                    <Route path="/admin-dashboard/*" element={
                      <ProtectedRoute requireAdmin={true}>
                        <AdminDashboard />
                      </ProtectedRoute>
                    } />
                    
                    {/* All role-specific dashboards now use UnifiedDashboard with wildcard routing */}
                    <Route path="/driver-dashboard/*" element={<UnifiedDashboard />} />
                    <Route path="/shipper-dashboard/*" element={<ShipperDashboard />} />
                    
                    {/* Broker, Vendor and Carrier use standalone dashboards */}
                    <Route path="/broker-dashboard" element={<BrokerDashboard />} />
                    <Route path="/vendor-dashboard/*" element={<VendorDashboard />} />
                    <Route path="/vendor-merchant-dashboard/*" element={<VendorDashboard />} />
                    <Route path="/carrier-dashboard/*" element={<CarrierDashboard />} />
                    
                    {/* Onboarding and Task Routes */}
                    <Route path="/onboarding" element={<OnboardingPage />} />
                    <Route path="/status-and-tasks" element={<StatusAndTasksPage />} />
                    <Route path="/tasks" element={<StatusAndTasksPage />} />
                    <Route path="/pending-approval" element={<StatusAndTasksPage />} />
                    <Route path="/w9-form" element={<W9Form />} />
                    <Route path="/task-workspace" element={<TaskWorkspace />} />
                    <Route path="/task-form" element={<ProtectedRoute><TaskFormPage /></ProtectedRoute>} />
                    
                    {/* Support and Notifications */}
                    <Route path="/support" element={<ProtectedRoute><Support /></ProtectedRoute>} />
                    <Route path="/notifications" element={<ProtectedRoute><NotificationCenter /></ProtectedRoute>} />
                    <Route path="/notifications-old" element={<ProtectedRoute><Notifications /></ProtectedRoute>} />
                    
                    {/* Live View Map */}
                    <Route path="/live-view" element={<ProtectedRoute><LiveView /></ProtectedRoute>} />
                    
                    {/* SMS Testing */}
                    <Route path="/sms-test" element={<ProtectedRoute><SMSTest /></ProtectedRoute>} />
                    
                    {/* Documentation Viewer */}
                    <Route path="/documentation" element={<DocumentationViewer />} />
                    
                    {/* Showcase & Demo */}
                    <Route path="/showcase" element={<Showcase />} />
                    
                    {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
                    <Route path="*" element={<NotFound />} />
                  </Routes>
                </TooltipProvider>
              </GlobalCustomizationWrapper>
            </PlatformSettingsProvider>
          </NotificationProvider>
        </AuthProvider>
      </PlatformEventsProvider>
    </BrowserRouter>
  );
};

export default App;
