import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useTwilioSMS } from '@/hooks/useTwilioSMS';
import { 
  generateVerificationCode, 
  formatPhoneNumber, 
  isValidPhoneNumber,
  storeVerificationCode,
  verifyStoredCode 
} from '@/lib/smsUtils';
import { toast } from 'sonner';

interface PhoneVerificationProps {
  onVerified?: (phoneNumber: string) => void;
  title?: string;
  description?: string;
}

export function PhoneVerification({ 
  onVerified, 
  title = "Phone Verification",
  description = "Enter your phone number to receive a verification code"
}: PhoneVerificationProps) {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [sentCode, setSentCode] = useState<string | null>(null);
  const [step, setStep] = useState<'phone' | 'code'>('phone');
  
  const { sendVerificationCode, sending } = useTwilioSMS();

  const handleSendCode = async () => {
    if (!phoneNumber) {
      toast.error('Please enter a phone number');
      return;
    }

    if (!isValidPhoneNumber(phoneNumber)) {
      toast.error('Please enter a valid phone number');
      return;
    }

    // Generate and store verification code
    const code = generateVerificationCode(6);
    const formattedPhone = formatPhoneNumber(phoneNumber);
    
    storeVerificationCode(formattedPhone, code, 10); // 10 minutes expiration
    setSentCode(code);

    // Send SMS
    const result = await sendVerificationCode(formattedPhone, code);
    
    if (result.success) {
      setStep('code');
      toast.success('Verification code sent!');
    }
  };

  const handleVerifyCode = () => {
    if (!verificationCode) {
      toast.error('Please enter the verification code');
      return;
    }

    const formattedPhone = formatPhoneNumber(phoneNumber);
    const isValid = verifyStoredCode(formattedPhone, verificationCode);

    if (isValid) {
      toast.success('Phone number verified successfully!');
      onVerified?.(formattedPhone);
    } else {
      toast.error('Invalid or expired verification code');
    }
  };

  const handleResendCode = async () => {
    setSentCode(null);
    setVerificationCode('');
    await handleSendCode();
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>{title}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {step === 'phone' ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                disabled={sending}
              />
              <p className="text-sm text-muted-foreground">
                Enter your phone number with country code (e.g., +1 for US)
              </p>
            </div>
            <Button 
              onClick={handleSendCode} 
              className="w-full"
              disabled={sending || !phoneNumber}
            >
              {sending ? 'Sending...' : 'Send Verification Code'}
            </Button>
          </>
        ) : (
          <>
            <div className="space-y-2">
              <Label htmlFor="code">Verification Code</Label>
              <Input
                id="code"
                type="text"
                placeholder="Enter 6-digit code"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                maxLength={6}
              />
              <p className="text-sm text-muted-foreground">
                A verification code was sent to {phoneNumber}
              </p>
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleVerifyCode} 
                className="flex-1"
                disabled={!verificationCode || verificationCode.length !== 6}
              >
                Verify Code
              </Button>
              <Button 
                onClick={handleResendCode}
                variant="outline"
                disabled={sending}
              >
                {sending ? 'Sending...' : 'Resend'}
              </Button>
            </div>
            <Button 
              onClick={() => {
                setStep('phone');
                setVerificationCode('');
                setSentCode(null);
              }}
              variant="ghost"
              className="w-full"
            >
              Change Phone Number
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
