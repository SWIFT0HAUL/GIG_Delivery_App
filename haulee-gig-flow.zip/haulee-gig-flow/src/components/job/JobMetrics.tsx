import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, TrendingDown, DollarSign, Clock, Users, Package,
  Target, BarChart3, PieChart, Calendar, Download, AlertTriangle,
  CheckCircle, XCircle, Activity
} from 'lucide-react';

const JobMetrics = () => {
  const [timeRange, setTimeRange] = useState('7d');
  const [metricType, setMetricType] = useState('overview');

  // Mock KPI data
  const kpis = [
    {
      title: 'Total Revenue',
      value: '$124,850',
      change: '+15.3%',
      trend: 'up',
      icon: DollarSign,
      color: 'bg-green-500'
    },
    {
      title: 'Completion Rate',
      value: '94.2%',
      change: '+2.1%',
      trend: 'up',
      icon: CheckCircle,
      color: 'bg-blue-500'
    },
    {
      title: 'Average Time',
      value: '4.2h',
      change: '-8.5%',
      trend: 'down',
      icon: Clock,
      color: 'bg-purple-500'
    },
    {
      title: 'My Jobs',
      value: '856',
      change: '+12.7%',
      trend: 'up',
      icon: Package,
      color: 'bg-orange-500'
    }
  ];

  // Mock performance data
  const performanceMetrics = [
    { category: 'On-Time Delivery', value: 89, target: 95, status: 'warning' },
    { category: 'Customer Satisfaction', value: 94, target: 90, status: 'success' },
    { category: 'Cost Efficiency', value: 87, target: 85, status: 'success' },
    { category: 'Resource Utilization', value: 76, target: 80, status: 'warning' },
    { category: 'Quality Score', value: 92, target: 90, status: 'success' }
  ];

  // Mock team performance data
  const teamPerformance = [
    { name: 'Mike Driver', role: 'Driver', completedJobs: 24, rating: 4.8, efficiency: 95 },
    { name: 'Lisa Carrier', role: 'Carrier', completedJobs: 31, rating: 4.9, efficiency: 92 },
    { name: 'David Vendor', role: 'Vendor/Merchant', completedJobs: 18, rating: 4.7, efficiency: 88 },
    { name: 'Steve Driver', role: 'Driver', completedJobs: 22, rating: 4.6, efficiency: 90 },
    { name: 'Carol Carrier', role: 'Carrier', completedJobs: 28, rating: 4.8, efficiency: 94 }
  ];

  // Mock operational metrics
  const operationalData = [
    { metric: 'Average Response Time', value: '12 min', change: '-15%', status: 'improved' },
    { metric: 'Fleet Utilization', value: '78%', change: '+5%', status: 'improved' },
    { metric: 'Fuel Efficiency', value: '24.5 MPG', change: '+8%', status: 'improved' },
    { metric: 'Incident Rate', value: '0.3%', change: '-12%', status: 'improved' },
    { metric: 'Overtime Hours', value: '156h', change: '+3%', status: 'declined' }
  ];

  // Mock financial breakdown
  const financialData = [
    { category: 'Delivery Services', amount: 45600, percentage: 36.5 },
    { category: 'Transportation', amount: 32400, percentage: 26.0 },
    { category: 'Logistics', amount: 28800, percentage: 23.0 },
    { category: 'Warehousing', amount: 18050, percentage: 14.5 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-600';
      case 'warning': return 'text-yellow-600';
      case 'danger': return 'text-red-600';
      case 'improved': return 'text-green-600';
      case 'declined': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
      case 'improved':
        return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'danger':
      case 'declined':
        return <TrendingDown className="h-4 w-4 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default:
        return <Activity className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Controls */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Job Performance KPIs & Metrics
            </CardTitle>
            <div className="flex space-x-4">
              <Select value={timeRange} onValueChange={setTimeRange}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1d">Last 24h</SelectItem>
                  <SelectItem value="7d">Last 7 days</SelectItem>
                  <SelectItem value="30d">Last 30 days</SelectItem>
                  <SelectItem value="90d">Last 90 days</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export Report
              </Button>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Main KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpis.map((kpi, index) => (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{kpi.title}</p>
                  <p className="text-2xl font-bold">{kpi.value}</p>
                  <div className="flex items-center mt-1">
                    {kpi.trend === 'up' ? (
                      <TrendingUp className="h-4 w-4 text-green-600 mr-1" />
                    ) : (
                      <TrendingDown className="h-4 w-4 text-red-600 mr-1" />
                    )}
                    <span className={`text-sm ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                      {kpi.change}
                    </span>
                  </div>
                </div>
                <div className={`p-3 rounded-full ${kpi.color}/10`}>
                  <kpi.icon className={`h-6 w-6 ${kpi.color.replace('bg-', 'text-')}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed Metrics Tabs */}
      <Tabs defaultValue="performance" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="team">Team Analytics</TabsTrigger>
          <TabsTrigger value="operations">Operations</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
        </TabsList>

        {/* Performance Metrics */}
        <TabsContent value="performance">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Performance vs Targets
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {performanceMetrics.map((metric, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">{metric.category}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-sm">{metric.value}%</span>
                        {getStatusIcon(metric.status)}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <Progress value={metric.value} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Target: {metric.target}%</span>
                        <span className={getStatusColor(metric.status)}>
                          {metric.value >= metric.target ? 'Above Target' : 'Below Target'}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Job Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Completed</span>
                      <span className="text-sm font-medium">421 jobs (33.8%)</span>
                    </div>
                    <Progress value={33.8} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">In Progress</span>
                      <span className="text-sm font-medium">856 jobs (68.7%)</span>
                    </div>
                    <Progress value={68.7} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Pending</span>
                      <span className="text-sm font-medium">231 jobs (18.5%)</span>
                    </div>
                    <Progress value={18.5} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Overdue</span>
                      <span className="text-sm font-medium">23 jobs (1.8%)</span>
                    </div>
                    <Progress value={1.8} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Team Analytics */}
        <TabsContent value="team">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Team Performance Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {teamPerformance.map((member, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                        <span className="text-sm font-medium">{index + 1}</span>
                      </div>
                      <div>
                        <h4 className="font-medium">{member.name}</h4>
                        <p className="text-sm text-muted-foreground">{member.role}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-6 text-sm">
                      <div className="text-center">
                        <p className="font-medium">{member.completedJobs}</p>
                        <p className="text-muted-foreground">Jobs</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{member.rating}/5.0</p>
                        <p className="text-muted-foreground">Rating</p>
                      </div>
                      <div className="text-center">
                        <p className="font-medium">{member.efficiency}%</p>
                        <p className="text-muted-foreground">Efficiency</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Operations */}
        <TabsContent value="operations">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {operationalData.map((item, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-muted-foreground">{item.metric}</p>
                      <p className="text-2xl font-bold">{item.value}</p>
                      <div className="flex items-center mt-1">
                        {getStatusIcon(item.status)}
                        <span className={`text-sm ml-1 ${getStatusColor(item.status)}`}>
                          {item.change}
                        </span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Financial */}
        <TabsContent value="financial">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <PieChart className="h-5 w-5" />
                  Revenue Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {financialData.map((item, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">{item.category}</span>
                      <span className="text-sm font-medium">${item.amount.toLocaleString()}</span>
                    </div>
                    <Progress value={item.percentage} className="h-2" />
                    <div className="text-xs text-muted-foreground text-right">
                      {item.percentage}% of total revenue
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Monthly Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">$124,850</div>
                    <p className="text-sm text-muted-foreground">Current Month Revenue</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="text-center">
                      <div className="font-medium">$108,450</div>
                      <p className="text-muted-foreground">Previous Month</p>
                    </div>
                    <div className="text-center">
                      <div className="font-medium text-green-600">+15.1%</div>
                      <p className="text-muted-foreground">Growth</p>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs">
                      <span>Monthly Target: $120,000</span>
                      <span className="text-green-600">104% achieved</span>
                    </div>
                    <Progress value={104} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default JobMetrics;