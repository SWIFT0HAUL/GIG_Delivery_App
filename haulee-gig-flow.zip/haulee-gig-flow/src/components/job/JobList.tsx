import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from '@/components/ui/dropdown-menu';
import { JobStatusIndicator, PriorityIndicator } from './JobStatusIndicator';
import { useToast } from '@/hooks/use-toast';
import { 
  MoreHorizontal, Eye, Edit, UserCheck, Ban, Bell, ArrowUpDown,
  Download, FileText, Search, MessageCircle, MapPin, Calendar,
  Activity, RefreshCw
} from 'lucide-react';

interface JobListProps {
  userRole: string;
  filters?: {
    search: string;
    status: string;
    jobType: string;
    assignedUser: string;
    dateRange?: Date;
  };
}

const JobList: React.FC<JobListProps> = ({ userRole, filters }) => {
  const { toast } = useToast();
  const [selectedJobs, setSelectedJobs] = useState<string[]>([]);
  const [sortField, setSortField] = useState<string>('');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Mock job data with enhanced fields
  const jobsData = [
    {
      jobID: 'JOB-001',
      type: 'Delivery',
      status: 'In Progress',
      creator: 'John Admin',
      assignedTo: 'Mike Driver',
      deadline: '2024-01-20',
      client: 'Tech Corp',
      priority: 'High',
      value: '$2,500',
      location: 'Downtown District',
      estimatedCompletion: '2024-01-20 18:00',
      progress: 65,
      lastUpdate: '2 hours ago'
    },
    {
      jobID: 'JOB-002',
      type: 'Pickup',
      status: 'Pending',
      creator: 'Sarah Broker',
      assignedTo: 'Lisa Carrier',
      deadline: '2024-01-22',
      client: 'ABC Logistics',
      priority: 'Medium',
      value: '$1,800',
      location: 'Industrial Zone',
      estimatedCompletion: '2024-01-22 14:00',
      progress: 0,
      lastUpdate: '5 minutes ago'
    },
    {
      jobID: 'JOB-003',
      type: 'Transport',
      status: 'Completed',
      creator: 'Tom Manager',
      assignedTo: 'David Vendor',
      deadline: '2024-01-18',
      client: 'Global Shipping',
      priority: 'Low',
      value: '$3,200',
      location: 'Cross State Route',
      estimatedCompletion: '2024-01-18 16:00',
      progress: 100,
      lastUpdate: '1 day ago'
    },
    {
      jobID: 'JOB-004',
      type: 'Logistics',
      status: 'In Progress',
      creator: 'Amy Admin',
      assignedTo: 'Steve Driver',
      deadline: '2024-01-25',
      client: 'Fast Freight',
      priority: 'High',
      value: '$4,100',
      location: 'North District',
      estimatedCompletion: '2024-01-25 12:00',
      progress: 30,
      lastUpdate: '30 minutes ago'
    },
    {
      jobID: 'JOB-005',
      type: 'Delivery',
      status: 'Overdue',
      creator: 'Bob Broker',
      assignedTo: 'Carol Carrier',
      deadline: '2024-01-15',
      client: 'Quick Move',
      priority: 'Critical',
      value: '$2,900',
      location: 'South District',
      estimatedCompletion: 'Overdue',
      progress: 85,
      lastUpdate: '3 days ago'
    }
  ];

  // Helper function to get semantic status colors
  const getJobStatusStyles = (status: string) => {
    const statusMap = {
      'In Progress': 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300',
      'Pending': 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
      'Completed': 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
      'Overdue': 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300',
      'Cancelled': 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-950 dark:text-gray-300',
    };
    return statusMap[status as keyof typeof statusMap] || 'bg-muted text-muted-foreground border-border';
  };

  const getPriorityStyles = (priority: string) => {
    const priorityMap = {
      'Critical': 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300',
      'High': 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950 dark:text-orange-300',
      'Medium': 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
      'Low': 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
    };
    return priorityMap[priority as keyof typeof priorityMap] || 'bg-muted text-muted-foreground border-border';
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedJobs(jobsData.map(job => job.jobID));
    } else {
      setSelectedJobs([]);
    }
  };

  const handleSelectJob = (jobId: string, checked: boolean) => {
    if (checked) {
      setSelectedJobs([...selectedJobs, jobId]);
    } else {
      setSelectedJobs(selectedJobs.filter(id => id !== jobId));
    }
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
    
    toast({
      title: "Table Sorted",
      description: `Sorted by ${field} in ${sortDirection === 'asc' ? 'descending' : 'ascending'} order.`,
    });
  };

  const handleJobAction = async (action: string, jobId: string) => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const actions = {
      'view': 'Job details viewed',
      'edit': 'Job opened for editing',
      'reassign': 'Job reassignment initiated',
      'cancel': 'Job cancelled successfully',
      'message': 'Message sent to assignee',
      'notify': 'Notification sent'
    };

    toast({
      title: "Action Completed",
      description: actions[action as keyof typeof actions] || 'Action completed successfully',
    });
    
    setIsLoading(false);
  };

  // Get permissions based on user role
  const getPermissions = (role: string) => {
    const rolePermissions = {
      Admin: ['view', 'edit', 'assign', 'cancel'],
      Broker: ['view', 'edit', 'assign', 'cancel'],
      Vendor: ['view', 'editStatus', 'addNotes'],
      Shipper: ['view', 'addNotes'],
      Carrier: ['view', 'editStatus', 'addNotes', 'updateETA'],
      Driver: ['view', 'editStatus', 'addNotes', 'updateETA']
    };
    return rolePermissions[role as keyof typeof rolePermissions] || ['view'];
  };

  const permissions = getPermissions(userRole);
  const canEdit = permissions.includes('edit');
  const canAssign = permissions.includes('assign');
  const canCancel = permissions.includes('cancel');

  return (
    <div className="space-y-6">
      {/* Job List Table */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Job List</CardTitle>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export CSV
              </Button>
              <Button variant="outline" size="sm">
                <FileText className="h-4 w-4 mr-2" />
                Export PDF
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Table */}
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedJobs.length === jobsData.length}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort('jobID')}>
                    <div className="flex items-center space-x-1">
                      <span>Job ID</span>
                      <ArrowUpDown className="h-4 w-4" />
                    </div>
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort('type')}>
                    <div className="flex items-center space-x-1">
                      <span>Type</span>
                      <ArrowUpDown className="h-4 w-4" />
                    </div>
                  </TableHead>
                  <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort('status')}>
                    <div className="flex items-center space-x-1">
                      <span>Status</span>
                      <ArrowUpDown className="h-4 w-4" />
                    </div>
                  </TableHead>
                  <TableHead>Creator</TableHead>
                  <TableHead>Assigned To</TableHead>
                  <TableHead className="cursor-pointer hover:bg-muted/50" onClick={() => handleSort('deadline')}>
                    <div className="flex items-center space-x-1">
                      <span>Deadline</span>
                      <ArrowUpDown className="h-4 w-4" />
                    </div>
                  </TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {jobsData.map((job) => (
                  <TableRow key={job.jobID}>
                    <TableCell>
                      <Checkbox
                        checked={selectedJobs.includes(job.jobID)}
                        onCheckedChange={(checked) => handleSelectJob(job.jobID, checked as boolean)}
                      />
                    </TableCell>
                    <TableCell className="font-medium">{job.jobID}</TableCell>
                    <TableCell>{job.type}</TableCell>
                    <TableCell>
                      <JobStatusIndicator status={job.status} size="sm" />
                    </TableCell>
                    <TableCell>{job.creator}</TableCell>
                    <TableCell>{job.assignedTo}</TableCell>
                    <TableCell>{job.deadline}</TableCell>
                    <TableCell>{job.client}</TableCell>
                    <TableCell>
                      <PriorityIndicator priority={job.priority} size="sm" />
                    </TableCell>
                    <TableCell className="font-medium">{job.value}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" className="h-8 w-8 p-0">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-56">
                          <DropdownMenuItem onClick={() => handleJobAction('view', job.jobID)}>
                            <Eye className="mr-2 h-4 w-4" />
                            View Job Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleJobAction('map', job.jobID)}>
                            <MapPin className="mr-2 h-4 w-4" />
                            View on Map
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleJobAction('timeline', job.jobID)}>
                            <Activity className="mr-2 h-4 w-4" />
                            View Timeline
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {canEdit && (
                            <DropdownMenuItem onClick={() => handleJobAction('edit', job.jobID)}>
                              <Edit className="mr-2 h-4 w-4" />
                              Edit Job Details
                            </DropdownMenuItem>
                          )}
                          {canAssign && (
                            <DropdownMenuItem onClick={() => handleJobAction('reassign', job.jobID)}>
                              <UserCheck className="mr-2 h-4 w-4" />
                              Reassign Job
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem onClick={() => handleJobAction('message', job.jobID)}>
                            <MessageCircle className="mr-2 h-4 w-4" />
                            Send Message
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleJobAction('notify', job.jobID)}>
                            <Bell className="mr-2 h-4 w-4" />
                            Send Notification
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          {canCancel && (
                            <DropdownMenuItem 
                              className="text-destructive"
                              onClick={() => handleJobAction('cancel', job.jobID)}
                            >
                              <Ban className="mr-2 h-4 w-4" />
                              Cancel Job
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Batch Actions */}
      {selectedJobs.length > 0 && (
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <span className="text-sm font-medium">
                  {selectedJobs.length} job(s) selected
                </span>
                {selectedJobs.length > 0 && (
                  <Badge variant="secondary" className="text-xs">
                    Ready for batch operations
                  </Badge>
                )}
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant="outline" disabled={selectedJobs.length === 0}>
                  <Activity className="h-4 w-4 mr-2" />
                  Update Status
                </Button>
                {canAssign && (
                  <Button size="sm" variant="outline" disabled={selectedJobs.length === 0}>
                    <UserCheck className="h-4 w-4 mr-2" />
                    Reassign Jobs
                  </Button>
                )}
                <Button size="sm" variant="outline" disabled={selectedJobs.length === 0}>
                  <Bell className="h-4 w-4 mr-2" />
                  Send Notification
                </Button>
                <Button size="sm" variant="outline" disabled={selectedJobs.length === 0}>
                  <Download className="h-4 w-4 mr-2" />
                  Export Selected
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default JobList;