import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { JobStatusIndicator, PriorityIndicator } from './JobStatusIndicator';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Package, Clock, CheckCircle, AlertTriangle, Users, TrendingUp, 
  DollarSign, MapPin, Calendar, Eye, ArrowRight, Truck, Navigation,
  Phone, MessageSquare, Edit, Image as ImageIcon, MapPinned
} from 'lucide-react';

interface JobOverviewProps {
  filters?: {
    search: string;
    status: string;
    jobType: string;
    assignedUser: string;
    dateRange?: Date;
  };
}

const JobOverview: React.FC<JobOverviewProps> = ({ filters }) => {
  const { toast } = useToast();
  const [activeRoutes, setActiveRoutes] = useState<any[]>([]);
  const [loadingRoutes, setLoadingRoutes] = useState(true);

  // Fetch active routes (jobs in progress or assigned)
  useEffect(() => {
    fetchActiveRoutes();

    // Real-time subscription for job updates
    const channel = supabase
      .channel('route-monitoring')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'jobs',
          filter: 'status=in.("in_progress","assigned")'
        },
        () => {
          fetchActiveRoutes();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'job_assignments'
        },
        () => {
          fetchActiveRoutes();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchActiveRoutes = async () => {
    try {
      const { data: jobs, error } = await supabase
        .from('jobs')
        .select(`
          *,
          job_assignments (
            *,
            driver:profiles!job_assignments_driver_id_fkey (
              id,
              full_name,
              phone
            )
          )
        `)
        .in('status', ['in_progress', 'assigned'])
        .order('pickup_time', { ascending: true });

      if (error) throw error;

      setActiveRoutes(jobs || []);
    } catch (error) {
      console.error('Error fetching active routes:', error);
    } finally {
      setLoadingRoutes(false);
    }
  };

  const handleManualStopUpdate = async (jobId: string, newStatus: string) => {
    try {
      const { error } = await supabase
        .from('jobs')
        .update({ status: newStatus, updated_at: new Date().toISOString() })
        .eq('id', jobId);

      if (error) throw error;

      toast({
        title: 'Stop Updated',
        description: 'Job status has been updated successfully.',
      });
      fetchActiveRoutes();
    } catch (error) {
      toast({
        title: 'Update Failed',
        description: 'Failed to update job status.',
        variant: 'destructive',
      });
    }
  };

  const kpiData = [
    {
      title: 'Total Jobs',
      value: '1,247',
      change: '+12%',
      trend: 'up',
      icon: Package,
      color: 'bg-blue-500'
    },
    {
      title: 'My Jobs',
      value: '856',
      change: '+8%',
      trend: 'up',
      icon: Clock,
      color: 'bg-orange-500'
    },
    {
      title: 'Completed Jobs',
      value: '421',
      change: '+15%',
      trend: 'up',
      icon: CheckCircle,
      color: 'bg-green-500'
    },
    {
      title: 'Overdue Jobs',
      value: '23',
      change: '-5%',
      trend: 'down',
      icon: AlertTriangle,
      color: 'bg-red-500'
    }
  ];

  const recentJobs = [
    { id: 'JOB-001', type: 'Delivery', client: 'Tech Corp', status: 'In Progress', priority: 'High' },
    { id: 'JOB-002', type: 'Pickup', client: 'ABC Logistics', status: 'Pending', priority: 'Medium' },
    { id: 'JOB-003', type: 'Transport', client: 'Global Shipping', status: 'Completed', priority: 'Low' },
    { id: 'JOB-004', type: 'Logistics', client: 'Fast Freight', status: 'In Progress', priority: 'High' },
    { id: 'JOB-005', type: 'Delivery', client: 'Quick Move', status: 'Pending', priority: 'Medium' }
  ];

  // Helper function to get semantic status colors
  const getJobStatusStyles = (status: string) => {
    const statusMap = {
      'In Progress': 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300',
      'Pending': 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
      'Completed': 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
      'Overdue': 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300',
      'Cancelled': 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-950 dark:text-gray-300',
    };
    return statusMap[status as keyof typeof statusMap] || 'bg-muted text-muted-foreground border-border';
  };

  const getPriorityStyles = (priority: string) => {
    const priorityMap = {
      'Critical': 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300',
      'High': 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950 dark:text-orange-300',
      'Medium': 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
      'Low': 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
    };
    return priorityMap[priority as keyof typeof priorityMap] || 'bg-muted text-muted-foreground border-border';
  };

  return (
    <div className="space-y-6">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => (
          <Card key={index} className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{kpi.title}</p>
                  <p className="text-2xl font-bold text-foreground">{kpi.value}</p>
                  <p className={`text-sm ${kpi.trend === 'up' ? 'text-green-600' : 'text-red-600'}`}>
                    {kpi.change} from last month
                  </p>
                </div>
                <div className={`p-3 rounded-full ${kpi.color}/10`}>
                  <kpi.icon className={`h-6 w-6 ${kpi.color.replace('bg-', 'text-')}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Quick Stats and Recent Jobs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Job Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Job Status Distribution
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">In Progress</span>
                <span className="text-sm text-muted-foreground">68.7%</span>
              </div>
              <Progress value={68.7} className="h-2" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Pending</span>
                <span className="text-sm text-muted-foreground">18.5%</span>
              </div>
              <Progress value={18.5} className="h-2" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Completed</span>
                <span className="text-sm text-muted-foreground">33.8%</span>
              </div>
              <Progress value={33.8} className="h-2" />
            </div>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm font-medium">Overdue</span>
                <span className="text-sm text-muted-foreground">1.8%</span>
              </div>
              <Progress value={1.8} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {/* Recent Jobs */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Recent Jobs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentJobs.map((job) => (
                <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer group">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full" />
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">{job.id}</p>
                        <Badge variant="secondary" className="text-xs">{job.type}</Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{job.client}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <PriorityIndicator priority={job.priority} size="sm" />
                    <JobStatusIndicator status={job.status} size="sm" />
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
              <div className="pt-2 border-t">
                <Button variant="outline" size="sm" className="w-full">
                  <ArrowRight className="h-4 w-4 mr-2" />
                  View All Jobs
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Revenue Impact
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$124,850</div>
            <p className="text-xs text-muted-foreground">Total revenue from active jobs</p>
            <div className="mt-2">
              <Progress value={75} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">75% of monthly target</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Team Utilization
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89%</div>
            <p className="text-xs text-muted-foreground">Average team utilization</p>
            <div className="mt-2">
              <Progress value={89} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">12 active team members</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Geographic Coverage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">15</div>
            <p className="text-xs text-muted-foreground">Active service areas</p>
            <div className="mt-2">
              <Progress value={60} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">60% coverage expansion</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Routes Monitoring Section */}
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Truck className="h-5 w-5" />
              <CardTitle>Active Routes Monitoring</CardTitle>
            </div>
            <Badge variant="secondary">
              {activeRoutes.length} Active Route{activeRoutes.length !== 1 ? 's' : ''}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {loadingRoutes ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="border rounded-lg p-4 animate-pulse">
                  <div className="h-6 bg-muted rounded w-1/3 mb-3" />
                  <div className="h-4 bg-muted rounded w-2/3" />
                </div>
              ))}
            </div>
          ) : activeRoutes.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <Truck className="h-12 w-12 mx-auto mb-4 opacity-20" />
              <p className="text-lg font-medium">No Active Routes</p>
              <p className="text-sm">All deliveries are completed or no routes are in progress</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeRoutes.map((job) => {
                const assignment = job.job_assignments?.[0];
                const driver = assignment?.driver;
                const pickupComplete = ['picked_up', 'delivered', 'completed'].includes(job.status);
                const deliveryComplete = ['delivered', 'completed'].includes(job.status);
                
                return (
                  <Card key={job.id} className="border-l-4 border-l-blue-500">
                    <CardContent className="p-4">
                      {/* Header */}
                      <div className="flex items-start justify-between mb-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold text-lg">{job.title}</h4>
                            <JobStatusIndicator status={job.status} size="sm" />
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            {driver ? (
                              <>
                                <Users className="h-4 w-4" />
                                <span>{driver.full_name}</span>
                                <span>•</span>
                                <Phone className="h-4 w-4" />
                                <span>{driver.phone || 'N/A'}</span>
                              </>
                            ) : (
                              <span className="text-orange-500">No driver assigned</span>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="sm" variant="outline" onClick={() => window.open(`tel:${driver?.phone}`, '_self')}>
                            <Phone className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <MapPinned className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      {/* Progress Bar */}
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2 text-sm">
                          <span className="font-medium">Route Progress</span>
                          <span className="text-muted-foreground">
                            {deliveryComplete ? '2' : pickupComplete ? '1' : '0'} of 2 stops completed
                          </span>
                        </div>
                        <Progress 
                          value={deliveryComplete ? 100 : pickupComplete ? 50 : 0} 
                          className="h-2"
                        />
                      </div>

                      {/* Stops */}
                      <div className="space-y-3">
                        {/* Pickup Stop */}
                        <div className={`flex items-start gap-3 p-3 rounded-lg border ${
                          pickupComplete ? 'bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800' : 'bg-muted/50'
                        }`}>
                          <div className="mt-1">
                            {pickupComplete ? (
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            ) : (
                              <div className="h-5 w-5 rounded-full border-2 border-muted-foreground" />
                            )}
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">Pickup</p>
                                <p className="text-sm text-muted-foreground">
                                  {job.pickup_location?.address || 'N/A'}
                                </p>
                                {assignment?.pickup_photo_url && (
                                  <div className="mt-2">
                                    <Button size="sm" variant="outline" className="gap-2">
                                      <ImageIcon className="h-3 w-3" />
                                      View Photo
                                    </Button>
                                  </div>
                                )}
                              </div>
                              {!pickupComplete && (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleManualStopUpdate(job.id, 'picked_up')}
                                >
                                  <Edit className="h-3 w-3 mr-1" />
                                  Mark Complete
                                </Button>
                              )}
                            </div>
                            {pickupComplete && assignment?.started_at && (
                              <p className="text-xs text-muted-foreground">
                                Completed: {new Date(assignment.started_at).toLocaleString()}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Delivery Stop */}
                        <div className={`flex items-start gap-3 p-3 rounded-lg border ${
                          deliveryComplete ? 'bg-green-50 border-green-200 dark:bg-green-950 dark:border-green-800' : 'bg-muted/50'
                        }`}>
                          <div className="mt-1">
                            {deliveryComplete ? (
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            ) : (
                              <div className="h-5 w-5 rounded-full border-2 border-muted-foreground" />
                            )}
                          </div>
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium">Delivery</p>
                                <p className="text-sm text-muted-foreground">
                                  {job.delivery_location?.address || 'N/A'}
                                </p>
                              </div>
                              {pickupComplete && !deliveryComplete && (
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleManualStopUpdate(job.id, 'delivered')}
                                >
                                  <Edit className="h-3 w-3 mr-1" />
                                  Mark Complete
                                </Button>
                              )}
                            </div>
                            {deliveryComplete && assignment?.completed_at && (
                              <p className="text-xs text-muted-foreground">
                                Completed: {new Date(assignment.completed_at).toLocaleString()}
                              </p>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Additional Info */}
                      <div className="mt-3 pt-3 border-t grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground">Distance</p>
                          <p className="font-medium">{job.distance_miles || 0} mi</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Pickup Time</p>
                          <p className="font-medium">
                            {job.pickup_time ? new Date(job.pickup_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                          </p>
                        </div>
                        <div>
                          <p className="text-muted-foreground">Delivery Time</p>
                          <p className="font-medium">
                            {job.delivery_time ? new Date(job.delivery_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'N/A'}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default JobOverview;