import React from 'react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { 
  Clock, CheckCircle, AlertTriangle, XCircle, 
  PlayCircle, PauseCircle 
} from 'lucide-react';

interface JobStatusIndicatorProps {
  status: string;
  showIcon?: boolean;
  size?: 'sm' | 'default' | 'lg';
}

export const JobStatusIndicator: React.FC<JobStatusIndicatorProps> = ({ 
  status, 
  showIcon = true,
  size = 'default'
}) => {
  const getStatusConfig = (status: string) => {
    const statusMap = {
      'pending': {
        styles: 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
        icon: Clock,
        label: 'Pending'
      },
      'planned': {
        styles: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-300',
        icon: Clock,
        label: 'Planned'
      },
      'claimed': {
        styles: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300',
        icon: Clock,
        label: 'Claimed'
      },
      'posted': {
        styles: 'bg-cyan-50 text-cyan-700 border-cyan-200 dark:bg-cyan-950 dark:text-cyan-300',
        icon: PlayCircle,
        label: 'Posted'
      },
      'assigned': {
        styles: 'bg-indigo-50 text-indigo-700 border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300',
        icon: CheckCircle,
        label: 'Assigned'
      },
      'in_progress': {
        styles: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300',
        icon: PlayCircle,
        label: 'In Progress'
      },
      'in_transit': {
        styles: 'bg-sky-50 text-sky-700 border-sky-200 dark:bg-sky-950 dark:text-sky-300',
        icon: PlayCircle,
        label: 'In Transit'
      },
      'picked_up': {
        styles: 'bg-teal-50 text-teal-700 border-teal-200 dark:bg-teal-950 dark:text-teal-300',
        icon: CheckCircle,
        label: 'Picked Up'
      },
      'on_hold': {
        styles: 'bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-300',
        icon: PauseCircle,
        label: 'On Hold'
      },
      'delayed': {
        styles: 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950 dark:text-orange-300',
        icon: AlertTriangle,
        label: 'Delayed'
      },
      'delivered': {
        styles: 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
        icon: CheckCircle,
        label: 'Delivered'
      },
      'cancelled': {
        styles: 'bg-gray-50 text-gray-700 border-gray-200 dark:bg-gray-950 dark:text-gray-300',
        icon: XCircle,
        label: 'Cancelled'
      },
      'archived': {
        styles: 'bg-slate-50 text-slate-700 border-slate-200 dark:bg-slate-950 dark:text-slate-300',
        icon: XCircle,
        label: 'Archived'
      }
    };
    return statusMap[status as keyof typeof statusMap] || {
      styles: 'bg-muted text-muted-foreground border-border',
      icon: Clock,
      label: status
    };
  };

  const config = getStatusConfig(status);
  const IconComponent = config.icon;

  return (
    <Badge 
      variant="outline" 
      className={cn(
        config.styles,
        size === 'sm' && 'text-xs px-2 py-1',
        size === 'lg' && 'text-sm px-3 py-1.5'
      )}
    >
      {showIcon && <IconComponent className={cn(
        "mr-1",
        size === 'sm' ? 'h-3 w-3' : size === 'lg' ? 'h-5 w-5' : 'h-4 w-4'
      )} />}
      {config.label}
    </Badge>
  );
};

interface PriorityIndicatorProps {
  priority: string;
  showIcon?: boolean;
  size?: 'sm' | 'default' | 'lg';
}

export const PriorityIndicator: React.FC<PriorityIndicatorProps> = ({ 
  priority, 
  showIcon = true,
  size = 'default'
}) => {
  const getPriorityConfig = (priority: string) => {
    const priorityMap = {
      'pickup_now': {
        styles: 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300',
        icon: AlertTriangle,
        label: 'Pick Up Now'
      },
      'scheduled': {
        styles: 'bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300',
        icon: Clock,
        label: 'Scheduled'
      },
      'route': {
        styles: 'bg-purple-50 text-purple-700 border-purple-200 dark:bg-purple-950 dark:text-purple-300',
        icon: CheckCircle,
        label: 'Route'
      },
      'Critical': {
        styles: 'bg-red-50 text-red-700 border-red-200 dark:bg-red-950 dark:text-red-300',
        icon: AlertTriangle,
        label: 'Critical'
      },
      'High': {
        styles: 'bg-orange-50 text-orange-700 border-orange-200 dark:bg-orange-950 dark:text-orange-300',
        icon: AlertTriangle,
        label: 'High'
      },
      'Medium': {
        styles: 'bg-yellow-50 text-yellow-700 border-yellow-200 dark:bg-yellow-950 dark:text-yellow-300',
        icon: Clock,
        label: 'Medium'
      },
      'Low': {
        styles: 'bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-300',
        icon: CheckCircle,
        label: 'Low'
      }
    };
    return priorityMap[priority as keyof typeof priorityMap] || {
      styles: 'bg-muted text-muted-foreground border-border',
      icon: Clock,
      label: priority
    };
  };

  const config = getPriorityConfig(priority);
  const IconComponent = config.icon;

  return (
    <Badge 
      variant="outline" 
      className={cn(
        config.styles,
        'whitespace-nowrap inline-flex items-center',
        size === 'sm' && 'text-[0.65rem] px-1.5 py-0.5',
        size === 'lg' && 'text-sm px-3 py-1.5'
      )}
    >
      {showIcon && <IconComponent className={cn(
        "mr-1 flex-shrink-0",
        size === 'sm' ? 'h-2.5 w-2.5' : size === 'lg' ? 'h-5 w-5' : 'h-4 w-4'
      )} />}
      <span className="inline-block">{config.label}</span>
    </Badge>
  );
};