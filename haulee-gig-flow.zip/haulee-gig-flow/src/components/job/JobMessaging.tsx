import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  MessageCircle, Send, Search, Users, Clock, AlertCircle, 
  CheckCircle, Filter, Plus, Paperclip, Bell, Eye
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface JobMessagingProps {
  userRole: string;
}

const JobMessaging: React.FC<JobMessagingProps> = ({ userRole }) => {
  const { toast } = useToast();
  const [selectedConversation, setSelectedConversation] = useState<any>(null);
  const [newMessage, setNewMessage] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [messageFilter, setMessageFilter] = useState('all');

  // Mock conversations data
  const conversations = [
    {
      id: 'CONV-001',
      jobId: 'JOB-001',
      jobTitle: 'Urgent Delivery to Downtown',
      participants: ['Mike Driver', 'John Admin'],
      lastMessage: 'ETA updated - arriving in 15 minutes',
      timestamp: '10 minutes ago',
      unreadCount: 2,
      status: 'active',
      priority: 'high'
    },
    {
      id: 'CONV-002',
      jobId: 'JOB-002',
      jobTitle: 'Warehouse Pickup',
      participants: ['Lisa Carrier', 'Sarah Broker'],
      lastMessage: 'Package secured and ready for transport',
      timestamp: '1 hour ago',
      unreadCount: 0,
      status: 'active',
      priority: 'medium'
    },
    {
      id: 'CONV-003',
      jobId: 'JOB-003',
      jobTitle: 'Long Distance Transport',
      participants: ['David Vendor', 'Tom Manager'],
      lastMessage: 'Job completed successfully',
      timestamp: '2 hours ago',
      unreadCount: 1,
      status: 'completed',
      priority: 'low'
    }
  ];

  // Mock messages for selected conversation
  const messages = [
    {
      id: 'MSG-001',
      sender: 'John Admin',
      content: 'Hi Mike, please confirm pickup status for JOB-001',
      timestamp: '2:30 PM',
      type: 'text',
      status: 'read'
    },
    {
      id: 'MSG-002',
      sender: 'Mike Driver',
      content: 'Pickup confirmed. Package secured and heading to destination.',
      timestamp: '2:35 PM',
      type: 'text',
      status: 'read'
    },
    {
      id: 'MSG-003',
      sender: 'Mike Driver',
      content: 'Traffic delay on Route 95. ETA updated to 4:15 PM',
      timestamp: '3:45 PM',
      type: 'text',
      status: 'delivered'
    },
    {
      id: 'MSG-004',
      sender: 'John Admin',
      content: 'Thanks for the update. Please notify when delivery is complete.',
      timestamp: '3:50 PM',
      type: 'text',
      status: 'delivered'
    },
    {
      id: 'MSG-005',
      sender: 'Mike Driver',
      content: 'ETA updated - arriving in 15 minutes',
      timestamp: '4:00 PM',
      type: 'text',
      status: 'sent'
    }
  ];

  // Mock broadcast messages
  const broadcastMessages = [
    {
      id: 'BROAD-001',
      title: 'Weather Alert - Heavy Rain Expected',
      content: 'All drivers please exercise caution. Consider route adjustments.',
      sender: 'System',
      timestamp: '1 hour ago',
      recipients: 'All Drivers',
      status: 'active'
    },
    {
      id: 'BROAD-002',
      title: 'New Safety Protocol Update',
      content: 'Updated safety guidelines are now in effect. Please review attached document.',
      sender: 'Safety Team',
      timestamp: '3 hours ago',
      recipients: 'All Users',
      status: 'active'
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800 border-green-200';
      case 'completed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      toast({
        title: "Message Sent",
        description: "Your message has been delivered successfully."
      });
      setNewMessage('');
    }
  };

  const handleSendBroadcast = () => {
    toast({
      title: "Broadcast Sent",
      description: "Your broadcast message has been sent to all selected recipients."
    });
  };

  return (
    <div className="space-y-6">
      {/* Header with Search and Actions */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Job Messages & Communications
            </CardTitle>
            <div className="flex space-x-2">
              <Dialog>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Broadcast
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Send Broadcast Message</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label>Recipients</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select audience" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Users</SelectItem>
                          <SelectItem value="drivers">All Drivers</SelectItem>
                          <SelectItem value="carriers">All Carriers</SelectItem>
                          <SelectItem value="vendors">All Vendors</SelectItem>
                          <SelectItem value="admins">All Admins</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Subject</Label>
                      <Input placeholder="Enter message subject" />
                    </div>
                    <div className="space-y-2">
                      <Label>Message</Label>
                      <Textarea placeholder="Enter your broadcast message..." rows={4} />
                    </div>
                    <div className="flex justify-end space-x-2">
                      <Button variant="outline">Cancel</Button>
                      <Button onClick={handleSendBroadcast}>Send Broadcast</Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search conversations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={messageFilter} onValueChange={setMessageFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter messages" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Messages</SelectItem>
                <SelectItem value="unread">Unread Only</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
                <SelectItem value="active">My Jobs</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Main Messaging Interface */}
      <Tabs defaultValue="conversations" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="conversations">Job Conversations</TabsTrigger>
          <TabsTrigger value="broadcasts">Broadcast Messages</TabsTrigger>
        </TabsList>

        {/* Job Conversations */}
        <TabsContent value="conversations">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[600px]">
            {/* Conversations List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Conversations</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[500px]">
                  <div className="space-y-2 p-4">
                    {conversations.map((conv) => (
                      <div
                        key={conv.id}
                        className={`p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                          selectedConversation?.id === conv.id ? 'bg-muted border-primary' : ''
                        }`}
                        onClick={() => setSelectedConversation(conv)}
                      >
                        <div className="flex items-start justify-between">
                          <div className="space-y-1 flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="text-sm font-medium truncate">{conv.jobTitle}</h4>
                              {conv.unreadCount > 0 && (
                                <Badge variant="secondary" className="text-xs">
                                  {conv.unreadCount}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {conv.jobId} • {conv.participants.join(', ')}
                            </p>
                            <p className="text-xs text-muted-foreground truncate">
                              {conv.lastMessage}
                            </p>
                          </div>
                          <div className="flex flex-col items-end space-y-1">
                            <span className="text-xs text-muted-foreground">{conv.timestamp}</span>
                            <AlertCircle className={`h-3 w-3 ${getPriorityColor(conv.priority)}`} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Message Thread */}
            <Card className="col-span-2">
              {selectedConversation ? (
                <>
                  <CardHeader className="border-b">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-sm">{selectedConversation.jobTitle}</CardTitle>
                        <p className="text-xs text-muted-foreground">
                          {selectedConversation.jobId} • {selectedConversation.participants.join(', ')}
                        </p>
                      </div>
                      <Badge variant="outline" className={getStatusColor(selectedConversation.status)}>
                        {selectedConversation.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    <ScrollArea className="h-[400px] p-4">
                      <div className="space-y-4">
                        {messages.map((message) => (
                          <div key={message.id} className="space-y-2">
                            <div className="flex items-center gap-2">
                              <span className="text-sm font-medium">{message.sender}</span>
                              <span className="text-xs text-muted-foreground">{message.timestamp}</span>
                              {message.status === 'read' && <Eye className="h-3 w-3 text-blue-500" />}
                              {message.status === 'delivered' && <CheckCircle className="h-3 w-3 text-green-500" />}
                            </div>
                            <div className="bg-muted p-3 rounded-lg max-w-md">
                              <p className="text-sm">{message.content}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                    <div className="p-4 border-t">
                      <div className="flex space-x-2">
                        <div className="flex-1 relative">
                          <Textarea
                            placeholder="Type your message..."
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            rows={2}
                            className="pr-20"
                          />
                          <Button
                            size="sm"
                            className="absolute bottom-2 right-2"
                            onClick={handleSendMessage}
                          >
                            <Send className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </>
              ) : (
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center text-muted-foreground">
                    <MessageCircle className="h-12 w-12 mx-auto mb-4" />
                    <p>Select a conversation to start messaging</p>
                  </div>
                </CardContent>
              )}
            </Card>
          </div>
        </TabsContent>

        {/* Broadcast Messages */}
        <TabsContent value="broadcasts">
          <div className="space-y-4">
            {broadcastMessages.map((broadcast) => (
              <Card key={broadcast.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2 flex-1">
                      <div className="flex items-center gap-2">
                        <Bell className="h-4 w-4 text-blue-500" />
                        <h4 className="font-semibold">{broadcast.title}</h4>
                        <Badge variant="outline" className={getStatusColor(broadcast.status)}>
                          {broadcast.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{broadcast.content}</p>
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span>From: {broadcast.sender}</span>
                        <span>To: {broadcast.recipients}</span>
                        <span>{broadcast.timestamp}</span>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default JobMessaging;