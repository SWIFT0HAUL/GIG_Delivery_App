import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar } from '@/components/ui/calendar';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  Users, Calendar as CalendarIcon, Clock, UserCheck, Bell, 
  Filter, Search, MapPin, Package, AlertTriangle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AssignmentScheduler = () => {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [filterStatus, setFilterStatus] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAssignment, setSelectedAssignment] = useState<any>(null);

  // Mock data for assignments
  const assignments = [
    {
      id: 'ASG-001',
      jobId: 'JOB-001',
      jobTitle: 'Urgent Delivery to Downtown',
      assignee: 'Mike Driver',
      assigneeType: 'Driver',
      status: 'Active',
      priority: 'High',
      scheduledDate: '2024-01-20',
      scheduledTime: '09:00 AM',
      location: 'Downtown District',
      estimatedDuration: '2 hours',
      progress: 65
    },
    {
      id: 'ASG-002',
      jobId: 'JOB-002',
      jobTitle: 'Warehouse Pickup',
      assignee: 'Lisa Carrier',
      assigneeType: 'Carrier',
      status: 'Pending',
      priority: 'Medium',
      scheduledDate: '2024-01-21',
      scheduledTime: '02:00 PM',
      location: 'Industrial Zone',
      estimatedDuration: '4 hours',
      progress: 0
    },
    {
      id: 'ASG-003',
      jobId: 'JOB-003',
      jobTitle: 'Long Distance Transport',
      assignee: 'David Vendor',
      assigneeType: 'Vendor/Merchant',
      status: 'Completed',
      priority: 'Low',
      scheduledDate: '2024-01-18',
      scheduledTime: '06:00 AM',
      location: 'Cross State Route',
      estimatedDuration: '8 hours',
      progress: 100
    }
  ];

  // Mock data for available workers
  const availableWorkers = [
    {
      id: 'WRK-001',
      name: 'Mike Driver',
      type: 'Driver',
      status: 'Available',
      location: 'North District',
      rating: 4.8,
      currentLoad: 2,
      maxLoad: 5
    },
    {
      id: 'WRK-002',
      name: 'Lisa Carrier',
      type: 'Carrier',
      status: 'Busy',
      location: 'South District',
      rating: 4.9,
      currentLoad: 4,
      maxLoad: 6
    },
    {
      id: 'WRK-003',
      name: 'David Vendor',
      type: 'Vendor/Merchant',
      status: 'Available',
      location: 'East District',
      rating: 4.7,
      currentLoad: 1,
      maxLoad: 4
    }
  ];

  // Mock unassigned jobs
  const unassignedJobs = [
    {
      id: 'JOB-004',
      title: 'Emergency Medical Supplies',
      type: 'Delivery',
      priority: 'Critical',
      deadline: '2024-01-21',
      location: 'City Hospital',
      requiredSkills: ['Medical Transport', 'Urgent Delivery']
    },
    {
      id: 'JOB-005',
      title: 'Furniture Relocation',
      type: 'Moving',
      priority: 'Medium',
      deadline: '2024-01-24',
      location: 'Residential Area',
      requiredSkills: ['Heavy Lifting', 'Furniture Handling']
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'planned': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'claimed': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'posted': return 'bg-cyan-100 text-cyan-800 border-cyan-200';
      case 'assigned': return 'bg-indigo-100 text-indigo-800 border-indigo-200';
      case 'in_progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'picked_up': return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'delivered': return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'archived': return 'bg-slate-100 text-slate-800 border-slate-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'High': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getWorkerStatusColor = (status: string) => {
    switch (status) {
      case 'Available': return 'bg-green-100 text-green-800 border-green-200';
      case 'Busy': return 'bg-red-100 text-red-800 border-red-200';
      case 'Offline': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const handleReassign = (assignmentId: string) => {
    toast({
      title: "Reassignment Initiated",
      description: "Select a new assignee for this job."
    });
  };

  const handleSendNotification = (assignmentId: string) => {
    toast({
      title: "Notification Sent",
      description: "Update notification has been sent to the assignee."
    });
  };

  return (
    <div className="space-y-6">
      {/* Filters and Search */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Assignment Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search assignments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="planned">Planned</SelectItem>
                <SelectItem value="claimed">Claimed</SelectItem>
                <SelectItem value="posted">Posted</SelectItem>
                <SelectItem value="assigned">Assigned</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="picked_up">Picked Up</SelectItem>
                <SelectItem value="delayed">Delayed</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
                <SelectItem value="archived">Archived</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex items-center space-x-2">
              <CalendarIcon className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">
                {selectedDate ? selectedDate.toDateString() : 'Select Date'}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Assignment Interface */}
      <Tabs defaultValue="assignments" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="assignments">Current Assignments</TabsTrigger>
          <TabsTrigger value="workers">Available Workers</TabsTrigger>
          <TabsTrigger value="unassigned">Unassigned Jobs</TabsTrigger>
        </TabsList>

        {/* Current Assignments */}
        <TabsContent value="assignments">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Active Assignments</h3>
              {assignments.map((assignment) => (
                <Card key={assignment.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className={getStatusColor(assignment.status)}>
                            {assignment.status}
                          </Badge>
                          <Badge variant="outline" className={getPriorityColor(assignment.priority)}>
                            {assignment.priority}
                          </Badge>
                        </div>
                        <h4 className="font-semibold">{assignment.jobTitle}</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4" />
                            {assignment.assignee} ({assignment.assigneeType})
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4" />
                            {assignment.scheduledDate} at {assignment.scheduledTime}
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            {assignment.location}
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${assignment.progress}%` }}
                          ></div>
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2 ml-4">
                        <Button size="sm" variant="outline" onClick={() => handleReassign(assignment.id)}>
                          <UserCheck className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleSendNotification(assignment.id)}>
                          <Bell className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Calendar View */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CalendarIcon className="h-5 w-5" />
                  Schedule Calendar
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border pointer-events-auto"
                />
                <div className="mt-4 space-y-2">
                  <h4 className="font-medium">Today's Schedule</h4>
                  <div className="text-sm text-muted-foreground space-y-1">
                    <div>• 9:00 AM - Urgent Delivery (Mike Driver)</div>
                    <div>• 2:00 PM - Warehouse Pickup (Lisa Carrier)</div>
                    <div>• 4:00 PM - Client Meeting (David Vendor)</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Available Workers */}
        <TabsContent value="workers">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {availableWorkers.map((worker) => (
              <Card key={worker.id}>
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold">{worker.name}</h4>
                      <Badge variant="outline" className={getWorkerStatusColor(worker.status)}>
                        {worker.status}
                      </Badge>
                    </div>
                    
                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <Package className="h-4 w-4" />
                        {worker.type}
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        {worker.location}
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Load: {worker.currentLoad}/{worker.maxLoad}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="text-sm">
                        Rating: {worker.rating}/5.0
                      </div>
                      <Button size="sm" disabled={worker.status !== 'Available'}>
                        Assign Job
                      </Button>
                    </div>

                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full" 
                        style={{ width: `${(worker.currentLoad / worker.maxLoad) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Unassigned Jobs */}
        <TabsContent value="unassigned">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                Unassigned Jobs ({unassignedJobs.length})
              </h3>
              <Button>
                Auto-Assign Available
              </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {unassignedJobs.map((job) => (
                <Card key={job.id} className="border-orange-200 bg-orange-50/50">
                  <CardContent className="p-4">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="outline" className={getPriorityColor(job.priority)}>
                              {job.priority}
                            </Badge>
                            <span className="text-sm text-muted-foreground">{job.type}</span>
                          </div>
                          <h4 className="font-semibold">{job.title}</h4>
                          <div className="text-sm text-muted-foreground space-y-1">
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4" />
                              Deadline: {job.deadline}
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="h-4 w-4" />
                              {job.location}
                            </div>
                          </div>
                        </div>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button size="sm">
                              Assign Now
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Assign Job: {job.title}</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4">
                              <div className="space-y-2">
                                <Label>Select Assignee</Label>
                                <Select>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Choose worker" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {availableWorkers.filter(w => w.status === 'Available').map((worker) => (
                                      <SelectItem key={worker.id} value={worker.id}>
                                        {worker.name} ({worker.type}) - {worker.location}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label>Assignment Notes</Label>
                                <Textarea placeholder="Add any special instructions..." />
                              </div>
                              <div className="flex justify-end space-x-2">
                                <Button variant="outline">Cancel</Button>
                                <Button>Confirm Assignment</Button>
                              </div>
                            </div>
                          </DialogContent>
                        </Dialog>
                      </div>

                      <div className="space-y-2">
                        <h5 className="text-sm font-medium">Required Skills:</h5>
                        <div className="flex flex-wrap gap-1">
                          {job.requiredSkills.map((skill, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AssignmentScheduler;