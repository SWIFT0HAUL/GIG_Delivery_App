import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { 
  Truck, CheckCircle, Users, Phone, MessageSquare, MapPinned, 
  Image as ImageIcon, Edit, Navigation, Clock, Package, Search,
  AlertTriangle, MapPin, RefreshCw
} from 'lucide-react';
import { JobMapView } from '@/components/driver/JobMapView';

interface RouteMonitorProps {
  filters?: {
    search: string;
    status: string;
    assignedUser: string;
  };
}

interface Job {
  id: string;
  title: string;
  status: string;
  pickup_location: any;
  delivery_location: any;
  pickup_time: string;
  delivery_time: string;
  distance_miles: number;
  job_assignments: Array<{
    id: string;
    status: string;
    pickup_photo_url: string | null;
    started_at: string | null;
    completed_at: string | null;
    driver: {
      id: string;
      full_name: string;
      phone: string;
    } | null;
  }>;
}

const RouteMonitor: React.FC<RouteMonitorProps> = ({ filters }) => {
  const { toast } = useToast();
  const [activeRoutes, setActiveRoutes] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterDriver, setFilterDriver] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [drivers, setDrivers] = useState<Array<{ id: string; full_name: string }>>([]);
  const [selectedDriverDetails, setSelectedDriverDetails] = useState<any>(null);
  const [showDriverDetails, setShowDriverDetails] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [selectedMapJob, setSelectedMapJob] = useState<Job | null>(null);

  useEffect(() => {
    fetchActiveRoutes();
    fetchDrivers();

    // Real-time subscription
    const channel = supabase
      .channel('route-monitor-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'jobs',
          filter: 'status=in.("planned","in_progress","assigned","picked_up")'
        },
        () => {
          console.log('Job updated, refreshing routes...');
          fetchActiveRoutes();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'job_assignments'
        },
        () => {
          console.log('Assignment updated, refreshing routes...');
          fetchActiveRoutes();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchDrivers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name')
        .eq('role_key', 'driver')
        .order('full_name');

      if (error) throw error;
      setDrivers(data || []);
    } catch (error) {
      console.error('Error fetching drivers:', error);
    }
  };

  const fetchActiveRoutes = async () => {
    try {
      setLoading(true);
      
      // Fetch jobs with their assignments
      const { data: jobs, error: jobsError } = await supabase
        .from('jobs')
        .select(`
          id,
          title,
          status,
          pickup_location,
          delivery_location,
          pickup_time,
          delivery_time,
          distance_miles
        `)
        .in('status', ['planned', 'in_progress', 'assigned', 'picked_up'])
        .order('pickup_time', { ascending: true });

      if (jobsError) throw jobsError;
      if (!jobs) {
        setActiveRoutes([]);
        return;
      }

      // Fetch all assignments for these jobs
      const { data: assignments, error: assignmentsError } = await supabase
        .from('job_assignments')
        .select('*')
        .in('job_id', jobs.map(j => j.id));

      if (assignmentsError) throw assignmentsError;

      // Fetch driver profiles
      const driverIds = [...new Set(assignments?.map(a => a.driver_id).filter(Boolean) || [])];
      const { data: drivers } = await supabase
        .from('profiles')
        .select('id, full_name, phone')
        .in('id', driverIds);

      // Combine the data
      const jobsWithAssignments = jobs.map(job => {
        const jobAssignments = (assignments || [])
          .filter(a => a.job_id === job.id)
          .map(assignment => ({
            ...assignment,
            driver: drivers?.find(d => d.id === assignment.driver_id) || null
          }));

        return {
          ...job,
          job_assignments: jobAssignments
        };
      });

      setActiveRoutes(jobsWithAssignments);
    } catch (error) {
      console.error('Error fetching active routes:', error);
      toast({
        title: 'Error',
        description: 'Failed to load active routes',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManualStopUpdate = async (jobId: string, newStatus: string, stopType: 'pickup' | 'delivery') => {
    try {
      const updates: any = { 
        status: newStatus, 
        updated_at: new Date().toISOString() 
      };

      const { error } = await supabase
        .from('jobs')
        .update(updates)
        .eq('id', jobId);

      if (error) throw error;

      toast({
        title: 'Stop Updated',
        description: `${stopType === 'pickup' ? 'Pickup' : 'Delivery'} marked as complete`,
      });
      
      fetchActiveRoutes();
    } catch (error) {
      console.error('Error updating stop:', error);
      toast({
        title: 'Update Failed',
        description: 'Failed to update stop status',
        variant: 'destructive',
      });
    }
  };

  const handleAddNote = async (jobId: string) => {
    const note = prompt('Enter admin note:');
    if (!note) return;

    try {
      const { data: job } = await supabase
        .from('jobs')
        .select('metadata')
        .eq('id', jobId)
        .single();

      const metadata = (job?.metadata as Record<string, any>) || {};
      const adminNotes = (metadata.admin_notes as Array<any>) || [];
      
      adminNotes.push({
        note,
        timestamp: new Date().toISOString(),
        admin_id: (await supabase.auth.getUser()).data.user?.id
      });

      const { error } = await supabase
        .from('jobs')
        .update({ 
          metadata: { ...metadata, admin_notes: adminNotes } as any,
          updated_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (error) throw error;

      toast({
        title: 'Note Added',
        description: 'Admin note has been added successfully',
      });
      
      fetchActiveRoutes();
    } catch (error) {
      console.error('Error adding note:', error);
      toast({
        title: 'Failed',
        description: 'Failed to add note',
        variant: 'destructive',
      });
    }
  };

  // Apply filters
  const filteredRoutes = activeRoutes.filter(job => {
    const assignment = job.job_assignments?.[0];
    const driver = assignment?.driver;

    // Driver filter
    if (filterDriver !== 'all' && driver?.id !== filterDriver) return false;

    // Status filter
    if (filterStatus !== 'all' && job.status !== filterStatus) return false;

    // Search filter
    if (searchQuery) {
      const searchLower = searchQuery.toLowerCase();
      const matchesTitle = job.title?.toLowerCase().includes(searchLower);
      const matchesDriver = driver?.full_name?.toLowerCase().includes(searchLower);
      const matchesPickup = job.pickup_location?.address?.toLowerCase().includes(searchLower);
      const matchesDelivery = job.delivery_location?.address?.toLowerCase().includes(searchLower);
      
      if (!matchesTitle && !matchesDriver && !matchesPickup && !matchesDelivery) return false;
    }

    return true;
  });

  const getStatusBadge = (status: string) => {
    const statusMap: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
      'assigned': { label: 'Assigned', variant: 'secondary' },
      'in_progress': { label: 'In Progress', variant: 'default' },
      'picked_up': { label: 'Picked Up', variant: 'default' },
    };

    const config = statusMap[status] || { label: status, variant: 'outline' };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="space-y-3">
                <Skeleton className="h-6 w-1/3" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-24 w-full" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Routes</p>
                <p className="text-2xl font-bold">{filteredRoutes.length}</p>
              </div>
              <Truck className="h-8 w-8 text-blue-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Progress</p>
                <p className="text-2xl font-bold">
                  {filteredRoutes.filter(j => j.status === 'in_progress' || j.status === 'picked_up').length}
                </p>
              </div>
              <Navigation className="h-8 w-8 text-green-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Assigned</p>
                <p className="text-2xl font-bold">
                  {filteredRoutes.filter(j => j.status === 'assigned').length}
                </p>
              </div>
              <Clock className="h-8 w-8 text-orange-500 opacity-50" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Distance</p>
                <p className="text-2xl font-bold">
                  {filteredRoutes.reduce((sum, j) => sum + (j.distance_miles || 0), 0).toFixed(0)} mi
                </p>
              </div>
              <MapPin className="h-8 w-8 text-purple-500 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Filter Routes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Search</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Job title, driver, location..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Driver</label>
              <Select value={filterDriver} onValueChange={setFilterDriver}>
                <SelectTrigger>
                  <SelectValue placeholder="All Drivers" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Drivers</SelectItem>
                  {drivers.map(driver => (
                    <SelectItem key={driver.id} value={driver.id}>
                      {driver.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="All Statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="picked_up">Picked Up</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Routes List */}
      {filteredRoutes.length === 0 ? (
        <Alert>
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            No active routes found. All deliveries are completed or no routes match the filters.
          </AlertDescription>
        </Alert>
      ) : (
        <div className="space-y-4">
          {filteredRoutes.map((job) => {
            const assignment = job.job_assignments?.[0];
            const driver = assignment?.driver;
            const pickupComplete = ['picked_up', 'delivered', 'completed'].includes(job.status);
            const deliveryComplete = ['delivered', 'completed'].includes(job.status);
            const progress = deliveryComplete ? 100 : pickupComplete ? 50 : 0;
            
            return (
              <Card key={job.id} className="border-l-4 border-l-blue-500 hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  {/* Header */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="space-y-2">
                      <div className="flex items-center gap-3">
                        <h3 className="font-semibold text-xl">{job.title}</h3>
                        {getStatusBadge(job.status)}
                      </div>
                      {driver ? (
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              console.log('Driver clicked:', driver);
                              setSelectedDriverDetails(driver);
                              setShowDriverDetails(true);
                            }}
                            className="flex items-center gap-1 hover:text-primary transition-colors h-auto p-0"
                          >
                            <Users className="h-4 w-4" />
                            <span className="hover:underline">{driver.full_name}</span>
                          </Button>
                          {driver.phone && (
                            <div className="flex items-center gap-1">
                              <Phone className="h-4 w-4" />
                              <span>{driver.phone}</span>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 text-orange-500">
                          <AlertTriangle className="h-4 w-4" />
                          <span className="text-sm">No driver assigned</span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {driver?.phone && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => window.open(`tel:${driver.phone}`, '_self')}
                        >
                          <Phone className="h-4 w-4" />
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleAddNote(job.id)}
                      >
                        <MessageSquare className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <MapPinned className="h-4 w-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={fetchActiveRoutes}
                      >
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  {/* Progress */}
                  <div className="mb-6">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Route Progress</span>
                      <span className="text-sm text-muted-foreground">
                        {deliveryComplete ? '2' : pickupComplete ? '1' : '0'} of 2 stops completed
                      </span>
                    </div>
                    <Progress value={progress} className="h-3" />
                  </div>

                  {/* Stops */}
                  <div className="space-y-3">
                    {/* Pickup */}
                    <div className={`flex items-start gap-4 p-4 rounded-lg border-2 ${
                      pickupComplete 
                        ? 'bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-800' 
                        : 'bg-muted/30 border-border'
                    }`}>
                      <div className="mt-1">
                        {pickupComplete ? (
                          <CheckCircle className="h-6 w-6 text-green-600" />
                        ) : (
                          <div className="h-6 w-6 rounded-full border-2 border-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-0 hover:bg-transparent"
                                onClick={() => {
                                  setSelectedMapJob(job);
                                  setShowMapModal(true);
                                }}
                              >
                                <Package className="h-4 w-4 text-primary hover:text-primary/80 cursor-pointer" />
                              </Button>
                              <p className="font-semibold">Pickup</p>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {job.pickup_location?.address || 'Address not available'}
                            </p>
                            {job.pickup_time && (
                              <p className="text-xs text-muted-foreground">
                                Scheduled: {new Date(job.pickup_time).toLocaleString()}
                              </p>
                            )}
                          </div>
                          {!pickupComplete && driver && (
                            <Button 
                              size="sm"
                              onClick={() => handleManualStopUpdate(job.id, 'picked_up', 'pickup')}
                            >
                              <Edit className="h-3 w-3 mr-1" />
                              Mark Complete
                            </Button>
                          )}
                        </div>
                        {assignment?.pickup_photo_url && (
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="gap-2"
                            onClick={() => window.open(assignment.pickup_photo_url!, '_blank')}
                          >
                            <ImageIcon className="h-3 w-3" />
                            View Pickup Photo
                          </Button>
                        )}
                        {pickupComplete && assignment?.started_at && (
                          <p className="text-xs text-green-600 font-medium">
                            ✓ Completed: {new Date(assignment.started_at).toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Delivery */}
                    <div className={`flex items-start gap-4 p-4 rounded-lg border-2 ${
                      deliveryComplete 
                        ? 'bg-green-50 border-green-200 dark:bg-green-950/20 dark:border-green-800' 
                        : 'bg-muted/30 border-border'
                    }`}>
                      <div className="mt-1">
                        {deliveryComplete ? (
                          <CheckCircle className="h-6 w-6 text-green-600" />
                        ) : (
                          <div className="h-6 w-6 rounded-full border-2 border-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-auto p-0 hover:bg-transparent"
                                onClick={() => {
                                  setSelectedMapJob(job);
                                  setShowMapModal(true);
                                }}
                              >
                                <MapPin className="h-4 w-4 text-primary hover:text-primary/80 cursor-pointer" />
                              </Button>
                              <p className="font-semibold">Delivery</p>
                            </div>
                            <p className="text-sm text-muted-foreground">
                              {job.delivery_location?.address || 'Address not available'}
                            </p>
                            {job.delivery_time && (
                              <p className="text-xs text-muted-foreground">
                                Scheduled: {new Date(job.delivery_time).toLocaleString()}
                              </p>
                            )}
                          </div>
                          {pickupComplete && !deliveryComplete && driver && (
                            <Button 
                              size="sm"
                              onClick={() => handleManualStopUpdate(job.id, 'delivered', 'delivery')}
                            >
                              <Edit className="h-3 w-3 mr-1" />
                              Mark Complete
                            </Button>
                          )}
                        </div>
                        {deliveryComplete && assignment?.completed_at && (
                          <p className="text-xs text-green-600 font-medium">
                            ✓ Completed: {new Date(assignment.completed_at).toLocaleString()}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Footer Info */}
                  <div className="mt-4 pt-4 border-t grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Distance</p>
                      <p className="font-semibold">{job.distance_miles?.toFixed(1) || 0} miles</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Pickup</p>
                      <p className="font-semibold">
                        {job.pickup_time 
                          ? new Date(job.pickup_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
                          : 'Not set'}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Delivery</p>
                      <p className="font-semibold">
                        {job.delivery_time 
                          ? new Date(job.delivery_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) 
                          : 'Not set'}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Driver Details Dialog */}
      <Dialog open={showDriverDetails} onOpenChange={setShowDriverDetails}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Driver Details</DialogTitle>
          </DialogHeader>
          
          {selectedDriverDetails && (
            <div className="space-y-6">
              {/* Driver Info */}
              <div className="flex items-start gap-4">
                <div className="bg-primary/10 p-3 rounded-full">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <div className="flex-1 space-y-1">
                  <h3 className="font-semibold text-lg">{selectedDriverDetails.full_name}</h3>
                  <p className="text-sm text-muted-foreground">{selectedDriverDetails.email}</p>
                  {selectedDriverDetails.phone && (
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4" />
                      <a href={`tel:${selectedDriverDetails.phone}`} className="hover:underline">
                        {selectedDriverDetails.phone}
                      </a>
                    </div>
                  )}
                </div>
              </div>

              <Separator />

              {/* Driver Stats */}
              <div className="grid grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground mb-1">My Jobs</p>
                    <p className="text-2xl font-bold">
                      {filteredRoutes.filter(r => r.job_assignments?.[0]?.driver?.id === selectedDriverDetails.id).length}
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground mb-1">In Progress</p>
                    <p className="text-2xl font-bold">
                      {filteredRoutes.filter(r => 
                        r.job_assignments?.[0]?.driver?.id === selectedDriverDetails.id && 
                        (r.status === 'in_progress' || r.status === 'picked_up')
                      ).length}
                    </p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground mb-1">Assigned</p>
                    <p className="text-2xl font-bold">
                      {filteredRoutes.filter(r => 
                        r.job_assignments?.[0]?.driver?.id === selectedDriverDetails.id && 
                        r.status === 'assigned'
                      ).length}
                    </p>
                  </CardContent>
                </Card>
              </div>

              <Separator />

              {/* Current Jobs */}
              <div className="space-y-2">
                <h4 className="font-semibold">Current Jobs</h4>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {filteredRoutes
                    .filter(r => r.job_assignments?.[0]?.driver?.id === selectedDriverDetails.id)
                    .map(job => (
                      <Card key={job.id} className="border-l-4 border-l-blue-500">
                        <CardContent className="p-3">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-semibold">{job.title}</span>
                            {getStatusBadge(job.status)}
                          </div>
                          <div className="space-y-1 text-xs text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Package className="h-3 w-3" />
                              <span className="truncate">{job.pickup_location?.address}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              <span className="truncate">{job.delivery_location?.address}</span>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  
                  {filteredRoutes.filter(r => r.job_assignments?.[0]?.driver?.id === selectedDriverDetails.id).length === 0 && (
                    <p className="text-sm text-muted-foreground text-center py-4">
                      No my jobs assigned
                    </p>
                  )}
                </div>
              </div>

              <div className="flex gap-2">
                <Button 
                  className="flex-1"
                  onClick={() => selectedDriverDetails.phone && window.open(`tel:${selectedDriverDetails.phone}`, '_self')}
                  disabled={!selectedDriverDetails.phone}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call Driver
                </Button>
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={() => setShowDriverDetails(false)}
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Map Modal */}
      <Dialog open={showMapModal} onOpenChange={setShowMapModal}>
        <DialogContent className="max-w-4xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>{selectedMapJob?.title || 'Job Route'}</DialogTitle>
          </DialogHeader>
          <div className="flex-1 h-full">
            {selectedMapJob && (
              <JobMapView
                pickupLocation={selectedMapJob.pickup_location}
                deliveryLocation={selectedMapJob.delivery_location}
                jobTitle={selectedMapJob.title}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default RouteMonitor;
