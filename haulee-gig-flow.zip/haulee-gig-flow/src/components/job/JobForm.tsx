import React, { useState, useEffect } from 'react';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  CalendarIcon, MapPin, DollarSign, 
  Plus, Trash2, Save, Send, FileText, Loader2
} from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { useKYCStatus } from '@/hooks/useKYCStatus';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { calculateJobCost } from '@/lib/jobCostCalculator';
import { useAuth } from '@/contexts/AuthContext';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { getDirections } from '@/lib/directions';
import { ALL_VEHICLE_TYPES, VEHICLE_CATEGORIES } from '@/lib/vehicleConfig';
import { useJobLocationGeocoding } from '@/hooks/useJobLocationGeocoding';

const jobFormSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  priority: z.enum(['pickup_now','scheduled','route'], { required_error: 'Priority is required' }).optional(),
  description: z.string().optional(),
  vehicle_type: z.string().optional(),
  distance_miles: z.string().optional(),
  estimated_duration: z.string().optional(),
  cargo_weight: z.string().optional(),
  cargo_length: z.string().optional(),
  cargo_width: z.string().optional(),
  cargo_height: z.string().optional(),
  cargo_pieces: z.string().optional(),
  pickup_location: z.object({
    address: z.string().min(1, 'Pickup address is required'),
    lat: z.number().optional(),
    lng: z.number().optional(),
  }),
  delivery_location: z.object({
    address: z.string().min(1, 'Delivery address is required'),
    lat: z.number().optional(),
    lng: z.number().optional(),
  }),
  pickup_time: z.date().optional(),
  delivery_time: z.date().optional(),
  pickup_contact_phone: z.string().optional(),
  delivery_contact_phone: z.string().optional(),
  pay_amount: z.string().optional(),
  pickup_instructions: z.string().optional(),
  delivery_instructions: z.string().optional(),
  signature_required: z.boolean().optional(),
});

type JobFormData = z.infer<typeof jobFormSchema>;

const JobForm = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const { kycVerified, kycStatus, loading: kycLoading } = useKYCStatus();
  const [scheduledDateOpen, setScheduledDateOpen] = useState(false);
  const [deadlineOpen, setDeadlineOpen] = useState(false);
  const { ensureLocationHasCoords, isGeocoding } = useJobLocationGeocoding();
  
  const { control, handleSubmit: hookFormSubmit, watch, setValue, reset, formState: { errors } } = useForm<JobFormData>({
    resolver: zodResolver(jobFormSchema),
    defaultValues: {
      title: '',
      priority: undefined,
      description: '',
      vehicle_type: '',
      distance_miles: '',
      estimated_duration: '',
      cargo_weight: '',
      cargo_length: '',
      cargo_width: '',
      cargo_height: '',
      cargo_pieces: '',
      pickup_location: { address: '' },
      delivery_location: { address: '' },
      pickup_contact_phone: '',
      delivery_contact_phone: '',
      pickup_instructions: '',
      delivery_instructions: '',
      pay_amount: '',
      signature_required: false,
    },
  });

  const pickupLocation = watch("pickup_location");
  const deliveryLocation = watch("delivery_location");
  const [calculatedDuration, setCalculatedDuration] = useState<number | null>(null);

  // Auto-calculation disabled - users can manually enter distance and duration
  // useEffect(() => {
  //   const calculateDistanceAndDuration = async () => {
  //     if (pickupLocation?.address && deliveryLocation?.address) {
  //       try {
  //         const result = await getDirections({
  //           origin: pickupLocation.address,
  //           destination: deliveryLocation.address,
  //           mode: 'driving'
  //         });
  //         if (result.routes && result.routes.length > 0) {
  //           const route = result.routes[0];
  //           let totalDistanceMeters = 0;
  //           let totalDurationSeconds = 0;
  //           route.legs.forEach(leg => {
  //             totalDistanceMeters += leg.distance.value;
  //             totalDurationSeconds += leg.duration.value;
  //           });
  //           const miles = (totalDistanceMeters / 1609.34).toFixed(1);
  //           setValue("distance_miles", miles);
  //           const minutes = Math.round(totalDurationSeconds / 60);
  //           setCalculatedDuration(minutes);
  //         }
  //       } catch (error) {
  //         console.error('Error calculating distance and duration:', error);
  //       }
  //     }
  //   };
  //   calculateDistanceAndDuration();
  // }, [pickupLocation?.address, deliveryLocation?.address, setValue]);

  const jobTypes: Array<'pickup_now' | 'scheduled' | 'route'> = [
    'pickup_now',
    'scheduled',
    'route'
  ];

  const jobTypeLabels: Record<'pickup_now' | 'scheduled' | 'route', string> = {
    pickup_now: 'Pick Up Now',
    scheduled: 'Scheduled',
    route: 'Route'
  };


  const availableUsers = [
    'Mike Driver',
    'Lisa Carrier',
    'David Vendor', 
    'Steve Driver',
    'Carol Carrier',
    'Sam Shipper'
  ];

  const clients = [
    'Tech Corp',
    'ABC Logistics',
    'Global Shipping',
    'Fast Freight',
    'Quick Move',
    'Rapid Transport'
  ];

  const createJobMutation = useMutation({
    mutationFn: async (data: JobFormData) => {
      if (!user?.id) throw new Error('User not authenticated');

      // Geocode locations to ensure they have coordinates
      const pickupWithCoords = await ensureLocationHasCoords(data.pickup_location);
      const deliveryWithCoords = await ensureLocationHasCoords(data.delivery_location);

      if (!pickupWithCoords || !deliveryWithCoords) {
        throw new Error('Failed to geocode addresses. Please check the addresses and try again.');
      }

      // Calculate costs
      const distance = data.distance_miles ? parseFloat(data.distance_miles) : 50;
      const duration = data.estimated_duration ? parseFloat(data.estimated_duration) : null;
      const weight = data.cargo_weight ? parseFloat(data.cargo_weight) : 0;
      const calculatedCost = calculateJobCost({
        distanceMiles: distance,
        weight: weight,
      });

      const jobData = {
        title: data.title,
        priority: data.priority,
        description: data.description || null,
        equipment_type: data.vehicle_type || null,
        distance_miles: distance,
        estimated_duration: duration,
        cargo_weight: weight,
        pickup_location: {
          ...pickupWithCoords,
          instructions: data.pickup_instructions || null,
        },
        delivery_location: {
          ...deliveryWithCoords,
          instructions: data.delivery_instructions || null,
        },
        pickup_time: data.pickup_time?.toISOString() || null,
        delivery_time: data.delivery_time?.toISOString() || null,
        pickup_contact_phone: data.pickup_contact_phone || null,
        delivery_contact_phone: data.delivery_contact_phone || null,
        pay_amount: data.pay_amount ? parseFloat(data.pay_amount) : calculatedCost,
        signature_required: data.signature_required || false,
        status: 'pending',
        created_by: user.id,
      };

      const { data: newJob, error } = await supabase
        .from('jobs')
        .insert([jobData])
        .select()
        .single();

      if (error) throw error;
      return newJob;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['jobs'] });
      toast({
        title: "Job Created",
        description: "Job has been created successfully.",
      });
      reset();
    },
    onError: (error: any) => {
      const errorMessage = error.message || "Failed to create job";
      
      // Check if error is about missing pickup time
      if (errorMessage.includes('pickup_time') || errorMessage.includes('pickup date')) {
        toast({
          title: "Pickup Date & Time Required",
          description: "Please set the pickup date and time before creating this job.",
          variant: "destructive",
        });
      } else {
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
    },
  });

  const onSubmit = (data: JobFormData) => {
    if (!kycVerified) {
      toast({
        title: "KYC Verification Required",
        description: "Please complete KYC verification to create jobs",
        variant: "destructive"
      });
      return;
    }
    createJobMutation.mutate(data);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'High': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <form onSubmit={hookFormSubmit(onSubmit)} className="space-y-6">
      {!kycLoading && !kycVerified && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>KYC Verification Required:</strong> You must complete identity verification before creating jobs. 
            {kycStatus === 'pending' && ' Your verification is currently under review.'}
            {kycStatus === 'not_submitted' && ' Please submit your documents for verification.'}
          </AlertDescription>
        </Alert>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Create New Job
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="title">Job Title *</Label>
              <Controller
                name="title"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="title"
                    placeholder="Enter job title"
                  />
                )}
              />
              {errors.title && <p className="text-sm text-destructive">{errors.title.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">Priority *</Label>
              <Controller
                name="priority"
                control={control}
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      {jobTypes.map((type) => (
                        <SelectItem key={type} value={type}>{jobTypeLabels[type]}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
              {errors.priority && <p className="text-sm text-destructive">{errors.priority.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicle_type">Vehicle Type</Label>
              <Controller
                name="vehicle_type"
                control={control}
                render={({ field }) => (
                  <Select value={field.value} onValueChange={field.onChange}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select vehicle type" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {VEHICLE_CATEGORIES.map((category) => (
                        <React.Fragment key={category.id}>
                          <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                            {category.icon} {category.name}
                          </div>
                          {category.vehicle_types.map((vehicle) => (
                            <SelectItem 
                              key={vehicle.name} 
                              value={vehicle.name}
                              className="pl-6"
                            >
                              {vehicle.name} ({vehicle.capacity})
                            </SelectItem>
                          ))}
                        </React.Fragment>
                      ))}
                    </SelectContent>
                  </Select>
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="distance_miles">Distance (miles)</Label>
              <Controller
                name="distance_miles"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="distance_miles"
                    type="number"
                    placeholder="Enter distance in miles"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="estimated_duration">Estimated Duration (minutes)</Label>
              <Controller
                name="estimated_duration"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="estimated_duration"
                    type="number"
                    placeholder="Enter duration in minutes"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cargo_weight">Weight (lbs)</Label>
              <Controller
                name="cargo_weight"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="cargo_weight"
                    type="number"
                    placeholder="Enter weight"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cargo_length">Length (ft)</Label>
              <Controller
                name="cargo_length"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="cargo_length"
                    type="number"
                    placeholder="Enter length"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cargo_width">Width (ft)</Label>
              <Controller
                name="cargo_width"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="cargo_width"
                    type="number"
                    placeholder="Enter width"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cargo_height">Height (ft)</Label>
              <Controller
                name="cargo_height"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="cargo_height"
                    type="number"
                    placeholder="Enter height"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cargo_pieces">Number of Pieces</Label>
              <Controller
                name="cargo_pieces"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="cargo_pieces"
                    type="number"
                    placeholder="Enter quantity"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pay_amount">Pay Amount</Label>
              <Controller
                name="pay_amount"
                control={control}
                render={({ field }) => (
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      {...field}
                      id="pay_amount"
                      placeholder="0.00"
                      className="pl-10"
                    />
                  </div>
                )}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Controller
              name="description"
              control={control}
              render={({ field }) => (
                <Textarea
                  {...field}
                  id="description"
                  placeholder="Enter job description and details"
                  rows={4}
                />
              )}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="pickup_location">Pickup Location *</Label>
              <Controller
                name="pickup_location.address"
                control={control}
                render={({ field }) => (
                  <AddressAutocomplete
                    value={field.value}
                    onAddressSelect={(address) => {
                      field.onChange(address.formatted_address);
                      setValue('pickup_location.lat', address.lat);
                      setValue('pickup_location.lng', address.lng);
                    }}
                    placeholder="Start typing pickup address..."
                    error={errors.pickup_location?.address?.message}
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="pickup_contact_phone">Pickup Contact Phone</Label>
              <Controller
                name="pickup_contact_phone"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="pickup_contact_phone"
                    type="tel"
                    placeholder="(555) 123-4567"
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery_location">Delivery Location *</Label>
              <Controller
                name="delivery_location.address"
                control={control}
                render={({ field }) => (
                  <AddressAutocomplete
                    value={field.value}
                    onAddressSelect={(address) => {
                      field.onChange(address.formatted_address);
                      setValue('delivery_location.lat', address.lat);
                      setValue('delivery_location.lng', address.lng);
                    }}
                    placeholder="Start typing delivery address..."
                    error={errors.delivery_location?.address?.message}
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery_contact_phone">Delivery Contact Phone</Label>
              <Controller
                name="delivery_contact_phone"
                control={control}
                render={({ field }) => (
                  <Input
                    {...field}
                    id="delivery_contact_phone"
                    type="tel"
                    placeholder="(555) 123-4567"
                  />
                )}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label>Pickup Date & Time</Label>
              <Controller
                name="pickup_time"
                control={control}
                render={({ field }) => (
                  <div className="space-y-2">
                    <Popover modal={false} open={scheduledDateOpen} onOpenChange={setScheduledDateOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          type="button"
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {field.value ? format(field.value, "PPP") : "Pick a date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => {
                            if (date) {
                              const currentTime = field.value || new Date();
                              date.setHours(currentTime.getHours());
                              date.setMinutes(currentTime.getMinutes());
                              field.onChange(date);
                            }
                            setScheduledDateOpen(false);
                          }}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <Input
                      type="time"
                      value={field.value ? format(field.value, "HH:mm") : ""}
                      onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(':').map(Number);
                        const newDate = field.value ? new Date(field.value) : new Date();
                        newDate.setHours(hours);
                        newDate.setMinutes(minutes);
                        field.onChange(newDate);
                      }}
                      className="w-full"
                    />
                  </div>
                )}
              />
            </div>

            <div className="space-y-2">
              <Label>Delivery Date & Time</Label>
              <Controller
                name="delivery_time"
                control={control}
                render={({ field }) => (
                  <div className="space-y-2">
                    <Popover modal={false} open={deadlineOpen} onOpenChange={setDeadlineOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          type="button"
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {field.value ? format(field.value, "PPP") : "Pick a date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={field.value}
                          onSelect={(date) => {
                            if (date) {
                              const currentTime = field.value || new Date();
                              date.setHours(currentTime.getHours());
                              date.setMinutes(currentTime.getMinutes());
                              field.onChange(date);
                            }
                            setDeadlineOpen(false);
                          }}
                          initialFocus
                          className="pointer-events-auto"
                        />
                      </PopoverContent>
                    </Popover>
                    <Input
                      type="time"
                      value={field.value ? format(field.value, "HH:mm") : ""}
                      onChange={(e) => {
                        const [hours, minutes] = e.target.value.split(':').map(Number);
                        const newDate = field.value ? new Date(field.value) : new Date();
                        newDate.setHours(hours);
                        newDate.setMinutes(minutes);
                        field.onChange(newDate);
                      }}
                      className="w-full"
                    />
                  </div>
                )}
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="pickup_instructions">Pickup Instructions</Label>
              <Controller
                name="pickup_instructions"
                control={control}
                render={({ field }) => (
                  <Textarea
                    {...field}
                    id="pickup_instructions"
                    placeholder="Loading dock info, access codes, special handling..."
                    rows={3}
                  />
                )}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery_instructions">Delivery Instructions</Label>
              <Controller
                name="delivery_instructions"
                control={control}
                render={({ field }) => (
                  <Textarea
                    {...field}
                    id="delivery_instructions"
                    placeholder="Delivery location details, contact info, special requirements..."
                    rows={3}
                  />
                )}
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Controller
              name="signature_required"
              control={control}
              render={({ field }) => (
                <Checkbox
                  id="signature_required"
                  checked={field.value}
                  onCheckedChange={field.onChange}
                />
              )}
            />
            <Label htmlFor="signature_required" className="text-sm font-normal cursor-pointer">
              Signature required upon delivery
            </Label>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={() => reset()}>
              Cancel
            </Button>
            <Button type="submit" disabled={createJobMutation.isPending}>
              {createJobMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Creating...
                </>
              ) : (
                <>
                  <Send className="h-4 w-4 mr-2" />
                  Create Job
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </form>
  );
};

export default JobForm;