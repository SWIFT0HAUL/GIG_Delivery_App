import { Button } from "@/components/ui/button";
import { ArrowRight, Truck, Package, Users } from "lucide-react";
import heroImage from "@/assets/hero-delivery.jpg";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

const Hero = () => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const handlePostJob = () => {
    navigate('/auth');
  };

  const handleFindJobs = () => {
    navigate('/auth');
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-background to-muted">
      <div className="container mx-auto px-4 py-16 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Connect <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Shippers</span> & <span className="bg-gradient-to-r from-accent to-primary bg-clip-text text-transparent">Carriers</span>
              </h1>
              <p className="text-xl text-muted-foreground leading-relaxed">
                Haulee is the professional gig delivery platform that connects shippers, brokers, and carriers. Post jobs, find loads, and grow your logistics business with our comprehensive marketplace.
              </p>
            </div>

            {/* Role Selection CTAs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-6 rounded-lg border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="bg-primary/10 p-2 rounded-lg">
                    <Package className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold">I Need Delivery</h3>
                </div>
                <p className="text-muted-foreground mb-4">Post your delivery jobs and connect with reliable carriers</p>
                <Button variant="gradient" className="w-full" onClick={handlePostJob}>
                  Post a Job <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>

              <div className="p-6 rounded-lg border border-border hover:border-accent/50 transition-all duration-300 hover:shadow-lg">
                <div className="flex items-center space-x-3 mb-3">
                  <div className="bg-accent/10 p-2 rounded-lg">
                    <Truck className="h-6 w-6 text-accent" />
                  </div>
                  <h3 className="text-lg font-semibold">I Deliver Goods</h3>
                </div>
                <p className="text-muted-foreground mb-4">Find profitable delivery jobs in your area</p>
                <Button variant="accent" className="w-full" onClick={handleFindJobs}>
                  Find Jobs <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">10K+</div>
                <div className="text-sm text-muted-foreground">My Jobs</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-accent">5K+</div>
                <div className="text-sm text-muted-foreground">Carriers</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-primary">2K+</div>
                <div className="text-sm text-muted-foreground">Shippers</div>
              </div>
            </div>
          </div>

          {/* Right Column - Image */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <img 
                src={heroImage} 
                alt="Professional delivery truck on highway representing Haulee's logistics network" 
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent"></div>
            </div>
            
            {/* Floating Elements */}
            <div className="absolute -top-6 -right-6 bg-card border border-border rounded-xl p-4 shadow-lg">
              <div className="flex items-center space-x-2">
                <div className="bg-accent/20 p-2 rounded-full">
                  <div className="w-3 h-3 bg-accent rounded-full animate-pulse"></div>
                </div>
                <div>
                  <div className="text-sm font-semibold">Live Jobs</div>
                  <div className="text-xs text-muted-foreground">247 available</div>
                </div>
              </div>
            </div>

            <div className="absolute -bottom-6 -left-6 bg-card border border-border rounded-xl p-4 shadow-lg">
              <div className="flex items-center space-x-2">
                <Users className="h-6 w-6 text-accent" />
                <div>
                  <div className="text-sm font-semibold">Trusted Network</div>
                  <div className="text-xs text-muted-foreground">15K+ members</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;