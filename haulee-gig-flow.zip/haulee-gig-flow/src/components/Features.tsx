import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Shield, 
  MapPin, 
  CreditCard, 
  Clock, 
  Users, 
  BarChart3,
  Bell,
  Smartphone,
  Zap
} from "lucide-react";

const Features = () => {
  const features = [
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Secure Platform",
      description: "End-to-end security with verified users, secure payments, and insurance coverage protection."
    },
    {
      icon: <MapPin className="h-8 w-8" />,
      title: "Real-time Tracking",
      description: "Track your deliveries in real-time with GPS monitoring and automated status updates."
    },
    {
      icon: <CreditCard className="h-8 w-8" />,
      title: "Instant Payments",
      description: "Fast, secure payment processing with multiple payment methods and instant payouts."
    },
    {
      icon: <Clock className="h-8 w-8" />,
      title: "24/7 Support",
      description: "Round-the-clock customer support to help resolve issues and answer questions quickly."
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Verified Network",
      description: "All carriers and shippers are verified with background checks and document validation."
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "Analytics Dashboard",
      description: "Comprehensive analytics and reporting tools to track performance and optimize operations."
    },
    {
      icon: <Bell className="h-8 w-8" />,
      title: "Smart Notifications",
      description: "Intelligent alerts for job matches, delivery updates, and important platform notifications."
    },
    {
      icon: <Smartphone className="h-8 w-8" />,
      title: "Mobile App",
      description: "Full-featured mobile apps for iOS and Android to manage your business on the go."
    },
    {
      icon: <Zap className="h-8 w-8" />,
      title: "Instant Matching",
      description: "AI-powered job matching algorithm connects the right carriers with the right loads."
    }
  ];

  return (
    <section id="features" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Everything You Need to <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Succeed</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our comprehensive platform provides all the tools and features needed to run your logistics business efficiently.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card key={index} className="border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg group">
              <CardHeader className="space-y-4">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-gradient-to-r from-primary/10 to-accent/10 rounded-lg text-primary group-hover:text-accent transition-colors">
                  {feature.icon}
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;