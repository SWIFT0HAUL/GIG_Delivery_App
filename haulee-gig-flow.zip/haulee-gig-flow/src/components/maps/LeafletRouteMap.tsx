import { useEffect, useRef } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';

// Fix for default marker icons in Leaflet
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

// Polyline decoder for encoded routes
function decodePolyline(encoded: string): L.LatLngExpression[] {
  const coords: L.LatLngExpression[] = [];
  let index = 0;
  let lat = 0;
  let lng = 0;

  while (index < encoded.length) {
    let b: number;
    let shift = 0;
    let result = 0;

    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);

    const dlat = (result & 1) !== 0 ? ~(result >> 1) : result >> 1;
    lat += dlat;

    shift = 0;
    result = 0;

    do {
      b = encoded.charCodeAt(index++) - 63;
      result |= (b & 0x1f) << shift;
      shift += 5;
    } while (b >= 0x20);

    const dlng = (result & 1) !== 0 ? ~(result >> 1) : result >> 1;
    lng += dlng;

    coords.push([lat / 1e5, lng / 1e5]);
  }

  return coords;
}

interface Location {
  lat: number;
  lng: number;
  label?: string;
}

interface LeafletRouteMapProps {
  pickup: Location;
  dropoff: Location;
  driverLocation?: Location;
  routePolyline?: string;
  className?: string;
}

export function LeafletRouteMap({
  pickup,
  dropoff,
  driverLocation,
  routePolyline,
  className = 'h-[400px] w-full rounded-lg',
}: LeafletRouteMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const { mapsDarkMode } = useDarkModeSettings();

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize map
    const map = L.map(containerRef.current).setView(
      [pickup.lat, pickup.lng],
      13
    );

    mapRef.current = map;

    // Add tile layer based on dark mode setting
    const tileUrl = mapsDarkMode 
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png'
      : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    
    const attribution = mapsDarkMode
      ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    
    L.tileLayer(tileUrl, {
      attribution,
      maxZoom: 19,
      subdomains: ['a', 'b', 'c'],
    }).addTo(map);

    // Add pickup marker (green)
    const pickupIcon = L.divIcon({
      className: 'custom-div-icon',
      html: `<div class="flex items-center justify-center w-8 h-8 bg-green-500 rounded-full border-2 border-white shadow-lg">
        <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/>
        </svg>
      </div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
    });

    L.marker([pickup.lat, pickup.lng], { icon: pickupIcon })
      .addTo(map)
      .bindPopup(`<strong>Pickup</strong><br>${pickup.label || 'Pickup Location'}`);

    // Add dropoff marker (red)
    const dropoffIcon = L.divIcon({
      className: 'custom-div-icon',
      html: `<div class="flex items-center justify-center w-8 h-8 bg-red-500 rounded-full border-2 border-white shadow-lg">
        <svg class="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"/>
        </svg>
      </div>`,
      iconSize: [32, 32],
      iconAnchor: [16, 32],
    });

    L.marker([dropoff.lat, dropoff.lng], { icon: dropoffIcon })
      .addTo(map)
      .bindPopup(`<strong>Dropoff</strong><br>${dropoff.label || 'Dropoff Location'}`);

    // Add driver location marker (blue) if provided
    if (driverLocation) {
      const driverIcon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div class="flex items-center justify-center w-10 h-10 bg-blue-500 rounded-full border-3 border-white shadow-lg animate-pulse">
          <svg class="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"/>
            <path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v6.05A2.5 2.5 0 0115.95 16H17a1 1 0 001-1v-5a1 1 0 00-.293-.707l-2-2A1 1 0 0015 7h-1z"/>
          </svg>
        </div>`,
        iconSize: [40, 40],
        iconAnchor: [20, 40],
      });

      L.marker([driverLocation.lat, driverLocation.lng], { icon: driverIcon })
        .addTo(map)
        .bindPopup(`<strong>Your Location</strong>`);
    }

    // Decode and display route polyline if provided
    if (routePolyline) {
      try {
        // Simple polyline decoder for LocationIQ/Google encoded polylines
        const decoded = decodePolyline(routePolyline);
        L.polyline(decoded, {
          color: '#3B82F6',
          weight: 4,
          opacity: 0.7,
        }).addTo(map);
      } catch (error) {
        console.warn('Failed to decode polyline:', error);
      }
    }

    // Fit bounds to show all markers
    const bounds = L.latLngBounds([
      [pickup.lat, pickup.lng],
      [dropoff.lat, dropoff.lng],
    ]);
    
    if (driverLocation) {
      bounds.extend([driverLocation.lat, driverLocation.lng]);
    }

    map.fitBounds(bounds, { padding: [50, 50] });

    // Cleanup
    return () => {
      map.remove();
      mapRef.current = null;
    };
  }, [pickup, dropoff, driverLocation, routePolyline]);

  return <div ref={containerRef} className={`${className} relative z-[1]`} />;
}
