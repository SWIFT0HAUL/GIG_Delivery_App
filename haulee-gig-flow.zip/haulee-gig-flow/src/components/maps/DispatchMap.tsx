import React, { useEffect, useRef, useState, forwardRef, useImperativeHandle } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { supabase } from '@/integrations/supabase/client';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';

interface DispatchMapProps {
  unassignedJobs?: any[];
  availableDrivers?: any[];
  selectedJobId?: string | null;
  selectedDriverId?: string | null;
}

export interface DispatchMapRef {
  centerMap: () => void;
}

export const DispatchMap = forwardRef<DispatchMapRef, DispatchMapProps>(({ 
  unassignedJobs = [], 
  availableDrivers = [], 
  selectedJobId,
  selectedDriverId 
}, ref) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<mapboxgl.Marker[]>([]);
  const [mapboxToken, setMapboxToken] = useState<string>('');
  const boundsRef = useRef<mapboxgl.LngLatBounds | null>(null);
  const { mapsDarkMode } = useDarkModeSettings();

  // Expose centerMap method to parent
  useImperativeHandle(ref, () => ({
    centerMap: () => {
      if (map.current && boundsRef.current) {
        map.current.fitBounds(boundsRef.current, { padding: 100, maxZoom: 10, duration: 1000 });
      }
    }
  }));

  // Fetch Mapbox token from edge function
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('get-mapbox-token');
        if (error) throw error;
        if (data?.token) {
          setMapboxToken(data.token);
        }
      } catch (error) {
        console.error('Error fetching Mapbox token:', error);
      }
    };
    fetchToken();
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || !mapboxToken) return;

    mapboxgl.accessToken = mapboxToken;
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: mapsDarkMode ? 'mapbox://styles/mapbox/dark-v11' : 'mapbox://styles/mapbox/light-v11',
      center: [-98.5795, 39.8283], // Center of US
      zoom: 4,
    });

    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
    map.current.addControl(new mapboxgl.FullscreenControl(), 'top-right');

    return () => {
      map.current?.remove();
    };
  }, [mapboxToken]);

  // Update markers for jobs and drivers
  useEffect(() => {
    if (!map.current) return;

    // Clear existing markers
    markers.current.forEach(marker => marker.remove());
    markers.current = [];

    const bounds = new mapboxgl.LngLatBounds();
    let validMarkers = 0;

    // Add job markers (orange pins)
    unassignedJobs.forEach((job) => {
      const pickup = job.pickup_location;
      
      if (pickup?.lng && pickup?.lat) {
        const jobEl = document.createElement('div');
        const isSelected = selectedJobId === job.id;
        jobEl.className = `w-5 h-5 ${isSelected ? 'bg-orange-600 scale-125' : 'bg-orange-500'} rounded-full border-2 border-white shadow-lg transition-all cursor-pointer`;
        jobEl.innerHTML = `<div class="absolute -top-6 -left-3 text-xs font-bold whitespace-nowrap ${isSelected ? 'text-orange-600' : 'text-orange-500'}">📦</div>`;
        
        const jobMarker = new mapboxgl.Marker({ element: jobEl })
          .setLngLat([pickup.lng, pickup.lat])
          .setPopup(
            new mapboxgl.Popup({ offset: 25 })
              .setHTML(`
                <div class="p-2">
                  <p class="font-semibold text-sm">Unassigned Job</p>
                  <p class="text-xs text-gray-600">${job.title || 'Job'}</p>
                  <p class="text-xs">${pickup.address || 'Address'}</p>
                  <p class="text-xs font-mono mt-1">#${job.id.slice(0, 8)}</p>
                  <p class="text-xs font-bold text-green-600 mt-1">$${job.pay_amount || '0'}</p>
                </div>
              `)
          )
          .addTo(map.current!);

        markers.current.push(jobMarker);
        bounds.extend([pickup.lng, pickup.lat]);
        validMarkers++;
      }
    });

    // Add driver markers (blue car icons)
    availableDrivers.forEach((driver) => {
      // Mock driver location (random offset from center)
      const mockLng = -98.5795 + (Math.random() - 0.5) * 10;
      const mockLat = 39.8283 + (Math.random() - 0.5) * 10;

      const driverEl = document.createElement('div');
      const isSelected = selectedDriverId === driver.id;
      driverEl.className = `w-6 h-6 ${isSelected ? 'bg-blue-600 scale-125' : 'bg-blue-500'} rounded-full border-2 border-white shadow-lg transition-all cursor-pointer flex items-center justify-center`;
      driverEl.innerHTML = '<span class="text-white text-xs">🚗</span>';
      
      const driverMarker = new mapboxgl.Marker({ element: driverEl })
        .setLngLat([mockLng, mockLat])
        .setPopup(
          new mapboxgl.Popup({ offset: 25 })
            .setHTML(`
              <div class="p-2">
                <p class="font-semibold text-sm">Available Driver</p>
                <p class="text-xs">${driver.full_name || 'Driver'}</p>
                <p class="text-xs text-gray-600">${driver.email}</p>
                <p class="text-xs mt-1">Current load: <span class="font-bold">3 jobs</span></p>
              </div>
            `)
        )
        .addTo(map.current!);

      markers.current.push(driverMarker);
      bounds.extend([mockLng, mockLat]);
      validMarkers++;
    });

    // Fit map to markers if any valid ones exist
    if (validMarkers > 0) {
      boundsRef.current = bounds;
      map.current!.fitBounds(bounds, { padding: 100, maxZoom: 10 });
    }
  }, [unassignedJobs, availableDrivers, selectedJobId, selectedDriverId]);

  if (!mapboxToken) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-muted rounded-lg">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-full z-[1]">
      <div ref={mapContainer} className="w-full h-full rounded-lg" />
      <div className="absolute bottom-4 left-4 bg-background/95 backdrop-blur-sm rounded-lg p-3 shadow-lg border">
        <div className="flex gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-orange-500"></div>
            <span>Unassigned Jobs</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span>Available Drivers</span>
          </div>
        </div>
      </div>
    </div>
  );
});
