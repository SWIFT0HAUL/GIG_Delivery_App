import React, { useEffect, useRef, useState, forwardRef, useImperativeHandle } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { supabase } from '@/integrations/supabase/client';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';

interface LiveViewMapProps {
  activeJobs?: any[];
  selectedJobId?: string | null;
}

export interface LiveViewMapRef {
  centerMap: () => void;
}

export const LiveViewMap = forwardRef<LiveViewMapRef, LiveViewMapProps>(({ activeJobs = [], selectedJobId }, ref) => {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<mapboxgl.Marker[]>([]);
  const [mapboxToken, setMapboxToken] = useState<string>('');
  const boundsRef = useRef<mapboxgl.LngLatBounds | null>(null);
  const { mapsDarkMode } = useDarkModeSettings();

  // Expose centerMap method to parent
  useImperativeHandle(ref, () => ({
    centerMap: () => {
      if (map.current && boundsRef.current) {
        map.current.fitBounds(boundsRef.current, { padding: 50, maxZoom: 12, duration: 1000 });
      }
    }
  }));

  // Fetch Mapbox token from edge function
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('get-mapbox-token');
        if (error) throw error;
        if (data?.token) {
          setMapboxToken(data.token);
        }
      } catch (error) {
        console.error('Error fetching Mapbox token:', error);
      }
    };
    fetchToken();
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || !mapboxToken) return;

    mapboxgl.accessToken = mapboxToken;
    
    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: mapsDarkMode ? 'mapbox://styles/mapbox/dark-v11' : 'mapbox://styles/mapbox/streets-v12',
      center: [-98.5795, 39.8283], // Center of US
      zoom: 4,
    });

    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');
    map.current.addControl(new mapboxgl.FullscreenControl(), 'top-right');

    return () => {
      map.current?.remove();
    };
  }, [mapboxToken]);

  // Update markers when jobs change
  useEffect(() => {
    if (!map.current || !activeJobs || activeJobs.length === 0) return;

    // Clear existing markers
    markers.current.forEach(marker => marker.remove());
    markers.current = [];

    const bounds = new mapboxgl.LngLatBounds();
    let validMarkers = 0;

    activeJobs.forEach((job) => {
      const pickup = job.pickup_location;
      const delivery = job.delivery_location;

      // Add pickup marker (green)
      if (pickup?.lng && pickup?.lat) {
        const pickupEl = document.createElement('div');
        pickupEl.className = 'w-4 h-4 bg-green-500 rounded-full border-2 border-white shadow-lg';
        
        const pickupMarker = new mapboxgl.Marker({ element: pickupEl })
          .setLngLat([pickup.lng, pickup.lat])
          .setPopup(
            new mapboxgl.Popup({ offset: 25 })
              .setHTML(`
                <div class="p-2">
                  <p class="font-semibold text-sm">Pickup: ${job.title || 'Job'}</p>
                  <p class="text-xs text-gray-600">${pickup.address || 'Address'}</p>
                  <p class="text-xs font-mono mt-1">#${job.id.slice(0, 8)}</p>
                </div>
              `)
          )
          .addTo(map.current!);

        markers.current.push(pickupMarker);
        bounds.extend([pickup.lng, pickup.lat]);
        validMarkers++;
      }

      // Add delivery marker (red)
      if (delivery?.lng && delivery?.lat) {
        const deliveryEl = document.createElement('div');
        deliveryEl.className = 'w-4 h-4 bg-red-500 rounded-full border-2 border-white shadow-lg';
        
        const deliveryMarker = new mapboxgl.Marker({ element: deliveryEl })
          .setLngLat([delivery.lng, delivery.lat])
          .setPopup(
            new mapboxgl.Popup({ offset: 25 })
              .setHTML(`
                <div class="p-2">
                  <p class="font-semibold text-sm">Delivery: ${job.title || 'Job'}</p>
                  <p class="text-xs text-gray-600">${delivery.address || 'Address'}</p>
                  <p class="text-xs font-mono mt-1">#${job.id.slice(0, 8)}</p>
                </div>
              `)
          )
          .addTo(map.current!);

        markers.current.push(deliveryMarker);
        bounds.extend([delivery.lng, delivery.lat]);
        validMarkers++;
      }
    });

    // Fit map to markers if any valid ones exist
    if (validMarkers > 0) {
      boundsRef.current = bounds;
      map.current!.fitBounds(bounds, { padding: 50, maxZoom: 12 });
    }
  }, [activeJobs]);

  // Center on selected job
  useEffect(() => {
    if (!map.current || !selectedJobId || !activeJobs) return;

    const selectedJob = activeJobs.find(job => job.id === selectedJobId);
    if (selectedJob?.pickup_location?.lng && selectedJob?.pickup_location?.lat) {
      map.current.flyTo({
        center: [selectedJob.pickup_location.lng, selectedJob.pickup_location.lat],
        zoom: 12,
        duration: 1000,
      });
    }
  }, [selectedJobId, activeJobs]);

  if (!mapboxToken) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-muted rounded-lg">
        <div className="text-center">
          <p className="text-sm text-muted-foreground">Loading map...</p>
        </div>
      </div>
    );
  }

  return <div ref={mapContainer} className="w-full h-full rounded-lg relative z-[1]" />;
});
