import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';

// Fix for default marker icons in Leaflet
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

interface LeafletTrackingMapProps {
  className?: string;
  showAccuracy?: boolean;
  autoCenter?: boolean;
}

export function LeafletTrackingMap({
  className = 'h-[500px] w-full rounded-lg',
  showAccuracy = true,
  autoCenter = true,
}: LeafletTrackingMapProps) {
  const mapRef = useRef<L.Map | null>(null);
  const markerRef = useRef<L.Marker | null>(null);
  const accuracyCircleRef = useRef<L.Circle | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [mapInitialized, setMapInitialized] = useState(false);
  const { mapsDarkMode } = useDarkModeSettings();

  const driverLocationState = useDriverLocation();
  const { coordinates, isLoading, error, accuracy } = driverLocationState;

  // Initialize map
  useEffect(() => {
    if (!containerRef.current || mapInitialized) return;

    const map = L.map(containerRef.current).setView([37.7749, -122.4194], 13);
    mapRef.current = map;
    setMapInitialized(true);

    // Add tile layer based on dark mode setting
    const tileUrl = mapsDarkMode 
      ? 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}.png'
      : 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    
    const attribution = mapsDarkMode
      ? '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
      : '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';
    
    L.tileLayer(tileUrl, {
      attribution,
      maxZoom: 19,
      subdomains: ['a', 'b', 'c'],
    }).addTo(map);

    // Cleanup
    return () => {
      map.remove();
      mapRef.current = null;
      markerRef.current = null;
      accuracyCircleRef.current = null;
      setMapInitialized(false);
    };
  }, [mapInitialized]);

  // Update driver location on map
  useEffect(() => {
    if (!mapRef.current || !coordinates) return;

    const { lat, lng } = coordinates;

    // Create or update driver marker
    if (!markerRef.current) {
      const driverIcon = L.divIcon({
        className: 'custom-div-icon',
        html: `<div class="flex items-center justify-center w-12 h-12 bg-blue-500 rounded-full border-4 border-white shadow-lg animate-pulse">
          <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 20 20">
            <path d="M8 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM15 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z"/>
            <path d="M3 4a1 1 0 00-1 1v10a1 1 0 001 1h1.05a2.5 2.5 0 014.9 0H10a1 1 0 001-1V5a1 1 0 00-1-1H3zM14 7a1 1 0 00-1 1v6.05A2.5 2.5 0 0115.95 16H17a1 1 0 001-1v-5a1 1 0 00-.293-.707l-2-2A1 1 0 0015 7h-1z"/>
          </svg>
        </div>`,
        iconSize: [48, 48],
        iconAnchor: [24, 48],
      });

      markerRef.current = L.marker([lat, lng], { icon: driverIcon })
        .addTo(mapRef.current)
        .bindPopup('<strong>Your Current Location</strong>');
    } else {
      markerRef.current.setLatLng([lat, lng]);
    }

    // Show/update accuracy circle
    if (showAccuracy && accuracy) {
      if (!accuracyCircleRef.current) {
        accuracyCircleRef.current = L.circle([lat, lng], {
          radius: accuracy,
          color: '#3B82F6',
          fillColor: '#3B82F6',
          fillOpacity: 0.1,
          weight: 1,
        }).addTo(mapRef.current);
      } else {
        accuracyCircleRef.current.setLatLng([lat, lng]);
        accuracyCircleRef.current.setRadius(accuracy);
      }
    }

    // Auto-center map on driver location
    if (autoCenter) {
      mapRef.current.setView([lat, lng], 15, { animate: true });
    }
  }, [coordinates, accuracy, showAccuracy, autoCenter]);

  return (
    <div className="relative z-[1]">
      <div ref={containerRef} className={className} />
      
      {/* Status overlays */}
      {isLoading && (
        <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg px-4 py-2 flex items-center gap-2">
          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-500"></div>
          <span className="text-sm font-medium">Getting your location...</span>
        </div>
      )}

      {error && (
        <div className="absolute top-4 left-4 bg-red-50 border border-red-200 rounded-lg shadow-lg px-4 py-2">
          <span className="text-sm font-medium text-red-700">{error}</span>
        </div>
      )}

      {coordinates && accuracy && (
        <div className="absolute bottom-4 right-4 bg-white rounded-lg shadow-lg px-4 py-2">
          <div className="text-xs text-gray-500">Accuracy</div>
          <div className="text-sm font-semibold">±{Math.round(accuracy)}m</div>
        </div>
      )}
    </div>
  );
}
