import React from 'react';
import { useGranularPermissions } from '@/hooks/useGranularPermissions';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ShieldAlert } from 'lucide-react';

interface PermissionGuardProps {
  permission?: string;
  permissions?: string[];
  requireAll?: boolean;
  fallback?: React.ReactNode;
  showAlert?: boolean;
  children: React.ReactNode;
}

export const PermissionGuard: React.FC<PermissionGuardProps> = ({
  permission,
  permissions = [],
  requireAll = false,
  fallback = null,
  showAlert = false,
  children,
}) => {
  const { hasPermission, hasAnyPermission, hasAllPermissions, loading, isSuperAdmin } = useGranularPermissions();

  if (loading) {
    return null;
  }

  // Super admins always have access
  if (isSuperAdmin) {
    return <>{children}</>;
  }

  const permissionKeys = permission ? [permission] : permissions;
  
  let hasAccess = false;
  if (requireAll) {
    hasAccess = hasAllPermissions(permissionKeys);
  } else {
    hasAccess = hasAnyPermission(permissionKeys);
  }

  if (!hasAccess) {
    if (showAlert) {
      return (
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertDescription>
            You don't have permission to access this feature.
          </AlertDescription>
        </Alert>
      );
    }
    return <>{fallback}</>;
  }

  return <>{children}</>;
};
