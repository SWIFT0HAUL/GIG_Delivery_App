import React from 'react';
import { Button, ButtonProps } from '@/components/ui/button';
import { useGranularPermissions } from '@/hooks/useGranularPermissions';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface ProtectedButtonProps extends ButtonProps {
  permission?: string;
  permissions?: string[];
  requireAll?: boolean;
  hideWhenNoPermission?: boolean;
  tooltipMessage?: string;
}

export const ProtectedButton: React.FC<ProtectedButtonProps> = ({
  permission,
  permissions = [],
  requireAll = false,
  hideWhenNoPermission = false,
  tooltipMessage = 'You do not have permission to perform this action',
  children,
  ...buttonProps
}) => {
  const { hasPermission, hasAnyPermission, hasAllPermissions, loading } = useGranularPermissions();

  if (loading) {
    return null;
  }

  const permissionKeys = permission ? [permission] : permissions;
  
  let hasAccess = false;
  if (requireAll) {
    hasAccess = hasAllPermissions(permissionKeys);
  } else {
    hasAccess = hasAnyPermission(permissionKeys);
  }

  if (!hasAccess && hideWhenNoPermission) {
    return null;
  }

  if (!hasAccess) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            <span>
              <Button {...buttonProps} disabled>
                {children}
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            <p>{tooltipMessage}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    );
  }

  return <Button {...buttonProps}>{children}</Button>;
};
