import React from 'react';
import { useGranularPermissions } from '@/hooks/useGranularPermissions';

interface ResourceGuardProps {
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete' | 'approve' | 'export';
  fallback?: React.ReactNode;
  children: React.ReactNode;
}

export const ResourceGuard: React.FC<ResourceGuardProps> = ({
  resource,
  action,
  fallback = null,
  children,
}) => {
  const {
    canCreate,
    canRead,
    canUpdate,
    canDelete,
    canApprove,
    canExport,
    loading,
  } = useGranularPermissions();

  if (loading) {
    return null;
  }

  let hasAccess = false;

  switch (action) {
    case 'create':
      hasAccess = canCreate(resource);
      break;
    case 'read':
      hasAccess = canRead(resource);
      break;
    case 'update':
      hasAccess = canUpdate(resource);
      break;
    case 'delete':
      hasAccess = canDelete(resource);
      break;
    case 'approve':
      hasAccess = canApprove(resource);
      break;
    case 'export':
      hasAccess = canExport(resource);
      break;
  }

  if (!hasAccess) {
    return <>{fallback}</>;
  }

  return <>{children}</>;
};
