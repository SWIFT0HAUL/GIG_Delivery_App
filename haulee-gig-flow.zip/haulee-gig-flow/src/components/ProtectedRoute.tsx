import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Shield, AlertCircle } from 'lucide-react';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
  requireSuperAdmin?: boolean;
}

export function ProtectedRoute({ 
  children, 
  requireAdmin = false, 
  requireSuperAdmin = false 
}: ProtectedRouteProps) {
  const { user, loading: authLoading } = useAuth();
  const [rbacLoading, setRbacLoading] = useState(true);
  const [isSuperAdminRBAC, setIsSuperAdminRBAC] = useState(false);
  const [isAdminRBAC, setIsAdminRBAC] = useState(false);

  React.useEffect(() => {
    const checkRoles = async () => {
      if (!user?.id) {
        setIsSuperAdminRBAC(false);
        setIsAdminRBAC(false);
        setRbacLoading(false);
        return;
      }
      try {
        const [superRes, adminRes] = await Promise.all([
          supabase.rpc('has_role', { _user_id: user.id, _role: 'super_admin' }),
          supabase.rpc('has_role', { _user_id: user.id, _role: 'admin' }),
        ]);
        setIsSuperAdminRBAC(Boolean(superRes.data));
        setIsAdminRBAC(Boolean(adminRes.data));
      } catch (e) {
        console.error('RBAC role check failed', e);
        setIsSuperAdminRBAC(false);
        setIsAdminRBAC(false);
      } finally {
        setRbacLoading(false);
      }
    };
    setRbacLoading(true);
    checkRoles();
  }, [user?.id]);

  // Show loading while checking authentication and roles
  if (authLoading || rbacLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="flex flex-col items-center justify-center p-6">
            <Loader2 className="h-8 w-8 animate-spin text-primary mb-4" />
            <p className="text-muted-foreground">Verifying access permissions...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Redirect to auth if not authenticated
  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  // Super Admin always has full access - bypass all other checks
  if (isSuperAdminRBAC) {
    console.log('Super Admin access granted:', user.id);
    return <>{children}</>;
  }

  // Check super admin access if required
  if (requireSuperAdmin && !isSuperAdminRBAC) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <span>Access Denied</span>
            </CardTitle>
            <CardDescription>
              You need Super Administrator privileges to access this area.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm">
              Contact your system administrator if you believe you should have access to this feature.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Check admin access if required
  if (requireAdmin && !(isAdminRBAC || isSuperAdminRBAC)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-destructive" />
              <span>Access Denied</span>
            </CardTitle>
            <CardDescription>
              You need Administrator privileges to access this area.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm">
              Contact your system administrator if you believe you should have access to this feature.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Allow access if all checks pass
  return <>{children}</>;
}