import { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const STORAGE_KEY = 'app:lastRoute';

export const RoutePersistence = () => {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  // Persist last meaningful route
  useEffect(() => {
    if (!user) return;
    const path = `${location.pathname}${location.search}${location.hash}`;
    // Avoid storing auth route
    if (!path.startsWith('/auth')) {
      try {
        localStorage.setItem(STORAGE_KEY, path);
      } catch {}
    }
  }, [user, location.pathname, location.search, location.hash]);

  // Restore last route on fresh tab if authenticated
  useEffect(() => {
    if (!user) return;
    const path = location.pathname;
    // Only auto-redirect from root and dashboard, not from /auth
    const isEntry = path === '/' || path === '/dashboard';
    if (isEntry) {
      try {
        const last = localStorage.getItem(STORAGE_KEY);
        if (last && last !== path) {
          navigate(last, { replace: true });
        }
      } catch {}
    }
  }, [user, location.pathname, navigate]);

  return null;
};
