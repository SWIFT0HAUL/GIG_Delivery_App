import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, Building, Users, Calendar, DollarSign, Upload, Eye, BarChart3, Download, Search, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface BrokerPartnership {
  broker_name: string;
  jobs_completed: number;
  total_revenue: number;
  on_time_rate: number;
  partnership_since: string;
  is_active: boolean;
}

interface ContractDocument {
  id: string;
  document_name: string;
  document_type: string;
  file_path: string;
  status: string;
  created_at: string;
}

export function CarrierContracts() {
  const { user } = useAuth();
  const [partnerships, setPartnerships] = useState<BrokerPartnership[]>([]);
  const [documents, setDocuments] = useState<ContractDocument[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<ContractDocument | null>(null);
  const [uploading, setUploading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadDocType, setUploadDocType] = useState('contract');
  const [uploadDocName, setUploadDocName] = useState('');

  useEffect(() => {
    if (user?.id) {
      fetchData();
    }
  }, [user?.id]);

  const fetchData = async () => {
    setLoading(true);
    await Promise.all([
      fetchBrokerPartnerships(),
      fetchContractDocuments()
    ]);
    setLoading(false);
  };

  const fetchBrokerPartnerships = async () => {
    if (!user?.id) return;

    // Fetch jobs and calculate broker partnerships
    const { data: jobs, error } = await supabase
      .from('jobs')
      .select('*')
      .or(`created_by.eq.${user.id},shipper_id.eq.${user.id}`);

    if (error) {
      console.error('Error fetching jobs:', error);
      return;
    }

    // Group jobs by broker/shipper and calculate metrics
    const brokerMap = new Map<string, any>();
    
    jobs?.forEach((job) => {
      const brokerId = job.shipper_id || job.created_by;
      if (!brokerId) return;

      if (!brokerMap.has(brokerId)) {
        brokerMap.set(brokerId, {
          broker_name: `Broker ${brokerId.slice(0, 8)}`,
          jobs_completed: 0,
          total_revenue: 0,
          on_time_jobs: 0,
          total_jobs: 0,
          first_job_date: job.created_at,
          is_active: job.status !== 'cancelled'
        });
      }

      const broker = brokerMap.get(brokerId);
      broker.total_jobs++;
      
      if (job.status === 'completed') {
        broker.jobs_completed++;
        broker.total_revenue += parseFloat(String(job.pay_amount || 0));
        broker.on_time_jobs++; // Simplified - would need delivery time comparison
      }
    });

    const partnershipsList = Array.from(brokerMap.values()).map(broker => ({
      broker_name: broker.broker_name,
      jobs_completed: broker.jobs_completed,
      total_revenue: broker.total_revenue,
      on_time_rate: broker.jobs_completed > 0 
        ? Math.round((broker.on_time_jobs / broker.jobs_completed) * 100) 
        : 0,
      partnership_since: new Date(broker.first_job_date).toLocaleDateString('en-US', { 
        month: 'short', 
        year: 'numeric' 
      }),
      is_active: broker.is_active
    }));

    setPartnerships(partnershipsList);
  };

  const fetchContractDocuments = async () => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('user_documents')
      .select('*')
      .eq('user_id', user.id)
      .in('document_type', ['contract', 'insurance', 'agreement', 'certificate']);

    if (error) {
      console.error('Error fetching documents:', error);
      return;
    }

    setDocuments(data?.map(doc => ({
      id: doc.id,
      document_name: doc.document_name,
      document_type: doc.document_type || 'contract',
      file_path: doc.file_path,
      status: doc.status || 'pending',
      created_at: doc.uploaded_at
    })) || []);
  };

  const handleViewDocument = async (doc: ContractDocument) => {
    if (!doc.file_path) {
      toast.error('Document file path not found');
      return;
    }

    try {
      const { data, error } = await supabase.storage
        .from('user-documents')
        .createSignedUrl(doc.file_path, 3600);

      if (error) throw error;

      if (data?.signedUrl) {
        window.open(data.signedUrl, '_blank');
        toast.success('Opening document...');
      }
    } catch (error) {
      console.error('Error viewing document:', error);
      toast.error('Failed to open document');
    }
  };

  const handleDownloadDocument = async (doc: ContractDocument) => {
    if (!doc.file_path) {
      toast.error('Document file path not found');
      return;
    }

    try {
      const { data, error } = await supabase.storage
        .from('user-documents')
        .download(doc.file_path);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.document_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      toast.success('Document downloaded');
    } catch (error) {
      console.error('Error downloading document:', error);
      toast.error('Failed to download document');
    }
  };

  const handleUploadDocument = async () => {
    if (!uploadFile || !uploadDocName || !user?.id) {
      toast.error('Please fill in all required fields');
      return;
    }

    setUploading(true);

    try {
      const fileExt = uploadFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('user-documents')
        .upload(fileName, uploadFile);

      if (uploadError) throw uploadError;

      const { error: dbError } = await supabase
        .from('user_documents')
        .insert({
          user_id: user.id,
          document_name: uploadDocName,
          document_type: uploadDocType,
          file_path: fileName,
          status: 'pending'
        });

      if (dbError) throw dbError;

      toast.success('Document uploaded successfully');
      setIsUploadOpen(false);
      setUploadFile(null);
      setUploadDocName('');
      setUploadDocType('contract');
      fetchContractDocuments();
    } catch (error) {
      console.error('Error uploading document:', error);
      toast.error('Failed to upload document');
    } finally {
      setUploading(false);
    }
  };

  const handleFindNewBrokers = () => {
    toast.info('Please contact our sales team to find new broker partnerships', {
      description: 'Email: sales@platform.com | Phone: 1-800-BROKERS',
      duration: 5000
    });
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.document_name.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || doc.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Contracts & Brokers</h2>
        <p className="text-muted-foreground">Manage your broker relationships and contracts</p>
      </div>

      <Tabs defaultValue="partnerships" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="partnerships">Broker Partnerships</TabsTrigger>
          <TabsTrigger value="documents">Contract Documents</TabsTrigger>
          <TabsTrigger value="metrics">Performance Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="partnerships" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building className="h-5 w-5" />
                Active Broker Partnerships
              </CardTitle>
              <CardDescription>Your current broker relationships</CardDescription>
            </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">Loading partnerships...</div>
            ) : partnerships.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Building className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No broker partnerships found</p>
                <p className="text-sm">Complete jobs to establish broker relationships</p>
              </div>
            ) : (
              <div className="space-y-4">
                {partnerships.filter(p => p.is_active).map((partnership, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        idx % 3 === 0 ? 'bg-blue-100' : idx % 3 === 1 ? 'bg-green-100' : 'bg-purple-100'
                      }`}>
                        <Building className={`h-5 w-5 ${
                          idx % 3 === 0 ? 'text-blue-600' : idx % 3 === 1 ? 'text-green-600' : 'text-purple-600'
                        }`} />
                      </div>
                      <div>
                        <p className="font-medium">{partnership.broker_name}</p>
                        <p className="text-sm text-muted-foreground">
                          Partnership since {partnership.partnership_since}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge>Active</Badge>
                      <p className="text-sm text-muted-foreground mt-1">
                        {partnership.jobs_completed} jobs completed
                      </p>
                    </div>
                  </div>
                ))}
                
                {partnerships.filter(p => !p.is_active).map((partnership, idx) => (
                  <div key={`inactive-${idx}`} className="flex items-center justify-between p-4 border rounded-lg opacity-60">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                        <Building className="h-5 w-5 text-gray-600" />
                      </div>
                      <div>
                        <p className="font-medium">{partnership.broker_name}</p>
                        <p className="text-sm text-muted-foreground">
                          Partnership since {partnership.partnership_since}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline">Inactive</Badge>
                      <p className="text-sm text-muted-foreground mt-1">
                        {partnership.jobs_completed} jobs completed
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <Button 
              variant="outline" 
              className="w-full mt-4"
              onClick={handleFindNewBrokers}
            >
              <Search className="h-4 w-4 mr-2" />
              Find New Brokers
            </Button>
          </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="documents" className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Contract Documents
                  </CardTitle>
                  <CardDescription>Important contract and legal documents</CardDescription>
                </div>
                <Button onClick={() => setIsUploadOpen(true)}>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload Document
                </Button>
              </div>
              <div className="flex gap-4 mt-4">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search documents..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center py-8 text-muted-foreground">Loading documents...</div>
              ) : filteredDocuments.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>{documents.length === 0 ? 'No contract documents uploaded' : 'No documents match your search'}</p>
                  <p className="text-sm">{documents.length === 0 ? 'Upload your contracts and certificates' : 'Try adjusting your filters'}</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredDocuments.map((doc) => (
                  <div key={doc.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <FileText className="h-5 w-5 text-blue-600" />
                      <div>
                        <p className="font-medium">{doc.document_name}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(doc.created_at).toLocaleDateString('en-US', {
                            month: 'short',
                            day: 'numeric',
                            year: 'numeric'
                          })}
                        </p>
                      </div>
                    </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={doc.status === 'approved' ? 'default' : doc.status === 'pending' ? 'secondary' : 'destructive'}>
                          {doc.status}
                        </Badge>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleViewDocument(doc)}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleDownloadDocument(doc)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                  </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metrics" className="space-y-6 mt-6">
          <Card>
        <CardHeader>
          <CardTitle>Performance Metrics with Brokers</CardTitle>
          <CardDescription>Your performance statistics with each broker partner</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">Loading metrics...</div>
          ) : partnerships.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <BarChart3 className="h-12 w-12 mx-auto mb-2 opacity-50" />
              <p>No performance data available</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {partnerships.filter(p => p.jobs_completed > 0).slice(0, 3).map((partnership, idx) => (
                <div key={idx} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-medium">{partnership.broker_name}</h4>
                    <Badge variant={idx === 0 ? 'default' : 'secondary'}>
                      {idx === 0 ? 'Top Partner' : partnership.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Jobs Completed:</span>
                      <span className="font-medium">{partnership.jobs_completed}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>On-Time Delivery:</span>
                      <span className={`font-medium ${
                        partnership.on_time_rate >= 95 ? 'text-green-600' : 
                        partnership.on_time_rate >= 90 ? 'text-yellow-600' : 
                        'text-red-600'
                      }`}>
                        {partnership.on_time_rate}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Total Revenue:</span>
                      <span className="font-medium">
                        ${partnership.total_revenue.toLocaleString('en-US', { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Avg Job Value:</span>
                      <span className="font-medium">
                        ${(partnership.total_revenue / partnership.jobs_completed).toLocaleString('en-US', { maximumFractionDigits: 0 })}
                      </span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span>Rating:</span>
                      <span className="font-medium">
                        {'⭐'.repeat(Math.min(5, Math.floor(partnership.on_time_rate / 20)))}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            )}
          </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Upload Document Dialog */}
      <Dialog open={isUploadOpen} onOpenChange={setIsUploadOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Upload Contract Document</DialogTitle>
            <DialogDescription>
              Upload contracts, certificates, and other important documents
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="docName">Document Name *</Label>
              <Input
                id="docName"
                placeholder="e.g., Broker Agreement 2024"
                value={uploadDocName}
                onChange={(e) => setUploadDocName(e.target.value)}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="docType">Document Type *</Label>
              <Select value={uploadDocType} onValueChange={setUploadDocType}>
                <SelectTrigger id="docType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="contract">Contract</SelectItem>
                  <SelectItem value="insurance">Insurance</SelectItem>
                  <SelectItem value="agreement">Agreement</SelectItem>
                  <SelectItem value="certificate">Certificate</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="file">File *</Label>
              <div className="flex items-center gap-2">
                <Input
                  id="file"
                  type="file"
                  accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
                  onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                />
                {uploadFile && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setUploadFile(null)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Accepted formats: PDF, DOC, DOCX, JPG, PNG (max 10MB)
              </p>
            </div>

            {uploadFile && (
              <div className="p-3 bg-muted rounded-lg">
                <div className="flex items-center gap-2">
                  <FileText className="h-5 w-5 text-muted-foreground" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{uploadFile.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(uploadFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2">
            <Button
              variant="outline"
              onClick={() => {
                setIsUploadOpen(false);
                setUploadFile(null);
                setUploadDocName('');
                setUploadDocType('contract');
              }}
              disabled={uploading}
            >
              Cancel
            </Button>
            <Button
              onClick={handleUploadDocument}
              disabled={uploading || !uploadFile || !uploadDocName}
            >
              {uploading ? 'Uploading...' : 'Upload'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}