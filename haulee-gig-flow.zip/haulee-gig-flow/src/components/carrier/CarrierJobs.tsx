import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { MapPin, Clock, DollarSign, Package, Truck, Calendar, FileText, AlertCircle, Loader2, ChevronDown, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { useDispatch } from '@/contexts/DispatchContext';
import { useQuery } from '@tanstack/react-query';

interface JobDetails {
  id: string;
  title: string;
  price: string;
  distance: string;
  duration: string;
  cargo: string;
  pickup: string;
  pickupTime: string;
  delivery: string;
  deliveryTime: string;
  requirements: string[];
  description?: string;
  priority?: string;
  vehicleType?: string;
  weight?: string;
  numberOfPieces?: number;
  specialInstructions?: string;
  brokerNotes?: string;
  pickupContactName?: string;
  pickupContactPhone?: string;
  deliveryContactName?: string;
  deliveryContactPhone?: string;
  temperatureRequirements?: string;
  hazmatDetails?: string;
}

const parseDurationToMinutes = (input: string): number => {
  const str = input.trim().toLowerCase();
  const num = parseFloat(str);
  if (isNaN(num)) return 0;
  if (str.includes('hour')) return Math.round(num * 60);
  if (str.includes('min')) return Math.round(num);
  return Math.round(num);
};

export function CarrierJobs() {
  const { user } = useAuth();
  const { addJobToDispatch, assignedJobs } = useDispatch();
  const [selectedJob, setSelectedJob] = useState<JobDetails | null>(null);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isAccepting, setIsAccepting] = useState(false);
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [trackingJob, setTrackingJob] = useState<any>(null);
  const [acceptedJobs, setAcceptedJobs] = useState<JobDetails[]>([]);
  const [activeTab, setActiveTab] = useState("available");
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState<string>('');
  const [jobToCancel, setJobToCancel] = useState<string | null>(null);
  const [expandedJobs, setExpandedJobs] = useState<Set<string>>(new Set());
  const [isDispatchDialogOpen, setIsDispatchDialogOpen] = useState(false);
  const [jobToDispatch, setJobToDispatch] = useState<string | null>(null);
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const [isDispatching, setIsDispatching] = useState(false);

  // Fetch available jobs from database
  const { data: dbJobs, isLoading, error } = useQuery({
    queryKey: ['carrier-available-jobs', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'posted')
        .or(`carrier_id.is.null,carrier_id.eq.${user?.id}`)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    refetchInterval: 10000, // Refetch every 10 seconds
  });

  // Fetch unassigned jobs (accepted by carrier but not assigned to driver)
  const { data: dbUnassignedJobs, isLoading: isLoadingUnassigned } = useQuery({
    queryKey: ['carrier-unassigned-jobs', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'claimed')
        .eq('carrier_id', user.id)
        .is('assigned_driver_id', null)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
    refetchInterval: 10000,
  });

  // Fetch assigned jobs (status = 'assigned') with driver info
  const { data: dbAssignedJobs, isLoading: isLoadingAssigned } = useQuery({
    queryKey: ['carrier-assigned-jobs', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          driver:profiles!jobs_assigned_driver_id_fkey(full_name, email)
        `)
        .eq('status', 'assigned')
        .eq('carrier_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
    refetchInterval: 10000,
  });

  // Fetch pending jobs (status = 'on_hold') with driver info
  const { data: dbPendingJobs, isLoading: isLoadingPending } = useQuery({
    queryKey: ['carrier-pending-jobs', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          driver:profiles!jobs_assigned_driver_id_fkey(full_name, email)
        `)
        .eq('status', 'on_hold')
        .eq('carrier_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
    refetchInterval: 10000,
  });

  // Fetch completed jobs (status = 'completed') with driver info
  const { data: dbCompletedJobs, isLoading: isLoadingCompleted } = useQuery({
    queryKey: ['carrier-completed-jobs', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          driver:profiles!jobs_assigned_driver_id_fkey(full_name, email)
        `)
        .eq('status', 'completed')
        .eq('carrier_id', user.id)
        .order('completed_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
    refetchInterval: 10000,
  });

  // Fetch available drivers for the carrier (via carrier_drivers link table)
  const { data: availableDrivers, isLoading: isLoadingDrivers } = useQuery({
    queryKey: ['carrier-drivers', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];

      // 1) Get driver ids linked to this carrier
      const { data: links, error: linkErr } = await supabase
        .from('carrier_drivers')
        .select('driver_id')
        .eq('carrier_id', user.id);

      if (linkErr) {
        console.error('Error fetching carrier_drivers:', linkErr);
        return [];
      }

      const ids = (links || []).map((l: any) => l.driver_id).filter(Boolean);
      if (ids.length === 0) return [];

      // 2) Fetch driver profiles using role_key
      const { data: drivers, error: profErr } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .in('id', ids)
        .eq('role_key', 'driver')
        .eq('is_active', true);

      if (profErr) {
        console.error('Error fetching driver profiles:', profErr);
        return [];
      }

      return drivers || [];
    },
    enabled: !!user?.id,
    refetchInterval: 30000,
    staleTime: 10000,
  });

  // Transform database jobs to JobDetails format
  const availableJobs: JobDetails[] = (dbJobs || []).map((job) => {
    const pickupLoc = job.pickup_location as any;
    const deliveryLoc = job.delivery_location as any;
    const cargoDetails = job.cargo_details as any;
    
    // Build requirements array from actual job data
    const requirements: string[] = [];
    
    if (job.is_hazmat) {
      requirements.push('Hazmat Required');
    }
    
    if (job.signature_required) {
      requirements.push('Signature Required');
    }
    
    if (job.temperature_requirements) {
      requirements.push(`Temperature: ${job.temperature_requirements}`);
    }
    
    if (job.required_certifications && Array.isArray(job.required_certifications) && job.required_certifications.length > 0) {
      requirements.push(...job.required_certifications);
    }
    
    if (job.trailer_type) {
      requirements.push(job.trailer_type);
    }
    
    return {
      id: job.id,
      title: job.title || 'Untitled Job',
      price: `$${job.pay_amount?.toFixed(2) || '0.00'}`,
      distance: job.distance_miles ? `${job.distance_miles} miles` : 'N/A',
      duration: job.estimated_duration ? `${Math.round(job.estimated_duration / 60)} hours` : 'N/A',
      cargo: cargoDetails?.description || cargoDetails?.vehicle_type || 'General Cargo',
      pickup: pickupLoc?.address || `${pickupLoc?.city}, ${pickupLoc?.state}` || 'Pickup Location',
      pickupTime: job.pickup_time ? new Date(job.pickup_time).toLocaleString() : 'TBD',
      delivery: deliveryLoc?.address || `${deliveryLoc?.city}, ${deliveryLoc?.state}` || 'Delivery Location',
      deliveryTime: job.delivery_time ? new Date(job.delivery_time).toLocaleString() : 'TBD',
      requirements: requirements.length > 0 ? requirements : ['Standard Requirements'],
      description: job.description || 'No additional details provided.',
      priority: job.priority,
      vehicleType: cargoDetails?.vehicle_type || job.equipment_type || 'Standard',
      weight: cargoDetails?.weight ? `${cargoDetails.weight} lbs` : 'N/A',
      numberOfPieces: cargoDetails?.pieces || cargoDetails?.quantity,
      specialInstructions: job.special_instructions,
      brokerNotes: job.broker_notes,
      pickupContactName: job.pickup_contact_name,
      pickupContactPhone: job.pickup_contact_phone,
      deliveryContactName: job.delivery_contact_name,
      deliveryContactPhone: job.delivery_contact_phone,
      temperatureRequirements: job.temperature_requirements,
      hazmatDetails: job.hazmat_details,
    };
  });

  // Helper function to transform database jobs to JobDetails format
  const transformJobToDetails = (job: any): JobDetails => {
    const pickupLoc = job.pickup_location as any;
    const deliveryLoc = job.delivery_location as any;
    const cargoDetails = job.cargo_details as any;
    
    const requirements: string[] = [];
    
    if (job.is_hazmat) {
      requirements.push('Hazmat Required');
    }
    
    if (job.signature_required) {
      requirements.push('Signature Required');
    }
    
    if (job.temperature_requirements) {
      requirements.push(`Temperature: ${job.temperature_requirements}`);
    }
    
    if (job.required_certifications && Array.isArray(job.required_certifications) && job.required_certifications.length > 0) {
      requirements.push(...job.required_certifications);
    }
    
    if (job.trailer_type) {
      requirements.push(job.trailer_type);
    }
    
    return {
      id: job.id,
      title: job.title || 'Untitled Job',
      price: `$${job.pay_amount?.toFixed(2) || '0.00'}`,
      distance: job.distance_miles ? `${job.distance_miles} miles` : 'N/A',
      duration: job.estimated_duration ? `${Math.round(job.estimated_duration / 60)} hours` : 'N/A',
      cargo: cargoDetails?.description || cargoDetails?.vehicle_type || 'General Cargo',
      pickup: pickupLoc?.address || `${pickupLoc?.city}, ${pickupLoc?.state}` || 'Pickup Location',
      pickupTime: job.pickup_time ? new Date(job.pickup_time).toLocaleString() : 'TBD',
      delivery: deliveryLoc?.address || `${deliveryLoc?.city}, ${deliveryLoc?.state}` || 'Delivery Location',
      deliveryTime: job.delivery_time ? new Date(job.delivery_time).toLocaleString() : 'TBD',
      requirements: requirements.length > 0 ? requirements : ['Standard Requirements'],
      description: job.description || 'No additional details provided.',
      priority: job.priority,
      vehicleType: cargoDetails?.vehicle_type || job.equipment_type || 'Standard',
      weight: cargoDetails?.weight ? `${cargoDetails.weight} lbs` : 'N/A',
      numberOfPieces: cargoDetails?.pieces || cargoDetails?.quantity,
      specialInstructions: job.special_instructions,
      brokerNotes: job.broker_notes,
      pickupContactName: job.pickup_contact_name,
      pickupContactPhone: job.pickup_contact_phone,
      deliveryContactName: job.delivery_contact_name,
      deliveryContactPhone: job.delivery_contact_phone,
      temperatureRequirements: job.temperature_requirements,
      hazmatDetails: job.hazmat_details,
    };
  };

  // Transform unassigned jobs to JobDetails format
  const unassignedJobsList: JobDetails[] = (dbUnassignedJobs || []).map(transformJobToDetails);
  
  // Transform assigned jobs to JobDetails format
  const assignedJobsList: JobDetails[] = (dbAssignedJobs || []).map(transformJobToDetails);
  
  // Transform pending jobs to JobDetails format
  const pendingJobsList: JobDetails[] = (dbPendingJobs || []).map(transformJobToDetails);
  
  // Transform completed jobs to JobDetails format
  const completedJobsList: JobDetails[] = (dbCompletedJobs || []).map(transformJobToDetails);

  const handleViewDetails = (job: JobDetails) => {
    setSelectedJob(job);
    setIsDetailsOpen(true);
  };

  const handleAcceptJob = async (job: JobDetails) => {
    if (!user?.id) {
      toast.error('Please sign in to accept jobs');
      return;
    }

    setIsAccepting(true);
    try {
      // Accept job - assign carrier and set to scheduled (valid transition from 'posted')
      const { error: updateError } = await supabase
        .from('jobs')
        .update({
          carrier_id: user.id,
          status: 'claimed',
          accepted_at: new Date().toISOString()
        })
        .eq('id', job.id);

      if (updateError) {
        console.error('Job assignment error:', updateError);
        throw new Error(updateError.message || 'Failed to accept job');
      }

      toast.success('Job accepted successfully!', {
        description: `You have accepted "${job.title}". Check the Assigned Jobs tab.`,
      });
      
      // Add job to Dispatch Center
      addJobToDispatch({
        id: job.id,
        title: job.title,
        pickup: job.pickup,
        delivery: job.delivery,
        distance: job.distance,
        duration: job.duration,
        cargo: job.cargo,
        price: job.price,
        priority: 'medium',
        deadline: job.duration,
      });
      
      // Update local UI state
      setAcceptedJobs((prev) => [...prev, job]);
      setActiveTab('assigned');
      setIsDetailsOpen(false);
    } catch (error: any) {
      console.error('Error accepting job:', error);
      toast.error('Failed to accept job', {
        description: error.message || 'Please try again later.',
      });
    } finally {
      setIsAccepting(false);
    }
  };

  const handleViewAssignedDetails = (job: any) => {
    setSelectedJob({
      id: job.id,
      title: job.title,
      price: job.price,
      distance: job.distance,
      duration: job.duration,
      cargo: job.cargo,
      pickup: job.pickup,
      pickupTime: 'Scheduled',
      delivery: job.delivery,
      deliveryTime: 'Estimated',
      requirements: [],
      description: `Assigned to: ${job.assignedDriver}`,
    });
    setIsDetailsOpen(true);
  };

  const handleTrackVehicle = (job: any) => {
    setTrackingJob(job);
    setIsTrackingOpen(true);
  };

  const openCancelDialog = (jobId: string) => {
    setJobToCancel(jobId);
    setCancelReason('');
    setIsCancelDialogOpen(true);
  };

  const handleCancelJob = async () => {
    if (!cancelReason) {
      toast.error('Please select a cancellation reason');
      return;
    }

    if (!jobToCancel) return;

    try {
      // Carrier cancellation should set to 'posted'
      const { error } = await supabase
        .from('jobs')
        .update({ 
          status: 'posted',
          carrier_id: null,
          accepted_at: null
        })
        .eq('id', jobToCancel);

      if (error) throw error;

      toast.success('Job cancelled successfully', {
        description: 'The job has been returned to the available jobs pool.',
      });
      
      // Remove from local state
      setAcceptedJobs((prev) => prev.filter((j) => j.id !== jobToCancel));
      setIsCancelDialogOpen(false);
      setJobToCancel(null);
      setCancelReason('');
    } catch (error: any) {
      console.error('Error cancelling job:', error);
      toast.error('Failed to cancel job', {
        description: error.message || 'Please try again later.',
      });
    }
  };

  const toggleJobExpansion = (jobId: string) => {
    setExpandedJobs((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(jobId)) {
        newSet.delete(jobId);
      } else {
        newSet.add(jobId);
      }
      return newSet;
    });
  };

  const openDispatchDialog = (jobId: string) => {
    setJobToDispatch(jobId);
    setSelectedDriver('');
    setIsDispatchDialogOpen(true);
  };

  const handleDispatchJob = async () => {
    if (!selectedDriver || !jobToDispatch) {
      toast.error('Please select a driver');
      return;
    }

    setIsDispatching(true);
    try {
      // Get job details for notification
      const { data: job } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', jobToDispatch)
        .single();

      // Update job with assigned driver
      const { error: jobError } = await supabase
        .from('jobs')
        .update({
          assigned_driver_id: selectedDriver,
          status: 'assigned',
          assigned_at: new Date().toISOString()
        })
        .eq('id', jobToDispatch);

      if (jobError) throw jobError;

      // Create job assignment record
      const { error: assignmentError } = await supabase
        .from('carrier_job_assignments')
        .insert({
          job_id: jobToDispatch,
          carrier_id: user?.id,
          driver_id: selectedDriver,
          status: 'assigned',
          assigned_at: new Date().toISOString()
        });

      if (assignmentError) {
        console.error('Error creating assignment record:', assignmentError);
        // Don't fail the whole operation if assignment record fails
      }

      // Send notification to driver
      if (job) {
        const pickupAddr = (job.pickup_location as any)?.address || 'Pickup location';
        const deliveryAddr = (job.delivery_location as any)?.address || 'Delivery location';
        
        await supabase
          .from('notifications')
          .insert({
            user_id: selectedDriver,
            title: 'New Job Assigned',
            message: `You have been assigned to job: ${job.title || 'Delivery Job'}\nPickup: ${pickupAddr}\nDelivery: ${deliveryAddr}\nPay: $${job.pay_amount || 'N/A'}`,
            type: 'system',
            link: '/driver-dashboard/my-jobs',
            metadata: {
              job_id: jobToDispatch,
              status: 'assigned',
              carrier_id: user?.id
            }
          });
      }

      // Refetch all job queries to update UI
      await Promise.all([
        supabase.from('jobs').select('count').eq('id', jobToDispatch),
        // This will trigger React Query refetches
      ]);

      toast.success('Job dispatched to driver successfully!');
      setIsDispatchDialogOpen(false);
      setJobToDispatch(null);
      setSelectedDriver('');
      
      // Force refetch queries
      window.location.reload();
    } catch (error: any) {
      console.error('Error dispatching job:', error);
      toast.error('Failed to dispatch job', {
        description: error.message || 'Please try again later.',
      });
    } finally {
      setIsDispatching(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Jobs / Shipments</h2>
        <p className="text-muted-foreground">Manage your fleet assignments and deliveries</p>
      </div>

      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedJob?.title}</DialogTitle>
            <DialogDescription>
              {selectedJob?.description?.includes('Assigned to:') 
                ? 'Assigned job details' 
                : 'Review job details before accepting'}
            </DialogDescription>
          </DialogHeader>
          
          {selectedJob && (
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-primary/5 rounded-lg">
                <span className="text-sm font-medium">Payment</span>
                <span className="text-2xl font-bold text-primary">{selectedJob.price}</span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Distance</p>
                    <p className="text-sm font-medium">{selectedJob.distance}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="text-sm font-medium">{selectedJob.duration}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Truck className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Vehicle Type</p>
                    <p className="text-sm font-medium">{selectedJob.vehicleType}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Package className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Weight</p>
                    <p className="text-sm font-medium">{selectedJob.weight}</p>
                  </div>
                </div>
              </div>

              {selectedJob.numberOfPieces && (
                <div className="p-3 bg-muted/50 rounded-lg">
                  <p className="text-sm"><span className="font-medium">Number of Pieces:</span> {selectedJob.numberOfPieces}</p>
                </div>
              )}

              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-green-600" />
                    <h4 className="font-semibold">Pickup Location</h4>
                  </div>
                  <p className="text-sm">{selectedJob.pickup}</p>
                  <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>{selectedJob.pickupTime}</span>
                  </div>
                  {selectedJob.pickupContactName && (
                    <div className="mt-3 pt-3 border-t space-y-1">
                      <p className="text-sm"><span className="font-medium">Contact:</span> {selectedJob.pickupContactName}</p>
                      {selectedJob.pickupContactPhone && (
                        <p className="text-sm"><span className="font-medium">Phone:</span> {selectedJob.pickupContactPhone}</p>
                      )}
                    </div>
                  )}
                </div>

                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <MapPin className="h-4 w-4 text-red-600" />
                    <h4 className="font-semibold">Delivery Location</h4>
                  </div>
                  <p className="text-sm">{selectedJob.delivery}</p>
                  <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                    <Calendar className="h-3 w-3" />
                    <span>{selectedJob.deliveryTime}</span>
                  </div>
                  {selectedJob.deliveryContactName && (
                    <div className="mt-3 pt-3 border-t space-y-1">
                      <p className="text-sm"><span className="font-medium">Contact:</span> {selectedJob.deliveryContactName}</p>
                      {selectedJob.deliveryContactPhone && (
                        <p className="text-sm"><span className="font-medium">Phone:</span> {selectedJob.deliveryContactPhone}</p>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {selectedJob.description && (
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="h-4 w-4" />
                    <h4 className="font-semibold">Job Description</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">{selectedJob.description}</p>
                </div>
              )}

              <div>
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="h-4 w-4" />
                  <h4 className="font-semibold">Requirements</h4>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.requirements.map((req, idx) => (
                    <Badge key={idx} variant="outline">{req}</Badge>
                  ))}
                </div>
              </div>

              {selectedJob.specialInstructions && (
                <div className="p-4 border rounded-lg bg-amber-50 dark:bg-amber-950/20">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="h-4 w-4 text-amber-600" />
                    <h4 className="font-semibold">Special Instructions</h4>
                  </div>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedJob.specialInstructions}</p>
                </div>
              )}

              {selectedJob.brokerNotes && (
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <FileText className="h-4 w-4" />
                    <h4 className="font-semibold">Broker Notes</h4>
                  </div>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedJob.brokerNotes}</p>
                </div>
              )}

              {selectedJob.temperatureRequirements && (
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold mb-1 text-sm">Temperature Requirements</h4>
                  <p className="text-sm text-muted-foreground">{selectedJob.temperatureRequirements}</p>
                </div>
              )}

              {selectedJob.hazmatDetails && (
                <div className="p-4 border rounded-lg bg-red-50 dark:bg-red-950/20">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-4 w-4 text-red-600" />
                    <h4 className="font-semibold">Hazmat Details</h4>
                  </div>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{selectedJob.hazmatDetails}</p>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button
                  variant="outline"
                  onClick={() => setIsDetailsOpen(false)}
                  className="flex-1"
                >
                  Close
                </Button>
                {!selectedJob?.description?.includes('Assigned to:') && (
                  <Button
                    onClick={() => handleAcceptJob(selectedJob)}
                    disabled={isAccepting}
                    className="flex-1"
                  >
                    {isAccepting ? 'Accepting...' : 'Accept Job'}
                  </Button>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={isTrackingOpen} onOpenChange={setIsTrackingOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-2xl">Track Vehicle</DialogTitle>
            <DialogDescription>
              Real-time tracking for {trackingJob?.title}
            </DialogDescription>
          </DialogHeader>
          
          {trackingJob && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Truck className="h-5 w-5 text-primary" />
                    <h4 className="font-semibold">Driver Information</h4>
                  </div>
                  <p className="text-sm"><span className="font-medium">Driver:</span> {trackingJob.assignedDriver}</p>
                  <p className="text-sm"><span className="font-medium">Vehicle:</span> Truck #{trackingJob.id}</p>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Package className="h-5 w-5 text-primary" />
                    <h4 className="font-semibold">Shipment Details</h4>
                  </div>
                  <p className="text-sm"><span className="font-medium">Cargo:</span> {trackingJob.cargo}</p>
                  <p className="text-sm"><span className="font-medium">Distance:</span> {trackingJob.distance}</p>
                </div>
              </div>

              <div className="border rounded-lg p-4 space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Route Details
                </h4>
                <div className="space-y-2">
                  <div className="flex items-start gap-3">
                    <div className="mt-1 h-3 w-3 rounded-full bg-green-500" />
                    <div>
                      <p className="font-medium">Pickup Location</p>
                      <p className="text-sm text-muted-foreground">{trackingJob.pickup}</p>
                    </div>
                  </div>
                  <div className="ml-1.5 h-8 w-0.5 bg-border" />
                  <div className="flex items-start gap-3">
                    <div className="mt-1 h-3 w-3 rounded-full bg-red-500" />
                    <div>
                      <p className="font-medium">Delivery Location</p>
                      <p className="text-sm text-muted-foreground">{trackingJob.delivery}</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-8 text-center border-2 border-dashed">
                <MapPin className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm font-medium mb-1">Live Tracking Map</p>
                <p className="text-xs text-muted-foreground">
                  Real-time GPS tracking will be displayed here
                </p>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsTrackingOpen(false)}
                  className="flex-1"
                >
                  Close
                </Button>
                <Button
                  onClick={() => {
                    toast.info('Driver contact feature coming soon');
                  }}
                  className="flex-1"
                >
                  Contact Driver
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList>
          <TabsTrigger value="available">Available Jobs</TabsTrigger>
          <TabsTrigger value="unassigned">
            Unassigned Jobs
            {unassignedJobsList.length > 0 && (
              <Badge variant="destructive" className="ml-2">{unassignedJobsList.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="assigned">Assigned Jobs</TabsTrigger>
          <TabsTrigger value="pending">Pending Jobs</TabsTrigger>
          <TabsTrigger value="completed">Completed Jobs</TabsTrigger>
        </TabsList>

        <TabsContent value="available" className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2 text-muted-foreground">Loading available jobs...</span>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center p-8 text-destructive">
              <AlertCircle className="h-5 w-5 mr-2" />
              Failed to load jobs. Please try again.
            </div>
          ) : availableJobs.length === 0 ? (
            <div className="text-center p-8 text-muted-foreground">
              <Package className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No available jobs at the moment.</p>
              <p className="text-sm">Check back later for new opportunities.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {availableJobs.map((job) => {
                const isExpanded = expandedJobs.has(job.id);
                return (
                  <Card 
                    key={job.id} 
                    className="cursor-pointer transition-all hover:shadow-md"
                    onClick={() => toggleJobExpansion(job.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <ChevronDown 
                            className={`h-5 w-5 text-muted-foreground transition-transform duration-200 flex-shrink-0 mt-1 ${
                              isExpanded ? 'rotate-180' : ''
                            }`}
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <CardTitle className="text-lg">{job.title}</CardTitle>
                              {job.priority && (
                                <Badge 
                                  variant={
                                    job.priority === 'pickup_now' ? 'destructive' : 
                                    job.priority === 'scheduled' ? 'default' : 
                                    'secondary'
                                  }
                                  className="text-xs"
                                >
                                  {job.priority === 'pickup_now' ? '🚀 Pickup Now' : 
                                   job.priority === 'scheduled' ? '📅 Scheduled' : 
                                   '🗺️ Route'}
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap mb-2">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                {job.distance}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {job.duration}
                              </span>
                              <span className="flex items-center gap-1">
                                <Package className="h-3 w-3" />
                                {job.cargo}
                              </span>
                            </div>
                            
                            {/* Show locations in collapsed state */}
                            {!isExpanded && (
                              <div className="space-y-1 text-sm">
                                <div className="flex items-start gap-2">
                                  <MapPin className="h-3 w-3 text-green-600 mt-0.5 flex-shrink-0" />
                                  <span className="text-muted-foreground truncate">{job.pickup}</span>
                                </div>
                                <div className="flex items-start gap-2">
                                  <MapPin className="h-3 w-3 text-red-600 mt-0.5 flex-shrink-0" />
                                  <span className="text-muted-foreground truncate">{job.delivery}</span>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {/* Price and Accept button row */}
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <Badge variant="default" className="text-base px-3 py-1 whitespace-nowrap">
                            {job.price}
                          </Badge>
                          {!isExpanded && (
                            <Button 
                              size="sm"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleAcceptJob(job);
                              }}
                              disabled={isAccepting}
                              className="whitespace-nowrap"
                            >
                              Accept Job
                            </Button>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    
                    {isExpanded && (
                      <CardContent className="pt-0 space-y-4 animate-accordion-down">
                        <div className="flex gap-2">
                          <Badge variant="secondary" className="text-xs">
                            <Truck className="h-3 w-3 mr-1" />
                            {job.vehicleType}
                          </Badge>
                          <Badge variant="secondary" className="text-xs">
                            {job.weight}
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 border rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <MapPin className="h-4 w-4 text-green-600" />
                              <p className="text-sm font-medium">Pickup</p>
                            </div>
                            <p className="text-sm text-muted-foreground">{job.pickup}</p>
                            <p className="text-xs text-muted-foreground mt-1">{job.pickupTime}</p>
                          </div>
                          <div className="p-3 border rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <MapPin className="h-4 w-4 text-red-600" />
                              <p className="text-sm font-medium">Delivery</p>
                            </div>
                            <p className="text-sm text-muted-foreground">{job.delivery}</p>
                            <p className="text-xs text-muted-foreground mt-1">{job.deliveryTime}</p>
                          </div>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-2">Requirements:</p>
                          <div className="flex flex-wrap gap-2">
                            {job.requirements.map((req, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">{req}</Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex gap-2 pt-2" onClick={(e) => e.stopPropagation()}>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleViewDetails(job);
                            }}
                            className="flex-1"
                          >
                            View Full Details
                          </Button>
                          <Button 
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleAcceptJob(job);
                            }}
                            disabled={isAccepting}
                            className="flex-1"
                          >
                            Accept Job
                          </Button>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="unassigned" className="space-y-4">
          {isLoadingUnassigned ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2 text-muted-foreground">Loading unassigned jobs...</span>
            </div>
          ) : unassignedJobsList.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Package className="h-12 w-12 mx-auto mb-2 opacity-50 text-muted-foreground" />
                <p className="text-muted-foreground">No unassigned jobs</p>
                <p className="text-sm text-muted-foreground">Jobs you've accepted will appear here until assigned to a driver</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {unassignedJobsList.map((job) => {
                const isExpanded = expandedJobs.has(`unassigned-${job.id}`);
                return (
                  <Card 
                    key={`unassigned-${job.id}`}
                    className="cursor-pointer transition-all hover:shadow-md border-l-4 border-l-blue-500"
                    onClick={() => toggleJobExpansion(`unassigned-${job.id}`)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <ChevronDown 
                            className={`h-5 w-5 text-muted-foreground transition-transform duration-200 flex-shrink-0 mt-1 ${
                              isExpanded ? 'rotate-180' : ''
                            }`}
                          />
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <CardTitle className="text-lg">{job.title}</CardTitle>
                              <Badge variant="secondary">Awaiting Assignment</Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground flex-wrap">
                              <span className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                {job.distance}
                              </span>
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                {job.duration}
                              </span>
                              <span className="flex items-center gap-1">
                                <Package className="h-3 w-3" />
                                {job.cargo}
                              </span>
                            </div>
                          </div>
                        </div>
                        <Badge variant="default" className="text-base px-3 py-1 flex-shrink-0">
                          {job.price}
                        </Badge>
                      </div>
                    </CardHeader>
                    
                    {isExpanded && (
                      <CardContent className="pt-0 space-y-4 animate-accordion-down">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="p-3 border rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <MapPin className="h-4 w-4 text-green-600" />
                              <p className="text-sm font-medium">Pickup</p>
                            </div>
                            <p className="text-sm text-muted-foreground">{job.pickup}</p>
                            <p className="text-xs text-muted-foreground mt-1">{job.pickupTime}</p>
                          </div>
                          <div className="p-3 border rounded-lg">
                            <div className="flex items-center gap-2 mb-1">
                              <MapPin className="h-4 w-4 text-red-600" />
                              <p className="text-sm font-medium">Delivery</p>
                            </div>
                            <p className="text-sm text-muted-foreground">{job.delivery}</p>
                            <p className="text-xs text-muted-foreground mt-1">{job.deliveryTime}</p>
                          </div>
                        </div>

                        <div className="flex gap-2 pt-2" onClick={(e) => e.stopPropagation()}>
                          <Button 
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              openDispatchDialog(job.id);
                            }}
                          >
                            Dispatch to Driver
                          </Button>
                          <Button 
                            variant="destructive"
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation();
                              openCancelDialog(job.id);
                            }}
                          >
                            Cancel
                          </Button>
                        </div>
                      </CardContent>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="assigned" className="space-y-4">
          {isLoadingAssigned ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2 text-muted-foreground">Loading assigned jobs...</span>
            </div>
          ) : assignedJobsList.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Package className="h-12 w-12 mx-auto mb-2 opacity-50 text-muted-foreground" />
                <p className="text-muted-foreground">No assigned jobs yet</p>
                <p className="text-sm text-muted-foreground">Jobs assigned to drivers will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {dbAssignedJobs?.map((job) => {
                const driver = job.driver as any;
                const pickupLoc = job.pickup_location as any;
                const deliveryLoc = job.delivery_location as any;
                const isExpanded = expandedJobs.has(`assigned-${job.id}`);
                
                return (
                  <Card 
                    key={`assigned-${job.id}`}
                    className="group relative overflow-hidden transition-all duration-300 hover:shadow-lg border-l-4 border-l-blue-500 bg-gradient-to-br from-background to-background/50 cursor-pointer"
                    onClick={() => toggleJobExpansion(`assigned-${job.id}`)}
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
                    
                    <CardHeader className="pb-3 relative space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <ChevronDown 
                              className={`h-5 w-5 text-muted-foreground transition-transform duration-200 flex-shrink-0 ${
                                isExpanded ? 'rotate-180' : ''
                              }`}
                            />
                            <div className="p-2 rounded-lg bg-blue-500/10">
                              <Truck className="h-5 w-5 text-blue-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-lg line-clamp-1">{job.title || 'Untitled Job'}</CardTitle>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <Badge 
                                  variant="default" 
                                  className={
                                    job.status === 'assigned' ? 'bg-blue-600 text-xs' :
                                    job.status === 'in_transit' ? 'bg-purple-600 text-xs' :
                                    'bg-gray-600 text-xs'
                                  }
                                >
                                  {job.status === 'assigned' ? '📋 Assigned' :
                                   job.status === 'in_transit' ? '🚚 In Transit' :
                                   job.status}
                                </Badge>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="text-2xl font-bold text-primary">${job.pay_amount?.toFixed(2)}</div>
                          <div className="text-xs text-muted-foreground">{job.distance_miles} mi</div>
                        </div>
                      </div>

                      {/* Compact view when collapsed */}
                      {!isExpanded && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span className="truncate">{pickupLoc?.city}, {pickupLoc?.state}</span>
                          <span>→</span>
                          <span className="truncate">{deliveryLoc?.city}, {deliveryLoc?.state}</span>
                        </div>
                      )}

                      {/* Expanded view */}
                      {isExpanded && (
                        <>
                          {/* Driver Information */}
                          <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border">
                            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-bold text-primary">
                                {driver?.full_name?.charAt(0) || driver?.email?.charAt(0) || '?'}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">Driver Assigned</p>
                              <p className="text-xs text-muted-foreground truncate">
                                {driver?.full_name || driver?.email || 'Unassigned'}
                              </p>
                            </div>
                          </div>

                          {/* Timeline */}
                          <div className="space-y-2">
                            <div className="flex items-center gap-3">
                              <div className="flex flex-col items-center gap-1">
                                <div className="h-3 w-3 rounded-full bg-green-500" />
                                <div className="w-px h-8 bg-gradient-to-b from-blue-500 to-orange-500" />
                                <div className="h-3 w-3 rounded-full bg-orange-500" />
                              </div>
                              <div className="flex-1 space-y-3 text-sm">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">Pickup</span>
                                    <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
                                      ✓ Completed
                                    </Badge>
                                  </div>
                                  <p className="text-xs text-muted-foreground truncate">
                                    {pickupLoc?.address || `${pickupLoc?.city}, ${pickupLoc?.state}`}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {job.pickup_time ? new Date(job.pickup_time).toLocaleString() : 'TBD'}
                                  </p>
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">Delivery</span>
                                    {job.status === 'completed' && (
                                      <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
                                        ✓ Completed
                                      </Badge>
                                    )}
                                  </div>
                                  <p className="text-xs text-muted-foreground truncate">
                                    {deliveryLoc?.address || `${deliveryLoc?.city}, ${deliveryLoc?.state}`}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {job.delivery_time ? new Date(job.delivery_time).toLocaleString() : 'TBD'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="pending" className="space-y-4">
          {isLoadingPending ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2 text-muted-foreground">Loading pending jobs...</span>
            </div>
          ) : pendingJobsList.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Package className="h-12 w-12 mx-auto mb-2 opacity-50 text-muted-foreground" />
                <p className="text-muted-foreground">No pending jobs</p>
                <p className="text-sm text-muted-foreground">Jobs on hold will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {dbPendingJobs?.map((job) => {
                const driver = job.driver as any;
                const pickupLoc = job.pickup_location as any;
                const deliveryLoc = job.delivery_location as any;
                const isExpanded = expandedJobs.has(`pending-${job.id}`);
                
                return (
                  <Card 
                    key={`pending-${job.id}`}
                    className="group relative overflow-hidden transition-all duration-300 hover:shadow-lg border-l-4 border-l-yellow-500 bg-gradient-to-br from-background to-background/50 cursor-pointer"
                    onClick={() => toggleJobExpansion(`pending-${job.id}`)}
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-yellow-500/5 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
                    
                    <CardHeader className="pb-3 relative space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <ChevronDown 
                              className={`h-5 w-5 text-muted-foreground transition-transform duration-200 flex-shrink-0 ${
                                isExpanded ? 'rotate-180' : ''
                              }`}
                            />
                            <div className="p-2 rounded-lg bg-yellow-500/10">
                              <AlertCircle className="h-5 w-5 text-yellow-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-lg line-clamp-1">{job.title || 'Untitled Job'}</CardTitle>
                              <Badge 
                                variant="secondary" 
                                className={
                                  job.status === 'on_hold' ? 'mt-1 bg-yellow-500/10 text-yellow-700 border-yellow-500/20 text-xs' :
                                  'mt-1 bg-gray-500/10 text-gray-700 border-gray-500/20 text-xs'
                                }
                              >
                                {job.status === 'on_hold' ? '⏸️ On Hold' : job.status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="text-2xl font-bold text-primary">${job.pay_amount?.toFixed(2)}</div>
                          <div className="text-xs text-muted-foreground">{job.distance_miles} mi</div>
                        </div>
                      </div>

                      {/* Compact view when collapsed */}
                      {!isExpanded && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span className="truncate">{pickupLoc?.city}, {pickupLoc?.state}</span>
                          <span>→</span>
                          <span className="truncate">{deliveryLoc?.city}, {deliveryLoc?.state}</span>
                        </div>
                      )}

                      {/* Expanded view */}
                      {isExpanded && (
                        <>
                          {/* Driver Information */}
                          <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border">
                            <div className="h-10 w-10 rounded-full bg-yellow-500/10 flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-bold text-yellow-600">
                                {driver?.full_name?.charAt(0) || driver?.email?.charAt(0) || '?'}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">Driver Assigned</p>
                              <p className="text-xs text-muted-foreground truncate">
                                {driver?.full_name || driver?.email || 'Unassigned'}
                              </p>
                            </div>
                          </div>

                          {/* Timeline */}
                          <div className="space-y-2">
                            <div className="flex items-center gap-3">
                              <div className="flex flex-col items-center gap-1">
                                <div className="h-3 w-3 rounded-full bg-yellow-500" />
                                <div className="w-px h-8 bg-yellow-500/30" />
                                <div className="h-3 w-3 rounded-full border-2 border-yellow-500 bg-background" />
                              </div>
                              <div className="flex-1 space-y-3 text-sm">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">Pickup</span>
                                    <Badge variant="secondary" className="text-xs bg-yellow-500/10 text-yellow-700">
                                      Waiting
                                    </Badge>
                                  </div>
                                  <p className="text-xs text-muted-foreground truncate">
                                    {pickupLoc?.address || `${pickupLoc?.city}, ${pickupLoc?.state}`}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {job.pickup_time ? new Date(job.pickup_time).toLocaleString() : 'TBD'}
                                  </p>
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">Delivery</span>
                                  </div>
                                  <p className="text-xs text-muted-foreground truncate">
                                    {deliveryLoc?.address || `${deliveryLoc?.city}, ${deliveryLoc?.state}`}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {job.delivery_time ? new Date(job.delivery_time).toLocaleString() : 'TBD'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          {isLoadingCompleted ? (
            <div className="flex items-center justify-center p-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2 text-muted-foreground">Loading completed jobs...</span>
            </div>
          ) : completedJobsList.length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <Package className="h-12 w-12 mx-auto mb-2 opacity-50 text-muted-foreground" />
                <p className="text-muted-foreground">No completed jobs yet</p>
                <p className="text-sm text-muted-foreground">Completed jobs will appear here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {dbCompletedJobs?.map((job) => {
                const driver = job.driver as any;
                const pickupLoc = job.pickup_location as any;
                const deliveryLoc = job.delivery_location as any;
                const isExpanded = expandedJobs.has(`completed-${job.id}`);
                
                return (
                  <Card 
                    key={`completed-${job.id}`}
                    className="group relative overflow-hidden transition-all duration-300 hover:shadow-lg border-l-4 border-l-green-500 bg-gradient-to-br from-background to-background/50 cursor-pointer"
                    onClick={() => toggleJobExpansion(`completed-${job.id}`)}
                  >
                    <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500" />
                    
                    <CardHeader className="pb-3 relative space-y-3">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <ChevronDown 
                              className={`h-5 w-5 text-muted-foreground transition-transform duration-200 flex-shrink-0 ${
                                isExpanded ? 'rotate-180' : ''
                              }`}
                            />
                            <div className="p-2 rounded-lg bg-green-500/10">
                              <CheckCircle className="h-5 w-5 text-green-600" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-lg line-clamp-1">{job.title || 'Untitled Job'}</CardTitle>
                              <Badge 
                                variant="secondary" 
                                className={
                                  job.status === 'completed' ? 'mt-1 bg-green-500/10 text-green-700 border-green-500/20 text-xs' :
                                  job.status === 'delivered' ? 'mt-1 bg-green-600/10 text-green-800 border-green-600/20 text-xs' :
                                  'mt-1 bg-gray-500/10 text-gray-700 border-gray-500/20 text-xs'
                                }
                              >
                                {job.status === 'completed' ? '✓ Completed' : 
                                 job.status === 'delivered' ? '✓ Delivered' : 
                                 job.status}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <div className="text-2xl font-bold text-green-600">${job.pay_amount?.toFixed(2)}</div>
                          <div className="text-xs text-muted-foreground">{job.distance_miles} mi</div>
                        </div>
                      </div>

                      {/* Compact view when collapsed */}
                      {!isExpanded && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span className="truncate">{pickupLoc?.city}, {pickupLoc?.state}</span>
                          <span>→</span>
                          <span className="truncate">{deliveryLoc?.city}, {deliveryLoc?.state}</span>
                        </div>
                      )}

                      {/* Expanded view */}
                      {isExpanded && (
                        <>
                          {/* Driver Information */}
                          <div className="flex items-center gap-2 p-3 rounded-lg bg-muted/50 border">
                            <div className="h-10 w-10 rounded-full bg-green-500/10 flex items-center justify-center flex-shrink-0">
                              <span className="text-sm font-bold text-green-600">
                                {driver?.full_name?.charAt(0) || driver?.email?.charAt(0) || '?'}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium">Completed by</p>
                              <p className="text-xs text-muted-foreground truncate">
                                {driver?.full_name || driver?.email || 'Unknown Driver'}
                              </p>
                            </div>
                          </div>

                          {/* Completion Timeline */}
                          <div className="space-y-2">
                            <div className="flex items-center gap-3">
                              <div className="flex flex-col items-center gap-1">
                                <div className="h-3 w-3 rounded-full bg-green-500" />
                                <div className="w-px h-8 bg-green-500" />
                                <div className="h-3 w-3 rounded-full bg-green-500" />
                              </div>
                              <div className="flex-1 space-y-3 text-sm">
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">Pickup</span>
                                    <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
                                      ✓ Done
                                    </Badge>
                                  </div>
                                  <p className="text-xs text-muted-foreground truncate">
                                    {pickupLoc?.address || `${pickupLoc?.city}, ${pickupLoc?.state}`}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {job.pickup_time ? new Date(job.pickup_time).toLocaleString() : 'N/A'}
                                  </p>
                                </div>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">Delivery</span>
                                    <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
                                      ✓ Done
                                    </Badge>
                                  </div>
                                  <p className="text-xs text-muted-foreground truncate">
                                    {deliveryLoc?.address || `${deliveryLoc?.city}, ${deliveryLoc?.state}`}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {job.completed_at ? new Date(job.completed_at).toLocaleString() : 'N/A'}
                                  </p>
                                </div>
                              </div>
                            </div>
                          </div>
                        </>
                      )}
                    </CardHeader>
                  </Card>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Job</DialogTitle>
            <DialogDescription>
              Please select a reason for cancelling this job. It will be returned to the available jobs pool.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="cancel-reason">Cancellation Reason</Label>
              <Select value={cancelReason} onValueChange={setCancelReason}>
                <SelectTrigger id="cancel-reason">
                  <SelectValue placeholder="Select a reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vehicle_unavailable">Vehicle Unavailable</SelectItem>
                  <SelectItem value="driver_unavailable">Driver Unavailable</SelectItem>
                  <SelectItem value="route_conflict">Route Conflict</SelectItem>
                  <SelectItem value="pricing_issue">Pricing Issue</SelectItem>
                  <SelectItem value="customer_request">Customer Request</SelectItem>
                  <SelectItem value="weather_conditions">Weather Conditions</SelectItem>
                  <SelectItem value="mechanical_issue">Mechanical Issue</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCancelDialogOpen(false)}>
              Keep Job
            </Button>
            <Button variant="destructive" onClick={handleCancelJob}>
              Cancel Job
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dispatch Dialog */}
      <Dialog open={isDispatchDialogOpen} onOpenChange={setIsDispatchDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Dispatch Job to Driver</DialogTitle>
            <DialogDescription>
              Select a driver from your fleet to assign this job. The job status will be updated to "assigned".
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="driver-select">Assign to Driver</Label>
              {isLoadingDrivers ? (
                <div className="flex items-center justify-center p-4 border rounded-lg bg-muted/50">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  <span className="text-sm text-muted-foreground">Loading drivers...</span>
                </div>
              ) : availableDrivers && availableDrivers.length > 0 ? (
                <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                  <SelectTrigger id="driver-select">
                    <SelectValue placeholder="Choose a driver" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableDrivers.map((driver: any) => (
                      <SelectItem key={driver.id} value={driver.id}>
                        {driver.full_name || driver.email || 'Unnamed driver'}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <div className="text-sm text-muted-foreground p-4 border rounded-lg bg-muted/50">
                  <p className="font-medium mb-1">No drivers available</p>
                  <p className="text-xs">Please add drivers to your fleet first in the Drivers section.</p>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsDispatchDialogOpen(false);
                setSelectedDriver('');
              }} 
              disabled={isDispatching}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleDispatchJob} 
              disabled={!selectedDriver || isDispatching || !availableDrivers || availableDrivers.length === 0}
            >
              {isDispatching ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Dispatching...
                </>
              ) : (
                'Dispatch Job'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}