import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Shield, FileText, AlertCircle, CheckCircle2, Clock, Upload, Eye, Plus, Edit } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface ComplianceDocument {
  id: string;
  name: string;
  status: 'valid' | 'expiring' | 'expired';
  expires: string;
  daysLeft: number;
}

interface DriverCompliance {
  id: string;
  driver: string;
  cdl: 'valid' | 'expiring' | 'expired';
  medical: 'valid' | 'expiring' | 'expired';
  hazmat: 'valid' | 'expiring' | 'expired' | 'n/a';
  score: number;
}

export const CarrierCompliance: React.FC = () => {
  const { user } = useAuth();
  const [uploadOpen, setUploadOpen] = useState(false);
  const [renewOpen, setRenewOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<ComplianceDocument | null>(null);
  const [uploading, setUploading] = useState(false);
  const [addDriverOpen, setAddDriverOpen] = useState(false);
  const [editDriverOpen, setEditDriverOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<DriverCompliance | null>(null);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  const documents: ComplianceDocument[] = [
    { id: '1', name: 'DOT Operating Authority', status: 'valid', expires: '2025-06-15', daysLeft: 502 },
    { id: '2', name: 'Motor Carrier Insurance', status: 'valid', expires: '2024-12-31', daysLeft: 334 },
    { id: '3', name: 'Cargo Insurance Policy', status: 'expiring', expires: '2024-03-15', daysLeft: 43 },
    { id: '4', name: 'IFTA License', status: 'expired', expires: '2024-01-01', daysLeft: -30 },
  ];

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setUploading(true);
    
    // Simulate upload
    setTimeout(() => {
      toast.success('Document uploaded successfully');
      setUploadOpen(false);
      setUploading(false);
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  const handleView = (doc: ComplianceDocument) => {
    toast.info(`Viewing ${doc.name}`);
  };

  const handleRenew = (doc: ComplianceDocument) => {
    setSelectedDoc(doc);
    setRenewOpen(true);
  };

  const handleRenewSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setUploading(true);
    
    // Simulate upload
    setTimeout(() => {
      toast.success('Document renewed successfully');
      setRenewOpen(false);
      setSelectedDoc(null);
      setUploading(false);
      (e.target as HTMLFormElement).reset();
    }, 1500);
  };

  const [driverCompliance, setDriverCompliance] = useState<DriverCompliance[]>([]);

  // Fetch driver compliance records
  useEffect(() => {
    const fetchDriverCompliance = async () => {
      if (!user) return;
      
      try {
        const { data, error } = await supabase
          .from('driver_compliance')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false });

        if (error) throw error;

        const formattedData: DriverCompliance[] = data.map(record => ({
          id: record.id,
          driver: record.driver_name,
          cdl: record.cdl_status as 'valid' | 'expiring' | 'expired',
          medical: record.medical_status as 'valid' | 'expiring' | 'expired',
          hazmat: record.hazmat_status as 'valid' | 'expiring' | 'expired' | 'n/a',
          score: record.compliance_score || 100,
        }));

        setDriverCompliance(formattedData);
      } catch (error) {
        console.error('Error fetching driver compliance:', error);
        toast.error('Failed to load driver compliance records');
      } finally {
        setLoading(false);
      }
    };

    fetchDriverCompliance();
  }, [user]);

  const handleAddDriver = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user) return;
    
    setSaving(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      
      // Handle file uploads
      const cdlFile = formData.get('cdl_document') as File;
      const medicalFile = formData.get('medical_document') as File;
      const hazmatFile = formData.get('hazmat_document') as File;
      
      let cdlPath = null;
      let medicalPath = null;
      let hazmatPath = null;
      
      // Upload CDL document
      if (cdlFile && cdlFile.size > 0) {
        const fileExt = cdlFile.name.split('.').pop();
        const filePath = `${user.id}/cdl-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('driver-compliance')
          .upload(filePath, cdlFile);
        
        if (uploadError) throw uploadError;
        cdlPath = filePath;
      }
      
      // Upload Medical document
      if (medicalFile && medicalFile.size > 0) {
        const fileExt = medicalFile.name.split('.').pop();
        const filePath = `${user.id}/medical-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('driver-compliance')
          .upload(filePath, medicalFile);
        
        if (uploadError) throw uploadError;
        medicalPath = filePath;
      }
      
      // Upload HAZMAT document
      if (hazmatFile && hazmatFile.size > 0) {
        const fileExt = hazmatFile.name.split('.').pop();
        const filePath = `${user.id}/hazmat-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('driver-compliance')
          .upload(filePath, hazmatFile);
        
        if (uploadError) throw uploadError;
        hazmatPath = filePath;
      }
      
      // Create database record
      const { data, error } = await supabase
        .from('driver_compliance')
        .insert({
          user_id: user.id,
          driver_name: formData.get('driver_name') as string,
          cdl_status: formData.get('cdl_status') as string,
          cdl_expiry_date: formData.get('cdl_expiry') as string || null,
          cdl_document_path: cdlPath,
          medical_status: formData.get('medical_status') as string,
          medical_expiry_date: formData.get('medical_expiry') as string || null,
          medical_document_path: medicalPath,
          hazmat_status: formData.get('hazmat_status') as string,
          hazmat_expiry_date: formData.get('hazmat_expiry') as string || null,
          hazmat_document_path: hazmatPath,
        })
        .select()
        .single();
      
      if (error) throw error;
      
      // Add to local state
      const newDriver: DriverCompliance = {
        id: data.id,
        driver: data.driver_name,
        cdl: data.cdl_status as 'valid' | 'expiring' | 'expired',
        medical: data.medical_status as 'valid' | 'expiring' | 'expired',
        hazmat: data.hazmat_status as 'valid' | 'expiring' | 'expired' | 'n/a',
        score: data.compliance_score || 100,
      };
      
      setDriverCompliance([...driverCompliance, newDriver]);
      toast.success('Driver compliance record added successfully');
      setAddDriverOpen(false);
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      console.error('Error adding driver compliance:', error);
      toast.error('Failed to add driver compliance record');
    } finally {
      setSaving(false);
    }
  };

  const handleEditDriver = (driver: DriverCompliance) => {
    setSelectedDriver(driver);
    setEditDriverOpen(true);
  };

  const handleUpdateDriver = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!user || !selectedDriver) return;
    
    setSaving(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      
      // Handle file uploads if new files are provided
      const cdlFile = formData.get('cdl_document') as File;
      const medicalFile = formData.get('medical_document') as File;
      const hazmatFile = formData.get('hazmat_document') as File;
      
      const updateData: any = {
        driver_name: formData.get('driver_name') as string,
        cdl_status: formData.get('cdl_status') as string,
        cdl_expiry_date: formData.get('cdl_expiry') as string || null,
        medical_status: formData.get('medical_status') as string,
        medical_expiry_date: formData.get('medical_expiry') as string || null,
        hazmat_status: formData.get('hazmat_status') as string,
        hazmat_expiry_date: formData.get('hazmat_expiry') as string || null,
      };
      
      // Upload new CDL document if provided
      if (cdlFile && cdlFile.size > 0) {
        const fileExt = cdlFile.name.split('.').pop();
        const filePath = `${user.id}/cdl-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('driver-compliance')
          .upload(filePath, cdlFile);
        
        if (uploadError) throw uploadError;
        updateData.cdl_document_path = filePath;
      }
      
      // Upload new Medical document if provided
      if (medicalFile && medicalFile.size > 0) {
        const fileExt = medicalFile.name.split('.').pop();
        const filePath = `${user.id}/medical-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('driver-compliance')
          .upload(filePath, medicalFile);
        
        if (uploadError) throw uploadError;
        updateData.medical_document_path = filePath;
      }
      
      // Upload new HAZMAT document if provided
      if (hazmatFile && hazmatFile.size > 0) {
        const fileExt = hazmatFile.name.split('.').pop();
        const filePath = `${user.id}/hazmat-${Date.now()}.${fileExt}`;
        const { error: uploadError } = await supabase.storage
          .from('driver-compliance')
          .upload(filePath, hazmatFile);
        
        if (uploadError) throw uploadError;
        updateData.hazmat_document_path = filePath;
      }
      
      // Update database record
      const { data, error } = await supabase
        .from('driver_compliance')
        .update(updateData)
        .eq('id', selectedDriver.id)
        .select()
        .single();
      
      if (error) throw error;
      
      // Update local state
      const updatedDriver: DriverCompliance = {
        id: data.id,
        driver: data.driver_name,
        cdl: data.cdl_status as 'valid' | 'expiring' | 'expired',
        medical: data.medical_status as 'valid' | 'expiring' | 'expired',
        hazmat: data.hazmat_status as 'valid' | 'expiring' | 'expired' | 'n/a',
        score: data.compliance_score || 100,
      };
      
      setDriverCompliance(driverCompliance.map(d => d.id === updatedDriver.id ? updatedDriver : d));
      toast.success('Driver compliance record updated successfully');
      setEditDriverOpen(false);
      setSelectedDriver(null);
      (e.target as HTMLFormElement).reset();
    } catch (error) {
      console.error('Error updating driver compliance:', error);
      toast.error('Failed to update driver compliance record');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold">Compliance & Documentation</h2>
          <p className="text-muted-foreground">Monitor regulatory compliance and documents</p>
        </div>
        <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
          <DialogTrigger asChild>
            <Button>
              <Upload className="h-4 w-4 mr-2" />
              Upload Document
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Upload Compliance Document</DialogTitle>
              <DialogDescription>
                Upload a new compliance document with expiry date
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <Label htmlFor="document_type">Document Type</Label>
                <Select name="document_type" required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select document type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="dot_authority">DOT Operating Authority</SelectItem>
                    <SelectItem value="carrier_insurance">Motor Carrier Insurance</SelectItem>
                    <SelectItem value="cargo_insurance">Cargo Insurance Policy</SelectItem>
                    <SelectItem value="ifta_license">IFTA License</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="document_name">Document Name</Label>
                <Input id="document_name" name="document_name" placeholder="e.g., DOT Authority 2024" required />
              </div>
              <div>
                <Label htmlFor="expiry_date">Expiry Date</Label>
                <Input id="expiry_date" name="expiry_date" type="date" required />
              </div>
              <div>
                <Label htmlFor="file">Upload File</Label>
                <Input id="file" name="file" type="file" accept=".pdf,.jpg,.jpeg,.png" required />
              </div>
              <Button type="submit" disabled={uploading} className="w-full">
                {uploading ? 'Uploading...' : 'Upload Document'}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Valid Documents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">24</div>
            <p className="text-xs text-muted-foreground">All up to date</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">3</div>
            <p className="text-xs text-muted-foreground">Within 60 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Expired</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">1</div>
            <p className="text-xs text-muted-foreground">Needs renewal</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Compliance Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">92%</div>
            <Progress value={92} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Company Documents</CardTitle>
          <CardDescription>Critical compliance documents and certifications</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {documents.map((doc) => (
              <div key={doc.id} className="border rounded-lg p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Shield className="h-4 w-4" />
                      <span className="font-semibold">{doc.name}</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>Expires: {doc.expires}</span>
                      <span>{Math.abs(doc.daysLeft)} days {doc.daysLeft < 0 ? 'overdue' : 'remaining'}</span>
                    </div>
                  </div>
                  <Badge variant={
                    doc.status === 'valid' ? 'default' :
                    doc.status === 'expiring' ? 'secondary' :
                    'destructive'
                  }>
                    {doc.status === 'valid' && <CheckCircle2 className="h-3 w-3 mr-1" />}
                    {doc.status === 'expiring' && <Clock className="h-3 w-3 mr-1" />}
                    {doc.status === 'expired' && <AlertCircle className="h-3 w-3 mr-1" />}
                    {doc.status}
                  </Badge>
                </div>
                <div className="flex gap-2 mt-3">
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleView(doc)}
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    View
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleRenew(doc)}
                  >
                    <Upload className="h-3 w-3 mr-1" />
                    Renew
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Renew Document Dialog */}
      <Dialog open={renewOpen} onOpenChange={setRenewOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Renew Document</DialogTitle>
            <DialogDescription>
              Upload a renewed version of {selectedDoc?.name}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleRenewSubmit} className="space-y-4">
            <div>
              <Label htmlFor="renew_expiry_date">New Expiry Date</Label>
              <Input id="renew_expiry_date" name="expiry_date" type="date" required />
            </div>
            <div>
              <Label htmlFor="renew_file">Upload New File</Label>
              <Input id="renew_file" name="file" type="file" accept=".pdf,.jpg,.jpeg,.png" required />
            </div>
            <Button type="submit" disabled={uploading} className="w-full">
              {uploading ? 'Uploading...' : 'Renew Document'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      <Card>
        <CardHeader>
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <CardTitle>Driver Compliance Status</CardTitle>
              <CardDescription>Monitor driver certifications and compliance</CardDescription>
            </div>
            <Dialog open={addDriverOpen} onOpenChange={setAddDriverOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Driver
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add Driver Compliance Record</DialogTitle>
                  <DialogDescription>
                    Add a new driver and their compliance certifications
                  </DialogDescription>
                </DialogHeader>
                <form onSubmit={handleAddDriver} className="space-y-4">
                  <div>
                    <Label htmlFor="driver_name">Driver Name</Label>
                    <Input id="driver_name" name="driver_name" placeholder="e.g., John Doe" required />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>CDL License</Label>
                    <Select name="cdl_status" defaultValue="valid" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select CDL status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="valid">Valid</SelectItem>
                        <SelectItem value="expiring">Expiring Soon</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input type="date" name="cdl_expiry" placeholder="Expiry Date" />
                    <Input type="file" name="cdl_document" accept=".pdf,.jpg,.jpeg,.png" />
                  </div>

                  <div className="space-y-2">
                    <Label>Medical Certificate</Label>
                    <Select name="medical_status" defaultValue="valid" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select medical status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="valid">Valid</SelectItem>
                        <SelectItem value="expiring">Expiring Soon</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input type="date" name="medical_expiry" placeholder="Expiry Date" />
                    <Input type="file" name="medical_document" accept=".pdf,.jpg,.jpeg,.png" />
                  </div>

                  <div className="space-y-2">
                    <Label>HAZMAT Endorsement</Label>
                    <Select name="hazmat_status" defaultValue="n/a" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Select HAZMAT status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="valid">Valid</SelectItem>
                        <SelectItem value="expiring">Expiring Soon</SelectItem>
                        <SelectItem value="expired">Expired</SelectItem>
                        <SelectItem value="n/a">N/A</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input type="date" name="hazmat_expiry" placeholder="Expiry Date" />
                    <Input type="file" name="hazmat_document" accept=".pdf,.jpg,.jpeg,.png" />
                  </div>

                  <Button type="submit" disabled={saving} className="w-full">
                    {saving ? 'Adding...' : 'Add Driver'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {driverCompliance.map((driver) => (
              <div key={driver.id} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <span className="font-semibold">{driver.driver}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">Compliance Score:</span>
                    <Badge variant={driver.score >= 90 ? 'default' : driver.score >= 70 ? 'secondary' : 'destructive'}>
                      {driver.score}%
                    </Badge>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleEditDriver(driver)}
                    >
                      <Edit className="h-3 w-3 mr-1" />
                      Edit
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">CDL:</span>
                    <Badge variant={driver.cdl === 'valid' ? 'default' : 'destructive'} className="text-xs">
                      {driver.cdl}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">Medical:</span>
                    <Badge variant={
                      driver.medical === 'valid' ? 'default' : 
                      driver.medical === 'expiring' ? 'secondary' : 
                      'destructive'
                    } className="text-xs">
                      {driver.medical}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <span className="text-muted-foreground">HAZMAT:</span>
                    <Badge variant={
                      driver.hazmat === 'valid' ? 'default' : 
                      driver.hazmat === 'n/a' ? 'outline' : 
                      'destructive'
                    } className="text-xs">
                      {driver.hazmat}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Edit Driver Dialog */}
      <Dialog open={editDriverOpen} onOpenChange={setEditDriverOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Driver Compliance Record</DialogTitle>
            <DialogDescription>
              Update compliance information for {selectedDriver?.driver}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleUpdateDriver} className="space-y-4">
            <div>
              <Label htmlFor="edit_driver_name">Driver Name</Label>
              <Input 
                id="edit_driver_name" 
                name="driver_name" 
                defaultValue={selectedDriver?.driver}
                placeholder="e.g., John Doe" 
                required 
              />
            </div>
            
            <div className="space-y-2">
              <Label>CDL License</Label>
              <Select name="cdl_status" defaultValue={selectedDriver?.cdl} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select CDL status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="valid">Valid</SelectItem>
                  <SelectItem value="expiring">Expiring Soon</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
              <Input type="date" name="cdl_expiry" placeholder="Expiry Date" />
              <Input type="file" name="cdl_document" accept=".pdf,.jpg,.jpeg,.png" />
            </div>

            <div className="space-y-2">
              <Label>Medical Certificate</Label>
              <Select name="medical_status" defaultValue={selectedDriver?.medical} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select medical status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="valid">Valid</SelectItem>
                  <SelectItem value="expiring">Expiring Soon</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
              <Input type="date" name="medical_expiry" placeholder="Expiry Date" />
              <Input type="file" name="medical_document" accept=".pdf,.jpg,.jpeg,.png" />
            </div>

            <div className="space-y-2">
              <Label>HAZMAT Endorsement</Label>
              <Select name="hazmat_status" defaultValue={selectedDriver?.hazmat} required>
                <SelectTrigger>
                  <SelectValue placeholder="Select HAZMAT status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="valid">Valid</SelectItem>
                  <SelectItem value="expiring">Expiring Soon</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                  <SelectItem value="n/a">N/A</SelectItem>
                </SelectContent>
              </Select>
              <Input type="date" name="hazmat_expiry" placeholder="Expiry Date" />
              <Input type="file" name="hazmat_document" accept=".pdf,.jpg,.jpeg,.png" />
            </div>

            <Button type="submit" disabled={saving} className="w-full">
              {saving ? 'Updating...' : 'Update Driver'}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
