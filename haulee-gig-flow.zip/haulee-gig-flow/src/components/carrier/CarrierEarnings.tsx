import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, FileText, BarChart3 } from 'lucide-react';

export function CarrierEarnings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Earnings & Payouts</h2>
        <p className="text-muted-foreground">Track your carrier revenue and financial reports</p>
      </div>

      <Tabs defaultValue="balance" className="space-y-6">
        <TabsList>
          <TabsTrigger value="balance">Carrier Balance</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="balance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Current Balance</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$28,450.80</div>
                <div className="flex items-center text-xs text-green-600">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +12% from last month
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">This Month Revenue</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$145,800</div>
                <div className="flex items-center text-xs text-green-600">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  +18% from last month
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Payments</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">$12,300</div>
                <div className="text-xs text-muted-foreground">8 invoices pending</div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Payments</CardTitle>
              <CardDescription>Your latest payment transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">Phoenix to Denver Route</p>
                    <p className="text-sm text-muted-foreground">Job #PD-2024-0325 • Completed March 25, 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-green-600">+$2,450.00</p>
                    <Badge variant="secondary">Paid</Badge>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">LA to Seattle Express</p>
                    <p className="text-sm text-muted-foreground">Job #LS-2024-0324 • Completed March 24, 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-green-600">+$3,200.00</p>
                    <Badge variant="secondary">Paid</Badge>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">Miami to Orlando</p>
                    <p className="text-sm text-muted-foreground">Job #MO-2024-0323 • Completed March 23, 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-yellow-600">$850.00</p>
                    <Badge variant="outline">Processing</Badge>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <p className="font-medium">Houston to Dallas</p>
                    <p className="text-sm text-muted-foreground">Job #HD-2024-0322 • Completed March 22, 2024</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-green-600">+$1,200.00</p>
                    <Badge variant="secondary">Paid</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Revenue Breakdown</CardTitle>
              <CardDescription>March 2024 performance summary</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Week 1 (Mar 1-7)</p>
                    <p className="text-sm text-muted-foreground">12 jobs completed</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">$28,450</p>
                    <p className="text-sm text-green-600">+15% vs prev week</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Week 2 (Mar 8-14)</p>
                    <p className="text-sm text-muted-foreground">15 jobs completed</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">$35,200</p>
                    <p className="text-sm text-green-600">+24% vs prev week</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Week 3 (Mar 15-21)</p>
                    <p className="text-sm text-muted-foreground">18 jobs completed</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">$42,800</p>
                    <p className="text-sm text-green-600">+22% vs prev week</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">Week 4 (Mar 22-28)</p>
                    <p className="text-sm text-muted-foreground">14 jobs completed</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">$39,350</p>
                    <p className="text-sm text-red-600">-8% vs prev week</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Financial Reports</CardTitle>
              <CardDescription>Comprehensive financial analysis and reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-medium">Monthly Revenue Report</h4>
                      <p className="text-sm text-muted-foreground">March 2024</p>
                    </div>
                    <Button variant="outline" size="sm">Download PDF</Button>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Total Revenue:</span>
                      <span className="font-medium">$145,800</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Operating Costs:</span>
                      <span className="font-medium">$87,480</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span>Net Profit:</span>
                      <span className="font-medium text-green-600">$58,320</span>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-medium">Driver Performance Report</h4>
                      <p className="text-sm text-muted-foreground">March 2024</p>
                    </div>
                    <Button variant="outline" size="sm">Download PDF</Button>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Total Drivers:</span>
                      <span className="font-medium">32</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Drivers:</span>
                      <span className="font-medium">28</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span>Avg Rating:</span>
                      <span className="font-medium">4.7/5</span>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-medium">Fleet Utilization Report</h4>
                      <p className="text-sm text-muted-foreground">March 2024</p>
                    </div>
                    <Button variant="outline" size="sm">Download PDF</Button>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Total Vehicles:</span>
                      <span className="font-medium">24</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Vehicles:</span>
                      <span className="font-medium">22</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span>Utilization Rate:</span>
                      <span className="font-medium">92%</span>
                    </div>
                  </div>
                </div>

                <div className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-medium">Tax Summary Report</h4>
                      <p className="text-sm text-muted-foreground">Q1 2024</p>
                    </div>
                    <Button variant="outline" size="sm">Download PDF</Button>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span>Gross Revenue:</span>
                      <span className="font-medium">$437,400</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Deductions:</span>
                      <span className="font-medium">$262,440</span>
                    </div>
                    <div className="flex justify-between border-t pt-2">
                      <span>Taxable Income:</span>
                      <span className="font-medium">$174,960</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-6">
                <h4 className="font-medium mb-4">Custom Report Generator</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium">Report Type</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Revenue Analysis</option>
                      <option>Driver Performance</option>
                      <option>Fleet Utilization</option>
                      <option>Cost Breakdown</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Date Range</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Last 30 Days</option>
                      <option>Last 3 Months</option>
                      <option>Last 6 Months</option>
                      <option>Custom Range</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Format</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>PDF</option>
                      <option>Excel</option>
                      <option>CSV</option>
                    </select>
                  </div>
                </div>
                <Button className="mt-4">Generate Report</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}