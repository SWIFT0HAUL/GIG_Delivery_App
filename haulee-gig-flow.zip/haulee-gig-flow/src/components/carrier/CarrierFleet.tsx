import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Truck, Users, MapPin, MoreVertical, Wrench, FileText, UserPlus, Phone } from 'lucide-react';
import { toast } from 'sonner';

interface Vehicle {
  id: string;
  name: string;
  model: string;
  vin: string;
  licensePlate: string;
  currentDriver: string;
  status: string;
  statusColor: string;
}

interface Driver {
  id: string;
  name: string;
  experience: string;
  phone: string;
  vehicle: string;
  rating: string;
  status: string;
  statusColor: string;
}

export function CarrierFleet() {
  const [isTrackingOpen, setIsTrackingOpen] = useState(false);
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const [isAssignDriverOpen, setIsAssignDriverOpen] = useState(false);
  const [isDriverDetailsOpen, setIsDriverDetailsOpen] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);
  const [selectedDriver, setSelectedDriver] = useState<string>('');
  const [selectedDriverDetails, setSelectedDriverDetails] = useState<Driver | null>(null);

  const vehicles: Vehicle[] = [
    {
      id: '24',
      name: 'Truck #24',
      model: '2021 Freightliner Cascadia',
      vin: '1FUJGBDV9MLXXXXXX',
      licensePlate: 'TX-ABC123',
      currentDriver: 'Mike Johnson',
      status: 'On Route',
      statusColor: 'text-green-600',
    },
    {
      id: '12',
      name: 'Truck #12',
      model: '2020 Peterbilt 579',
      vin: '1XP5DB9X8LD123456',
      licensePlate: 'TX-DEF456',
      currentDriver: 'Sarah Davis',
      status: 'At Terminal',
      statusColor: 'text-blue-600',
    },
  ];

  const drivers: Driver[] = [
    {
      id: '1',
      name: 'Mike Johnson',
      experience: 'CDL-A, 8 years experience',
      phone: '(555) 123-4567',
      vehicle: 'Truck #24',
      rating: '⭐⭐⭐⭐⭐ (4.9)',
      status: 'On Route',
      statusColor: 'text-green-600',
    },
    {
      id: '2',
      name: 'Sarah Davis',
      experience: 'CDL-A, 5 years experience',
      phone: '(555) 234-5678',
      vehicle: 'Truck #12',
      rating: '⭐⭐⭐⭐⭐ (4.8)',
      status: 'Rest Period',
      statusColor: 'text-yellow-600',
    },
  ];

  const availableDrivers: Driver[] = drivers;

  const handleTrackVehicle = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setIsTrackingOpen(true);
  };

  const handleViewDetails = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setIsDetailsOpen(true);
  };

  const handleAssignDriver = (vehicle: Vehicle) => {
    setSelectedVehicle(vehicle);
    setIsAssignDriverOpen(true);
  };

  const handleConfirmAssignment = () => {
    if (selectedDriver && selectedVehicle) {
      toast.success(`Driver assigned successfully`, {
        description: `${selectedDriver} has been assigned to ${selectedVehicle.name}`,
      });
      setIsAssignDriverOpen(false);
      setSelectedDriver('');
    }
  };

  const handleMaintenanceSchedule = (vehicle: Vehicle) => {
    toast.info(`Maintenance scheduling`, {
      description: `Opening maintenance schedule for ${vehicle.name}`,
    });
  };

  const handleViewDocuments = (vehicle: Vehicle) => {
    toast.info(`Documents viewer`, {
      description: `Opening documents for ${vehicle.name}`,
    });
  };

  const handleViewDriverDetails = (driver: Driver) => {
    setSelectedDriverDetails(driver);
    setIsDriverDetailsOpen(true);
  };

  const handleAssignJob = (driver: Driver) => {
    toast.info('Assign job to driver', {
      description: `Opening job assignment for ${driver.name}`,
    });
  };

  const handleContactDriver = (driver: Driver) => {
    toast.info('Contact driver', {
      description: `Calling ${driver.name} at ${driver.phone}`,
    });
  };

  const handleEditDriver = (driver: Driver) => {
    toast.info('Edit driver', {
      description: `Opening editor for ${driver.name}`,
    });
  };

  const handleScheduleDriver = (driver: Driver) => {
    toast.info('Schedule driver', {
      description: `Opening schedule for ${driver.name}`,
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Fleet Management</h2>
        <p className="text-muted-foreground">Manage your drivers, vehicles, and job assignments</p>
      </div>

      <Tabs defaultValue="drivers" className="space-y-6">
        <TabsList>
          <TabsTrigger value="drivers">Manage Drivers</TabsTrigger>
          <TabsTrigger value="vehicles">Vehicles</TabsTrigger>
          <TabsTrigger value="assignments">Assign Jobs</TabsTrigger>
        </TabsList>

        <TabsContent value="drivers" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Driver Management</h3>
            <Button>Add New Driver</Button>
          </div>
          
          <div className="grid gap-4">
            {drivers.map((driver) => (
              <Card key={driver.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                        <Users className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{driver.name}</CardTitle>
                        <CardDescription>{driver.experience}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge>{driver.status}</Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48 bg-background z-50">
                          <DropdownMenuItem onClick={() => handleViewDriverDetails(driver)}>
                            <FileText className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAssignJob(driver)}>
                            <UserPlus className="h-4 w-4 mr-2" />
                            Assign Job
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleContactDriver(driver)}>
                            <Phone className="h-4 w-4 mr-2" />
                            Contact Driver
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleScheduleDriver(driver)}>
                            <Wrench className="h-4 w-4 mr-2" />
                            Manage Schedule
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleEditDriver(driver)}>
                            <FileText className="h-4 w-4 mr-2" />
                            Edit Profile
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="font-medium">Phone:</p>
                      <p className="text-muted-foreground">{driver.phone}</p>
                    </div>
                    <div>
                      <p className="font-medium">Current Vehicle:</p>
                      <p className="text-muted-foreground">{driver.vehicle}</p>
                    </div>
                    <div>
                      <p className="font-medium">Rating:</p>
                      <p className="text-muted-foreground">{driver.rating}</p>
                    </div>
                    <div>
                      <p className="font-medium">Status:</p>
                      <p className={driver.statusColor}>{driver.status}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm" onClick={() => handleViewDriverDetails(driver)}>View Details</Button>
                    <Button variant="outline" size="sm" onClick={() => handleAssignJob(driver)}>Assign Job</Button>
                    <Button variant="outline" size="sm" onClick={() => handleContactDriver(driver)}>Contact</Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="vehicles" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Vehicle Fleet</h3>
            <Button>Add New Vehicle</Button>
          </div>
          
          <div className="grid gap-4">
            {vehicles.map((vehicle) => (
              <Card key={vehicle.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-muted rounded-full flex items-center justify-center">
                        <Truck className="h-6 w-6" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{vehicle.name}</CardTitle>
                        <CardDescription>{vehicle.model}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge>{vehicle.status}</Badge>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48 bg-background z-50">
                          <DropdownMenuItem onClick={() => handleViewDetails(vehicle)}>
                            <FileText className="h-4 w-4 mr-2" />
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleTrackVehicle(vehicle)}>
                            <MapPin className="h-4 w-4 mr-2" />
                            Track Vehicle
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleAssignDriver(vehicle)}>
                            <UserPlus className="h-4 w-4 mr-2" />
                            Assign Driver
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleMaintenanceSchedule(vehicle)}>
                            <Wrench className="h-4 w-4 mr-2" />
                            Schedule Maintenance
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="font-medium">VIN:</p>
                      <p className="text-muted-foreground">{vehicle.vin}</p>
                    </div>
                    <div>
                      <p className="font-medium">License Plate:</p>
                      <p className="text-muted-foreground">{vehicle.licensePlate}</p>
                    </div>
                    <div>
                      <p className="font-medium">Current Driver:</p>
                      <p className="text-muted-foreground">{vehicle.currentDriver}</p>
                    </div>
                    <div>
                      <p className="font-medium">Status:</p>
                      <p className={vehicle.statusColor}>{vehicle.status}</p>
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleTrackVehicle(vehicle)}
                    >
                      Track Vehicle
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleViewDetails(vehicle)}
                    >
                      View Details
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleAssignDriver(vehicle)}
                    >
                      Assign Driver
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="assignments" className="space-y-4">
          <div>
            <h3 className="text-lg font-semibold">Job Assignment Center</h3>
            <p className="text-muted-foreground">Assign available jobs to your drivers and vehicles</p>
          </div>
          
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Available Jobs for Assignment</CardTitle>
                <CardDescription>Jobs waiting for driver and vehicle assignment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Chicago to Atlanta</p>
                      <p className="text-sm text-muted-foreground">Pickup: March 28, 9:00 AM • $1,800</p>
                    </div>
                    <Button size="sm">Assign</Button>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Boston to New York</p>
                      <p className="text-sm text-muted-foreground">Pickup: March 29, 7:00 AM • $950</p>
                    </div>
                    <Button size="sm">Assign</Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Assignment Tool</CardTitle>
                <CardDescription>Efficiently match jobs with available resources</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium">Select Job</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Chicago to Atlanta - $1,800</option>
                      <option>Boston to New York - $950</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Select Driver</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Mike Johnson (Available)</option>
                      <option>Robert Kim (Available)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Select Vehicle</label>
                    <select className="w-full mt-1 p-2 border rounded-md">
                      <option>Truck #12 (Available)</option>
                      <option>Truck #08 (Available)</option>
                    </select>
                  </div>
                </div>
                <Button className="mt-4">Create Assignment</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {/* Track Vehicle Dialog */}
      <Dialog open={isTrackingOpen} onOpenChange={setIsTrackingOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle className="text-2xl">Track Vehicle</DialogTitle>
            <DialogDescription>
              Real-time tracking for {selectedVehicle?.name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedVehicle && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Truck className="h-5 w-5 text-primary" />
                    <h4 className="font-semibold">Vehicle Information</h4>
                  </div>
                  <p className="text-sm"><span className="font-medium">Model:</span> {selectedVehicle.model}</p>
                  <p className="text-sm"><span className="font-medium">License Plate:</span> {selectedVehicle.licensePlate}</p>
                  <p className="text-sm"><span className="font-medium">Status:</span> <span className={selectedVehicle.statusColor}>{selectedVehicle.status}</span></p>
                </div>
                
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Users className="h-5 w-5 text-primary" />
                    <h4 className="font-semibold">Driver Information</h4>
                  </div>
                  <p className="text-sm"><span className="font-medium">Driver:</span> {selectedVehicle.currentDriver}</p>
                  <p className="text-sm"><span className="font-medium">VIN:</span> {selectedVehicle.vin}</p>
                </div>
              </div>

              <div className="bg-muted/50 rounded-lg p-8 text-center border-2 border-dashed">
                <MapPin className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
                <p className="text-sm font-medium mb-1">Live Tracking Map</p>
                <p className="text-xs text-muted-foreground">
                  Real-time GPS tracking will be displayed here
                </p>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsTrackingOpen(false)}
                  className="flex-1"
                >
                  Close
                </Button>
                <Button
                  onClick={() => {
                    toast.info('Driver contact feature coming soon');
                  }}
                  className="flex-1"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Contact Driver
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* View Details Dialog */}
      <Dialog open={isDetailsOpen} onOpenChange={setIsDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedVehicle?.name}</DialogTitle>
            <DialogDescription>
              Complete vehicle information and history
            </DialogDescription>
          </DialogHeader>
          
          {selectedVehicle && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Model</p>
                  <p className="text-base">{selectedVehicle.model}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <p className={`text-base ${selectedVehicle.statusColor}`}>{selectedVehicle.status}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">VIN</p>
                  <p className="text-base">{selectedVehicle.vin}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">License Plate</p>
                  <p className="text-base">{selectedVehicle.licensePlate}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Current Driver</p>
                  <p className="text-base">{selectedVehicle.currentDriver}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Vehicle ID</p>
                  <p className="text-base">#{selectedVehicle.id}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-semibold mb-3">Maintenance History</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Oil Change</span>
                    <span className="text-muted-foreground">Last: 2 weeks ago</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Tire Rotation</span>
                    <span className="text-muted-foreground">Last: 1 month ago</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Inspection</span>
                    <span className="text-muted-foreground">Last: 3 months ago</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsDetailsOpen(false)}
                  className="flex-1"
                >
                  Close
                </Button>
                <Button
                  onClick={() => handleMaintenanceSchedule(selectedVehicle)}
                  className="flex-1"
                >
                  <Wrench className="h-4 w-4 mr-2" />
                  Schedule Maintenance
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Assign Driver Dialog */}
      <Dialog open={isAssignDriverOpen} onOpenChange={setIsAssignDriverOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-2xl">Assign Driver</DialogTitle>
            <DialogDescription>
              Select a driver for {selectedVehicle?.name}
            </DialogDescription>
          </DialogHeader>
          
          {selectedVehicle && (
            <div className="space-y-6">
              <div className="p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center gap-3">
                  <Truck className="h-8 w-8 text-primary" />
                  <div>
                    <p className="font-semibold">{selectedVehicle.name}</p>
                    <p className="text-sm text-muted-foreground">{selectedVehicle.model}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Select Driver</label>
                <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a driver..." />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    {availableDrivers.map((driver) => (
                      <SelectItem key={driver.id} value={driver.name}>
                        {driver.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAssignDriverOpen(false);
                    setSelectedDriver('');
                  }}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleConfirmAssignment}
                  disabled={!selectedDriver}
                  className="flex-1"
                >
                  <UserPlus className="h-4 w-4 mr-2" />
                  Confirm Assignment
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Driver Details Dialog */}
      <Dialog open={isDriverDetailsOpen} onOpenChange={setIsDriverDetailsOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl">{selectedDriverDetails?.name}</DialogTitle>
            <DialogDescription>Complete driver information</DialogDescription>
          </DialogHeader>
          
          {selectedDriverDetails && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Experience</p>
                  <p className="text-base">{selectedDriverDetails.experience}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <p className={`text-base ${selectedDriverDetails.statusColor}`}>{selectedDriverDetails.status}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Phone</p>
                  <p className="text-base">{selectedDriverDetails.phone}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Current Vehicle</p>
                  <p className="text-base">{selectedDriverDetails.vehicle}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Rating</p>
                  <p className="text-base">{selectedDriverDetails.rating}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Driver ID</p>
                  <p className="text-base">#{selectedDriverDetails.id}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <h4 className="font-semibold mb-3">Recent Activity</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Job completed</span>
                    <span className="text-muted-foreground">2 hours ago</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Started route</span>
                    <span className="text-muted-foreground">5 hours ago</span>
                  </div>
                  <div className="flex justify-between p-2 bg-muted/50 rounded">
                    <span>Job accepted</span>
                    <span className="text-muted-foreground">6 hours ago</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsDriverDetailsOpen(false)}
                  className="flex-1"
                >
                  Close
                </Button>
                <Button
                  onClick={() => handleContactDriver(selectedDriverDetails)}
                  className="flex-1"
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Contact Driver
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}