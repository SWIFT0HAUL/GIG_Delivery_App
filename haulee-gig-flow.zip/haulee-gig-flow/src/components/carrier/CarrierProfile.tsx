import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Building, FileText, User, Camera, Truck, Shield, Upload, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { z } from 'zod';

const profileSchema = z.object({
  full_name: z.string().trim().min(1, "Name is required").max(100, "Name must be less than 100 characters"),
  phone: z.string().trim().min(10, "Phone number must be at least 10 digits").max(20, "Phone must be less than 20 characters"),
  email: z.string().trim().email("Invalid email address").max(255, "Email must be less than 255 characters"),
});

interface ProfileData {
  full_name: string;
  phone: string;
  email: string;
  avatar_url: string | null;
}

interface DocumentRecord {
  id: string;
  document_name: string;
  document_type: string;
  file_path: string;
  status: string;
  uploaded_at: string;
}

interface CompanyStatus {
  status: string;
  compliance_score: number;
  active_since: string;
  last_updated: string;
  insurance_verified: boolean;
  dot_number: string | null;
  mc_number: string | null;
}

export function CarrierProfile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState<ProfileData>({
    full_name: '',
    phone: '',
    email: '',
    avatar_url: null
  });
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [documentType, setDocumentType] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [viewingDoc, setViewingDoc] = useState<DocumentRecord | null>(null);
  const [companyStatus, setCompanyStatus] = useState<CompanyStatus | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user?.id) {
      fetchProfile();
      fetchDocuments();
      fetchCompanyStatus();
    }
  }, [user?.id]);

  const fetchDocuments = async () => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('user_documents')
      .select('*')
      .eq('user_id', user.id)
      .order('uploaded_at', { ascending: false });

    if (error) {
      console.error('Error fetching documents:', error);
    } else {
      setDocuments(data || []);
    }
  };

  const fetchCompanyStatus = async () => {
    if (!user?.id) return;

    try {
      const { data, error } = await supabase
        .from('carrier_company_status')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching company status:', error);
        return;
      }

      if (data) {
        setCompanyStatus(data);
      } else {
        // Create default status if none exists
        const { data: newStatus, error: insertError } = await supabase
          .from('carrier_company_status')
          .insert({
            user_id: user.id,
            status: 'active',
            compliance_score: 0,
          })
          .select()
          .single();

        if (insertError) {
          console.error('Error creating company status:', insertError);
        } else {
          setCompanyStatus(newStatus);
        }
      }
    } catch (error) {
      console.error('Error in fetchCompanyStatus:', error);
    }
  };

  const fetchProfile = async () => {
    if (!user?.id) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('profiles')
      .select('full_name, phone, email, avatar_url')
      .eq('id', user.id)
      .single();

    if (error) {
      console.error('Error fetching profile:', error);
      toast.error('Failed to load profile');
    } else {
      setProfile({
        full_name: data.full_name || '',
        phone: data.phone || '',
        email: data.email || user.email || '',
        avatar_url: data.avatar_url || null
      });
    }
    setLoading(false);
  };

  const handleInputChange = (field: keyof ProfileData, value: string) => {
    setProfile(prev => ({ ...prev, [field]: value }));
    // Clear error for this field when user starts typing
    if (errors[field]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[field];
        return newErrors;
      });
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id) {
      toast.error('Not authenticated');
      return;
    }

    setErrors({});

    try {
      const validatedData = profileSchema.parse({
        full_name: profile.full_name,
        phone: profile.phone,
        email: profile.email,
      });

      setSaving(true);

      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: validatedData.full_name,
          phone: validatedData.phone,
          email: validatedData.email,
        })
        .eq('id', user.id);

      if (error) throw error;

      toast.success('Profile updated successfully');
      // Refresh profile data
      await fetchProfile();
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0] as string] = err.message;
          }
        });
        setErrors(fieldErrors);
        toast.error('Please fix the validation errors');
      } else {
        console.error('Error updating profile:', error);
        toast.error('Failed to update profile');
      }
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!user?.id || !event.target.files || event.target.files.length === 0) {
      return;
    }

    const file = event.target.files[0];
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
      toast.error('Please upload an image file');
      return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('Image must be less than 5MB');
      return;
    }

    setUploading(true);

    try {
      // Get user's storage path
      const { data: pathData, error: pathError } = await supabase.rpc('get_user_storage_path', {
        _user_id: user.id
      });

      if (pathError || !pathData) {
        throw new Error('Could not get storage path');
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `avatar-${Date.now()}.${fileExt}`;
      const filePath = `${pathData}${fileName}`;

      // Upload to Supabase storage
      const { error: uploadError } = await supabase.storage
        .from('profiles')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: true
        });

      if (uploadError) {
        console.error('Upload error:', uploadError);
        throw uploadError;
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('profiles')
        .getPublicUrl(filePath);

      // Save avatar URL to profile
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ avatar_url: publicUrl })
        .eq('id', user.id);

      if (updateError) {
        console.error('Error saving avatar URL:', updateError);
        throw updateError;
      }

      setProfile(prev => ({ ...prev, avatar_url: publicUrl }));
      toast.success('Profile picture updated successfully');
      
      // Refresh profile to get the new avatar
      await fetchProfile();
    } catch (error: any) {
      console.error('Error uploading avatar:', error);
      if (error?.message?.includes('row-level security')) {
        toast.error('Storage permission error. Please contact support.');
      } else {
        toast.error('Failed to upload profile picture');
      }
    } finally {
      setUploading(false);
    }
  };

  const handleDocumentUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    if (!user?.id || !event.target.files || event.target.files.length === 0) {
      return;
    }

    if (!documentType) {
      toast.error('Please select a document type');
      return;
    }

    const file = event.target.files[0];
    
    // Validate file size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast.error('File must be less than 10MB');
      return;
    }

    setUploading(true);

    try {
      // Get user's storage path
      const { data: pathData } = await supabase.rpc('get_user_storage_path', {
        _user_id: user.id
      });

      if (!pathData) {
        throw new Error('Could not get storage path');
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${documentType}-${Date.now()}.${fileExt}`;
      const filePath = `${pathData}documents/${fileName}`;

      // Upload to storage
      const { error: uploadError } = await supabase.storage
        .from('carrier')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      // Save document record
      const { error: dbError } = await supabase
        .from('user_documents')
        .insert({
          user_id: user.id,
          document_name: file.name,
          document_type: documentType,
          file_path: filePath,
          file_size: file.size,
          status: 'pending'
        });

      if (dbError) throw dbError;

      toast.success('Document uploaded successfully');
      setDocumentType('');
      setExpiryDate('');
      if (docInputRef.current) {
        docInputRef.current.value = '';
      }
      // Refresh documents list
      await fetchDocuments();
    } catch (error) {
      console.error('Error uploading document:', error);
      toast.error('Failed to upload document');
    } finally {
      setUploading(false);
    }
  };

  const handleViewDocument = async (doc: DocumentRecord) => {
    try {
      const { data, error } = await supabase.storage
        .from('carrier')
        .createSignedUrl(doc.file_path, 3600); // 1 hour expiry

      if (error) throw error;

      if (data?.signedUrl) {
        window.open(data.signedUrl, '_blank');
      }
    } catch (error) {
      console.error('Error viewing document:', error);
      toast.error('Failed to view document');
    }
  };

  const handleUpdateDocument = (doc: DocumentRecord) => {
    setDocumentType(doc.document_type);
    setViewingDoc(doc);
    toast.info('Select a new file to replace this document');
    docInputRef.current?.click();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Profile & Settings</h2>
        <p className="text-muted-foreground">Manage your carrier company profile and settings</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building className="h-5 w-5" />
              Company Information
            </CardTitle>
            <CardDescription>Update your carrier company details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-4">
              <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center overflow-hidden">
                {profile.avatar_url ? (
                  <img src={profile.avatar_url} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  <Building className="h-8 w-8 text-muted-foreground" />
                )}
              </div>
              <div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleAvatarUpload}
                  className="hidden"
                />
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex items-center gap-2"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                >
                  {uploading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Camera className="h-4 w-4" />
                  )}
                  Update Logo
                </Button>
                <p className="text-xs text-muted-foreground mt-1">JPG, PNG up to 5MB</p>
              </div>
            </div>

            <div>
              <Label htmlFor="full_name">Full Name</Label>
              <Input 
                id="full_name"
                value={profile.full_name}
                onChange={(e) => handleInputChange('full_name', e.target.value)}
                className={errors.full_name ? 'border-red-500' : ''}
              />
              {errors.full_name && (
                <p className="text-xs text-red-500 mt-1">{errors.full_name}</p>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="phone">Phone Number</Label>
                <Input 
                  id="phone"
                  value={profile.phone}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  className={errors.phone ? 'border-red-500' : ''}
                />
                {errors.phone && (
                  <p className="text-xs text-red-500 mt-1">{errors.phone}</p>
                )}
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input 
                  id="email"
                  type="email"
                  value={profile.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className={errors.email ? 'border-red-500' : ''}
                />
                {errors.email && (
                  <p className="text-xs text-red-500 mt-1">{errors.email}</p>
                )}
              </div>
            </div>

            <Button onClick={handleSaveProfile} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Update Profile Information'
              )}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Company Status</CardTitle>
            <CardDescription>Your carrier certification and status</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {companyStatus ? (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Status</span>
                  <Badge variant={companyStatus.status === 'active' ? 'default' : 'secondary'}>
                    {companyStatus.status.charAt(0).toUpperCase() + companyStatus.status.slice(1)}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Last Updated</span>
                  <span className="text-sm font-medium">
                    {new Date(companyStatus.last_updated).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Compliance Score</span>
                  <span className="text-sm font-medium">{companyStatus.compliance_score}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Active Since</span>
                  <span className="text-sm font-medium">
                    {new Date(companyStatus.active_since).toLocaleDateString('en-US', { 
                      month: 'short', 
                      year: 'numeric' 
                    })}
                  </span>
                </div>
                {companyStatus.insurance_verified && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Insurance</span>
                    <Badge variant="default">Verified</Badge>
                  </div>
                )}
                {companyStatus.dot_number && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">DOT Number</span>
                    <span className="text-sm font-medium">{companyStatus.dot_number}</span>
                  </div>
                )}
                {companyStatus.mc_number && (
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">MC Number</span>
                    <span className="text-sm font-medium">{companyStatus.mc_number}</span>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center text-muted-foreground py-4">
                <Loader2 className="h-6 w-6 animate-spin mx-auto" />
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Required Documents
          </CardTitle>
          <CardDescription>Keep your carrier documents up to date</CardDescription>
        </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {documents.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <FileText className="h-5 w-5 text-blue-600" />
                    <div>
                      <p className="font-medium">{doc.document_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(doc.uploaded_at).toLocaleDateString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          year: 'numeric'
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant={doc.status === 'approved' ? 'default' : 'secondary'}>
                      {doc.status === 'approved' ? 'Valid' : doc.status}
                    </Badge>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleViewDocument(doc)}
                    >
                      View
                    </Button>
                    <Button 
                      variant="outline" 
                      size="sm"
                      onClick={() => handleUpdateDocument(doc)}
                    >
                      Update
                    </Button>
                  </div>
                </div>
              ))}

              {documents.length === 0 && (
                <div className="col-span-2 text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No documents uploaded yet</p>
                  <p className="text-sm">Upload your carrier documents below</p>
                </div>
              )}
            </div>

          <div className="mt-6">
            <h4 className="font-medium mb-4">Upload New Document</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="documentType">Document Type</Label>
                <Select value={documentType} onValueChange={setDocumentType}>
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue placeholder="Select document type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="insurance">Insurance Certificate</SelectItem>
                    <SelectItem value="dot_authority">DOT Authority</SelectItem>
                    <SelectItem value="mc_authority">MC Authority</SelectItem>
                    <SelectItem value="w9">W-9 Form</SelectItem>
                    <SelectItem value="safety">Safety Document</SelectItem>
                    <SelectItem value="certificate">Certificate</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="expiryDate">Expiry Date (if applicable)</Label>
                <Input 
                  id="expiryDate" 
                  type="date" 
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                  className="mt-1"
                />
              </div>
            </div>
            
            <input
              ref={docInputRef}
              type="file"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={handleDocumentUpload}
              className="hidden"
            />
            
            <div 
              className="mt-4 border-2 border-dashed border-muted-foreground/25 rounded-lg p-6 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onClick={() => docInputRef.current?.click()}
            >
              {uploading ? (
                <>
                  <Loader2 className="h-8 w-8 mx-auto mb-2 text-primary animate-spin" />
                  <p className="text-sm text-muted-foreground">Uploading...</p>
                </>
              ) : (
                <>
                  <Upload className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-sm text-muted-foreground">Drop files here or click to browse</p>
                  <p className="text-xs text-muted-foreground mt-1">PDF, JPG, PNG up to 10MB</p>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}