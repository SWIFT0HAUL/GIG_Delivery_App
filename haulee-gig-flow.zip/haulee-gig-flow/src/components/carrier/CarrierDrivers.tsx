import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { UserPlus, Search, Phone, Mail, RefreshCw, Eye, EyeOff, Loader2, Truck, MoreVertical, UserX } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast as sonnerToast } from 'sonner';

interface DriverFormData {
  email: string;
  password: string;
  first_name: string;
  middle_name: string;
  last_name: string;
  phone: string;
  vehicle_assignment: string;
  role: string;
  sub_role: string;
}

interface CarrierDriver {
  id: string;
  email: string;
  full_name: string;
  phone: string | null;
  vehicle_assignment: string | null;
  is_active: boolean;
  status: string;
  created_at: string;
}

export const CarrierDrivers: React.FC = () => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isVehicleDialogOpen, setIsVehicleDialogOpen] = useState(false);
  const [isDeactivationDialogOpen, setIsDeactivationDialogOpen] = useState(false);
  const [selectedDriver, setSelectedDriver] = useState<CarrierDriver | null>(null);
  const [vehicleInput, setVehicleInput] = useState('');
  const [deactivationReason, setDeactivationReason] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [hasNoMiddleName, setHasNoMiddleName] = useState(false);
  const [formData, setFormData] = useState<DriverFormData>({
    email: '',
    password: '',
    first_name: '',
    middle_name: '',
    last_name: '',
    phone: '',
    vehicle_assignment: '',
    role: 'driver',
    sub_role: 'carrier_driver',
  });
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const generatePassword = () => {
    // Generate 12-character password with at least one special character
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijkmnopqrstuvwxyz';
    const numbers = '0123456789';
    const special = '!@#$%^&*';
    const allChars = uppercase + lowercase + numbers + special;
    
    // Ensure at least one character from each category
    let password = '';
    password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
    password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
    password += numbers.charAt(Math.floor(Math.random() * numbers.length));
    password += special.charAt(Math.floor(Math.random() * special.length));
    
    // Fill the rest randomly to reach 12 characters
    for (let i = password.length; i < 12; i++) {
      password += allChars.charAt(Math.floor(Math.random() * allChars.length));
    }
    
    // Shuffle the password
    password = password.split('').sort(() => Math.random() - 0.5).join('');
    
    setFormData(prev => ({ ...prev, password }));
    setShowPassword(true);
    sonnerToast.success('Password generated successfully');
  };

  // Fetch carrier's drivers from database
  const { data: drivers = [], isLoading } = useQuery<CarrierDriver[]>({
    queryKey: ['carrier-drivers', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase.rpc('get_carrier_drivers' as any);

      if (error) throw error;
      
      // Map the returned data to include status field
      // Ensure status is always 'active' or 'suspended'
      const driversWithStatus = (data || []).map((driver: any) => ({
        ...driver,
        status: driver.status === 'active' ? 'active' : 'suspended'
      }));
      
      return driversWithStatus as CarrierDriver[];
    },
    enabled: !!user?.id
  });

  // Add driver to fleet mutation
  const addDriverMutation = useMutation({
    mutationFn: async (data: DriverFormData) => {
      console.log('Adding driver to fleet:', data.email);
      
      // Combine names
      const fullName = hasNoMiddleName 
        ? `${data.first_name.trim()} ${data.last_name.trim()}`
        : `${data.first_name.trim()} ${data.middle_name.trim()} ${data.last_name.trim()}`;
      
      // Call the create-driver edge function
      const { data: result, error } = await supabase.functions.invoke('create-driver', {
        body: {
          email: data.email.trim(),
          password: data.password,
          first_name: data.first_name.trim(),
          middle_name: hasNoMiddleName ? '' : data.middle_name.trim(),
          last_name: data.last_name.trim(),
          phone: data.phone.trim(),
          vehicle_assignment: data.vehicle_assignment || null,
          role_key: data.role,
          sub_role: data.sub_role
        }
      });

      // Check for errors from the edge function
      if (error) {
        throw new Error(error.message || 'Failed to create driver');
      }
      
      // Check if the response contains an error
      if (result?.error) {
        throw new Error(result.error);
      }
      
      if (!result?.success) {
        throw new Error('Failed to create driver');
      }
      
      return result;
    },
    onSuccess: () => {
      toast({
        title: 'Driver added successfully',
        description: 'The driver has been added with suspended status until admin activation.',
      });
      queryClient.invalidateQueries({ queryKey: ['carrier-drivers', user?.id] });
      setIsDialogOpen(false);
      setFormData({
        email: '',
        password: '',
        first_name: '',
        middle_name: '',
        last_name: '',
        phone: '',
        vehicle_assignment: '',
        role: 'driver',
        sub_role: 'carrier_driver',
      });
      setHasNoMiddleName(false);
    },
    onError: (error: any) => {
      console.error('Error adding driver:', error);
      
      // Extract a user-friendly error message
      let errorMessage = 'Failed to add driver. Please try again.';
      
      if (error.message) {
        errorMessage = error.message;
      } else if (typeof error === 'string') {
        errorMessage = error;
      }
      
      toast({
        title: 'Error adding driver',
        description: errorMessage,
        variant: 'destructive',
      });
    }
  });

  // Update vehicle assignment mutation
  const updateVehicleMutation = useMutation({
    mutationFn: async ({ driverId, vehicle }: { driverId: string; vehicle: string }) => {
      const { error } = await supabase
        .from('carrier_drivers')
        .update({ vehicle_assignment: vehicle || null })
        .eq('driver_id', driverId)
        .eq('carrier_id', user?.id);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: 'Vehicle updated',
        description: 'Vehicle assignment has been updated successfully.',
      });
      queryClient.invalidateQueries({ queryKey: ['carrier-drivers', user?.id] });
      setIsVehicleDialogOpen(false);
      setSelectedDriver(null);
      setVehicleInput('');
    },
    onError: (error: any) => {
      console.error('Error updating vehicle:', error);
      toast({
        title: 'Error updating vehicle',
        description: error.message || 'Failed to update vehicle assignment.',
        variant: 'destructive',
      });
    }
  });

  const handleVehicleUpdate = (driver: CarrierDriver) => {
    setSelectedDriver(driver);
    setVehicleInput(driver.vehicle_assignment || '');
    setIsVehicleDialogOpen(true);
  };

  const handleDeactivationRequest = (driver: CarrierDriver) => {
    setSelectedDriver(driver);
    setDeactivationReason('');
    setIsDeactivationDialogOpen(true);
  };

  // Submit deactivation request mutation
  const submitDeactivationMutation = useMutation({
    mutationFn: async ({ driverId, reason }: { driverId: string; reason: string }) => {
      if (!user?.id) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('driver_support_messages')
        .insert({
          user_id: driverId,
          message: `DEACTIVATION REQUEST from Carrier: ${reason}`,
          is_support_agent: false,
          sender_name: 'Carrier'
        });

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: 'Request sent',
        description: 'Your driver deactivation request has been sent to support.',
      });
      setIsDeactivationDialogOpen(false);
      setSelectedDriver(null);
      setDeactivationReason('');
    },
    onError: (error: any) => {
      console.error('Error submitting deactivation request:', error);
      toast({
        title: 'Error',
        description: 'Failed to submit deactivation request. Please try again.',
        variant: 'destructive',
      });
    }
  });

  const handleVehicleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (selectedDriver) {
      updateVehicleMutation.mutate({
        driverId: selectedDriver.id,
        vehicle: vehicleInput.trim()
      });
    }
  };


  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.email.trim()) {
      sonnerToast.error('Email is required');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email.trim())) {
      sonnerToast.error('Please enter a valid email address');
      return;
    }
    
    if (!formData.password || formData.password.length < 12) {
      sonnerToast.error('Password must be at least 12 characters');
      return;
    }
    
    // Check for at least one special character
    const specialCharRegex = /[!@#$%^&*]/;
    if (!specialCharRegex.test(formData.password)) {
      sonnerToast.error('Password must include at least one special character (!@#$%^&*)');
      return;
    }
    
    if (!formData.first_name.trim()) {
      sonnerToast.error('First name is required');
      return;
    }
    
    if (!formData.last_name.trim()) {
      sonnerToast.error('Last name is required');
      return;
    }
    
    if (!hasNoMiddleName && !formData.middle_name.trim()) {
      sonnerToast.error('Middle name is required or check "No middle name"');
      return;
    }
    
    if (!formData.phone.trim()) {
      sonnerToast.error('Phone is required');
      return;
    }
    
    addDriverMutation.mutate(formData);
  };


  const filteredDrivers = drivers.filter(driver => 
    driver.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    driver.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold">Driver Management</h2>
          <p className="text-muted-foreground">Manage your driver team</p>
        </div>
        <Button onClick={() => setIsDialogOpen(true)}>
          <UserPlus className="h-4 w-4 mr-2" />
          Add Driver
        </Button>
      </div>

      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search drivers..." 
            className="pl-9" 
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Drivers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{drivers.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{drivers.filter(d => d.status === 'active').length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Suspended</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{drivers.filter(d => d.status === 'suspended').length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Drivers</CardTitle>
          <CardDescription>Manage your driver roster</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            To remove a driver from your fleet, please contact support.
          </p>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Vehicle</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">Loading drivers...</TableCell>
                </TableRow>
              ) : filteredDrivers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center">No drivers found</TableCell>
                </TableRow>
              ) : (
                filteredDrivers.map((driver) => (
                  <TableRow key={driver.id}>
                    <TableCell className="font-medium">{driver.full_name || 'N/A'}</TableCell>
                    <TableCell>{driver.email}</TableCell>
                    <TableCell>{driver.phone || 'N/A'}</TableCell>
                    <TableCell>{driver.vehicle_assignment || 'Unassigned'}</TableCell>
                    <TableCell>
                      <Badge variant={driver.status === 'active' ? 'default' : 'secondary'}>
                        {driver.status === 'active' ? 'Active' : 'Suspended'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleVehicleUpdate(driver)}>
                            <Truck className="h-4 w-4 mr-2" />
                            Update Vehicle
                          </DropdownMenuItem>
                          {driver.phone && (
                            <DropdownMenuItem asChild>
                              <a href={`tel:${driver.phone}`}>
                                <Phone className="h-4 w-4 mr-2" />
                                Call Driver
                              </a>
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem asChild>
                            <a href={`mailto:${driver.email}`}>
                              <Mail className="h-4 w-4 mr-2" />
                              Send Email
                            </a>
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            onClick={() => handleDeactivationRequest(driver)}
                            className="text-destructive focus:text-destructive"
                          >
                            <UserX className="h-4 w-4 mr-2" />
                            Request Deactivation
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-5 w-5" />
              Add New Driver
            </DialogTitle>
          </DialogHeader>

          <form onSubmit={handleFormSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                placeholder="driver@example.com"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password *</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    placeholder="Min. 12 characters + special char"
                    minLength={12}
                    required
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                    onClick={() => setShowPassword(!showPassword)}
                    title={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? (
                      <EyeOff className="h-4 w-4 text-muted-foreground" />
                    ) : (
                      <Eye className="h-4 w-4 text-muted-foreground" />
                    )}
                  </Button>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={generatePassword}
                  title="Generate Password"
                >
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Minimum 12 characters with at least one special character (!@#$%^&*) required.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="first_name">First Name *</Label>
              <Input
                id="first_name"
                value={formData.first_name}
                onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                placeholder="John"
                required
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="middle_name">Middle Name {!hasNoMiddleName && '*'}</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="no_middle_name"
                    checked={hasNoMiddleName}
                    onCheckedChange={(checked) => {
                      setHasNoMiddleName(checked as boolean);
                      if (checked) {
                        setFormData({ ...formData, middle_name: '' });
                      }
                    }}
                  />
                  <Label 
                    htmlFor="no_middle_name" 
                    className="text-xs font-normal cursor-pointer"
                  >
                    No middle name
                  </Label>
                </div>
              </div>
              <Input
                id="middle_name"
                value={formData.middle_name}
                onChange={(e) => setFormData({ ...formData, middle_name: e.target.value })}
                placeholder="Michael"
                required={!hasNoMiddleName}
                disabled={hasNoMiddleName}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="last_name">Last Name *</Label>
              <Input
                id="last_name"
                value={formData.last_name}
                onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                placeholder="Doe"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone *</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                placeholder="+1 (555) 000-0000"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Role</Label>
              <Input
                id="role"
                value="Driver"
                disabled
                className="bg-muted"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sub_role">Sub-Role</Label>
              <Input
                id="sub_role"
                value="Carrier Driver"
                disabled
                className="bg-muted"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicle_assignment">Vehicle Assignment (Optional)</Label>
              <Input
                id="vehicle_assignment"
                value={formData.vehicle_assignment}
                onChange={(e) => setFormData({ ...formData, vehicle_assignment: e.target.value })}
                placeholder="Truck #24"
              />
            </div>

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsDialogOpen(false)}
                disabled={addDriverMutation.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={addDriverMutation.isPending}>
                {addDriverMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Create Driver
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Vehicle Update Dialog */}
      <Dialog open={isVehicleDialogOpen} onOpenChange={setIsVehicleDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Truck className="h-5 w-5" />
              Update Vehicle Assignment
            </DialogTitle>
            <DialogDescription>
              {selectedDriver && `Update vehicle for ${selectedDriver.full_name}`}
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleVehicleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="vehicle_update">Vehicle Assignment</Label>
              <Input
                id="vehicle_update"
                value={vehicleInput}
                onChange={(e) => setVehicleInput(e.target.value)}
                placeholder="Truck #24 or leave empty to unassign"
              />
              <p className="text-xs text-muted-foreground">
                Enter the vehicle identifier or leave empty to unassign
              </p>
            </div>

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsVehicleDialogOpen(false);
                  setSelectedDriver(null);
                  setVehicleInput('');
                }}
                disabled={updateVehicleMutation.isPending}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={updateVehicleMutation.isPending}>
                {updateVehicleMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Update Vehicle
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Driver Deactivation Request Dialog */}
      <Dialog open={isDeactivationDialogOpen} onOpenChange={setIsDeactivationDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserX className="h-5 w-5 text-destructive" />
              Request Driver Deactivation
            </DialogTitle>
            <DialogDescription>
              {selectedDriver && `Submit a request to support to deactivate ${selectedDriver.full_name}`}
            </DialogDescription>
          </DialogHeader>

          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (selectedDriver && deactivationReason.trim()) {
                submitDeactivationMutation.mutate({ 
                  driverId: selectedDriver.id, 
                  reason: deactivationReason 
                });
              }
            }} 
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="deactivation_reason">Reason for Deactivation</Label>
              <Textarea
                id="deactivation_reason"
                value={deactivationReason}
                onChange={(e) => setDeactivationReason(e.target.value)}
                placeholder="Please provide a detailed reason for requesting driver deactivation..."
                rows={4}
                required
              />
              <p className="text-xs text-muted-foreground">
                This request will be sent to support for review. The driver will remain active until support processes your request.
              </p>
            </div>

            <DialogFooter className="gap-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setIsDeactivationDialogOpen(false);
                  setSelectedDriver(null);
                  setDeactivationReason('');
                }}
                disabled={submitDeactivationMutation.isPending}
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                variant="destructive"
                disabled={submitDeactivationMutation.isPending || !deactivationReason.trim()}
              >
                {submitDeactivationMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Submit Request
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};
