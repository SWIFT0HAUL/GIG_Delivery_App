import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Truck, MapPin, Clock, Package, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const CarrierDispatch: React.FC = () => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedDrivers, setSelectedDrivers] = useState<Record<string, string>>({});
  const [isCancelDialogOpen, setIsCancelDialogOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [jobToCancel, setJobToCancel] = useState<string | null>(null);

  // Fetch unassigned jobs from database
  const { data: unassignedJobs = [], isLoading: isLoadingJobs } = useQuery({
    queryKey: ['carrier-unassigned-jobs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'claimed')
        .is('assigned_driver_id', null)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch available drivers
  const { data: availableDrivers = [], isLoading: isLoadingDrivers } = useQuery({
    queryKey: ['carrier-available-drivers'],
    queryFn: async () => {
      const { data: drivers, error } = await supabase
        .from('profiles')
        .select('*, driver_status(*)')
        .eq('role_key', 'driver')
        .eq('is_active', true);
      
      if (error) throw error;
      return drivers?.map(d => {
        const status = Array.isArray(d.driver_status) ? d.driver_status[0] : null;
        return {
          id: d.id,
          name: d.full_name || d.email?.split('@')[0] || 'Unknown',
          vehicle: 'Truck #' + d.id.slice(0, 2).toUpperCase(),
          location: status?.current_location || 'Unknown',
          status: status?.is_online ? 'available' : 'offline'
        };
      }) || [];
    }
  });

  // Fetch recent assignments
  const { data: recentAssignments = [] } = useQuery({
    queryKey: ['carrier-recent-assignments'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('job_assignments')
        .select(`
          *,
          jobs(*),
          profiles:driver_id(full_name, email)
        `)
        .in('status', ['assigned', 'in_progress'])
        .order('created_at', { ascending: false })
        .limit(5);
      
      if (error) throw error;
      return data || [];
    }
  });

  // Assign driver mutation
  const assignDriverMutation = useMutation({
    mutationFn: async ({ jobId, driverId }: { jobId: string; driverId: string }) => {
      // Create job assignment
      const { error: assignError } = await supabase
        .from('job_assignments')
        .insert({
          job_id: jobId,
          driver_id: driverId,
          status: 'assigned'
        });
      
      if (assignError) throw assignError;

      // Update job status
      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'assigned',
          assigned_driver_id: driverId 
        })
        .eq('id', jobId);
      
      if (jobError) throw jobError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['carrier-unassigned-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['carrier-recent-assignments'] });
      toast.success('Job assigned successfully');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to assign job');
    }
  });

  // Remove job mutation
  const removeJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      const { error } = await supabase
        .from('jobs')
        .update({ 
          status: 'cancelled',
          cancellation_reason: cancelReason
        })
        .eq('id', jobId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['carrier-unassigned-jobs'] });
      toast.success('Job removed from dispatch queue');
      setIsCancelDialogOpen(false);
      setJobToCancel(null);
      setCancelReason('');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to remove job');
    }
  });

  const openCancelDialog = (jobId: string) => {
    setJobToCancel(jobId);
    setCancelReason('');
    setIsCancelDialogOpen(true);
  };

  const handleCancelJob = () => {
    if (!cancelReason) {
      toast.error('Please select a cancellation reason');
      return;
    }

    if (!jobToCancel) return;

    removeJobMutation.mutate(jobToCancel);
    setSelectedDrivers(prev => {
      const updated = { ...prev };
      delete updated[jobToCancel];
      return updated;
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold">Dispatch Center</h2>
          <p className="text-muted-foreground">Assign jobs to available drivers</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Unassigned Jobs</CardTitle>
            <CardDescription>Jobs waiting for driver assignment</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingJobs ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : unassignedJobs.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Package className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p>No unassigned jobs</p>
                <p className="text-sm">Accept jobs from the Jobs section to see them here</p>
              </div>
            ) : (
              <div className="space-y-4">
                {unassignedJobs.map((job) => {
                  const pickupAddr = (job.pickup_location as any)?.address || 'Pickup Location';
                  const deliveryAddr = (job.delivery_location as any)?.address || 'Delivery Location';
                  const distance = job.distance_miles ? `${job.distance_miles} mi` : 'N/A';
                  
                  return (
                    <div key={job.id} className="bg-card border-l-4 border-l-primary rounded-lg p-4 space-y-4 shadow-sm">
                      {/* Header: Job ID & Payment */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="space-y-1">
                          <p className="text-sm font-semibold text-foreground">
                            {job.title || `Job #${job.id.slice(0, 8)}`}
                          </p>
                          <p className="text-xs text-muted-foreground">ID: {job.id.slice(0, 8)}</p>
                        </div>
                        <div className="flex flex-col items-end gap-1 bg-primary/10 px-3 py-2 rounded">
                          <span className="text-[10px] font-medium text-muted-foreground uppercase">Payment</span>
                          <span className="text-lg font-bold text-primary">${job.pay_amount}</span>
                        </div>
                      </div>

                      {/* Route Information */}
                      <div className="bg-muted/30 rounded-md p-3 space-y-2.5">
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-0.5">From</p>
                            <p className="text-xs font-medium text-foreground">{pickupAddr}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 pl-1">
                          <div className="w-3 border-l-2 border-dashed border-muted-foreground/30 h-4"></div>
                          <div className="flex items-center gap-2 text-xs text-muted-foreground">
                            <Clock className="h-3 w-3" />
                            <span className="font-medium">{distance}</span>
                          </div>
                        </div>
                        <div className="flex items-start gap-2">
                          <MapPin className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-[10px] font-semibold text-muted-foreground uppercase mb-0.5">To</p>
                            <p className="text-xs font-medium text-foreground">{deliveryAddr}</p>
                          </div>
                        </div>
                      </div>

                      {/* Driver Assignment Controls */}
                      <div className="space-y-2 pt-2 border-t">
                        <Label className="text-xs font-semibold text-foreground">Assign to Driver</Label>
                        <Select 
                          value={selectedDrivers[job.id] || ''} 
                          onValueChange={(value) => setSelectedDrivers(prev => ({ ...prev, [job.id]: value }))}
                        >
                          <SelectTrigger className="h-9">
                            <SelectValue placeholder="Choose a driver..." />
                          </SelectTrigger>
                          <SelectContent>
                            {availableDrivers.map((driver) => (
                              <SelectItem key={driver.id} value={driver.id}>
                                {driver.name} - {driver.vehicle}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <div className="flex gap-2 pt-1">
                          <Button 
                            size="sm"
                            className="flex-1 h-9"
                            disabled={!selectedDrivers[job.id] || assignDriverMutation.isPending}
                            onClick={() => {
                              const driverId = selectedDrivers[job.id];
                              if (driverId) {
                                assignDriverMutation.mutate({ jobId: job.id, driverId });
                                setSelectedDrivers(prev => {
                                  const updated = { ...prev };
                                  delete updated[job.id];
                                  return updated;
                                });
                              }
                            }}
                          >
                            <Truck className="h-4 w-4 mr-2" />
                            Dispatch
                          </Button>
                          <Button 
                            size="sm"
                            variant="outline"
                            className="h-9"
                            onClick={() => openCancelDialog(job.id)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Available Drivers</CardTitle>
            <CardDescription>Drivers ready for assignment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {availableDrivers.map((driver) => (
                <div key={driver.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold">{driver.name}</span>
                    <Badge variant="secondary">{driver.status}</Badge>
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <Truck className="h-4 w-4" />
                      <span>{driver.vehicle}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4" />
                      <span>{driver.location}</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full">View Details</Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Assignments</CardTitle>
          <CardDescription>Recently dispatched jobs</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Job ID</TableHead>
                <TableHead>Driver</TableHead>
                <TableHead>Route</TableHead>
                <TableHead>Assigned</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-medium">J-0998</TableCell>
                <TableCell>Emily Davis</TableCell>
                <TableCell>Phoenix, AZ → Las Vegas, NV</TableCell>
                <TableCell>15 mins ago</TableCell>
                <TableCell><Badge>In Progress</Badge></TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-medium">J-0997</TableCell>
                <TableCell>Robert Brown</TableCell>
                <TableCell>Seattle, WA → San Francisco, CA</TableCell>
                <TableCell>1 hour ago</TableCell>
                <TableCell><Badge>In Progress</Badge></TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={isCancelDialogOpen} onOpenChange={setIsCancelDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel Job</DialogTitle>
            <DialogDescription>
              Please select a reason for cancelling this job.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="cancel-reason">Cancellation Reason</Label>
              <Select value={cancelReason} onValueChange={setCancelReason}>
                <SelectTrigger id="cancel-reason">
                  <SelectValue placeholder="Select a reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="vehicle_unavailable">Vehicle Unavailable</SelectItem>
                  <SelectItem value="driver_unavailable">Driver Unavailable</SelectItem>
                  <SelectItem value="route_conflict">Route Conflict</SelectItem>
                  <SelectItem value="capacity_issue">Capacity Issue</SelectItem>
                  <SelectItem value="timing_conflict">Timing Conflict</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCancelDialogOpen(false)}>
              Keep Job
            </Button>
            <Button variant="destructive" onClick={handleCancelJob}>
              Confirm Cancellation
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
