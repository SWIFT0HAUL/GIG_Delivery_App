import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Wrench, Calendar, AlertTriangle, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { z } from 'zod';

const maintenanceSchema = z.object({
  vehicle_name: z.string().trim().min(1, "Vehicle is required").max(100, "Vehicle name must be less than 100 characters"),
  maintenance_type: z.string().trim().min(1, "Maintenance type is required").max(100, "Type must be less than 100 characters"),
  scheduled_date: z.string().min(1, "Date is required"),
  notes: z.string().max(500, "Notes must be less than 500 characters").optional(),
});

interface MaintenanceRecord {
  id: string;
  vehicle_id: string | null;
  maintenance_type: string;
  scheduled_date: string;
  status: string;
  notes: string | null;
  created_at: string;
  vehicles?: {
    name: string;
  };
}

export const CarrierMaintenance: React.FC = () => {
  const { user } = useAuth();
  const [isScheduleOpen, setIsScheduleOpen] = useState(false);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [maintenanceSchedule, setMaintenanceSchedule] = useState<MaintenanceRecord[]>([]);
  const [selectedRecord, setSelectedRecord] = useState<MaintenanceRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [newMaintenance, setNewMaintenance] = useState({
    vehicle_name: '',
    maintenance_type: '',
    scheduled_date: '',
    notes: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (user?.id) {
      fetchMaintenanceSchedules();
    }
  }, [user?.id]);

  const fetchMaintenanceSchedules = async () => {
    if (!user?.id) return;

    setLoading(true);
    const { data, error } = await supabase
      .from('maintenance_schedules')
      .select(`
        *,
        vehicles (
          name
        )
      `)
      .eq('user_id', user.id)
      .order('scheduled_date', { ascending: false });

    if (error) {
      console.error('Error fetching maintenance schedules:', error);
      toast.error('Failed to load maintenance schedules');
    } else {
      setMaintenanceSchedule(data || []);
    }
    setLoading(false);
  };

  const handleScheduleMaintenance = async () => {
    if (!user?.id) {
      toast.error('Not authenticated', { description: 'Please log in to schedule maintenance' });
      return;
    }

    setErrors({});

    try {
      const validatedData = maintenanceSchema.parse({
        vehicle_name: newMaintenance.vehicle_name,
        maintenance_type: newMaintenance.maintenance_type,
        scheduled_date: newMaintenance.scheduled_date,
        notes: newMaintenance.notes || undefined,
      });

      // Store maintenance record
      const insertData: any = {
        user_id: user.id,
        maintenance_type: validatedData.maintenance_type,
        scheduled_date: validatedData.scheduled_date,
        status: 'scheduled',
        notes: validatedData.notes || null,
      };

      const { error } = await supabase
        .from('maintenance_schedules')
        .insert(insertData);

      if (error) {
        toast.error('Failed to schedule maintenance', { description: error.message });
        return;
      }

      toast.success('Maintenance scheduled', {
        description: `${validatedData.maintenance_type} scheduled for ${validatedData.vehicle_name} on ${validatedData.scheduled_date}`,
      });

      setNewMaintenance({
        vehicle_name: '',
        maintenance_type: '',
        scheduled_date: '',
        notes: '',
      });
      setIsScheduleOpen(false);
      fetchMaintenanceSchedules();
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) {
            fieldErrors[err.path[0].toString()] = err.message;
          }
        });
        setErrors(fieldErrors);
        toast.error('Validation failed', { description: 'Please check all fields' });
      }
    }
  };

  const handleViewRecord = (record: MaintenanceRecord) => {
    setSelectedRecord(record);
    setIsViewOpen(true);
  };

  // Filter upcoming and overdue maintenance
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const upcomingMaintenance = maintenanceSchedule.filter(item => {
    const scheduledDate = new Date(item.scheduled_date);
    scheduledDate.setHours(0, 0, 0, 0);
    return scheduledDate >= today && item.status === 'scheduled';
  }).slice(0, 2);

  const overdueMaintenance = maintenanceSchedule.filter(item => {
    const scheduledDate = new Date(item.scheduled_date);
    scheduledDate.setHours(0, 0, 0, 0);
    return scheduledDate < today && item.status === 'scheduled';
  }).slice(0, 2);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-3xl font-bold">Maintenance Schedule</h2>
          <p className="text-muted-foreground">Track and manage vehicle maintenance</p>
        </div>
        <Button onClick={() => setIsScheduleOpen(true)}>
          <Calendar className="h-4 w-4 mr-2" />
          Schedule Maintenance
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Scheduled</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">Next 30 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Overdue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">3</div>
            <p className="text-xs text-muted-foreground">Needs attention</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">Currently servicing</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Completed (Month)</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Maintenance</CardTitle>
            <CardDescription>Scheduled service appointments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                <div className="text-center py-4 text-muted-foreground">Loading...</div>
              ) : upcomingMaintenance.length === 0 && overdueMaintenance.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>No upcoming maintenance scheduled</p>
                </div>
              ) : (
                <>
                  {upcomingMaintenance.map((item) => (
                    <div key={item.id} className="border rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{item.vehicles?.name || 'Vehicle'}</span>
                        <Badge variant="secondary">Scheduled</Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Wrench className="h-4 w-4" />
                        <span>{item.maintenance_type}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>{new Date(item.scheduled_date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric', 
                          year: 'numeric' 
                        })}</span>
                      </div>
                      <Button variant="outline" size="sm" className="w-full" onClick={() => handleViewRecord(item)}>
                        View Details
                      </Button>
                    </div>
                  ))}
                  {overdueMaintenance.map((item) => (
                    <div key={item.id} className="border border-orange-500 rounded-lg p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-semibold">{item.vehicles?.name || 'Vehicle'}</span>
                        <Badge variant="destructive">Overdue</Badge>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <AlertTriangle className="h-4 w-4 text-orange-500" />
                        <span>{item.maintenance_type}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4" />
                        <span>Was due: {new Date(item.scheduled_date).toLocaleDateString('en-US', { 
                          month: 'short', 
                          day: 'numeric', 
                          year: 'numeric' 
                        })}</span>
                      </div>
                      <Button size="sm" className="w-full" onClick={() => handleViewRecord(item)}>
                        Schedule Now
                      </Button>
                    </div>
                  ))}
                </>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Maintenance History</CardTitle>
            <CardDescription>Recent completed services</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="border rounded-lg p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Truck #32</span>
                  <Badge variant="default">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Completed
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Wrench className="h-4 w-4" />
                  <span>General Service - 50K Miles</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Completed: Jan 25, 2024</span>
                </div>
                <div className="text-sm font-semibold">Cost: $850</div>
              </div>
              <div className="border rounded-lg p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold">Truck #24</span>
                  <Badge variant="default">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Completed
                  </Badge>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Wrench className="h-4 w-4" />
                  <span>Brake Pad Replacement</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="h-4 w-4" />
                  <span>Completed: Jan 22, 2024</span>
                </div>
                <div className="text-sm font-semibold">Cost: $620</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Maintenance Records</CardTitle>
          <CardDescription>Complete maintenance history</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8">Loading maintenance schedules...</div>
          ) : maintenanceSchedule.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No maintenance schedules yet. Create your first schedule to get started.
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Vehicle</TableHead>
                  <TableHead>Service Type</TableHead>
                  <TableHead>Scheduled Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {maintenanceSchedule.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">
                      {item.vehicles?.name || 'N/A'}
                    </TableCell>
                    <TableCell>{item.maintenance_type}</TableCell>
                    <TableCell>{new Date(item.scheduled_date).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Badge variant={
                        item.status === 'completed' ? 'default' : 
                        item.status === 'overdue' ? 'destructive' : 
                        'secondary'
                      }>
                        {item.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-xs truncate">
                      {item.notes || '-'}
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleViewRecord(item)}>View</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* Schedule Maintenance Dialog */}
      <Dialog open={isScheduleOpen} onOpenChange={setIsScheduleOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Schedule Maintenance</DialogTitle>
            <DialogDescription>
              Schedule a maintenance service for your vehicle
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="vehicle_name">Vehicle Name</Label>
              <Input
                id="vehicle_name"
                placeholder="Enter vehicle name or number"
                value={newMaintenance.vehicle_name}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, vehicle_name: e.target.value })}
              />
              {errors.vehicle_name && <p className="text-sm text-destructive">{errors.vehicle_name}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="maintenance_type">Service Type</Label>
              <Select
                value={newMaintenance.maintenance_type}
                onValueChange={(value) => setNewMaintenance({ ...newMaintenance, maintenance_type: value })}
              >
                <SelectTrigger id="maintenance_type">
                  <SelectValue placeholder="Select service type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Oil Change">Oil Change</SelectItem>
                  <SelectItem value="Tire Rotation">Tire Rotation</SelectItem>
                  <SelectItem value="Brake Inspection">Brake Inspection</SelectItem>
                  <SelectItem value="General Service">General Service</SelectItem>
                  <SelectItem value="Engine Service">Engine Service</SelectItem>
                  <SelectItem value="Transmission Service">Transmission Service</SelectItem>
                  <SelectItem value="Electrical Repair">Electrical Repair</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
              {errors.maintenance_type && <p className="text-sm text-destructive">{errors.maintenance_type}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="scheduled_date">Scheduled Date</Label>
              <Input
                id="scheduled_date"
                type="date"
                value={newMaintenance.scheduled_date}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, scheduled_date: e.target.value })}
              />
              {errors.scheduled_date && <p className="text-sm text-destructive">{errors.scheduled_date}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes (Optional)</Label>
              <Textarea
                id="notes"
                placeholder="Add any additional notes or details"
                value={newMaintenance.notes}
                onChange={(e) => setNewMaintenance({ ...newMaintenance, notes: e.target.value })}
                rows={3}
              />
              {errors.notes && <p className="text-sm text-destructive">{errors.notes}</p>}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsScheduleOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleScheduleMaintenance}>
              Schedule Maintenance
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Maintenance Record Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Maintenance Record Details</DialogTitle>
            <DialogDescription>
              Complete information for this maintenance schedule
            </DialogDescription>
          </DialogHeader>
          {selectedRecord && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Vehicle</p>
                  <p className="text-base font-semibold">{selectedRecord.vehicles?.name || 'N/A'}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Status</p>
                  <Badge variant={
                    selectedRecord.status === 'completed' ? 'default' : 
                    selectedRecord.status === 'overdue' ? 'destructive' : 
                    'secondary'
                  }>
                    {selectedRecord.status}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Service Type</p>
                  <p className="text-base">{selectedRecord.maintenance_type}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Scheduled Date</p>
                  <p className="text-base">{new Date(selectedRecord.scheduled_date).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Created On</p>
                  <p className="text-base">{new Date(selectedRecord.created_at).toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Record ID</p>
                  <p className="text-base font-mono text-xs">{selectedRecord.id}</p>
                </div>
              </div>

              <div className="border-t pt-4">
                <p className="text-sm font-medium text-muted-foreground mb-2">Notes</p>
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm">{selectedRecord.notes || 'No notes provided for this maintenance record.'}</p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setIsViewOpen(false)}
                  className="flex-1"
                >
                  Close
                </Button>
                <Button
                  onClick={() => {
                    setIsViewOpen(false);
                    toast.info('Edit functionality coming soon');
                  }}
                  className="flex-1"
                >
                  <Wrench className="h-4 w-4 mr-2" />
                  Edit Record
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};