import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, Play, Square } from 'lucide-react';
import { useTimesheet } from '@/hooks/useTimesheet';
import { Skeleton } from '@/components/ui/skeleton';

interface UniversalTimesheetCardProps {
  jobId?: string;
  jobStage?: string;
  onClockIn?: () => void;
  onClockOut?: () => void;
}

export const UniversalTimesheetCard = ({ 
  jobId, 
  jobStage,
  onClockIn,
  onClockOut 
}: UniversalTimesheetCardProps) => {
  const { activeSession, loading, elapsedTime, clockIn, clockOut, formatDuration } = useTimesheet();

  const handleClockIn = async () => {
    await clockIn({ jobId, jobStage });
    onClockIn?.();
  };

  const handleClockOut = async () => {
    await clockOut();
    onClockOut?.();
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-4 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Time Tracking
        </CardTitle>
        <CardDescription>
          {activeSession ? 'Session in progress' : 'Start tracking your time'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activeSession ? (
          <>
            <div className="rounded-lg bg-muted p-4">
              <div className="text-sm text-muted-foreground">Elapsed Time</div>
              <div className="text-3xl font-bold font-mono">
                {formatDuration(elapsedTime)}
              </div>
              {activeSession.job_id && (
                <div className="mt-2 text-sm text-muted-foreground">
                  Stage: <span className="font-medium">{activeSession.job_stage}</span>
                </div>
              )}
            </div>
            <Button 
              onClick={handleClockOut} 
              className="w-full"
              variant="destructive"
            >
              <Square className="mr-2 h-4 w-4" />
              Clock Out
            </Button>
          </>
        ) : (
          <Button 
            onClick={handleClockIn} 
            className="w-full"
          >
            <Play className="mr-2 h-4 w-4" />
            Clock In
          </Button>
        )}
      </CardContent>
    </Card>
  );
};