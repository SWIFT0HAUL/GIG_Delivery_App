import { useParams } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { ArrowLeft, CheckCircle, Clock, PlayCircle, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { fetchTaskById, fetchTaskLogs, updateTaskStatus, addTaskNote, TaskStatus } from '@/lib/api/task-center/taskCenterApi';
import { useToast } from '@/hooks/use-toast';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const statusColors = {
  pending: 'bg-yellow-500/10 text-yellow-500 border-yellow-500/20',
  in_progress: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  completed: 'bg-green-500/10 text-green-500 border-green-500/20',
  overdue: 'bg-red-500/10 text-red-500 border-red-500/20',
};

const priorityColors = {
  low: 'bg-gray-500/10 text-gray-500 border-gray-500/20',
  medium: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
  high: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
  critical: 'bg-red-500/10 text-red-500 border-red-500/20',
};

export function TaskDetailPage() {
  const { taskId } = useParams<{ taskId: string }>();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [note, setNote] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<TaskStatus | ''>('');

  const { data: task, isLoading: taskLoading } = useQuery({
    queryKey: ['admin-task', taskId],
    queryFn: () => fetchTaskById(taskId!),
    enabled: !!taskId,
  });

  const { data: logs, isLoading: logsLoading } = useQuery({
    queryKey: ['admin-task-logs', taskId],
    queryFn: () => fetchTaskLogs(taskId!),
    enabled: !!taskId,
  });

  const updateStatusMutation = useMutation({
    mutationFn: ({ status, note }: { status: TaskStatus; note?: string }) =>
      updateTaskStatus(taskId!, status, note),
    onSuccess: () => {
      toast({ title: 'Success', description: 'Task status updated' });
      queryClient.invalidateQueries({ queryKey: ['admin-task', taskId] });
      queryClient.invalidateQueries({ queryKey: ['admin-task-logs', taskId] });
      queryClient.invalidateQueries({ queryKey: ['admin-tasks'] });
      queryClient.invalidateQueries({ queryKey: ['task-stats'] });
      setNote('');
      setSelectedStatus('');
    },
  });

  const addNoteMutation = useMutation({
    mutationFn: (note: string) => addTaskNote(taskId!, note),
    onSuccess: () => {
      toast({ title: 'Success', description: 'Note added' });
      queryClient.invalidateQueries({ queryKey: ['admin-task-logs', taskId] });
      setNote('');
    },
  });

  const handleStatusUpdate = (status: TaskStatus) => {
    updateStatusMutation.mutate({ status, note: note || undefined });
  };

  const handleAddNote = () => {
    if (!note.trim()) return;
    addNoteMutation.mutate(note);
  };

  if (taskLoading) {
    return <div className="container mx-auto p-6">Loading...</div>;
  }

  if (!task) {
    return <div className="container mx-auto p-6">Task not found</div>;
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate('/admin/task-center')}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">{task.title}</h1>
            {task.auto_generated && (
              <Badge variant="outline" className="bg-blue-500/10 text-blue-500">
                <Clock className="h-3 w-3 mr-1" />
                Auto-generated
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground mt-1">Task ID: {task.id.slice(0, 8)}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Task Details Card */}
          <Card>
            <CardHeader>
              <CardTitle>Task Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium text-muted-foreground">Description</label>
                <p className="mt-1">{task.description || 'No description provided'}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Category</label>
                  <Badge variant="outline" className="mt-1 capitalize">
                    {task.category}
                  </Badge>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Frequency</label>
                  <Badge variant="outline" className="mt-1 capitalize">
                    {task.frequency}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Status</label>
                  <Badge variant="outline" className={`mt-1 ${statusColors[task.status]}`}>
                    {task.status.replace('_', ' ')}
                  </Badge>
                </div>
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Priority</label>
                  <Badge variant="outline" className={`mt-1 ${priorityColors[task.priority]}`}>
                    {task.priority}
                  </Badge>
                </div>
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">Due Date</label>
                <p className="mt-1">{format(new Date(task.due_date), 'MMMM dd, yyyy HH:mm')}</p>
              </div>

              <div>
                <label className="text-sm font-medium text-muted-foreground">Assigned To</label>
                <p className="mt-1">
                  {task.assigned_user?.full_name || task.assigned_user?.email || 'Unassigned'}
                </p>
              </div>

              {task.completed_at && (
                <div>
                  <label className="text-sm font-medium text-muted-foreground">Completed At</label>
                  <p className="mt-1">{format(new Date(task.completed_at), 'MMMM dd, yyyy HH:mm')}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Activity Log */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Activity Log
              </CardTitle>
              <CardDescription>{logs?.length || 0} entries</CardDescription>
            </CardHeader>
            <CardContent>
              {logsLoading ? (
                <p>Loading activity...</p>
              ) : logs && logs.length > 0 ? (
                <div className="space-y-4">
                  {logs.map((log) => (
                    <div key={log.id} className="flex gap-3 pb-4 border-b last:border-0">
                      <div className="flex-1">
                        {log.old_status && log.new_status && (
                          <p className="text-sm">
                            Status changed from{' '}
                            <Badge variant="outline" className="mx-1">
                              {log.old_status}
                            </Badge>
                            to{' '}
                            <Badge variant="outline" className="mx-1">
                              {log.new_status}
                            </Badge>
                          </p>
                        )}
                        {log.note && <p className="text-sm mt-1">{log.note}</p>}
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(log.created_at), 'MMM dd, yyyy HH:mm')} by{' '}
                          {log.changed_by_user?.full_name || 'System'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No activity yet</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Actions Sidebar */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {task.status !== 'in_progress' && task.status !== 'completed' && (
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={() => handleStatusUpdate('in_progress')}
                >
                  <PlayCircle className="h-4 w-4 mr-2" />
                  Start Task
                </Button>
              )}
              {task.status !== 'completed' && (
                <Button
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
                  onClick={() => handleStatusUpdate('completed')}
                >
                  <CheckCircle className="h-4 w-4 mr-2" />
                  Mark Complete
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Update Status */}
          <Card>
            <CardHeader>
              <CardTitle>Update Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Select
                value={selectedStatus}
                onValueChange={(value) => setSelectedStatus(value as TaskStatus)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="overdue">Overdue</SelectItem>
                </SelectContent>
              </Select>
              <Textarea
                placeholder="Add a note (optional)"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
              />
              <Button
                className="w-full"
                disabled={!selectedStatus || updateStatusMutation.isPending}
                onClick={() => selectedStatus && handleStatusUpdate(selectedStatus)}
              >
                Update Status
              </Button>
            </CardContent>
          </Card>

          {/* Add Note */}
          <Card>
            <CardHeader>
              <CardTitle>Add Note</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Textarea
                placeholder="Add a note to this task"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={4}
              />
              <Button
                className="w-full"
                variant="outline"
                disabled={!note.trim() || addNoteMutation.isPending}
                onClick={handleAddNote}
              >
                Add Note
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
