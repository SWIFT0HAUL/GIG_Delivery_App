import { useQuery } from '@tanstack/react-query';
import { CheckCircle2, Clock, AlertCircle, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { fetchTaskStats } from '@/lib/api/task-center/taskCenterApi';
import { useAuth } from '@/contexts/AuthContext';

export function TaskCenterDashboard() {
  const { user } = useAuth();

  const { data: stats, isLoading } = useQuery({
    queryKey: ['task-stats', user?.id],
    queryFn: () => fetchTaskStats(user?.id),
  });

  const statCards = [
    {
      title: 'Tasks Due Today',
      value: stats?.due_today || 0,
      icon: Clock,
      gradient: 'from-blue-500 to-cyan-500',
    },
    {
      title: 'Overdue Tasks',
      value: stats?.overdue || 0,
      icon: AlertCircle,
      gradient: 'from-red-500 to-pink-500',
    },
    {
      title: 'Completed Today',
      value: stats?.completed || 0,
      icon: CheckCircle2,
      gradient: 'from-green-500 to-emerald-500',
    },
    {
      title: 'High Priority',
      value: stats?.high_priority || 0,
      icon: TrendingUp,
      gradient: 'from-orange-500 to-amber-500',
    },
  ];

  if (isLoading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="space-y-0 pb-2">
              <div className="h-4 bg-muted rounded w-24"></div>
            </CardHeader>
            <CardContent>
              <div className="h-8 bg-muted rounded w-16"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="relative overflow-hidden group hover:shadow-lg transition-shadow">
              <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-5 group-hover:opacity-10 transition-opacity`}></div>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
                <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.gradient}`}>
                  <Icon className="h-4 w-4 text-white" />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground mt-1">
                  of {stats?.total || 0} total tasks
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Task Overview</CardTitle>
          <CardDescription>Current task distribution by status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Pending</span>
              <span className="text-sm font-medium">{stats?.pending || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">In Progress</span>
              <span className="text-sm font-medium">{stats?.in_progress || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Completed</span>
              <span className="text-sm font-medium">{stats?.completed || 0}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Overdue</span>
              <span className="text-sm font-medium text-destructive">{stats?.overdue || 0}</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
