import { useEffect } from 'react';
import { useSessionAwareness } from '@/hooks/useSessionAwareness';
import { crossTabSync } from '@/lib/crossTabSync';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export function NotificationProvider({ children }: { children: React.ReactNode }) {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  
  // Enable session awareness
  useSessionAwareness();

  // Setup cross-tab sync
  useEffect(() => {
    // Listen for logout events from other tabs
    const cleanupLogout = crossTabSync.on('LOGOUT', async () => {
      console.log('Logout event received from another tab');
      await signOut();
      navigate('/auth');
    });

    // Listen for refresh events from other tabs
    const cleanupRefresh = crossTabSync.on('FORCE_RELOAD', () => {
      console.log('Refresh event received from another tab');
      window.location.reload();
    });

    // Listen for user deletion from other tabs
    const cleanupUserDeleted = crossTabSync.on('USER_DELETED', async () => {
      console.log('User deletion from another tab');
      await signOut();
      navigate('/auth');
    });

    // Listen for role changes
    const cleanupRoleChange = crossTabSync.on('ROLE_CHANGE', () => {
      console.log('Role change from another tab');
      window.location.reload();
    });

    return () => {
      cleanupLogout();
      cleanupRefresh();
      cleanupUserDeleted();
      cleanupRoleChange();
    };
  }, [signOut, navigate]);

  return <>{children}</>;
}
