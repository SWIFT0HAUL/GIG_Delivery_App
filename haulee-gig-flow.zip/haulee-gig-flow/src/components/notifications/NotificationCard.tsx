import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { 
  Bell, 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  Info,
  MoreVertical,
  Eye,
  Archive,
  Clock,
  Trash2,
  Pin
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { PlatformNotification } from '@/hooks/useNotifications';

interface NotificationCardProps {
  notification: PlatformNotification;
  onMarkRead: (id: string) => void;
  onArchive?: (id: string) => void;
  onSnooze?: (id: string, until: Date) => void;
  onDelete?: (id: string) => void;
}

export function NotificationCard({
  notification,
  onMarkRead,
  onArchive,
  onSnooze,
  onDelete
}: NotificationCardProps) {
  const navigate = useNavigate();
  const [isPinned, setIsPinned] = useState(false);

  const getIcon = () => {
    switch (notification.type) {
      case 'success': return <CheckCircle className="h-4 w-4 text-success" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-warning" />;
      case 'error': return <XCircle className="h-4 w-4 text-destructive" />;
      case 'system': return <Bell className="h-4 w-4 text-primary" />;
      default: return <Info className="h-4 w-4 text-info" />;
    }
  };

  const getPriorityColor = () => {
    return 'border-l-4 border-primary';
  };

  const handleAction = () => {
    if (notification.link) {
      navigate(notification.link);
    }
    if (!notification.is_read) {
      onMarkRead(notification.id);
    }
  };

  const handleSnooze = () => {
    if (onSnooze) {
      const snoozeUntil = new Date();
      snoozeUntil.setHours(snoozeUntil.getHours() + 1);
      onSnooze(notification.id, snoozeUntil);
    }
  };

  return (
    <Card className={`p-3 ${getPriorityColor()} ${!notification.is_read ? 'bg-accent/50' : ''} ${isPinned ? 'ring-2 ring-primary' : ''}`}>
      <div className="flex items-start gap-2">
        <div className="flex-shrink-0 mt-0.5">
          {getIcon()}
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-0.5">
            <h4 className="font-semibold text-xs">{notification.title}</h4>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-5 w-5">
                  <MoreVertical className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="text-xs">
                {!notification.is_read && (
                  <DropdownMenuItem onClick={() => onMarkRead(notification.id)}>
                    <Eye className="h-3 w-3 mr-1.5" />
                    Mark as Read
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={() => setIsPinned(!isPinned)}>
                  <Pin className="h-3 w-3 mr-1.5" />
                  {isPinned ? 'Unpin' : 'Pin'}
                </DropdownMenuItem>
                {onSnooze && (
                  <DropdownMenuItem onClick={handleSnooze}>
                    <Clock className="h-3 w-3 mr-1.5" />
                    Snooze (1 hour)
                  </DropdownMenuItem>
                )}
                {onArchive && (
                  <DropdownMenuItem onClick={() => onArchive(notification.id)}>
                    <Archive className="h-3 w-3 mr-1.5" />
                    Archive
                  </DropdownMenuItem>
                )}
                {onDelete && (
                  <DropdownMenuItem 
                    onClick={() => onDelete(notification.id)}
                    className="text-destructive"
                  >
                    <Trash2 className="h-3 w-3 mr-1.5" />
                    Delete
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          <p className="text-xs text-muted-foreground mb-1.5">{notification.message}</p>
          
          <div className="flex items-center gap-1.5 flex-wrap">
            <Badge variant="outline" className="text-[10px] px-1.5 py-0">
              {notification.type}
            </Badge>
            <span className="text-[10px] text-muted-foreground ml-auto">
              {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
            </span>
          </div>
          
          {notification.link && (
            <Button 
              variant="link" 
              size="sm" 
              className="mt-1.5 p-0 h-auto text-xs"
              onClick={handleAction}
            >
              View Details →
            </Button>
          )}
        </div>
      </div>
    </Card>
  );
}