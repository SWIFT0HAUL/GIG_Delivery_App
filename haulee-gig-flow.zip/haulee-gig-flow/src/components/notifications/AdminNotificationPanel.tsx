import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Send, Users, Megaphone } from 'lucide-react';

export function AdminNotificationPanel() {
  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [targetRole, setTargetRole] = useState<string>('all');
  const [type, setType] = useState<'info' | 'success' | 'warning' | 'error' | 'system'>('info');
  const [sending, setSending] = useState(false);

  const handleBroadcast = async () => {
    if (!title || !message) {
      toast({
        title: 'Error',
        description: 'Please fill in all required fields',
        variant: 'destructive'
      });
      return;
    }

    setSending(true);
    try {
      // Get users based on target role
      const query = supabase
        .from('profiles')
        .select('id, role_key');

      if (targetRole !== 'all') {
        query.eq('role_key', targetRole as any);
      }

      const { data: users, error: usersError } = await query;
      if (usersError) throw usersError;

      // Create notifications for each user
      const notifications = users?.map(user => ({
        user_id: user.id,
        title,
        message,
        type: type === 'info' || type === 'success' || type === 'warning' || type === 'error' ? 'system' : type,
        metadata: { original_type: type, priority, category: 'broadcast' }
      })) as any;

      const { error: notifError } = await supabase
        .from('notifications')
        .insert(notifications);

      if (notifError) throw notifError;

      toast({
        title: 'Success',
        description: `Broadcast sent to ${users?.length} users`
      });

      // Reset form
      setTitle('');
      setMessage('');
      setPriority('medium');
      setType('info');
      setTargetRole('all');
    } catch (error) {
      console.error('Error broadcasting notification:', error);
      toast({
        title: 'Error',
        description: 'Failed to send broadcast',
        variant: 'destructive'
      });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Megaphone className="h-5 w-5" />
            Broadcast Notification
          </CardTitle>
          <CardDescription>Send notifications to multiple users at once</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Notification title"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Message *</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Notification message"
              rows={4}
            />
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label>Type</Label>
              <Select value={type} onValueChange={(value: any) => setType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="info">Info</SelectItem>
                  <SelectItem value="success">Success</SelectItem>
                  <SelectItem value="warning">Warning</SelectItem>
                  <SelectItem value="error">Error</SelectItem>
                  <SelectItem value="system">System</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Priority</Label>
              <Select value={priority} onValueChange={(value: any) => setPriority(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Target Role</Label>
              <Select value={targetRole} onValueChange={setTargetRole}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Users</SelectItem>
                  <SelectItem value="driver">Drivers</SelectItem>
                  <SelectItem value="shipper">Shippers</SelectItem>
                  <SelectItem value="vendor">Vendors</SelectItem>
                  <SelectItem value="broker">Brokers</SelectItem>
                  <SelectItem value="carrier">Carriers</SelectItem>
                  <SelectItem value="admin">Admins</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button 
            onClick={handleBroadcast} 
            disabled={sending}
            className="w-full"
          >
            <Send className="h-4 w-4 mr-2" />
            {sending ? 'Sending...' : 'Send Broadcast'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Notification Templates
          </CardTitle>
          <CardDescription>Pre-configured notification templates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <Button
              variant="outline"
              onClick={() => {
                setTitle('System Maintenance');
                setMessage('The platform will undergo scheduled maintenance tonight at 2 AM EST.');
                setType('warning');
                setPriority('high');
              }}
            >
              Maintenance Alert
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setTitle('New Feature Available');
                setMessage('Check out our latest features to improve your experience!');
                setType('info');
                setPriority('medium');
              }}
            >
              Feature Announcement
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setTitle('Payment Processed');
                setMessage('Your recent payment has been successfully processed.');
                setType('success');
                setPriority('medium');
              }}
            >
              Payment Confirmation
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setTitle('Action Required');
                setMessage('Please complete your profile to continue using the platform.');
                setType('warning');
                setPriority('high');
              }}
            >
              Action Required
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}