import { useState, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Phone, MessageSquare, Send, User, Headphones } from 'lucide-react';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface ChatMessage {
  id: string;
  user_id: string;
  message: string;
  is_support_agent: boolean;
  created_at: string;
  sender_name?: string;
}

export default function DriverSupportChat() {
  const { user } = useAuth();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isOnline, setIsOnline] = useState(false);
  const [isCalling, setIsCalling] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Check if support is online (mock for now)
    setIsOnline(true);
    
    // Fetch existing messages
    fetchMessages();
    
    // Setup realtime subscription
    const channel = supabase
      .channel('driver-support-chat')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'driver_support_messages',
        },
        (payload: any) => {
          setMessages(prev => [...prev, payload.new as ChatMessage]);
          scrollToBottom();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const fetchMessages = async () => {
    try {
      const { data, error } = await (supabase as any)
        .from('driver_support_messages')
        .select('*')
        .eq('user_id', user!.id)
        .order('created_at', { ascending: true })
        .limit(50);

      if (error) {
        console.log('No previous messages or table not ready');
        return;
      }
      setMessages(data || []);
      setTimeout(scrollToBottom, 100);
    } catch (error) {
      console.log('Chat history not available yet');
    }
  };

  const scrollToBottom = () => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newMessage.trim()) return;

    try {
      const { error } = await (supabase as any)
        .from('driver_support_messages')
        .insert({
          user_id: user!.id,
          message: newMessage,
          is_support_agent: false,
        });

      if (error) throw error;

      setNewMessage('');
      toast.success('Message sent');
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message. Creating support ticket instead.');
    }
  };

  const handleCall = () => {
    setIsCalling(true);
    toast.success('Connecting to driver support...', {
      description: 'Support: 1-800-DRIVER-HELP',
    });
    
    // In production, integrate with Twilio or similar service
    setTimeout(() => {
      setIsCalling(false);
    }, 3000);
  };

  return (
    <div className="grid gap-4 md:grid-cols-2">
      {/* Live Chat Section */}
      <Card className="flex flex-col">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              <CardTitle>Live Chat</CardTitle>
            </div>
            <Badge variant={isOnline ? "default" : "secondary"} className="gap-1">
              <span className={cn(
                "h-2 w-2 rounded-full",
                isOnline ? "bg-green-500 animate-pulse" : "bg-gray-400"
              )} />
              {isOnline ? 'Support Online' : 'Offline'}
            </Badge>
          </div>
          <CardDescription>
            Chat with our driver support team in real-time
          </CardDescription>
        </CardHeader>
        
        <CardContent className="flex-1 flex flex-col gap-4">
          <ScrollArea ref={scrollRef} className="flex-1 h-[400px] pr-4">
            <div className="space-y-4">
              {messages.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <Headphones className="h-12 w-12 mx-auto mb-2 opacity-50" />
                  <p>Start a conversation with driver support</p>
                  <p className="text-sm mt-1">We're here to help with routes, payments, and more</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={cn(
                      "flex gap-2",
                      msg.is_support_agent ? "justify-start" : "justify-end"
                    )}
                  >
                    <div
                      className={cn(
                        "max-w-[80%] rounded-lg p-3",
                        msg.is_support_agent
                          ? "bg-accent text-accent-foreground"
                          : "bg-primary text-primary-foreground"
                      )}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        {msg.is_support_agent && <User className="h-3 w-3" />}
                        <span className="text-xs font-medium">
                          {msg.is_support_agent ? 'Support Agent' : 'You'}
                        </span>
                        <span className="text-xs opacity-70">
                          {formatDistanceToNow(new Date(msg.created_at), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm">{msg.message}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </ScrollArea>

          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              placeholder="Type your message..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              disabled={!isOnline}
            />
            <Button type="submit" size="icon" disabled={!isOnline || !newMessage.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Call Support Section */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <Phone className="h-5 w-5" />
            <CardTitle>Call Driver Support</CardTitle>
          </div>
          <CardDescription>
            Speak directly with a support specialist
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="bg-accent/50 p-6 rounded-lg text-center space-y-4">
            <Phone className={cn(
              "h-16 w-16 mx-auto",
              isCalling && "animate-bounce text-primary"
            )} />
            
            <div>
              <h3 className="font-semibold text-lg mb-1">24/7 Driver Hotline</h3>
              <p className="text-2xl font-bold text-primary">1-800-DRIVER-HELP</p>
              <p className="text-sm text-muted-foreground mt-2">
                (1-800-374-8374)
              </p>
            </div>

            <Button 
              onClick={handleCall} 
              size="lg" 
              className="w-full"
              disabled={isCalling}
            >
              <Phone className="h-4 w-4 mr-2" />
              {isCalling ? 'Connecting...' : 'Call Now'}
            </Button>
          </div>

          <div className="space-y-3">
            <h4 className="font-medium text-sm">What we can help with:</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Route planning and navigation issues</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Payment and earnings questions</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Job assignment and scheduling</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Vehicle and equipment support</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-primary mt-0.5">•</span>
                <span>Emergency road assistance</span>
              </li>
            </ul>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-4">
            <p className="text-sm font-medium text-yellow-700 dark:text-yellow-500 mb-1">
              ⚠️ For Emergencies
            </p>
            <p className="text-xs text-muted-foreground">
              If you're experiencing an emergency situation, please call 911 first, 
              then contact driver support for incident reporting.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
