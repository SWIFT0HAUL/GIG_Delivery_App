import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

interface StepProgressProps {
  currentStep: number;
  totalSteps: number;
  stepTitles: string[];
}

export function StepProgress({ currentStep, totalSteps, stepTitles }: StepProgressProps) {
  return (
    <div className="w-full mb-4 sm:mb-6 lg:mb-8">
      <div className="flex items-center justify-between mb-3 sm:mb-4 overflow-x-auto pb-2">
        {Array.from({ length: totalSteps }, (_, i) => {
          const stepNumber = i + 1;
          const isCompleted = stepNumber < currentStep;
          const isCurrent = stepNumber === currentStep;
          
          return (
            <div key={stepNumber} className="flex items-center min-w-0 flex-shrink-0">
              <div
                className={cn(
                  "flex items-center justify-center w-7 h-7 sm:w-9 sm:h-9 lg:w-10 lg:h-10 rounded-full border-2 transition-colors",
                  {
                    "bg-primary border-primary text-primary-foreground": isCompleted,
                    "bg-primary/10 border-primary text-primary": isCurrent,
                    "bg-muted border-muted-foreground/20 text-muted-foreground": !isCompleted && !isCurrent,
                  }
                )}
              >
                {isCompleted ? (
                  <Check className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5" />
                ) : (
                  <span className="text-[10px] sm:text-xs lg:text-sm font-medium">{stepNumber}</span>
                )}
              </div>
              
              {stepNumber < totalSteps && (
                <div
                  className={cn(
                    "h-0.5 w-6 sm:w-10 lg:w-12 mx-1 sm:mx-2 transition-colors flex-shrink-0",
                    isCompleted ? "bg-primary" : "bg-muted-foreground/20"
                  )}
                />
              )}
            </div>
          );
        })}
      </div>
      
      <div className="text-center px-2">
        <h2 className="text-base sm:text-lg lg:text-xl font-semibold mb-1">
          Step {currentStep} of {totalSteps}
        </h2>
        <p className="text-xs sm:text-sm lg:text-base text-muted-foreground line-clamp-2">
          {stepTitles[currentStep - 1] || `Step ${currentStep}`}
        </p>
      </div>
    </div>
  );
}