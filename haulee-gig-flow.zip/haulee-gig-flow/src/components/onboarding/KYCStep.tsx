import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { FileUpload } from '@/components/onboarding/FileUpload';
import { Shield, Info } from 'lucide-react';
import { useOnboarding } from './OnboardingProvider';

export function KYCStep() {
  const { formData, uploadedFiles, updateFormData, setCurrentStep, role } = useOnboarding();
  
  const [governmentId, setGovernmentId] = useState<string | null>(
    formData.government_id || uploadedFiles.government_id || null
  );
  const [proofOfAddress, setProofOfAddress] = useState<string | null>(
    formData.proof_of_address || uploadedFiles.proof_of_address || null
  );
  const [selfie, setSelfie] = useState<string | null>(
    formData.selfie || uploadedFiles.selfie || null
  );

  const handleGovernmentIdChange = (value: string | null) => {
    setGovernmentId(value);
    updateFormData({ government_id: value });
  };

  const handleProofOfAddressChange = (value: string | null) => {
    setProofOfAddress(value);
    updateFormData({ proof_of_address: value });
  };

  const handleSelfieChange = (value: string | null) => {
    setSelfie(value);
    updateFormData({ selfie: value });
  };

  // Auto-advance to step 5 when all required KYC documents are uploaded (admin only)
  useEffect(() => {
    if (role === 'admin' && governmentId && proofOfAddress) {
      // Small delay to ensure state is saved
      const timer = setTimeout(() => {
        setCurrentStep(5);
      }, 500);
      return () => clearTimeout(timer);
    }
  }, [governmentId, proofOfAddress, role, setCurrentStep]);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <Shield className="h-6 w-6 text-primary" />
            <div>
              <CardTitle>Identity Verification (KYC)</CardTitle>
              <CardDescription>
                Verify your identity to unlock all platform features
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              <strong>Why we need this:</strong> Identity verification helps us maintain a safe and trusted platform for all users. 
              All documents are securely encrypted and only accessible to authorized admins.
            </AlertDescription>
          </Alert>

          <Alert>
            <AlertDescription>
              <strong>Required Documents:</strong>
              <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                <li>Government-issued ID (passport, driver's license, or national ID card)</li>
                <li>Proof of address (utility bill, bank statement - not older than 3 months)</li>
                <li>Optional: A selfie holding your ID for enhanced verification</li>
              </ul>
            </AlertDescription>
          </Alert>

          <div className="space-y-4">
            <FileUpload
              label="Government-Issued ID"
              fieldName="government_id"
              value={governmentId}
              onChange={handleGovernmentIdChange}
              required
            />

            <FileUpload
              label="Proof of Address"
              fieldName="proof_of_address"
              value={proofOfAddress}
              onChange={handleProofOfAddressChange}
              required
            />

            <FileUpload
              label="Selfie with ID (Optional)"
              fieldName="selfie"
              value={selfie}
              onChange={handleSelfieChange}
              options={['camera']}
            />
          </div>

          <Alert className="bg-muted">
            <AlertDescription className="text-sm">
              <strong>Data Security:</strong> Your documents are encrypted at rest and in transit. 
              Only authorized administrators can access them for verification purposes. 
              We comply with all relevant data protection regulations.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    </div>
  );
}
