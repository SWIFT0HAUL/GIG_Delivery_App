import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Image, Edit2 } from 'lucide-react';
import { useOnboarding } from './OnboardingProvider';

interface ReviewStepProps {
  onEditStep: (step: number) => void;
  stepTitles: string[];
  onSubmit: () => void;
  onboardingSchema: any;
}

export function ReviewStep({ onEditStep, stepTitles, onSubmit, onboardingSchema }: ReviewStepProps) {
  const { formData, isLoading, role } = useOnboarding();

  const renderValue = (value: any, fieldKey?: string, isDocument?: boolean) => {
    if (!value) return <span className="text-muted-foreground">Not provided</span>;
    
    // Special handling for Documents
    if (isDocument) {
      const isImage = /\.(jpg|jpeg|png|gif|webp)$/i.test(value);
      const isPdf = /\.pdf$/i.test(value);
      
      return (
        <div className="space-y-3">
          {isImage && (
            <div className="relative w-full h-48 bg-muted rounded-xl overflow-hidden border-2 border-primary/30 shadow-lg hover:shadow-xl transition-shadow">
              <img 
                src={value} 
                alt={fieldKey} 
                className="w-full h-full object-contain bg-background"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-2">
                <span className="text-white text-xs font-medium flex items-center gap-1">
                  <Image className="w-3 h-3" />
                  Image Document
                </span>
              </div>
            </div>
          )}
          {!isImage && (
            <div className="flex items-center gap-3 p-4 bg-gradient-to-br from-primary/10 to-primary/5 rounded-xl border-2 border-primary/30 shadow-md">
              <div className="p-3 bg-primary/20 rounded-lg">
                <FileText className="w-8 h-8 text-primary" />
              </div>
              <div className="flex-1">
                <span className="text-sm font-semibold text-foreground block">
                  {isPdf ? 'PDF Document' : 'Document'} Uploaded
                </span>
                <span className="text-xs text-muted-foreground">
                  Click to view
                </span>
              </div>
            </div>
          )}
        </div>
      );
    }
    
    if (typeof value === 'object' && !Array.isArray(value)) {
      return (
        <div className="space-y-1">
          {Object.entries(value).map(([key, val]) => (
            <div key={key} className="text-sm">
              <span className="font-medium capitalize">{key.replace(/_/g, ' ')}: </span>
              <span>{val as string || 'Not provided'}</span>
            </div>
          ))}
        </div>
      );
    }
    
    if (Array.isArray(value)) {
      return (
        <div className="flex flex-wrap gap-1">
          {value.map((item, index) => (
            <Badge key={index} variant="secondary" className="text-xs">
              {item}
            </Badge>
          ))}
        </div>
      );
    }
    
    return <span>{value}</span>;
  };

  const isDocumentField = (key: string) => {
    return key.includes('document') || 
           key.includes('license') ||
           key.includes('selfie') ||
           key.includes('_front') ||
           key.includes('_back');
  };

  // Organize data into sections
  const sections = [
    {
      title: 'Contact Information',
      icon: '📞',
      fields: ['email', 'phone_number']
    },
    {
      title: 'Personal Information',
      icon: '👤',
      fields: ['first_name', 'middle_name', 'last_name', 'date_of_birth']
    },
    {
      title: 'Address',
      icon: '📍',
      fields: ['address_street', 'address_apt', 'address_city', 'address_state', 'address_postal_code', 'address_country']
    },
    {
      title: 'Identity Verification',
      icon: '🔐',
      fields: ['id_type', 'id_number', 'id_document', 'selfie']
    }
  ];

  // Add role-specific section
  const roleSpecificFields: { [key: string]: string[] } = {
    driver: ['driver_license_number', 'driver_license_front', 'driver_license_back'],
    carrier: ['company_name'],
    shipper: ['business_name'],
    broker: ['broker_license_number'],
    vendor_merchant: ['store_name'],
    merchant: ['store_name'],
    admin: ['admin_id']
  };

  if (role && roleSpecificFields[role]) {
    sections.push({
      title: `${role.replace('_', ' ').charAt(0).toUpperCase() + role.replace('_', ' ').slice(1)} Information`,
      icon: '💼',
      fields: roleSpecificFields[role]
    });
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="text-center mb-4 sm:mb-6 px-2">
        <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold mb-2">Review Your Information</h2>
        <p className="text-sm sm:text-base text-muted-foreground">
          Please review all the information below before submitting. You can edit by going back to the previous step.
        </p>
      </div>

      <div className="space-y-6">
        {sections.map((section) => {
          const sectionFields = section.fields
            .filter(fieldKey => formData[fieldKey])
            .reduce((acc, fieldKey) => {
              acc[fieldKey] = formData[fieldKey];
              return acc;
            }, {} as any);
          
          if (Object.keys(sectionFields).length === 0) return null;
          
          // Separate documents from regular fields
          const documentFields: any = {};
          const regularFields: any = {};
          
          Object.entries(sectionFields).forEach(([key, value]) => {
            if (isDocumentField(key)) {
              documentFields[key] = value;
            } else {
              regularFields[key] = value;
            }
          });
          
          return (
            <Card key={section.title} className="border-2 shadow-md">
              <CardHeader className="bg-muted/30 p-4 sm:p-6">
                <div className="flex items-start sm:items-center justify-between gap-3">
                  <CardTitle className="text-base sm:text-lg lg:text-xl flex items-center gap-2 sm:gap-3 flex-1">
                    <span className="text-xl sm:text-2xl shrink-0">{section.icon}</span>
                    <span className="break-words">{section.title}</span>
                  </CardTitle>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onEditStep(1)}
                    className="gap-2 shrink-0"
                  >
                    <Edit2 className="h-3 w-3 sm:h-4 sm:w-4" />
                    <span className="hidden sm:inline">Edit</span>
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6">
                {/* Regular Fields */}
                {Object.keys(regularFields).length > 0 && (
                  <div className="grid gap-3 sm:gap-4 grid-cols-1 lg:grid-cols-2 mb-4 sm:mb-6">
                    {Object.entries(regularFields).map(([fieldKey, fieldValue]) => (
                      <div 
                        key={fieldKey} 
                        className="group relative flex flex-col space-y-2 p-3 sm:p-4 rounded-lg bg-muted/20 hover:bg-muted/30 transition-colors"
                      >
                        <span className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wide break-words">
                          {fieldKey.replace(/_/g, ' ')}
                        </span>
                        <div className="text-xs sm:text-sm font-medium break-words">
                          {renderValue(fieldValue, fieldKey, false)}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Document Fields */}
                {Object.keys(documentFields).length > 0 && (
                  <>
                    {Object.keys(regularFields).length > 0 && (
                      <div className="border-t pt-4 sm:pt-6 mb-3 sm:mb-4">
                        <h3 className="text-xs sm:text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3 sm:mb-4">
                          📎 Documents
                        </h3>
                      </div>
                    )}
                    <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
                      {Object.entries(documentFields).map(([fieldKey, fieldValue]) => (
                        <div 
                          key={fieldKey} 
                          className="group relative flex flex-col space-y-2"
                        >
                          <span className="text-[10px] sm:text-xs font-semibold text-muted-foreground uppercase tracking-wide break-words mb-2">
                            {fieldKey.replace(/_/g, ' ')}
                          </span>
                          <div className="text-sm font-medium">
                            {renderValue(fieldValue, fieldKey, true)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="flex justify-center pt-4 sm:pt-6 px-2">
        <Button 
          onClick={onSubmit} 
          size="lg" 
          disabled={isLoading}
          className="w-full sm:w-auto min-w-[200px] min-h-[44px]"
        >
          {isLoading ? 'Submitting...' : 'Submit Application'}
        </Button>
      </div>
    </div>
  );
}