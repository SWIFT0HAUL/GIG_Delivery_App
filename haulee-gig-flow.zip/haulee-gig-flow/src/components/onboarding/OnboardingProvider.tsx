import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export type OnboardingRole = 'admin' | 'driver' | 'carrier' | 'broker' | 'shipper' | 'vendor_merchant' | 'merchant';

export interface OnboardingData {
  [key: string]: any;
}

export interface OnboardingContextType {
  currentStep: number;
  totalSteps: number;
  role: OnboardingRole | null;
  formData: OnboardingData;
  isLoading: boolean;
  uploadedFiles: { [key: string]: string };
  setCurrentStep: (step: number) => void;
  updateFormData: (stepData: OnboardingData) => void;
  submitOnboarding: () => Promise<boolean>;
  uploadFile: (file: File, fieldName: string) => Promise<string | null>;
  setRole: (role: OnboardingRole) => void;
  saveStepData: (stepNumber: number, stepTitle: string, stepData: OnboardingData) => Promise<void>;
  loadSavedData: () => Promise<void>;
}

const OnboardingContext = createContext<OnboardingContextType | undefined>(undefined);

export function useOnboarding() {
  const context = useContext(OnboardingContext);
  if (context === undefined) {
    throw new Error('useOnboarding must be used within an OnboardingProvider');
  }
  return context;
}

interface OnboardingProviderProps {
  children: ReactNode;
}

export function OnboardingProvider({ children }: OnboardingProviderProps) {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(1);
  const [totalSteps, setTotalSteps] = useState(3);
  const [role, setRole] = useState<OnboardingRole | null>(null);
  const [formData, setFormData] = useState<OnboardingData>({});
  const [uploadedFiles, setUploadedFiles] = useState<{ [key: string]: string }>({});
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (role) {
      // All roles now have 2 steps: Unified KYC + Review
      setTotalSteps(2);
    }
  }, [role]);

  useEffect(() => {
    if (user && role) {
      loadSavedData();
    }
  }, [user, role]);

  const updateFormData = (stepData: OnboardingData) => {
    setFormData(prev => ({ ...prev, ...stepData }));
  };

  // Update step with progress tracking
  const updateCurrentStep = (step: number) => {
    setCurrentStep(step);
    
    // Update progress in database (non-blocking, in background)
    if (user && role) {
      Promise.resolve(
        supabase.rpc('update_onboarding_progress', {
          p_user_id: user.id,
          p_step_number: step,
          p_mark_complete: false
        })
      ).catch(error => {
        console.error('Error updating step progress:', error);
      });
    }
  };

  // Helper to get step name based on step number
  const getStepName = (stepNum: number): string => {
    const stepNames: Record<number, string> = {
      1: 'welcome',
      2: 'personal_info',
      3: 'business_info', 
      4: 'documents',
      5: 'payment',
      6: 'tasks',
      7: 'review'
    };
    return stepNames[stepNum] || 'unknown';
  };

  const loadSavedData = async () => {
    if (!user || !role) return;

    try {
      const { data, error } = await supabase
        .from('onboarding_data')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) {
        console.error('Error loading saved data:', error);
        return;
      }

      if (data) {
        const combinedData: OnboardingData = {};
        const combinedFiles: { [key: string]: string } = {};
        
        // Parse the JSONB steps object
        const steps = data.steps as Record<string, any> || {};
        
        Object.values(steps).forEach((step: any) => {
          if (step.step_data) {
            Object.assign(combinedData, step.step_data);
          }
          if (step.uploaded_files) {
            Object.assign(combinedFiles, step.uploaded_files);
          }
        });
        
        setFormData(combinedData);
        setUploadedFiles(combinedFiles);
        
        // Set current step based on last_step_number
        if (data.last_step_number) {
          setCurrentStep(data.last_step_number + 1);
        }
      }
    } catch (error) {
      console.error('Error loading saved data:', error);
    }
  };

  const saveStepData = async (stepNumber: number, stepTitle: string, stepData: OnboardingData) => {
    if (!user) return;

    try {
      const { error } = await supabase.rpc('save_onboarding_step', {
        p_step_number: stepNumber,
        p_step_title: stepTitle,
        p_step_data: stepData,
        p_uploaded_files: uploadedFiles
      });

      if (error) {
        console.error('Error saving step data:', error);
        toast({
          title: "Save failed",
          description: "Failed to save progress",
          variant: "destructive",
        });
        return;
      }

      // Also update the onboarding progress tracking (non-blocking)
      Promise.resolve(
        supabase.rpc('update_onboarding_progress', {
          p_user_id: user.id,
          p_step_number: stepNumber,
          p_mark_complete: false
        })
      ).catch(progressError => {
        console.error('Error updating progress tracking:', progressError);
        // Don't fail the main save for this
      });
    } catch (error) {
      console.error('Error saving step data:', error);
    }
  };

  const uploadFile = async (file: File, fieldName: string): Promise<string | null> => {
    if (!user) return null;

    try {
      // Use dedicated onboarding storage bucket with per-user folder (aligns with RLS)
      const bucket_name = 'user-uploads';
      const storage_path = `${user.id}/`;

      
      // Create file path with account number folder
      const filePath = `${storage_path}${fieldName}_${Date.now()}_${file.name}`;
      
      const { data, error } = await supabase.storage
        .from(bucket_name)
        .upload(filePath, file);

      if (error) {
        console.error('Upload error:', error);
        toast({
          title: "Upload failed",
          description: error.message,
          variant: "destructive",
        });
        return null;
      }

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from(bucket_name)
        .getPublicUrl(data.path);

      // Update uploaded files state
      setUploadedFiles(prev => ({
        ...prev,
        [fieldName]: publicUrl
      }));

      return publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: "Failed to upload file",
        variant: "destructive",
      });
      return null;
    }
  };

  const submitOnboarding = async (): Promise<boolean> => {
    if (!user || !role) return false;

    setIsLoading(true);
    try {
      // Extract phone from formData (checking multiple possible field names)
      const phone = formData.phone || 
                    formData.phone_number || 
                    formData.company_phone || 
                    formData.business_phone || 
                    formData.primary_contact_phone || 
                    formData.contact_phone ||
                    null;

      // Mark onboarding as completed and save phone
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ 
          onboarding_complete: true,
          phone
        })
        .eq('id', user.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
        toast({
          title: "Submission failed",
          description: profileError.message,
          variant: "destructive",
        });
        return false;
      }

      // Submit KYC if documents were uploaded
      if (formData.government_id && formData.proof_of_address) {
        console.log('Submitting KYC documents as part of onboarding');
        try {
          const kycData = {
            user_id: user.id,
            government_id_path: formData.government_id,
            proof_of_address_path: formData.proof_of_address,
            selfie_path: formData.selfie || null,
            status: 'pending',
            submitted_at: new Date().toISOString()
          };

          const { error: kycError } = await supabase
            .from('kyc_submissions' as any)
            .insert(kycData);

          if (kycError) {
            console.error('KYC submission error:', kycError);
            // Don't fail the entire onboarding for KYC
            toast({
              title: "KYC Submission Warning",
              description: "Onboarding completed but KYC submission had an issue. You can resubmit KYC documents later.",
              variant: "destructive",
            });
          } else {
            // Update profile KYC status
            await supabase
              .from('profiles' as any)
              .update({ kyc_status: 'pending' } as any)
              .eq('id', user.id);
            
            console.log('KYC documents submitted successfully');
          }
        } catch (kycErr) {
          console.error('KYC error:', kycErr);
          // Continue with onboarding even if KYC fails
        }
      }

      // Create admin approval record
      const { error: approvalError } = await supabase
        .from('admin_approvals')
        .upsert([{
          user_id: user.id,
          approval_type: 'onboarding_completion',
          action_type: 'onboarding_completion',
          status: 'pending'
        }]);

      if (approvalError) {
        console.error('Approval record error:', approvalError);
        // Don't fail the submission for this
      }

      // Mark onboarding as complete in progress tracking
      try {
        await supabase.rpc('update_onboarding_progress', {
          p_user_id: user.id,
          p_step_number: totalSteps,
          p_mark_complete: true
        });
      } catch (progressError) {
        console.error('Error updating completion progress:', progressError);
        // Don't fail submission for this
      }

      // Process KYC data from onboarding and populate tables
      try {
        console.log('Processing KYC data from onboarding...');
        const { data: processResult, error: processError } = await supabase.rpc(
          'process_kyc_from_onboarding',
          { p_user_id: user.id }
        );

        if (processError) {
          console.error('Error processing KYC data:', processError);
          // Don't fail the entire onboarding for this
        } else {
          console.log('KYC data processed successfully:', processResult);
        }
      } catch (kycError) {
        console.error('Failed to process KYC data:', kycError);
        // Continue anyway
      }

      // Populate role-specific profile tables
      try {
        console.log(`Populating ${role} profile from onboarding...`);
        
        if (role === 'carrier') {
          const carrierData: any = {
            user_id: user.id,
            company_name: formData.legal_company_name || formData.company_name,
            dba_name: formData.dba_name,
            carrier_type: formData.carrier_type,
            ein_tax_id: formData.ein_tax_id || formData.ein,
            year_established: formData.year_established ? parseInt(formData.year_established) : null,
            operation_type: formData.operation_type,
            fleet_size: formData.fleet_size ? parseInt(formData.fleet_size) : null,
            driver_count: formData.total_drivers || formData.number_of_drivers ? parseInt(formData.total_drivers || formData.number_of_drivers) : null,
            dot_number: formData.dot_number,
            mc_number: formData.mc_number,
            physical_address: formData.physical_address || formData.business_address,
            mailing_address: formData.mailing_address,
            insurance_company: formData.insurance_company || formData.insurance_provider,
            insurance_policy_number: formData.insurance_policy_number || formData.policy_number,
            insurance_coverage_type: formData.insurance_coverage_type || formData.coverage_type,
            insurance_coverage_limit: formData.insurance_coverage_limit || formData.coverage_amount ? parseFloat(formData.insurance_coverage_limit || formData.coverage_amount) : null,
            insurance_effective_date: formData.insurance_effective_date || formData.coverage_start_date,
            insurance_expiry_date: formData.insurance_expiry_date || formData.coverage_end_date,
            vehicle_types: formData.vehicle_types ? (Array.isArray(formData.vehicle_types) ? formData.vehicle_types : [formData.vehicle_types]) : null,
            vehicle_registration_numbers: formData.vehicle_registration_numbers ? (Array.isArray(formData.vehicle_registration_numbers) ? formData.vehicle_registration_numbers : [formData.vehicle_registration_numbers]) : null,
            primary_contact_name: formData.primary_contact_name || formData.contact_name,
            primary_contact_title: formData.primary_contact_title || formData.contact_title,
            primary_contact_email: formData.primary_contact_email || formData.contact_email || formData.email,
            primary_contact_phone: formData.primary_contact_phone || formData.contact_phone || phone,
            status: 'active'
          };

          await supabase.from('carrier_company_status').upsert(carrierData, { onConflict: 'user_id' });
        }
        
        if (role === 'broker') {
          const brokerData: any = {
            user_id: user.id,
            brokerage_name: formData.brokerage_name || formData.company_name || formData.business_name,
            mc_number: formData.mc_number,
            dot_number: formData.dot_number,
            dba_name: formData.dba_name,
            ein_tax_id: formData.ein_tax_id || formData.ein,
            year_established: formData.year_established ? parseInt(formData.year_established) : null,
            business_type: formData.business_type,
            physical_address: formData.physical_address || formData.business_address,
            mailing_address: formData.mailing_address,
            primary_contact_name: formData.primary_contact_name || formData.contact_name,
            primary_contact_title: formData.primary_contact_title || formData.contact_title,
            primary_contact_email: formData.primary_contact_email || formData.contact_email || formData.email,
            primary_contact_phone: formData.primary_contact_phone || formData.contact_phone || phone,
            bond_amount: formData.bond_amount ? parseFloat(formData.bond_amount) : null,
            bond_company: formData.bond_company,
            bond_policy_number: formData.bond_policy_number,
            bond_expiry_date: formData.bond_expiry_date,
            insurance_company: formData.insurance_company,
            insurance_policy_number: formData.insurance_policy_number,
            insurance_coverage_limit: formData.insurance_coverage_limit ? parseFloat(formData.insurance_coverage_limit) : null,
            insurance_expiry_date: formData.insurance_expiry_date,
            service_areas: formData.service_areas ? (Array.isArray(formData.service_areas) ? formData.service_areas : [formData.service_areas]) : null,
            status: 'active'
          };

          await supabase.from('broker_profiles').upsert(brokerData, { onConflict: 'user_id' });
        }
        
        if (role === 'shipper') {
          const shipperData: any = {
            user_id: user.id,
            company_name: formData.company_name || formData.business_name,
            dba_name: formData.dba_name,
            ein_tax_id: formData.ein_tax_id || formData.ein,
            year_established: formData.year_established ? parseInt(formData.year_established) : null,
            business_type: formData.business_type,
            industry: formData.industry,
            physical_address: formData.physical_address || formData.business_address,
            mailing_address: formData.mailing_address,
            primary_contact_name: formData.primary_contact_name || formData.contact_name,
            primary_contact_title: formData.primary_contact_title || formData.contact_title,
            primary_contact_email: formData.primary_contact_email || formData.contact_email || formData.email,
            primary_contact_phone: formData.primary_contact_phone || formData.contact_phone || phone,
            billing_contact_name: formData.billing_contact_name,
            billing_contact_email: formData.billing_contact_email,
            billing_contact_phone: formData.billing_contact_phone,
            shipping_volume_monthly: formData.shipping_volume_monthly ? parseInt(formData.shipping_volume_monthly) : null,
            preferred_carriers: formData.preferred_carriers ? (Array.isArray(formData.preferred_carriers) ? formData.preferred_carriers : [formData.preferred_carriers]) : null,
            payment_terms: formData.payment_terms,
            credit_limit: formData.credit_limit ? parseFloat(formData.credit_limit) : null,
            status: 'active'
          };

          await supabase.from('shipper_profiles').upsert(shipperData, { onConflict: 'user_id' });
        }
        
        if (role === 'vendor_merchant' || role === 'merchant') {
          const vendorData: any = {
            user_id: user.id,
            business_name: formData.business_name || formData.company_name,
            dba_name: formData.dba_name,
            ein_tax_id: formData.ein_tax_id || formData.ein,
            year_established: formData.year_established ? parseInt(formData.year_established) : null,
            business_type: formData.business_type,
            store_address: formData.store_address || formData.business_address,
            mailing_address: formData.mailing_address,
            primary_contact_name: formData.primary_contact_name || formData.contact_name,
            primary_contact_title: formData.primary_contact_title || formData.contact_title,
            primary_contact_email: formData.primary_contact_email || formData.contact_email || formData.email,
            primary_contact_phone: formData.primary_contact_phone || formData.contact_phone || phone,
            business_hours: formData.business_hours,
            delivery_radius_miles: formData.delivery_radius_miles ? parseInt(formData.delivery_radius_miles) : null,
            product_categories: formData.product_categories ? (Array.isArray(formData.product_categories) ? formData.product_categories : [formData.product_categories]) : null,
            payment_processor: formData.payment_processor,
            bank_name: formData.bank_name,
            account_holder_name: formData.account_holder_name,
            status: 'active'
          };

          await supabase.from('vendor_profiles').upsert(vendorData, { onConflict: 'user_id' });
        }
        
        if (role === 'driver') {
          const driverProfileData: any = {
            user_id: user.id,
            license_number: formData.license_number || formData.drivers_license_number,
            license_state: formData.license_state,
            license_expiry_date: formData.license_expiry_date || formData.license_expiration_date,
            license_class: formData.license_class,
            cdl_number: formData.cdl_number,
            cdl_endorsed: formData.cdl_endorsed || formData.has_cdl || false,
            emergency_contact_name: formData.emergency_contact_name,
            emergency_contact_phone: formData.emergency_contact_phone,
            emergency_contact_relationship: formData.emergency_contact_relationship,
            preferred_routes: formData.preferred_routes ? (Array.isArray(formData.preferred_routes) ? formData.preferred_routes : [formData.preferred_routes]) : null,
            years_of_experience: formData.years_of_experience ? parseInt(formData.years_of_experience) : null,
            status: 'active'
          };

          await supabase.from('driver_profiles').upsert(driverProfileData, { onConflict: 'user_id' });

          // Also populate vehicle data if provided
          if (formData.vehicle_make || formData.vehicle_model) {
            const vehicleData: any = {
              driver_id: user.id,
              make: formData.vehicle_make,
              model: formData.vehicle_model,
              year: formData.vehicle_year,
              color: formData.vehicle_color,
              license_plate: formData.license_plate || formData.vehicle_license_plate,
              vin: formData.vin || formData.vehicle_vin,
              registration_expiry: formData.registration_expiry || formData.vehicle_registration_expiry,
              is_primary: true
            };

            await supabase.from('driver_vehicles').upsert(vehicleData);
          }

          // Populate insurance data if provided
          if (formData.insurance_company || formData.insurance_provider) {
            const insuranceData: any = {
              driver_id: user.id,
              company: formData.insurance_company || formData.insurance_provider,
              policy_number: formData.insurance_policy_number || formData.policy_number,
              expiry_date: formData.insurance_expiry_date || formData.insurance_expiration_date,
              coverage_amount: formData.insurance_coverage_amount || formData.coverage_amount ? parseFloat(formData.insurance_coverage_amount || formData.coverage_amount) : null,
              is_active: true
            };

            await supabase.from('driver_insurance').upsert(insuranceData);
          }
        }

        console.log(`${role} profile populated successfully`);
      } catch (profileError) {
        console.error(`Failed to populate ${role} profile:`, profileError);
        // Continue anyway
      }

      toast({
        title: "Onboarding completed!",
        description: formData.government_id ? "Your application and identity verification have been submitted for review." : "Your application has been submitted for review.",
      });

      return true;
    } catch (error) {
      console.error('Submission error:', error);
      toast({
        title: "Submission failed",
        description: "Failed to submit onboarding",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const value: OnboardingContextType = {
    currentStep,
    totalSteps,
    role,
    formData,
    isLoading,
    uploadedFiles,
    setCurrentStep: updateCurrentStep,
    updateFormData,
    submitOnboarding,
    uploadFile,
    setRole,
    saveStepData,
    loadSavedData,
  };

  return (
    <OnboardingContext.Provider value={value}>
      {children}
    </OnboardingContext.Provider>
  );
}