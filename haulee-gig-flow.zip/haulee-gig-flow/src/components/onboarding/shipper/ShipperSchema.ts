export const SHIPPER_SCHEMA = {
  steps: [
    {
      step: 1,
      title: "Company Information",
      fields: [
        { text: { label: "Legal Company Name", type: "string", auto_fill: "company_name" } },
        { text: { label: "Doing Business As (DBA) Name", type: "string", optional: true } },
        { dropdown: { label: "Company Type", options: ["Manufacturer","Distributor","Retailer","E-commerce Seller","Importer","Exporter","Third-Party Logistics (3PL) Provider","Courier / Local Delivery Service","Agriculture / Farming","Construction / Industrial Supplier","Pharmaceutical / Medical Supplier","Food & Beverage","Specialty / Niche Goods","Other"] } },
        {
          row: [
            { number: { label: "Year Established", type: "number" } },
            { text: { label: "Tax ID / EIN", type: "string" } }
          ]
        },
        { text: { label: "Business License Number", type: "string", optional: true } },
        { dropdown: { label: "Operating Regions", options: ["Local","Regional","National","International"], multi_select: true } }
      ]
    },
    {
      step: 2,
      title: "Contact Information", 
      fields: [
        {
          row: [
            { text: { label: "Primary Contact First Name", type: "string" } },
            { text: { label: "Primary Contact Last Name", type: "string" } }
          ]
        },
        { text: { label: "Primary Contact Title", type: "string" } },
        {
          row: [
            { text: { label: "Phone Number", type: "string" } },
            { text: { label: "Email Address", type: "string", auto_fill: "email" } }
          ]
        },
        { text: { label: "Company Website", type: "string", optional: true } },
        {
          address: {
            label: "Physical Address (Headquarters)",
            street_number: "string",
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string"
          }
        },
        {
          address: {
            label: "Mailing Address",
            street_number: "string", 
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string",
            optional: true,
            collapsible: true
          }
        }
      ]
    },
    {
      step: 3,
      title: "Financial Information",
      fields: [
        {
          row: [
            { dropdown: { label: "Payment Terms", options: ["Net 30","Net 15","COD","Other"] } },
            { dropdown: { label: "Preferred Payment Method", options: ["ACH","Wire","Check"] } }
          ]
        },
        { custom_button: { label: "Complete W-9 Form", link: "/w9-form", optional: true } }
      ]
    },
    {
      step: 4,
      title: "Documents Upload",
      fields: [
        {
          row: [
            { upload: { label: "Proof of Insurance", options: ["camera", "file_upload"] } },
            { upload: { label: "Business License / Registration", options: ["camera", "file_upload"], optional: true } }
          ]
        },
        { custom_button: { label: "Complete W-9 Form", link: "/w9-form", optional: true } },
        { upload: { label: "Other Certifications", options: ["camera", "file_upload"], optional: true } }
      ]
    },
    {
      step: 5,
      title: "Review & Confirm",
      type: "review",
      fields: "all_previous",
      description: "Review all information and uploaded documents before submitting. You can edit any section before final submission."
    }
  ]
};
