import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { StepProgress } from '@/components/onboarding/StepProgress';
import { FormField } from '@/components/onboarding/FormField';
import { ReviewStep } from '@/components/onboarding/ReviewStep';
import { useOnboarding } from '@/components/onboarding/OnboardingProvider';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowLeft, ArrowRight, LogOut } from 'lucide-react';
import { SHIPPER_SCHEMA } from './ShipperSchema';

export function ShipperOnboarding() {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { 
    currentStep, 
    totalSteps, 
    formData, 
    setCurrentStep, 
    updateFormData, 
    submitOnboarding,
    saveStepData
  } = useOnboarding();

  const [stepData, setStepData] = useState<any>({});
  const [errors, setErrors] = useState<any>({});
  const [autoFillData, setAutoFillData] = useState<any>({});
  const [isLoading, setIsLoading] = useState(true);

  const schema = SHIPPER_SCHEMA;
  const stepTitles = schema.steps.map(step => step.title);

  // Redirect to status page after submission
  if (currentStep > totalSteps) {
    navigate('/status-and-tasks', { replace: true });
    return null;
  }

  const currentStepData = schema.steps[currentStep - 1];

  // Pre-fill data from user metadata and load saved data
  useEffect(() => {
    if (!currentStepData || !currentStepData.fields) {
      setIsLoading(false);
      return;
    }

    const autoFill: any = {};
    if (user?.email) {
      autoFill.email = user.email;
      autoFill.email_address = user.email;
    }
    if (user?.user_metadata?.company_name) {
      autoFill.legal_company_name = user.user_metadata.company_name;
      autoFill.company_name = user.user_metadata.company_name;
    }
    setAutoFillData(autoFill);
    
    // Load data from formData for current step
    const currentStepFields: any = {};
    
    // Only iterate over fields if it's an array (not 'all_previous' string for review step)
    if (Array.isArray(currentStepData.fields)) {
      currentStepData.fields.forEach((field: any) => {
        const fieldType = Object.keys(field)[0];
        
        if (fieldType === 'row') {
          field[fieldType].forEach((subField: any) => {
            const subFieldType = Object.keys(subField)[0];
            const subFieldConfig = subField[subFieldType];
            const key = subFieldConfig.label.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
            
            if (formData[key] !== undefined) {
              currentStepFields[key] = formData[key];
            } else if (autoFill[key]) {
              currentStepFields[key] = autoFill[key];
            }
          });
        } else {
          const fieldConfig = field[fieldType];
          const key = fieldConfig.label.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
          
          if (formData[key] !== undefined) {
            currentStepFields[key] = formData[key];
          } else if (autoFill[key]) {
            currentStepFields[key] = autoFill[key];
          }
        }
      });
    }
    
    setStepData(currentStepFields);
    setIsLoading(false);
  }, [user, currentStep, formData, currentStepData]);

  // Safety check: show loading if step data not ready
  if (isLoading || !currentStepData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading step...</p>
        </div>
      </div>
    );
  }

  const validateStep = () => {
    const errors: any = {};
    
    if (currentStepData.type === 'review') {
      return {}; // No validation needed for review step
    }

    const requireCascading = (cfg: any) => {
      const parentKey = cfg.parent?.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
      const parentVal = parentKey ? stepData[parentKey] : undefined;
      return Boolean(parentVal);
    };

    const validateOne = (type: string, cfg: any) => {
      const key = cfg.label.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
      // Check stepData first, then fall back to autoFillData
      const val = stepData[key] !== undefined ? stepData[key] : 
        (cfg.auto_fill && autoFillData[key] ? autoFillData[key] : undefined);

      // Skip validation for custom buttons
      if (type === 'custom_button') {
        return;
      }

      // Special handling for cascading dropdowns
      if (type === 'cascading_dropdown') {
        if (!requireCascading(cfg)) return;
        if (!cfg.optional && !val) {
          errors[key] = `${cfg.label} is required`;
        }
        return;
      }

      // Skip validation for optional upload fields that are empty
      if (type === 'upload' && cfg.optional && !val) {
        return;
      }

      if (!cfg.optional && !val) {
        errors[key] = `${cfg.label} is required`;
      }

      if (type === 'address' && !cfg.optional) {
        const requiredAddressFields = ['street_number', 'city', 'state', 'zip'];
        requiredAddressFields.forEach(addrField => {
          if (!val?.[addrField]) {
            errors[key] = `${cfg.label} requires all fields`;
          }
        });
      }
    };

    if (Array.isArray(currentStepData.fields)) {
      currentStepData.fields.forEach((field: any) => {
        const fieldType = Object.keys(field)[0];

        if (fieldType === 'row') {
          const rowFields = field[fieldType];
          rowFields.forEach((subField: any) => {
            const subType = Object.keys(subField)[0];
            const subCfg = subField[subType];
            validateOne(subType, subCfg);
          });
          return;
        }

        const fieldConfig = field[fieldType];
        validateOne(fieldType, fieldConfig);
      });
    }

    return errors;
  };

  const handleNext = () => {
    const stepErrors = validateStep();
    setErrors(stepErrors);

    if (Object.keys(stepErrors).length === 0) {
      // Persist current step to context and DB
      updateFormData(stepData);
      saveStepData(currentStep, currentStepData.title, stepData);
      
      if (currentStep < totalSteps) {
        // Move to next step
        setCurrentStep(currentStep + 1);
        setErrors({});
      }
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      // Save current data before going back
      updateFormData(stepData);
      saveStepData(currentStep, currentStepData.title, stepData);
      setCurrentStep(currentStep - 1);
      setErrors({});
    } else {
      navigate('/auth');
    }
  };

  const handleEditStep = (step: number) => {
    setCurrentStep(step);
    setErrors({});
  };

  const handleSubmit = async () => {
    // Save final step data
    updateFormData(stepData);
    saveStepData(currentStep, currentStepData.title, stepData);
    
    setIsLoading(true);
    const success = await submitOnboarding();
    setIsLoading(false);
    
    if (success) {
      navigate('/status-and-tasks', { replace: true });
    }
  };

  const handleFieldChange = (fieldLabel: string, value: any) => {
    const fieldKey = fieldLabel.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
    setStepData({ ...stepData, [fieldKey]: value });
    
    if (errors[fieldKey]) {
      setErrors({ ...errors, [fieldKey]: undefined });
    }
  };

  return (
    <div className="min-h-screen bg-background py-4 sm:py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center mb-6 gap-4">
          <div className="flex-1">
            <StepProgress 
              currentStep={currentStep} 
              totalSteps={totalSteps} 
              stepTitles={stepTitles}
            />
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={signOut}
            className="flex items-center gap-2 self-start sm:self-auto"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </Button>
        </div>

        <Card>
          <CardHeader className="p-4 sm:p-6">
            <CardTitle className="text-xl sm:text-2xl">{currentStepData.title}</CardTitle>
            {currentStepData.description && (
              <p className="text-sm sm:text-base text-muted-foreground mt-2">{currentStepData.description}</p>
            )}
          </CardHeader>
          <CardContent className="p-4 sm:p-6">
            {currentStepData.type === 'review' ? (
              <ReviewStep
                onEditStep={handleEditStep}
                stepTitles={stepTitles}
                onSubmit={handleSubmit}
                onboardingSchema={{ shipper: SHIPPER_SCHEMA }}
              />
            ) : (
              <div className="space-y-4 sm:space-y-6">
                {Array.isArray(currentStepData.fields) && currentStepData.fields.map((field: any, index: number) => {
                  const fieldType = Object.keys(field)[0];
                  
                  // Handle row fields
                  if (fieldType === 'row') {
                    const rowFields = field[fieldType];
                    return (
                      <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {rowFields.map((subField: any, subIndex: number) => {
                          const subFieldType = Object.keys(subField)[0];
                          const subFieldConfig = subField[subFieldType];
                          const subFieldKey = subFieldConfig.label.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
                          const subFieldValue = stepData[subFieldKey] !== undefined ? stepData[subFieldKey] : 
                            (subFieldConfig.auto_fill && autoFillData[subFieldKey] ? autoFillData[subFieldKey] : undefined);
                          
                          return (
                            <FormField
                              key={subIndex}
                              field={subField}
                              value={subFieldValue}
                              onChange={(value) => handleFieldChange(subFieldConfig.label, value)}
                              error={errors[subFieldKey]}
                              formData={stepData}
                            />
                          );
                        })}
                      </div>
                    );
                  }

                  // Handle regular fields
                  const fieldConfig = field[fieldType];
                  const fieldKey = fieldConfig.label.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '');
                  const fieldValue = stepData[fieldKey] !== undefined ? stepData[fieldKey] :
                    (fieldConfig.auto_fill && autoFillData[fieldKey] ? autoFillData[fieldKey] : undefined);

                  return (
                    <FormField
                      key={index}
                      field={field}
                      value={fieldValue}
                      onChange={(value) => handleFieldChange(fieldConfig.label, value)}
                      error={errors[fieldKey]}
                      formData={stepData}
                    />
                  );
                })}

                <div className="flex flex-col-reverse sm:flex-row gap-3 pt-6">
                  <Button
                    variant="outline"
                    onClick={handlePrevious}
                    className="flex items-center justify-center gap-2 w-full sm:w-auto min-h-[44px]"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span className="hidden sm:inline">{currentStep === 1 ? 'Back to Login' : 'Previous'}</span>
                    <span className="sm:hidden">Back</span>
                  </Button>
                  <Button
                    onClick={handleNext}
                    className="flex items-center justify-center gap-2 w-full sm:flex-1 min-h-[44px]"
                  >
                    Next
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
