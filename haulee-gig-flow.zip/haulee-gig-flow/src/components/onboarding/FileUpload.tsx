import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Camera, Upload, X, Eye } from 'lucide-react';
import { useOnboarding } from './OnboardingProvider';
import { toast } from '@/hooks/use-toast';

interface FileUploadProps {
  label: string;
  fieldName: string;
  value?: string;
  onChange: (value: string | null) => void;
  required?: boolean;
  options?: string[];
  error?: string;
}

export function FileUpload({ 
  label, 
  fieldName, 
  value, 
  onChange, 
  required = false,
  options = ['camera', 'file_upload'],
  error,
}: FileUploadProps) {
  const { uploadFile } = useOnboarding();
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (file: File) => {
    if (!file) return;

    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please select a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please select a JPEG, PNG, or PDF file",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    
    // Create preview for images
    if (file.type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }

    try {
      const uploadPath = await uploadFile(file, fieldName);
      if (uploadPath) {
        onChange(uploadPath);
        toast({
          title: "Upload successful",
          description: "File uploaded successfully",
        });
      } else {
        // Upload failed but didn't throw - show error
        toast({
          title: "Upload failed",
          description: "Failed to upload file. Please try again.",
          variant: "destructive",
        });
        setPreview(null);
      }
    } catch (error) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        variant: "destructive",
      });
      setPreview(null);
    } finally {
      setUploading(false);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
    // Reset input so same file can be selected again if upload fails
    event.target.value = '';
  };

  const clearFile = () => {
    onChange(null);
    setPreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const hasCamera = options.includes('camera');
  const hasFileUpload = options.includes('file_upload');

  return (
    <div className="space-y-2">
      <Label className="text-sm font-medium">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      
      {!value && (
        <Card className={`p-4 sm:p-6 border-dashed border-2 ${error ? 'border-destructive' : 'border-muted-foreground/25'}`}>
          <div className="text-center space-y-4">
            <div className="flex flex-col sm:flex-row justify-center gap-2">
              {hasCamera && (
                <>
                  <input
                    ref={cameraInputRef}
                    type="file"
                    accept="image/*"
                    capture="environment"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => cameraInputRef.current?.click()}
                    disabled={uploading}
                    className="w-full sm:w-auto"
                  >
                    <Camera className="w-4 h-4 mr-2" />
                    Camera
                  </Button>
                </>
              )}
              
              {hasFileUpload && (
                <>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handleFileSelect}
                    className="hidden"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={uploading}
                    className="w-full sm:w-auto"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    Upload File
                  </Button>
                </>
              )}
            </div>
            
            <p className="text-xs sm:text-sm text-muted-foreground px-2">
              {uploading ? 'Uploading...' : 'Select a file to upload (JPEG, PNG, or PDF, max 10MB)'}
            </p>
          </div>
        </Card>
      )}
      {error && !value && <p className="text-sm text-destructive">{error}</p>}

      {(value || preview) && (
        <Card className="p-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="flex items-center gap-3">
              {preview && (
                <img 
                  src={preview} 
                  alt="Preview" 
                  className="w-12 h-12 object-cover rounded border flex-shrink-0"
                />
              )}
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-primary">
                  File uploaded successfully
                </p>
                <p className="text-xs text-muted-foreground">
                  {uploading ? 'Processing...' : 'Ready'}
                </p>
              </div>
            </div>
            
            <div className="flex gap-2 justify-end sm:justify-start">
              {preview && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => window.open(preview, '_blank')}
                >
                  <Eye className="w-4 h-4" />
                </Button>
              )}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={clearFile}
                disabled={uploading}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}
    </div>
  );
}