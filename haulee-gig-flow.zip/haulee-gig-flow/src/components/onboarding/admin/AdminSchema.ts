export const ADMIN_SCHEMA = {
  steps: [
    {
      step: 1,
      title: "Personal Information",
      fields: [
        {
          row: [
            { text: { label: "First Name", type: "string" } },
            { text: { label: "Middle Name", type: "string", optional: true } },
            { text: { label: "Last Name", type: "string" } }
          ]
        },
        {
          row: [
            { text: { label: "Email Address", type: "string", auto_fill: "email" } },
            { text: { label: "Phone Number", type: "phone" } }
          ]
        },
        {
          address: {
            label: "Residential Address",
            street_number: "string",
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string"
          }
        }
      ]
    },
    {
      step: 2,
      title: "Employment Information",
      fields: [
        { text: { label: "Position/Title", type: "string" } },
        { dropdown: { label: "Department", options: ["Operations","Finance","Customer Service","Dispatch","Management","IT","Other"] } },
        { date: { label: "Start Date" } },
        {
          row: [
            { dropdown: { label: "Employment Type", options: ["Full-Time","Part-Time","Contract","Temporary"] } },
            { dropdown: { label: "Work Schedule", options: ["Day Shift","Night Shift","Flexible","Other"] } }
          ]
        },
        { text: { label: "Emergency Contact Name", type: "string" } },
        {
          row: [
            { text: { label: "Emergency Contact Phone", type: "phone" } },
            { text: { label: "Emergency Contact Relationship", type: "string" } }
          ]
        }
      ]
    },
    {
      step: 3,
      title: "Review & Confirm",
      type: "review",
      fields: "all_previous",
      description: "Review all information before submitting. You can edit any section before final submission."
    }
  ]
};
