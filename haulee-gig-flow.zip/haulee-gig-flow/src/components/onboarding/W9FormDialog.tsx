import { useState, useRef, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "sonner";
import { FileText, Download, CheckCircle } from "lucide-react";

interface W9FormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function W9FormDialog({ open, onOpenChange }: W9FormDialogProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    taxpayerName: "",
    businessName: "",
    tinType: "EIN" as "SSN" | "EIN",
    tin: "",
    address: "",
    city: "",
    state: "",
    zip: "",
  });

  useEffect(() => {
    if (open) {
      checkExistingW9();
    }
  }, [open]);

  const checkExistingW9 = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const { data, error } = await supabase
      .from("w9_forms")
      .select("status, approved_at, pdf_url")
      .eq("user_id", user.id)
      .order("submitted_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (data?.approved_at) {
      setIsCompleted(true);
      if (data.pdf_url) {
        setPdfUrl(data.pdf_url);
      }
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const signatureData = canvas.toDataURL("image/png");
    
    // Check if signature is empty
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const isEmpty = !imageData.data.some(channel => channel !== 0);
    
    if (isEmpty) {
      toast.error("Please provide your signature");
      return;
    }

    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      // Call edge function to generate PDF
      const { data, error } = await supabase.functions.invoke("generate-w9-pdf", {
        body: {
          ...formData,
          signatureData,
          userId: user.id,
        },
      });

      if (error) throw error;

      setIsCompleted(true);
      setPdfUrl(data.pdfUrl);
      toast.success("W-9 form submitted successfully!");
    } catch (error: any) {
      console.error("Error submitting W-9:", error);
      toast.error(error.message || "Failed to submit W-9 form");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDownload = async () => {
    if (!pdfUrl) return;
    
    try {
      const { data, error } = await supabase.storage
        .from("w9-forms")
        .download(pdfUrl.replace("w9-forms/", ""));

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement("a");
      a.href = url;
      a.download = "W-9_Form.pdf";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error: any) {
      console.error("Error downloading W-9:", error);
      toast.error("Failed to download W-9 form");
    }
  };

  const handleClose = () => {
    onOpenChange(false);
    // Reset form if not completed
    if (!isCompleted) {
      setFormData({
        taxpayerName: "",
        businessName: "",
        tinType: "EIN",
        tin: "",
        address: "",
        city: "",
        state: "",
        zip: "",
      });
      clearSignature();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto p-4 sm:p-6">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 sm:gap-3 text-lg sm:text-xl">
            {isCompleted ? (
              <>
                <CheckCircle className="h-5 w-5 sm:h-6 sm:w-6 text-green-500" />
                <span>W-9 Form Completed</span>
              </>
            ) : (
              <>
                <FileText className="h-5 w-5 sm:h-6 sm:w-6" />
                <span>Complete W-9 Form</span>
              </>
            )}
          </DialogTitle>
          {isCompleted && (
            <DialogDescription className="text-sm">
              Your W-9 form has been completed and saved. You can download it at any time.
            </DialogDescription>
          )}
        </DialogHeader>

        {isCompleted ? (
          <div className="space-y-4 pt-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <Button onClick={handleDownload} className="gap-2 w-full sm:w-auto">
                <Download className="h-4 w-4" />
                Download My W-9
              </Button>
              <Button variant="outline" onClick={handleClose} className="w-full sm:w-auto">
                Close
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6 pt-4">
            <div className="space-y-4">
              <div>
                <Label htmlFor="taxpayerName">Taxpayer Name *</Label>
                <Input
                  id="taxpayerName"
                  required
                  value={formData.taxpayerName}
                  onChange={(e) => setFormData({ ...formData, taxpayerName: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="businessName">Business Name (if different)</Label>
                <Input
                  id="businessName"
                  value={formData.businessName}
                  onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                />
              </div>

              <div>
                <Label>Tax Identification Number Type *</Label>
                <RadioGroup
                  value={formData.tinType}
                  onValueChange={(value) => setFormData({ ...formData, tinType: value as "SSN" | "EIN" })}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="SSN" id="ssn" />
                    <Label htmlFor="ssn" className="font-normal">Social Security Number (SSN)</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="EIN" id="ein" />
                    <Label htmlFor="ein" className="font-normal">Employer Identification Number (EIN)</Label>
                  </div>
                </RadioGroup>
              </div>

              <div>
                <Label htmlFor="tin">{formData.tinType} *</Label>
                <Input
                  id="tin"
                  required
                  placeholder={formData.tinType === "SSN" ? "XXX-XX-XXXX" : "XX-XXXXXXX"}
                  value={formData.tin}
                  onChange={(e) => setFormData({ ...formData, tin: e.target.value })}
                />
              </div>

              <div>
                <Label htmlFor="address">Address *</Label>
                <Input
                  id="address"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    required
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="state">State *</Label>
                  <Input
                    id="state"
                    required
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="zip">ZIP Code *</Label>
                  <Input
                    id="zip"
                    required
                    value={formData.zip}
                    onChange={(e) => setFormData({ ...formData, zip: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label className="text-sm sm:text-base">Signature *</Label>
                <div className="space-y-2">
                  <canvas
                    ref={canvasRef}
                    width={600}
                    height={150}
                    className="border rounded-md w-full cursor-crosshair bg-white touch-none"
                    onMouseDown={startDrawing}
                    onMouseMove={draw}
                    onMouseUp={stopDrawing}
                    onMouseLeave={stopDrawing}
                    onTouchStart={(e) => {
                      const touch = e.touches[0];
                      const mouseEvent = new MouseEvent('mousedown', {
                        clientX: touch.clientX,
                        clientY: touch.clientY
                      });
                      e.currentTarget.dispatchEvent(mouseEvent);
                    }}
                    onTouchMove={(e) => {
                      e.preventDefault();
                      const touch = e.touches[0];
                      const mouseEvent = new MouseEvent('mousemove', {
                        clientX: touch.clientX,
                        clientY: touch.clientY
                      });
                      e.currentTarget.dispatchEvent(mouseEvent);
                    }}
                    onTouchEnd={(e) => {
                      const mouseEvent = new MouseEvent('mouseup', {});
                      e.currentTarget.dispatchEvent(mouseEvent);
                    }}
                  />
                  <Button type="button" variant="outline" size="sm" onClick={clearSignature} className="w-full sm:w-auto">
                    Clear Signature
                  </Button>
                </div>
              </div>
            </div>

            <div className="flex flex-col-reverse sm:flex-row gap-3">
              <Button type="button" variant="outline" onClick={handleClose} className="w-full sm:w-auto">
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting} className="w-full sm:flex-1 min-h-[44px]">
                {isSubmitting ? "Submitting..." : "Submit W-9"}
              </Button>
            </div>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
