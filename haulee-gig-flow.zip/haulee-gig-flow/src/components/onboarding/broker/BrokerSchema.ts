export const BROKER_SCHEMA = {
  steps: [
    {
      step: 1,
      title: "Company Information",
      fields: [
        { text: { label: "Legal Company Name", type: "string", auto_fill: "company_name" } },
        { text: { label: "Doing Business As (DBA) Name", type: "string", optional: true } },
        { dropdown: { label: "Company Type", options: ["Manufacturer","Distributor","Retailer","E-commerce Seller","Importer","Exporter","Third-Party Logistics (3PL) Provider","Courier / Local Delivery Service","Agriculture / Farming","Construction / Industrial Supplier","Pharmaceutical / Medical Supplier","Food & Beverage","Specialty / Niche Goods","Other"] } },
        {
          row: [
            { number: { label: "Year Established", type: "number" } },
            { text: { label: "Tax ID / EIN", type: "string" } }
          ]
        },
        { text: { label: "Business License Number", type: "string", optional: true } },
        { dropdown: { label: "Operating Regions", options: ["Local","Regional","National","International"], multi_select: true } }
      ]
    },
    {
      step: 2,
      title: "Contact Information", 
      fields: [
        {
          row: [
            { text: { label: "Primary Contact First Name", type: "string" } },
            { text: { label: "Primary Contact Last Name", type: "string" } }
          ]
        },
        { text: { label: "Primary Contact Title", type: "string" } },
        {
          row: [
            { text: { label: "Phone Number", type: "string" } },
            { text: { label: "Email Address", type: "string" } }
          ]
        },
        { text: { label: "Company Website", type: "string", optional: true } },
        {
          address: {
            label: "Physical Address (Headquarters)",
            street_number: "string",
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string"
          }
        },
        {
          address: {
            label: "Mailing Address",
            street_number: "string", 
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string",
            optional: true,
            collapsible: true
          }
        }
      ]
    },
    {
      step: 3,
      title: "Compliance & Authority",
      fields: [
        {
          row: [
            { text: { label: "Broker Authority Number / MC Number", type: "string", optional: true } },
            { text: { label: "USDOT Number", type: "string", optional: true } }
          ]
        },
        { dropdown: { label: "Insurance Type", options: ["General Liability","Cargo","Other"], multi_select: true } },
        {
          row: [
            { upload: { label: "Compliance Documents", options: ["camera", "file_upload"], optional: true } },
            { upload: { label: "Certifications or Licenses (if required)", options: ["camera", "file_upload"], optional: true } }
          ]
        }
      ]
    },
    {
      step: 4,
      title: "Financial Information",
      fields: [
        {
          row: [
            { dropdown: { label: "Payment Terms", options: ["Net 30","Net 15","COD","Other"] } },
            { dropdown: { label: "Preferred Payment Method", options: ["ACH","Wire","Check"] } }
          ]
        },
        { text: { label: "Bank Details", type: "string", optional: true } },
        { custom_button: { label: "Complete W-9 Form", link: "/w9-form", optional: true } }
      ]
    },
    {
      step: 5,
      title: "Load & Operational Preferences",
      fields: [
        { dropdown: { label: "Types of Cargo Handled", options: ["FTL","LTL","Refrigerated","Hazardous","Dry","Other"], multi_select: true } },
        {
          row: [
            { text: { label: "Equipment Requirements", type: "string", optional: true } },
            { text: { label: "Geographic Coverage / Delivery Regions", type: "string" } }
          ]
        },
        {
          row: [
            { text: { label: "Maximum/Minimum Shipment Size", type: "string", optional: true } },
            { text: { label: "Preferred Carriers / Restrictions", type: "string", optional: true } }
          ]
        },
        { text: { label: "Operational Notes", type: "string", optional: true } }
      ]
    },
    {
      step: 6,
      title: "Documents Upload",
      fields: [
        {
          row: [
            { upload: { label: "Proof of Insurance", options: ["camera", "file_upload"] } },
            { upload: { label: "Business License / Registration", options: ["camera", "file_upload"], optional: true } }
          ]
        },
        { upload: { label: "Broker Authority Documents (if applicable)", options: ["camera", "file_upload"], optional: true } },
        { custom_button: { label: "Complete W-9 Form", link: "/w9-form", optional: true } },
        { upload: { label: "Other Certifications", options: ["camera", "file_upload"], optional: true } }
      ]
    },
    {
      step: 7,
      title: "Optional / Advanced Information",
      fields: [
        {
          row: [
            { text: { label: "EDI Capabilities", type: "string", optional: true } },
            { text: { label: "API Integration Details", type: "string", optional: true } }
          ]
        },
        {
          row: [
            { text: { label: "References from Past Shipments", type: "string", optional: true } },
            { text: { label: "Credit or Financial Verification", type: "string", optional: true } }
          ]
        }
      ]
    },
    {
      step: 8,
      title: 'Review & Confirm',
      type: 'review',
      fields: 'all_previous',
      description: 'Review all information and uploaded documents before submitting. You can edit any section before final submission.'
    }
  ]
};
