import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useOnboarding, OnboardingRole } from './OnboardingProvider';
import { useAuth } from '@/contexts/AuthContext';
import { FileUpload } from './FileUpload';
import { Badge } from '@/components/ui/badge';
import { Shield, User, MapPin, FileText, Building2, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { useNavigate } from 'react-router-dom';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';

const US_STATES = ["AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA","KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ","NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT","VA","WA","WV","WI","WY"];

const ID_TYPES = ["Driver License", "State ID", "Passport", "Military ID"];

export function UnifiedKYCForm() {
  const { user } = useAuth();
  const { formData, updateFormData, role } = useOnboarding();
  const navigate = useNavigate();
  const [ageError, setAgeError] = useState<string | null>(null);
  const [isUnderAge, setIsUnderAge] = useState(false);
  const [localData, setLocalData] = useState<any>({
    // Prefilled fields
    email: user?.email || '',
    phone_number: formData.phone_number || formData.phone || user?.phone || user?.user_metadata?.phone || '',
    
    // Basic personal info
    first_name: formData.first_name || '',
    middle_name: formData.middle_name || '',
    last_name: formData.last_name || '',
    date_of_birth: formData.date_of_birth || '',
    
    // Address
    address_street: formData.address_street || '',
    address_apt: formData.address_apt || '',
    address_city: formData.address_city || '',
    address_state: formData.address_state || '',
    address_postal_code: formData.address_postal_code || '',
    address_country: formData.address_country || 'United States',
    
    // ID verification
    id_type: formData.id_type || '',
    id_number: formData.id_number || '',
    id_document: formData.id_document || null,
    selfie: formData.selfie || null,
    
    // Role-specific fields
    driver_license_number: formData.driver_license_number || '',
    driver_license_front: formData.driver_license_front || null,
    driver_license_back: formData.driver_license_back || null,
    company_name: formData.company_name || '',
    business_name: formData.business_name || '',
    broker_license_number: formData.broker_license_number || '',
    store_name: formData.store_name || '',
    admin_id: formData.admin_id || '',
  });

  // Auto-save on changes
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      updateFormData(localData);
    }, 500);
    
    return () => clearTimeout(timeoutId);
  }, [localData]);

  const calculateAge = (birthDate: string): number => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  const handleChange = (field: string, value: any) => {
    // Special validation for date of birth
    if (field === 'date_of_birth' && value) {
      const age = calculateAge(value);
      
      if (age < 18) {
        setAgeError(`You must be at least 18 years old to apply. Current age: ${age}`);
        setIsUnderAge(true);
        
        // Terminate application after 3 seconds
        setTimeout(() => {
          navigate('/auth', { replace: true });
        }, 3000);
      } else {
        setAgeError(null);
        setIsUnderAge(false);
      }
    }
    
    setLocalData((prev: any) => ({ ...prev, [field]: value }));
  };

  const renderRoleSpecificFields = () => {
    switch (role) {
      case 'driver':
        return (
          <Card className="border-2">
            <CardHeader className="bg-muted/30 p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                Driver Information
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6 space-y-3 sm:space-y-4">
              <div>
                <Label htmlFor="driver_license_number" className="text-xs sm:text-sm">Driver License Number <span className="text-muted-foreground text-xs">(Optional)</span></Label>
                <Input
                  id="driver_license_number"
                  value={localData.driver_license_number}
                  onChange={(e) => handleChange('driver_license_number', e.target.value)}
                  placeholder="Enter license number"
                  className="h-9 sm:h-10 text-sm"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <Label className="text-xs sm:text-sm">Driver License (Front)</Label>
                  <FileUpload
                    label=""
                    fieldName="driver_license_front"
                    value={localData.driver_license_front}
                    onChange={(value) => handleChange('driver_license_front', value)}
                    options={['camera', 'file_upload']}
                  />
                </div>
                <div>
                  <Label className="text-xs sm:text-sm">Driver License (Back)</Label>
                  <FileUpload
                    label=""
                    fieldName="driver_license_back"
                    value={localData.driver_license_back}
                    onChange={(value) => handleChange('driver_license_back', value)}
                    options={['camera', 'file_upload']}
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        );
      
      case 'carrier':
        return (
          <Card className="border-2">
            <CardHeader className="bg-muted/30 p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                Carrier Information
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6">
              <div>
                <Label htmlFor="company_name" className="text-xs sm:text-sm">Company Name <span className="text-destructive">*</span></Label>
                <Input
                  id="company_name"
                  value={localData.company_name}
                  onChange={(e) => handleChange('company_name', e.target.value)}
                  placeholder="Enter company name"
                  required
                  className="h-9 sm:h-10 text-sm"
                />
              </div>
            </CardContent>
          </Card>
        );
      
      case 'shipper':
        return (
          <Card className="border-2">
            <CardHeader className="bg-muted/30 p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                Shipper Information
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6">
              <div>
                <Label htmlFor="business_name" className="text-xs sm:text-sm">Business Name <span className="text-destructive">*</span></Label>
                <Input
                  id="business_name"
                  value={localData.business_name}
                  onChange={(e) => handleChange('business_name', e.target.value)}
                  placeholder="Enter business name"
                  required
                  className="h-9 sm:h-10 text-sm"
                />
              </div>
            </CardContent>
          </Card>
        );
      
      case 'broker':
        return (
          <Card className="border-2">
            <CardHeader className="bg-muted/30 p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                Broker Information
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6">
              <div>
                <Label htmlFor="broker_license_number" className="text-xs sm:text-sm">Broker License Number <span className="text-destructive">*</span></Label>
                <Input
                  id="broker_license_number"
                  value={localData.broker_license_number}
                  onChange={(e) => handleChange('broker_license_number', e.target.value)}
                  placeholder="Enter broker license number"
                  required
                  className="h-9 sm:h-10 text-sm"
                />
              </div>
            </CardContent>
          </Card>
        );
      
      case 'vendor_merchant':
      case 'merchant':
        return (
          <Card className="border-2">
            <CardHeader className="bg-muted/30 p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                Vendor Information
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6">
              <div>
                <Label htmlFor="store_name" className="text-xs sm:text-sm">Store Name <span className="text-destructive">*</span></Label>
                <Input
                  id="store_name"
                  value={localData.store_name}
                  onChange={(e) => handleChange('store_name', e.target.value)}
                  placeholder="Enter store name"
                  required
                  className="h-9 sm:h-10 text-sm"
                />
              </div>
            </CardContent>
          </Card>
        );
      
      case 'admin':
        return (
          <Card className="border-2">
            <CardHeader className="bg-muted/30 p-4 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Shield className="h-4 w-4 sm:h-5 sm:w-5" />
                Admin Information
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6">
              <div>
                <Label htmlFor="admin_id" className="text-xs sm:text-sm">Admin ID <span className="text-destructive">*</span></Label>
                <Input
                  id="admin_id"
                  value={localData.admin_id}
                  onChange={(e) => handleChange('admin_id', e.target.value)}
                  placeholder="Enter admin ID"
                  required
                  className="h-9 sm:h-10 text-sm"
                />
              </div>
            </CardContent>
          </Card>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6 max-w-4xl mx-auto px-2 sm:px-0">
      {/* Age Restriction Alert */}
      {isUnderAge && (
        <Alert variant="destructive" className="border-2">
          <AlertCircle className="h-4 w-4 sm:h-5 sm:w-5" />
          <AlertTitle className="text-sm sm:text-base">Application Terminated</AlertTitle>
          <AlertDescription className="text-xs sm:text-sm">
            {ageError} You do not meet the minimum age requirement. Redirecting you back to the login page...
          </AlertDescription>
        </Alert>
      )}

      {/* Header */}
      <div className="text-center space-y-2 px-2">
        <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold">Initial Application</h1>
        <p className="text-sm sm:text-base text-muted-foreground">
          Complete your identity verification to get started. All fields auto-save as you type.
        </p>
        <Badge variant="secondary" className="mt-2 text-xs sm:text-sm">
          Role: {role?.replace('_', ' ').toUpperCase()}
        </Badge>
      </div>

      {/* Prefilled Contact Info */}
      <Card className="border-2">
        <CardHeader className="bg-muted/30 p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <User className="h-4 w-4 sm:h-5 sm:w-5" />
            Contact Information (Prefilled)
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6 space-y-3 sm:space-y-4">
          <div>
            <Label htmlFor="email" className="text-xs sm:text-sm">Email Address</Label>
            <Input
              id="email"
              type="email"
              value={localData.email}
              readOnly
              disabled
              className="bg-muted h-9 sm:h-10 text-sm"
            />
          </div>
          <div>
            <Label htmlFor="phone_number" className="text-xs sm:text-sm">Phone Number</Label>
            <Input
              id="phone_number"
              value={localData.phone_number}
              readOnly
              disabled
              className="bg-muted h-9 sm:h-10 text-sm"
            />
          </div>
        </CardContent>
      </Card>

      {/* Basic Personal Info */}
      <Card className="border-2">
        <CardHeader className="bg-muted/30 p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <User className="h-4 w-4 sm:h-5 sm:w-5" />
            Personal Information
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6 space-y-3 sm:space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <Label htmlFor="first_name" className="text-xs sm:text-sm">First Name <span className="text-destructive">*</span></Label>
              <Input
                id="first_name"
                value={localData.first_name}
                onChange={(e) => handleChange('first_name', e.target.value)}
                placeholder="Enter first name"
                required
                className="h-9 sm:h-10 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="last_name" className="text-xs sm:text-sm">Last Name <span className="text-destructive">*</span></Label>
              <Input
                id="last_name"
                value={localData.last_name}
                onChange={(e) => handleChange('last_name', e.target.value)}
                placeholder="Enter last name"
                required
                className="h-9 sm:h-10 text-sm"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="middle_name" className="text-xs sm:text-sm">Middle Name <span className="text-muted-foreground text-xs">(Optional)</span></Label>
            <Input
              id="middle_name"
              value={localData.middle_name}
              onChange={(e) => handleChange('middle_name', e.target.value)}
              placeholder="Enter middle name"
              className="h-9 sm:h-10 text-sm"
            />
          </div>
          <div>
            <Label htmlFor="date_of_birth" className="text-xs sm:text-sm">Date of Birth <span className="text-destructive">*</span></Label>
            <Input
              id="date_of_birth"
              type="date"
              value={localData.date_of_birth}
              onChange={(e) => handleChange('date_of_birth', e.target.value)}
              max={new Date().toISOString().split('T')[0]}
              required
              disabled={isUnderAge}
              className={`h-9 sm:h-10 text-sm ${ageError ? 'border-destructive' : ''}`}
            />
            {ageError && !isUnderAge && (
              <p className="text-xs sm:text-sm text-destructive mt-1">{ageError}</p>
            )}
            <p className="text-xs text-muted-foreground mt-1">You must be at least 18 years old</p>
          </div>
        </CardContent>
      </Card>

      {/* Address */}
      <Card className="border-2">
        <CardHeader className="bg-muted/30 p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <MapPin className="h-4 w-4 sm:h-5 sm:w-5" />
            Address
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6 space-y-3 sm:space-y-4">
          <div>
            <AddressAutocomplete
              label="Street Address"
              value={localData.address_street}
              onAddressSelect={(address) => {
                handleChange('address_street', address.formatted_address || '');
                handleChange('address_city', address.city || '');
                handleChange('address_state', address.state || '');
                handleChange('address_postal_code', address.zip || '');
              }}
              placeholder="Start typing your address..."
              required
            />
          </div>
          <div>
            <Label htmlFor="address_apt" className="text-xs sm:text-sm">Apartment/Suite <span className="text-muted-foreground text-xs">(Optional)</span></Label>
            <Input
              id="address_apt"
              value={localData.address_apt}
              onChange={(e) => handleChange('address_apt', e.target.value)}
              placeholder="Apt, Suite, Unit, etc."
              className="h-9 sm:h-10 text-sm"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
            <div>
              <Label htmlFor="address_city" className="text-xs sm:text-sm">City <span className="text-destructive">*</span></Label>
              <Input
                id="address_city"
                value={localData.address_city}
                onChange={(e) => handleChange('address_city', e.target.value)}
                placeholder="Enter city"
                required
                className="h-9 sm:h-10 text-sm"
              />
            </div>
            <div>
              <Label htmlFor="address_state" className="text-xs sm:text-sm">State <span className="text-destructive">*</span></Label>
              <Select
                value={localData.address_state}
                onValueChange={(value) => handleChange('address_state', value)}
              >
                <SelectTrigger id="address_state" className="h-9 sm:h-10 text-sm">
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent className="max-h-[200px]">
                  {US_STATES.map(state => (
                    <SelectItem key={state} value={state} className="text-sm">{state}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="address_postal_code" className="text-xs sm:text-sm">Postal Code <span className="text-destructive">*</span></Label>
              <Input
                id="address_postal_code"
                value={localData.address_postal_code}
                onChange={(e) => handleChange('address_postal_code', e.target.value)}
                placeholder="ZIP code"
                required
                className="h-9 sm:h-10 text-sm"
              />
            </div>
          </div>
          <div>
            <Label htmlFor="address_country" className="text-xs sm:text-sm">Country <span className="text-destructive">*</span></Label>
            <Input
              id="address_country"
              value={localData.address_country}
              readOnly
              disabled
              className="bg-muted h-9 sm:h-10 text-sm"
            />
          </div>
        </CardContent>
      </Card>

      {/* ID Verification */}
      <Card className="border-2">
        <CardHeader className="bg-muted/30 p-4 sm:p-6">
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
            Identity Verification
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-4 sm:pt-6 p-4 sm:p-6 space-y-3 sm:space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <Label htmlFor="id_type" className="text-xs sm:text-sm">ID Type <span className="text-destructive">*</span></Label>
              <Select
                value={localData.id_type}
                onValueChange={(value) => handleChange('id_type', value)}
              >
                <SelectTrigger id="id_type" className="h-9 sm:h-10 text-sm">
                  <SelectValue placeholder="Select ID type" />
                </SelectTrigger>
                <SelectContent className="max-h-[200px]">
                  {ID_TYPES.map(type => (
                    <SelectItem key={type} value={type} className="text-sm">{type}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="id_number" className="text-xs sm:text-sm">ID Number <span className="text-destructive">*</span></Label>
              <Input
                id="id_number"
                value={localData.id_number}
                onChange={(e) => handleChange('id_number', e.target.value)}
                placeholder="Enter ID number"
                required
                className="h-9 sm:h-10 text-sm"
              />
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
            <div>
              <Label className="text-xs sm:text-sm">ID Document <span className="text-destructive">*</span></Label>
              <FileUpload
                label=""
                fieldName="id_document"
                value={localData.id_document}
                onChange={(value) => handleChange('id_document', value)}
                options={['camera', 'file_upload']}
                required
              />
            </div>
            <div>
              <Label className="text-xs sm:text-sm">Selfie Photo <span className="text-destructive">*</span></Label>
              <FileUpload
                label=""
                fieldName="selfie"
                value={localData.selfie}
                onChange={(value) => handleChange('selfie', value)}
                options={['camera', 'file_upload']}
                required
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Role-Specific Fields */}
      {renderRoleSpecificFields()}

      {/* Auto-save indicator */}
      <div className="text-center text-xs sm:text-sm text-muted-foreground px-2">
        <Badge variant="outline" className="gap-2 text-xs sm:text-sm">
          <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
          All changes are saved automatically
        </Badge>
      </div>
    </div>
  );
}
