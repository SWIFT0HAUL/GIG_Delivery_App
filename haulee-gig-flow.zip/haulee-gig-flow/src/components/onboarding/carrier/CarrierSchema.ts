export const CARRIER_SCHEMA = {
  steps: [
    {
      step: 1,
      title: "Company Information",
      fields: [
        { text: { label: "Legal Company Name", type: "string", auto_fill: "company_name" } },
        { text: { label: "Doing Business As (DBA) Name", type: "string", optional: true } },
        { dropdown: { label: "Carrier Type", options: ["Owner-Operator","Fleet","Other"] } },
        {
          row: [
            { text: { label: "DOT Number", type: "string" } },
            { text: { label: "MC Number", type: "string", optional: true } }
          ]
        },
        {
          row: [
            { dropdown: { label: "USDOT Registration Status", options: ["Active","Inactive","Pending"] } },
            { text: { label: "EIN / Tax ID", type: "string" } }
          ]
        },
        {
          row: [
            { number: { label: "Year Established", type: "number" } },
            { dropdown: { label: "Type of Operation", options: ["Local","Regional","Interstate"] } }
          ]
        },
        {
          row: [
            { number: { label: "Number of Vehicles in Fleet", type: "number" } },
            { number: { label: "Number of Drivers Employed", type: "number" } }
          ]
        }
      ]
    },
    {
      step: 2,
      title: "Contact Information",
      fields: [
        {
          row: [
            { text: { label: "Primary Contact First Name", type: "string" } },
            { text: { label: "Primary Contact Last Name", type: "string" } }
          ]
        },
        { text: { label: "Primary Contact Title", type: "string" } },
        {
          row: [
            { text: { label: "Phone Number", type: "phone" } },
            { text: { label: "Email Address", type: "string", auto_fill: "email" } }
          ]
        },
        { text: { label: "Company Website", type: "string", optional: true } },
        {
          address: {
            label: "Physical Address (Headquarters)",
            street_number: "string",
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string"
          }
        },
        {
          address: {
            label: "Mailing Address",
            street_number: "string",
            apt_suite: "string (optional)",
            city: "string",
            state: "dropdown_us_states",
            zip: "string",
            optional: true,
            collapsible: true
          }
        }
      ]
    },
    {
      step: 3,
      title: "Insurance Details",
      fields: [
        {
          row: [
            { dropdown: { label: "Insurance Company", options: ["State Farm","GEICO","Progressive","Allstate","Nationwide","Farmers","Liberty Mutual","Travelers","USAA","Other"] } },
            { text: { label: "Policy Number", type: "string" } }
          ]
        },
        { dropdown: { label: "Coverage Type", options: ["General Liability","Cargo","Auto","Other"], multi_select: true } },
        {
          row: [
            { text: { label: "Coverage Limit", type: "string" } },
            { date: { label: "Effective Date" } }
          ]
        },
        { date: { label: "Expiration Date" } },
        { upload: { label: "Insurance Documents", options: ["camera", "file_upload"] } }
      ]
    },
    {
      step: 4,
      title: "Driver & Vehicle Information",
      fields: [
        {
          row: [
            { dropdown: { label: "Vehicle Types", options: ["Truck","Van","Flatbed","Refrigerated","Other"] } },
            { dropdown: { label: "Vehicle Size / Capacity", options: ["Small","Medium","Large","Extra Large","Other"], multi_select: true } }
          ]
        },
        { text: { label: "Vehicle Registration Numbers", type: "string" } },
        {
          row: [
            { upload: { label: "Vehicle Inspection / Maintenance Records", options: ["camera", "file_upload"] } },
            { upload: { label: "Driver Roster", options: ["camera", "file_upload"], optional: true } }
          ]
        }
      ]
    },
    {
      step: 5,
      title: "Review & Confirm",
      type: "review",
      fields: "all_previous",
      description: "Review all information and uploaded documents before submitting. You can edit any section before final submission."
    }
  ]
};
