import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { ChevronDown, ChevronUp } from 'lucide-react';

interface AddressFieldProps {
  label: string;
  value: any;
  onChange: (value: any) => void;
  error?: string;
  required?: boolean;
  collapsible?: boolean;
}

export function AddressField({ 
  label, 
  value = {}, 
  onChange, 
  error,
  required = false,
  collapsible = false
}: AddressFieldProps) {
  const [isCollapsed, setIsCollapsed] = useState(collapsible);
  const [useAutocomplete, setUseAutocomplete] = useState(true);

  const handleAutocompleteSelect = (addressData: any) => {
    onChange({
      street_number: addressData.street_number || '',
      apt_suite: value.apt_suite || '',
      city: addressData.city || '',
      state: addressData.state || '',
      zip: addressData.zip || '',
      formatted_address: addressData.formatted_address || ''
    });
  };

  const handleManualChange = (field: string, fieldValue: string) => {
    onChange({
      ...value,
      [field]: fieldValue
    });
  };

  if (collapsible && isCollapsed) {
    return (
      <div className="space-y-2">
        <button
          type="button"
          onClick={() => setIsCollapsed(false)}
          className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
        >
          <ChevronDown className="h-4 w-4" />
          Add {label}
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-4 p-3 sm:p-4 border rounded-lg">
      <div className="flex items-center justify-between">
        <h4 className="text-sm sm:text-base font-medium">
          {label} {required && <span className="text-destructive">*</span>}
        </h4>
        {collapsible && (
          <button
            type="button"
            onClick={() => setIsCollapsed(true)}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            <ChevronUp className="h-4 w-4" />
          </button>
        )}
      </div>

      {useAutocomplete ? (
        <>
          <AddressAutocomplete
            label="Search Address"
            onAddressSelect={handleAutocompleteSelect}
            placeholder="Start typing your address..."
            required={required}
            defaultValue={value.formatted_address || ''}
          />
          <button
            type="button"
            onClick={() => setUseAutocomplete(false)}
            className="text-xs text-muted-foreground hover:text-foreground underline"
          >
            Enter address manually
          </button>
        </>
      ) : (
        <>
          <button
            type="button"
            onClick={() => setUseAutocomplete(true)}
            className="text-xs text-muted-foreground hover:text-foreground underline mb-2"
          >
            Use address search instead
          </button>
        </>
      )}

      <div className="grid gap-4">
        <div className="space-y-2">
          <Label htmlFor={`${label}-street`}>
            Street Address {required && <span className="text-destructive">*</span>}
          </Label>
          <Input
            id={`${label}-street`}
            placeholder="123 Main St"
            value={value.street_number || ''}
            onChange={(e) => handleManualChange('street_number', e.target.value)}
            required={required}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor={`${label}-apt`}>Apt/Suite (Optional)</Label>
          <Input
            id={`${label}-apt`}
            placeholder="Apt 4B"
            value={value.apt_suite || ''}
            onChange={(e) => handleManualChange('apt_suite', e.target.value)}
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor={`${label}-city`}>
              City {required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={`${label}-city`}
              placeholder="New York"
              value={value.city || ''}
              onChange={(e) => handleManualChange('city', e.target.value)}
              required={required}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor={`${label}-state`}>
              State {required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={`${label}-state`}
              placeholder="NY"
              maxLength={2}
              value={value.state || ''}
              onChange={(e) => handleManualChange('state', e.target.value.toUpperCase())}
              required={required}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor={`${label}-zip`}>
            ZIP Code {required && <span className="text-destructive">*</span>}
          </Label>
          <Input
            id={`${label}-zip`}
            placeholder="10001"
            maxLength={10}
            value={value.zip || ''}
            onChange={(e) => handleManualChange('zip', e.target.value)}
            required={required}
          />
        </div>
      </div>

      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}
