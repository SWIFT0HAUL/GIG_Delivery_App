import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { FileUpload } from './FileUpload';
import { W9FormDialog } from './W9FormDialog';
import { AddressField } from './AddressField';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';

interface FormFieldProps {
  field: any;
  value: any;
  onChange: (value: any) => void;
  error?: string;
  formData?: any;
}

const US_STATES = [
  'AL', 'AK', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'FL', 'GA', 'HI',
  'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MD', 'MA', 'MI',
  'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC',
  'ND', 'OH', 'OK', 'OR', 'PA', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT',
  'VT', 'VA', 'WA', 'WV', 'WI', 'WY'
];

export function FormField({ field, value, onChange, error, formData }: FormFieldProps) {
  const fieldType = Object.keys(field)[0];
  const fieldConfig = field[fieldType];
  const [showW9Dialog, setShowW9Dialog] = useState(false);

  const renderField = () => {
    switch (fieldType) {
      case 'custom_button':
        return (
          <>
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
              </Label>
              <div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowW9Dialog(true)}
                  className="w-full gap-2"
                >
                  <FileText className="w-4 h-4" />
                  {fieldConfig.label}
                </Button>
              </div>
            </div>
            <W9FormDialog open={showW9Dialog} onOpenChange={setShowW9Dialog} />
          </>
        );
      
      case 'cascading_dropdown':
        const parentValue = formData?.[fieldConfig.parent.toLowerCase().replace(/\s+/g, '_').replace(/[^\w]/g, '')];
        const cascadingOptions = parentValue && fieldConfig.options[parentValue] 
          ? fieldConfig.options[parentValue]
          : [];
        
        return (
          <div className="space-y-2">
            <Label className="text-sm font-medium">
              {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
            </Label>
            <Select 
              value={value || ''} 
              onValueChange={onChange}
              disabled={!parentValue || cascadingOptions.length === 0}
            >
              <SelectTrigger className={error ? 'border-destructive' : ''}>
                <SelectValue placeholder={parentValue ? `Select ${fieldConfig.label}` : `Select ${fieldConfig.parent} first`} />
              </SelectTrigger>
              <SelectContent>
                {cascadingOptions.map((option: string) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
        );
      
      case 'text':
        const formatPhoneNumber = (val: string) => {
          const cleaned = val.replace(/\D/g, '');
          const match = cleaned.match(/^(\d{0,3})(\d{0,3})(\d{0,4})$/);
          if (!match) return val;
          
          const parts = [match[1], match[2], match[3]].filter(Boolean);
          if (parts.length === 0) return '';
          if (parts.length === 1) return parts[0];
          if (parts.length === 2) return `(${parts[0]}) ${parts[1]}`;
          return `(${parts[0]}) ${parts[1]}-${parts[2]}`;
        };
        
        return (
          <div className="space-y-2">
            <Label htmlFor={fieldConfig.label} className="text-sm font-medium">
              {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={fieldConfig.label}
              type={fieldConfig.type === 'phone' ? 'tel' : (fieldConfig.type === 'string' ? 'text' : fieldConfig.type)}
              value={value || ''}
              onChange={(e) => {
                if (fieldConfig.type === 'phone') {
                  onChange(formatPhoneNumber(e.target.value));
                } else {
                  onChange(e.target.value);
                }
              }}
              className={error ? 'border-destructive' : ''}
              placeholder={fieldConfig.type === 'phone' ? '(555) 123-4567' : fieldConfig.label}
              maxLength={fieldConfig.type === 'phone' ? 14 : undefined}
              disabled={fieldConfig.auto_fill}
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
        );

      case 'number':
        return (
          <div className="space-y-2">
            <Label htmlFor={fieldConfig.label} className="text-sm font-medium">
              {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={fieldConfig.label}
              type="number"
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              className={error ? 'border-destructive' : ''}
              placeholder={fieldConfig.label}
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
        );

      case 'date':
        return (
          <div className="space-y-2">
            <Label htmlFor={fieldConfig.label} className="text-sm font-medium">
              {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
            </Label>
            <Input
              id={fieldConfig.label}
              type="date"
              value={value || ''}
              onChange={(e) => onChange(e.target.value)}
              className={error ? 'border-destructive' : ''}
            />
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
        );

      case 'dropdown':
        const options = fieldConfig.options === 'dropdown_us_states' ? US_STATES : fieldConfig.options;
        
        if (fieldConfig.multi_select) {
          return (
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
              </Label>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {options.map((option: string) => (
                  <div key={option} className="flex items-center space-x-2">
                    <Checkbox
                      id={option}
                      checked={Array.isArray(value) && value.includes(option)}
                      onCheckedChange={(checked) => {
                        const currentValue = Array.isArray(value) ? value : [];
                        if (checked) {
                          onChange([...currentValue, option]);
                        } else {
                          onChange(currentValue.filter((v: string) => v !== option));
                        }
                      }}
                    />
                    <Label htmlFor={option} className="text-sm font-normal flex-1 cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </div>
              {error && <p className="text-sm text-destructive">{error}</p>}
            </div>
          );
        }

        return (
          <div className="space-y-2">
            <Label className="text-sm font-medium">
              {fieldConfig.label} {!fieldConfig.optional && <span className="text-destructive">*</span>}
            </Label>
            <Select value={value || ''} onValueChange={onChange}>
              <SelectTrigger className={error ? 'border-destructive' : ''}>
                <SelectValue placeholder={`Select ${fieldConfig.label}`} />
              </SelectTrigger>
              <SelectContent>
                {options.map((option: string) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
        );

      case 'address':
        return (
          <AddressField
            label={fieldConfig.label}
            value={value}
            onChange={onChange}
            error={error}
            required={!fieldConfig.optional}
            collapsible={fieldConfig.collapsible}
          />
        );

      case 'upload':
        return (
          <FileUpload
            label={fieldConfig.label}
            fieldName={fieldConfig.label.toLowerCase().replace(/\s+/g, '_')}
            value={value}
            onChange={onChange}
            required={!fieldConfig.optional}
            options={fieldConfig.options}
            error={error}
          />
        );

      default:
        return null;
    }
  };

  return renderField();
}