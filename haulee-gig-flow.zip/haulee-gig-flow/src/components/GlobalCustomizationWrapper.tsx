import { useGlobalCustomization } from "@/hooks/useGlobalCustomization";

export const GlobalCustomizationWrapper = ({ children }: { children: React.ReactNode }) => {
  useGlobalCustomization();
  return <>{children}</>;
};
