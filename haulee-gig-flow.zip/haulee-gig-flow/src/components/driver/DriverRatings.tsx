import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, TrendingUp, MessageSquare, User } from 'lucide-react';

export function DriverRatings() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Ratings & Feedback</h2>
        <p className="text-muted-foreground">Your customer ratings and reviews</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              +0.2 this month
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
            <MessageSquare className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">127</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              +12 this week
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Repeat Customers</CardTitle>
            <User className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">23%</div>
            <div className="flex items-center text-xs text-green-600">
              <TrendingUp className="h-3 w-3 mr-1" />
              +5% this month
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Rating Breakdown</CardTitle>
          <CardDescription>Distribution of your ratings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">5 stars</span>
                <div className="w-32 h-2 bg-muted rounded-full">
                  <div className="w-24 h-2 bg-yellow-500 rounded-full"></div>
                </div>
              </div>
              <span className="text-sm font-medium">76 (60%)</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">4 stars</span>
                <div className="w-32 h-2 bg-muted rounded-full">
                  <div className="w-16 h-2 bg-yellow-500 rounded-full"></div>
                </div>
              </div>
              <span className="text-sm font-medium">38 (30%)</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">3 stars</span>
                <div className="w-32 h-2 bg-muted rounded-full">
                  <div className="w-4 h-2 bg-yellow-500 rounded-full"></div>
                </div>
              </div>
              <span className="text-sm font-medium">10 (8%)</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">2 stars</span>
                <div className="w-32 h-2 bg-muted rounded-full">
                  <div className="w-1 h-2 bg-yellow-500 rounded-full"></div>
                </div>
              </div>
              <span className="text-sm font-medium">2 (1.5%)</span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm">1 star</span>
                <div className="w-32 h-2 bg-muted rounded-full">
                  <div className="w-0.5 h-2 bg-yellow-500 rounded-full"></div>
                </div>
              </div>
              <span className="text-sm font-medium">1 (0.5%)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Reviews</CardTitle>
          <CardDescription>What customers are saying about you</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Sarah M.</span>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                    ))}
                  </div>
                </div>
                <span className="text-sm text-muted-foreground">2 hours ago</span>
              </div>
              <p className="text-sm">"Excellent service! Driver was very professional and delivered my package quickly and safely. Highly recommend!"</p>
              <Badge variant="secondary" className="mt-2">Verified Delivery</Badge>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Mike D.</span>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                    ))}
                  </div>
                </div>
                <span className="text-sm text-muted-foreground">1 day ago</span>
              </div>
              <p className="text-sm">"Great communication throughout the delivery. Package arrived in perfect condition and on time."</p>
              <Badge variant="secondary" className="mt-2">Verified Delivery</Badge>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Jennifer L.</span>
                  <div className="flex">
                    {[1, 2, 3, 4].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                    ))}
                    <Star className="h-4 w-4 text-gray-300" />
                  </div>
                </div>
                <span className="text-sm text-muted-foreground">3 days ago</span>
              </div>
              <p className="text-sm">"Good service overall. Delivery was a bit delayed but driver kept me updated. Package was handled with care."</p>
              <Badge variant="secondary" className="mt-2">Verified Delivery</Badge>
            </div>

            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-medium">Robert K.</span>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star key={star} className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                    ))}
                  </div>
                </div>
                <span className="text-sm text-muted-foreground">1 week ago</span>
              </div>
              <p className="text-sm">"Outstanding driver! Very courteous and went above and beyond to ensure safe delivery. Will request again!"</p>
              <Badge variant="secondary" className="mt-2">Verified Delivery</Badge>
            </div>
          </div>
          
          <div className="pt-4">
            <Button variant="outline" className="w-full">Load More Reviews</Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}