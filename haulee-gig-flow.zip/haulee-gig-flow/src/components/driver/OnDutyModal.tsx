import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Clock, MapPin, Navigation, X, CheckCircle, Phone, FileText, HelpCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { NavigationModal } from './NavigationModal';
import { SlideToConfirm } from './SlideToConfirm';
import { OnDutyPickupModal } from './OnDutyPickupModal';
import { OnDutyDeliveryModal } from './OnDutyDeliveryModal';
import { JobMapView } from './JobMapView';
import { LeafletRouteMap } from '@/components/maps/LeafletRouteMap';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';
import { JobNotesModal } from './JobNotesModal';
import { DriverSupportModal } from './DriverSupportModal';

interface OnDutyModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobId: string;
}

type JobStep = 'start' | 'pickup' | 'dropoff' | 'completed';

const getJobStep = (status: string): JobStep => {
  switch (status) {
    case 'assigned':
      return 'start';
    case 'in_progress':
      return 'pickup';
    case 'picked_up':
    case 'in_transit':
      return 'dropoff';
    case 'delivered':
      return 'completed';
    default:
      return 'start';
  }
};

const getStatusBadgeVariant = (status: string) => {
  switch (status) {
    case 'in_progress':
      return 'default';
    case 'picked_up':
    case 'in_transit':
      return 'secondary';
    case 'delivered':
      return 'outline';
    default:
      return 'outline';
  }
};

export const OnDutyModal: React.FC<OnDutyModalProps> = ({
  open,
  onOpenChange,
  jobId,
}) => {
  const [showCloseConfirm, setShowCloseConfirm] = useState(false);
  const [currentStep, setCurrentStep] = useState<JobStep>('start');
  const [showNavigationModal, setShowNavigationModal] = useState(false);
  const [navigationDestination, setNavigationDestination] = useState<{ address: string; lat?: number; lng?: number } | null>(null);
  const [showPickupModal, setShowPickupModal] = useState(false);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [arrivedAtPickup, setArrivedAtPickup] = useState(false);
  const [arrivedAtDropoff, setArrivedAtDropoff] = useState(false);
  const [notesModalOpen, setNotesModalOpen] = useState(false);
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  const [headingToDropoff, setHeadingToDropoff] = useState(false);

  // Get live driver location for map tracking
  const driverLocationState = useDriverLocation();
  const driverLocation = driverLocationState.coordinates;

  // Fetch job details
  const { data: job, isLoading } = useQuery({
    queryKey: ['on-duty-job', jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', jobId)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!jobId && open,
    refetchInterval: 5000
  });

  // Fetch job assignment to get pickup photo and assignment data
  const { data: jobAssignment } = useQuery({
    queryKey: ['job-assignment', jobId],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      
      const { data, error } = await supabase
        .from('job_assignments')
        .select('*')
        .eq('job_id', jobId)
        .eq('driver_id', user.id)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!jobId && open,
    refetchInterval: 5000
  });

  // Update job to in_progress when modal opens
  useEffect(() => {
    const updateJobStatus = async () => {
      if (open && job && job.status === 'assigned') {
        const { error } = await supabase
          .from('jobs')
          .update({ status: 'in_progress', started_at: new Date().toISOString() })
          .eq('id', jobId);
        
        if (error) {
          console.error('Error updating job status:', error);
          toast.error('Failed to update job status');
        } else {
          toast.success('Job started!');
          
          // If job is part of a route, update route status to in_progress
          if (job.route_id) {
            const { error: routeError } = await supabase
              .from('routes')
              .update({ 
                status: 'in_progress',
                updated_at: new Date().toISOString()
              })
              .eq('id', job.route_id)
              .neq('status', 'completed')
              .neq('status', 'cancelled');
            
            if (routeError) {
              console.error('Error updating route status:', routeError);
            }
          }
        }
      }
    };
    
    updateJobStatus();
  }, [open, job?.status, jobId]);

  // Update current step based on job status
  useEffect(() => {
    if (job) {
      setCurrentStep(getJobStep(job.status));
      
      // Reset arrival states when job status changes
      if (job.status === 'in_progress') {
        setArrivedAtPickup(false);
      } else if (job.status === 'picked_up') {
        setArrivedAtPickup(true);
        setArrivedAtDropoff(false);
        setHeadingToDropoff(false);
      } else if (job.status === 'in_transit') {
        setArrivedAtPickup(true);
        setArrivedAtDropoff(false);
        setHeadingToDropoff(true);
      }
      
      // Auto-close if job is pending or cancelled
      if (job.status === 'pending' || job.status === 'cancelled') {
        toast.info('Job is no longer active');
        onOpenChange(false);
      }
    }
  }, [job, onOpenChange]);

  const handleClose = () => {
    if (job?.status !== 'delivered') {
      setShowCloseConfirm(true);
    } else {
      onOpenChange(false);
    }
  };

  const handleNavigate = () => {
    if (!job) return;
    const location = currentStep === 'pickup' ? job.pickup_location : job.delivery_location;
    
    let address = '';
    let lat: number | undefined;
    let lng: number | undefined;
    
    if (typeof location === 'object' && location !== null) {
      address = (location as any).address || (location as any).formatted_address || '';
      lat = (location as any).lat;
      lng = (location as any).lng;
    } else if (typeof location === 'string') {
      address = location;
    }
    
    if (address) {
      setNavigationDestination({ address, lat, lng });
      setShowNavigationModal(true);
    }
  };

  const calculateDistance = () => {
    if (!job?.distance_miles) return 'N/A';
    return `${job.distance_miles} mi`;
  };

  const calculateETA = () => {
    if (!job) return 'N/A';
    return formatDuration(getJobDuration(job.estimated_duration, job.distance_miles));
  };

  const steps: { key: JobStep; label: string; icon: React.ReactNode }[] = [
    { key: 'start', label: 'Start', icon: <Clock className="h-4 w-4" /> },
    { key: 'pickup', label: 'Pickup', icon: <MapPin className="h-4 w-4" /> },
    { key: 'dropoff', label: 'Drop-off', icon: <Navigation className="h-4 w-4" /> },
    { key: 'completed', label: 'Completed', icon: <CheckCircle className="h-4 w-4" /> },
  ];

  return (
    <>
      <Dialog open={open} onOpenChange={() => handleClose()}>
        <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
          {/* Sub-Header */}
          <div className="sticky top-0 z-10 bg-background border-b px-4 py-3 flex-shrink-0">
            <div className="flex items-center justify-between gap-3">
              <div className="flex-1 min-w-0">
                <h1 className="font-semibold text-lg truncate">
                  {job?.title || 'Loading...'}
                </h1>
                <div className="flex items-center gap-2">
                  <p className="text-xs text-muted-foreground">
                    Job #{jobId.substring(0, 8)}
                  </p>
                  {job && (
                    <Badge variant={getStatusBadgeVariant(job.status)} className="text-xs">
                      {job.status === 'in_progress' ? 'In Progress' :
                       job.status === 'picked_up' ? 'Picked Up' :
                       job.status === 'in_transit' ? 'In Transit' :
                       job.status === 'delivered' ? 'Delivered' : 'Assigned'}
                    </Badge>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setNotesModalOpen(true)}
                  aria-label="View job notes"
                  disabled={!job}
                >
                  <FileText className="h-5 w-5 text-primary" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setSupportModalOpen(true)}
                  aria-label="Contact support"
                >
                  <HelpCircle className="h-5 w-5" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onOpenChange(false)}
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>
          </div>

          {/* Progress Timeline */}
          <div className="px-4 py-2 border-b bg-muted/30">
            <div className="flex items-center justify-between max-w-2xl mx-auto">
              {steps.map((step, index) => {
                const stepIndex = steps.findIndex(s => s.key === step.key);
                const currentIndex = steps.findIndex(s => s.key === currentStep);
                const isActive = stepIndex <= currentIndex;
                const isCurrent = step.key === currentStep;

                return (
                  <React.Fragment key={step.key}>
                    <div className="flex flex-col items-center gap-1">
                      <div
                        className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
                          isActive
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted text-muted-foreground'
                        } ${isCurrent ? 'ring-2 ring-primary/20' : ''}`}
                      >
                        {React.cloneElement(step.icon as React.ReactElement, { className: 'h-3.5 w-3.5' })}
                      </div>
                      <span className={`text-[10px] font-medium ${isActive ? 'text-foreground' : 'text-muted-foreground'}`}>
                        {step.label}
                      </span>
                    </div>
                    {index < steps.length - 1 && (
                      <div className="flex-1 h-0.5 mx-2 mb-5">
                        <div
                          className={`h-full transition-colors ${
                            stepIndex < currentIndex ? 'bg-primary' : 'bg-muted'
                          }`}
                        />
                      </div>
                    )}
                  </React.Fragment>
                );
              })}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
            {isLoading ? (
              <div className="flex items-center justify-center p-8">
                <p className="text-muted-foreground">Loading job details...</p>
              </div>
            ) : job?.status === 'on_hold' ? (
              <div className="flex items-center justify-center p-8">
                <Card className="p-6 max-w-md">
                  <div className="text-center space-y-3">
                    <Badge variant="secondary" className="text-sm">On Hold</Badge>
                    <h3 className="font-semibold text-lg">Job Currently On Hold</h3>
                    <p className="text-sm text-muted-foreground">
                      This job has been placed on hold. All actions are disabled until the job is reactivated.
                    </p>
                  </div>
                </Card>
              </div>
            ) : (
              <>
                {/* Live Map Section */}
                <Card className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-primary" />
                      Route Overview
                    </h3>
                    <button
                      onClick={handleNavigate}
                      className="p-2 bg-primary text-primary-foreground rounded-full shadow-lg hover:bg-primary/90 transition-colors"
                      aria-label="Open in Maps"
                    >
                      <Navigation className="h-4 w-4" />
                    </button>
                  </div>
                  
                  {/* Actual Map with Live Tracking */}
                  {job?.pickup_location && job?.delivery_location && (
                    <LeafletRouteMap
                      pickup={{
                        lat: (job.pickup_location as any)?.lat || 0,
                        lng: (job.pickup_location as any)?.lng || 0,
                        label: typeof job.pickup_location === 'string' 
                          ? job.pickup_location 
                          : (job.pickup_location as any)?.address || 'Pickup'
                      }}
                      dropoff={{
                        lat: (job.delivery_location as any)?.lat || 0,
                        lng: (job.delivery_location as any)?.lng || 0,
                        label: typeof job.delivery_location === 'string'
                          ? job.delivery_location
                          : (job.delivery_location as any)?.address || 'Dropoff'
                      }}
                      driverLocation={driverLocation ? {
                        lat: driverLocation.lat,
                        lng: driverLocation.lng,
                        label: 'Your Location'
                      } : undefined}
                      className="w-full h-64 sm:h-96 rounded-lg"
                    />
                  )}

                  {/* Slide to Mark Arrival */}
                  {job?.status === 'in_progress' && !arrivedAtPickup && (
                    <SlideToConfirm
                      onConfirm={() => {
                        setArrivedAtPickup(true);
                        toast.success('Arrival confirmed! You can now confirm pickup.');
                      }}
                      text="Slide to mark arrival to pickup"
                      className="w-full"
                    />
                  )}

                  {/* Confirm Pickup Button - Enabled only after arrival */}
                  {job?.status === 'in_progress' && (
                    <Button
                      variant="default"
                      size="lg"
                      onClick={() => setShowPickupModal(true)}
                      disabled={!arrivedAtPickup}
                      className="w-full shadow-lg"
                    >
                      <CheckCircle className="h-5 w-5 mr-2" />
                      Confirm Pickup
                    </Button>
                  )}

                  {/* Head to Drop-off Button - Shows after pickup completion */}
                  {(job?.status === 'picked_up' || job?.status === 'in_transit') && !arrivedAtDropoff && !headingToDropoff && (
                    <Button
                      variant="default"
                      size="lg"
                      onClick={async () => {
                        // Update job status to in_transit
                        const { error } = await supabase
                          .from('jobs')
                          .update({ status: 'in_transit' })
                          .eq('id', jobId);
                        
                        if (error) {
                          console.error('Error updating job status:', error);
                          toast.error('Failed to update job status');
                        } else {
                          toast.success('Status updated to in transit');
                          setHeadingToDropoff(true);
                        }
                      }}
                      className="w-1/2 mx-auto shadow-lg"
                    >
                      Head to Drop-off
                    </Button>
                  )}

                  {/* Slide to Mark Arrival at Dropoff */}
                  {(job?.status === 'picked_up' || job?.status === 'in_transit') && !arrivedAtDropoff && headingToDropoff && (
                    <SlideToConfirm
                      onConfirm={() => {
                        setArrivedAtDropoff(true);
                        setShowDeliveryModal(true);
                      }}
                      text="Slide to mark arrival to drop-off"
                      className="w-full"
                    />
                  )}
                </Card>

                {/* Current Location Info */}
                <Card className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold">
                      {currentStep === 'start' || currentStep === 'pickup' ? '📦 Pickup Location' : '📍 Delivery Location'}
                    </h3>
                    <button
                      onClick={() => toast.info('Contact feature coming soon')}
                      className="p-2 rounded-full hover:bg-muted/50 transition-colors"
                      aria-label="Contact"
                    >
                      <Phone className="h-5 w-5 text-primary" />
                    </button>
                  </div>
                  <div className="space-y-3">
                    {currentStep === 'start' || currentStep === 'pickup' ? (
                      <>
                        {/* Full Address */}
                        <div className="p-3 bg-muted/50 rounded-lg">
                          <p className="text-sm font-medium leading-relaxed">
                            {typeof job?.pickup_location === 'string' ? (
                              job.pickup_location.replace(/, USA$/i, '').replace(/, United States$/i, '')
                            ) : typeof job?.pickup_location === 'object' && job.pickup_location !== null ? (
                              ((job.pickup_location as any)?.formatted_address || 
                              (job.pickup_location as any)?.address ||
                              'Address not available').replace(/, USA$/i, '').replace(/, United States$/i, '')
                            ) : (
                              'Address not available'
                            )}
                          </p>
                        </div>
                      </>
                    ) : (
                      <>
                        {/* Full Address */}
                        <div className="p-3 bg-muted/50 rounded-lg">
                          <p className="text-sm font-medium leading-relaxed">
                            {typeof job?.delivery_location === 'string' ? (
                              job.delivery_location.replace(/, USA$/i, '').replace(/, United States$/i, '')
                            ) : typeof job?.delivery_location === 'object' && job.delivery_location !== null ? (
                              ((job.delivery_location as any)?.formatted_address || 
                              (job.delivery_location as any)?.address ||
                              'Address not available').replace(/, USA$/i, '').replace(/, United States$/i, '')
                            ) : (
                              'Address not available'
                            )}
                          </p>
                        </div>
                      </>
                    )}
                  </div>
                </Card>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Close Confirmation Dialog */}
      <AlertDialog open={showCloseConfirm} onOpenChange={setShowCloseConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Close Active Job?</AlertDialogTitle>
            <AlertDialogDescription>
              You have an active job in progress. Are you sure you want to close this view?
              Your job will remain active in the background.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              setShowCloseConfirm(false);
              onOpenChange(false);
            }}>
              Close View
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Navigation Modal */}
      {navigationDestination && (
        <NavigationModal
          open={showNavigationModal}
          onOpenChange={setShowNavigationModal}
          destination={navigationDestination}
        />
      )}

      {/* Pickup Modal */}
      <OnDutyPickupModal
        open={showPickupModal}
        onOpenChange={setShowPickupModal}
        jobId={jobId}
        assignmentId={jobAssignment?.id || ''}
        assignment={jobAssignment || {}}
        job={job || {}}
        pickupLocation={job?.pickup_location}
        areaType="urban"
        onPickupComplete={() => {
          setCurrentStep('pickup');
          toast.success('Pickup completed successfully!');
        }}
      />

      {/* Delivery Modal */}
      <OnDutyDeliveryModal
        open={showDeliveryModal}
        onClose={() => setShowDeliveryModal(false)}
        onDeliveryComplete={async (deliveryData) => {
          console.log('🚚 Delivery completion triggered with data:', deliveryData);
          
          try {
            let photoUrl: string | undefined;
            let signatureUrl: string | undefined;

            // Upload photo if provided
            if (deliveryData.photoBlob) {
              const photoFileName = `${jobId}_delivery_${Date.now()}.jpg`;
              const { error: photoUploadError } = await supabase.storage
                .from('delivery_photos')
                .upload(photoFileName, deliveryData.photoBlob, {
                  contentType: 'image/jpeg',
                  upsert: false
                });

              if (photoUploadError) throw photoUploadError;

              const { data: { publicUrl } } = supabase.storage
                .from('delivery_photos')
                .getPublicUrl(photoFileName);
              
              photoUrl = publicUrl;
            }

            // Upload signature if provided
            if (deliveryData.signature) {
              const signatureBlob = await (await fetch(deliveryData.signature)).blob();
              const signatureFileName = `${jobId}_signature_${Date.now()}.png`;
              const { error: signatureUploadError } = await supabase.storage
                .from('signatures')
                .upload(signatureFileName, signatureBlob, {
                  contentType: 'image/png',
                  upsert: false
                });

              if (signatureUploadError) throw signatureUploadError;

              const { data: { publicUrl } } = supabase.storage
                .from('signatures')
                .getPublicUrl(signatureFileName);
              
              signatureUrl = publicUrl;
            }

            // First, update the driver's assignment to delivered
            const { data: authData } = await supabase.auth.getUser();
            const currentUser = authData?.user;
            if (!currentUser) throw new Error('Not authenticated');

            const { error: assignErr } = await supabase
              .from('job_assignments')
              .update({ status: 'delivered', completed_at: new Date().toISOString() })
              .eq('job_id', jobId)
              .eq('driver_id', currentUser.id);
            if (assignErr) {
              console.error('❌ Error updating assignment:', assignErr);
              throw new Error('Failed to update job status');
            }

            // Then, update job status to delivered
            const dropoffParts = deliveryData.dropoffLocation?.split(' - ') || [];
            const dropoffLocationType = dropoffParts[0] || '';
            const specificDeliveryArea = dropoffParts[1] || '';

            const updateData: any = { 
              status: 'delivered',
              actual_delivery_time: new Date().toISOString(),
              completed_at: new Date().toISOString(),
              updated_at: new Date().toISOString(),
              metadata: {
                signature_url: signatureUrl || null,
                recipient_name: deliveryData.recipientName || null,
                dropoff_location_type: dropoffLocationType,
                specific_delivery_area: specificDeliveryArea,
                actual_dropoff_location: deliveryData.dropoffLocation || null,
              }
            };

            if (photoUrl) updateData.proof_of_delivery_url = photoUrl;

            const { error } = await supabase
              .from('jobs')
              .update(updateData)
              .eq('id', jobId)
              .eq('assigned_driver_id', currentUser.id);
            
            if (error) {
              console.error('❌ Error updating job status:', error);
              throw new Error('Failed to update job status');
            }
            
            console.log('✅ Job status updated to delivered');
            setShowDeliveryModal(false);
            setCurrentStep('completed');
            toast.success('Delivery completed successfully!');
            onOpenChange(false);
          } catch (error: any) {
            console.error('❌ Delivery completion error:', error);
            toast.error(error.message || 'Failed to update job status');
          }
        }}
        signatureRequired={job?.signature_required || false}
        pickupPhotoUrl={jobAssignment?.pickup_photo_url}
        job={job}
      />

      {/* Job Notes Modal */}
      {job && (
        <JobNotesModal 
          open={notesModalOpen} 
          onOpenChange={setNotesModalOpen} 
          job={job} 
        />
      )}

      {/* Driver Support Modal */}
      <DriverSupportModal 
        open={supportModalOpen} 
        onClose={() => setSupportModalOpen(false)}
        jobId={job?.id}
        assignmentId={jobAssignment?.id}
        context="general"
      />
    </>
  );
};
