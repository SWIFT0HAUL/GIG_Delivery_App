import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface DriverSupportModalProps {
  open: boolean;
  onClose: () => void;
  jobId?: string;
  assignmentId?: string;
  context: 'pickup' | 'delivery' | 'general';
}

const issueTypes = {
  pickup: [
    { value: 'address_not_found', label: 'Cannot find pickup address' },
    { value: 'items_not_ready', label: 'Items not ready for pickup' },
    { value: 'items_not_available', label: 'Items not available' },
    { value: 'access_issue', label: 'Cannot access building/location' },
    { value: 'wrong_address', label: 'Wrong address provided' },
    { value: 'contact_unavailable', label: 'Cannot contact sender' },
    { value: 'other', label: 'Other pickup issue' },
  ],
  delivery: [
    { value: 'address_not_found', label: 'Cannot find delivery address' },
    { value: 'recipient_unavailable', label: 'Recipient not available' },
    { value: 'access_issue', label: 'Cannot access building/location' },
    { value: 'wrong_address', label: 'Wrong address provided' },
    { value: 'unsafe_location', label: 'Unsafe to leave package' },
    { value: 'contact_unavailable', label: 'Cannot contact recipient' },
    { value: 'delivery_refused', label: 'Delivery refused' },
    { value: 'other', label: 'Other delivery issue' },
  ],
  general: [
    { value: 'vehicle_issue', label: 'Vehicle issue' },
    { value: 'safety_concern', label: 'Safety concern' },
    { value: 'app_issue', label: 'App technical issue' },
    { value: 'route_issue', label: 'Route navigation problem' },
    { value: 'other', label: 'Other issue' },
  ],
};

export function DriverSupportModal({ open, onClose, jobId, assignmentId, context }: DriverSupportModalProps) {
  const [issueType, setIssueType] = useState<string>('');
  const [details, setDetails] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!issueType) {
      toast.error('Please select an issue type');
      return;
    }

    if (!details.trim()) {
      toast.error('Please provide issue details');
      return;
    }

    setSubmitting(true);
    try {
      // Insert support ticket into database
      const { error } = await supabase.from('driver_support_tickets').insert({
        job_id: jobId,
        assignment_id: assignmentId,
        issue_type: issueType,
        issue_context: context,
        details: details.trim(),
        status: 'open',
      });

      if (error) throw error;

      toast.success('Support request submitted successfully');
      handleClose();
    } catch (error) {
      console.error('Error submitting support request:', error);
      toast.error('Failed to submit support request');
    } finally {
      setSubmitting(false);
    }
  };

  const handleClose = () => {
    setIssueType('');
    setDetails('');
    onClose();
  };

  const currentIssueTypes = issueTypes[context];

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
        <DialogHeader className="flex-shrink-0 px-4 py-4 border-b">
          <DialogTitle>Report an Issue</DialogTitle>
          <DialogDescription>
            Describe the issue you're experiencing so our support team can assist you.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-6 px-4 overflow-y-auto flex-1 max-w-2xl mx-auto w-full">
          <div className="space-y-3">
            <Label>Issue Type</Label>
            <RadioGroup value={issueType} onValueChange={setIssueType}>
              {currentIssueTypes.map((issue) => (
                <div key={issue.value} className="flex items-center space-x-2">
                  <RadioGroupItem value={issue.value} id={issue.value} />
                  <Label htmlFor={issue.value} className="font-normal cursor-pointer">
                    {issue.label}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          <div className="space-y-2">
            <Label htmlFor="details">Additional Details</Label>
            <Textarea
              id="details"
              placeholder="Please provide more details about the issue..."
              value={details}
              onChange={(e) => setDetails(e.target.value)}
              rows={4}
              className="resize-none"
            />
          </div>
        </div>

        <div className="flex gap-2 justify-end px-4 py-4 border-t flex-shrink-0 max-w-2xl mx-auto w-full">
          <Button variant="outline" onClick={handleClose} disabled={submitting}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={submitting}>
            {submitting ? 'Submitting...' : 'Submit Request'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
