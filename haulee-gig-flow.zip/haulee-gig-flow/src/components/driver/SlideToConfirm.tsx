import React, { useState, useRef, useEffect } from 'react';
import { ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SlideToConfirmProps {
  onConfirm: () => void;
  text?: string;
  confirmedText?: string;
  icon?: React.ReactNode;
  disabled?: boolean;
  className?: string;
}

export function SlideToConfirm({
  onConfirm,
  text = "Slide to confirm",
  confirmedText = "Confirmed!",
  icon,
  disabled = false,
  className
}: SlideToConfirmProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [position, setPosition] = useState(0);
  const [isConfirmed, setIsConfirmed] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);

  const handleStart = (clientX: number) => {
    if (disabled || isConfirmed) return;
    setIsDragging(true);
  };

  const handleMove = (clientX: number) => {
    if (!isDragging || !containerRef.current || !sliderRef.current || disabled) return;

    const container = containerRef.current;
    const slider = sliderRef.current;
    const containerRect = container.getBoundingClientRect();
    const sliderWidth = slider.offsetWidth;
    const maxPosition = containerRect.width - sliderWidth;

    let newPosition = clientX - containerRect.left - sliderWidth / 2;
    newPosition = Math.max(0, Math.min(newPosition, maxPosition));

    setPosition(newPosition);

    // Check if slider reached the end (within 10px threshold)
    if (newPosition >= maxPosition - 10) {
      setIsConfirmed(true);
      setIsDragging(false);
      onConfirm();
    }
  };

  const handleEnd = () => {
    if (!isConfirmed) {
      setPosition(0);
    }
    setIsDragging(false);
  };

  // Mouse events
  const handleMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    handleStart(e.clientX);
  };

  const handleMouseMove = (e: MouseEvent) => {
    handleMove(e.clientX);
  };

  const handleMouseUp = () => {
    handleEnd();
  };

  // Touch events
  const handleTouchStart = (e: React.TouchEvent) => {
    handleStart(e.touches[0].clientX);
  };

  const handleTouchMove = (e: TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  const handleTouchEnd = () => {
    handleEnd();
  };

  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      document.addEventListener('touchmove', handleTouchMove);
      document.addEventListener('touchend', handleTouchEnd);

      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
        document.removeEventListener('touchmove', handleTouchMove);
        document.removeEventListener('touchend', handleTouchEnd);
      };
    }
  }, [isDragging]);

  return (
    <div
      ref={containerRef}
      className={cn(
        "relative h-14 rounded-2xl overflow-hidden select-none shadow-sm",
        "bg-gradient-to-r from-muted/80 to-muted/60 backdrop-blur-sm",
        "border border-border/50",
        disabled && "opacity-50 cursor-not-allowed",
        isConfirmed && "bg-gradient-to-r from-primary/20 to-primary/30 border-primary/50",
        className
      )}
    >
      {/* Progress indicator */}
      {!isConfirmed && (
        <div
          className="absolute inset-0 bg-gradient-to-r from-primary/15 via-primary/10 to-transparent transition-all duration-100"
          style={{
            width: `${(position / (containerRef.current?.offsetWidth || 1)) * 100}%`
          }}
        />
      )}

      {/* Background text */}
      <div className="absolute inset-0 flex items-center justify-end pointer-events-none pr-6">
        <span className={cn(
          "text-sm font-semibold tracking-wide transition-all duration-300",
          isConfirmed ? "text-primary scale-105" : "text-muted-foreground",
          isDragging && "opacity-50"
        )}>
          {isConfirmed ? confirmedText : text}
        </span>
      </div>

      {/* Slider button */}
      <div
        ref={sliderRef}
        className={cn(
          "absolute rounded-xl",
          "bg-gradient-to-br from-primary to-primary/80",
          "shadow-lg shadow-primary/20",
          "flex items-center justify-center",
          "cursor-grab active:cursor-grabbing",
          "transition-all duration-200",
          isDragging && "scale-110 shadow-xl shadow-primary/40",
          isConfirmed && "bg-gradient-to-br from-primary to-primary scale-100 shadow-primary/50",
          disabled && "cursor-not-allowed"
        )}
        style={{
          top: '6px',
          left: '6px',
          width: '60px',
          height: '44px',
          transform: `translateX(${position}px)`,
          transition: isDragging || isConfirmed ? 'none' : 'transform 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
        }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
      >
        {isConfirmed ? (
          <span className="text-primary-foreground font-bold text-xl animate-scale-in">✓</span>
        ) : (
          <div className="relative">
            {icon || <ChevronRight className="h-6 w-6 text-primary-foreground" />}
            {!isDragging && (
              <ChevronRight className="h-6 w-6 text-primary-foreground absolute -left-3 opacity-30 animate-pulse" />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
