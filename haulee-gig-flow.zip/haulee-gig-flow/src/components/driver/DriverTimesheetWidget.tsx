import { UniversalTimesheetCard } from '@/components/timesheet/UniversalTimesheetCard';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const DriverTimesheetWidget = () => {
  const { user } = useAuth();

  // Get active job for driver
  const { data: activeJob } = useQuery({
    queryKey: ['driver-active-job', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('assigned_driver_id', user.id)
        .in('status', ['assigned', 'in_progress', 'picked_up'])
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  // Map job status to timesheet stage
  const getJobStage = () => {
    if (!activeJob) return undefined;
    
    const stageMap: Record<string, string> = {
      'assigned': 'assigned',
      'in_progress': 'start',
      'picked_up': 'pickup',
    };
    
    return stageMap[activeJob.status] || 'assigned';
  };

  return (
    <UniversalTimesheetCard 
      jobId={activeJob?.id}
      jobStage={getJobStage()}
    />
  );
};