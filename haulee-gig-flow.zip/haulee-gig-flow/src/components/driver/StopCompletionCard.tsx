import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { MapPin, CheckCircle2, Camera, FileSignature, FileText, ChevronDown } from 'lucide-react';
import { format } from 'date-fns';
import { JobNotesModal } from './JobNotesModal';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

interface Stop {
  id: string;
  stop_type: 'pickup' | 'delivery';
  stop_sequence: number;
  location: any;
  scheduled_time: string | null;
  status: 'pending' | 'completed' | 'skipped' | 'in_progress';
  completed_at: string | null;
  job_id: string;
}

interface StopCompletionCardProps {
  stop: Stop;
  jobTitle: string;
  jobData: any;
  onCompleteStop: (stopId: string, stopType: 'pickup' | 'delivery') => void;
  isProcessing: boolean;
}

export const StopCompletionCard: React.FC<StopCompletionCardProps> = ({
  stop,
  jobTitle,
  jobData,
  onCompleteStop,
  isProcessing
}) => {
  const [showNotesModal, setShowNotesModal] = useState(false);
  const isPickup = stop.stop_type === 'pickup';
  const isCompleted = stop.status === 'completed';
  
  const getStopIcon = () => {
    if (isCompleted) return <CheckCircle2 className="h-5 w-5 text-green-500" />;
    if (isPickup) return <Camera className="h-5 w-5 text-blue-500" />;
    return <FileSignature className="h-5 w-5 text-purple-500" />;
  };

  const getStopBadge = () => {
    if (isCompleted) return <Badge variant="default" className="bg-green-600">Completed</Badge>;
    if (stop.status === 'in_progress') return <Badge variant="default" className="bg-blue-600">In Progress</Badge>;
    return <Badge variant="outline">Pending</Badge>;
  };

  return (
    <Collapsible defaultOpen={!isCompleted}>
      <Card className="p-3 sm:p-4 mb-3 w-full max-w-full">
        <CollapsibleTrigger className="w-full">
          <div className="flex items-start justify-between gap-2 w-full">
            <div className="flex items-start space-x-2 sm:space-x-3 flex-1 min-w-0">
              <div className="mt-0.5 sm:mt-1 flex-shrink-0">
                {getStopIcon()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-1 sm:space-x-2 mb-1 flex-wrap gap-1">
                  <span className="font-semibold text-xs sm:text-sm truncate">
                    Stop {stop.stop_sequence}: {isPickup ? 'Pickup' : 'Delivery'}
                  </span>
                  {getStopBadge()}
                </div>
                <p className="text-xs sm:text-sm text-muted-foreground mb-1 text-left truncate">{jobTitle}</p>
              </div>
            </div>
            <ChevronDown className="h-4 w-4 transition-transform duration-200 [[data-state=open]_&]:rotate-180 flex-shrink-0" />
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <div className="mt-2 sm:mt-3 space-y-2">
            <div className="flex items-start space-x-2 text-xs sm:text-sm text-muted-foreground">
              <MapPin className="h-3 w-3 sm:h-4 sm:w-4 mt-0.5 flex-shrink-0" />
              <span className="break-words">{stop.location?.address || 'Location not available'}</span>
            </div>
            {stop.scheduled_time && (
              <p className="text-[10px] sm:text-xs text-muted-foreground">
                Scheduled: {format(new Date(stop.scheduled_time), 'MMM d, h:mm a')}
              </p>
            )}
            {isCompleted && stop.completed_at && (
              <p className="text-[10px] sm:text-xs text-green-600">
                Completed: {format(new Date(stop.completed_at), 'MMM d, h:mm a')}
              </p>
            )}
            <div className="flex items-center gap-2 pt-2">
              <Button
                size="sm"
                variant="outline"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowNotesModal(true);
                }}
                className="h-8 w-8 sm:h-9 sm:w-auto px-0 sm:px-3"
              >
                <FileText className="h-3 w-3 sm:h-4 sm:w-4" />
              </Button>
              {!isCompleted && (
                <Button
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onCompleteStop(stop.id, stop.stop_type);
                  }}
                  disabled={isProcessing}
                  className="h-8 sm:h-9 text-xs sm:text-sm"
                >
                  {isPickup ? 'Pick Up' : 'Deliver'}
                </Button>
              )}
            </div>
          </div>
        </CollapsibleContent>
      </Card>

      <JobNotesModal
        open={showNotesModal}
        onOpenChange={setShowNotesModal}
        job={jobData}
      />
    </Collapsible>
  );
};
