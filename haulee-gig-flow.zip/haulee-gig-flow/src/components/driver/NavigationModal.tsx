import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Navigation } from 'lucide-react';
import { MapViewModal } from './MapViewModal';

interface NavigationModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  destination: {
    lat?: number;
    lng?: number;
    address: string;
  };
}

export const NavigationModal: React.FC<NavigationModalProps> = ({
  open,
  onOpenChange,
  destination,
}) => {
  const [mapViewOpen, setMapViewOpen] = useState(false);
  const [selectedMapUrl, setSelectedMapUrl] = useState('');

  const openNavigation = (app: 'google' | 'apple' | 'waze') => {
    const { lat, lng, address } = destination;
    let url = '';

    // Use coordinates if available, otherwise use address
    const destination_param = lat && lng ? `${lat},${lng}` : encodeURIComponent(address);

    switch (app) {
      case 'google':
        url = lat && lng 
          ? `https://www.google.com/maps/dir/?api=1&destination=${destination_param}`
          : `https://www.google.com/maps/search/?api=1&query=${destination_param}`;
        break;
      case 'apple':
        url = lat && lng
          ? `http://maps.apple.com/?daddr=${destination_param}`
          : `http://maps.apple.com/?q=${destination_param}`;
        break;
      case 'waze':
        url = lat && lng
          ? `https://waze.com/ul?ll=${destination_param}&navigate=yes`
          : `https://waze.com/ul?q=${destination_param}&navigate=yes`;
        break;
    }

    setSelectedMapUrl(url);
    setMapViewOpen(true);
    onOpenChange(false);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="w-[160px] h-[160px] p-3 fixed right-4 top-1/2 -translate-y-1/2 left-auto data-[state=open]:slide-in-from-right-2 bg-background">
          <DialogHeader className="pb-2 space-y-0">
            <DialogTitle className="flex items-center gap-1.5 text-xs font-semibold">
              <Navigation className="h-3 w-3" />
              Navigate
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-2 flex flex-col">
            <Button
              onClick={() => openNavigation('google')}
              className="w-full h-7 text-[10px] px-2 whitespace-nowrap"
              variant="outline"
              size="sm"
            >
              Google Maps
            </Button>

            <Button
              onClick={() => openNavigation('apple')}
              className="w-full h-7 text-[10px] px-2 whitespace-nowrap"
              variant="outline"
              size="sm"
            >
              Apple Maps
            </Button>

            <Button
              onClick={() => openNavigation('waze')}
              className="w-full h-7 text-[10px] px-2"
              variant="outline"
              size="sm"
            >
              Waze
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <MapViewModal
        open={mapViewOpen}
        onOpenChange={setMapViewOpen}
        mapUrl={selectedMapUrl}
        nested={true}
      />
    </>
  );
};
