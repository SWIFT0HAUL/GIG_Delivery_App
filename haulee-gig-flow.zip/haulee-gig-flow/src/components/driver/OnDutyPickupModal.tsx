import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { CardContent } from '@/components/ui/card';
import { X, Camera, Package, CheckCircle2, MapPin, Phone, FileText, HelpCircle, DollarSign, Clock, Navigation, User, Truck, Info } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { Camera as CapacitorCamera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Capacitor } from '@capacitor/core';
import { SlideToConfirm } from './SlideToConfirm';
import { format } from 'date-fns';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';
import { JobNotesModal } from './JobNotesModal';
import { DriverSupportModal } from './DriverSupportModal';

interface OnDutyPickupModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobId: string;
  assignmentId: string;
  assignment: any;
  job: any;
  pickupLocation: any;
  areaType: string;
  onPickupComplete: () => void;
}

export const OnDutyPickupModal: React.FC<OnDutyPickupModalProps> = ({
  open,
  onOpenChange,
  jobId,
  assignmentId,
  assignment,
  job,
  pickupLocation,
  areaType,
  onPickupComplete,
}) => {
  const queryClient = useQueryClient();
  const [photoTaken, setPhotoTaken] = useState(false);
  const [photoAccepted, setPhotoAccepted] = useState(false);
  const [itemsVerified, setItemsVerified] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [photoBlob, setPhotoBlob] = useState<Blob | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameraOpen, setCameraOpen] = useState(false);
  const [notesModalOpen, setNotesModalOpen] = useState(false);
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const canvasRef = React.useRef<HTMLCanvasElement>(null);

  // Start camera - use Capacitor Camera on native, fallback to web API
  const startCamera = async () => {
    try {
      console.log('📸 Starting camera...');
      // Check if running on native platform
      if (Capacitor.isNativePlatform()) {
        console.log('📱 Using Capacitor native camera');
        // Use Capacitor Camera for native apps
        const image = await CapacitorCamera.getPhoto({
          quality: 90,
          allowEditing: false,
          resultType: CameraResultType.DataUrl,
          source: CameraSource.Camera
        });

        if (image.dataUrl) {
          setCapturedPhoto(image.dataUrl);
          setPhotoTaken(true);
          toast.success('Photo captured successfully');
        }
      } else {
        // Fallback to web camera for browser
        console.log('🌐 Using web camera');
        const mediaStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: 1280, height: 720 },
        });
        console.log('✅ MediaStream obtained:', mediaStream);
        setStream(mediaStream);
        setCameraOpen(true);
        
        // Wait for next tick to ensure video element is rendered
        setTimeout(() => {
          if (videoRef.current && mediaStream) {
            console.log('📹 Setting video srcObject');
            videoRef.current.srcObject = mediaStream;
            videoRef.current.play().catch(err => {
              console.error('Video play error:', err);
            });
          }
        }, 100);
      }
    } catch (error) {
      console.error('❌ Camera error:', error);
      toast.error('Failed to access camera. Please check permissions.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCameraOpen(false);
  };

  const capturePhoto = () => {
    console.log('📸 Capturing photo...');
    if (!videoRef.current || !canvasRef.current) {
      console.error('❌ Video or canvas ref missing');
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    console.log('📹 Video dimensions:', video.videoWidth, 'x', video.videoHeight);
    
    if (video.videoWidth === 0 || video.videoHeight === 0) {
      toast.error('Camera not ready, please wait a moment');
      return;
    }
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      console.error('❌ Canvas context not available');
      return;
    }

    ctx.drawImage(video, 0, 0);
    const photoDataUrl = canvas.toDataURL('image/jpeg', 0.8);
    console.log('✅ Photo captured, data URL length:', photoDataUrl.length);
    setCapturedPhoto(photoDataUrl);
    setPhotoTaken(true);
    stopCamera();
    toast.success('Photo captured successfully');
  };

  const retakePhoto = () => {
    setCapturedPhoto(null);
    setPhotoTaken(false);
    setPhotoAccepted(false);
    setPhotoBlob(null);
    startCamera();
  };

  const handleAcceptPhoto = () => {
    setPhotoAccepted(true);
    toast.success('Photo accepted');
  };

  const handleCompletePickup = async () => {
    if (!photoTaken || !photoAccepted || !itemsVerified) {
      toast.error('Please complete all required steps');
      return;
    }

    if (!capturedPhoto) {
      toast.error('Photo not found');
      return;
    }

    setIsUploading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Convert data URL to Blob
      const response = await fetch(capturedPhoto);
      const blob = await response.blob();

      // Upload photo to storage
      const fileName = `${jobId}_${Date.now()}.jpg`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('pickup-photos')
        .upload(fileName, blob, {
          contentType: 'image/jpeg',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('pickup-photos')
        .getPublicUrl(fileName);

      // Update job_assignments with photo URL and status
      const { error: assignmentError } = await supabase
        .from('job_assignments')
        .update({ 
          status: 'picked_up',
          pickup_photo_url: publicUrl,
          started_at: new Date().toISOString()
        })
        .eq('job_id', jobId)
        .eq('driver_id', user.id);

      if (assignmentError) throw assignmentError;

      // Also update jobs table status
      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'picked_up',
          started_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (jobError) throw jobError;

      // Invalidate queries to refresh UI
      await queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      await queryClient.invalidateQueries({ queryKey: ['on-duty-job', jobId] });
      
      toast.success('Pickup completed! Job is now in progress.');
      onPickupComplete();
      onOpenChange(false);
    } catch (error: any) {
      console.error('Pickup error:', error);
      toast.error(error.message || 'Failed to complete pickup');
    } finally {
      setIsUploading(false);
    }
  };

  const handleVerifyItems = () => {
    setItemsVerified(true);
    toast.success('Items verified');
  };

  // Cleanup camera on unmount or close
  React.useEffect(() => {
    if (!open) {
      stopCamera();
      setCapturedPhoto(null);
      setPhotoTaken(false);
      setPhotoAccepted(false);
      setItemsVerified(false);
    }
  }, [open]);

  const formatAddress = (location: any) => {
    if (typeof location === 'string') {
      return location.replace(/, USA$/i, '').replace(/, United States$/i, '');
    }
    if (typeof location === 'object' && location !== null) {
      return (location.formatted_address || location.address || 'Address not available')
        .replace(/, USA$/i, '')
        .replace(/, United States$/i, '');
    }
    return 'Address not available';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
        {/* SEO: Title and description for accessibility */}
        <header className="sticky top-0 z-10 bg-background border-b flex-shrink-0">
          {/* Header */}
          <div className="px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex-1 min-w-0">
              <h1 className="font-semibold text-lg">On Duty Pickup</h1>
              <p className="text-xs text-muted-foreground">Job #{jobId.substring(0, 8)}</p>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={assignment.status === 'assigned' ? 'outline' : 'default'} className="px-2 py-1 text-xs">
                {assignment.status === 'assigned' ? 'Not Started' : assignment.status === 'in_progress' ? 'In Progress' : 'Picked Up'}
              </Badge>
              <Button variant="ghost" size="icon" onClick={() => setNotesModalOpen(true)} aria-label="View job notes">
                <FileText className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setSupportModalOpen(true)} aria-label="Contact support">
                <HelpCircle className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} aria-label="Close On Duty Pickup modal">
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Timeline Progress */}
          <div className="px-4 py-2 bg-muted/30">
            <div className="flex items-center justify-between text-xs">
              <div className={`flex items-center gap-1 ${itemsVerified ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${itemsVerified ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  {itemsVerified ? <CheckCircle2 className="w-4 h-4" /> : '1'}
                </div>
                <span>Verify</span>
              </div>
              <div className={`flex-1 h-px mx-2 ${photoTaken ? 'bg-primary' : 'bg-border'}`} />
              <div className={`flex items-center gap-1 ${photoTaken ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${photoTaken ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  {photoTaken ? <CheckCircle2 className="w-4 h-4" /> : '2'}
                </div>
                <span>Picked Up</span>
              </div>
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
          {/* Job Information Card */}
          <Card className="border-2 shadow-lg">
            <CardContent className="p-6 space-y-6">
              {/* Time & Distance Section */}
              <div className="grid grid-cols-2 gap-4">
                {job.estimated_duration && (
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Duration</p>
                      <p className="text-sm font-semibold">{formatDuration(getJobDuration(job.estimated_duration, job.distance_miles))}</p>
                    </div>
                  </div>
                )}
                {(job.metadata as any)?.distance && (
                  <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                      <Navigation className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Distance</p>
                      <p className="text-sm font-semibold">{((job.metadata as any).distance).toFixed(1)} mi</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Pickup Location */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">📦 Pickup Location</h3>
                  {pickupLocation?.contact_phone && (
                    <button
                      onClick={() => window.location.href = `tel:${pickupLocation.contact_phone}`}
                      className="p-2 rounded-full hover:bg-muted/50 transition-colors"
                      aria-label="Contact"
                    >
                      <Phone className="h-5 w-5 text-primary" />
                    </button>
                  )}
                </div>
                <div className="space-y-3">
                  {/* Full Address */}
                  <div className="p-3 bg-muted/50 rounded-lg">
                    <p className="text-sm font-medium leading-relaxed">
                      {formatAddress(pickupLocation)}
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Camera View or Action Cards */}
          {cameraOpen ? (
            <div className="fixed inset-0 z-50 bg-black flex flex-col">
              {/* Camera Header */}
              <div className="sticky top-0 z-10 bg-black/80 backdrop-blur-sm px-4 py-3 flex-shrink-0">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-white">Camera</h3>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={stopCamera}
                    className="text-white hover:bg-white/20"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>
              </div>

              {/* Full screen video */}
              <div className="flex-1 relative">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full h-full object-cover"
                  onLoadedMetadata={() => console.log('✅ Video metadata loaded')}
                  onPlay={() => console.log('▶️ Video playing')}
                />
              </div>

              <canvas ref={canvasRef} className="hidden" />

              {/* Camera Controls */}
              <div className="fixed bottom-0 left-0 right-0 z-10 bg-black/80 backdrop-blur-sm p-4 pb-safe">
                <div className="flex gap-4 justify-center max-w-md mx-auto">
                  <Button onClick={capturePhoto} size="lg" className="flex-1 bg-white text-black hover:bg-white/90">
                    <Camera className="mr-2 h-5 w-5" />
                    Capture Photo
                  </Button>
                  <Button onClick={stopCamera} variant="outline" size="lg" className="flex-1 border-white text-white hover:bg-white/20">
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <>
              <Card className="p-4 space-y-4">
                <h3 className="font-semibold">Pickup Actions</h3>
                
                {/* Canvas for photo capture */}
                <canvas ref={canvasRef} className="hidden" />
                
                {/* Verify Items */}
                <div className="p-3 bg-muted/30 rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        itemsVerified ? 'bg-primary/20' : 'bg-muted'
                      }`}>
                        <Package className={`h-5 w-5 ${itemsVerified ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                      <div>
                        <p className="font-medium text-sm">Verify upon arrival</p>
                      </div>
                    </div>
                    {!itemsVerified && (
                      <Button size="sm" onClick={handleVerifyItems}>
                        Verify
                      </Button>
                    )}
                    {itemsVerified && (
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  {!itemsVerified && (
                    <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside ml-[52px]">
                      <li>Location</li>
                      <li>Item(s) condition</li>
                      <li>Etc...</li>
                    </ul>
                  )}
                  {itemsVerified && (
                    <p className="text-xs text-muted-foreground ml-[52px]">Items verified ✓</p>
                  )}
                </div>

                {/* Take Photo */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        photoAccepted ? 'bg-primary/20' : 'bg-muted'
                      }`}>
                        <Camera className={`h-5 w-5 ${photoAccepted ? 'text-primary' : 'text-muted-foreground'}`} />
                      </div>
                      <div>
                        <p className="font-medium text-sm">Pick Up Item(s)</p>
                        <p className="text-xs text-muted-foreground">
                          {photoAccepted ? 'Photo accepted ✓' : photoTaken ? 'Review photo' : 'Capture item(s) photo'}
                        </p>
                      </div>
                    </div>
                    {!photoTaken && (
                      <Button size="sm" onClick={startCamera} disabled={!itemsVerified}>
                        <Camera className="h-4 w-4 mr-1" />
                        Take Photo
                      </Button>
                    )}
                    {photoAccepted && (
                      <CheckCircle2 className="h-5 w-5 text-primary" />
                    )}
                  </div>
                  
                  {/* Show captured photo preview with accept/retake buttons */}
                  {capturedPhoto && !photoAccepted && (
                    <div className="space-y-3">
                      <div className="relative rounded-lg overflow-hidden border-2 border-primary">
                        <img 
                          src={capturedPhoto} 
                          alt="Captured pickup item photo"
                          className="w-full h-64 object-cover"
                          loading="lazy"
                        />
                      </div>
                      <div className="flex gap-3 justify-center items-center px-4">
                        <Button
                          size="lg"
                          variant="outline"
                          onClick={retakePhoto}
                          className="flex-1 max-w-[140px]"
                        >
                          <Camera className="h-4 w-4 mr-2" />
                          Retake
                        </Button>
                        <Button
                          size="lg"
                          onClick={handleAcceptPhoto}
                          className="flex-1 max-w-[140px]"
                        >
                          <CheckCircle2 className="h-4 w-4 mr-2" />
                          Accept Photo
                        </Button>
                      </div>
                    </div>
                  )}

                  {/* Show accepted photo preview */}
                  {capturedPhoto && photoAccepted && (
                    <div className="relative rounded-lg overflow-hidden border-2 border-primary">
                      <img 
                        src={capturedPhoto} 
                        alt="Accepted pickup item photo"
                        className="w-full h-48 object-cover"
                        loading="lazy"
                      />
                      <div className="absolute top-2 right-2 bg-primary text-primary-foreground px-2 py-1 rounded-md text-xs font-medium">
                        ✓ Accepted
                      </div>
                    </div>
                  )}
                </div>
              </Card>
            </>
          )}

          {/* Instructions - only show when camera is not open and items not verified */}
          {!cameraOpen && !itemsVerified && (
            <Card className="p-4 bg-primary/5 border-primary/20">
              <h4 className="font-semibold text-sm mb-2">Tips for Pickup</h4>
              <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                <li>Verify pickup address matches the location</li>
                <li>Take clear photos of all packages</li>
                <li>Confirm package count and condition</li>
                <li>Get signature if required</li>
              </ul>
            </Card>
          )}

          {/* Complete Pickup Button - Only show after all steps */}
          {photoAccepted && itemsVerified && !cameraOpen && (
            <Button
              size="lg"
              onClick={handleCompletePickup}
              disabled={isUploading}
              className="w-full"
            >
              {isUploading ? (
                <>
                  <span className="mr-2">Uploading...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-5 w-5 mr-2" />
                  Complete Pickup
                </>
              )}
            </Button>
          )}
        </div>

      </DialogContent>

      {/* Job Notes Modal */}
      <JobNotesModal 
        open={notesModalOpen} 
        onOpenChange={setNotesModalOpen} 
        job={job} 
      />

      {/* Driver Support Modal */}
      <DriverSupportModal 
        open={supportModalOpen} 
        onClose={() => setSupportModalOpen(false)}
        jobId={job?.id}
        assignmentId={assignment?.id}
        context="pickup"
      />
    </Dialog>
  );
};
