import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { JobMapView } from './JobMapView';
import { OnDutyModal } from './OnDutyModal';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';
import { JobStatusIndicator } from '@/components/job/JobStatusIndicator';
import {
  MapPin,
  DollarSign,
  Clock,
  User,
  Package,
  Calendar,
  Truck,
  FileText,
  AlertCircle,
  Map,
  Phone,
  AlertTriangle,
  ThermometerSnowflake,
  Shield,
} from 'lucide-react';
import { format } from 'date-fns';

interface DriverJobDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  job: {
    id: string;
    title: string;
    description?: string;
    pickup_location: any;
    delivery_location: any;
    dropoff_locations?: any[];
    pay_amount?: number;
    estimated_duration?: number;
    distance_miles?: number;
    pickup_time?: string;
    delivery_time?: string;
    status?: string;
    priority?: string;
    assigned_driver_id?: string | null;
    special_instructions?: string;
    cargo_details?: any;
    cargo_weight?: number;
    cargo_dimensions?: any;
    signature_required?: boolean;
    require_signature?: boolean;
    pickup_contact_name?: string;
    pickup_contact_phone?: string;
    delivery_contact_name?: string;
    delivery_contact_phone?: string;
    equipment_type?: string;
    trailer_type?: string;
    is_hazmat?: boolean;
    hazmat_details?: string;
    temperature_requirements?: string;
    required_certifications?: string[];
    insurance_requirements?: string;
    payment_terms?: string;
    created_at?: string;
  };
  type?: 'pickup_now' | 'scheduled' | 'active';
  onClaim?: (jobId: string) => void;
  onStartJob?: (jobId: string) => void;
  onPickup?: (jobId: string) => void;
  onDelivery?: (jobId: string) => void;
  onCancel?: (jobId: string, reason: string) => void;
  isClaiming?: boolean;
  isProcessing?: boolean;
  canClaim?: boolean;
}

const getFullAddress = (location: any) => {
  if (!location) return 'No address provided';
  
  // Handle string locations
  if (typeof location === 'string') {
    // Try to extract city and state from string
    const parts = location.split(',').map(p => p.trim());
    if (parts.length >= 2) {
      // Assume format contains city and state
      const city = parts[parts.length - 3] || parts[0];
      const state = parts[parts.length - 2]?.split(' ')[0]; // Remove zip if present
      return state ? `${city}, ${state}` : city;
    }
    return location;
  }
  
  // Handle object locations - prioritize city and state
  const city = location.city;
  const state = location.state;
  
  if (city && state) {
    return `${city}, ${state}`;
  } else if (city) {
    return city;
  } else if (state) {
    return state;
  }
  
  // Fallback to full address formats
  if (location.address) return location.address;
  if (location.formatted_address) return location.formatted_address;
  
  return 'Address not available';
};

const getPriorityColor = (priority?: string) => {
  switch (priority?.toLowerCase()) {
    case 'critical':
      return 'destructive';
    case 'high':
      return 'default';
    case 'medium':
      return 'secondary';
    case 'low':
      return 'outline';
    default:
      return 'secondary';
  }
};

const getStatusColor = (status?: string) => {
  switch (status?.toLowerCase()) {
    case 'pending':
      return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
    case 'assigned':
      return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    case 'planned':
      return 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200';
    case 'in_progress':
      return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200';
    case 'completed':
      return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
    case 'cancelled':
      return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
    default:
      return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
  }
};

export const DriverJobDetailsDialog: React.FC<DriverJobDetailsDialogProps> = ({
  open,
  onOpenChange,
  job,
  type = 'pickup_now',
  onClaim,
  onStartJob,
  onPickup,
  onDelivery,
  onCancel,
  isClaiming = false,
  isProcessing = false,
  canClaim = true,
}) => {
  if (!job) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Job Not Found</DialogTitle>
            <DialogDescription>
              Unable to load job details. Please try again.
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    );
  }

  const pickupTime = job.pickup_time ? new Date(job.pickup_time) : null;
  const deliveryTime = job.delivery_time ? new Date(job.delivery_time) : null;
  const [activeTab, setActiveTab] = useState('details');
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [showOnDutyModal, setShowOnDutyModal] = useState(false);

  const displayDuration = getJobDuration(job.estimated_duration, job.distance_miles);

  const handleClaimClick = () => {
    if (onClaim) {
      onClaim(job.id);
    }
  };

  const handleStartJob = async () => {
    console.log('🔵 Start Job button clicked, job ID:', job.id);
    if (onStartJob) {
      try {
        console.log('🔵 Calling onStartJob...');
        await onStartJob(job.id);
        console.log('✅ onStartJob completed successfully');
        // Only open modal and close dialog after job status is updated
        setShowOnDutyModal(true);
        onOpenChange(false);
      } catch (error) {
        console.error('❌ Error in handleStartJob:', error);
      }
    } else {
      console.error('❌ onStartJob prop is not defined!');
    }
  };

  const handlePickup = () => {
    if (onPickup) {
      onPickup(job.id);
    }
  };

  const handleDelivery = () => {
    if (onDelivery) {
      onDelivery(job.id);
    }
  };

  const handleCancelConfirm = () => {
    if (onCancel && cancelReason.trim()) {
      onCancel(job.id, cancelReason);
      setShowCancelDialog(false);
      setCancelReason('');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-screen h-screen max-w-full max-h-full flex flex-col p-0 m-0 rounded-none z-[150]">
        <div className="p-3 sm:p-6 pb-2 sm:pb-3 border-b shrink-0">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between gap-2">
              <span className="text-sm sm:text-lg">{job.title}</span>
            </DialogTitle>
            <DialogDescription className="text-xs sm:text-sm text-muted-foreground">
              Job ID: {`${job.id.substring(0, 8)}...`}
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="overflow-y-auto flex-1 p-3 sm:p-6 space-y-2 sm:space-y-4">
          {/* Status and Priority */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
            {job.status && (
              <JobStatusIndicator status={job.status} size="sm" />
            )}
            {job.priority && (
              <Badge variant={getPriorityColor(job.priority)} className="text-xs">
                {job.priority.toUpperCase()} Priority
              </Badge>
            )}
            {job.signature_required && (
              <Badge variant="outline" className="flex items-center gap-1 text-xs">
                <FileText className="h-2.5 w-2.5" />
                Signature Required
              </Badge>
            )}
          </div>

          <Separator />

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2 h-8 sm:h-10">
              <TabsTrigger value="details" className="text-xs sm:text-sm">
                <FileText className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                Details
              </TabsTrigger>
              <TabsTrigger value="map" className="text-xs sm:text-sm">
                <Map className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                Map View
              </TabsTrigger>
            </TabsList>

            {/* Details Tab */}
            <TabsContent value="details" className="space-y-2 sm:space-y-3 mt-2 sm:mt-4">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 sm:gap-4">
                <div className="flex items-start gap-1.5 sm:gap-2">
                  <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-primary mt-0.5" />
                  <div>
                    <p className="text-xs sm:text-sm font-medium">Pay Amount</p>
                    <p className="text-base sm:text-lg font-bold text-primary">
                      ${job.pay_amount || '0'}
                    </p>
                  </div>
                </div>
                {displayDuration && (
                  <div className="flex items-start gap-1.5 sm:gap-2">
                    <Clock className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs sm:text-sm font-medium">Duration</p>
                      <p className="text-sm sm:text-base font-semibold">
                        {formatDuration(displayDuration)}
                      </p>
                    </div>
                  </div>
                )}
                {job.distance_miles && (
                  <div className="flex items-start gap-1.5 sm:gap-2">
                    <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground mt-0.5" />
                    <div>
                      <p className="text-xs sm:text-sm font-medium">Distance</p>
                      <p className="text-sm sm:text-base font-semibold">
                        {job.distance_miles} miles
                      </p>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              {/* Pickup Location */}
              <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-green-600" />
                  <h3 className="text-xs sm:text-sm font-semibold">Pickup Location</h3>
                </div>
                <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                  {getFullAddress(job.pickup_location)}
                </p>
                {pickupTime && (
                  <div className="flex items-center gap-1.5 sm:gap-2 ml-5 sm:ml-7">
                    <Calendar className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                    <p className="text-xs sm:text-sm text-muted-foreground">
                      {format(pickupTime, 'PPpp')}
                    </p>
                  </div>
                )}
                {(job.pickup_contact_name || job.pickup_contact_phone) && (
                  <div className="ml-5 sm:ml-7 pt-2 space-y-1">
                    {job.pickup_contact_name && (
                      <p className="text-xs sm:text-sm text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {job.pickup_contact_name}
                      </p>
                    )}
                    {job.pickup_contact_phone && (
                      <p className="text-xs sm:text-sm text-muted-foreground flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {job.pickup_contact_phone}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Delivery Location */}
              <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-red-50 dark:bg-red-950 rounded-lg">
                <div className="flex items-center gap-1.5 sm:gap-2">
                  <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-red-600" />
                  <h3 className="text-xs sm:text-sm font-semibold">Delivery Location</h3>
                </div>
                <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                  {getFullAddress(job.delivery_location)}
                </p>
                {deliveryTime && (
                  <div className="flex items-center gap-1.5 sm:gap-2 ml-5 sm:ml-7">
                    <Calendar className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                    <p className="text-xs sm:text-sm text-muted-foreground">
                      {format(deliveryTime, 'PPpp')}
                    </p>
                  </div>
                )}
                {(job.delivery_contact_name || job.delivery_contact_phone) && (
                  <div className="ml-5 sm:ml-7 pt-2 space-y-1">
                    {job.delivery_contact_name && (
                      <p className="text-xs sm:text-sm text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {job.delivery_contact_name}
                      </p>
                    )}
                    {job.delivery_contact_phone && (
                      <p className="text-xs sm:text-sm text-muted-foreground flex items-center gap-1">
                        <Phone className="h-3 w-3" />
                        {job.delivery_contact_phone}
                      </p>
                    )}
                  </div>
                )}
                {(job.signature_required || job.require_signature) && (
                  <div className="ml-5 sm:ml-7 pt-2">
                    <div className="flex items-center gap-1 text-xs sm:text-sm text-muted-foreground">
                      <FileText className="h-3 w-3" />
                      <span className="font-medium">Signature required upon delivery</span>
                    </div>
                  </div>
                )}
              </div>

              <Separator />

              {job.description && (
                <div className="space-y-1 sm:space-y-2">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <FileText className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                    <h3 className="text-xs sm:text-sm font-semibold">Description</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    {job.description}
                  </p>
                </div>
              )}

              {(job.equipment_type || job.trailer_type || job.is_hazmat) && (
                <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <Truck className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600" />
                    <h3 className="text-xs sm:text-sm font-semibold">Equipment Requirements</h3>
                  </div>
                  <div className="ml-5 sm:ml-7 space-y-1">
                    {job.equipment_type && (
                      <p className="text-xs sm:text-sm text-muted-foreground">
                        <span className="font-medium">Vehicle Type:</span> {job.equipment_type}
                      </p>
                    )}
                    {job.trailer_type && (
                      <p className="text-xs sm:text-sm text-muted-foreground">
                        <span className="font-medium">Trailer Type:</span> {job.trailer_type}
                      </p>
                    )}
                    {job.is_hazmat && (
                      <div className="flex items-center gap-1">
                        <AlertTriangle className="h-3 w-3 text-red-600" />
                        <p className="text-xs sm:text-sm text-red-600 font-medium">HAZMAT Material</p>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {job.cargo_details && (
                <div className="space-y-1 sm:space-y-2">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <Package className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                    <h3 className="text-xs sm:text-sm font-semibold">Cargo Details</h3>
                  </div>
                  <div className="ml-5 sm:ml-7 text-xs sm:text-sm text-muted-foreground space-y-0.5 sm:space-y-1">
                    {job.cargo_details.weight && (
                      <p>Weight: {job.cargo_details.weight} lbs</p>
                    )}
                    {job.cargo_details.description && (
                      <p>{job.cargo_details.description}</p>
                    )}
                    {job.cargo_details.vehicle_type && (
                      <p>Vehicle Type Required: {job.cargo_details.vehicle_type}</p>
                    )}
                  </div>
                </div>
              )}

              {job.temperature_requirements && (
                <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-cyan-50 dark:bg-cyan-950 rounded-lg">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <ThermometerSnowflake className="h-4 w-4 sm:h-5 sm:w-5 text-cyan-600" />
                    <h3 className="text-xs sm:text-sm font-semibold">Temperature Control</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    {job.temperature_requirements}
                  </p>
                </div>
              )}

              {job.required_certifications && job.required_certifications.length > 0 && (
                <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-amber-50 dark:bg-amber-950 rounded-lg">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-amber-600" />
                    <h3 className="text-xs sm:text-sm font-semibold">Required Certifications</h3>
                  </div>
                  <ul className="ml-5 sm:ml-7 text-xs sm:text-sm text-muted-foreground space-y-0.5">
                    {job.required_certifications.map((cert: string, idx: number) => (
                      <li key={idx}>• {cert}</li>
                    ))}
                  </ul>
                </div>
              )}

              {job.special_instructions && (
                <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <AlertCircle className="h-4 w-4 sm:h-5 sm:w-5 text-orange-600" />
                    <h3 className="text-xs sm:text-sm font-semibold">Special Instructions</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    {job.special_instructions}
                  </p>
                </div>
              )}

              {job.hazmat_details && (
                <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-red-50 dark:bg-red-950 rounded-lg">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <AlertTriangle className="h-4 w-4 sm:h-5 sm:w-5 text-red-600" />
                    <h3 className="text-xs sm:text-sm font-semibold">HAZMAT Details</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    {job.hazmat_details}
                  </p>
                </div>
              )}

              {job.insurance_requirements && (
                <div className="space-y-1 sm:space-y-2">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <Shield className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                    <h3 className="text-xs sm:text-sm font-semibold">Insurance Requirements</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    {job.insurance_requirements}
                  </p>
                </div>
              )}

              {job.payment_terms && (
                <div className="space-y-1 sm:space-y-2">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <DollarSign className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                    <h3 className="text-xs sm:text-sm font-semibold">Payment Terms</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    {job.payment_terms}
                  </p>
                </div>
              )}

              {job.assigned_driver_id && (
                <div className="space-y-1 sm:space-y-2 p-2 sm:p-3 bg-muted rounded-lg">
                  <div className="flex items-center gap-1.5 sm:gap-2">
                    <User className="h-4 w-4 sm:h-5 sm:w-5 text-muted-foreground" />
                    <h3 className="text-xs sm:text-sm font-semibold">Assignment Status</h3>
                  </div>
                  <p className="text-xs sm:text-sm text-muted-foreground ml-5 sm:ml-7">
                    This job has been assigned to a driver
                  </p>
                </div>
              )}
            </TabsContent>

            {/* Map Tab */}
            <TabsContent value="map" className="mt-2 sm:mt-4">
              <div className="space-y-2 sm:space-y-4">
                <JobMapView
                  pickupLocation={
                    job.pickup_location?.lat && job.pickup_location?.lng
                      ? {
                          lat: job.pickup_location.lat,
                          lng: job.pickup_location.lng,
                          address: getFullAddress(job.pickup_location),
                        }
                      : null
                  }
                  deliveryLocation={
                    job.delivery_location?.lat && job.delivery_location?.lng
                      ? {
                          lat: job.delivery_location.lat,
                          lng: job.delivery_location.lng,
                          address: getFullAddress(job.delivery_location),
                        }
                      : null
                  }
                  jobTitle={job.title}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 sm:gap-4">
                  {job.pickup_location?.lat && job.pickup_location?.lng && (
                    <div className="p-2 sm:p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                      <div className="flex items-center gap-1.5 sm:gap-2 mb-1 sm:mb-2">
                        <MapPin className="h-3 w-3 sm:h-4 sm:w-4 text-green-600" />
                        <span className="font-semibold text-xs sm:text-sm">Pickup</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {getFullAddress(job.pickup_location)}
                      </p>
                    </div>
                  )}
                  
                  {job.delivery_location?.lat && job.delivery_location?.lng && (
                    <div className="p-2 sm:p-3 bg-red-50 dark:bg-red-900/20 rounded-lg">
                      <div className="flex items-center gap-1.5 sm:gap-2 mb-1 sm:mb-2">
                        <MapPin className="h-3 w-3 sm:h-4 sm:w-4 text-red-600" />
                        <span className="font-semibold text-xs sm:text-sm">Delivery</span>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {getFullAddress(job.delivery_location)}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Action Buttons - Fixed at bottom */}
        <div className="shrink-0 p-3 sm:p-4 bg-background border-t flex gap-2 sm:gap-3 z-[60]">
          {type === 'pickup_now' && !job.assigned_driver_id && (
            <>
              <Button 
                variant="outline"
                className="text-xs sm:text-sm h-9 sm:h-10" 
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                className="text-xs sm:text-sm h-9 sm:h-10" 
                onClick={handleClaimClick}
                disabled={isClaiming || !canClaim}
              >
                {isClaiming ? 'Claiming...' : 'Claim Job'}
              </Button>
            </>
          )}
          
          {type === 'scheduled' && !job.assigned_driver_id && (
            <>
              <Button 
                variant="outline"
                className="text-xs sm:text-sm h-9 sm:h-10" 
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                className="text-xs sm:text-sm h-9 sm:h-10" 
                onClick={handleClaimClick}
                disabled={isClaiming || !canClaim}
              >
                {isClaiming ? 'Claiming...' : 'Claim Job'}
              </Button>
            </>
          )}
          
          {type === 'active' && job.assigned_driver_id && (
            <>
              {job.status === 'in_progress' && (
                <Button 
                  className="flex-1 text-xs sm:text-sm h-9 sm:h-10" 
                  onClick={handlePickup}
                  disabled={isProcessing}
                >
                  {isProcessing ? 'Processing...' : 'Pick Up'}
                </Button>
              )}
              
              {job.status === 'picked_up' && (
                <Button 
                  className="flex-1 text-xs sm:text-sm h-9 sm:h-10" 
                  onClick={handleDelivery}
                  disabled={isProcessing}
                >
                  {isProcessing ? 'Processing...' : 'Mark as Delivered'}
                </Button>
              )}
              
              <Button 
                variant="destructive" 
                className="flex-1 text-xs sm:text-sm h-9 sm:h-10" 
                onClick={() => setShowCancelDialog(true)}
                disabled={isProcessing}
              >
                Cancel Job
              </Button>
            </>
          )}
        </div>

        {/* Cancel Dialog */}
        <Dialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Cancel Job</DialogTitle>
              <DialogDescription>
                Please provide a reason for cancelling this job.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <textarea
                className="w-full p-2 border rounded-md"
                rows={4}
                placeholder="Enter cancellation reason..."
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
              />
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setShowCancelDialog(false)}>
                  Back
                </Button>
                <Button 
                  variant="destructive" 
                  onClick={handleCancelConfirm}
                  disabled={!cancelReason.trim()}
                >
                  Confirm Cancel
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* On Duty Modal */}
        <OnDutyModal
          open={showOnDutyModal}
          onOpenChange={setShowOnDutyModal}
          jobId={job.id}
        />
      </DialogContent>
    </Dialog>
  );
};
