import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { MapPin, Package, CheckCircle2, Map as MapIcon } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { OnDutyPickupModal } from './OnDutyPickupModal';
import { OnDutyDeliveryModal } from './OnDutyDeliveryModal';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { supabase } from '@/integrations/supabase/client';
import { geocodeByAddress } from '@/lib/geocoding';

interface Stop {
  id: string;
  jobId: string;
  jobTitle: string;
  type: 'pickup' | 'delivery';
  address: string;
  sequence: number;
  status: 'pending' | 'en_route' | 'arrived' | 'complete';
}

interface RouteTasksModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobs: any[];
  onActivateRoute: () => void;
}

export function RouteTasksModal({ open, onOpenChange, jobs, onActivateRoute }: RouteTasksModalProps) {
  const [stops, setStops] = useState<Stop[]>([]);
  const [showPickupModal, setShowPickupModal] = useState(false);
  const [showDeliveryModal, setShowDeliveryModal] = useState(false);
  const [selectedStop, setSelectedStop] = useState<Stop | null>(null);
  const [showMap, setShowMap] = useState(false);
  const [mapboxToken, setMapboxToken] = useState<string>('');
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markersRef = useRef<mapboxgl.Marker[]>([]);

  // Fetch Mapbox token
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('get-mapbox-token');
        if (error) throw error;
        if (data?.token) {
          setMapboxToken(data.token);
        }
      } catch (error) {
        console.error('Error fetching Mapbox token:', error);
      }
    };
    fetchToken();
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapContainer.current || !mapboxToken || !showMap) return;

    mapboxgl.accessToken = mapboxToken;

    // Get center from first job
    const firstJob = jobs[0];
    const center: [number, number] = firstJob?.pickup_location?.lng && firstJob?.pickup_location?.lat
      ? [firstJob.pickup_location.lng, firstJob.pickup_location.lat]
      : [-98.5795, 39.8283]; // Default to center of US

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center,
      zoom: 11,
    });

    map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');

    return () => {
      map.current?.remove();
    };
  }, [mapboxToken, showMap, jobs]);

  // Update markers when jobs change
  useEffect(() => {
    if (!map.current || !showMap) return;

    // Clear existing markers
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    const bounds = new mapboxgl.LngLatBounds();
    let hasValidLocation = false;

    jobs.forEach((job, index) => {
      // Add pickup marker (green)
      if (job.pickup_location?.lat && job.pickup_location?.lng) {
        const pickupEl = document.createElement('div');
        pickupEl.className = 'flex items-center justify-center w-8 h-8 bg-success rounded-full border-2 border-white shadow-lg text-white font-bold text-xs';
        pickupEl.textContent = `${index * 2 + 1}`;

        const pickupMarker = new mapboxgl.Marker({ element: pickupEl })
          .setLngLat([job.pickup_location.lng, job.pickup_location.lat])
          .setPopup(
            new mapboxgl.Popup({ offset: 25 }).setHTML(`
              <div class="p-2">
                <p class="font-semibold text-sm">Pickup #${index * 2 + 1}</p>
                <p class="text-xs font-medium">${job.title}</p>
                <p class="text-xs text-gray-600">${job.pickup_location.address || 'Location'}</p>
              </div>
            `)
          )
          .addTo(map.current);

        markersRef.current.push(pickupMarker);
        bounds.extend([job.pickup_location.lng, job.pickup_location.lat]);
        hasValidLocation = true;
      }

      // Add delivery marker (primary color)
      if (job.delivery_location?.lat && job.delivery_location?.lng) {
        const deliveryEl = document.createElement('div');
        deliveryEl.className = 'flex items-center justify-center w-8 h-8 bg-primary rounded-full border-2 border-white shadow-lg text-white font-bold text-xs';
        deliveryEl.textContent = `${index * 2 + 2}`;

        const deliveryMarker = new mapboxgl.Marker({ element: deliveryEl })
          .setLngLat([job.delivery_location.lng, job.delivery_location.lat])
          .setPopup(
            new mapboxgl.Popup({ offset: 25 }).setHTML(`
              <div class="p-2">
                <p class="font-semibold text-sm">Delivery #${index * 2 + 2}</p>
                <p class="text-xs font-medium">${job.title}</p>
                <p class="text-xs text-gray-600">${job.delivery_location.address || 'Location'}</p>
              </div>
            `)
          )
          .addTo(map.current);

        markersRef.current.push(deliveryMarker);
        bounds.extend([job.delivery_location.lng, job.delivery_location.lat]);
        hasValidLocation = true;
      }
    });

    // Fit bounds if we have valid locations
    if (hasValidLocation) {
      map.current.fitBounds(bounds, { padding: 80, maxZoom: 13 });
    }
  }, [jobs, showMap]);

  // Regenerate stops whenever jobs change
  useEffect(() => {
    const generatedStops: Stop[] = [];
    jobs.forEach((job, index) => {
      generatedStops.push({
        id: `${job.id}-pickup`,
        jobId: job.id,
        jobTitle: job.title,
        type: 'pickup',
        address: job.pickup_location?.address || 'Pickup location',
        sequence: index * 2 + 1,
        status: 'pending'
      });
      generatedStops.push({
        id: `${job.id}-delivery`,
        jobId: job.id,
        jobTitle: job.title,
        type: 'delivery',
        address: job.delivery_location?.address || 'Delivery location',
        sequence: index * 2 + 2,
        status: 'pending'
      });
    });
    setStops(generatedStops);
  }, [jobs]);

  const handleStatusChange = (stopId: string, newStatus: string) => {
    setStops(prev => prev.map(stop => 
      stop.id === stopId ? { ...stop, status: newStatus as Stop['status'] } : stop
    ));
  };

  const handleMarkComplete = (stopId: string) => {
    handleStatusChange(stopId, 'complete');
  };

  const completedCount = stops.filter(s => s.status === 'complete').length;
  const totalStops = stops.length;

  const getStatusColor = (status: Stop['status']) => {
    switch (status) {
      case 'complete': return 'bg-success text-success-foreground';
      case 'arrived': return 'bg-primary text-primary-foreground';
      case 'en_route': return 'bg-accent text-accent-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusLabel = (status: Stop['status']) => {
    switch (status) {
      case 'en_route': return 'En Route';
      case 'arrived': return 'Arrived';
      case 'complete': return 'Complete';
      default: return 'Pending';
    }
  };

  return (
    <>
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-full w-screen h-screen max-h-screen flex flex-col p-0 gap-0">
        <DialogHeader className="px-4 py-3 border-b bg-card/50 backdrop-blur-sm sticky top-0 z-10">
          <div className="flex items-center justify-between">
            <DialogTitle className="text-lg font-semibold">Route Disposition</DialogTitle>
            <Button
              variant={showMap ? "default" : "outline"}
              size="sm"
              onClick={() => setShowMap(!showMap)}
              className="gap-2"
            >
              <MapIcon className="h-4 w-4" />
              {showMap ? 'Hide Map' : 'Show Map'}
            </Button>
          </div>
        </DialogHeader>

        {/* Map View */}
        {showMap && (
          <div className="h-64 sm:h-80 relative border-b">
            {mapboxToken ? (
              <div ref={mapContainer} className="absolute inset-0" />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center bg-muted">
                <p className="text-sm text-muted-foreground">Loading map...</p>
              </div>
            )}
          </div>
        )}

        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2.5">
          {stops.map((stop, idx) => (
            <div 
              key={stop.id}
              className={`border rounded-xl p-3.5 transition-all ${
                stop.status === 'complete' 
                  ? 'bg-success/5 border-success/20' 
                  : 'bg-card'
              }`}
            >
              <div className="flex items-start gap-3 mb-3">
                <div className={`p-2.5 rounded-full flex-shrink-0 ${
                  stop.type === 'pickup' 
                    ? 'bg-success/15 ring-2 ring-success/30' 
                    : 'bg-primary/15 ring-2 ring-primary/30'
                }`}>
                  {stop.type === 'pickup' ? (
                    <Package className="h-5 w-5 text-success" />
                  ) : (
                    <MapPin className="h-5 w-5 text-primary" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xs font-bold text-muted-foreground bg-muted px-2 py-0.5 rounded">
                      #{stop.sequence}
                    </span>
                    <h3 className="font-semibold text-base">
                      {stop.type === 'pickup' ? 'Pickup' : 'Drop-off'}
                    </h3>
                    <Badge 
                      variant="secondary" 
                      className={`text-xs ml-auto ${getStatusColor(stop.status)}`}
                    >
                      {getStatusLabel(stop.status)}
                    </Badge>
                  </div>
                  <p className="font-medium text-sm mb-1">{stop.jobTitle}</p>
                  <p className="text-xs text-muted-foreground flex items-start gap-1.5">
                    <MapPin className="h-3.5 w-3.5 mt-0.5 flex-shrink-0" />
                    <span className="line-clamp-2">{stop.address}</span>
                  </p>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  size="default"
                  variant={stop.status === 'pending' ? 'default' : 'outline'}
                  onClick={() => {
                    if (stop.type === 'pickup') {
                      setSelectedStop(stop);
                      setShowPickupModal(true);
                    } else if (stop.type === 'delivery') {
                      setSelectedStop(stop);
                      setShowDeliveryModal(true);
                    }
                  }}
                  disabled={stop.status !== 'pending'}
                  className="flex-1 h-10"
                >
                  Start
                </Button>

                <Button
                  size="default"
                  variant={stop.status === 'complete' ? 'default' : 'outline'}
                  onClick={() => handleMarkComplete(stop.id)}
                  disabled={stop.status === 'complete'}
                  className="whitespace-nowrap h-10 px-4"
                >
                  {stop.status === 'complete' ? (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-1.5" />
                      Done
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="h-4 w-4 mr-1.5" />
                      Complete
                    </>
                  )}
                </Button>
              </div>
            </div>
          ))}
        </div>

        <div className="fixed bottom-0 left-0 right-0 z-10 bg-card/80 backdrop-blur-sm border-t px-4 pt-4 pb-safe space-y-4 shadow-lg">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground font-medium">Progress:</span>
            <div className="flex items-center gap-2">
              <div className="h-2 w-24 bg-muted rounded-full overflow-hidden">
                <div 
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${(completedCount / totalStops) * 100}%` }}
                />
              </div>
              <span className="font-bold text-lg">{completedCount}/{totalStops}</span>
            </div>
          </div>
          <Button 
            className="w-full h-12 text-base font-semibold" 
            size="lg"
            variant="outline"
            onClick={() => {
              onOpenChange(false);
            }}
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>

    {/* Pickup Modal */}
    {selectedStop && selectedStop.type === 'pickup' && (
      <OnDutyPickupModal
        open={showPickupModal}
        onOpenChange={(isOpen) => {
          setShowPickupModal(isOpen);
          if (!isOpen) setSelectedStop(null);
        }}
        jobId={selectedStop.jobId}
        assignmentId=""
        assignment={{}}
        job={jobs.find(j => j.id === selectedStop.jobId) || {}}
        pickupLocation={jobs.find(j => j.id === selectedStop.jobId)?.pickup_location}
        areaType="urban"
        onPickupComplete={() => {
          handleStatusChange(selectedStop.id, 'complete');
          setShowPickupModal(false);
          setSelectedStop(null);
          // Keep Route Tasks Modal open
        }}
      />
    )}

    {/* Delivery Modal */}
    {selectedStop && selectedStop.type === 'delivery' && (
      <OnDutyDeliveryModal
        open={showDeliveryModal}
        onClose={() => {
          setShowDeliveryModal(false);
          setSelectedStop(null);
          // Keep Route Tasks Modal open
        }}
        onDeliveryComplete={async (deliveryData) => {
          handleStatusChange(selectedStop.id, 'complete');
          setShowDeliveryModal(false);
          setSelectedStop(null);
          // Keep Route Tasks Modal open
        }}
        signatureRequired={false}
        dropoffLocations={[]}
        job={jobs.find(j => j.id === selectedStop.jobId)}
      />
    )}
    </>
  );
}
