import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface AdminOverrideModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onConfirm: (reason: string) => void;
  conflictingJobs?: Array<{
    job_title: string;
    pickup_time: string;
    delivery_time: string;
  }>;
  isLoading?: boolean;
}

export function AdminOverrideModal({
  open,
  onOpenChange,
  onConfirm,
  conflictingJobs = [],
  isLoading = false,
}: AdminOverrideModalProps) {
  const [reason, setReason] = useState('');

  const handleConfirm = () => {
    if (reason.trim()) {
      onConfirm(reason);
      setReason('');
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            Schedule Overlap Detected
          </DialogTitle>
          <DialogDescription>
            This job overlaps with existing scheduled jobs. As an admin, you can override this restriction.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {conflictingJobs.length > 0 && (
            <Alert variant="destructive">
              <AlertDescription>
                <div className="font-semibold mb-2">Conflicting Jobs:</div>
                <ul className="space-y-1 text-sm">
                  {conflictingJobs.map((job, idx) => (
                    <li key={idx}>
                      • {job.job_title} ({new Date(job.pickup_time).toLocaleTimeString()} - {new Date(job.delivery_time).toLocaleTimeString()})
                    </li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          <div className="space-y-2">
            <Label htmlFor="override-reason">
              Override Justification <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="override-reason"
              placeholder="Enter reason for overriding (e.g., 'Emergency reroute', 'Special client request', 'Driver requested multiple pickups')"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={4}
              className="resize-none"
            />
            <p className="text-sm text-muted-foreground">
              This action will be logged for audit purposes.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => {
              setReason('');
              onOpenChange(false);
            }}
            disabled={isLoading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={!reason.trim() || isLoading}
            variant="destructive"
          >
            {isLoading ? 'Overriding...' : 'Override & Assign Job'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
