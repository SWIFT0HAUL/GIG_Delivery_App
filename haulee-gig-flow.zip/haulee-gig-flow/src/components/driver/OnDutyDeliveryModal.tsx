import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { Camera, RotateCcw, Check, FileSignature, X, MapPin, Package, CheckCircle2, Phone, FileText, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { toast } from 'sonner';
import { SlideToConfirm } from './SlideToConfirm';
import { supabase } from '@/integrations/supabase/client';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';
import { JobNotesModal } from './JobNotesModal';
import { DriverSupportModal } from './DriverSupportModal';

interface OnDutyDeliveryModalProps {
  open: boolean;
  onClose: () => void;
  onDeliveryComplete: (data: {
    dropoffLocation: string;
    photoBlob?: Blob;
    signature?: string;
    recipientName?: string;
  }) => void;
  signatureRequired: boolean;
  dropoffLocations?: any[];
  pickupPhotoUrl?: string;
  job?: any;
}

export function OnDutyDeliveryModal({ 
  open, 
  onClose, 
  onDeliveryComplete,
  signatureRequired,
  dropoffLocations = [],
  pickupPhotoUrl,
  job
}: OnDutyDeliveryModalProps) {
  // Hierarchical location options with sub-locations
  const locationOptionsHierarchy = [
    { 
      id: 'home', 
      label: 'Home',
      subLocations: ['Front Door', 'Back Door', 'Garage', 'Mailbox', 'Porch', 'Side Entrance']
    },
    { 
      id: 'apartment', 
      label: 'Apartment',
      subLocations: ['Front Desk', 'Unit Door', 'Mailbox', 'Lobby', 'Parcel Room', 'Leasing Office']
    },
    { 
      id: 'office', 
      label: 'Office',
      subLocations: ['Reception', 'Mailroom', 'Loading Dock', 'Security Desk', 'Specific Floor/Suite']
    },
    { 
      id: 'retail_store', 
      label: 'Retail Store',
      subLocations: ['Front Counter', 'Back Entrance', 'Storage Room', 'Manager Office']
    },
    { 
      id: 'warehouse', 
      label: 'Warehouse',
      subLocations: ['Loading Bay', 'Receiving Dock', 'Security Gate', 'Office Entrance']
    },
    { 
      id: 'hospital', 
      label: 'Hospital',
      subLocations: ['Main Entrance', 'Emergency Entrance', 'Loading Dock', 'Pharmacy', 'Specific Department']
    },
    { 
      id: 'school', 
      label: 'School',
      subLocations: ['Main Office', 'Cafeteria', 'Loading Zone', 'Gym Entrance', 'Specific Classroom']
    },
    { 
      id: 'parcel_locker', 
      label: 'Parcel Locker',
      subLocations: ['Locker #1-50', 'Locker #51-100', 'Oversized Section', 'Main Hub']
    },
    { 
      id: 'restaurant', 
      label: 'Restaurant',
      subLocations: ['Front Counter', 'Back Kitchen Entrance', 'Drive-Thru Window', 'Curbside Pickup']
    },
    { 
      id: 'construction_site', 
      label: 'Construction Site',
      subLocations: ['Main Gate', 'Site Office', 'Trailer', 'Foreman Location', 'Tool Storage']
    },
    { 
      id: 'customer', 
      label: 'Customer',
      subLocations: ['Front Door', 'Reception', 'Direct Handoff', 'Security Desk', 'Designated Area']
    },
  ];

  // Use provided dropoff locations or fallback to default types
  const locationOptions = dropoffLocations.length > 0 
    ? dropoffLocations.map((loc, idx) => ({
        id: loc.id || `loc_${idx}`,
        label: loc.address || loc.label || `Location ${idx + 1}`,
        subLocations: []
      }))
    : locationOptionsHierarchy;

  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [selectedSubLocation, setSelectedSubLocation] = useState<string>('');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [signature, setSignature] = useState<string>('');
  const [recipientName, setRecipientName] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState<'items' | 'location' | 'photo' | 'signature'>(signatureRequired ? 'signature' : 'items');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [itemsConfirmed, setItemsConfirmed] = useState(false);
  const [mapExpanded, setMapExpanded] = useState(false);
  const [mapboxToken, setMapboxToken] = useState<string | null>(null);
  const [notesModalOpen, setNotesModalOpen] = useState(false);
  const [supportModalOpen, setSupportModalOpen] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const signatureCanvasRef = useRef<HTMLCanvasElement>(null);
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<mapboxgl.Map | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);

  // Auto-select first location when signature is required and modal opens
  useEffect(() => {
    if (open && signatureRequired && !selectedLocation && locationOptions.length > 0) {
      setSelectedLocation(locationOptions[0].id);
      setItemsConfirmed(true); // Mark items as confirmed since we're skipping
    }
  }, [open, signatureRequired, selectedLocation, locationOptions]);

  // Removed auto-start camera - now triggered by button click

  // Initialize signature canvas
  useEffect(() => {
    if (currentStep === 'signature' && signatureCanvasRef.current) {
      const canvas = signatureCanvasRef.current;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 2;
        ctx.lineCap = 'round';
      }
    }
  }, [currentStep]);

  const startCamera = async () => {
    try {
      console.log('📸 Starting camera...');
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: 1280, height: 720 },
      });
      console.log('✅ MediaStream obtained:', mediaStream);
      setStream(mediaStream);
      setCameraOpen(true);
      
      // Wait for next tick to ensure video element is rendered
      setTimeout(() => {
        if (videoRef.current && mediaStream) {
          console.log('📹 Setting video srcObject');
          videoRef.current.srcObject = mediaStream;
          videoRef.current.play().catch(err => {
            console.error('Video play error:', err);
          });
        }
      }, 100);
    } catch (error) {
      console.error('❌ Camera error:', error);
      toast.error('Failed to access camera. Please check permissions.');
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCameraOpen(false);
  };

  const capturePhoto = () => {
    console.log('📸 Capturing photo...');
    if (!videoRef.current || !canvasRef.current) {
      console.error('❌ Video or canvas ref missing');
      return;
    }

    const video = videoRef.current;
    const canvas = canvasRef.current;
    
    console.log('📹 Video dimensions:', video.videoWidth, 'x', video.videoHeight);
    
    if (video.videoWidth === 0 || video.videoHeight === 0) {
      toast.error('Camera not ready, please wait a moment');
      return;
    }
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) {
      console.error('❌ Canvas context not available');
      return;
    }

    ctx.drawImage(video, 0, 0);
    const photoDataUrl = canvas.toDataURL('image/jpeg', 0.8);
    console.log('✅ Photo captured, data URL length:', photoDataUrl.length);
    setCapturedPhoto(photoDataUrl);
    stopCamera();
    toast.success('Photo captured successfully');
  };

  const retakePhoto = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  const handleLocationNext = () => {
    if (!selectedLocation) {
      toast.error('Please select a drop-off location');
      return;
    }
    // Only validate sub-location if signature is NOT required
    if (!signatureRequired) {
      const selectedLocationObj = locationOptions.find(loc => loc.id === selectedLocation);
      if (selectedLocationObj && selectedLocationObj.subLocations && selectedLocationObj.subLocations.length > 0 && !selectedSubLocation) {
        toast.error('Please select a specific drop-off area');
        return;
      }
    }
    // If signature is required, go to signature; otherwise go to photo
    if (signatureRequired) {
      setCurrentStep('signature');
    } else {
      setCurrentStep('photo');
    }
  };

  const handlePhotoNext = () => {
    if (!capturedPhoto) {
      toast.error('Please take a delivery photo');
      return;
    }
    // Photo flow goes directly to complete (no signature)
    handleComplete();
  };

  const handleComplete = async () => {
    if (!selectedLocation) return;
    
    // Validate based on which flow we're in
    if (signatureRequired) {
      // Signature flow: require signature and recipient name
      if (!signature) {
        toast.error('Please provide recipient signature');
        return;
      }
      if (!recipientName.trim()) {
        toast.error('Please enter recipient name');
        return;
      }
    } else {
      // Photo flow: require photo
      if (!capturedPhoto) {
        toast.error('Please take a delivery photo');
        return;
      }
    }

    setIsLoading(true);
    try {
      let photoBlob: Blob | undefined;
      
      // Only process photo if we're in the photo flow (signature not required)
      if (capturedPhoto && !signatureRequired) {
        const response = await fetch(capturedPhoto);
        photoBlob = await response.blob();
      }
      
      // Combine location and sub-location for more specific delivery info
      const locationLabel = locationOptions.find(loc => loc.id === selectedLocation)?.label || selectedLocation;
      const fullLocation = selectedSubLocation 
        ? `${locationLabel} - ${selectedSubLocation}`
        : locationLabel;

      await onDeliveryComplete({
        dropoffLocation: fullLocation,
        photoBlob,
        signature: signatureRequired ? signature : undefined,
        recipientName: signatureRequired ? recipientName.trim() : undefined
      });
      
      handleClose();
    } catch (error) {
      toast.error('Failed to complete delivery');
      console.error('Delivery completion error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    stopCamera();
    setSelectedLocation('');
    setSelectedSubLocation('');
    setCapturedPhoto(null);
    setSignature('');
    setRecipientName('');
    setCurrentStep(signatureRequired ? 'signature' : 'items');
    setCameraOpen(false);
    setItemsConfirmed(false);
    onClose();
  };

  const handleItemConfirmation = () => {
    setItemsConfirmed(true);
    setCurrentStep('location');
    toast.success('Items confirmed for delivery');
  };
  
  // Fetch Mapbox token and initialize map
  useEffect(() => {
    const fetchToken = async () => {
      try {
        const { data, error } = await supabase.functions.invoke('get-mapbox-token');
        if (error) throw error;
        if (data?.token) {
          setMapboxToken(data.token);
        }
      } catch (error) {
        console.error('Error fetching Mapbox token:', error);
      }
    };
    fetchToken();
  }, []);

  // Initialize map when expanded
  useEffect(() => {
    if (!mapExpanded || !mapboxToken || !mapContainerRef.current || dropoffLocations.length === 0) return;

    if (mapRef.current) return; // Map already initialized

    mapboxgl.accessToken = mapboxToken;
    
    const map = new mapboxgl.Map({
      container: mapContainerRef.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [-98.5795, 39.8283], // Default center (US)
      zoom: 12,
    });

    mapRef.current = map;

    map.on('load', () => {
      // Add delivery marker
      const deliveryLoc = dropoffLocations[0];
      const deliveryCoords = deliveryLoc?.coordinates || deliveryLoc?.location?.coordinates;
      if (deliveryCoords && Array.isArray(deliveryCoords) && deliveryCoords.length === 2) {
        new mapboxgl.Marker({ color: '#ef4444' })
          .setLngLat([deliveryCoords[0], deliveryCoords[1]])
          .setPopup(new mapboxgl.Popup().setHTML('<strong>Delivery Location</strong>'))
          .addTo(map);
        
        map.flyTo({
          center: [deliveryCoords[0], deliveryCoords[1]],
          zoom: 14,
        });
      }
    });

    return () => {
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    };
  }, [mapExpanded, mapboxToken, dropoffLocations]);

  // Cleanup camera on unmount or close
  useEffect(() => {
    if (!open) {
      stopCamera();
      setCapturedPhoto(null);
      setMapExpanded(false);
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
      }
    }
  }, [open]);

  // Signature pad handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.beginPath();
      ctx.moveTo(x, y);
    }
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = 'touches' in e ? e.touches[0].clientX - rect.left : e.clientX - rect.left;
    const y = 'touches' in e ? e.touches[0].clientY - rect.top : e.clientY - rect.top;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.lineTo(x, y);
      ctx.stroke();
    }
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    
    const canvas = signatureCanvasRef.current;
    if (canvas) {
      setSignature(canvas.toDataURL());
    }
  };

  const clearSignature = () => {
    const canvas = signatureCanvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      setSignature('');
    }
  };

  // Get delivery address from first dropoff location or default
  const deliveryAddress = dropoffLocations.length > 0 
    ? (dropoffLocations[0].address || dropoffLocations[0].label || 'Delivery location')
    : 'Delivery location';

  const formatAddress = (address: string) => {
    return address.replace(/, USA$/i, '').replace(/, United States$/i, '');
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
        <div className="sticky top-0 z-10 bg-background border-b flex-shrink-0">
          {/* Header */}
          <div className="px-4 py-3 flex items-center justify-between gap-3">
            <div className="flex-1 min-w-0">
              <DialogTitle className="text-lg font-semibold">
                {currentStep === 'items' && 'Confirm Picked Up Items'}
                {currentStep === 'location' && 'Select Drop-off Location'}
                {currentStep === 'photo' && 'Take Delivery Photo'}
                {currentStep === 'signature' && 'Recipient Signature'}
              </DialogTitle>
              <DialogDescription className="sr-only">
                {currentStep === 'items' && 'Verify items before proceeding.'}
                {currentStep === 'location' && 'Choose the drop-off location type and area.'}
                {currentStep === 'photo' && 'Capture a clear delivery photo.'}
                {currentStep === 'signature' && 'Collect recipient signature if required.'}
              </DialogDescription>
            </div>
            <div className="flex items-center gap-1">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={() => setNotesModalOpen(true)} 
                aria-label="View job notes"
                disabled={!job}
              >
                <FileText className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={() => setSupportModalOpen(true)} aria-label="Contact support">
                <HelpCircle className="h-5 w-5" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleClose} aria-label="Close delivery modal">
                <X className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Timeline Progress */}
          <div className="px-4 py-2 bg-muted/30">
            <div className="flex items-center justify-between text-xs">
              <div className={`flex items-center gap-1 ${itemsConfirmed ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${itemsConfirmed ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  {itemsConfirmed ? <CheckCircle2 className="w-4 h-4" /> : '1'}
                </div>
                <span>Verify</span>
              </div>
              <div className={`flex-1 h-px mx-2 ${selectedLocation ? 'bg-primary' : 'bg-border'}`} />
              <div className={`flex items-center gap-1 ${selectedLocation ? 'text-primary font-medium' : 'text-muted-foreground'}`}>
                <div className={`w-6 h-6 rounded-full flex items-center justify-center ${selectedLocation ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                  {selectedLocation ? <CheckCircle2 className="w-4 h-4" /> : '2'}
                </div>
                <span>Deliver</span>
              </div>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Item Confirmation Screen */}
          {currentStep === 'items' && (
            <>
              <div className="flex items-start gap-3 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <Package className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium">Verify Pickup Items</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Review the pickup photo below and confirm that all items shown have been picked up and are ready for delivery.
                  </p>
                </div>
              </div>

              <div className="flex-1 min-h-0 flex flex-col">
                <h3 className="font-semibold text-sm mb-2">Pickup Photo</h3>
                <div className="relative h-96 bg-muted rounded-lg overflow-hidden border border-border">
                  {pickupPhotoUrl ? (
                    <img 
                      src={pickupPhotoUrl} 
                      alt="Pickup photo"
                      className="absolute inset-0 w-full h-full object-contain"
                      loading="lazy"
                    />
                  ) : (
                    <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                      <Package className="h-12 w-12 mb-2" />
                      <p className="text-sm">No pickup photo available</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="pt-8">
                <Button
                  size="lg"
                  onClick={handleItemConfirmation}
                  className="w-full"
                  disabled={!pickupPhotoUrl}
                >
                  <CheckCircle2 className="mr-2 h-5 w-5" />
                  Confirm Items
                </Button>
              </div>
            </>
          )}

          {/* Existing Location/Photo/Signature Steps */}
          {currentStep === 'location' && (
            <>
              <div className="space-y-2">
                <Label htmlFor="location" className="text-xs sm:text-sm">Drop-off Location Type *</Label>
                <Select 
                  value={selectedLocation} 
                  onValueChange={(value) => {
                    setSelectedLocation(value);
                    setSelectedSubLocation(''); // Reset sub-location when main location changes
                  }}
                >
                  <SelectTrigger className="h-8 sm:h-10 text-xs sm:text-sm">
                    <SelectValue placeholder="Select a location type" />
                  </SelectTrigger>
                  <SelectContent position="popper" sideOffset={4} className="z-[9999] bg-popover border shadow-lg">
                    {locationOptions
                      .filter(loc => signatureRequired ? loc.id === 'customer' : true)
                      .map((loc) => (
                        <SelectItem key={loc.id} value={loc.id} className="text-xs sm:text-sm">
                          {loc.label}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Sub-location dropdown - only show if main location is selected and has sub-locations, but hide for customer or when signature is required */}
              {!signatureRequired && selectedLocation && selectedLocation !== 'customer' && locationOptions.find(loc => loc.id === selectedLocation)?.subLocations && locationOptions.find(loc => loc.id === selectedLocation)!.subLocations!.length > 0 && (
                <div className="space-y-2">
                  <Label htmlFor="subLocation" className="text-xs sm:text-sm">Specific Delivery Area *</Label>
                  <Select value={selectedSubLocation} onValueChange={setSelectedSubLocation}>
                    <SelectTrigger className="h-8 sm:h-10 text-xs sm:text-sm">
                      <SelectValue placeholder="Select specific area" />
                    </SelectTrigger>
                    <SelectContent position="popper" sideOffset={4} className="z-[9999] bg-popover border shadow-lg">
                      {locationOptions
                        .find(loc => loc.id === selectedLocation)
                        ?.subLocations?.map((subLoc, idx) => (
                          <SelectItem key={idx} value={subLoc} className="text-xs sm:text-sm">
                            {subLoc}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <Button onClick={handleLocationNext} className="w-full text-xs sm:text-sm" size="sm">
                {signatureRequired ? 'Next: Signature' : 'Next: Take Photo'}
              </Button>
            </>
          )}

          {currentStep === 'photo' && (
            <>
              {/* Camera View or Action Card */}
              {cameraOpen ? (
                <div className="fixed inset-0 z-50 bg-black flex flex-col">
                  {/* Camera Header */}
                  <div className="sticky top-0 z-10 bg-black/80 backdrop-blur-sm px-4 py-3 flex-shrink-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold text-white">Camera</h3>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={stopCamera}
                        className="text-white hover:bg-white/20"
                      >
                        <X className="h-5 w-5" />
                      </Button>
                    </div>
                  </div>

                  {/* Full screen video */}
                  <div className="flex-1 relative">
                    <video
                      ref={videoRef}
                      autoPlay
                      playsInline
                      muted
                      className="w-full h-full object-cover"
                      onLoadedMetadata={() => console.log('✅ Video metadata loaded')}
                      onPlay={() => console.log('▶️ Video playing')}
                    />
                  </div>

                  <canvas ref={canvasRef} className="hidden" />

                  {/* Camera Controls */}
                  <div className="fixed bottom-0 left-0 right-0 z-10 bg-black/80 backdrop-blur-sm p-4 pb-safe">
                    <div className="flex gap-4 justify-center max-w-md mx-auto">
                      <Button onClick={capturePhoto} size="lg" className="flex-1 bg-white text-black hover:bg-white/90">
                        <Camera className="mr-2 h-5 w-5" />
                        Capture Photo
                      </Button>
                      <Button onClick={stopCamera} variant="outline" size="lg" className="flex-1 border-white text-white hover:bg-white/20">
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <Card className="p-4 space-y-4">
                  <h3 className="font-semibold">Delivery Actions</h3>
                  
                  {/* Canvas for photo capture */}
                  <canvas ref={canvasRef} className="hidden" />
                  
                  {/* Take Photo */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                          capturedPhoto ? 'bg-primary/20' : 'bg-muted'
                        }`}>
                          <Camera className={`h-5 w-5 ${capturedPhoto ? 'text-primary' : 'text-muted-foreground'}`} />
                        </div>
                        <div>
                          <p className="font-medium text-sm">Delivery Photo</p>
                          <p className="text-xs text-muted-foreground">
                            {capturedPhoto ? 'Photo captured ✓' : 'Capture delivery photo'}
                          </p>
                        </div>
                      </div>
                      {!capturedPhoto && (
                        <Button size="sm" onClick={startCamera}>
                          Take Photo
                        </Button>
                      )}
                    </div>
                    
                    {/* Show captured photo preview */}
                    {capturedPhoto && (
                      <div className="relative rounded-lg overflow-hidden border border-border">
                        <img 
                          src={capturedPhoto} 
                          alt="Captured delivery photo"
                          className="w-full h-48 object-cover"
                          loading="lazy"
                        />
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={retakePhoto}
                          className="absolute bottom-2 right-2"
                        >
                          Retake
                        </Button>
                      </div>
                    )}
                  </div>
                </Card>
              )}

              {/* Instructions - only show when camera is not open */}
              {!cameraOpen && (
                <Card className="p-4 bg-primary/5 border-primary/20">
                  <h4 className="font-semibold text-sm mb-2">Delivery Instructions</h4>
                  <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                    <li>Verify delivery address matches the location</li>
                    <li>Take clear photos of delivered packages</li>
                    <li>Ensure package is secure at drop-off location</li>
                  </ul>
                </Card>
              )}

              {/* Mark as Delivered Button - only show when camera is not open */}
              {!cameraOpen && (
                <Button 
                  onClick={handleComplete} 
                  disabled={!capturedPhoto || isLoading}
                  className="w-full"
                  size="lg"
                >
                  {isLoading ? 'Completing...' : 'Mark as Delivered'}
                </Button>
              )}
            </>
          )}

          {currentStep === 'signature' && (
            <>
              <Card className="p-4 space-y-4">
                <h3 className="font-semibold">Delivery Signature</h3>
                
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="recipientName" className="text-xs sm:text-sm">Recipient Name *</Label>
                    <Input
                      id="recipientName"
                      type="text"
                      placeholder="Enter recipient's full name"
                      value={recipientName}
                      onChange={(e) => setRecipientName(e.target.value)}
                      className="h-8 sm:h-10 text-xs sm:text-sm"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-xs sm:text-sm">Recipient Signature *</Label>
                    <div className="border-2 border-dashed rounded-lg p-1 bg-white">
                      <canvas
                        ref={signatureCanvasRef}
                        width={500}
                        height={120}
                        className="w-full touch-none cursor-crosshair"
                        style={{ maxHeight: '120px' }}
                        onMouseDown={startDrawing}
                        onMouseMove={draw}
                        onMouseUp={stopDrawing}
                        onMouseLeave={stopDrawing}
                        onTouchStart={startDrawing}
                        onTouchMove={draw}
                        onTouchEnd={stopDrawing}
                      />
                    </div>
                    <Button onClick={clearSignature} variant="outline" size="sm" className="w-full sm:w-auto text-xs sm:text-sm">
                      Clear Signature
                    </Button>
                  </div>
                </div>
              </Card>

              {/* Instructions */}
              <Card className="p-4 bg-primary/5 border-primary/20">
                <h4 className="font-semibold text-sm mb-2">Signature Instructions</h4>
                <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Request recipient's full name</li>
                  <li>Obtain clear signature on device</li>
                  <li>Verify signature matches recipient identity</li>
                </ul>
              </Card>

              {/* Mark as Delivered Button */}
              <Button 
                onClick={handleComplete} 
                disabled={!signature || !recipientName.trim() || isLoading}
                className="w-full"
                size="lg"
              >
                {isLoading ? 'Completing...' : 'Mark as Delivered'}
              </Button>
            </>
          )}
        </div>
      </DialogContent>

      {/* Job Notes Modal */}
      {job && (
        <JobNotesModal 
          open={notesModalOpen} 
          onOpenChange={setNotesModalOpen} 
          job={job} 
        />
      )}

      {/* Driver Support Modal */}
      <DriverSupportModal 
        open={supportModalOpen} 
        onClose={() => setSupportModalOpen(false)}
        jobId={job?.id}
        context="delivery"
      />
    </Dialog>
  );
}