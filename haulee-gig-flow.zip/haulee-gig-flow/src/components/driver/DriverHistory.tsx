import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar, MapPin, DollarSign, Clock, Star, Package, Search, TrendingUp, CheckCircle } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { DriverJobDetailsDialog } from './DriverJobDetailsDialog';
export function DriverHistory() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [selectedAssignment, setSelectedAssignment] = useState<any>(null);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);

  // Fetch completed jobs
  const {
    data: completedJobs = [],
    isLoading
  } = useQuery({
    queryKey: ['driver-completed-jobs'],
    queryFn: async () => {
      const {
        data: {
          user
        }
      } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      const {
        data,
        error
      } = await supabase.from('job_assignments').select(`
          *,
          jobs (*)
        `).eq('driver_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', {
        ascending: false
      });
      if (error) throw error;
      return data || [];
    },
    refetchInterval: 10000 // Auto-refresh every 10 seconds
  });

  // Calculate statistics
  const totalEarnings = completedJobs.reduce((sum, assignment: any) => {
    return sum + (parseFloat(assignment.jobs?.pay_amount) || 0);
  }, 0);
  const totalJobs = completedJobs.length;
  const totalDistance = completedJobs.reduce((sum, assignment: any) => {
    return sum + (parseFloat(assignment.jobs?.distance_miles) || 0);
  }, 0);
  const avgRating = completedJobs.reduce((sum, assignment: any) => {
    return sum + (assignment.rating || 0);
  }, 0) / (completedJobs.filter((a: any) => a.rating).length || 1);

  // Filter jobs based on search
  const filteredJobs = completedJobs.filter((assignment: any) => {
    const job = assignment.jobs;
    if (!job) return false;
    const searchLower = searchTerm.toLowerCase();
    return job.title?.toLowerCase().includes(searchLower) || job.pickup_location?.address?.toLowerCase().includes(searchLower) || job.delivery_location?.address?.toLowerCase().includes(searchLower);
  });
  return <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Job History</h2>
        <p className="text-muted-foreground">Review your completed deliveries and earnings</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalEarnings.toFixed(2)}</div>
            <p className="text-xs text-muted-foreground">All time</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Jobs</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalJobs}</div>
            <p className="text-xs text-muted-foreground">Deliveries</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Distance Driven</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalDistance.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">Miles</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rating</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgRating.toFixed(1)}</div>
            <p className="text-xs text-muted-foreground">Out of 5.0</p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filter */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search jobs by title or location..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} className="pl-9" />
        </div>
      </div>

      {/* Job History List */}
      <div>
        <h3 className="text-lg font-semibold mb-4">Completed Deliveries</h3>
        {isLoading ? <p className="text-sm text-muted-foreground text-center py-8">Loading history...</p> : filteredJobs.length === 0 ? <div className="text-center py-8 space-y-2">
            <Package className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              {searchTerm ? 'No jobs match your search' : 'No completed jobs yet'}
            </p>
            {!searchTerm && <p className="text-xs text-muted-foreground">
                Start claiming and completing jobs to build your history
              </p>}
          </div> : <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredJobs.map((assignment: any) => {
          const job = assignment.jobs;
          if (!job) return null;
          const completedAt = assignment.completed_at ? new Date(assignment.completed_at) : null;
          return <Card key={assignment.id} className="hover:shadow-md transition-shadow cursor-pointer" onClick={() => {
            setSelectedJob(job);
            setSelectedAssignment(assignment);
            setDetailsDialogOpen(true);
          }}>
                  <CardContent className="p-4 space-y-3">
                    <div>
                      <h4 className="font-semibold text-base line-clamp-2">{job.title}</h4>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Amount</span>
                      <Badge variant="secondary" className="font-semibold">
                        ${job.pay_amount || '0'}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between">
                      {completedAt && <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Calendar className="h-4 w-4" />
                          <span>{format(completedAt, 'MMM d, yyyy')}</span>
                        </div>}
                      <Badge className="bg-green-600 hover:bg-green-700 text-white">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Completed
                      </Badge>
                    </div>
                  </CardContent>
                </Card>;
        })}
          </div>}
      </div>

      {/* Job Details Dialog */}
      {detailsDialogOpen && selectedJob && <div className="fixed inset-0 z-50 bg-background/80 backdrop-blur-sm" onClick={() => setDetailsDialogOpen(false)}>
          <div className="fixed left-[50%] top-[50%] z-50 w-full max-w-2xl translate-x-[-50%] translate-y-[-50%] p-4" onClick={e => e.stopPropagation()}>
            <div className="bg-background border rounded-lg shadow-lg p-6 max-h-[90vh] overflow-y-auto">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="font-semibold text-lg">{selectedJob.title}</h2>
                  <button onClick={() => setDetailsDialogOpen(false)} className="text-muted-foreground hover:text-foreground">
                    ✕
                  </button>
                </div>

                <div className="space-y-3">
                  {/* Completion Time */}
                  {selectedAssignment?.completed_at && <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                      <div className="flex items-center gap-2 text-green-700 dark:text-green-300">
                        <CheckCircle className="h-5 w-5" />
                        <div>
                          <p className="font-semibold">Completed</p>
                          <p className="text-sm">
                            {format(new Date(selectedAssignment.completed_at), 'MMM d, yyyy')} at {format(new Date(selectedAssignment.completed_at), 'h:mm a')}
                          </p>
                        </div>
                      </div>
                    </div>}

                  {/* Pickup Location */}
                  <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <div className="flex items-start gap-2">
                      <MapPin className="h-5 w-5 text-blue-600 mt-0.5" />
                      <div className="flex-1">
                        <p className="font-semibold text-sm">Pickup Location</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {selectedJob.pickup_location?.address || 'N/A'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Delivery Location */}
                  <div className="p-3 bg-orange-50 dark:bg-orange-950 rounded-lg">
                    <div className="flex items-start gap-2">
                      <MapPin className="h-5 w-5 text-orange-600 mt-0.5" />
                      <div className="flex-1">
                        <p className="font-semibold text-sm">Delivery Location</p>
                        <p className="text-sm text-muted-foreground mt-1">
                          {selectedJob.delivery_location?.address || 'N/A'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Job Details */}
                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <div>
                      <p className="text-sm text-muted-foreground">Pay Amount</p>
                      <p className="text-lg font-semibold">${selectedJob.pay_amount || '0'}</p>
                    </div>
                    {selectedJob.distance_miles && <div>
                        <p className="text-sm text-muted-foreground">Distance</p>
                        <p className="text-lg font-semibold">{selectedJob.distance_miles} miles</p>
                      </div>}
                  </div>

                  {selectedJob.description && <div className="pt-2 border-t">
                      <p className="text-sm font-medium">Description</p>
                      <p className="text-sm text-muted-foreground mt-1">{selectedJob.description}</p>
                    </div>}
                </div>
              </div>
            </div>
          </div>
        </div>}
    </div>;
}