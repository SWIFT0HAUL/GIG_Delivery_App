import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CheckCircle, X, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface ItemConfirmationModalProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  pickupPhotoUrl?: string;
}

export function ItemConfirmationModal({ 
  open, 
  onClose, 
  onConfirm,
  pickupPhotoUrl 
}: ItemConfirmationModalProps) {

  const handleConfirm = () => {
    onConfirm();
    toast.success('Items confirmed for delivery');
  };

  const handleCancel = () => {
    onClose();
    toast.info('Item confirmation cancelled');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-background border-b px-4 py-3 flex-shrink-0">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold text-lg">Confirm Picked Up Items</h2>
            <Button
              variant="ghost"
              size="icon"
              onClick={handleCancel}
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 min-h-0 flex flex-col gap-4 p-4 pb-28 overflow-hidden">
          {/* Instruction Card */}
          <div className="flex items-start gap-3 p-4 bg-primary/5 border border-primary/20 rounded-lg">
            <AlertCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium">Verify Pickup Items</p>
              <p className="text-xs text-muted-foreground mt-1">
                Review the pickup photo below and confirm that all items shown have been picked up and are ready for delivery.
              </p>
            </div>
          </div>

          {/* Pickup Photo - Fills remaining space */}
          <div className="flex-1 min-h-0 flex flex-col">
            <h3 className="font-semibold text-sm mb-2">Pickup Photo</h3>
            <div className="relative flex-1 min-h-0 bg-muted rounded-lg overflow-hidden border border-border">
              {pickupPhotoUrl ? (
                <img 
                  src={pickupPhotoUrl} 
                  alt="Pickup photo"
                  className="absolute inset-0 w-full h-full object-contain"
                  loading="lazy"
                />
              ) : (
                <div className="absolute inset-0 flex flex-col items-center justify-center text-muted-foreground">
                  <AlertCircle className="h-12 w-12 mb-2" />
                  <p className="text-sm">No pickup photo available</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons - Fixed at bottom */}
        <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-4 z-20">
          <div className="flex gap-3">
            <Button
              variant="outline"
              size="lg"
              onClick={handleCancel}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              size="lg"
              onClick={handleConfirm}
              className="flex-1"
              disabled={!pickupPhotoUrl}
            >
              <CheckCircle className="mr-2 h-5 w-5" />
              Confirm Items
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
