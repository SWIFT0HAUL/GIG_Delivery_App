import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { SlideToConfirm } from './SlideToConfirm';
import { supabase } from '@/integrations/supabase/client';
import { 
  FileText, 
  Navigation, 
  Phone, 
  MapPin, 
  Package,
  Play,
  CheckCircle,
  XCircle
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface StopDetailsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  stop: any;
  onStart: () => void;
  onMarkInProgress?: () => Promise<void>;
  pickupPhotoUrl?: string;
}

export const StopDetailsModal: React.FC<StopDetailsModalProps> = ({
  open,
  onOpenChange,
  stop,
  onStart,
  onMarkInProgress,
  pickupPhotoUrl: propPickupPhotoUrl,
}) => {
  const [slideConfirmed, setSlideConfirmed] = useState(false);
  const [isStarted, setIsStarted] = useState(false);
  const [hasMarkedArrival, setHasMarkedArrival] = useState(false);
  const [photoConfirmed, setPhotoConfirmed] = useState(false);
  const [fetchedPickupPhotoUrl, setFetchedPickupPhotoUrl] = useState<string | null>(null);
  const { toast } = useToast();

  // Reset states when modal opens or stop changes
  React.useEffect(() => {
    if (open) {
      setHasMarkedArrival(false);
      setPhotoConfirmed(false);
      setIsStarted(false);
      setSlideConfirmed(false);
    }
  }, [open, stop?.id]);

  // Fetch pickup photo for delivery stops
  React.useEffect(() => {
    if (!stop || stop.stop_type === 'pickup' || !stop.job_id) return;

    const fetchPickupPhoto = async () => {
      const { data, error } = await supabase
        .from('route_stops')
        .select('proof_photo_url')
        .eq('job_id', stop.job_id)
        .eq('stop_type', 'pickup')
        .single();

      if (data?.proof_photo_url) {
        setFetchedPickupPhotoUrl(data.proof_photo_url);
      }
    };

    fetchPickupPhoto();
  }, [stop]);

  if (!stop) return null;

  const isPickup = stop.stop_type === 'pickup';
  const location = stop.location?.address || (isPickup ? stop.pickup_location : stop.delivery_location);
  const contact = isPickup ? stop.pickup_contact : stop.delivery_contact;
  const phoneNumber = isPickup ? stop.pickup_phone : stop.delivery_phone;
  const instructions = isPickup ? stop.pickup_instructions : stop.delivery_instructions;
  const job = stop.job;
  const pickupPhotoUrl = propPickupPhotoUrl || fetchedPickupPhotoUrl || stop.pickup_photo_url || stop.proof_photo_url || job?.pickup_photo_url;

  console.log('Stop details:', { 
    isPickup, 
    hasMarkedArrival, 
    pickupPhotoUrl, 
    fetchedPickupPhotoUrl,
    propPickupPhotoUrl,
    stop_pickup_photo: stop.pickup_photo_url,
    stop_proof_photo: stop.proof_photo_url,
    job_pickup_photo: job?.pickup_photo_url,
    full_stop: stop,
    full_job: job
  });

  const handleNavigate = () => {
    if (location) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(location)}`;
      window.open(url, '_blank');
    }
  };

  const handleCall = () => {
    if (phoneNumber) {
      window.location.href = `tel:${phoneNumber}`;
    } else {
      toast({
        variant: 'destructive',
        title: 'No phone number',
        description: isPickup ? 'No pickup contact number available.' : 'No recipient phone number available.',
      });
    }
  };
  const handleSlideComplete = () => {
    setSlideConfirmed(true);
    setHasMarkedArrival(true);
    setSlideConfirmed(false);
  };

  const handleStartClick = async () => {
    try {
      if (onMarkInProgress) {
        await onMarkInProgress();
      }
    } catch (error) {
      console.error('Error marking job in progress:', error);
    } finally {
      setIsStarted(true);
    }
  };

  const handlePrimaryActionClick = async () => {
    if ((isPickup && hasMarkedArrival) || (!isPickup && photoConfirmed)) {
      try {
        if (onMarkInProgress) {
          await onMarkInProgress();
        }
      } catch (error) {
        console.error('Error marking job in progress:', error);
      } finally {
        setIsStarted(true);
        onStart();
      }
    } else {
      await handleStartClick();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-[95vw] max-w-md max-h-[95vh] p-0 gap-0 overflow-hidden border-2 shadow-2xl animate-scale-in flex flex-col">
        <DialogHeader className="px-3 sm:px-6 pt-3 sm:pt-6 pb-2 sm:pb-4 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 flex-shrink-0">
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-1 min-w-0 flex-1">
              <DialogTitle className="text-base sm:text-xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent truncate">
                {isPickup ? 'Pickup' : 'Delivery'} Stop
              </DialogTitle>
              <p className="text-xs sm:text-sm font-medium text-muted-foreground flex items-center gap-1 sm:gap-2">
                <MapPin className="h-3 w-3 sm:h-3.5 sm:w-3.5 flex-shrink-0" />
                <span className="truncate">Stop #{stop.stop_sequence}</span>
              </p>
            </div>
            <div className="flex flex-col items-end gap-1 sm:gap-2 flex-shrink-0">
              <Badge 
                variant={isPickup ? 'default' : 'secondary'} 
                className="shadow-sm px-2 sm:px-3 py-0.5 sm:py-1 font-semibold animate-fade-in text-xs"
              >
                {isPickup ? 'Pickup' : 'Delivery'}
              </Badge>
              <div className="flex items-center gap-1 sm:gap-2">
                <button
                  onClick={handleNavigate}
                  disabled={!isStarted}
                  className={`h-8 w-8 sm:h-10 sm:w-10 rounded-full flex items-center justify-center transition-all duration-300 shadow-md flex-shrink-0 ${
                    isStarted 
                      ? 'bg-gradient-to-br from-primary to-primary/80 hover:shadow-lg hover:scale-110 animate-[pulse_2s_ease-in-out_infinite]' 
                      : 'bg-muted cursor-not-allowed opacity-50'
                  }`}
                >
                  <Navigation className={`h-3 w-3 sm:h-4 sm:w-4 ${isStarted ? 'text-primary-foreground' : 'text-muted-foreground'}`} />
                </button>
                <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-gradient-to-br from-accent to-accent/80 flex items-center justify-center shadow-md flex-shrink-0">
                  <FileText className="h-3 w-3 sm:h-4 sm:w-4 text-accent-foreground" />
                </div>
              </div>
            </div>
          </div>
        </DialogHeader>

        <Separator className="bg-gradient-to-r from-transparent via-border to-transparent flex-shrink-0" />

        <div className="px-3 sm:px-6 py-3 sm:py-5 space-y-2 sm:space-y-4 overflow-y-auto flex-1 min-h-0">
          {/* Location */}
          <Card className="p-3 sm:p-5 bg-gradient-to-br from-primary/5 to-accent/5 border-l-4 border-l-primary shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in">
            <div className="flex items-start gap-2 sm:gap-4">
              <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                <MapPin className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start sm:items-center justify-between mb-1 sm:mb-2 gap-2">
                  <p className="text-xs sm:text-sm font-bold text-foreground">Location</p>
                  <Badge 
                    variant={!isStarted ? 'secondary' : isPickup ? 'default' : 'outline'} 
                    className="text-[10px] sm:text-xs shadow-sm font-medium animate-fade-in flex-shrink-0"
                  >
                    {!isStarted 
                      ? 'Not Started' 
                      : isPickup 
                        ? 'En Route' 
                        : 'En Route'}
                  </Badge>
                </div>
                <p className="text-xs sm:text-sm text-muted-foreground break-words leading-relaxed">
                  {location || 'No location provided'}
                </p>
              </div>
            </div>
          </Card>

          {/* Contact */}
          {contact && (
            <Card className="p-3 sm:p-5 bg-gradient-to-br from-secondary/5 to-accent/5 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in">
              <div className="flex items-start gap-2 sm:gap-4">
                <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-secondary/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="h-4 w-4 sm:h-5 sm:w-5 text-secondary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm font-bold text-foreground mb-1 sm:mb-2">Contact</p>
                  <p className="text-xs sm:text-sm text-muted-foreground font-medium break-words">{contact}</p>
                  {phoneNumber && (
                    <p className="text-xs sm:text-sm text-primary font-bold mt-1 sm:mt-2 flex items-center gap-1 sm:gap-2">
                      <Phone className="h-3 w-3 sm:h-3.5 sm:w-3.5 flex-shrink-0" />
                      <span className="break-all">{phoneNumber}</span>
                    </p>
                  )}
                </div>
              </div>
            </Card>
          )}

          {/* Instructions */}
          {instructions && (
            <Card className="p-3 sm:p-5 bg-gradient-to-br from-accent/10 to-accent/5 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in">
              <div className="flex items-start gap-2 sm:gap-4">
                <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <FileText className="h-4 w-4 sm:h-5 sm:w-5 text-accent-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm font-bold text-foreground mb-1 sm:mb-2">Instructions</p>
                  <p className="text-xs sm:text-sm text-muted-foreground break-words leading-relaxed">
                    {instructions}
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Package Info */}
          {stop.package_description && (
            <Card className="p-3 sm:p-5 bg-gradient-to-br from-primary/5 to-secondary/5 shadow-sm hover:shadow-md transition-all duration-300 animate-fade-in">
              <div className="flex items-start gap-2 sm:gap-4">
                <div className="h-8 w-8 sm:h-10 sm:w-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Package className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs sm:text-sm font-bold text-foreground mb-1 sm:mb-2">Package</p>
                  <p className="text-xs sm:text-sm text-muted-foreground break-words leading-relaxed">
                    {stop.package_description}
                  </p>
                </div>
              </div>
            </Card>
          )}

          {/* Photo Confirmation for Delivery */}
          {!isPickup && hasMarkedArrival && !photoConfirmed && pickupPhotoUrl && (
            <Card className="p-3 sm:p-5 bg-gradient-to-br from-primary/10 to-primary/5 border-2 border-primary shadow-lg animate-scale-in">
              <div className="space-y-2 sm:space-y-4">
                <p className="text-xs sm:text-sm font-bold text-center flex items-center justify-center gap-1 sm:gap-2">
                  <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 text-primary flex-shrink-0" />
                  <span>Confirm Pickup Photo</span>
                </p>
                <div className="relative w-full aspect-video rounded-lg sm:rounded-xl overflow-hidden bg-muted shadow-md border-2 border-primary/20">
                  <img 
                    src={pickupPhotoUrl} 
                    alt="Pickup photo" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2 sm:gap-3">
                  <Button
                    onClick={() => setPhotoConfirmed(true)}
                    className="w-full shadow-md hover:shadow-lg transition-all duration-300 font-semibold text-xs sm:text-sm h-9 sm:h-11"
                    variant="default"
                  >
                    <CheckCircle className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                    Confirm
                  </Button>
                  <Button
                    onClick={() => onOpenChange(false)}
                    className="w-full shadow-sm hover:shadow-md transition-all duration-300 font-semibold text-xs sm:text-sm h-9 sm:h-11"
                    variant="outline"
                  >
                    <XCircle className="h-3 w-3 sm:h-4 sm:w-4 mr-1 sm:mr-2" />
                    Cancel
                  </Button>
                </div>
              </div>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="grid grid-cols-2 gap-2 sm:gap-4 pt-1 sm:pt-2">
            <Button
              onClick={handlePrimaryActionClick}
              className="w-full shadow-lg hover:shadow-xl transition-all duration-300 font-bold text-xs sm:text-base hover:scale-105 h-9 sm:h-11"
              variant="default"
              disabled={isStarted && (isPickup ? !hasMarkedArrival : !photoConfirmed)}
            >
              <Play className="h-3 w-3 sm:h-5 sm:w-5 mr-1 sm:mr-2" />
              {isStarted ? (isPickup ? 'Pick up' : 'Deliver') : 'Start'}
            </Button>
            <Button
              variant="outline"
              onClick={handleCall}
              disabled={!isStarted}
              className="w-full shadow-md hover:shadow-lg transition-all duration-300 font-bold text-xs sm:text-base hover:scale-105 h-9 sm:h-11"
            >
              <Phone className="h-3 w-3 sm:h-5 sm:w-5 mr-1 sm:mr-2" />
              <span className="hidden sm:inline">{isPickup ? 'Call Contact' : 'Call Recipient'}</span>
              <span className="sm:hidden">Call</span>
            </Button>
          </div>
        </div>

        <Separator className="bg-gradient-to-r from-transparent via-border to-transparent flex-shrink-0" />

        {!hasMarkedArrival && (
          <div className="px-3 sm:px-6 py-3 sm:py-5 bg-gradient-to-br from-accent/5 to-transparent flex-shrink-0">
            {/* Slide to Confirm */}
            <SlideToConfirm
              text={isPickup ? "Slide to mark arrival at pickup" : "Slide to mark arrival at drop-off"}
              confirmedText={isPickup ? "Arrived at pickup!" : "Arrived at drop-off!"}
              onConfirm={handleSlideComplete}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
