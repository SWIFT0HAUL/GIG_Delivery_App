import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { LocationCoordinates } from '@/lib/locationUtils';
import { Loader2 } from 'lucide-react';

interface DeliveryRadiusMapProps {
  targetLocation: LocationCoordinates;
  driverLocation: LocationCoordinates | null;
  radiusMeters: number;
  actionType: 'pickup' | 'dropoff';
}

export function DeliveryRadiusMap({
  targetLocation,
  driverLocation,
  radiusMeters,
  actionType,
}: DeliveryRadiusMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<google.maps.Map | null>(null);
  const radiusCircleRef = useRef<google.maps.Circle | null>(null);
  const driverMarkerRef = useRef<google.maps.Marker | null>(null);
  const targetMarkerRef = useRef<google.maps.Marker | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load Google Maps API
  useEffect(() => {
    const loadGoogleMaps = async () => {
      try {
        // Check if already loaded
        if (window.google?.maps) {
          setIsLoading(false);
          return;
        }

        const { data, error } = await supabase.functions.invoke('get-mapbox-token');
        
        if (error) throw error;

        // For now, we'll use a placeholder since we need Google Maps API key
        // In production, you'd load the actual Google Maps script here
        setError('Google Maps API key not configured. Please add GOOGLE_MAPS_API_KEY to Supabase secrets.');
        setIsLoading(false);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load maps');
        setIsLoading(false);
      }
    };

    loadGoogleMaps();
  }, []);

  // Initialize map
  useEffect(() => {
    if (!mapContainerRef.current || !window.google?.maps || !targetLocation) return;

    if (!mapRef.current) {
      mapRef.current = new google.maps.Map(mapContainerRef.current, {
        center: targetLocation,
        zoom: 18,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: false,
      });
    }
  }, [targetLocation]);

  // Update radius circle
  useEffect(() => {
    if (!mapRef.current || !window.google?.maps) return;

    // Remove old circle
    if (radiusCircleRef.current) {
      radiusCircleRef.current.setMap(null);
    }

    // Create new circle
    radiusCircleRef.current = new google.maps.Circle({
      map: mapRef.current,
      center: targetLocation,
      radius: radiusMeters,
      fillColor: actionType === 'pickup' ? '#3b82f6' : '#10b981',
      fillOpacity: 0.2,
      strokeColor: actionType === 'pickup' ? '#3b82f6' : '#10b981',
      strokeOpacity: 0.8,
      strokeWeight: 2,
    });

    // Update target marker
    if (!targetMarkerRef.current) {
      targetMarkerRef.current = new google.maps.Marker({
        map: mapRef.current,
        position: targetLocation,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 8,
          fillColor: actionType === 'pickup' ? '#3b82f6' : '#10b981',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 2,
        },
        title: actionType === 'pickup' ? 'Pickup Location' : 'Drop-off Location',
      });
    } else {
      targetMarkerRef.current.setPosition(targetLocation);
    }
  }, [targetLocation, radiusMeters, actionType]);

  // Update driver marker
  useEffect(() => {
    if (!mapRef.current || !window.google?.maps || !driverLocation) return;

    if (!driverMarkerRef.current) {
      driverMarkerRef.current = new google.maps.Marker({
        map: mapRef.current,
        position: driverLocation,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 10,
          fillColor: '#ef4444',
          fillOpacity: 1,
          strokeColor: '#ffffff',
          strokeWeight: 3,
        },
        title: 'Your Location',
      });
    } else {
      driverMarkerRef.current.setPosition(driverLocation);
    }

    // Recenter map to show both locations
    const bounds = new google.maps.LatLngBounds();
    bounds.extend(targetLocation);
    bounds.extend(driverLocation);
    mapRef.current.fitBounds(bounds);
  }, [driverLocation, targetLocation]);

  if (isLoading) {
    return (
      <div className="w-full h-64 flex items-center justify-center bg-muted rounded-lg">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="w-full h-64 flex items-center justify-center bg-muted rounded-lg">
        <p className="text-sm text-muted-foreground">{error}</p>
      </div>
    );
  }

  return (
    <div ref={mapContainerRef} className="w-full h-64 rounded-lg overflow-hidden" />
  );
}
