import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { FileUpload } from '@/components/FileUpload';
import { Combobox, ComboboxOption } from '@/components/ui/combobox';
import { Car, FileText, User, Camera, LogOut, CreditCard, Bell, Shield, Smartphone, Key, Lock, Sun, Moon, Monitor } from 'lucide-react';
import { toast } from 'sonner';
import { DeleteAccountSection } from '@/components/profile/DeleteAccountSection';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { VEHICLE_MODELS } from '@/lib/vehicleModels';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';
import { useDriverProfileData } from '@/hooks/useDriverProfileData';
import { Switch } from '@/components/ui/switch';
import { MapPin } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useLanguageSync } from '@/hooks/useLanguageSync';

// Vehicle options - generated from VEHICLE_MODELS
const vehicleMakes: ComboboxOption[] = Object.keys(VEHICLE_MODELS)
  .sort()
  .map(make => ({ value: make, label: make }));

const makeToModels: Record<string, ComboboxOption[]> = Object.entries(VEHICLE_MODELS).reduce((acc, [make, models]) => {
  acc[make] = models.map(model => ({ value: model, label: model }));
  return acc;
}, {} as Record<string, ComboboxOption[]>);

const vehicleYears: ComboboxOption[] = Array.from({ length: 21 }, (_, i) => {
  const year = (2025 - i).toString();
  return { value: year, label: year };
});

const vehicleColors: ComboboxOption[] = [
  { value: "Beige", label: "Beige" },
  { value: "Black", label: "Black" },
  { value: "Blue", label: "Blue" },
  { value: "Bronze", label: "Bronze" },
  { value: "Brown", label: "Brown" },
  { value: "Burgundy", label: "Burgundy" },
  { value: "Charcoal", label: "Charcoal" },
  { value: "Copper", label: "Copper" },
  { value: "Cream", label: "Cream" },
  { value: "Gold", label: "Gold" },
  { value: "Gray", label: "Gray" },
  { value: "Green", label: "Green" },
  { value: "Ivory", label: "Ivory" },
  { value: "Maroon", label: "Maroon" },
  { value: "Navy", label: "Navy" },
  { value: "Orange", label: "Orange" },
  { value: "Pearl", label: "Pearl" },
  { value: "Purple", label: "Purple" },
  { value: "Red", label: "Red" },
  { value: "Silver", label: "Silver" },
  { value: "Tan", label: "Tan" },
  { value: "Teal", label: "Teal" },
  { value: "White", label: "White" },
  { value: "Yellow", label: "Yellow" },
];

const insuranceCompanies: ComboboxOption[] = [
  { value: "AAA", label: "AAA" },
  { value: "Allstate", label: "Allstate" },
  { value: "American Family", label: "American Family" },
  { value: "Auto-Owners", label: "Auto-Owners" },
  { value: "Country Financial", label: "Country Financial" },
  { value: "Esurance", label: "Esurance" },
  { value: "Farmers", label: "Farmers" },
  { value: "Geico", label: "Geico" },
  { value: "Liberty Mutual", label: "Liberty Mutual" },
  { value: "MetLife", label: "MetLife" },
  { value: "Nationwide", label: "Nationwide" },
  { value: "Progressive", label: "Progressive" },
  { value: "Safeco", label: "Safeco" },
  { value: "State Farm", label: "State Farm" },
  { value: "The General", label: "The General" },
  { value: "The Hartford", label: "The Hartford" },
  { value: "Travelers", label: "Travelers" },
  { value: "USAA", label: "USAA" },
  { value: "Other", label: "Other" },
];

export function DriverProfile() {
  const { t } = useTranslation();
  useLanguageSync(); // Sync language preference from database
  const { signOut, user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { profileData, loading } = useDriverProfileData();
  
  const [vehicleMake, setVehicleMake] = useState("");
  const [vehicleModel, setVehicleModel] = useState("");
  const [vehicleYear, setVehicleYear] = useState("");
  const [vehicleColor, setVehicleColor] = useState("");
  const [vehicleLicensePlate, setVehicleLicensePlate] = useState("");
  const [vehicleVin, setVehicleVin] = useState("");
  const [vehicleRegistrationExpiry, setVehicleRegistrationExpiry] = useState("");
  const [insuranceCompany, setInsuranceCompany] = useState("");
  const [insuranceExpiryDate, setInsuranceExpiryDate] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [emergencyContact, setEmergencyContact] = useState("");
  const [bankName, setBankName] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [routingNumber, setRoutingNumber] = useState("");
  const [address, setAddress] = useState("");
  const [activeVehicleTab, setActiveVehicleTab] = useState('info');
  const [activeMainTab, setActiveMainTab] = useState('profile');
  const [showInsuranceAccess, setShowInsuranceAccess] = useState(false);
  const [showInsuranceUpload, setShowInsuranceUpload] = useState(false);
  const [showInsuranceDetails, setShowInsuranceDetails] = useState(false);
  const [insurancePolicyNumber, setInsurancePolicyNumber] = useState('SF-123456789');
  const [insuranceCarrierName, setInsuranceCarrierName] = useState('');
  const [coverageAmount, setCoverageAmount] = useState('');
  const [preferredLanguage, setPreferredLanguage] = useState('English');
  const [activeProfileTab, setActiveProfileTab] = useState('personal');
  const [paymentMethodType, setPaymentMethodType] = useState('bank');
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [smsAuthEnabled, setSmsAuthEnabled] = useState(true);
  const [emailAuthEnabled, setEmailAuthEnabled] = useState(true);
  const [themePreference, setThemePreference] = useState('system');
  const { appDarkMode, mapsDarkMode, setAppDarkMode, setMapsDarkMode } = useDarkModeSettings();

  // Update local state when profile data loads
  useEffect(() => {
    if (profileData) {
      setFirstName(profileData.personalInfo.firstName);
      setLastName(profileData.personalInfo.lastName);
      setPhone(profileData.personalInfo.phone);
      setEmergencyContact(profileData.personalInfo.emergencyContact);
      setAddress(profileData.personalInfo.address);
      setVehicleMake(profileData.vehicleInfo.make);
      setVehicleModel(profileData.vehicleInfo.model);
      setVehicleYear(profileData.vehicleInfo.year);
      setVehicleColor(profileData.vehicleInfo.color);
      setVehicleLicensePlate(profileData.vehicleInfo.licensePlate);
      setVehicleVin(profileData.vehicleInfo.vin);
      setVehicleRegistrationExpiry(profileData.vehicleInfo.registrationExpiry);
      setInsuranceCompany(profileData.insuranceInfo.company);
      setInsurancePolicyNumber(profileData.insuranceInfo.policyNumber);
      setInsuranceExpiryDate(profileData.insuranceInfo.expiryDate);
      setCoverageAmount(profileData.insuranceInfo.coverageAmount);
      setPaymentMethodType(profileData.paymentInfo.paymentMethodType);
      setBankName(profileData.paymentInfo.bankName);
      setAccountNumber(profileData.paymentInfo.accountNumber);
      setRoutingNumber(profileData.paymentInfo.routingNumber);
      setPreferredLanguage(profileData.personalInfo.preferredLanguage);
    }
  }, [profileData]);

  // Get filtered models based on selected make
  const availableModels = vehicleMake ? makeToModels[vehicleMake] || [] : [];

  // Handle make change and reset model if it's not valid for new make
  const handleMakeChange = (newMake: string) => {
    setVehicleMake(newMake);
    const newModels = makeToModels[newMake] || [];
    const isModelValid = newModels.some(model => model.value === vehicleModel);
    if (!isModelValid) {
      setVehicleModel("");
    }
  };

  // Handle insurance action from URL query parameters
  useEffect(() => {
    const tab = searchParams.get('tab');
    const action = searchParams.get('action');
    
    if (tab === 'insurance') {
      // Ensure outer tab shows Vehicle when handling insurance
      setActiveMainTab('vehicle');
      setActiveVehicleTab('insurance');
      
      // Small delay to ensure DOM is ready
      setTimeout(() => {
        if (action === 'upload') {
          setShowInsuranceUpload(true);
        } else if (action === 'details') {
          setShowInsuranceDetails(true);
        } else {
          // No action means Step 1 - Access Insurance Section
          setShowInsuranceAccess(true);
        }
      }, 100);
    } else if (tab === 'security') {
      setActiveMainTab('security');
    } else if (tab === 'profile') {
      setActiveMainTab('profile');
    }
  }, [searchParams]);

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    
    try {
      // Parse emergency contact
      const emergencyParts = emergencyContact.split(' - ');
      const emergencyName = emergencyParts[0]?.trim() || '';
      const emergencyPhone = emergencyParts[1]?.trim() || '';

      const { error } = await supabase
        .from('profiles')
        .update({
          full_name: `${firstName} ${lastName}`,
          phone: phone,
          full_address: address,
          emergency_contact_name: emergencyName,
          emergency_contact_phone: emergencyPhone,
          notification_preferences: {
            language: preferredLanguage,
          }
        } as any)
        .eq('id', user.id);

      if (error) throw error;
      
      toast.success(t('driver.profile.profileUpdated'));
    } catch (error: any) {
      console.error('Error saving profile:', error);
      toast.error('Failed to save profile changes');
    }
  };

  const handleSaveVehicle = async () => {
    if (!user) return;
    
    try {
      // Check if vehicle exists
      const { data: existingVehicle } = await supabase
        .from('driver_vehicles')
        .select('id')
        .eq('driver_id', user.id)
        .eq('is_primary', true)
        .single();

      const vehicleRecord = {
        driver_id: user.id,
        make: vehicleMake,
        model: vehicleModel,
        year: vehicleYear,
        color: vehicleColor,
        license_plate: vehicleLicensePlate,
        vin: vehicleVin,
        registration_expiry: vehicleRegistrationExpiry || null,
        is_primary: true,
      };

      if (existingVehicle) {
        const { error } = await supabase
          .from('driver_vehicles')
          .update(vehicleRecord)
          .eq('id', existingVehicle.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('driver_vehicles')
          .insert(vehicleRecord);
        if (error) throw error;
      }

      toast.success('Vehicle information updated successfully');
    } catch (error: any) {
      console.error('Error saving vehicle:', error);
      toast.error(error.message);
    }
  };

  const handleSaveInsurance = async () => {
    if (!user) return;
    
    try {
      const { data: existingInsurance } = await supabase
        .from('driver_insurance')
        .select('id')
        .eq('driver_id', user.id)
        .eq('is_active', true)
        .single();

      const insuranceRecord = {
        driver_id: user.id,
        company: insuranceCompany,
        policy_number: insurancePolicyNumber,
        expiry_date: insuranceExpiryDate || null,
        coverage_amount: coverageAmount ? parseFloat(coverageAmount.replace(/[^0-9.]/g, '')) : null,
        is_active: true,
      };

      if (existingInsurance) {
        const { error } = await supabase
          .from('driver_insurance')
          .update(insuranceRecord)
          .eq('id', existingInsurance.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('driver_insurance')
          .insert(insuranceRecord);
        if (error) throw error;
      }

      toast.success('Insurance information updated successfully');
      setShowInsuranceDetails(false);
    } catch (error: any) {
      console.error('Error saving insurance:', error);
      toast.error(error.message);
    }
  };

  const handleSavePaymentMethod = async () => {
    if (!user) return;
    
    try {
      const { data: existingPayment } = await supabase
        .from('driver_payment_methods')
        .select('id')
        .eq('driver_id', user.id)
        .eq('is_primary', true)
        .single();

      const last4 = accountNumber.replace(/\*/g, '').slice(-4);

      const paymentRecord = {
        driver_id: user.id,
        payment_type: paymentMethodType,
        bank_name: bankName,
        account_holder: `${firstName} ${lastName}`,
        account_number_last4: last4,
        routing_number: routingNumber,
        is_primary: true,
      };

      if (existingPayment) {
        const { error } = await supabase
          .from('driver_payment_methods')
          .update(paymentRecord)
          .eq('id', existingPayment.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('driver_payment_methods')
          .insert(paymentRecord);
        if (error) throw error;
      }

      toast.success('Payment method updated successfully');
    } catch (error: any) {
      console.error('Error saving payment method:', error);
      toast.error(error.message);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full overflow-x-hidden scrollbar-hide">
      <Tabs value={activeMainTab} onValueChange={setActiveMainTab} className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-9 sm:h-10">
          <TabsTrigger value="profile" className="text-xs sm:text-sm">{t('driver.profile.title')}</TabsTrigger>
          <TabsTrigger value="vehicle" className="text-xs sm:text-sm">{t('driver.profile.vehicleInfo')}</TabsTrigger>
          <TabsTrigger value="security" className="text-xs sm:text-sm">MFA / Security</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-4">
          <Tabs value={activeProfileTab} onValueChange={setActiveProfileTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-auto sm:h-10 p-1">
              <TabsTrigger value="personal" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">{t('driver.profile.personalInfo')}</TabsTrigger>
              <TabsTrigger value="payment" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">Payment Method</TabsTrigger>
              <TabsTrigger value="notifications" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">Notifications & {t('driver.profile.preferences')}</TabsTrigger>
            </TabsList>

            <TabsContent value="personal" className="space-y-4">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                <Card>
                  <CardHeader className="p-3 sm:p-6">
                    <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                      <User className="h-4 w-4 sm:h-5 sm:w-5" />
                      {t('driver.profile.personalInfo')}
                    </CardTitle>
                    <CardDescription className="text-xs sm:text-sm">Update your personal details</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
                    <div className="flex items-center space-x-3 sm:space-x-4">
                      <div className="w-16 h-16 sm:w-20 sm:h-20 bg-muted rounded-full flex items-center justify-center flex-shrink-0">
                        <User className="h-6 w-6 sm:h-8 sm:w-8 text-muted-foreground" />
                      </div>
                      <div>
                        <Button variant="outline" size="sm" className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm h-8 sm:h-9">
                          <Camera className="h-3 w-3 sm:h-4 sm:w-4" />
                          <span className="hidden sm:inline">Change Photo</span>
                          <span className="sm:hidden">Change</span>
                        </Button>
                        <p className="text-xs text-muted-foreground mt-1">JPG, PNG up to 5MB</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                      <div>
                        <Label htmlFor="firstName" className="text-xs sm:text-sm">First Name</Label>
                        <Input 
                          id="firstName" 
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          disabled={loading}
                          className="h-9 sm:h-10 text-sm" 
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName" className="text-xs sm:text-sm">Last Name</Label>
                        <Input 
                          id="lastName" 
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          disabled={loading}
                          className="h-9 sm:h-10 text-sm" 
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-xs sm:text-sm">Email</Label>
                      <Input 
                        id="email" 
                        type="email" 
                        value={profileData?.personalInfo.email || ''} 
                        disabled={true}
                        className="h-9 sm:h-10 text-sm" 
                      />
                    </div>

                    <div>
                      <Label htmlFor="phone" className="text-xs sm:text-sm">Phone Number</Label>
                      <Input 
                        id="phone" 
                        type="tel" 
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        disabled={loading}
                        className="h-9 sm:h-10 text-sm" 
                      />
                    </div>

                    <div>
                      <Label className="text-xs sm:text-sm">Address</Label>
                      <AddressAutocomplete
                        value={address}
                        onAddressSelect={(addr) => setAddress(addr.formatted_address || '')}
                        placeholder="Start typing your address..."
                        className="h-9 sm:h-10 text-sm"
                      />
                    </div>

                    <div>
                      <Label htmlFor="emergencyContact" className="text-xs sm:text-sm">Emergency Contact</Label>
                      <Input 
                        id="emergencyContact" 
                        value={emergencyContact}
                        onChange={(e) => setEmergencyContact(e.target.value)}
                        placeholder="Name - Phone Number"
                        disabled={loading}
                        className="h-9 sm:h-10 text-sm" 
                      />
                    </div>

                    <div>
                      <Label htmlFor="preferredLanguage" className="text-xs sm:text-sm">{t('driver.profile.preferredLanguage')}</Label>
                      <Select 
                        value={preferredLanguage} 
                        onValueChange={setPreferredLanguage}
                        disabled={loading}
                      >
                        <SelectTrigger id="preferredLanguage" className="h-9 sm:h-10 text-sm bg-background">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover z-50">
                          <SelectItem value="English">{t('languages.en')}</SelectItem>
                          <SelectItem value="Spanish">{t('languages.es')}</SelectItem>
                          <SelectItem value="French">{t('languages.fr')}</SelectItem>
                          <SelectItem value="Arabic">{t('languages.ar')}</SelectItem>
                          <SelectItem value="Mandarin">{t('languages.zh')}</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button 
                      onClick={handleSaveProfile} 
                      disabled={loading}
                      className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10"
                    >
                      {loading ? t('driver.profile.savingChanges') : t('driver.profile.saveChanges')}
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="p-3 sm:p-6">
                    <CardTitle className="text-base sm:text-lg">Account Status</CardTitle>
                    <CardDescription className="text-xs sm:text-sm">Your driver account information</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Account Status</span>
                      <Badge 
                        variant={profileData?.accountStatus.status === 'Active' ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {profileData?.accountStatus.status || 'Unknown'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Background Check</span>
                      <Badge 
                        variant={profileData?.accountStatus.backgroundCheck === 'Approved' ? 'secondary' : 'outline'}
                        className="text-xs"
                      >
                        {profileData?.accountStatus.backgroundCheck || 'Pending'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Driver License</span>
                      <Badge 
                        variant={profileData?.accountStatus.driverLicense === 'Verified' ? 'secondary' : 'outline'}
                        className="text-xs"
                      >
                        {profileData?.accountStatus.driverLicense || 'Pending'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Insurance</span>
                      <Badge 
                        variant={profileData?.accountStatus.insurance === 'Valid' ? 'secondary' : 'outline'}
                        className="text-xs"
                      >
                        {profileData?.accountStatus.insurance || 'Pending'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Vehicle Registration</span>
                      <Badge 
                        variant={profileData?.accountStatus.vehicleRegistration === 'Valid' ? 'secondary' : 'outline'}
                        className="text-xs"
                      >
                        {profileData?.accountStatus.vehicleRegistration || 'Pending'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Member Since</span>
                      <span className="text-xs sm:text-sm">{profileData?.accountStatus.memberSince || 'N/A'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs sm:text-sm font-medium">Total Deliveries</span>
                      <span className="text-xs sm:text-sm">{profileData?.accountStatus.totalDeliveries || 0}</span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <DeleteAccountSection />

              {/* Sign Out Section */}
              <Card className="border-muted">
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Account Actions</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Sign out of your account</CardDescription>
                </CardHeader>
                <CardContent className="p-3 sm:p-6">
                  <Button
                    variant="outline"
                    onClick={handleSignOut}
                    className="w-full sm:w-auto gap-2 text-destructive hover:text-destructive"
                  >
                    <LogOut className="h-4 w-4" />
                    Sign Out
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="payment" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <CreditCard className="h-4 w-4 sm:h-5 sm:w-5" />
                    Payment Methods
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Manage your payment and payout methods</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
                  <div>
                    <Label htmlFor="paymentType" className="text-xs sm:text-sm">Payment Method Type</Label>
                    <Select value={paymentMethodType} onValueChange={setPaymentMethodType}>
                      <SelectTrigger id="paymentType" className="h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select payment type" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="bank">Bank Account</SelectItem>
                        <SelectItem value="debit">Debit Card</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {paymentMethodType === 'bank' && (
                    <>
                      <div>
                        <Label htmlFor="bankName" className="text-xs sm:text-sm">Bank Name</Label>
                        <Input 
                          id="bankName" 
                          value={bankName}
                          onChange={(e) => setBankName(e.target.value)}
                          className="h-9 sm:h-10 text-sm" 
                        />
                      </div>

                      <div>
                        <Label htmlFor="accountHolder" className="text-xs sm:text-sm">Account Holder Name</Label>
                        <Input 
                          id="accountHolder" 
                          value={`${firstName} ${lastName}`}
                          disabled={true}
                          className="h-9 sm:h-10 text-sm" 
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                        <div>
                          <Label htmlFor="accountNumber" className="text-xs sm:text-sm">Account Number</Label>
                          <Input 
                            id="accountNumber" 
                            type="password" 
                            value={accountNumber}
                            onChange={(e) => setAccountNumber(e.target.value)}
                            placeholder="Last 4 digits"
                            className="h-9 sm:h-10 text-sm" 
                          />
                        </div>
                        <div>
                          <Label htmlFor="routingNumber" className="text-xs sm:text-sm">Routing Number</Label>
                          <Input 
                            id="routingNumber" 
                            value={routingNumber}
                            onChange={(e) => setRoutingNumber(e.target.value)}
                            className="h-9 sm:h-10 text-sm" 
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="accountType" className="text-xs sm:text-sm">Account Type</Label>
                        <Select defaultValue="checking">
                          <SelectTrigger id="accountType" className="h-9 sm:h-10 text-sm bg-background">
                            <SelectValue placeholder="Select account type" />
                          </SelectTrigger>
                          <SelectContent className="bg-popover z-50">
                            <SelectItem value="checking">Checking</SelectItem>
                            <SelectItem value="savings">Savings</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </>
                  )}

                  {paymentMethodType === 'debit' && (
                    <>
                      <div>
                        <Label htmlFor="cardholderName" className="text-xs sm:text-sm">Cardholder Name</Label>
                        <Input id="cardholderName" placeholder="John Smith" className="h-9 sm:h-10 text-sm" />
                      </div>

                      <div>
                        <Label htmlFor="cardNumber" className="text-xs sm:text-sm">Card Number</Label>
                        <Input 
                          id="cardNumber" 
                          type="text" 
                          placeholder="1234 5678 9012 3456" 
                          maxLength={19}
                          className="h-9 sm:h-10 text-sm" 
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-3 sm:gap-4">
                        <div>
                          <Label htmlFor="expiryDate" className="text-xs sm:text-sm">Expiry Date</Label>
                          <Input 
                            id="expiryDate" 
                            type="text" 
                            placeholder="MM/YY" 
                            maxLength={5}
                            className="h-9 sm:h-10 text-sm" 
                          />
                        </div>
                        <div>
                          <Label htmlFor="cvv" className="text-xs sm:text-sm">CVV</Label>
                          <Input 
                            id="cvv" 
                            type="password" 
                            placeholder="123" 
                            maxLength={4}
                            className="h-9 sm:h-10 text-sm" 
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="billingZip" className="text-xs sm:text-sm">Billing ZIP Code</Label>
                        <Input 
                          id="billingZip" 
                          type="text" 
                          placeholder="12345" 
                          maxLength={10}
                          className="h-9 sm:h-10 text-sm" 
                        />
                      </div>
                    </>
                  )}

                  <Button onClick={handleSavePaymentMethod} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">Update Payment Method</Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5" />
                    Notification Preferences
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Choose how you want to receive notifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">New Job Alerts</Label>
                        <p className="text-xs text-muted-foreground">Get notified when new jobs are available</p>
                      </div>
                      <Input type="checkbox" defaultChecked className="h-5 w-5" />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Earnings Updates</Label>
                        <p className="text-xs text-muted-foreground">Receive updates about your earnings and payouts</p>
                      </div>
                      <Input type="checkbox" defaultChecked className="h-5 w-5" />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Job Reminders</Label>
                        <p className="text-xs text-muted-foreground">Get reminders about upcoming scheduled jobs</p>
                      </div>
                      <Input type="checkbox" defaultChecked className="h-5 w-5" />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Account Updates</Label>
                        <p className="text-xs text-muted-foreground">Important updates about your account status</p>
                      </div>
                      <Input type="checkbox" defaultChecked className="h-5 w-5" />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">System Maintenance</Label>
                        <p className="text-xs text-muted-foreground">Notifications about scheduled maintenance</p>
                      </div>
                      <Input type="checkbox" defaultChecked className="h-5 w-5" />
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Label className="text-xs sm:text-sm font-medium">Notification Channel</Label>
                    <p className="text-xs text-muted-foreground mb-3">How would you like to receive notifications?</p>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Input type="checkbox" defaultChecked id="email-notif" className="h-4 w-4" />
                        <Label htmlFor="email-notif" className="text-xs sm:text-sm cursor-pointer">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Input type="checkbox" defaultChecked id="sms-notif" className="h-4 w-4" />
                        <Label htmlFor="sms-notif" className="text-xs sm:text-sm cursor-pointer">SMS</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Input type="checkbox" defaultChecked id="push-notif" className="h-4 w-4" />
                        <Label htmlFor="push-notif" className="text-xs sm:text-sm cursor-pointer">Push Notifications</Label>
                      </div>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Label className="text-xs sm:text-sm font-medium">Appearance</Label>
                    <p className="text-xs text-muted-foreground mb-3">Choose your preferred theme</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={() => setThemePreference('light')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'light' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Sun className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Light mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('dark')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'dark' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Moon className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Dark mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('system')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'system' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Monitor className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">System default</span>
                      </button>
                    </div>
                  </div>

                  {themePreference === 'dark' && (
                    <>
                      <Separator className="my-4" />

                      <div>
                        <Label className="text-xs sm:text-sm font-medium">Advanced Dark Mode Settings</Label>
                        <p className="text-xs text-muted-foreground mb-4">Separately control dark mode for app and maps</p>
                        
                        <div className="space-y-4">
                          <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-lg bg-primary/10">
                                <Monitor className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">App Dark Mode</p>
                                <p className="text-xs text-muted-foreground">Enable dark theme for the interface</p>
                              </div>
                            </div>
                            <Switch
                              checked={appDarkMode}
                              onCheckedChange={setAppDarkMode}
                            />
                          </div>
  
                          <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-lg bg-primary/10">
                                <MapPin className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">Maps Dark Mode</p>
                                <p className="text-xs text-muted-foreground">Enable dark theme for maps</p>
                              </div>
                            </div>
                            <Switch
                              checked={mapsDarkMode}
                              onCheckedChange={setMapsDarkMode}
                            />
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  <Button onClick={() => toast.success('Notification preferences saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">Save Preferences</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        <TabsContent value="vehicle" className="space-y-4">
          <Tabs value={activeVehicleTab} onValueChange={setActiveVehicleTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="info">Vehicle Info</TabsTrigger>
              <TabsTrigger value="insurance">Insurance</TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Car className="h-4 w-4 sm:h-5 sm:w-5" />
                    Vehicle Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Update your vehicle details</CardDescription>
                </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <Label htmlFor="make">Make</Label>
                  <Combobox
                    options={vehicleMakes}
                    value={vehicleMake}
                    onValueChange={handleMakeChange}
                    placeholder="Select make"
                    searchPlaceholder="Search make..."
                    emptyText="No make found."
                  />
                </div>
                <div>
                  <Label htmlFor="model">Model</Label>
                  <Combobox
                    options={availableModels}
                    value={vehicleModel}
                    onValueChange={setVehicleModel}
                    placeholder={vehicleMake ? "Select model" : "Select make first"}
                    searchPlaceholder="Search model..."
                    emptyText={vehicleMake ? "No model found." : "Please select a make first"}
                    disabled={!vehicleMake || availableModels.length === 0}
                  />
                </div>
                <div>
                  <Label htmlFor="year">Year</Label>
                  <Combobox
                    options={vehicleYears}
                    value={vehicleYear}
                    onValueChange={setVehicleYear}
                    placeholder="Select year"
                    searchPlaceholder="Search year..."
                    emptyText="No year found."
                  />
                </div>
                <div>
                  <Label htmlFor="color">Color</Label>
                  <Combobox
                    options={vehicleColors}
                    value={vehicleColor}
                    onValueChange={setVehicleColor}
                    placeholder="Select color"
                    searchPlaceholder="Search color..."
                    emptyText="No color found."
                  />
                </div>
                <div>
                  <Label htmlFor="licensePlate">License Plate</Label>
                  <Input 
                    id="licensePlate" 
                    value={vehicleLicensePlate}
                    onChange={(e) => setVehicleLicensePlate(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="vin">VIN</Label>
                  <Input 
                    id="vin" 
                    value={vehicleVin}
                    onChange={(e) => setVehicleVin(e.target.value)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="registrationExpiry">Registration Expiry</Label>
                  <Input 
                    id="registrationExpiry" 
                    type="date" 
                    value={vehicleRegistrationExpiry}
                    onChange={(e) => setVehicleRegistrationExpiry(e.target.value)}
                  />
                </div>
              </div>

              <Button onClick={handleSaveVehicle}>Update Vehicle Info</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Vehicle Photos</CardTitle>
              <CardDescription>Upload photos of your vehicle</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="border rounded-lg p-4 text-center">
                  <Car className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Front View</p>
                  <Button variant="outline" size="sm" className="mt-2">Upload</Button>
                </div>
                <div className="border rounded-lg p-4 text-center">
                  <Car className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Side View</p>
                  <Button variant="outline" size="sm" className="mt-2">Upload</Button>
                </div>
                <div className="border rounded-lg p-4 text-center">
                  <Car className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">Interior</p>
                  <Button variant="outline" size="sm" className="mt-2">Upload</Button>
                </div>
                <div className="border rounded-lg p-4 text-center">
                  <FileText className="h-8 w-8 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">License Plate</p>
                  <Button variant="outline" size="sm" className="mt-2">Upload</Button>
                </div>
              </div>
            </CardContent>
          </Card>
            </TabsContent>

            <TabsContent value="insurance" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
                    Insurance Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Manage your vehicle insurance</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="insuranceCompany">Insurance Company</Label>
                      <Combobox
                        options={insuranceCompanies}
                        value={insuranceCompany}
                        onValueChange={setInsuranceCompany}
                        placeholder="Select insurance company"
                        searchPlaceholder="Search insurance company..."
                        emptyText="No insurance company found."
                      />
                    </div>
                    <div>
                      <Label htmlFor="policyNumber">Policy Number</Label>
                      <Input 
                        id="policyNumber" 
                        value={insurancePolicyNumber}
                        onChange={(e) => setInsurancePolicyNumber(e.target.value)}
                        placeholder="Enter policy number" 
                      />
                    </div>
                    <div>
                      <Label htmlFor="insuranceExpiry">Insurance Expiry</Label>
                      <Input 
                        id="insuranceExpiry" 
                        type="date" 
                        value={insuranceExpiryDate}
                        onChange={(e) => setInsuranceExpiryDate(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="coverageAmount">Coverage Amount</Label>
                      <Input 
                        id="coverageAmount" 
                        value={coverageAmount}
                        onChange={(e) => setCoverageAmount(e.target.value)}
                        placeholder="e.g., $1,000,000" 
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label>Insurance Documents</Label>
                      <div className="mt-2 space-y-2">
                        <div className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-2">
                            <FileText className="h-4 w-4 text-muted-foreground" />
                            <span className="text-sm">Insurance Certificate</span>
                          </div>
                          <Badge variant="secondary">Valid</Badge>
                        </div>
                        <Button 
                          variant="outline" 
                          className="w-full"
                          onClick={() => setShowInsuranceUpload(true)}
                        >
                          <Camera className="h-4 w-4 mr-2" />
                          Upload New Insurance Document
                        </Button>
                      </div>
                    </div>

                    <Button 
                      onClick={handleSaveInsurance}
                    >
                      Update Insurance Details
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Step 1: Access Insurance Section Modal */}
          <Dialog open={showInsuranceAccess} onOpenChange={setShowInsuranceAccess}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Access Insurance Section</DialogTitle>
                <DialogDescription>
                  Navigate to the insurance documents area to upload your insurance proof and enter policy details.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <Card>
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary font-semibold">
                          1
                        </div>
                        <div>
                          <h4 className="font-semibold">Current Step</h4>
                          <p className="text-sm text-muted-foreground">
                            You are now in the insurance section. Here you can manage your vehicle insurance documents.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground font-semibold">
                          2
                        </div>
                        <div>
                          <h4 className="font-semibold">Next: Upload Insurance</h4>
                          <p className="text-sm text-muted-foreground">
                            Upload your insurance declaration page or Certificate of Insurance.
                          </p>
                        </div>
                      </div>
                      <div className="flex items-start gap-3">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-muted-foreground font-semibold">
                          3
                        </div>
                        <div>
                          <h4 className="font-semibold">Finally: Enter Details</h4>
                          <p className="text-sm text-muted-foreground">
                            Fill in policy number, carrier name, and coverage amounts.
                          </p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    className="flex-1"
                    onClick={() => setShowInsuranceAccess(false)}
                  >
                    Close
                  </Button>
                  <Button 
                    className="flex-1"
                    onClick={() => {
                      setShowInsuranceAccess(false);
                      toast.success('Insurance section accessed successfully!');
                    }}
                  >
                    Continue
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          {/* Step 2: Insurance Upload Dialog */}
          <Dialog open={showInsuranceUpload} onOpenChange={setShowInsuranceUpload}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Upload Insurance Policy</DialogTitle>
                <DialogDescription>
                  Upload your insurance declaration page or Certificate of Insurance. Required minimum liability: $1,000,000.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <FileUpload 
                  field="insurance_document"
                  label="Insurance Document"
                  onChange={(field, fileUrl) => {
                    if (fileUrl) {
                      console.log('Insurance file uploaded:', fileUrl);
                      toast.success('Insurance document uploaded successfully!');
                    }
                  }}
                  acceptedTypes="image/*,.pdf"
                />
                <Button 
                  className="w-full"
                  onClick={() => {
                    toast.success('Insurance document saved!');
                    setShowInsuranceUpload(false);
                  }}
                >
                  Save Document
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          {/* Step 3: Insurance Details Dialog */}
          <Dialog open={showInsuranceDetails} onOpenChange={setShowInsuranceDetails}>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Enter Policy Details</DialogTitle>
                <DialogDescription>
                  Fill in your insurance policy information including policy number, carrier name, and coverage amounts.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <Label htmlFor="detailsPolicyNumber">Policy Number *</Label>
                  <Input 
                    id="detailsPolicyNumber"
                    value={insurancePolicyNumber}
                    onChange={(e) => setInsurancePolicyNumber(e.target.value)}
                    placeholder="Enter policy number"
                  />
                </div>
                <div>
                  <Label htmlFor="detailsCarrierName">Insurance Carrier Name *</Label>
                  <Input 
                    id="detailsCarrierName"
                    value={insuranceCarrierName}
                    onChange={(e) => setInsuranceCarrierName(e.target.value)}
                    placeholder="Enter carrier name"
                  />
                </div>
                <div>
                  <Label htmlFor="detailsCoverageAmount">Coverage Amount *</Label>
                  <Input 
                    id="detailsCoverageAmount"
                    value={coverageAmount}
                    onChange={(e) => setCoverageAmount(e.target.value)}
                    placeholder="$1,000,000 minimum"
                  />
                </div>
                <div>
                  <Label htmlFor="detailsExpiryDate">Expiry Date *</Label>
                  <Input 
                    id="detailsExpiryDate"
                    type="date"
                  />
                </div>
                <Button 
                  className="w-full"
                  onClick={() => {
                    if (!insurancePolicyNumber || !insuranceCarrierName || !coverageAmount) {
                      toast.error('Please fill in all required fields');
                      return;
                    }
                    toast.success('Insurance details saved successfully!');
                    setShowInsuranceDetails(false);
                  }}
                >
                  Save Details
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </TabsContent>

        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Shield className="h-4 w-4 sm:h-5 sm:w-5" />
                Multi-Factor Authentication (MFA)
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">Add an extra layer of security to your account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-3 sm:p-6">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Smartphone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">Authenticator App (Recommended)</p>
                    <p className="text-xs text-muted-foreground">Use an app like Google Authenticator or Authy</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={mfaEnabled ? "default" : "secondary"} className="text-xs">
                    {mfaEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setMfaEnabled(!mfaEnabled);
                      toast.success(mfaEnabled ? 'MFA disabled' : 'MFA enabled successfully!');
                    }}
                  >
                    {mfaEnabled ? "Disable" : "Enable"}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Bell className="h-5 w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">SMS Authentication</p>
                    <p className="text-xs text-muted-foreground">Receive verification codes via text message</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={smsAuthEnabled ? "default" : "secondary"} className="text-xs">
                    {smsAuthEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setSmsAuthEnabled(!smsAuthEnabled);
                      toast.success(smsAuthEnabled ? 'SMS auth disabled' : 'SMS auth enabled!');
                    }}
                  >
                    {smsAuthEnabled ? "Disable" : "Enable"}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <Bell className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-sm">Email Authentication</p>
                    <p className="text-xs text-muted-foreground">Receive verification codes via email</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={emailAuthEnabled ? "default" : "secondary"} className="text-xs">
                    {emailAuthEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setEmailAuthEnabled(!emailAuthEnabled);
                      toast.success(emailAuthEnabled ? 'Email auth disabled' : 'Email auth enabled!');
                    }}
                  >
                    {emailAuthEnabled ? "Disable" : "Enable"}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Key className="h-4 w-4 sm:h-5 sm:w-5" />
                Password & Security
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">Manage your password and security settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-3 sm:p-6">
              <div>
                <Label htmlFor="currentPassword" className="text-xs sm:text-sm">Current Password</Label>
                <Input id="currentPassword" type="password" placeholder="Enter current password" className="h-9 sm:h-10 text-sm" />
              </div>

              <div>
                <Label htmlFor="newPassword" className="text-xs sm:text-sm">New Password</Label>
                <Input id="newPassword" type="password" placeholder="Enter new password" className="h-9 sm:h-10 text-sm" />
              </div>

              <div>
                <Label htmlFor="confirmPassword" className="text-xs sm:text-sm">Confirm New Password</Label>
                <Input id="confirmPassword" type="password" placeholder="Confirm new password" className="h-9 sm:h-10 text-sm" />
              </div>

              <div className="pt-2">
                <p className="text-xs text-muted-foreground mb-2">Password requirements:</p>
                <ul className="text-xs text-muted-foreground space-y-1 ml-4 list-disc">
                  <li>At least 8 characters long</li>
                  <li>Contains uppercase and lowercase letters</li>
                  <li>Contains at least one number</li>
                  <li>Contains at least one special character</li>
                </ul>
              </div>

              <Button onClick={() => toast.success('Password updated successfully!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                Update Password
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Lock className="h-4 w-4 sm:h-5 sm:w-5" />
                Security Questions
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">Set up security questions for account recovery</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-3 sm:p-6">
              <div>
                <Label htmlFor="question1" className="text-xs sm:text-sm">Security Question 1</Label>
                <Select defaultValue="mother">
                  <SelectTrigger id="question1" className="h-9 sm:h-10 text-sm bg-background">
                    <SelectValue placeholder="Select question" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover z-50">
                    <SelectItem value="mother">What is your mother's maiden name?</SelectItem>
                    <SelectItem value="pet">What was the name of your first pet?</SelectItem>
                    <SelectItem value="city">In what city were you born?</SelectItem>
                    <SelectItem value="school">What was the name of your elementary school?</SelectItem>
                  </SelectContent>
                </Select>
                <Input placeholder="Your answer" className="mt-2 h-9 sm:h-10 text-sm" />
              </div>

              <div>
                <Label htmlFor="question2" className="text-xs sm:text-sm">Security Question 2</Label>
                <Select defaultValue="pet">
                  <SelectTrigger id="question2" className="h-9 sm:h-10 text-sm bg-background">
                    <SelectValue placeholder="Select question" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover z-50">
                    <SelectItem value="mother">What is your mother's maiden name?</SelectItem>
                    <SelectItem value="pet">What was the name of your first pet?</SelectItem>
                    <SelectItem value="city">In what city were you born?</SelectItem>
                    <SelectItem value="school">What was the name of your elementary school?</SelectItem>
                  </SelectContent>
                </Select>
                <Input placeholder="Your answer" className="mt-2 h-9 sm:h-10 text-sm" />
              </div>

              <Button onClick={() => toast.success('Security questions saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                Save Security Questions
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="text-base sm:text-lg">Active Sessions</CardTitle>
              <CardDescription className="text-xs sm:text-sm">Manage devices where you're currently logged in</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 p-3 sm:p-6">
              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Chrome on Windows</p>
                  <p className="text-xs text-muted-foreground">Last active: 2 minutes ago • New York, USA</p>
                </div>
                <Badge variant="default" className="text-xs">Current</Badge>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Safari on iPhone</p>
                  <p className="text-xs text-muted-foreground">Last active: 3 hours ago • New York, USA</p>
                </div>
                <Button variant="outline" size="sm" className="text-xs">
                  Sign Out
                </Button>
              </div>

              <div className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="text-sm font-medium">Chrome on Android</p>
                  <p className="text-xs text-muted-foreground">Last active: 1 day ago • Chicago, USA</p>
                </div>
                <Button variant="outline" size="sm" className="text-xs">
                  Sign Out
                </Button>
              </div>

              <Button variant="destructive" className="w-full text-xs sm:text-sm h-9 sm:h-10" onClick={() => toast.success('All other sessions signed out!')}>
                Sign Out All Other Sessions
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}