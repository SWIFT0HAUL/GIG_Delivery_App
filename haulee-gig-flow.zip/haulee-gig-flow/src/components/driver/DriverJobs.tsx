import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { MapPin, Clock, DollarSign, Package, Play, CheckCircle, Undo2, Navigation, AlertCircle, Phone, XCircle, FileText, ChevronDown, ChevronUp, TrendingUp, PackageCheck, User, Timer, Truck, Info } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';

import { PickupPhotoModal } from './PickupPhotoModal';
import { OnDutyDeliveryModal } from './OnDutyDeliveryModal';
import { NavigationModal } from './NavigationModal';
import { StopDetailsModal } from './StopDetailsModal';
import { OnDutyPickupModal } from './OnDutyPickupModal';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { SlideToConfirm } from './SlideToConfirm';
import { JobMapView } from './JobMapView';
import { DriverJobDetailsDialog } from './DriverJobDetailsDialog';
import { OnDutyModal } from './OnDutyModal';
import { calculateDistance, metersToYards, formatDistance, classifyLocation, getAllowedRadius, isWithinRadius, type LocationCoordinates, type AreaType, type ActionType } from '@/lib/locationUtils';
import { logDeliveryAction, getFailedAttemptsCount } from '@/lib/deliveryLogger';
import { usePlatformSettings } from '@/contexts/PlatformSettingsContext';
import { useSafeMode } from '@/contexts/SafeModeContext';

type JobStep = 'assigned' | 'in_progress' | 'picked_up' | 'delivered';

export function DriverJobs() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isSafeModeActive } = useSafeMode();
  const [photoModalOpen, setPhotoModalOpen] = useState(false);
  const [deliveryModalOpen, setDeliveryModalOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<{
    assignmentId: string;
    jobId: string;
    job?: any;
  } | null>(null);
  const [areaTypes, setAreaTypes] = useState<Record<string, AreaType>>({});
  const [arrivedAtPickup, setArrivedAtPickup] = useState<Record<string, boolean>>({});
  const [arrivedAtDropoff, setArrivedAtDropoff] = useState<Record<string, boolean>>({});
  const [navigationModalOpen, setNavigationModalOpen] = useState(false);
  const [navigationDestination, setNavigationDestination] = useState<{
    lat?: number;
    lng?: number;
    address: string;
  } | null>(null);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelReasonDetails, setCancelReasonDetails] = useState('');
  const [jobToCancel, setJobToCancel] = useState<{ assignmentId: string; jobId: string } | null>(null);
  const [detailsDialogOpen, setDetailsDialogOpen] = useState(false);
  const [selectedJobForDetails, setSelectedJobForDetails] = useState<any>(null);
  const [selectedStop, setSelectedStop] = useState<any>(null);
  const [showStopDetails, setShowStopDetails] = useState(false);
  const [onDutyModalOpen, setOnDutyModalOpen] = useState(false);
  const [selectedJobForOnDuty, setSelectedJobForOnDuty] = useState<string | null>(null);
  const [expandedStops, setExpandedStops] = useState<Record<string, boolean>>({});
  const [pickupModalOpen, setPickupModalOpen] = useState(false);
  const [selectedJobForPickup, setSelectedJobForPickup] = useState<any>(null);
  const { settings } = usePlatformSettings();
  const [completingIds, setCompletingIds] = useState<Record<string, boolean>>({});

  // Real-time driver location tracking
  const driverLocation = useDriverLocation();

  // Fetch active job assignments for the current driver
  const { data: activeJobs = [], isLoading } = useQuery({
    queryKey: ['active-jobs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');
      
      const { data, error } = await supabase
        .from('job_assignments')
        .select(`*, jobs (*)`)
        .eq('driver_id', user.id)
        .in('status', ['assigned', 'in_progress', 'picked_up', 'delivered'])
        .order('assigned_at', { ascending: false });
      
      if (error) throw error;
      
      // Filter logic (same as before)
      const now = new Date();
      const filteredData = (data || []).filter((assignment: any) => {
        const job = assignment.jobs;
        if (!job) return false;
        
        // Show jobs until assignment status becomes 'completed' (set by Submit & Complete button)
        return ['assigned', 'in_progress', 'picked_up', 'delivered'].includes(assignment.status);
      });
      
      return filteredData;
    },
    refetchInterval: 10000
  });

  // Locally hide any assignments that are in the middle of completion to prevent flicker
  const visibleJobs = useMemo(() => activeJobs.filter((a: any) => !completingIds[a.id]), [activeJobs, completingIds]);

  // Fetch route stops for jobs that are part of routes
  const { data: routeStops = [] } = useQuery({
    queryKey: ['route-stops'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const routeIds = activeJobs
        .map((assignment: any) => assignment.jobs?.route_id)
        .filter((id: string | null) => id != null);

      if (routeIds.length === 0) return [];

      const { data: stops, error } = await supabase
        .from('route_stops')
        .select('*')
        .in('route_id', routeIds)
        .order('stop_sequence', { ascending: true });

      if (error) throw error;
      return stops || [];
    },
    enabled: activeJobs.length > 0,
    refetchInterval: 10000
  });

  // Classify locations for all jobs
  useEffect(() => {
    const classifyAllLocations = async () => {
      if (!activeJobs.length) return;
      const newAreaTypes: Record<string, AreaType> = {};
      
      for (const assignment of activeJobs) {
        const job = assignment.jobs;
        if (!job) continue;
        
        const pickupLoc = job.pickup_location as any;
        const deliveryLoc = job.delivery_location as any;
        
        if (pickupLoc?.address && pickupLoc?.coordinates) {
          const areaType = await classifyLocation(pickupLoc.address, pickupLoc.coordinates);
          newAreaTypes[`${job.id}-pickup`] = areaType;
        }
        
        if (deliveryLoc?.address && deliveryLoc?.coordinates) {
          const areaType = await classifyLocation(deliveryLoc.address, deliveryLoc.coordinates);
          newAreaTypes[`${job.id}-dropoff`] = areaType;
        }
      }
      
      setAreaTypes(newAreaTypes);
    };
    
    classifyAllLocations();
  }, [activeJobs]);

  // Update job assignment status
  const updateStatusMutation = useMutation({
    mutationFn: async ({ assignmentId, newStatus, jobId }: { assignmentId: string; newStatus: string; jobId: string }) => {
      const updates: any = { status: newStatus };
      
      if (newStatus === 'in_progress') updates.accepted_at = new Date().toISOString();
      if (newStatus === 'picked_up') updates.started_at = new Date().toISOString();
      if (newStatus === 'delivered' || newStatus === 'completed') {
        updates.completed_at = new Date().toISOString();
        updates.status = 'completed';
      }
      
      const { error: assignmentError } = await supabase
        .from('job_assignments')
        .update(updates)
        .eq('id', assignmentId);
        
      if (assignmentError) throw assignmentError;

      // Update job status to match
      if (newStatus === 'in_progress') {
        const { error: jobError } = await supabase
          .from('jobs')
          .update({ status: 'in_progress' })
          .eq('id', jobId);
        if (jobError) throw jobError;
      } else if (newStatus === 'picked_up') {
        const { error: jobError } = await supabase
          .from('jobs')
          .update({ status: 'picked_up' })
          .eq('id', jobId);
        if (jobError) throw jobError;
      } else if (newStatus === 'delivered') {
        const { error: jobError } = await supabase
          .from('jobs')
          .update({ status: 'delivered' })
          .eq('id', jobId);
        if (jobError) throw jobError;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['completed-jobs'] });
      toast.success('Job status updated');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to update status');
    }
  });

  // Go back one step in the job flow
  const goBackMutation = useMutation({
    mutationFn: async ({ assignmentId, currentStatus, jobId }: { assignmentId: string; currentStatus: string; jobId: string }) => {
      const statusMap: Record<string, string> = {
        'in_progress': 'assigned',
        'picked_up': 'in_progress',
        'completed': 'picked_up'
      };
      
      const newStatus = statusMap[currentStatus];
      if (!newStatus) throw new Error('Cannot go back from this status');
      
      const updates: any = { status: newStatus };

      if (currentStatus === 'in_progress') {
        updates.accepted_at = null;
      } else if (currentStatus === 'picked_up') {
        updates.started_at = null;
        updates.pickup_photo_url = null;
      } else if (currentStatus === 'delivered') {
        updates.completed_at = null;
      }
      
      const { error: assignmentError } = await supabase
        .from('job_assignments')
        .update(updates)
        .eq('id', assignmentId);
        
      if (assignmentError) throw assignmentError;

      if (currentStatus === 'delivered') {
        const { error: jobError } = await supabase
          .from('jobs')
          .update({ status: 'picked_up' })
          .eq('id', jobId);
        if (jobError) throw jobError;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['completed-jobs'] });
      toast.success('Reverted to previous step');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to go back');
    }
  });

  // Complete job mutation - updates job status to completed and closes assignment
  const completeJobMutation = useMutation<void, any, { jobId: string; assignmentId: string }>({
    mutationFn: async ({ jobId, assignmentId }: { jobId: string; assignmentId: string }) => {
      const nowIso = new Date().toISOString();
      
      console.log('🎯 Completing job:', { jobId, assignmentId });

      // Get current user for RLS and scoping updates
      const { data: authData } = await supabase.auth.getUser();
      const currentUser = authData?.user;
      if (!currentUser) throw new Error('Not authenticated');

      // 1) Mark assignment as completed (RLS enforces ownership)
      const { error: assignErr } = await supabase
        .from('job_assignments')
        .update({ status: 'completed', completed_at: nowIso })
        .eq('id', assignmentId);
      if (assignErr) {
        console.error('❌ Error updating assignment:', assignErr);
        throw new Error('Failed to complete assignment');
      }
      console.log('✅ Assignment marked as completed');

      // 2) Mark job as completed (feeds completed_jobs view)
      const { error: jobErr } = await supabase
        .from('jobs')
        .update({ 
          status: 'completed',
          secondary_status: 'completed',
          completed_at: nowIso
        })
        .eq('id', jobId)
        .eq('assigned_driver_id', currentUser.id);
      if (jobErr) {
        console.error('❌ Error updating job:', jobErr);
        throw new Error('Failed to complete job');
      }
      console.log('✅ Job marked as completed');
    },
    onMutate: async ({ assignmentId }) => {
      // Hide locally to avoid flicker while server updates
      setCompletingIds((prev) => ({ ...prev, [assignmentId]: true }));
      await queryClient.cancelQueries({ queryKey: ['active-jobs'] });
      const previousActiveJobs = queryClient.getQueryData<any[]>(['active-jobs']) || [];
      const nextActive = previousActiveJobs.filter((a: any) => a.id !== assignmentId);
      queryClient.setQueryData(['active-jobs'], nextActive);
      return { previousActiveJobs, assignmentId };
    },
    onError: (error: any, vars: { assignmentId: string }, context: any) => {
      // Restore local visibility on error
      setCompletingIds((prev) => {
        const { [vars.assignmentId]: _ignored, ...rest } = prev;
        return rest;
      });
      if (context?.previousActiveJobs) {
        queryClient.setQueryData(['active-jobs'], context.previousActiveJobs);
      }
      toast.error(error.message || 'Failed to complete job');
    },
    onSuccess: (_data, vars: { assignmentId: string }) => {
      // Cleanup local flag; item will naturally disappear from query afterward
      setCompletingIds((prev) => {
        const { [vars.assignmentId]: _ignored, ...rest } = prev;
        return rest;
      });
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['completed-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['driver-completed-jobs'] });
      toast.success('Job completed successfully!');
    },
  });

  // Cancel job mutation
  const cancelJobMutation = useMutation({
    mutationFn: async ({ assignmentId, jobId, reason, category }: {
      assignmentId: string;
      jobId: string;
      reason: string;
      category: 'vehicle_issue' | 'personal_emergency' | 'preference_based' | 'claim_by_mistake' | 'other';
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'posted',
          assigned_driver_id: null,
          cancellation_reason: reason,
          cancellation_reason_category: category,
          updated_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (jobError) throw jobError;

      const { error: assignmentError } = await supabase
        .from('job_assignments')
        .delete()
        .eq('id', assignmentId);
        
      if (assignmentError) throw assignmentError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      toast.success('Job cancelled and returned to Available Jobs');
      setCancelDialogOpen(false);
      setCancelReason('');
      setCancelReasonDetails('');
      setJobToCancel(null);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to cancel job');
    }
  });

  const handleCancelClick = (assignmentId: string, jobId: string) => {
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }
    setJobToCancel({ assignmentId, jobId });
    setCancelReason('');
    setCancelReasonDetails('');
    setCancelDialogOpen(true);
  };

  const confirmCancel = () => {
    if (!jobToCancel || !cancelReason) return;
    
    if (cancelReason === 'Other' && !cancelReasonDetails.trim()) {
      toast.error('Please provide details for cancellation');
      return;
    }
    
    const categoryMap: Record<string, 'vehicle_issue' | 'personal_emergency' | 'preference_based' | 'claim_by_mistake' | 'other'> = {
      'Vehicle issue': 'vehicle_issue',
      'Personal / Emergency Reasons': 'personal_emergency',
      'Preference-Based Reasons': 'preference_based',
      'Claim by Mistake': 'claim_by_mistake',
      'Other': 'other'
    };
    
    const fullReason = cancelReason === 'Other' 
      ? `Other: ${cancelReasonDetails}` 
      : cancelReason;
    
    cancelJobMutation.mutate({ 
      assignmentId: jobToCancel.assignmentId, 
      jobId: jobToCancel.jobId,
      reason: fullReason,
      category: categoryMap[cancelReason]
    });
  };

  const handleStatusChange = async (
    assignmentId: string,
    jobId: string,
    currentStatus: string,
    targetLocation: LocationCoordinates,
    actionType: ActionType,
    areaType: AreaType
  ) => {
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }

    const globalEnabled = settings.enableRadiusEnforcement ?? true;
    const pickupEnabled = settings.enablePickupRadius ?? true;
    const dropoffEnabled = settings.enableDropoffRadius ?? true;
    const loggingEnabled = settings.logRadiusAttempts ?? true;
    
    const shouldEnforceRadius = globalEnabled && (
      (actionType === 'pickup' && pickupEnabled) ||
      (actionType === 'dropoff' && dropoffEnabled)
    );
    
    if (shouldEnforceRadius) {
      if (!driverLocation.coordinates) {
        toast.error('Unable to get your location. Please enable location access.');
        return;
      }
      
      const distance = calculateDistance(driverLocation.coordinates, targetLocation);
      const allowedRadius = getAllowedRadius(actionType, areaType);
      const withinRadius = distance <= allowedRadius;

      if (loggingEnabled) {
        await logDeliveryAction({
          assignmentId,
          jobId,
          actionType,
          driverLocation: driverLocation.coordinates,
          targetLocation,
          distanceMeters: distance,
          distanceYards: metersToYards(distance),
          withinRadius,
          areaType,
          allowedRadiusMeters: allowedRadius,
          success: withinRadius,
          failureReason: withinRadius ? undefined : 'Driver outside allowed radius'
        });
      }
      
      if (!withinRadius) {
        const failedAttempts = await getFailedAttemptsCount(assignmentId);
        toast.error(
          actionType === 'pickup' 
            ? `You are too far from pickup location. Distance: ${formatDistance(distance)} (${failedAttempts + 1} attempts)`
            : `You are too far from drop-off location. Distance: ${formatDistance(distance)} (${failedAttempts + 1} attempts)`,
          { duration: 5000 }
        );
        return;
      }
    }

    if (currentStatus === 'assigned') {
      updateStatusMutation.mutate({ assignmentId, newStatus: 'in_progress', jobId });
    } else if (currentStatus === 'in_progress') {
      setSelectedAssignment({ assignmentId, jobId });
      setPhotoModalOpen(true);
    }
  };

  const handlePhotoAccepted = async (photoBlob: Blob) => {
    if (!selectedAssignment) return;
    
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const fileName = `${selectedAssignment.assignmentId}-${Date.now()}.jpg`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('pickup-photos')
        .upload(fileName, photoBlob, {
          contentType: 'image/jpeg',
          upsert: false
        });
        
      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('pickup-photos')
        .getPublicUrl(fileName);

      const { error: updateError } = await supabase
        .from('job_assignments')
        .update({
          pickup_photo_url: publicUrl,
          status: 'picked_up',
          started_at: new Date().toISOString()
        })
        .eq('id', selectedAssignment.assignmentId);
        
      if (updateError) throw updateError;

      const { error: jobError } = await supabase
        .from('jobs')
        .update({ status: 'picked_up' })
        .eq('id', selectedAssignment.jobId);
        
      if (jobError) throw jobError;

      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      toast.success('Pickup photo saved and status updated');
      setPhotoModalOpen(false);
      setSelectedAssignment(null);
    } catch (error: any) {
      toast.error(error.message || 'Failed to save pickup photo');
    }
  };

  const handleDeliveryComplete = async (data: {
    dropoffLocation: string;
    photoBlob?: Blob;
    signature?: string;
    recipientName?: string;
  }) => {
    if (!selectedAssignment) return;
    
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      let publicUrl = '';
      if (data.photoBlob) {
        const fileName = `${selectedAssignment.assignmentId}-delivery-${Date.now()}.jpg`;
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('delivery-photos')
          .upload(fileName, data.photoBlob, {
            contentType: 'image/jpeg',
            upsert: false
          });
          
        if (uploadError) throw uploadError;

        const urlData = supabase.storage
          .from('delivery-photos')
          .getPublicUrl(fileName);
        publicUrl = urlData.data.publicUrl;
      }

      const { error: updateError } = await supabase
        .from('job_assignments')
        .update({
          delivery_photo_url: publicUrl || null,
          delivery_signature: data.signature || null,
          recipient_name: data.recipientName || null,
          status: 'delivered',
          completed_at: new Date().toISOString()
        })
        .eq('id', selectedAssignment.assignmentId);
        
      if (updateError) throw updateError;

      const dropoffParts = data.dropoffLocation?.split(' - ') || [];
      const dropoffLocationType = dropoffParts[0] || '';
      const specificDeliveryArea = dropoffParts[1] || '';

      let signatureUrl: string | undefined;
      if (data.signature) {
        const signatureBlob = await (await fetch(data.signature)).blob();
        const signatureFileName = `${selectedAssignment.jobId}_signature_${Date.now()}.png`;
        const { error: signatureUploadError } = await supabase.storage
          .from('signatures')
          .upload(signatureFileName, signatureBlob, {
            contentType: 'image/png',
            upsert: false
          });

        if (!signatureUploadError) {
          const { data: { publicUrl: sigPublicUrl } } = supabase.storage
            .from('signatures')
            .getPublicUrl(signatureFileName);
          signatureUrl = sigPublicUrl;
        }
      }

      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'delivered',
          actual_delivery_time: new Date().toISOString(),
          completed_at: new Date().toISOString(),
          proof_of_delivery_url: publicUrl || null,
          metadata: {
            signature_url: signatureUrl || null,
            recipient_name: data.recipientName || null,
            dropoff_location_type: dropoffLocationType,
            specific_delivery_area: specificDeliveryArea,
            actual_dropoff_location: data.dropoffLocation || null,
          }
        })
        .eq('id', selectedAssignment.jobId);
        
      if (jobError) throw jobError;

      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['completed-jobs'] });
      toast.success('Delivery completed successfully!');
      setDeliveryModalOpen(false);
      setSelectedAssignment(null);
    } catch (error: any) {
      toast.error(error.message || 'Failed to complete delivery');
    }
  };

  const handleNavigate = (location: any) => {
    setNavigationDestination({
      lat: location?.coordinates?.lat || location?.lat,
      lng: location?.coordinates?.lng || location?.lng,
      address: location?.address || 'Destination'
    });
    setNavigationModalOpen(true);
  };

  const toggleStopExpanded = (stopId: string) => {
    setExpandedStops(prev => ({
      ...prev,
      [stopId]: !prev[stopId]
    }));
  };

  // Helper functions for status display
  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'assigned':
      case 'planned':
        return 'secondary';
      case 'in_progress':
        return 'default';
      case 'picked_up':
        return 'default';
      case 'delivered':
        return 'default';
      default:
        return 'secondary';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'assigned':
        return 'Ready to Start';
      case 'planned':
        return 'Planned';
      case 'in_progress':
        return 'En Route to Pickup';
      case 'picked_up':
        return 'Package Picked Up';
      case 'delivered':
        return 'Delivered';
      default:
        return status;
    }
  };

  const calculateProgress = (status: string) => {
    switch (status) {
      case 'assigned':
      case 'planned':
        return 0;
      case 'in_progress':
        return 33;
      case 'picked_up':
        return 66;
      case 'delivered':
        return 100;
      default:
        return 0;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Loading your jobs...</div>
      </div>
    );
  }

  if (visibleJobs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-4">
        <Package className="h-16 w-16 text-muted-foreground/50" />
        <div className="text-center">
          <h3 className="text-lg font-semibold">No Active Jobs</h3>
          <p className="text-sm text-muted-foreground">Check Available Jobs to claim new deliveries</p>
        </div>
        <Button onClick={() => navigate('/driver-dashboard/available-jobs')}>
          Browse Available Jobs
        </Button>
      </div>
    );
  }

  // Get the most active job (prioritize in_progress > picked_up > assigned)
  const primaryJob = visibleJobs.find((a: any) => a.status === 'in_progress') ||
    visibleJobs.find((a: any) => a.status === 'picked_up') ||
    visibleJobs[0];
  const job = primaryJob?.jobs;
  const assignment = primaryJob;

  if (!job || !assignment) {
    return <div className="text-center p-8">No job details available</div>;
  }

  // Get all stops for this route (if it's part of a route)
  const currentRouteId = job.route_id;
  const currentRouteStops = currentRouteId 
    ? routeStops.filter((stop: any) => stop.route_id === currentRouteId)
    : [];
  
  // Get all jobs in this route
  const routeJobs = currentRouteId
    ? visibleJobs.filter((a: any) => a.jobs?.route_id === currentRouteId).map((a: any) => a.jobs)
    : [job];

  const pickupLoc = job.pickup_location as any;
  const deliveryLoc = job.delivery_location as any;
  const pickupAreaType = areaTypes[`${job.id}-pickup`] || 'urban';
  const dropoffAreaType = areaTypes[`${job.id}-dropoff`] || 'urban';

  return (
    <div className="max-w-4xl mx-auto space-y-4 pb-24">
      {/* Merged Map and Info Card - Hidden during in_progress/picked_up/delivered */}
      {assignment.status !== 'in_progress' && assignment.status !== 'picked_up' && assignment.status !== 'delivered' && (
        <Card className="relative shadow-lg animate-fade-in overflow-hidden border-0">
          {/* Map Section */}
          <div className="p-4">
            <JobMapView
              pickupLocation={pickupLoc}
              deliveryLocation={deliveryLoc}
              jobTitle={`#${job.id.slice(0, 8)}`}
            />
          </div>
          
          <CardContent className="p-4 pt-0">
            {/* Top Section - Action Buttons */}
            <div className="flex items-center gap-2 mb-4">
              <Button
                variant="destructive"
                size="lg"
                onClick={() => {
                  if (isSafeModeActive) {
                    toast.error('Action disabled: Safe mode is active');
                    return;
                  }
                  handleCancelClick(assignment.id, job.id);
                }}
                className="flex-1 gap-2 shadow-lg hover:shadow-xl transition-shadow"
              >
                <XCircle className="h-4 w-4" />
                Cancel Job
              </Button>
              
              {assignment.status === 'assigned' && (
                <Button
                  variant="default"
                  size="lg"
                  onClick={() => {
                    if (isSafeModeActive) {
                      toast.error('Action disabled: Safe mode is active');
                      return;
                    }
                    setSelectedJobForOnDuty(job.id);
                    setOnDutyModalOpen(true);
                  }}
                  className="flex-1 shadow-lg"
                >
                  <Play className="h-5 w-5 mr-2" />
                  Start Job
                </Button>
              )}

              {assignment.status === 'in_progress' && (
                <Button
                  variant="default"
                  size="lg"
                  onClick={() => {
                    if (isSafeModeActive) {
                      toast.error('Action disabled: Safe mode is active');
                      return;
                    }
                    setSelectedJobForPickup({ assignment, job });
                    setPickupModalOpen(true);
                  }}
                  className="flex-1 shadow-lg"
                >
                  <Package className="h-5 w-5 mr-2" />
                  Confirm Pickup
                </Button>
              )}

              {assignment.status === 'picked_up' && (
                <Button
                  variant="default"
                  size="lg"
                  onClick={() => {
                    if (isSafeModeActive) {
                      toast.error('Action disabled: Safe mode is active');
                      return;
                    }
                    setSelectedAssignment({ assignmentId: assignment.id, jobId: job.id, job });
                    setDeliveryModalOpen(true);
                  }}
                  className="flex-1 shadow-lg"
                >
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Mark Delivered
                </Button>
              )}
            </div>

            {/* Status Badge */}
            <div className="mb-4">
              <Badge variant={getStatusBadgeVariant(assignment.status)} className="px-2 py-1 text-xs w-fit">
                {getStatusText(assignment.status)}
              </Badge>
            </div>

            {/* Progress Bar */}
            <div className="mb-4">
              <Progress value={calculateProgress(assignment.status)} className="h-1.5" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Job Information Card */}
      <Card className="border-2 shadow-lg">
        <CardContent className="p-6 space-y-6">
          {/* Time & Distance Section - Hidden during in_progress/picked_up/delivered */}
          {assignment.status !== 'in_progress' && assignment.status !== 'picked_up' && assignment.status !== 'delivered' && (
            <div className="grid grid-cols-2 gap-4">
              {job.estimated_duration && (
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="text-sm font-semibold">{formatDuration(getJobDuration(job.estimated_duration, job.distance_miles))}</p>
                  </div>
                </div>
              )}
              {(job.metadata as any)?.distance && (
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                  <div className="flex-shrink-0 w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Navigation className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Distance</p>
                    <p className="text-sm font-semibold">{((job.metadata as any).distance).toFixed(1)} mi</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Route Stops Section - Show all stops if part of a route */}
          {currentRouteId && currentRouteStops.length > 0 ? (
            <div className="space-y-3">
              <div className="flex items-center gap-2 mb-3">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center border-2 border-primary/20">
                  <Navigation className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold text-base">Route Stops ({currentRouteStops.length})</h3>
                  <p className="text-xs text-muted-foreground">Complete stops in order</p>
                </div>
              </div>

              <div className="space-y-3">
                {currentRouteStops.map((stop: any, index: number) => {
                  const stopJob = routeJobs.find((j: any) => j.id === stop.job_id);
                  const isCompleted = stop.status === 'completed';
                  const isPending = stop.status === 'pending';
                  
                  return (
                    <div
                      key={stop.id}
                      className={`p-3 rounded-lg border-2 ${
                        isCompleted
                          ? 'bg-green-50 dark:bg-green-950/20 border-green-200 dark:border-green-800'
                          : isPending
                          ? 'bg-muted/50 border-muted-foreground/20'
                          : 'bg-primary/5 border-primary/20'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                          isCompleted
                            ? 'bg-green-500 text-white'
                            : 'bg-primary/20 text-primary'
                        }`}>
                          {stop.stop_sequence}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            {stop.stop_type === 'pickup' ? (
                              <Package className="h-4 w-4 text-primary flex-shrink-0" />
                            ) : (
                              <Truck className="h-4 w-4 text-primary flex-shrink-0" />
                            )}
                            <span className="text-sm font-semibold">
                              {stop.stop_type === 'pickup' ? 'Pickup' : 'Delivery'}
                            </span>
                            {isCompleted && (
                              <Badge variant="outline" className="text-xs bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 border-green-300">
                                Completed
                              </Badge>
                            )}
                          </div>
                          {stopJob?.title && (
                            <p className="text-xs text-muted-foreground mb-1">
                              {stopJob.title}
                            </p>
                          )}
                          <div className="flex items-start gap-1">
                            <MapPin className="h-3 w-3 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <p className="text-xs break-words">{stop.location?.address || 'Address not available'}</p>
                          </div>
                          {stop.scheduled_time && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {format(new Date(stop.scheduled_time), 'MMM d, h:mm a')}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            <>
              {/* Pickup Section */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center border-2 ${
                    assignment.status === 'picked_up' || assignment.status === 'delivered'
                      ? 'bg-gradient-to-br from-green-500 to-green-600 border-green-600'
                      : assignment.status === 'in_progress'
                      ? 'bg-gradient-to-br from-primary to-primary/80 border-primary/80 animate-pulse'
                      : 'bg-muted border-muted-foreground/20'
                  }`}>
                    <Package className="h-5 w-5 text-white" strokeWidth={2.5} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-base">Pickup Location</h3>
                    {job.pickup_time && (
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(job.pickup_time), 'MMM d, h:mm a')}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="ml-12 space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{pickupLoc?.address || 'Address not available'}</p>
                  </div>
                  
                  {pickupLoc?.contact_name && (
                    <div className="flex items-center gap-2 text-sm">
                      <User className="h-4 w-4 text-blue-600 flex-shrink-0" />
                      <div>
                        <p className="font-medium">{pickupLoc.contact_name}</p>
                        {pickupLoc?.contact_phone && (
                          <a href={`tel:${pickupLoc.contact_phone}`} className="text-primary hover:underline text-xs">
                            {pickupLoc.contact_phone}
                          </a>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Delivery Section */}
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <div className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center border-2 ${
                    assignment.status === 'delivered'
                      ? 'bg-gradient-to-br from-green-500 to-green-600 border-green-600'
                      : assignment.status === 'picked_up'
                      ? 'bg-gradient-to-br from-primary to-primary/80 border-primary/80 animate-pulse'
                      : 'bg-muted border-muted-foreground/20'
                  }`}>
                    <Truck className="h-5 w-5 text-white" strokeWidth={2.5} />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-base">Delivery Location</h3>
                    {job.delivery_time && (
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(job.delivery_time), 'MMM d, h:mm a')}
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="ml-12 space-y-3">
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{deliveryLoc?.address || 'Address not available'}</p>
                  </div>
                  
                  {deliveryLoc?.contact_name && (
                    <div className="flex items-center gap-2 text-sm">
                      <User className="h-4 w-4 text-blue-600 flex-shrink-0" />
                      <div>
                        <p className="font-medium">{deliveryLoc.contact_name}</p>
                        {deliveryLoc?.contact_phone && (
                          <a href={`tel:${deliveryLoc.contact_phone}`} className="text-primary hover:underline text-xs">
                            {deliveryLoc.contact_phone}
                          </a>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}

          {/* Action Button - Always visible */}
          <div className="pt-4 border-t">
            {assignment.status !== 'assigned' && (
              <Button
                variant="default"
                size="lg"
                onClick={() => {
                  if (isSafeModeActive) {
                    toast.error('Action disabled: Safe mode is active');
                    return;
                  }
                  if (assignment.status === 'delivered') {
                    completeJobMutation.mutate({ jobId: job.id, assignmentId: assignment.id });
                  } else {
                    setSelectedJobForOnDuty(job.id);
                    setOnDutyModalOpen(true);
                  }
                }}
                disabled={assignment.status === 'delivered' && !!completingIds[assignment.id]}
                className="w-full shadow-lg"
              >
                {assignment.status === 'delivered' ? (
                  <>
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Submit & Complete
                  </>
                ) : (
                  <>
                    <Play className="h-5 w-5 mr-2" />
                    Go Back on Duty
                  </>
                )}
              </Button>
            )}
          </div>

          {/* Additional Information - Hidden during in_progress/picked_up/delivered */}
          {assignment.status === 'assigned' && (job.special_instructions || (job.metadata as any)?.cargo_description || job.equipment_type) && (
            <div className="pt-4 border-t space-y-3">
              <h4 className="font-semibold text-sm text-muted-foreground">Additional Details</h4>
              
              <div className="flex items-center gap-2 text-sm">
                <span className="text-xs text-muted-foreground">ID:</span>
                <span className="text-xs font-mono font-semibold">#{job.id.slice(0, 8)}</span>
              </div>
              
              {job.special_instructions && (
                <div className="flex items-start gap-2 p-3 bg-amber-500/10 rounded-lg border border-amber-500/20">
                  <Info className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-xs font-medium text-amber-900 dark:text-amber-200 mb-1">Special Instructions</p>
                    <p className="text-xs text-amber-800 dark:text-amber-300">{job.special_instructions}</p>
                  </div>
                </div>
              )}
              
              <div className="grid grid-cols-2 gap-3">
                {(job.metadata as any)?.cargo_description && (
                  <div className="flex items-center gap-2 text-sm">
                    <Package className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs">{(job.metadata as any).cargo_description}</span>
                  </div>
                )}
                {job.equipment_type && (
                  <div className="flex items-center gap-2 text-sm">
                    <Truck className="h-4 w-4 text-muted-foreground" />
                    <span className="text-xs">{job.equipment_type}</span>
                  </div>
                )}
              </div>
              
              {job.signature_required && (
                <div className="flex items-center gap-2 p-2 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                  <FileText className="h-4 w-4 text-yellow-700 dark:text-yellow-500" />
                  <span className="text-xs font-medium text-yellow-700 dark:text-yellow-400">Signature Required</span>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Floating Action Bar - Hidden during in_progress/picked_up/delivered */}
      {assignment.status === 'assigned' && (
        <div className="fixed bottom-0 left-0 right-0 bg-background border-t shadow-lg p-4 space-y-2 md:relative md:border-0 md:shadow-none md:p-0">
          <div className="flex gap-2 max-w-4xl mx-auto">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => {
                if (isSafeModeActive) {
                  toast.error('Action disabled: Safe mode is active');
                  return;
                }
                handleCancelClick(assignment.id, job.id);
              }}
            >
              <XCircle className="h-4 w-4 mr-2" />
              Cancel Job
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => {
                setSelectedJobForDetails(job);
                setDetailsDialogOpen(true);
              }}
            >
              <FileText className="h-4 w-4 mr-2" />
              Details
            </Button>
          </div>
        </div>
      )}

      {/* Modals */}
      <PickupPhotoModal
        open={photoModalOpen}
        onClose={() => setPhotoModalOpen(false)}
        onPhotoAccepted={handlePhotoAccepted}
      />

      <OnDutyDeliveryModal
        open={deliveryModalOpen}
        onClose={() => setDeliveryModalOpen(false)}
        onDeliveryComplete={handleDeliveryComplete}
        signatureRequired={false}
        dropoffLocations={[]}
      />

      <NavigationModal
        open={navigationModalOpen}
        onOpenChange={setNavigationModalOpen}
        destination={navigationDestination}
      />

      <DriverJobDetailsDialog
        open={detailsDialogOpen}
        onOpenChange={setDetailsDialogOpen}
        job={selectedJobForDetails}
      />

      {/* Cancel Dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Job</AlertDialogTitle>
            <AlertDialogDescription>
              Please select a reason for cancellation. This job will be returned to the Available Jobs pool.
            </AlertDialogDescription>
          </AlertDialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="cancel-reason">Cancellation Reason</Label>
              <Select value={cancelReason} onValueChange={setCancelReason}>
                <SelectTrigger id="cancel-reason">
                  <SelectValue placeholder="Select a reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Vehicle issue">Vehicle issue</SelectItem>
                  <SelectItem value="Personal / Emergency Reasons">Personal / Emergency Reasons</SelectItem>
                  <SelectItem value="Preference-Based Reasons">Preference-Based Reasons</SelectItem>
                  <SelectItem value="Claim by Mistake">Claim by Mistake</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {cancelReason === 'Other' && (
              <div className="space-y-2">
                <Label htmlFor="cancel-details">Please provide details</Label>
                <Textarea
                  id="cancel-details"
                  value={cancelReasonDetails}
                  onChange={(e) => setCancelReasonDetails(e.target.value)}
                  placeholder="Explain your reason for cancellation..."
                  rows={3}
                />
              </div>
            )}
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel>Keep Job</AlertDialogCancel>
            <AlertDialogAction onClick={confirmCancel} disabled={!cancelReason}>
              Confirm Cancellation
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Modals */}
      <PickupPhotoModal
        open={photoModalOpen}
        onClose={() => setPhotoModalOpen(false)}
        onPhotoAccepted={handlePhotoAccepted}
      />
      
      {selectedJobForPickup && (
        <OnDutyPickupModal
          open={pickupModalOpen}
          onOpenChange={setPickupModalOpen}
          jobId={selectedJobForPickup.job.id}
          assignmentId={selectedJobForPickup.assignment.id}
          job={selectedJobForPickup.job}
          assignment={selectedJobForPickup.assignment}
          pickupLocation={selectedJobForPickup.job.pickup_location}
          areaType={areaTypes[`${selectedJobForPickup.job.id}-pickup`] || 'urban'}
          onPickupComplete={() => {
            queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
            setPickupModalOpen(false);
            setSelectedJobForPickup(null);
          }}
        />
      )}
      
      <OnDutyDeliveryModal
        open={deliveryModalOpen}
        onClose={() => setDeliveryModalOpen(false)}
        dropoffLocations={selectedAssignment?.job?.delivery_location ? [selectedAssignment.job.delivery_location] : []}
        signatureRequired={selectedAssignment?.job?.signature_required || false}
        onDeliveryComplete={handleDeliveryComplete}
        job={selectedAssignment?.job}
      />
      
      <NavigationModal
        open={navigationModalOpen}
        onOpenChange={setNavigationModalOpen}
        destination={navigationDestination}
      />
      
      {selectedJobForOnDuty && (
        <OnDutyModal
          open={onDutyModalOpen}
          onOpenChange={setOnDutyModalOpen}
          jobId={selectedJobForOnDuty}
        />
      )}
    </div>
  );
}
