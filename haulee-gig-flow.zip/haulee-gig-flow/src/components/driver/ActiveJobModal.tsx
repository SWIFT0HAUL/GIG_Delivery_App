import React, { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, MapPin, Package, Phone, User, Navigation, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { OnDutyDeliveryModal } from './OnDutyDeliveryModal';
import { JobStatusIndicator } from '@/components/job/JobStatusIndicator';

interface ActiveJobModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  jobId: string;
}

export const ActiveJobModal: React.FC<ActiveJobModalProps> = ({
  open,
  onOpenChange,
  jobId,
}) => {
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [deliveryModalOpen, setDeliveryModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  // Fetch job details
  const { data: job, isLoading } = useQuery({
    queryKey: ['active-job', jobId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', jobId)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!jobId && open,
    refetchInterval: 5000
  });

  // Auto-close if job is no longer active
  useEffect(() => {
    if (job && !['assigned', 'in_progress', 'picked_up'].includes(job.status)) {
      toast.info('Job completed or cancelled');
      onOpenChange(false);
    }
  }, [job?.status, onOpenChange]);

  // Handle delivery
  const handleDeliveryComplete = async (data: {
    dropoffLocation: string;
    photoBlob?: Blob;
    signature?: string;
    recipientName?: string;
  }) => {
    // Validate that we have either photo or signature
    if (!data.photoBlob && !data.signature) {
      toast.error('Photo or signature is required to complete delivery');
      return;
    }
    
    setIsProcessing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      let photoUrl: string | undefined;

      // Upload photo if provided
      if (data.photoBlob) {
        const photoFileName = `${jobId}_delivery_${Date.now()}.jpg`;
        const { error: photoUploadError } = await supabase.storage
          .from('delivery_photos')
          .upload(photoFileName, data.photoBlob, {
            contentType: 'image/jpeg',
            upsert: false
          });

        if (photoUploadError) throw photoUploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('delivery_photos')
          .getPublicUrl(photoFileName);
        
        photoUrl = publicUrl;
      }

      let signatureUrl: string | undefined;

      if (data.signature) {
        const signatureBlob = await (await fetch(data.signature)).blob();
        const signatureFileName = `${jobId}_signature_${Date.now()}.png`;
        const { error: signatureUploadError } = await supabase.storage
          .from('signatures')
          .upload(signatureFileName, signatureBlob, {
            contentType: 'image/png',
            upsert: false
          });

        if (signatureUploadError) throw signatureUploadError;

        const { data: { publicUrl } } = supabase.storage
          .from('signatures')
          .getPublicUrl(signatureFileName);
        
        signatureUrl = publicUrl;
      }

      // Parse dropoff location into type and specific area
      const dropoffParts = data.dropoffLocation?.split(' - ') || [];
      const dropoffLocationType = dropoffParts[0] || '';
      const specificDeliveryArea = dropoffParts[1] || '';

      const updateData: any = { 
        status: 'delivered',
        actual_delivery_time: new Date().toISOString(),
        completed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        metadata: {
          signature_url: signatureUrl || null,
          recipient_name: data.recipientName || null,
          dropoff_location_type: dropoffLocationType,
          specific_delivery_area: specificDeliveryArea,
          actual_dropoff_location: data.dropoffLocation || null,
        }
      };

      // Only include URLs if they exist
      if (photoUrl) updateData.proof_of_delivery_url = photoUrl;

      // First, update the driver's assignment to delivered
      const { data: authData } = await supabase.auth.getUser();
      const currentUser = authData?.user;
      if (!currentUser) throw new Error('Not authenticated');

      const { error: assignErr } = await supabase
        .from('job_assignments')
        .update({ status: 'delivered', completed_at: new Date().toISOString() })
        .eq('job_id', jobId)
        .eq('driver_id', currentUser.id);
      
      if (assignErr) {
        console.error('Assignment update error:', assignErr);
        throw new Error('Failed to update job status');
      }

      // Then, update the job status
      const { error: updateError } = await supabase
        .from('jobs')
        .update(updateData)
        .eq('id', jobId)
        .eq('assigned_driver_id', currentUser.id);

      if (updateError) {
        console.error('Job update error:', updateError);
        throw new Error('Failed to update job status');
      }

      await queryClient.invalidateQueries({ queryKey: ['active-job'] });
      await queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      toast.success('Delivery completed!');
      setDeliveryModalOpen(false);
      onOpenChange(false);
    } catch (error: any) {
      toast.error(error.message || 'Failed to complete delivery');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleNavigate = () => {
    if (!job) return;
    const location = job.status === 'in_progress' || job.status === 'assigned'
      ? job.pickup_location
      : job.delivery_location;
    
    const address = typeof location === 'object' && location !== null
      ? (location as any).address || (location as any).formatted_address
      : typeof location === 'string' ? location : null;
    
    if (address) {
      const url = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(address)}`;
      window.open(url, '_blank');
    }
  };

  const handleCall = (phone?: string) => {
    if (phone) {
      window.location.href = `tel:${phone}`;
    }
  };

  if (!job && !isLoading) {
    return null;
  }

  const currentLocation = job?.status === 'in_progress' || job?.status === 'assigned'
    ? job?.pickup_location
    : job?.delivery_location;

  const currentContact = job?.status === 'in_progress' || job?.status === 'assigned'
    ? { name: job?.pickup_contact_name, phone: job?.pickup_contact_phone }
    : { name: job?.delivery_contact_name, phone: job?.delivery_contact_phone };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
          {/* Header */}
          <div className="sticky top-0 z-10 bg-background border-b px-4 py-3 flex-shrink-0">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onOpenChange(false)}
              >
                <X className="h-5 w-5" />
              </Button>
              <div className="flex-1 min-w-0">
                <h1 className="font-semibold truncate">{job?.title}</h1>
                <p className="text-xs text-muted-foreground">
                  {job?.status === 'assigned' && 'Ready to start'}
                  {job?.status === 'in_progress' && 'Head to pickup'}
                  {job?.status === 'picked_up' && 'Deliver package'}
                </p>
              </div>
              {job?.status && (
                <JobStatusIndicator status={job.status} size="sm" />
              )}
            </div>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto p-4">
            {/* Content removed - only buttons remain */}
          </div>

          {/* Action Button */}
          <div className="sticky bottom-0 p-4 bg-background border-t flex-shrink-0">
            {job?.status === 'picked_up' && (
              <Button
                className="w-full h-12"
                onClick={() => setDeliveryModalOpen(true)}
                disabled={isProcessing}
              >
                {isProcessing ? 'Processing...' : 'Complete Delivery'}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Modals */}
      <OnDutyDeliveryModal
        open={deliveryModalOpen}
        onClose={() => setDeliveryModalOpen(false)}
        onDeliveryComplete={handleDeliveryComplete}
        signatureRequired={job?.signature_required || false}
        dropoffLocations={[]}
        job={job}
      />
    </>
  );
};
