import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Phone, User, FileText, AlertCircle, PenLine, Building2, Mail, MapPin, Calendar, Package, Truck, Weight, Ruler } from 'lucide-react';

interface Job {
  id: string;
  title: string;
  status?: string;
  special_instructions?: string;
  description?: string;
  pickup_contact_name?: string;
  pickup_contact_phone?: string;
  pickup_contact_email?: string;
  pickup_company_name?: string;
  delivery_contact_name?: string;
  delivery_contact_phone?: string;
  delivery_contact_email?: string;
  delivery_company_name?: string;
  signature_required?: boolean;
  pickup_location?: any;
  delivery_location?: any;
  scheduled_for?: string;
  pickup_date?: string;
  delivery_date?: string;
  vehicle_type?: string;
  cargo_weight?: number;
  cargo_dimensions?: string | number | any;
  cargo_description?: string;
  metadata?: any;
  distance_miles?: number;
  pay_amount?: number;
}

interface JobNotesModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  job: Job;
}

export const JobNotesModal: React.FC<JobNotesModalProps> = ({
  open,
  onOpenChange,
  job,
}) => {
  const isInProgress = job.status === 'in_progress';
  const isPickedUp = job.status === 'picked_up';

  const contactName = isPickedUp 
    ? job.delivery_contact_name 
    : job.pickup_contact_name;
  
  const contactPhone = isPickedUp 
    ? job.delivery_contact_phone 
    : job.pickup_contact_phone;

  const contactEmail = isPickedUp 
    ? job.delivery_contact_email 
    : job.pickup_contact_email;

  const companyName = isPickedUp 
    ? job.delivery_company_name 
    : job.pickup_company_name;

  const location = isPickedUp 
    ? job.delivery_location 
    : job.pickup_location;

  const contactLabel = isPickedUp ? 'Delivery Contact' : 'Pickup Contact';

  const formatAddress = (location: any) => {
    if (!location) return null;
    if (typeof location === 'string') return location;
    if (typeof location === 'object') {
      return location.formatted_address || location.address || null;
    }
    return null;
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    try {
      return new Date(dateString).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
      });
    } catch {
      return dateString;
    }
  };

  const formatDimensions = (dimensions: any): string | null => {
    if (!dimensions) return null;
    
    // If it's already a string, return it
    if (typeof dimensions === 'string') return dimensions;
    
    // If it's an object, format it
    if (typeof dimensions === 'object') {
      const parts = [];
      if (dimensions.length) parts.push(`L: ${dimensions.length}ft`);
      if (dimensions.width) parts.push(`W: ${dimensions.width}ft`);
      if (dimensions.height) parts.push(`H: ${dimensions.height}ft`);
      if (dimensions.pieces) parts.push(`Pieces: ${dimensions.pieces}`);
      
      return parts.length > 0 ? parts.join(' × ') : null;
    }
    
    return null;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-full max-h-full w-screen h-screen p-0 m-0 flex flex-col">
        <DialogHeader className="flex-shrink-0 pb-3 px-4 pt-4 border-b">
          <DialogTitle className="flex items-center gap-2 text-base sm:text-lg">
            <FileText className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
            <span className="truncate">Job Details & Instructions</span>
          </DialogTitle>
        </DialogHeader>
        
        <div className="overflow-y-auto flex-1 min-h-0 px-4 py-4">
          <div className="space-y-3 sm:space-y-4 max-w-2xl mx-auto">

            {/* Company Name */}
            {companyName && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <Building2 className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>{isPickedUp ? 'Delivery' : 'Pickup'} Company</span>
                  </h3>
                  <p className="text-xs sm:text-sm break-words">{companyName}</p>
                </div>
                <Separator />
              </>
            )}

            {/* Contact Details */}
            {(contactName || contactPhone || contactEmail) && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2">
                    {contactLabel}
                  </h3>
                  <div className="space-y-1 sm:space-y-2">
                    {contactName && (
                      <div className="flex items-center gap-2 text-xs sm:text-sm">
                        <User className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                        <span className="break-words">{contactName}</span>
                      </div>
                    )}
                    {contactPhone && (
                      <div className="flex items-center gap-2 text-xs sm:text-sm">
                        <Phone className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                        <a 
                          href={`tel:${contactPhone}`}
                          className="text-primary hover:underline break-all"
                        >
                          {contactPhone}
                        </a>
                      </div>
                    )}
                    {contactEmail && (
                      <div className="flex items-center gap-2 text-xs sm:text-sm">
                        <Mail className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                        <a 
                          href={`mailto:${contactEmail}`}
                          className="text-primary hover:underline break-all"
                        >
                          {contactEmail}
                        </a>
                      </div>
                    )}
                  </div>
                </div>
                <Separator />
              </>
            )}

            {/* Location */}
            {formatAddress(location) && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <MapPin className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>{isPickedUp ? 'Delivery' : 'Pickup'} Address</span>
                  </h3>
                  <p className="text-xs sm:text-sm whitespace-pre-wrap break-words">{formatAddress(location)}</p>
                </div>
                <Separator />
              </>
            )}

            {/* Date/Time */}
            {(job.pickup_date || job.delivery_date || job.scheduled_for) && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <Calendar className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>Schedule</span>
                  </h3>
                  <div className="space-y-1 text-xs sm:text-sm">
                    {job.pickup_date && (
                      <p><span className="font-medium">Pickup:</span> {formatDate(job.pickup_date)}</p>
                    )}
                    {job.delivery_date && (
                      <p><span className="font-medium">Delivery:</span> {formatDate(job.delivery_date)}</p>
                    )}
                    {job.scheduled_for && !job.pickup_date && (
                      <p><span className="font-medium">Scheduled:</span> {formatDate(job.scheduled_for)}</p>
                    )}
                  </div>
                </div>
                <Separator />
              </>
            )}

            {/* Special Instructions */}
            {job.special_instructions && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <AlertCircle className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>Special Instructions</span>
                  </h3>
                  <p className="text-xs sm:text-sm whitespace-pre-wrap bg-muted p-2 sm:p-3 rounded-md break-words">
                    {job.special_instructions}
                  </p>
                </div>
                <Separator />
              </>
            )}

            {/* Pickup Instructions from location object */}
            {location?.instructions && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <AlertCircle className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>{isPickedUp ? 'Delivery' : 'Pickup'} Instructions</span>
                  </h3>
                  <p className="text-xs sm:text-sm whitespace-pre-wrap bg-muted p-2 sm:p-3 rounded-md break-words">
                    {location.instructions}
                  </p>
                </div>
                <Separator />
              </>
            )}

            {/* Load/Cargo Description */}
            {(job.description || job.cargo_description) && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <FileText className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>Load Description</span>
                  </h3>
                  <p className="text-xs sm:text-sm whitespace-pre-wrap break-words">
                    {job.cargo_description || job.description}
                  </p>
                </div>
                <Separator />
              </>
            )}

            {/* Cargo Details */}
            {(job.vehicle_type || job.cargo_weight || job.cargo_dimensions || job.distance_miles) && (
              <>
                <div>
                  <h3 className="font-semibold text-xs sm:text-sm text-muted-foreground mb-1 sm:mb-2 flex items-center gap-1 sm:gap-2">
                    <Package className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                    <span>Cargo Details</span>
                  </h3>
                  <div className="space-y-1 text-xs sm:text-sm">
                    {job.vehicle_type && (
                      <div className="flex items-center gap-2">
                        <Truck className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        <span><span className="font-medium">Vehicle Type:</span> {job.vehicle_type}</span>
                      </div>
                    )}
                    {job.cargo_weight && (
                      <div className="flex items-center gap-2">
                        <Weight className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        <span><span className="font-medium">Weight:</span> {job.cargo_weight} lbs</span>
                      </div>
                    )}
                    {formatDimensions(job.cargo_dimensions) && (
                      <div className="flex items-center gap-2">
                        <Ruler className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        <span><span className="font-medium">Dimensions:</span> {formatDimensions(job.cargo_dimensions)}</span>
                      </div>
                    )}
                    {job.distance_miles && (
                      <div className="flex items-center gap-2">
                        <MapPin className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                        <span><span className="font-medium">Distance:</span> {job.distance_miles} miles</span>
                      </div>
                    )}
                  </div>
                </div>
                <Separator />
              </>
            )}


            {/* Signature Requirement */}
            {job.signature_required && (
              <div className="bg-primary/10 border-2 border-primary rounded-lg p-3 sm:p-4">
                <div className="flex items-center gap-2 text-xs sm:text-sm">
                  <div className="p-1.5 sm:p-2 bg-primary rounded-full">
                    <PenLine className="h-3 w-3 sm:h-4 sm:w-4 text-primary-foreground flex-shrink-0" />
                  </div>
                  <div>
                    <p className="font-bold text-primary text-sm sm:text-base">SIGNATURE REQUIRED</p>
                    <p className="text-xs sm:text-sm text-muted-foreground mt-0.5">
                      {isPickedUp ? 'Signature must be collected upon delivery' : 'Signature will be required at delivery'}
                    </p>
                  </div>
                </div>
              </div>
            )}

          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
