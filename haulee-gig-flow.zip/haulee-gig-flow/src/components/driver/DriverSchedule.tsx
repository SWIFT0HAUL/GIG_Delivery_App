import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Calendar as CalendarIcon, Clock, MapPin, DollarSign, Package, XCircle, Play, ChevronDown, ChevronUp } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, isSameDay, isAfter } from 'date-fns';
import { toast } from 'sonner';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

export function DriverSchedule() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [expandedJobs, setExpandedJobs] = useState<Record<string, boolean>>({});
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState('');
  const [cancelReasonDetails, setCancelReasonDetails] = useState('');
  const [jobToCancel, setJobToCancel] = useState<string | null>(null);
  const queryClient = useQueryClient();

  const toggleJobExpanded = (jobId: string) => {
    setExpandedJobs(prev => ({
      ...prev,
      [jobId]: !prev[jobId]
    }));
  };

  // Fetch planned jobs only
  const { data: plannedJobs = [], isLoading } = useQuery({
    queryKey: ['driver-planned-jobs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('assigned_driver_id', user.id)
        .eq('status', 'planned')
        .order('pickup_time', { ascending: true });

      if (error) throw error;
      
      return (data || []).filter((job: any) => job.pickup_time);
    }
  });

  // Get planned jobs for selected date and group by route
  const jobsForSelectedDate = React.useMemo(() => {
    const filteredJobs = plannedJobs.filter((job: any) => {
      if (!job?.pickup_time || !selectedDate) return false;
      return isSameDay(new Date(job.pickup_time), selectedDate);
    });

    // Group jobs by route_id
    const routeMap = new Map<string | null, any[]>();
    
    filteredJobs.forEach((job: any) => {
      const routeKey = job.route_id || `single-${job.id}`; // Jobs without route_id get unique key
      if (!routeMap.has(routeKey)) {
        routeMap.set(routeKey, []);
      }
      routeMap.get(routeKey)!.push(job);
    });

    // Convert to array of route groups
    return Array.from(routeMap.entries()).map(([routeId, jobs]) => ({
      id: routeId,
      route_id: routeId.startsWith('single-') ? null : routeId,
      jobs: jobs,
      status: 'planned',
      assigned_at: jobs[0].created_at
    }));
  }, [plannedJobs, selectedDate]);

  // Get dates with planned jobs for calendar highlighting
  const scheduledDates = plannedJobs
    .map((job: any) => job.pickup_time)
    .filter(Boolean)
    .map((date: string) => new Date(date));

  // Fetch route stops for expanded jobs
  const { data: routeStops = [] } = useQuery({
    queryKey: ['route-stops', Object.keys(expandedJobs).filter(id => expandedJobs[id])],
    queryFn: async () => {
      const expandedJobIds = Object.keys(expandedJobs).filter(id => expandedJobs[id]);
      if (expandedJobIds.length === 0) return [];

      const routeIds = plannedJobs
        .filter((job: any) => expandedJobIds.includes(job.id) && job.route_id)
        .map((job: any) => job.route_id);

      if (routeIds.length === 0) return [];

      const { data, error } = await supabase
        .from('route_stops')
        .select('*')
        .in('route_id', routeIds)
        .order('stop_sequence', { ascending: true });

      if (error) throw error;
      return data || [];
    },
    enabled: Object.values(expandedJobs).some(v => v)
  });

  // Cancel job mutation
  const cancelJobMutation = useMutation({
    mutationFn: async ({ jobId, reason, category }: {
      jobId: string;
      reason: string;
      category: 'vehicle_issue' | 'personal_emergency' | 'preference_based' | 'claim_by_mistake' | 'other';
    }) => {
      const { error } = await supabase
        .from('jobs')
        .update({ 
          status: 'posted',
          assigned_driver_id: null,
          cancellation_reason: reason,
          cancellation_reason_category: category,
          updated_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['driver-planned-jobs'] });
      toast.success('Job cancelled successfully');
      setCancelDialogOpen(false);
      setCancelReason('');
      setCancelReasonDetails('');
      setJobToCancel(null);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to cancel job');
    }
  });

  const handleCancelClick = (jobId: string) => {
    setJobToCancel(jobId);
    setCancelReason('');
    setCancelReasonDetails('');
    setCancelDialogOpen(true);
  };

  const confirmCancel = () => {
    if (!jobToCancel || !cancelReason) {
      toast.error('Please select a cancellation reason');
      return;
    }
    
    if (cancelReason === 'Other' && !cancelReasonDetails.trim()) {
      toast.error('Please provide details for cancellation');
      return;
    }
    
    const categoryMap: Record<string, 'vehicle_issue' | 'personal_emergency' | 'preference_based' | 'claim_by_mistake' | 'other'> = {
      'Vehicle issue': 'vehicle_issue',
      'Personal / Emergency Reasons': 'personal_emergency',
      'Preference-Based Reasons': 'preference_based',
      'Claim by Mistake': 'claim_by_mistake',
      'Other': 'other'
    };
    
    const fullReason = cancelReason === 'Other' 
      ? `Other: ${cancelReasonDetails}` 
      : cancelReason;
    
    cancelJobMutation.mutate({ 
      jobId: jobToCancel,
      reason: fullReason,
      category: categoryMap[cancelReason]
    });
  };

  // Activate job mutation
  const activateJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Update job to assigned status
      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'assigned',
          metadata: { manually_activated: true },
          updated_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (jobError) throw jobError;

      // Create or update job assignment
      const { error: assignmentError } = await supabase
        .from('job_assignments')
        .upsert({
          job_id: jobId,
          driver_id: user.id,
          status: 'assigned',
          assigned_at: new Date().toISOString()
        }, {
          onConflict: 'job_id,driver_id'
        });

      if (assignmentError) throw assignmentError;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['driver-planned-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      toast.success('Job activated and moved to My Jobs');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to activate job');
    }
  });

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full overflow-x-hidden">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold">Planned Routes</h2>
        <p className="text-sm sm:text-base text-muted-foreground">View your planned delivery routes</p>
      </div>

      <Tabs defaultValue="calendar" className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-2 h-9 sm:h-10">
          <TabsTrigger value="calendar" className="text-xs sm:text-sm">Calendar</TabsTrigger>
          <TabsTrigger value="list" className="text-xs sm:text-sm">List</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <Card>
              <CardHeader className="p-3 sm:p-6">
                <CardTitle className="text-base sm:text-lg">Select Date</CardTitle>
                <CardDescription className="text-xs sm:text-sm">View your scheduled jobs for any date</CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center p-3 sm:p-6">
                <Calendar
                  mode="single"
                  selected={selectedDate}
                  onSelect={setSelectedDate}
                  className="rounded-md border w-full max-w-full"
                  modifiers={{
                    scheduled: scheduledDates
                  }}
                  modifiersClassNames={{
                    scheduled: "font-bold"
                  }}
                  components={{
                    DayContent: ({ date, ...props }) => {
                      const hasScheduledJob = scheduledDates.some(scheduledDate => 
                        isSameDay(scheduledDate, date)
                      );
                      return (
                        <div className="relative w-full h-full flex items-center justify-center">
                          <span>{date.getDate()}</span>
                          {hasScheduledJob && (
                            <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
                          )}
                        </div>
                      );
                    }
                  }}
                />
              </CardContent>
            </Card>

            <div className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <CalendarIcon className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                    <span className="truncate">{selectedDate ? format(selectedDate, 'MMM d, yyyy') : 'Select a date'}</span>
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    {jobsForSelectedDate.reduce((sum, group) => sum + group.jobs.length, 0)} planned {jobsForSelectedDate.reduce((sum, group) => sum + group.jobs.length, 0) === 1 ? 'job' : 'jobs'}
                  </CardDescription>
                </CardHeader>
                 <CardContent className="space-y-3 p-3 sm:p-6 max-h-[400px] sm:max-h-[500px] overflow-y-auto">
                  {isLoading ? (
                    <p className="text-xs sm:text-sm text-muted-foreground">Loading planned routes...</p>
                  ) : jobsForSelectedDate.length === 0 ? (
                    <p className="text-xs sm:text-sm text-muted-foreground text-center py-4">
                      No planned jobs for this date
                    </p>
                  ) : (
                    jobsForSelectedDate.map((routeGroup: any) => {
                      const jobs = routeGroup.jobs; // Array of jobs
                      const isMultiJob = jobs.length > 1;
                      const totalPay = jobs.reduce((sum: number, job: any) => sum + (job.pay_amount || 0), 0);
                      
                      // For display, use first job's details
                      const firstJob = jobs[0];
                      const pickupTime = new Date(firstJob.pickup_time);
                      const isExpanded = expandedJobs[routeGroup.id];

                      // Build stops from all jobs in the route
                      const allStops: any[] = [];
                      jobs.forEach((job: any) => {
                        const pickupLoc = job.pickup_location as any;
                        const deliveryLoc = job.delivery_location as any;
                        
                        // Add pickup stop
                        allStops.push({ 
                          type: 'pickup', 
                          location: pickupLoc, 
                          time: job.pickup_time,
                          jobTitle: job.title,
                          jobId: job.id
                        });
                        
                        // Add intermediate route stops if any
                        const intermediateStops = routeStops.filter((stop: any) => stop.route_id === job.route_id);
                        allStops.push(...intermediateStops);
                        
                        // Add delivery stop
                        allStops.push({ 
                          type: 'delivery', 
                          location: deliveryLoc, 
                          time: job.delivery_time,
                          jobTitle: job.title,
                          jobId: job.id
                        });
                      });

                      return (
                        <Card key={routeGroup.id} className="w-full max-w-full">
                          <Collapsible open={isExpanded} onOpenChange={() => toggleJobExpanded(routeGroup.id)}>
                            <CollapsibleTrigger asChild>
                              <CardContent className="p-3 sm:pt-6 space-y-2 sm:space-y-3 cursor-pointer hover:bg-muted/30 transition-colors">
                                <div className="flex items-start justify-between gap-2">
                                  <div className="min-w-0 flex-1">
                                    <div className="flex items-center gap-2">
                                      <h4 className="font-semibold text-sm sm:text-base truncate">
                                        {isMultiJob ? `Route with ${jobs.length} jobs` : firstJob.title}
                                      </h4>
                                      {isExpanded ? <ChevronUp className="h-4 w-4 flex-shrink-0" /> : <ChevronDown className="h-4 w-4 flex-shrink-0" />}
                                    </div>
                                    <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm text-muted-foreground mt-1">
                                      <Clock className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                                      <span>{format(pickupTime, 'h:mm a')}</span>
                                    </div>
                                    {isMultiJob && (
                                      <div className="text-xs text-muted-foreground mt-1">
                                        {jobs.map((j: any, idx: number) => j.title).join(', ')}
                                      </div>
                                    )}
                                  </div>
                                  <Badge variant="secondary" className="text-xs sm:text-sm flex-shrink-0">${totalPay}</Badge>
                                </div>
                                <Badge variant="secondary" className="text-xs">
                                  {allStops.length} {allStops.length === 1 ? 'stop' : 'stops'}
                                </Badge>
                              </CardContent>
                            </CollapsibleTrigger>
                            <CollapsibleContent>
                              <CardContent className="px-3 pb-3 sm:px-6 sm:pb-6 pt-0 space-y-3">
                                {/* Jobs List */}
                                {isMultiJob && (
                                  <div className="space-y-2 border-t pt-3">
                                    <h5 className="font-semibold text-xs sm:text-sm">Jobs in this route</h5>
                                    {jobs.map((job: any, idx: number) => (
                                      <div key={job.id} className="flex justify-between items-center p-2 rounded bg-muted/50 text-xs sm:text-sm">
                                        <div className="flex-1 min-w-0">
                                          <p className="font-medium truncate">{job.title}</p>
                                          <p className="text-muted-foreground text-xs">
                                            {format(new Date(job.pickup_time), 'h:mm a')}
                                          </p>
                                        </div>
                                        <Badge variant="outline" className="text-xs">${job.pay_amount || '0'}</Badge>
                                      </div>
                                    ))}
                                  </div>
                                )}
                                
                                {/* Stops List */}
                                <div className="space-y-2 border-t pt-3">
                                  <h5 className="font-semibold text-xs sm:text-sm">Stops</h5>
                                  {allStops.map((stop: any, idx: number) => (
                                    <div key={idx} className="flex gap-2 text-xs sm:text-sm p-2 rounded bg-muted/50">
                                      <Badge variant="outline" className="text-xs h-fit">{idx + 1}</Badge>
                                      <div className="flex-1 min-w-0">
                                        <p className="font-medium">
                                          {stop.stop_type ? (stop.stop_type === 'pickup' ? 'Pick up' : 'Drop off') : (stop.type === 'pickup' ? 'Pick up' : 'Drop off')}
                                          {stop.jobTitle && ` (${stop.jobTitle})`}
                                        </p>
                                        <p className="text-muted-foreground truncate">
                                          {stop.address || (stop.location?.city && stop.location?.state ? `${stop.location.city}, ${stop.location.state}` : 'Location')}
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                                
                                {/* Action Buttons */}
                                <div className="flex gap-2 pt-2">
                                  {isMultiJob ? (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        // Activate all jobs in the route
                                        jobs.forEach((job: any) => activateJobMutation.mutate(job.id));
                                      }}
                                      disabled={activateJobMutation.isPending}
                                      className="flex-1"
                                    >
                                      <Play className="h-3 w-3 mr-1" />
                                      Activate All ({jobs.length})
                                    </Button>
                                  ) : (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        activateJobMutation.mutate(firstJob.id);
                                      }}
                                      disabled={activateJobMutation.isPending}
                                      className="flex-1"
                                    >
                                      <Play className="h-3 w-3 mr-1" />
                                      Activate
                                    </Button>
                                  )}
                                  <Button
                                    size="sm"
                                    variant="destructive"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleCancelClick(firstJob.id);
                                    }}
                                    disabled={cancelJobMutation.isPending}
                                    className="flex-1"
                                  >
                                    <XCircle className="h-3 w-3 mr-1" />
                                    Cancel {isMultiJob ? 'Route' : ''}
                                  </Button>
                                </div>
                              </CardContent>
                            </CollapsibleContent>
                          </Collapsible>
                        </Card>
                      );
                    })
                  )}
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="list" className="space-y-4">
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="text-base sm:text-lg">Planned Routes</CardTitle>
              <CardDescription className="text-xs sm:text-sm">All planned jobs in chronological order</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
              {isLoading ? (
                <p className="text-xs sm:text-sm text-muted-foreground">Loading planned routes...</p>
              ) : plannedJobs.length === 0 ? (
                <p className="text-xs sm:text-sm text-muted-foreground text-center py-8">
                  No planned routes yet. Check Route Planner to add jobs to your schedule!
                </p>
              ) : (
                (() => {
                  // Group jobs by route_id for list view
                  const routeMap = new Map<string | null, any[]>();
                  plannedJobs.forEach((job: any) => {
                    const routeKey = job.route_id || `single-${job.id}`;
                    if (!routeMap.has(routeKey)) {
                      routeMap.set(routeKey, []);
                    }
                    routeMap.get(routeKey)!.push(job);
                  });

                  // Convert to array and sort by earliest pickup time
                  const routeGroups = Array.from(routeMap.entries()).map(([routeId, jobs]) => ({
                    id: routeId,
                    route_id: routeId.startsWith('single-') ? null : routeId,
                    jobs: jobs.sort((a: any, b: any) => {
                      const timeA = a.pickup_time ? new Date(a.pickup_time).getTime() : 0;
                      const timeB = b.pickup_time ? new Date(b.pickup_time).getTime() : 0;
                      return timeA - timeB;
                    })
                  })).sort((a, b) => {
                    const timeA = a.jobs[0]?.pickup_time ? new Date(a.jobs[0].pickup_time).getTime() : 0;
                    const timeB = b.jobs[0]?.pickup_time ? new Date(b.jobs[0].pickup_time).getTime() : 0;
                    return timeA - timeB;
                  });

                  return routeGroups.map((routeGroup: any) => {
                    const jobs = routeGroup.jobs;
                    const isMultiJob = jobs.length > 1;
                    const totalPay = jobs.reduce((sum: number, job: any) => sum + (job.pay_amount || 0), 0);
                    const firstJob = jobs[0];
                    const pickupTime = firstJob.pickup_time ? new Date(firstJob.pickup_time) : null;
                    const isExpanded = expandedJobs[routeGroup.id];

                    // Build stops from all jobs
                    const allStops: any[] = [];
                    jobs.forEach((job: any) => {
                      const pickupLoc = job.pickup_location as any;
                      const deliveryLoc = job.delivery_location as any;
                      
                      allStops.push({ 
                        type: 'pickup', 
                        location: pickupLoc, 
                        time: job.pickup_time,
                        jobTitle: job.title
                      });
                      
                      const intermediateStops = routeStops.filter((stop: any) => stop.route_id === job.route_id);
                      allStops.push(...intermediateStops);
                      
                      allStops.push({ 
                        type: 'delivery', 
                        location: deliveryLoc, 
                        time: job.delivery_time,
                        jobTitle: job.title
                      });
                    });

                    return (
                      <Card key={routeGroup.id} className="w-full max-w-full">
                        <Collapsible open={isExpanded} onOpenChange={() => toggleJobExpanded(routeGroup.id)}>
                          <CollapsibleTrigger asChild>
                            <CardContent className="p-3 sm:pt-6 cursor-pointer hover:bg-muted/30 transition-colors">
                              <div className="space-y-3 sm:space-y-4">
                                <div className="flex flex-col sm:flex-row items-start justify-between gap-2">
                                  <div className="space-y-1 flex-1 min-w-0 w-full sm:w-auto">
                                    <div className="flex items-center gap-2">
                                      <h4 className="font-semibold text-base sm:text-lg break-words">
                                        {isMultiJob ? `Route with ${jobs.length} jobs` : firstJob.title}
                                      </h4>
                                      {isExpanded ? <ChevronUp className="h-4 w-4 flex-shrink-0" /> : <ChevronDown className="h-4 w-4 flex-shrink-0" />}
                                    </div>
                                    {pickupTime && (
                                      <div className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm">
                                        <CalendarIcon className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                                        <span className="text-muted-foreground">
                                          {format(pickupTime, 'EEE, MMM d')} at {format(pickupTime, 'h:mm a')}
                                        </span>
                                      </div>
                                    )}
                                    {isMultiJob && (
                                      <div className="text-xs text-muted-foreground mt-1">
                                        {jobs.map((j: any) => j.title).join(', ')}
                                      </div>
                                    )}
                                  </div>
                                  <Badge variant="secondary" className="text-sm sm:text-base px-2 sm:px-3 py-0.5 sm:py-1 flex-shrink-0">
                                    ${totalPay}
                                  </Badge>
                                </div>

                                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pt-2">
                                  <Badge variant="secondary" className="text-xs">
                                    {allStops.length} {allStops.length === 1 ? 'stop' : 'stops'}
                                  </Badge>
                                  {firstJob.distance_miles && (
                                    <span className="text-xs sm:text-sm text-muted-foreground">
                                      {firstJob.distance_miles} miles{firstJob.estimated_duration ? ` · ${firstJob.estimated_duration} min` : ''}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </CardContent>
                          </CollapsibleTrigger>
                          <CollapsibleContent>
                            <CardContent className="px-3 pb-3 sm:px-6 sm:pb-6 pt-0 space-y-3">
                              {/* Jobs List */}
                              {isMultiJob && (
                                <div className="space-y-2 border-t pt-3">
                                  <h5 className="font-semibold text-xs sm:text-sm">Jobs in this route</h5>
                                  {jobs.map((job: any) => (
                                    <div key={job.id} className="flex justify-between items-center p-2 rounded bg-muted/50 text-xs sm:text-sm">
                                      <div className="flex-1 min-w-0">
                                        <p className="font-medium truncate">{job.title}</p>
                                        <p className="text-muted-foreground text-xs">
                                          {job.pickup_time && format(new Date(job.pickup_time), 'h:mm a')}
                                        </p>
                                      </div>
                                      <Badge variant="outline" className="text-xs">${job.pay_amount || '0'}</Badge>
                                    </div>
                                  ))}
                                </div>
                              )}
                              
                              {/* Stops */}
                              <div className="space-y-2 border-t pt-3">
                                <h5 className="font-semibold text-sm">Stops</h5>
                                {allStops.map((stop: any, idx: number) => (
                                  <div key={idx} className="flex gap-2 text-xs sm:text-sm p-2 rounded bg-muted/50">
                                    <Badge variant="outline" className="text-xs h-fit">{idx + 1}</Badge>
                                    <div className="flex-1 min-w-0">
                                      <p className="font-medium">
                                        {stop.stop_type ? (stop.stop_type === 'pickup' ? 'Pick up' : 'Drop off') : (stop.type === 'pickup' ? 'Pick up' : 'Drop off')}
                                        {stop.jobTitle && ` (${stop.jobTitle})`}
                                      </p>
                                      <p className="text-muted-foreground truncate">
                                        {stop.address || (stop.location?.city && stop.location?.state ? `${stop.location.city}, ${stop.location.state}` : 'Location')}
                                      </p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                              
                              {/* Action Buttons */}
                              <div className="flex gap-2 pt-2">
                                {isMultiJob ? (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      jobs.forEach((job: any) => activateJobMutation.mutate(job.id));
                                    }}
                                    disabled={activateJobMutation.isPending}
                                    className="flex-1"
                                  >
                                    <Play className="h-3 w-3 mr-1" />
                                    Activate All ({jobs.length})
                                  </Button>
                                ) : (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      activateJobMutation.mutate(firstJob.id);
                                    }}
                                    disabled={activateJobMutation.isPending}
                                    className="flex-1"
                                  >
                                    <Play className="h-3 w-3 mr-1" />
                                    Activate
                                  </Button>
                                )}
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleCancelClick(firstJob.id);
                                  }}
                                  disabled={cancelJobMutation.isPending}
                                  className="flex-1"
                                >
                                  <XCircle className="h-3 w-3 mr-1" />
                                  Cancel {isMultiJob ? 'Route' : ''}
                                </Button>
                              </div>
                            </CardContent>
                          </CollapsibleContent>
                        </Collapsible>
                      </Card>
                    );
                  });
                })()
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Cancel Job Dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Job</AlertDialogTitle>
            <AlertDialogDescription>
              Please provide a reason for cancelling this job.
            </AlertDialogDescription>
          </AlertDialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="cancel-reason">Reason for Cancellation</Label>
              <Select value={cancelReason} onValueChange={setCancelReason}>
                <SelectTrigger id="cancel-reason">
                  <SelectValue placeholder="Select a reason" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Vehicle issue">Vehicle issue</SelectItem>
                  <SelectItem value="Personal / Emergency Reasons">Personal / Emergency Reasons</SelectItem>
                  <SelectItem value="Preference-Based Reasons">Preference-Based Reasons</SelectItem>
                  <SelectItem value="Claim by Mistake">Claim by Mistake</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {cancelReason === 'Other' && (
              <div className="space-y-2">
                <Label htmlFor="cancel-details">Please provide details</Label>
                <Textarea
                  id="cancel-details"
                  placeholder="Explain your reason for cancellation..."
                  value={cancelReasonDetails}
                  onChange={(e) => setCancelReasonDetails(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
            )}
          </div>

          <AlertDialogFooter>
            <AlertDialogCancel>Keep Job</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmCancel}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Confirm Cancel
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
