import React, { useState, useRef, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Camera, RotateCcw, Check } from 'lucide-react';
import { toast } from 'sonner';

interface PickupPhotoModalProps {
  open: boolean;
  onClose: () => void;
  onPhotoAccepted: (photoBlob: Blob) => void;
}

export function PickupPhotoModal({ open, onClose, onPhotoAccepted }: PickupPhotoModalProps) {
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (open && !capturedPhoto) {
      startCamera();
    }
    return () => {
      stopCamera();
    };
  }, [open, capturedPhoto]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: 1280, height: 720 },
      });
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (error) {
      toast.error('Failed to access camera. Please check permissions.');
      console.error('Camera error:', error);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.drawImage(video, 0, 0);
    const photoDataUrl = canvas.toDataURL('image/jpeg', 0.8);
    setCapturedPhoto(photoDataUrl);
    stopCamera();
  };

  const retakePhoto = () => {
    setCapturedPhoto(null);
    startCamera();
  };

  const acceptPhoto = async () => {
    if (!capturedPhoto) return;

    setIsLoading(true);
    try {
      // Convert data URL to Blob
      const response = await fetch(capturedPhoto);
      const blob = await response.blob();
      
      await onPhotoAccepted(blob);
      handleClose();
    } catch (error) {
      toast.error('Failed to save photo');
      console.error('Photo save error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    stopCamera();
    setCapturedPhoto(null);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[85vh] overflow-y-auto p-2 sm:p-6">
        <DialogHeader>
          <DialogTitle className="text-sm sm:text-lg">Take Pickup Photo</DialogTitle>
        </DialogHeader>

        <div className="space-y-2">
          <div className="relative bg-black rounded-lg overflow-hidden w-full mx-auto" style={{ aspectRatio: '4/3', maxHeight: '40vh' }}>
            {!capturedPhoto ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-contain"
              />
            ) : (
              <img
                src={capturedPhoto}
                alt="Captured"
                className="w-full h-full object-contain"
              />
            )}
          </div>

          <canvas ref={canvasRef} className="hidden" />

          <div className="flex gap-2 justify-center px-2">
            {!capturedPhoto ? (
              <Button onClick={capturePhoto} size="sm" className="text-xs sm:text-sm max-w-[200px]">
                <Camera className="mr-1 h-3 w-3 sm:h-5 sm:w-5" />
                Capture Photo
              </Button>
            ) : (
              <>
                <Button onClick={retakePhoto} variant="outline" size="sm" className="text-xs sm:text-sm flex-1 max-w-[140px]">
                  <RotateCcw className="mr-1 h-3 w-3 sm:h-5 sm:w-5" />
                  Retake
                </Button>
                <Button onClick={acceptPhoto} size="sm" disabled={isLoading} className="text-xs sm:text-sm flex-1 max-w-[140px]">
                  <Check className="mr-1 h-3 w-3 sm:h-5 sm:w-5" />
                  {isLoading ? 'Saving...' : 'Accept Photo'}
                </Button>
              </>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
