import React, { useEffect, useState } from 'react';
import { geocodeByAddress } from '@/lib/geocoding';
import { LeafletRouteMap } from '@/components/maps/LeafletRouteMap';

interface LocationData {
  lat?: number;
  lng?: number;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
}

interface JobMapViewProps {
  pickupLocation: LocationData | null;
  deliveryLocation: LocationData | null;
  jobTitle?: string;
}

export const JobMapView: React.FC<JobMapViewProps> = ({
  pickupLocation,
  deliveryLocation,
  jobTitle = 'Job',
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [geocodedPickup, setGeocodedPickup] = useState<{ lat: number; lng: number; address: string } | null>(null);
  const [geocodedDelivery, setGeocodedDelivery] = useState<{ lat: number; lng: number; address: string } | null>(null);

  // Helper to build address string from location object
  const buildAddressString = (location: LocationData): string | null => {
    if (location.address) return location.address;
    const parts = [];
    if (location.city) parts.push(location.city);
    if (location.state) parts.push(location.state);
    if (location.zipCode) parts.push(location.zipCode);
    return parts.length > 0 ? parts.join(', ') : null;
  };

  // Geocode locations if they don't have lat/lng
  useEffect(() => {
    const geocodeLocations = async () => {
      setIsLoading(true);
      
      // Pickup
      if (pickupLocation && !pickupLocation.lat) {
        const addressString = buildAddressString(pickupLocation);
        if (addressString) {
          try {
            const result = await geocodeByAddress(addressString);
            if (result) setGeocodedPickup(result);
          } catch (error) {
            console.error('Error geocoding pickup:', error);
          }
        }
      } else if (pickupLocation?.lat && pickupLocation?.lng) {
        setGeocodedPickup({
          lat: pickupLocation.lat,
          lng: pickupLocation.lng,
          address: pickupLocation.address || ''
        });
      }

      // Delivery
      if (deliveryLocation && !deliveryLocation.lat) {
        const addressString = buildAddressString(deliveryLocation);
        if (addressString) {
          try {
            const result = await geocodeByAddress(addressString);
            if (result) setGeocodedDelivery(result);
          } catch (error) {
            console.error('Error geocoding delivery:', error);
          }
        }
      } else if (deliveryLocation?.lat && deliveryLocation?.lng) {
        setGeocodedDelivery({
          lat: deliveryLocation.lat,
          lng: deliveryLocation.lng,
          address: deliveryLocation.address || ''
        });
      }
      
      setIsLoading(false);
    };

    geocodeLocations();
  }, [pickupLocation, deliveryLocation]);

  if (isLoading) {
    return (
      <div className="w-full h-64 sm:h-96 flex items-center justify-center bg-muted rounded-lg">
        <p className="text-sm text-muted-foreground">Loading map...</p>
      </div>
    );
  }

  if (!geocodedPickup || !geocodedDelivery) {
    return (
      <div className="w-full h-64 sm:h-96 flex items-center justify-center bg-muted rounded-lg">
        <p className="text-sm text-muted-foreground">Location data unavailable</p>
      </div>
    );
  }

  return (
    <LeafletRouteMap
      pickup={{
        lat: geocodedPickup.lat,
        lng: geocodedPickup.lng,
        label: geocodedPickup.address
      }}
      dropoff={{
        lat: geocodedDelivery.lat,
        lng: geocodedDelivery.lng,
        label: geocodedDelivery.address
      }}
      className="w-full h-64 sm:h-96 rounded-lg"
    />
  );
};
