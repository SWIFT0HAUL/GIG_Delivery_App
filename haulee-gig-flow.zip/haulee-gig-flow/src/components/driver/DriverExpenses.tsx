import React, { useState, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Receipt, Fuel, Car, Upload, Calendar, TrendingDown, Package } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';

export function DriverExpenses() {
  const [expenseType, setExpenseType] = useState('fuel');
  const [amount, setAmount] = useState('');
  const [expenseDate, setExpenseDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [description, setDescription] = useState('');
  const queryClient = useQueryClient();

  // Fetch driver expenses
  const { data: expenses = [], isLoading } = useQuery({
    queryKey: ['driver-expenses'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('driver_expenses')
        .select('*')
        .eq('driver_id', user.id)
        .order('expense_date', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    refetchInterval: 30000
  });

  // Add expense mutation
  const addExpenseMutation = useMutation({
    mutationFn: async (newExpense: any) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('driver_expenses')
        .insert({
          driver_id: user.id,
          expense_type: newExpense.expense_type,
          amount: parseFloat(newExpense.amount),
          expense_date: newExpense.expense_date,
          description: newExpense.description,
          category: newExpense.expense_type
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['driver-expenses'] });
      toast.success('Expense added successfully');
      // Reset form
      setExpenseType('fuel');
      setAmount('');
      setExpenseDate(format(new Date(), 'yyyy-MM-dd'));
      setDescription('');
    },
    onError: (error) => {
      toast.error('Failed to add expense: ' + error.message);
    }
  });

  const handleAddExpense = () => {
    if (!amount || parseFloat(amount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    addExpenseMutation.mutate({
      expense_type: expenseType,
      amount,
      expense_date: expenseDate,
      description
    });
  };

  // Calculate statistics
  const stats = useMemo(() => {
    const now = new Date();
    const weekStart = startOfWeek(now, { weekStartsOn: 1 });
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });
    const monthStart = startOfMonth(now);
    const monthEnd = endOfMonth(now);

    let weekTotal = 0;
    let monthTotal = 0;
    const categoryTotals: { [key: string]: { total: number; count: number } } = {};

    expenses.forEach((expense: any) => {
      const expenseDate = new Date(expense.expense_date);
      const amount = parseFloat(expense.amount);

      // Week total
      if (expenseDate >= weekStart && expenseDate <= weekEnd) {
        weekTotal += amount;
      }

      // Month total
      if (expenseDate >= monthStart && expenseDate <= monthEnd) {
        monthTotal += amount;
        
        // Category breakdown
        const category = expense.expense_type || 'other';
        if (!categoryTotals[category]) {
          categoryTotals[category] = { total: 0, count: 0 };
        }
        categoryTotals[category].total += amount;
        categoryTotals[category].count += 1;
      }
    });

    // Find top category
    let topCategory = { name: 'None', total: 0 };
    Object.entries(categoryTotals).forEach(([name, data]) => {
      if (data.total > topCategory.total) {
        topCategory = { name, total: data.total };
      }
    });

    // Calculate percentages
    const categoriesWithPercentage = Object.entries(categoryTotals).map(([name, data]) => ({
      name,
      total: data.total,
      count: data.count,
      percentage: monthTotal > 0 ? ((data.total / monthTotal) * 100).toFixed(0) : '0'
    }));

    return {
      weekTotal,
      monthTotal,
      monthCount: expenses.filter((e: any) => {
        const d = new Date(e.expense_date);
        return d >= monthStart && d <= monthEnd;
      }).length,
      topCategory,
      categories: categoriesWithPercentage
    };
  }, [expenses]);

  const getCategoryIcon = (type: string) => {
    switch (type) {
      case 'fuel': return <Fuel className="h-5 w-5 text-primary" />;
      case 'maintenance': return <Car className="h-5 w-5 text-primary" />;
      default: return <Receipt className="h-5 w-5 text-primary" />;
    }
  };

  const getCategoryLabel = (type: string) => {
    const labels: { [key: string]: string } = {
      fuel: 'Fuel',
      maintenance: 'Maintenance',
      tolls: 'Tolls & Parking',
      insurance: 'Insurance',
      other: 'Other'
    };
    return labels[type] || type;
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Expenses</h2>
        <p className="text-muted-foreground">Track and manage your work-related expenses</p>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-9 sm:h-10">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="add">Add Expense</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">Loading expenses...</p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">This Week</CardTitle>
                    <Receipt className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${stats.weekTotal.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground mt-1">Weekly expenses</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">This Month</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${stats.monthTotal.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground mt-1">{stats.monthCount} expenses logged</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Top Category</CardTitle>
                    <Fuel className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{getCategoryLabel(stats.topCategory.name)}</div>
                    <p className="text-xs text-muted-foreground mt-1">${stats.topCategory.total.toFixed(2)} total</p>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Expense Breakdown</CardTitle>
                  <CardDescription>Your expenses by category this month</CardDescription>
                </CardHeader>
                <CardContent>
                  {stats.categories.length === 0 ? (
                    <div className="text-center py-8 space-y-2">
                      <Package className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No expenses this month</p>
                      <p className="text-xs text-muted-foreground">Add your first expense to start tracking</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {stats.categories.map((category) => (
                        <div key={category.name} className="flex items-center justify-between p-3 border rounded-lg">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-primary/10 rounded-lg">
                              {getCategoryIcon(category.name)}
                            </div>
                            <div>
                              <p className="font-medium">{getCategoryLabel(category.name)}</p>
                              <p className="text-sm text-muted-foreground">{category.count} transactions</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-medium">${category.total.toFixed(2)}</p>
                            <Badge variant="secondary">{category.percentage}%</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>

        <TabsContent value="add" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Add New Expense</CardTitle>
              <CardDescription>Record a new work-related expense</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expense-type">Expense Type</Label>
                  <Select value={expenseType} onValueChange={setExpenseType}>
                    <SelectTrigger id="expense-type">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fuel">Fuel</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="tolls">Tolls & Parking</SelectItem>
                      <SelectItem value="insurance">Insurance</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="amount">Amount ($)</Label>
                  <Input 
                    id="amount" 
                    type="number" 
                    placeholder="0.00" 
                    step="0.01"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date">Date</Label>
                <Input 
                  id="date" 
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  max={format(new Date(), 'yyyy-MM-dd')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Input 
                  id="description" 
                  placeholder="Add details about this expense"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>

              <div className="flex gap-2">
                <Button 
                  className="flex-1"
                  onClick={handleAddExpense}
                  disabled={addExpenseMutation.isPending}
                >
                  {addExpenseMutation.isPending ? 'Saving...' : 'Save Expense'}
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => {
                    setExpenseType('fuel');
                    setAmount('');
                    setExpenseDate(format(new Date(), 'yyyy-MM-dd'));
                    setDescription('');
                  }}
                >
                  Clear
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Expense History</CardTitle>
              <CardDescription>Your recorded expenses over time</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="text-center py-8">
                  <p className="text-sm text-muted-foreground">Loading history...</p>
                </div>
              ) : expenses.length === 0 ? (
                <div className="text-center py-8 space-y-2">
                  <Package className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">No expenses recorded yet</p>
                  <p className="text-xs text-muted-foreground">Start tracking your expenses by adding your first one</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {expenses.map((expense: any) => (
                    <div key={expense.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          {getCategoryIcon(expense.expense_type)}
                        </div>
                        <div>
                          <p className="font-medium">
                            {getCategoryLabel(expense.expense_type)}
                            {expense.description && ` - ${expense.description}`}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(expense.expense_date), 'MMMM d, yyyy')}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium">${parseFloat(expense.amount).toFixed(2)}</p>
                        <Badge variant={expense.receipt_url ? "secondary" : "outline"}>
                          {expense.receipt_url ? 'Receipt' : 'No Receipt'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}