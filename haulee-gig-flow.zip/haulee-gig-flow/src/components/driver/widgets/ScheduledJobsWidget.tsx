import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card } from '@/components/ui/card';
import { Calendar, MapPin } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { JobCard } from '../JobCard';
import { DriverJobDetailsDialog } from '../DriverJobDetailsDialog';
import { AdminOverrideModal } from '../AdminOverrideModal';
import { useDriverCapacityCheck } from '@/hooks/useDriverCapacityCheck';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { filterJobsByDistance } from '@/lib/distanceCalculation';
import { useSafeMode } from '@/contexts/SafeModeContext';

export const ScheduledJobsWidget: React.FC = () => {
  const { t } = useTranslation();
  const { isSafeModeActive } = useSafeMode();
  const queryClient = useQueryClient();
  const [claimingJobId, setClaimingJobId] = useState<string | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [overrideModalOpen, setOverrideModalOpen] = useState(false);
  const [pendingOverrideJob, setPendingOverrideJob] = useState<{ jobId: string; conflictingJobs: any[] } | null>(null);
  const { coordinates: driverLocation, isLoading: isLoadingLocation, error: locationError } = useDriverLocation();

  // Fetch available jobs (jobs with future pickup times)
  const { data: scheduledJobs = [], isLoading } = useQuery({
    queryKey: ['scheduled-jobs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get all pending jobs with future pickup times
      const { data: jobs, error: jobsError } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'pending')
        .not('pickup_time', 'is', null)
        .gte('pickup_time', new Date().toISOString())
        .order('pickup_time', { ascending: true })
        .limit(1000);
      
      if (jobsError) throw jobsError;

      // Fetch only the current driver's assignments
      const { data: assignments, error: assignmentsError } = await supabase
        .from('job_assignments')
        .select('job_id')
        .eq('driver_id', user.id);
      
      if (assignmentsError) throw assignmentsError;

      // Filter out jobs that this driver has claimed and keep only scheduled ones
      const assignedJobIds = new Set(assignments?.map(a => a.job_id) || []);
      let availableJobs = (jobs || []).filter(job =>
        !assignedJobIds.has(job.id) && (
          (job.pickup_time && new Date(job.pickup_time).toISOString() >= new Date().toISOString()) ||
          job.priority === 'scheduled'
        )
      );

      return availableJobs.slice(0, 1000);
    },
    refetchInterval: 10000, // Auto-refresh every 10 seconds
    enabled: !isLoadingLocation // Wait for location before fetching jobs
  });

  // Claim scheduled job mutation using atomic function
  const claimJobMutation = useMutation({
    mutationFn: async ({ jobId, adminOverride = false, overrideReason }: { 
      jobId: string; 
      adminOverride?: boolean; 
      overrideReason?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Use atomic claim function that handles driver assignment and status update together
      const { data: claimResult, error: claimError } = await supabase.rpc('claim_job_atomic' as any, {
        p_job_id: jobId,
        p_driver_id: user.id,
        p_admin_override: adminOverride,
        p_override_reason: overrideReason || null
      } as any);

      if (claimError) throw claimError;

      const claim = claimResult as any;
      if (!claim?.success) {
        // Check if it's an overlap error that can be overridden
        if (claim?.overlap_detected && claim?.can_override) {
          throw { 
            isOverlapError: true, 
            conflictingJobs: claim.conflicting_jobs || [],
            message: claim.error 
          };
        }
        throw new Error(claim?.error || 'Failed to claim job');
      }

      return { assignment_id: claim.assignment_id, override_applied: claim.override_applied };
    },
    onSuccess: async (res, { jobId }) => {
      // Optimistically remove the job from the scheduled jobs list
      queryClient.setQueryData(['scheduled-jobs'], (old: any[] = []) => 
        old.filter(job => job.id !== jobId)
      );
      
      // Refetch all related queries
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['scheduled-jobs'] }),
        queryClient.invalidateQueries({ queryKey: ['planned-jobs'] }),
        queryClient.invalidateQueries({ queryKey: ['active-jobs'] })
      ]);
      
      toast.success(res.override_applied ? 'Job claimed with admin override!' : 'Scheduled job claimed successfully!');
      setClaimingJobId(null);
      setPendingOverrideJob(null);
      setOverrideModalOpen(false);

      // Trigger route optimization for scheduled jobs
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Get the job to extract the route date
        const { data: job } = await supabase
          .from('jobs')
          .select('pickup_time, status')
          .eq('id', jobId)
          .single();
        
        if (job?.pickup_time && job?.status === 'planned') {
          const routeDate = new Date(job.pickup_time).toISOString().split('T')[0];
          
          // Call auto-optimize-route edge function
          const { error: optimizeError } = await supabase.functions.invoke('auto-optimize-route', {
            body: {
              driver_id: user.id,
              route_date: routeDate,
              job_id: jobId
            }
          });
          
          if (optimizeError) {
            console.warn('Route optimization failed:', optimizeError);
          } else {
            console.log('Route optimization triggered successfully');
          }
        }
      } catch (error) {
        console.warn('Failed to trigger route optimization:', error);
      }
    },
    onError: (error: any) => {
      // Check if it's an overlap error that can be overridden
      if (error.isOverlapError) {
        setPendingOverrideJob({
          jobId: claimingJobId!,
          conflictingJobs: error.conflictingJobs || []
        });
        setOverrideModalOpen(true);
        return;
      }
      
      const errorMessage = error.message || 'Failed to claim job';
      if (errorMessage.includes('pickup_time') || errorMessage.includes('pickup date')) {
        toast.error('Please set pickup date and time for this job before scheduling');
      } else if (errorMessage.includes('overlapping schedule')) {
        toast.error('Cannot claim: This job overlaps with your existing schedule');
      } else {
        toast.error(errorMessage);
      }
      setClaimingJobId(null);
    }
  });

  const handleClaim = (jobId: string) => {
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }

    const job = scheduledJobs.find(j => j.id === jobId);
    if (job?.status === 'on_hold') {
      toast.error('Cannot claim job: This job is currently on hold');
      return;
    }
    setClaimingJobId(jobId);
    claimJobMutation.mutate({ jobId });
  };

  const handleAdminOverride = (reason: string) => {
    if (pendingOverrideJob) {
      claimJobMutation.mutate({
        jobId: pendingOverrideJob.jobId,
        adminOverride: true,
        overrideReason: reason
      });
    }
  };

  const handleJobClick = (jobId: string) => {
    setSelectedJobId(jobId);
    setDialogOpen(true);
  };

  const selectedJob = scheduledJobs.find(job => job.id === selectedJobId);

  if (isLoadingLocation) {
    return (
      <Card className="p-3 sm:p-4 w-full max-w-full">
        <div className="flex items-center justify-between gap-2 mb-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold">
            <Calendar className="h-4 w-4 flex-shrink-0" />
            {t('driver.jobs.scheduledJobs')}
          </h3>
        </div>
        <div className="text-xs text-muted-foreground flex items-center gap-2">
          <MapPin className="h-3 w-3 animate-pulse" />
          {t('driver.jobs.gettingLocation')}
        </div>
      </Card>
    );
  }

  if (locationError) {
    return (
      <Card className="p-3 sm:p-4 w-full max-w-full">
        <div className="flex items-center justify-between gap-2 mb-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold">
            <Calendar className="h-4 w-4 flex-shrink-0" />
            {t('driver.jobs.scheduledJobs')}
          </h3>
        </div>
        <div className="text-xs text-destructive">
          {locationError} - {t('driver.jobs.locationError')}
        </div>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="p-3 sm:p-4 w-full max-w-full">
        <div className="flex items-center justify-between gap-2 mb-3">
          <h3 className="flex items-center gap-2 text-sm font-semibold">
            <Calendar className="h-4 w-4 flex-shrink-0" />
            {t('driver.jobs.scheduledJobs')}
          </h3>
        </div>
        <div className="text-xs text-muted-foreground">{t('driver.jobs.loadingScheduled')}</div>
      </Card>
    );
  }

  return (
    <Card className="p-3 sm:p-4 w-full max-w-full">
      <div className="flex items-center justify-between gap-2 mb-3">
        <h3 className="flex items-center gap-2 text-sm font-semibold">
          <Calendar className="h-4 w-4 flex-shrink-0" />
          {t('driver.jobs.scheduledJobs')}
        </h3>
        {driverLocation && (
          <div className="text-xs text-muted-foreground flex items-center gap-1 flex-shrink-0">
            <MapPin className="h-3 w-3" />
            75mi
          </div>
        )}
      </div>
      <div className="space-y-2 w-full max-w-full">
        {scheduledJobs.length === 0 ? (
          <div className="text-xs text-muted-foreground text-center py-3">
            {t('driver.jobs.noScheduledJobs')}
          </div>
        ) : (
          scheduledJobs.map((job) => (
            <JobCard
              key={job.id}
              job={job}
              type="scheduled"
              onClick={handleJobClick}
              driverLocation={driverLocation}
            />
          ))
        )}
      </div>

      {selectedJob && (
        <DriverJobDetailsDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          job={selectedJob}
          type="scheduled"
          onClaim={handleClaim}
          isClaiming={claimingJobId === selectedJob.id}
          canClaim={true}
        />
      )}

      <AdminOverrideModal
        open={overrideModalOpen}
        onOpenChange={setOverrideModalOpen}
        onConfirm={handleAdminOverride}
        conflictingJobs={pendingOverrideJob?.conflictingJobs}
        isLoading={claimJobMutation.isPending}
      />
    </Card>
  );
};
