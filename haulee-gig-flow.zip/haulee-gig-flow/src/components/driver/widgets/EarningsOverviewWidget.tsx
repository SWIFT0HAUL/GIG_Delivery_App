import React from 'react';
import { useTranslation } from 'react-i18next';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, TrendingUp, Wallet } from 'lucide-react';
export const EarningsOverviewWidget: React.FC = () => {
  const { t } = useTranslation();
  const earnings = {
    today: 127.50,
    thisWeek: 542.30,
    thisMonth: 2156.80,
    pending: 89.25
  };
  return <Card className="p-3 sm:p-4 w-full max-w-full">
      <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
        <Wallet className="h-4 w-4 flex-shrink-0" />
        {t('driver.earnings.overview')}
      </h3>
      <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">{t('driver.earnings.today')}</p>
            <p className="font-bold flex items-center text-base">
              <DollarSign className="h-4 w-4 flex-shrink-0" />
              <span className="truncate text-lg">{earnings.today.toFixed(2)}</span>
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">{t('driver.earnings.thisWeek')}</p>
            <p className="text-lg font-bold flex items-center">
              <DollarSign className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{earnings.thisWeek.toFixed(2)}</span>
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">{t('driver.earnings.thisMonth')}</p>
            <p className="text-lg font-bold flex items-center gap-1">
              <DollarSign className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{earnings.thisMonth.toFixed(2)}</span>
              <TrendingUp className="h-3 w-3 text-green-500 flex-shrink-0" />
            </p>
          </div>
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">{t('driver.earnings.pending')}</p>
            <p className="text-lg font-bold flex items-center text-yellow-600">
              <DollarSign className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{earnings.pending.toFixed(2)}</span>
            </p>
          </div>
        </div>
    </Card>;
};