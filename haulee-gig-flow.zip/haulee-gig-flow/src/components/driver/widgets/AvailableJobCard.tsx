import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { MapPin, DollarSign, FileText, Clock, Truck, Navigation } from 'lucide-react';
import { PriorityIndicator } from '@/components/job/JobStatusIndicator';
import { JobNotesModal } from '../JobNotesModal';
import { calculateDistance, getJobCoordinates } from '@/lib/distanceCalculation';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';

interface AvailableJobCardProps {
  job: {
    id: string;
    title: string;
    status?: string;
    pickup_location: any;
    delivery_location: any;
    pay_amount?: number;
    estimated_duration?: number;
    distance_miles?: number;
    pickup_time?: string;
    equipment_type?: string;
    trailer_type?: string;
    is_hazmat?: boolean;
    priority?: string;
    special_instructions?: string;
    description?: string;
    pickup_contact_name?: string;
    pickup_contact_phone?: string;
    delivery_contact_name?: string;
    delivery_contact_phone?: string;
  };
  type?: 'pickup_now' | 'scheduled';
  onClick?: (jobId: string) => void;
  showNotesButton?: boolean;
  driverLocation?: { lat: number; lng: number } | null;
}

// Extract city and state from address
const getLocationShort = (location: any) => {
  // Check if location has separate city and state fields
  if (location?.city && location?.state) {
    const stateInitials = location.state.substring(0, 2).toUpperCase();
    return `${location.city}, ${stateInitials}`;
  }
  
  // Otherwise try to parse from address string
  if (!location?.address) return 'Location';
  const parts = location.address.split(',').map((p: string) => p.trim());
  if (parts.length >= 3) {
    // Get city (second to last) and state initials (last)
    const stateInitials = parts[parts.length - 1].substring(0, 2).toUpperCase();
    return `${parts[parts.length - 2]}, ${stateInitials}`;
  } else if (parts.length === 2) {
    // If only 2 parts, assume they are city and state
    const stateInitials = parts[1].substring(0, 2).toUpperCase();
    return `${parts[0]}, ${stateInitials}`;
  }
  
  // If no commas found, return the address as is (fallback)
  return location.address;
};

export const AvailableJobCard: React.FC<AvailableJobCardProps> = ({
  job,
  type = 'pickup_now',
  onClick,
  showNotesButton = false,
  driverLocation,
}) => {
  const { t } = useTranslation();
  const [showNotesModal, setShowNotesModal] = useState(false);
  const pickupLoc = job.pickup_location;
  const deliveryLoc = job.delivery_location;

  // Calculate heading distance (driver to pickup)
  const headingDistance = React.useMemo(() => {
    if (!driverLocation) return null;
    const pickupCoords = getJobCoordinates(pickupLoc);
    if (!pickupCoords) return null;
    return calculateDistance(
      driverLocation.lat,
      driverLocation.lng,
      pickupCoords.lat,
      pickupCoords.lng
    );
  }, [driverLocation, pickupLoc]);

  return (
    <>
      <Card 
        className="group relative overflow-hidden w-full cursor-pointer hover:shadow-xl transition-all duration-300 border-l-2 border-l-primary/60 hover:border-l-primary"
        onClick={() => onClick?.(job.id)}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            onClick?.(job.id);
          }
        }}
      >
        {/* Gradient overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        <div className="relative p-2">
          {/* Top row: Title and Priority + Pay */}
          <div className="flex items-start justify-between gap-1.5 mb-1.5">
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-xs truncate mb-0.5">{job.title}</h3>
              {job.priority && <PriorityIndicator priority={job.priority} size="sm" />}
            </div>
            <div className="flex flex-col items-end gap-0 bg-primary/10 px-1.5 py-1 rounded-md">
              <div className="text-[9px] text-muted-foreground font-medium leading-tight">{t('driver.jobs.payout')}</div>
              <div className="flex items-center gap-0 text-primary font-bold text-sm">
                <DollarSign className="h-3 w-3" />
                <span>{job.pay_amount || '0'}</span>
              </div>
            </div>
          </div>

          {/* Route visualization */}
          <div className="relative bg-muted/30 rounded-md p-1.5 mb-1.5">
            <div className="flex items-center gap-1">
              <div className="flex items-center gap-0.5">
                <div className="w-2 h-2 rounded-full bg-green-500 ring-1 ring-green-200" />
                <div className="w-4 h-0.5 bg-gradient-to-r from-green-500 to-orange-500" />
                <div className="w-2 h-2 rounded-full bg-orange-500 ring-1 ring-orange-200" />
              </div>
              <div className="flex-1 flex items-center gap-2 min-w-0">
                <div className="flex-1 min-w-0 text-[11px] truncate leading-tight">
                  <span className="text-[9px] text-muted-foreground font-medium">{t('driver.jobs.pickup')}: </span>
                  <span className="font-semibold">{getLocationShort(pickupLoc)}</span>
                </div>
                <div className="flex-1 min-w-0 text-[11px] truncate leading-tight">
                  <span className="text-[9px] text-muted-foreground font-medium">{t('driver.jobs.delivery')}: </span>
                  <span className="font-semibold">{getLocationShort(deliveryLoc)}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Stats grid */}
          <div className="grid grid-cols-3 gap-1 mb-1.5">
            <div className="bg-muted/50 rounded-sm p-1 text-center">
              <Navigation className="h-2.5 w-2.5 mx-auto mb-0.5 text-primary" />
              <div className="text-[8px] text-muted-foreground leading-tight">{t('driver.jobs.toPickup')}</div>
              <div className="text-[10px] font-bold leading-tight">{headingDistance !== null ? `${headingDistance.toFixed(1)}mi` : '--'}</div>
            </div>
            <div className="bg-muted/50 rounded-sm p-1 text-center">
              <Truck className="h-2.5 w-2.5 mx-auto mb-0.5 text-primary" />
              <div className="text-[8px] text-muted-foreground leading-tight">{t('driver.jobs.toDropOff')}</div>
              <div className="text-[10px] font-bold leading-tight">{typeof job.distance_miles === 'number' ? `${job.distance_miles}mi` : '--'}</div>
            </div>
            <div className="bg-muted/50 rounded-sm p-1 text-center">
              <Clock className="h-2.5 w-2.5 mx-auto mb-0.5 text-primary" />
              <div className="text-[8px] text-muted-foreground leading-tight">{t('driver.jobs.duration')}</div>
              <div className="text-[10px] font-bold leading-tight">{formatDuration(getJobDuration(job.estimated_duration, job.distance_miles))}</div>
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-wrap items-center gap-1">
            {job.equipment_type && (
              <Badge variant="secondary" className="text-[9px] font-medium h-4 px-1.5">
                {job.equipment_type}
              </Badge>
            )}
            {job.trailer_type && (
              <Badge variant="outline" className="text-[9px] h-4 px-1.5">
                {job.trailer_type}
              </Badge>
            )}
            {job.is_hazmat && (
              <Badge variant="destructive" className="text-[9px] font-semibold h-4 px-1.5">
                {t('driver.jobs.hazmat')}
              </Badge>
            )}
          </div>

          {showNotesButton && (
            <div className="mt-1.5 pt-1.5 border-t">
              <Button
                size="sm"
                variant="ghost"
                className="w-full h-6 text-[10px] hover:bg-primary/10"
                onClick={(e) => {
                  e.stopPropagation();
                  setShowNotesModal(true);
                }}
              >
                <FileText className="h-3 w-3 mr-1" />
                {t('driver.jobs.viewNotes')}
              </Button>
            </div>
          )}
        </div>
      </Card>

      <JobNotesModal
        open={showNotesModal}
        onOpenChange={setShowNotesModal}
        job={job}
      />
    </>
  );
};
