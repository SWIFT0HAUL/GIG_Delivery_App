import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Package, MapPin } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { AvailableJobCard } from './AvailableJobCard';
import { DriverJobDetailsDialog } from '../DriverJobDetailsDialog';
import { AdminOverrideModal } from '../AdminOverrideModal';
import { useDriverCapacityCheck } from '@/hooks/useDriverCapacityCheck';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { filterJobsByDistance } from '@/lib/distanceCalculation';
import { useSafeMode } from '@/contexts/SafeModeContext';
import { useUserRole } from '@/hooks/useUserRole';

export const AvailableJobsWidget: React.FC = () => {
  const { isSafeModeActive } = useSafeMode();
  const queryClient = useQueryClient();
  const { profile } = useUserRole();
  const [claimingJobId, setClaimingJobId] = useState<string | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [overrideModalOpen, setOverrideModalOpen] = useState(false);
  const [pendingOverrideJob, setPendingOverrideJob] = useState<{ jobId: string; conflictingJobs: any[] } | null>(null);
  const { coordinates: driverLocation, isLoading: isLoadingLocation, error: locationError } = useDriverLocation();

  // Fetch all available jobs (both pickup now and scheduled)
  const { data: availableJobs = [], isLoading } = useQuery({
    queryKey: ['all-available-jobs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get jobs based on driver sub_role
      let query = supabase
        .from('jobs')
        .select('*');
      
      // Carrier drivers see jobs with status 'claimed' (Accepted)
      // Regular drivers see jobs with status 'posted'
      if (profile?.sub_role === 'carrier_driver') {
        query = query.eq('status', 'claimed');
      } else {
        query = query.eq('status', 'posted');
      }
      
      const { data: jobs, error: jobsError } = await query
        .order('pickup_time', { ascending: true, nullsFirst: true })
        .order('created_at', { ascending: false })
        .limit(1000);
      
      if (jobsError) throw jobsError;

      // Fetch only the current driver's assignments
      const { data: assignments, error: assignmentsError } = await supabase
        .from('job_assignments')
        .select('job_id')
        .eq('driver_id', user.id);
      
      if (assignmentsError) throw assignmentsError;

      // Filter out jobs that this driver has claimed
      const assignedJobIds = new Set(assignments?.map(a => a.job_id) || []);
      let availableJobs = (jobs || []).filter(job => !assignedJobIds.has(job.id));

      return availableJobs.slice(0, 1000);
    },
    refetchInterval: 10000, // Auto-refresh every 10 seconds
    enabled: !isLoadingLocation // Wait for location before fetching jobs
  });

  // Claim job mutation using atomic function with overlap detection
  const claimJobMutation = useMutation({
    mutationFn: async ({ jobId, adminOverride = false, overrideReason }: { 
      jobId: string; 
      adminOverride?: boolean; 
      overrideReason?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Use atomic claim function that handles driver assignment and status update together
      const { data: claimResult, error: claimError } = await supabase.rpc('claim_job_atomic' as any, {
        p_job_id: jobId,
        p_driver_id: user.id,
        p_admin_override: adminOverride,
        p_override_reason: overrideReason || null
      } as any);

      if (claimError) throw claimError;

      const claim = claimResult as any;
      if (!claim?.success) {
        // Check if it's an overlap error that can be overridden
        if (claim?.overlap_detected && claim?.can_override) {
          throw { 
            isOverlapError: true, 
            conflictingJobs: claim.conflicting_jobs || [],
            message: claim.error 
          };
        }
        throw new Error(claim?.error || 'Failed to claim job');
      }

      return { assignment_id: claim.assignment_id, override_applied: claim.override_applied };
    },
    onSuccess: async (res, { jobId }) => {
      // Optimistically remove the job from the available jobs list
      queryClient.setQueryData(['all-available-jobs'], (old: any[] = []) => 
        old.filter(job => job.id !== jobId)
      );
      
      // Refetch all related queries
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['all-available-jobs'] }),
        queryClient.invalidateQueries({ queryKey: ['active-jobs'] }),
        queryClient.invalidateQueries({ queryKey: ['planned-jobs'] })
      ]);
      
      toast.success(res.override_applied ? 'Job claimed with admin override!' : 'Job claimed successfully!');
      setClaimingJobId(null);
      setPendingOverrideJob(null);
      setOverrideModalOpen(false);

      // Trigger route optimization for scheduled jobs
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Get the job to extract the route date and check if it's a scheduled job
        const { data: job } = await supabase
          .from('jobs')
          .select('pickup_time, status, priority')
          .eq('id', jobId)
          .single();
        
        if (job?.pickup_time && job?.status === 'planned' && job?.priority === 'claimed') {
          const routeDate = new Date(job.pickup_time).toISOString().split('T')[0];
          
          // Call auto-optimize-route edge function
          const { error: optimizeError } = await supabase.functions.invoke('auto-optimize-route', {
            body: {
              driver_id: user.id,
              route_date: routeDate,
              job_id: jobId
            }
          });
          
          if (optimizeError) {
            console.warn('Route optimization failed:', optimizeError);
          } else {
            console.log('Route optimization triggered successfully');
          }
        }
      } catch (error) {
        console.warn('Failed to trigger route optimization:', error);
      }
    },
    onError: (error: any) => {
      // Check if it's an overlap error that can be overridden
      if (error.isOverlapError) {
        setPendingOverrideJob({
          jobId: claimingJobId!,
          conflictingJobs: error.conflictingJobs || []
        });
        setOverrideModalOpen(true);
        return;
      }
      
      const errorMessage = error.message || 'Failed to claim job';
      
      // Check if error is about missing pickup time
      if (errorMessage.includes('pickup_time') || errorMessage.includes('pickup date')) {
        toast.error('Please set pickup date and time for this job before claiming');
      } else if (errorMessage.includes('overlapping schedule')) {
        toast.error('Cannot claim: This job overlaps with your existing schedule');
      } else {
        toast.error(errorMessage);
      }
      
      setClaimingJobId(null);
    }
  });

  const handleClaim = (jobId: string) => {
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }

    const job = availableJobs.find(j => j.id === jobId);
    if (job?.status === 'on_hold') {
      toast.error('Cannot claim job: This job is currently on hold');
      return;
    }
    setClaimingJobId(jobId);
    claimJobMutation.mutate({ jobId });
  };

  const handleAdminOverride = (reason: string) => {
    if (pendingOverrideJob) {
      claimJobMutation.mutate({
        jobId: pendingOverrideJob.jobId,
        adminOverride: true,
        overrideReason: reason
      });
    }
  };

  const handleJobClick = (jobId: string) => {
    setSelectedJobId(jobId);
    setDialogOpen(true);
  };

  const selectedJob = availableJobs.find(job => job.id === selectedJobId);

  // Determine job type based on pickup_time or priority
  const getJobType = (job: any) => {
    const isScheduled = (job?.priority === 'scheduled') || (job?.pickup_time ? new Date(job.pickup_time) > new Date() : false);
    return isScheduled ? 'scheduled' : 'pickup_now';
  };

  if (isLoadingLocation) {
    return (
      <div className="h-full w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">Available Jobs</span>
        </h3>
        <div className="text-xs text-muted-foreground flex items-center gap-2">
          <MapPin className="h-3 w-3 animate-pulse" />
          Getting your location...
        </div>
      </div>
    );
  }

  if (locationError) {
    return (
      <div className="h-full w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">Available Jobs</span>
        </h3>
        <div className="text-xs text-destructive">
          {locationError} - Jobs shown without distance filtering.
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="h-full w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">Available Jobs</span>
        </h3>
        <div className="text-xs text-muted-foreground">Loading available jobs...</div>
      </div>
    );
  }

  return (
    <div className="h-full w-full">
      <div className="flex items-start justify-between gap-2 mb-3">
        <h3 className="flex items-center gap-2 font-semibold text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">Available Jobs</span>
        </h3>
        {driverLocation && (
          <div className="text-xs text-muted-foreground flex items-center gap-1 flex-shrink-0">
            <MapPin className="h-3 w-3" />
            75mi
          </div>
        )}
      </div>
      <div className="space-y-2 w-full">
        {availableJobs.length === 0 ? (
          <div className="text-xs text-muted-foreground text-center py-3">
            No available jobs at the moment
          </div>
        ) : (
          availableJobs.map(job => (
            <AvailableJobCard
              key={job.id}
              job={job}
              type={getJobType(job)}
              onClick={handleJobClick}
              driverLocation={driverLocation}
            />
          ))
        )}
      </div>

      {selectedJob && (
        <DriverJobDetailsDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          job={selectedJob}
          type={getJobType(selectedJob)}
          onClaim={handleClaim}
          isClaiming={claimingJobId === selectedJob.id}
          canClaim={true}
        />
      )}

      <AdminOverrideModal
        open={overrideModalOpen}
        onOpenChange={setOverrideModalOpen}
        onConfirm={handleAdminOverride}
        conflictingJobs={pendingOverrideJob?.conflictingJobs}
        isLoading={claimJobMutation.isPending}
      />
    </div>
  );
};
