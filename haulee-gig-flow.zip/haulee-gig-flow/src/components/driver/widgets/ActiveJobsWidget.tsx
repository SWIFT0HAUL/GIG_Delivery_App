import React, { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Truck, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { JobCard } from '../JobCard';
import { DriverJobDetailsDialog } from '../DriverJobDetailsDialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useAuth } from '@/contexts/AuthContext';

interface ActiveJobsWidgetProps {
  onJobClick?: (jobId: string) => void;
}

export const ActiveJobsWidget: React.FC<ActiveJobsWidgetProps> = ({ onJobClick }) => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [cancelCategory, setCancelCategory] = useState('');
  const [cancelDetails, setCancelDetails] = useState('');
  const [fadingOutJobs, setFadingOutJobs] = useState<Set<string>>(new Set());

  // Realtime subscription for job changes
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('active-jobs-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'jobs',
          filter: `assigned_driver_id=eq.${user.id}`
        },
        (payload) => {
          const updatedJob = payload.new as any;
          // If job is picked up or delivered, trigger fade-out animation
          if (updatedJob && (updatedJob.status === 'picked_up' || updatedJob.status === 'delivered' || updatedJob.status === 'completed')) {
            setFadingOutJobs(prev => new Set(prev).add(updatedJob.id));
            // Remove from fade-out set and invalidate queries after animation
            setTimeout(() => {
              setFadingOutJobs(prev => {
                const next = new Set(prev);
                next.delete(updatedJob.id);
                return next;
              });
              queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
            }, 300); // Match fade-out animation duration
          } else {
            queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, queryClient]);

  // Fetch Active Jobs - only status: assigned
  const { data: activeJobs = [], isLoading } = useQuery({
    queryKey: ['active-jobs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: jobs, error } = await supabase
        .from('jobs')
        .select(`
          *,
          pickup_contact_name,
          pickup_contact_phone,
          delivery_contact_name,
          delivery_contact_phone,
          special_instructions,
          description,
          job_assignments (
            status,
            driver_id
          )
        `)
        .eq('assigned_driver_id', user.id)
        .order('created_at', { ascending: false });
      
      // Include jobs still assigned, or already in progress, or whose assignment moved to in_progress for this driver
      const processed = (jobs as any[] | null)?.filter((j: any) =>
        j.status === 'assigned' ||
        j.status === 'in_progress' ||
        (Array.isArray(j.job_assignments) && j.job_assignments.some((a: any) => a.driver_id === user.id && a.status === 'in_progress'))
      ).map((j: any) => ({
        ...j,
        status: (
          j.status === 'in_progress' ||
          j.started_at ||
          (Array.isArray(j.job_assignments) && j.job_assignments.some((a: any) => a.driver_id === user.id && a.status === 'in_progress'))
        ) ? 'in_progress' : j.status
      })) || [];
      
      console.log('✅ Active jobs processed:', processed.length);
      return processed;
    },
    refetchInterval: 5000 // Refresh every 5 seconds
  });

  // Start Job - assigned → in_progress (update assignment first, then job)
  const startJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const nowIso = new Date().toISOString();
      console.log('🚀 Starting job:', jobId);

      // 1) First, try to update existing job_assignment
      const { data: existingAssignment } = await supabase
        .from('job_assignments')
        .select('id')
        .eq('job_id', jobId)
        .eq('driver_id', user.id)
        .maybeSingle();

      if (existingAssignment) {
        console.log('✅ Found existing assignment, updating...');
        const { error: updateError } = await supabase
          .from('job_assignments')
          .update({ 
            status: 'in_progress',
            started_at: nowIso
          })
          .eq('id', existingAssignment.id);
        
        if (updateError) {
          console.error('❌ Assignment update error:', updateError);
          throw updateError;
        }
        console.log('✅ Assignment updated to in_progress');
      } else {
        console.log('⚠️ No assignment found, creating new one...');
        const { error: insertError } = await supabase
          .from('job_assignments')
          .insert({
            job_id: jobId,
            driver_id: user.id,
            status: 'in_progress',
            started_at: nowIso,
            assigned_at: nowIso
          });
        
        if (insertError) {
          console.error('❌ Assignment insert error:', insertError);
          throw insertError;
        }
        console.log('✅ New assignment created with in_progress status');
      }

      // 2) Update jobs table
      console.log('🔄 Updating jobs table...');
      const { data: jobData, error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'in_progress',
          started_at: nowIso,
          updated_at: nowIso
        })
        .eq('id', jobId)
        .eq('assigned_driver_id', user.id)
        .select('id, status, started_at');

      if (jobError) {
        console.error('❌ Job update error:', jobError);
        throw jobError;
      }

      if (!jobData || jobData.length === 0) {
        console.error('❌ Job update returned no data');
        throw new Error('Job update failed - no rows affected');
      }

      console.log('✅ Job updated:', jobData[0]);
      return jobData[0];
    },
    onSuccess: (data) => {
      console.log('✅ Start job mutation succeeded, invalidating queries...');
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['job-assignments'] });
      toast.success('Job started successfully!');
    },
    onError: (error: any) => {
      console.error('❌ Start job mutation failed:', error);
      toast.error(error.message || 'Failed to start job');
    }
  });

  // Cancel Job - Returns job to pending with categorized cancellation reason
  const cancelJobMutation = useMutation({
    mutationFn: async ({ 
      jobId, 
      category, 
      details 
    }: { 
      jobId: string; 
      category: string; 
      details: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Construct cancellation reason
      const cancellationReason = category === 'other' 
        ? `Other: ${details}` 
        : category;

      // Update job status and clear assignment - driver cancellation returns job to posted
      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'posted',
          assigned_driver_id: null,
          cancellation_reason: cancellationReason,
          updated_at: new Date().toISOString()
        })
        .eq('id', jobId);

      if (jobError) throw jobError;

      // Delete any job assignment records
      const { error: assignmentError } = await supabase
        .from('job_assignments')
        .delete()
        .eq('job_id', jobId)
        .eq('driver_id', user.id);

      if (assignmentError) {
        console.warn('No assignment record to delete:', assignmentError);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      toast.success('Job returned to Available Jobs');
      setCancelDialogOpen(false);
      setCancelCategory('');
      setCancelDetails('');
      setDialogOpen(false);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to cancel job');
    }
  });

  // Click Handlers - Opens job details dialog
  const handleJobClick = (jobId: string) => {
    if (onJobClick) {
      onJobClick(jobId);
    } else {
      setSelectedJobId(jobId);
      setDialogOpen(true);
    }
  };

  const handleCancelJob = (jobId: string) => {
    setSelectedJobId(jobId);
    setCancelCategory('');
    setCancelDetails('');
    setCancelDialogOpen(true);
  };

  const confirmCancel = () => {
    if (!selectedJobId || !cancelCategory) {
      toast.error('Please select a cancellation reason');
      return;
    }
    
    if (cancelCategory === 'other' && !cancelDetails.trim()) {
      toast.error('Please provide details for cancellation');
      return;
    }
    
    cancelJobMutation.mutate({ 
      jobId: selectedJobId, 
      category: cancelCategory,
      details: cancelDetails
    });
  };

  const selectedJob = activeJobs.find(job => job.id === selectedJobId);

  if (isLoading) {
    return (
      <Card className="p-4 w-full max-w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Truck className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{t('driver.widgets.activeJobs')}</span>
        </h3>
        <div className="text-xs text-muted-foreground">{t('driver.jobs.loading')}</div>
      </Card>
    );
  }

  return (
    <>
      <Card className="p-4 w-full max-w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Truck className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{t('driver.jobs.myJobs')}</span>
        </h3>
        <div className="space-y-4 w-full max-w-full">
          {activeJobs.length === 0 ? (
            <div className="text-xs text-muted-foreground text-center py-3 flex items-center justify-center gap-2">
              <AlertCircle className="h-4 w-4" />
              {t('driver.widgets.noActiveJobs')}
            </div>
          ) : (
            <>
              {activeJobs.map(job => (
                <div 
                  key={job.id} 
                  className={`space-y-2 transition-opacity duration-300 ${
                    fadingOutJobs.has(job.id) ? 'animate-fade-out opacity-0' : 'opacity-100'
                  }`}
                >
                  <JobCard
                    job={job}
                    type="active"
                    onClick={handleJobClick}
                    showNotesButton={true}
                  />
                  {job.status === 'assigned' && (
                    <Button 
                      className="w-full" 
                      onClick={() => startJobMutation.mutate(job.id)}
                      disabled={startJobMutation.isPending}
                    >
                      {startJobMutation.isPending ? 'Starting...' : 'Start Job'}
                    </Button>
                  )}
                </div>
              ))}
            </>
          )}
        </div>
      </Card>

      {/* Job Details Dialog */}
      {selectedJob && (
        <DriverJobDetailsDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          job={selectedJob}
          type="active"
          onStartJob={async (jobId) => {
            console.log('🟢 onStartJob called with jobId:', jobId);
            try {
              const result = await startJobMutation.mutateAsync(jobId);
              console.log('🟢 Mutation completed successfully:', result);
              return result;
            } catch (err) {
              console.error('🔴 Mutation failed in onStartJob wrapper:', err);
              throw err;
            }
          }}
          onCancel={handleCancelJob}
          isProcessing={startJobMutation.isPending}
        />
      )}

      {/* Cancel Job Dialog */}
      <AlertDialog open={cancelDialogOpen} onOpenChange={setCancelDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Return Job to Available Pool</AlertDialogTitle>
            <AlertDialogDescription>
              This job will be returned to Available Jobs for other drivers to claim. Please select your reason.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="cancelCategory">Cancellation Reason</Label>
              <Select value={cancelCategory} onValueChange={setCancelCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a reason..." />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  <SelectItem value="vehicle_issue">Vehicle Issue</SelectItem>
                  <SelectItem value="personal_emergency">Personal/Emergency Reasons</SelectItem>
                  <SelectItem value="preference">Preference-Based Reasons</SelectItem>
                  <SelectItem value="claim_mistake">Claim by Mistake</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            {cancelCategory === 'other' && (
              <div className="space-y-2">
                <Label htmlFor="cancelDetails">Details (Required)</Label>
                <Textarea
                  id="cancelDetails"
                  value={cancelDetails}
                  onChange={(e) => setCancelDetails(e.target.value)}
                  placeholder="Please provide more details..."
                  rows={3}
                />
              </div>
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => {
              setCancelDialogOpen(false);
              setCancelCategory('');
              setCancelDetails('');
            }}>
              Keep Job
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmCancel}
              disabled={
                !cancelCategory || 
                (cancelCategory === 'other' && !cancelDetails.trim()) ||
                cancelJobMutation.isPending
              }
              className="bg-warning text-warning-foreground hover:bg-warning/90"
            >
              Return to Pool
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};
