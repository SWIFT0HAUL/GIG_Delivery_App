import React, { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Card } from '@/components/ui/card';
import { Package, MapPin } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { JobCard } from '../JobCard';
import { DriverJobDetailsDialog } from '../DriverJobDetailsDialog';
import { AdminOverrideModal } from '../AdminOverrideModal';
import { useDriverCapacityCheck } from '@/hooks/useDriverCapacityCheck';
import { useDriverLocation } from '@/hooks/useDriverLocation';
import { filterJobsByDistance } from '@/lib/distanceCalculation';
import { useSafeMode } from '@/contexts/SafeModeContext';

export const PickUpNowWidget: React.FC = () => {
  const { t } = useTranslation();
  const { isSafeModeActive } = useSafeMode();
  const queryClient = useQueryClient();
  const [claimingJobId, setClaimingJobId] = useState<string | null>(null);
  const [selectedJobId, setSelectedJobId] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [overrideModalOpen, setOverrideModalOpen] = useState(false);
  const [pendingOverrideJob, setPendingOverrideJob] = useState<{ jobId: string; conflictingJobs: any[] } | null>(null);
  const { coordinates: driverLocation, isLoading: isLoadingLocation, error: locationError } = useDriverLocation();

  // Check if driver has active jobs
  const { data: activeJobsCount = 0 } = useQuery({
    queryKey: ['active-jobs-count'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return 0;

      const { count, error } = await supabase
        .from('jobs')
        .select('*', { count: 'exact', head: true })
        .eq('assigned_driver_id', user.id)
        .in('status', ['assigned', 'planned', 'in_progress', 'picked_up']);

      if (error) throw error;
      return count || 0;
    },
    refetchInterval: 5000
  });

  // Fetch available jobs (status = 'pending')
  const { data: availableJobs = [], isLoading } = useQuery({
    queryKey: ['available-jobs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get all pending jobs
      const { data: jobs, error: jobsError } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(1000);
      
      if (jobsError) throw jobsError;

      // Fetch only the current driver's assignments
      const { data: assignments, error: assignmentsError } = await supabase
        .from('job_assignments')
        .select('job_id')
        .eq('driver_id', user.id);
      
      if (assignmentsError) throw assignmentsError;

      // Filter out jobs that this driver has claimed
      const assignedJobIds = new Set(assignments?.map(a => a.job_id) || []);
      let availableJobs = (jobs || []).filter(job => !assignedJobIds.has(job.id));

      return availableJobs.slice(0, 1000);
    },
    refetchInterval: 10000, // Auto-refresh every 10 seconds
    enabled: !isLoadingLocation // Wait for location before fetching jobs
  });

  // Claim job mutation using atomic function with overlap detection
  const claimJobMutation = useMutation({
    mutationFn: async ({ jobId, adminOverride = false, overrideReason }: { 
      jobId: string; 
      adminOverride?: boolean; 
      overrideReason?: string;
    }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Use atomic claim function that handles driver assignment and status update together
      const { data: claimResult, error: claimError } = await supabase.rpc('claim_job_atomic' as any, {
        p_job_id: jobId,
        p_driver_id: user.id,
        p_admin_override: adminOverride,
        p_override_reason: overrideReason || null
      } as any);

      if (claimError) throw claimError;

      const claim = claimResult as any;
      if (!claim?.success) {
        // Check if it's an overlap error that can be overridden
        if (claim?.overlap_detected && claim?.can_override) {
          throw { 
            isOverlapError: true, 
            conflictingJobs: claim.conflicting_jobs || [],
            message: claim.error 
          };
        }
        throw new Error(claim?.error || 'Failed to claim job');
      }

      return { assignment_id: claim.assignment_id, override_applied: claim.override_applied };
    },
    onSuccess: async (res, { jobId }) => {
      // Optimistically remove the job from the available jobs list
      queryClient.setQueryData(['available-jobs'], (old: any[] = []) => 
        old.filter(job => job.id !== jobId)
      );
      
      // Refetch all related queries
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['available-jobs'] }),
        queryClient.invalidateQueries({ queryKey: ['active-jobs'] }),
        queryClient.invalidateQueries({ queryKey: ['planned-jobs'] })
      ]);
      
      toast.success(res.override_applied ? 'Job claimed with admin override!' : 'Job claimed successfully!');
      setClaimingJobId(null);
      setPendingOverrideJob(null);
      setOverrideModalOpen(false);
    },
    onError: (error: any) => {
      // Check if it's an overlap error that can be overridden
      if (error.isOverlapError) {
        setPendingOverrideJob({
          jobId: claimingJobId!,
          conflictingJobs: error.conflictingJobs || []
        });
        setOverrideModalOpen(true);
        return;
      }
      
      toast.error(error.message || 'Failed to claim job');
      setClaimingJobId(null);
    }
  });

  // Create authorization request mutation
  const createAuthRequestMutation = useMutation({
    mutationFn: async ({ jobId, activeJobs }: { jobId: string; activeJobs: any[] }) => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('job_claim_authorization_requests')
        .insert([{
          driver_id: user.id,
          job_id: jobId,
          driver_current_jobs: activeJobs as any,
          driver_location: driverLocation as any,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Authorization request sent to admin. You will be notified once reviewed.');
      setClaimingJobId(null);
      queryClient.invalidateQueries({ queryKey: ['available-jobs'] });
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to send authorization request');
      setClaimingJobId(null);
    }
  });

  const handleClaim = async (jobId: string) => {
    if (isSafeModeActive) {
      toast.error('Action disabled: Safe mode is active');
      return;
    }

    setClaimingJobId(jobId);

    const job = availableJobs.find(j => j.id === jobId);
    if (job?.status === 'on_hold') {
      toast.error('Cannot claim job: This job is currently on hold');
      setClaimingJobId(null);
      return;
    }

    // If driver has active jobs, create authorization request
    if (activeJobsCount > 0) {
      const { data: activeJobs } = await supabase
        .from('jobs')
        .select('id, title, status, pickup_location, delivery_location')
        .eq('assigned_driver_id', (await supabase.auth.getUser()).data.user?.id)
        .in('status', ['assigned', 'planned', 'in_progress', 'picked_up']);

      createAuthRequestMutation.mutate({ jobId, activeJobs: activeJobs || [] });
    } else {
      // Directly claim the job
      claimJobMutation.mutate({ jobId });
    }
  };

  const handleAdminOverride = (reason: string) => {
    if (pendingOverrideJob) {
      claimJobMutation.mutate({
        jobId: pendingOverrideJob.jobId,
        adminOverride: true,
        overrideReason: reason
      });
    }
  };

  const handleJobClick = (jobId: string) => {
    setSelectedJobId(jobId);
    setDialogOpen(true);
  };

  const selectedJob = availableJobs.find(job => job.id === selectedJobId);

  if (isLoadingLocation) {
    return (
      <Card className="p-3 sm:p-4 w-full max-w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{t('driver.jobs.availableNow')}</span>
        </h3>
        <div className="text-xs text-muted-foreground flex items-center gap-2">
          <MapPin className="h-3 w-3 animate-pulse" />
          Getting your location...
        </div>
      </Card>
    );
  }

  if (locationError) {
    return (
      <Card className="p-3 sm:p-4 w-full max-w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{t('driver.jobs.availableNow')}</span>
        </h3>
        <div className="text-xs text-destructive">
          {locationError} - Jobs shown without distance filtering.
        </div>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card className="p-3 sm:p-4 w-full max-w-full">
        <h3 className="flex items-center gap-2 font-semibold mb-3 text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{t('driver.jobs.availableNow')}</span>
        </h3>
        <div className="text-xs text-muted-foreground">{t('driver.jobs.loading')}</div>
      </Card>
    );
  }

  return (
    <Card className="p-3 sm:p-4 w-full max-w-full">
      <div className="flex items-start justify-between gap-2 mb-3">
        <h3 className="flex items-center gap-2 font-semibold text-sm">
          <Package className="h-4 w-4 flex-shrink-0" />
          <span className="truncate">{t('driver.jobs.availableNow')}</span>
        </h3>
        {driverLocation && (
          <div className="text-xs text-muted-foreground flex items-center gap-1 flex-shrink-0">
            <MapPin className="h-3 w-3" />
            75mi
          </div>
        )}
      </div>
      {activeJobsCount > 0 && (
        <div className="text-xs text-amber-600 dark:text-amber-500 bg-amber-50 dark:bg-amber-950/20 p-2 rounded-md mb-2">
          You have {activeJobsCount} active job{activeJobsCount > 1 ? 's' : ''}. Claiming new jobs requires admin authorization.
        </div>
      )}
      <div className="space-y-2 w-full max-w-full">
        {availableJobs.length === 0 ? (
          <div className="text-xs text-muted-foreground text-center py-3">
            {t('driver.jobs.noJobs')}
          </div>
        ) : (
          availableJobs.map(job => (
            <JobCard
              key={job.id}
              job={job}
              type="pickup_now"
              onClick={handleJobClick}
              driverLocation={driverLocation}
            />
          ))
        )}
      </div>

      {selectedJob && (
        <DriverJobDetailsDialog
          open={dialogOpen}
          onOpenChange={setDialogOpen}
          job={selectedJob}
          type="pickup_now"
          onClaim={handleClaim}
          isClaiming={claimingJobId === selectedJob.id}
          canClaim={true}
        />
      )}

      <AdminOverrideModal
        open={overrideModalOpen}
        onOpenChange={setOverrideModalOpen}
        onConfirm={handleAdminOverride}
        conflictingJobs={pendingOverrideJob?.conflictingJobs}
        isLoading={claimJobMutation.isPending}
      />
    </Card>
  );
};