import React from 'react';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';

interface MapViewModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  mapUrl: string;
  nested?: boolean;
}

export const MapViewModal: React.FC<MapViewModalProps> = ({
  open,
  onOpenChange,
  mapUrl,
  nested = false,
}) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent nested={nested} className={nested ? "max-w-full h-[calc(100%-2rem)]" : "w-screen h-screen max-w-none p-0 m-0 border-0"}>
        <div className="relative w-full h-full">
          <Button
            onClick={() => onOpenChange(false)}
            className="absolute top-2 right-2 sm:top-4 sm:right-4 z-10 h-8 w-8 sm:h-10 sm:w-10 rounded-full"
            variant="default"
            size="icon"
          >
            <X className="h-4 w-4 sm:h-5 sm:w-5" />
          </Button>
          
          <iframe
            src={mapUrl}
            className="w-full h-full border-0"
            title="Map View"
            allow="geolocation"
          />
        </div>
      </DialogContent>
    </Dialog>
  );
};
