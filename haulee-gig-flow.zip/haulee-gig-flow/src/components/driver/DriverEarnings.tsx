import React, { useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, Calendar, CreditCard, Package } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { format, startOfDay, startOfWeek, endOfWeek, subDays, isWithinInterval } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export function DriverEarnings() {
  // Fetch driver's completed jobs for earnings calculation
  const { data: completedJobs = [], isLoading } = useQuery({
    queryKey: ['driver-earnings'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('job_assignments')
        .select(`
          *,
          jobs (*)
        `)
        .eq('driver_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Calculate earnings statistics
  const stats = useMemo(() => {
    const now = new Date();
    const todayStart = startOfDay(now);
    const weekStart = startOfWeek(now, { weekStartsOn: 1 }); // Monday
    const weekEnd = endOfWeek(now, { weekStartsOn: 1 });

    let todayEarnings = 0;
    let weekEarnings = 0;
    let totalEarnings = 0;
    const weeklyBreakdown: { [key: string]: { amount: number; count: number } } = {};

    completedJobs.forEach((assignment: any) => {
      const job = assignment.jobs;
      if (!job || !job.pay_amount) return;

      const amount = parseFloat(job.pay_amount);
      totalEarnings += amount;

      const completedAt = assignment.completed_at ? new Date(assignment.completed_at) : null;
      if (!completedAt) return;

      // Today's earnings
      if (completedAt >= todayStart) {
        todayEarnings += amount;
      }

      // This week's earnings
      if (isWithinInterval(completedAt, { start: weekStart, end: weekEnd })) {
        weekEarnings += amount;
        
        const dayName = format(completedAt, 'EEEE');
        if (!weeklyBreakdown[dayName]) {
          weeklyBreakdown[dayName] = { amount: 0, count: 0 };
        }
        weeklyBreakdown[dayName].amount += amount;
        weeklyBreakdown[dayName].count += 1;
      }
    });

    return {
      todayEarnings,
      weekEarnings,
      totalEarnings,
      availableBalance: totalEarnings * 0.9, // 90% available (simulate holding period)
      weeklyBreakdown
    };
  }, [completedJobs]);

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  
  // Prepare chart data for all days of the week
  const chartData = useMemo(() => {
    return daysOfWeek.map(day => ({
      day: day.substring(0, 3), // Mon, Tue, etc.
      earnings: stats.weeklyBreakdown[day]?.amount || 0,
      deliveries: stats.weeklyBreakdown[day]?.count || 0
    }));
  }, [stats.weeklyBreakdown]);

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full overflow-x-hidden">
      <div>
        <h2 className="text-xl sm:text-2xl font-bold">Earnings</h2>
        <p className="text-sm sm:text-base text-muted-foreground">Track your income and manage payouts</p>
      </div>

      <Tabs defaultValue="income" className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-2 gap-0.5 sm:gap-1 h-9 sm:h-10">
          <TabsTrigger value="income" className="text-xs sm:text-sm">Income</TabsTrigger>
          <TabsTrigger value="payouts" className="text-xs sm:text-sm">Payouts</TabsTrigger>
        </TabsList>

        <TabsContent value="income" className="space-y-3 sm:space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">Loading earnings data...</p>
            </div>
          ) : (
            <>
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Weekly Earnings Chart</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Your income per day this week</CardDescription>
                </CardHeader>
                <CardContent className="p-3 sm:p-6 pt-0">
                  {Object.keys(stats.weeklyBreakdown).length === 0 ? (
                    <div className="text-center py-8 space-y-2">
                      <Package className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No earnings this week yet</p>
                      <p className="text-xs text-muted-foreground">Complete deliveries to start earning</p>
                    </div>
                  ) : (
                    <ResponsiveContainer width="100%" height={150}>
                      <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                        <XAxis 
                          dataKey="day" 
                          className="text-xs"
                          tick={{ fill: 'hsl(var(--muted-foreground))' }}
                        />
                        <YAxis 
                          className="text-xs"
                          tick={{ fill: 'hsl(var(--muted-foreground))' }}
                          tickFormatter={(value) => `$${value}`}
                        />
                        <Tooltip 
                          content={({ active, payload }) => {
                            if (active && payload && payload.length) {
                              const value = typeof payload[0].value === 'number' ? payload[0].value : 0;
                              return (
                                <div className="bg-popover border rounded-lg p-3 shadow-lg">
                                  <p className="font-medium text-sm">{payload[0].payload.day}</p>
                                  <p className="text-primary text-lg font-bold">
                                    ${value.toFixed(2)}
                                  </p>
                                  <p className="text-xs text-muted-foreground">
                                    {payload[0].payload.deliveries} {payload[0].payload.deliveries === 1 ? 'delivery' : 'deliveries'}
                                  </p>
                                </div>
                              );
                            }
                            return null;
                          }}
                        />
                        <Bar 
                          dataKey="earnings" 
                          fill="hsl(var(--primary))" 
                          radius={[8, 8, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  )}
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">Today's Earnings</CardTitle>
                    <DollarSign className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0">
                    <div className="text-xl sm:text-2xl font-bold">${stats.todayEarnings.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground mt-1 mb-3">
                      {completedJobs.filter((a: any) => {
                        const completedAt = a.completed_at ? new Date(a.completed_at) : null;
                        return completedAt && completedAt >= startOfDay(new Date());
                      }).length} deliveries today
                    </p>
                    <Button size="sm" className="w-1/2 h-8 text-xs ml-auto">
                      Request Payout
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">This Week</CardTitle>
                    <Calendar className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0">
                    <div className="text-xl sm:text-2xl font-bold">${stats.weekEarnings.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {Object.values(stats.weeklyBreakdown).reduce((sum, day: any) => sum + day.count, 0)} deliveries this week
                    </p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 p-3 sm:p-6">
                    <CardTitle className="text-xs sm:text-sm font-medium">Total Earnings</CardTitle>
                    <CreditCard className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground flex-shrink-0" />
                  </CardHeader>
                  <CardContent className="p-3 sm:p-6 pt-0">
                    <div className="text-xl sm:text-2xl font-bold">${stats.totalEarnings.toFixed(2)}</div>
                    <p className="text-xs text-muted-foreground mt-1">
                      {completedJobs.length} total deliveries
                    </p>
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="payouts" className="space-y-3 sm:space-y-4">
          {isLoading ? (
            <div className="text-center py-8">
              <p className="text-sm text-muted-foreground">Loading payout data...</p>
            </div>
          ) : (
            <>
              {/* Payout Summary Card */}
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Available for Payout</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Earnings ready to be withdrawn</CardDescription>
                </CardHeader>
                <CardContent className="p-3 sm:p-6 pt-0">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl sm:text-3xl font-bold text-green-600">
                        ${stats.availableBalance.toFixed(2)}
                      </div>
                      <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                        From {completedJobs.length} completed {completedJobs.length === 1 ? 'delivery' : 'deliveries'}
                      </p>
                    </div>
                    <Button size="sm" className="h-9 text-xs">
                      Request Payout
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Recent Earnings</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Your completed job payments</CardDescription>
                </CardHeader>
                <CardContent className="p-3 sm:p-6 pt-0">
                  {completedJobs.length === 0 ? (
                    <div className="text-center py-8 space-y-2">
                      <Package className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">No earnings yet</p>
                      <p className="text-xs text-muted-foreground">Complete deliveries to start earning</p>
                    </div>
                  ) : (
                    <div className="space-y-3 sm:space-y-4">
                      {completedJobs.slice(0, 10).map((assignment: any) => {
                        const job = assignment.jobs;
                        if (!job || !job.pay_amount) return null;
                        
                        const completedDate = assignment.completed_at 
                          ? format(new Date(assignment.completed_at), 'MMM d, yyyy')
                          : 'N/A';
                        
                        const isPaid = assignment.status === 'paid';
                        
                        return (
                          <div key={assignment.id} className="flex items-center justify-between p-3 sm:p-4 border rounded-lg gap-2">
                            <div className="min-w-0 flex-1">
                              <p className="font-medium text-sm sm:text-base truncate">{job.title}</p>
                              <p className="text-xs sm:text-sm text-muted-foreground">{completedDate}</p>
                            </div>
                            <div className="text-right flex-shrink-0">
                              <p className="font-medium text-sm sm:text-base text-green-600">
                                +${parseFloat(job.pay_amount).toFixed(2)}
                              </p>
                              <Badge 
                                variant={isPaid ? "default" : "secondary"} 
                                className="text-xs"
                              >
                                {isPaid ? 'Paid' : 'Pending'}
                              </Badge>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Payout Information</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">How payouts work</CardDescription>
                </CardHeader>
                <CardContent className="p-3 sm:p-6 pt-0">
                  <div className="space-y-3 sm:space-y-4">
                    <div className="p-3 sm:p-4 bg-muted rounded-lg">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <Calendar className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-sm">Standard Payout Schedule</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Earnings are processed and paid out weekly on Mondays for jobs completed the previous week.
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-3 sm:p-4 bg-muted rounded-lg">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <CreditCard className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-sm">Instant Payout Option</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Request instant payouts for completed jobs with a small processing fee. Available for jobs completed over 24 hours ago.
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="p-3 sm:p-4 bg-muted rounded-lg">
                      <div className="flex items-start gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <DollarSign className="h-4 w-4 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium text-sm">Minimum Payout Amount</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            A minimum balance of $25.00 is required to request a payout. Below this amount, earnings will roll over to the next payout period.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}