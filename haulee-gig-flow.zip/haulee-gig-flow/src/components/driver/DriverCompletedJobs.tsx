import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { formatDistanceToNow } from "date-fns";
import { Loader2 } from "lucide-react";

export default function DriverCompletedJobs() {
  const { user } = useAuth();

  const { data: completedJobs, isLoading } = useQuery({
    queryKey: ["completed-jobs", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("job_assignments")
        .select(`
          *,
          jobs (
            id,
            title,
            pickup_location,
            delivery_location,
            pay_amount,
            completed_at,
            status
          )
        `)
        .eq("driver_id", user?.id)
        .or("jobs.status.eq.completed,jobs.secondary_status.eq.completed")
        .order("completed_at", { ascending: false });

      if (error) throw error;
      return data;
    },
    enabled: !!user?.id,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Completed Jobs</h2>
      
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Job Title</TableHead>
              <TableHead>Pickup Location</TableHead>
              <TableHead>Delivery Location</TableHead>
              <TableHead>Pay Amount</TableHead>
              <TableHead>Completed</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {completedJobs?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="text-center text-muted-foreground">
                  No completed jobs found
                </TableCell>
              </TableRow>
            ) : (
              completedJobs?.map((assignment) => {
                const job = assignment.jobs;
                if (!job) return null;
                
                return (
                  <TableRow key={assignment.id}>
                    <TableCell className="font-medium">{job.title}</TableCell>
                    <TableCell>
                      {(job.pickup_location as any)?.address || "N/A"}
                    </TableCell>
                    <TableCell>
                      {(job.delivery_location as any)?.address || "N/A"}
                    </TableCell>
                    <TableCell>${job.pay_amount?.toFixed(2) || "0.00"}</TableCell>
                    <TableCell>
                      {job.completed_at
                        ? formatDistanceToNow(new Date(job.completed_at), { addSuffix: true })
                        : "N/A"}
                    </TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
