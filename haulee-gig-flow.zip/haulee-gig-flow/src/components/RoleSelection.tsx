import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, Truck, Shield, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

const RoleSelection = () => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleRoleSelection = (role: string) => {
    navigate('/auth');
  };

  const handleTalkToTeam = () => {
    toast({
      title: "Contact Our Team",
      description: "Opening contact form...",
    });
  };

  const roles = [
    {
      title: "Shipper / Broker",
      description: "Post delivery jobs, manage shipments, and connect with reliable carriers",
      icon: <Package className="h-12 w-12" />,
      features: [
        "Post unlimited jobs",
        "Real-time carrier tracking", 
        "Secure payment processing",
        "Invoice management",
        "Performance analytics"
      ],
      gradient: "from-primary to-primary-glow",
      buttonVariant: "gradient" as const
    },
    {
      title: "Driver / Carrier", 
      description: "Find profitable delivery jobs and grow your transportation business",
      icon: <Truck className="h-12 w-12" />,
      features: [
        "Browse available jobs",
        "Instant job claiming",
        "Route optimization",
        "Earnings dashboard", 
        "Quick payouts"
      ],
      gradient: "from-accent to-orange-500",
      buttonVariant: "accent" as const
    },
    {
      title: "Fleet Manager",
      description: "Manage multiple drivers and optimize fleet operations at scale",
      icon: <Shield className="h-12 w-12" />,
      features: [
        "Multi-driver management",
        "Fleet analytics",
        "Bulk job assignments", 
        "Performance monitoring",
        "Cost optimization"
      ],
      gradient: "from-primary to-accent",
      buttonVariant: "hero" as const
    }
  ];

  return (
    <section id="role-selection" className="py-16 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            Choose Your <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Role</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join thousands of professionals using Haulee to grow their logistics business. Select your role to get started.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {roles.map((role, index) => (
            <Card key={index} className="border-border hover:border-primary/50 transition-all duration-300 hover:shadow-xl relative overflow-hidden group">
              <div className={`absolute inset-0 bg-gradient-to-br ${role.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-300`}></div>
              
              <CardHeader className="text-center space-y-4 relative">
                <div className={`inline-flex items-center justify-center w-20 h-20 bg-gradient-to-r ${role.gradient} rounded-2xl text-white mx-auto group-hover:scale-110 transition-transform duration-300`}>
                  {role.icon}
                </div>
                <div>
                  <CardTitle className="text-2xl mb-2">{role.title}</CardTitle>
                  <CardDescription className="text-base">
                    {role.description}
                  </CardDescription>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-6 relative">
                <ul className="space-y-3">
                  {role.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-muted-foreground">
                      <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <Button 
                  variant={role.buttonVariant} 
                  className="w-full group-hover:shadow-lg"
                  onClick={() => handleRoleSelection(role.title.split('/')[0].trim())}
                >
                  Get Started as {role.title.split('/')[0].trim()}
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-6">
            Need help deciding? Our platform supports multiple roles for growing businesses.
          </p>
          <Button variant="outline" size="lg" onClick={handleTalkToTeam}>
            Talk to Our Team
          </Button>
        </div>
      </div>
    </section>
  );
};

export default RoleSelection;