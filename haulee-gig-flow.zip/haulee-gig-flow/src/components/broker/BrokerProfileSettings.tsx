import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { User, Building2, Shield, Bell, CreditCard, MapPin, Sun, Moon, Monitor, LogOut } from 'lucide-react';
import { toast } from 'sonner';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';
import { useBrokerProfileData } from '@/hooks/useBrokerProfileData';
import { DeleteAccountSection } from '@/components/profile/DeleteAccountSection';
import { useAuth } from '@/contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export function BrokerProfileSettings() {
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const { profileData, loading } = useBrokerProfileData();
  const [activeMainTab, setActiveMainTab] = useState('profile');
  const [activeProfileTab, setActiveProfileTab] = useState('personal');
  const [paymentMethodType, setPaymentMethodType] = useState('bank');
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [smsAuthEnabled, setSmsAuthEnabled] = useState(true);
  const [emailAuthEnabled, setEmailAuthEnabled] = useState(true);
  const [themePreference, setThemePreference] = useState('system');
  const { appDarkMode, mapsDarkMode, setAppDarkMode, setMapsDarkMode } = useDarkModeSettings();

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  return (
    <div className="space-y-4 sm:space-y-6 w-full max-w-full overflow-x-hidden">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Profile & Settings</h1>
        <p className="text-sm sm:text-base text-muted-foreground mt-2">
          Manage your broker account information and preferences
        </p>
      </div>

      <Tabs value={activeMainTab} onValueChange={setActiveMainTab} className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-2 gap-0.5 sm:gap-1 h-9 sm:h-10">
          <TabsTrigger value="profile" className="text-xs sm:text-sm">Profile</TabsTrigger>
          <TabsTrigger value="security" className="text-xs sm:text-sm">Security</TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-4">
          <Tabs value={activeProfileTab} onValueChange={setActiveProfileTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-auto sm:h-10 p-1">
              <TabsTrigger value="personal" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Personal Information
              </TabsTrigger>
              <TabsTrigger value="payment" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Payment Method
              </TabsTrigger>
              <TabsTrigger value="notifications" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Notifications & Preferences
              </TabsTrigger>
            </TabsList>

            {/* Personal Information */}
            <TabsContent value="personal" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <User className="h-4 w-4 sm:h-5 sm:w-5" />
                    Personal Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Update your personal and brokerage contact details
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 sm:space-y-4 p-3 sm:p-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                    <div>
                      <Label htmlFor="firstName" className="text-xs sm:text-sm">First Name</Label>
                      <Input id="firstName" defaultValue={profileData?.personalInfo.firstName} disabled={loading} className="h-9 sm:h-10 text-sm" />
                    </div>
                    <div>
                      <Label htmlFor="lastName" className="text-xs sm:text-sm">Last Name</Label>
                      <Input id="lastName" defaultValue={profileData?.personalInfo.lastName} disabled={loading} className="h-9 sm:h-10 text-sm" />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="company" className="text-xs sm:text-sm">Brokerage Name</Label>
                    <Input id="company" defaultValue={profileData?.personalInfo.brokerageName} disabled={loading} className="h-9 sm:h-10 text-sm" />
                  </div>

                  <div>
                    <Label htmlFor="mcNumber" className="text-xs sm:text-sm">MC Number</Label>
                    <Input id="mcNumber" defaultValue={profileData?.personalInfo.mcNumber} disabled={loading} className="h-9 sm:h-10 text-sm" />
                  </div>

                  <div>
                    <Label htmlFor="email" className="text-xs sm:text-sm">Email</Label>
                    <Input id="email" type="email" defaultValue={profileData?.personalInfo.email} disabled={loading} className="h-9 sm:h-10 text-sm" />
                  </div>

                  <div>
                    <Label htmlFor="phone" className="text-xs sm:text-sm">Phone Number</Label>
                    <Input id="phone" type="tel" defaultValue={profileData?.personalInfo.phone} disabled={loading} className="h-9 sm:h-10 text-sm" />
                  </div>

                  <Button onClick={() => toast.success('Profile updated successfully!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Account Status</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Your broker account information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-medium">Account Status</span>
                    <Badge className="text-xs">{profileData?.accountStatus.status || 'Active'}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-medium">License Verification</span>
                    <Badge variant="secondary" className="text-xs">{profileData?.accountStatus.licenseVerification || 'Verified'}</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs sm:text-sm font-medium">Member Since</span>
                    <span className="text-xs sm:text-sm">{profileData?.accountStatus.memberSince || 'March 2024'}</span>
                  </div>
                </CardContent>
              </Card>

              <DeleteAccountSection />

              <Card className="border-muted">
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="text-base sm:text-lg">Account Actions</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Sign out of your account</CardDescription>
                </CardHeader>
                <CardContent className="p-3 sm:p-6">
                  <Button
                    variant="outline"
                    onClick={handleSignOut}
                    className="w-full sm:w-auto gap-2 text-destructive hover:text-destructive"
                  >
                    <LogOut className="h-4 w-4" />
                    Sign Out
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payment Method */}
            <TabsContent value="payment" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <CreditCard className="h-4 w-4 sm:h-5 sm:w-5" />
                    Payment Methods
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Manage your payment options
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div>
                    <Label htmlFor="paymentType" className="text-xs sm:text-sm">Payment Method Type</Label>
                    <Select value={paymentMethodType} onValueChange={setPaymentMethodType}>
                      <SelectTrigger id="paymentType" className="h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select payment type" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="bank">Bank Account</SelectItem>
                        <SelectItem value="check">Check</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {paymentMethodType === 'bank' && (
                    <>
                      <div>
                        <Label htmlFor="bankName" className="text-xs sm:text-sm">Bank Name</Label>
                        <Input id="bankName" defaultValue="Chase Bank" className="h-9 sm:h-10 text-sm" />
                      </div>
                      <div>
                        <Label htmlFor="accountNumber" className="text-xs sm:text-sm">Account Number</Label>
                        <Input id="accountNumber" placeholder="**** **** **** 1234" className="h-9 sm:h-10 text-sm" />
                      </div>
                      <div>
                        <Label htmlFor="routingNumber" className="text-xs sm:text-sm">Routing Number</Label>
                        <Input id="routingNumber" placeholder="123456789" className="h-9 sm:h-10 text-sm" />
                      </div>
                    </>
                  )}

                  <Button onClick={() => toast.success('Payment method updated!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Payment Method
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications & Preferences */}
            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5" />
                    Notifications & Preferences
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure your notification settings and appearance
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Load alerts</Label>
                        <p className="text-xs text-muted-foreground">Get notified about new load opportunities</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Carrier responses</Label>
                        <p className="text-xs text-muted-foreground">Receive notifications when carriers respond</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <Separator />

                  <div className="pt-2">
                    <Label className="text-xs sm:text-sm font-medium">Appearance</Label>
                    <p className="text-xs text-muted-foreground mb-3">Choose your preferred theme</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={() => setThemePreference('light')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'light' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Sun className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Light mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('dark')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'dark' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Moon className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Dark mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('system')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'system' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Monitor className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">System default</span>
                      </button>
                    </div>
                  </div>

                  {themePreference === 'dark' && (
                    <>
                      <Separator className="my-4" />

                      <div>
                        <Label className="text-xs sm:text-sm font-medium">Advanced Dark Mode Settings</Label>
                        <p className="text-xs text-muted-foreground mb-4">Separately control dark mode for app and maps</p>
                        
                        <div className="space-y-4">
                          <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-lg bg-primary/10">
                                <Monitor className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">App Dark Mode</p>
                                <p className="text-xs text-muted-foreground">Enable dark theme for the interface</p>
                              </div>
                            </div>
                            <Switch
                              checked={appDarkMode}
                              onCheckedChange={setAppDarkMode}
                            />
                          </div>
  
                          <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                            <div className="flex items-center gap-3">
                              <div className="p-2 rounded-lg bg-primary/10">
                                <MapPin className="h-5 w-5 text-primary" />
                              </div>
                              <div>
                                <p className="text-sm font-medium">Maps Dark Mode</p>
                                <p className="text-xs text-muted-foreground">Enable dark theme for maps</p>
                              </div>
                            </div>
                            <Switch
                              checked={mapsDarkMode}
                              onCheckedChange={setMapsDarkMode}
                            />
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  <Button onClick={() => toast.success('Preferences saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Preferences
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Shield className="h-4 w-4 sm:h-5 sm:w-5" />
                Multi-Factor Authentication (MFA)
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Add an extra layer of security to your account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-3 sm:p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-xs sm:text-sm font-medium">Enable MFA</Label>
                  <p className="text-xs text-muted-foreground">Require additional verification when signing in</p>
                </div>
                <Switch checked={mfaEnabled} onCheckedChange={setMfaEnabled} />
              </div>

              {mfaEnabled && (
                <>
                  <Separator />
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Authenticator App</Label>
                        <p className="text-xs text-muted-foreground">Use an authenticator app for MFA</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">SMS Authentication</Label>
                        <p className="text-xs text-muted-foreground">Receive codes via SMS</p>
                      </div>
                      <Switch checked={smsAuthEnabled} onCheckedChange={setSmsAuthEnabled} />
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Email Authentication</Label>
                        <p className="text-xs text-muted-foreground">Receive codes via email</p>
                      </div>
                      <Switch checked={emailAuthEnabled} onCheckedChange={setEmailAuthEnabled} />
                    </div>
                  </div>
                </>
              )}

              <Button onClick={() => toast.success('Security settings updated!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                Save Security Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
