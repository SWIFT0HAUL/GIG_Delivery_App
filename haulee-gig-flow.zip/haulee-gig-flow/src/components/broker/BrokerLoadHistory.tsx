import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Eye, Download, Calendar } from 'lucide-react';

export function BrokerLoadHistory() {
  const [searchTerm, setSearchTerm] = useState('');

  const loadHistory = [
    { 
      id: 'LD-4401', 
      route: 'LA → Phoenix', 
      carrier: 'Fast Freight LLC',
      completedDate: '2024-01-15',
      rate: '$1,850',
      margin: '$320',
      status: 'Delivered'
    },
    { 
      id: 'LD-4402', 
      route: 'Dallas → Houston', 
      carrier: 'Texas Transport',
      completedDate: '2024-01-14',
      rate: '$950',
      margin: '$180',
      status: 'Delivered'
    },
    { 
      id: 'LD-4403', 
      route: 'Chicago → Atlanta', 
      carrier: 'Midwest Carriers',
      completedDate: '2024-01-13',
      rate: '$2,650',
      margin: '$450',
      status: 'Delivered'
    },
    { 
      id: 'LD-4404', 
      route: 'Miami → NYC', 
      carrier: 'East Coast Express',
      completedDate: '2024-01-12',
      rate: '$3,200',
      margin: '$580',
      status: 'Delivered'
    },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Load History
          </CardTitle>
          <CardDescription>View completed loads and historical data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search load history..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" className="gap-2">
              <Download className="h-4 w-4" />
              Export Report
            </Button>
          </div>

          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Load ID</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Carrier</TableHead>
                  <TableHead>Completed Date</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Margin</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadHistory.map((load) => (
                  <TableRow key={load.id}>
                    <TableCell className="font-medium">{load.id}</TableCell>
                    <TableCell>{load.route}</TableCell>
                    <TableCell>{load.carrier}</TableCell>
                    <TableCell>{load.completedDate}</TableCell>
                    <TableCell className="font-semibold">{load.rate}</TableCell>
                    <TableCell className="font-semibold text-green-600">{load.margin}</TableCell>
                    <TableCell>
                      <Badge className="bg-green-100 text-green-800">
                        {load.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" className="gap-2">
                        <Eye className="h-3 w-3" />
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
