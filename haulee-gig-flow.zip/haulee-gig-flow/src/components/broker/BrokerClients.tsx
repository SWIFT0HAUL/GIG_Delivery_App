import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Building2, Phone, Mail, MapPin, Plus, Search } from 'lucide-react';

export function BrokerClients() {
  const clients = [
    { 
      id: 'C001', 
      name: 'ABC Logistics', 
      contact: 'Sarah Johnson', 
      email: 'sarah@abclogistics.com', 
      phone: '(555) 123-4567',
      location: 'Los Angeles, CA',
      activeJobs: 3,
      totalJobs: 45,
      status: 'Active',
      rating: 4.8
    },
    { 
      id: 'C002', 
      name: 'XYZ Shipping', 
      contact: 'Mike Chen', 
      email: 'mike@xyzshipping.com', 
      phone: '(555) 987-6543',
      location: 'Chicago, IL',
      activeJobs: 2,
      totalJobs: 32,
      status: 'Active',
      rating: 4.6
    },
    { 
      id: 'C003', 
      name: 'Global Transport', 
      contact: 'Emma Davis', 
      email: 'emma@globaltransport.com', 
      phone: '(555) 456-7890',
      location: 'Seattle, WA',
      activeJobs: 1,
      totalJobs: 28,
      status: 'Active',
      rating: 4.9
    },
    { 
      id: 'C004', 
      name: 'Fast Delivery Co', 
      contact: 'Alex Rodriguez', 
      email: 'alex@fastdelivery.com', 
      phone: '(555) 321-0987',
      location: 'Dallas, TX',
      activeJobs: 0,
      totalJobs: 15,
      status: 'Inactive',
      rating: 4.3
    }
  ];

  const partners = [
    {
      id: 'P001',
      name: 'Premier Carriers',
      type: 'Carrier Network',
      contact: 'James Wilson',
      email: 'james@premiercarriers.com',
      vehicles: 150,
      rating: 4.7,
      status: 'Active'
    },
    {
      id: 'P002', 
      name: 'Elite Drivers Alliance',
      type: 'Driver Network',
      contact: 'Lisa Anderson',
      email: 'lisa@elitedrivers.com',
      vehicles: 85,
      rating: 4.5,
      status: 'Active'
    }
  ];

  const getStatusColor = (status: string) => {
    return status === 'Active' ? 'bg-green-100 text-green-800 border-green-200' : 'bg-gray-100 text-gray-800 border-gray-200';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Clients & Partners</CardTitle>
              <CardDescription>Manage your client relationships and partner networks</CardDescription>
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Client
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search clients..." className="pl-8" />
            </div>
          </div>

          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Clients ({clients.length})</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Company</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Jobs</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {clients.map((client) => (
                  <TableRow key={client.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <div className="font-medium">{client.name}</div>
                          <div className="text-sm text-muted-foreground">ID: {client.id}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{client.contact}</div>
                        <div className="text-sm text-muted-foreground flex items-center">
                          <Mail className="h-3 w-3 mr-1" />
                          {client.email}
                        </div>
                        <div className="text-sm text-muted-foreground flex items-center">
                          <Phone className="h-3 w-3 mr-1" />
                          {client.phone}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center text-sm">
                        <MapPin className="h-3 w-3 mr-1" />
                        {client.location}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{client.activeJobs} active</div>
                        <div className="text-sm text-muted-foreground">{client.totalJobs} total</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="text-sm font-medium">{client.rating}/5</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(client.status)}>
                        {client.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm">View Details</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Partners ({partners.length})</h3>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Partner</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Fleet Size</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {partners.map((partner) => (
                  <TableRow key={partner.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <div className="font-medium">{partner.name}</div>
                          <div className="text-sm text-muted-foreground">ID: {partner.id}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{partner.type}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{partner.contact}</div>
                        <div className="text-sm text-muted-foreground">{partner.email}</div>
                      </div>
                    </TableCell>
                    <TableCell>{partner.vehicles} vehicles</TableCell>
                    <TableCell>{partner.rating}/5</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(partner.status)}>
                        {partner.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm">View Details</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}