import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText } from 'lucide-react';

export function BrokerInvoicing() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Invoicing & Billing
        </CardTitle>
        <CardDescription>Manage invoices and billing</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-muted-foreground">Invoice management coming soon</p>
      </CardContent>
    </Card>
  );
}
