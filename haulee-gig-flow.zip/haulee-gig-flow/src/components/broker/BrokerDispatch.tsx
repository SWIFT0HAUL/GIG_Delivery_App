import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Truck, MapPin } from 'lucide-react';

export function BrokerDispatch() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Truck className="h-5 w-5" />
          Dispatch & Operations
        </CardTitle>
        <CardDescription>Real-time dispatch and operational management</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="p-4 border rounded-lg">
            <div className="flex justify-between items-start mb-2">
              <div>
                <p className="font-medium">Load #LD-4501</p>
                <p className="text-sm text-muted-foreground">LA → Phoenix</p>
              </div>
              <Badge className="bg-blue-100 text-blue-800">In Transit</Badge>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <MapPin className="h-4 w-4" />
              <span>Current: Bakersfield, CA</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
