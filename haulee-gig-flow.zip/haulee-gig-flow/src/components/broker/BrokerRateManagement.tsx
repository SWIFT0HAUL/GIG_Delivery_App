import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, TrendingDown } from 'lucide-react';

export function BrokerRateManagement() {
  const lanes = [
    { route: 'LA → Phoenix', avgRate: '$1,850', trend: 'up', change: '+5%' },
    { route: 'Dallas → Houston', avgRate: '$950', trend: 'down', change: '-3%' },
    { route: 'Chicago → Atlanta', avgRate: '$2,650', trend: 'up', change: '+8%' },
    { route: 'Miami → NYC', avgRate: '$3,200', trend: 'up', change: '+12%' },
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Rate Per Mile</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$2.45</div>
            <p className="text-xs text-muted-foreground">+$0.15 from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Margin</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">18.5%</div>
            <p className="text-xs text-muted-foreground">+1.2% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$182,400</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Rate Management & Pricing</CardTitle>
          <CardDescription>Manage lane rates and pricing strategies</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="base-rate">Base Rate Per Mile</Label>
                <Input id="base-rate" type="number" placeholder="2.45" step="0.01" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="min-margin">Minimum Margin %</Label>
                <Input id="min-margin" type="number" placeholder="15" step="0.5" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="target-margin">Target Margin %</Label>
                <Input id="target-margin" type="number" placeholder="20" step="0.5" />
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Lane Rate Trends</h3>
              <div className="space-y-3">
                {lanes.map((lane, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div>
                        <p className="font-medium">{lane.route}</p>
                        <p className="text-sm text-muted-foreground">Average Rate: {lane.avgRate}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <Badge className={lane.trend === 'up' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                        {lane.trend === 'up' ? (
                          <TrendingUp className="h-3 w-3 mr-1" />
                        ) : (
                          <TrendingDown className="h-3 w-3 mr-1" />
                        )}
                        {lane.change}
                      </Badge>
                      <Button size="sm" variant="outline">Edit Rate</Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-4">
              <Button variant="outline">Reset to Defaults</Button>
              <Button>Save Changes</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
