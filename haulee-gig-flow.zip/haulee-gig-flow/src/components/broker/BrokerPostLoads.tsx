import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, MapPin, Package, Calendar, DollarSign } from 'lucide-react';
import { toast } from 'sonner';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { VEHICLE_CATEGORIES } from '@/lib/vehicleConfig';

export function BrokerPostLoads() {
  const [formData, setFormData] = useState({
    origin: '',
    destination: '',
    pickupDate: '',
    deliveryDate: '',
    vehicleType: '',
    weight: '',
    distance: '',
    length: '',
    width: '',
    height: '',
    rate: '',
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Load posted successfully!');
    setFormData({
      origin: '',
      destination: '',
      pickupDate: '',
      deliveryDate: '',
      vehicleType: '',
      weight: '',
      distance: '',
      length: '',
      width: '',
      height: '',
      rate: '',
      description: ''
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Post New Load
          </CardTitle>
          <CardDescription>Create a new delivery gig job for carriers</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <MapPin className="h-4 w-4 text-green-600" />
                  <Label>Origin</Label>
                </div>
                <AddressAutocomplete
                  value={formData.origin}
                  onAddressSelect={(address) => setFormData({ ...formData, origin: address.formatted_address || '' })}
                  placeholder="Start typing origin address..."
                  required
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2 mb-2">
                  <MapPin className="h-4 w-4 text-red-600" />
                  <Label>Destination</Label>
                </div>
                <AddressAutocomplete
                  value={formData.destination}
                  onAddressSelect={(address) => setFormData({ ...formData, destination: address.formatted_address || '' })}
                  placeholder="Start typing destination address..."
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="pickupDate" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Pickup Date
                </Label>
                <Input
                  id="pickupDate"
                  type="date"
                  value={formData.pickupDate}
                  onChange={(e) => setFormData({ ...formData, pickupDate: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="deliveryDate" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Delivery Date
                </Label>
                <Input
                  id="deliveryDate"
                  type="date"
                  value={formData.deliveryDate}
                  onChange={(e) => setFormData({ ...formData, deliveryDate: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="vehicleType" className="flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Vehicle Type
                </Label>
                <Select value={formData.vehicleType} onValueChange={(value) => setFormData({ ...formData, vehicleType: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select vehicle type" />
                  </SelectTrigger>
                  <SelectContent className="max-h-[300px]">
                    {VEHICLE_CATEGORIES.map((category) => (
                      <React.Fragment key={category.id}>
                        <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                          {category.icon} {category.name}
                        </div>
                        {category.vehicle_types.map((vehicle) => (
                          <SelectItem 
                            key={vehicle.name} 
                            value={vehicle.name}
                            className="pl-6"
                          >
                            {vehicle.name} ({vehicle.capacity})
                          </SelectItem>
                        ))}
                      </React.Fragment>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priority *</Label>
                <Select required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pickup_now">Pick Up Now</SelectItem>
                    <SelectItem value="claimed">Claimed</SelectItem>
                    <SelectItem value="route">Route</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight">Weight (lbs)</Label>
                <Input
                  id="weight"
                  type="number"
                  placeholder="0"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="distance">Distance (miles)</Label>
                <Input
                  id="distance"
                  type="number"
                  placeholder="0"
                  value={formData.distance}
                  onChange={(e) => setFormData({ ...formData, distance: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="length">Length (ft)</Label>
                <Input
                  id="length"
                  type="number"
                  placeholder="0"
                  value={formData.length}
                  onChange={(e) => setFormData({ ...formData, length: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="width">Width (ft)</Label>
                <Input
                  id="width"
                  type="number"
                  placeholder="0"
                  value={formData.width}
                  onChange={(e) => setFormData({ ...formData, width: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="height">Height (ft)</Label>
                <Input
                  id="height"
                  type="number"
                  placeholder="0"
                  value={formData.height}
                  onChange={(e) => setFormData({ ...formData, height: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="rate" className="flex items-center gap-2">
                  <DollarSign className="h-4 w-4" />
                  Rate ($)
                </Label>
                <Input
                  id="rate"
                  type="number"
                  placeholder="0.00"
                  step="0.01"
                  value={formData.rate}
                  onChange={(e) => setFormData({ ...formData, rate: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Load Description</Label>
              <Textarea
                id="description"
                placeholder="Enter additional details about the load..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                rows={4}
              />
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <Checkbox id="signature_required" />
              <Label htmlFor="signature_required" className="text-sm font-normal cursor-pointer">
                Signature required upon delivery
              </Label>
            </div>

            <div className="flex justify-end gap-4">
              <Button type="button" variant="outline">Cancel</Button>
              <Button type="submit">Post Load</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
