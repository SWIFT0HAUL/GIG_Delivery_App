import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingUp, Download, Calendar } from 'lucide-react';

export function BrokerPayments() {
  const earnings = [
    { id: 'E001', jobId: '1001', client: 'ABC Logistics', amount: '$245.00', commission: '10%', date: '2024-01-20', status: 'Paid' },
    { id: 'E002', jobId: '1000', client: 'Mega Corp', amount: '$175.00', commission: '10%', date: '2024-01-18', status: 'Paid' },
    { id: 'E003', jobId: '0999', client: 'Quick Ship', amount: '$142.50', commission: '10%', date: '2024-01-15', status: 'Paid' },
    { id: 'E004', jobId: '1002', client: 'XYZ Shipping', amount: '$185.00', commission: '10%', date: '2024-01-22', status: 'Pending' },
  ];

  const payouts = [
    { id: 'P001', amount: '$2,450.00', period: 'Jan 1-15, 2024', method: 'Bank Transfer', date: '2024-01-16', status: 'Completed' },
    { id: 'P002', amount: '$3,120.00', period: 'Dec 16-31, 2023', method: 'Bank Transfer', date: '2024-01-02', status: 'Completed' },
    { id: 'P003', amount: '$1,875.00', period: 'Jan 16-31, 2024', method: 'Bank Transfer', date: 'Pending', status: 'Processing' },
  ];

  const monthlyReports = [
    { month: 'January 2024', totalEarnings: '$12,340', totalJobs: 45, avgCommission: '$274', status: 'Available' },
    { month: 'December 2023', totalEarnings: '$15,670', totalJobs: 52, avgCommission: '$301', status: 'Available' },
    { month: 'November 2023', totalEarnings: '$9,890', totalJobs: 38, avgCommission: '$260', status: 'Available' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Paid': 
      case 'Completed': 
      case 'Available': 
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Pending': 
      case 'Processing': 
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: 
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payments & Commissions</CardTitle>
        <CardDescription>Track your earnings, payouts, and financial reports</CardDescription>
      </CardHeader>
      <CardContent>
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Earnings (MTD)</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$12,340</div>
              <p className="text-xs text-muted-foreground">+8% from last month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending Earnings</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">$1,875</div>
              <p className="text-xs text-muted-foreground">From 7 jobs</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Next Payout</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">Feb 1</div>
              <p className="text-xs text-muted-foreground">$1,875 scheduled</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="earnings" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="earnings">Earnings</TabsTrigger>
            <TabsTrigger value="payouts">Payouts</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
          </TabsList>

          <TabsContent value="earnings" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Commission Earnings</h3>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Job ID</TableHead>
                  <TableHead>Client</TableHead>
                  <TableHead>Commission Rate</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {earnings.map((earning) => (
                  <TableRow key={earning.id}>
                    <TableCell className="font-medium">#{earning.jobId}</TableCell>
                    <TableCell>{earning.client}</TableCell>
                    <TableCell>{earning.commission}</TableCell>
                    <TableCell className="font-semibold">{earning.amount}</TableCell>
                    <TableCell>{earning.date}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(earning.status)}>
                        {earning.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          <TabsContent value="payouts" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Payout History</h3>
              <Button>Request Payout</Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Payout ID</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Period</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {payouts.map((payout) => (
                  <TableRow key={payout.id}>
                    <TableCell className="font-medium">{payout.id}</TableCell>
                    <TableCell className="font-semibold">{payout.amount}</TableCell>
                    <TableCell>{payout.period}</TableCell>
                    <TableCell>{payout.method}</TableCell>
                    <TableCell>{payout.date}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(payout.status)}>
                        {payout.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Monthly Reports</h3>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download All
              </Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Period</TableHead>
                  <TableHead>Total Earnings</TableHead>
                  <TableHead>Total Jobs</TableHead>
                  <TableHead>Avg Commission</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {monthlyReports.map((report, index) => (
                  <TableRow key={index}>
                    <TableCell className="font-medium">{report.month}</TableCell>
                    <TableCell className="font-semibold">{report.totalEarnings}</TableCell>
                    <TableCell>{report.totalJobs}</TableCell>
                    <TableCell>{report.avgCommission}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(report.status)}>
                        {report.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}