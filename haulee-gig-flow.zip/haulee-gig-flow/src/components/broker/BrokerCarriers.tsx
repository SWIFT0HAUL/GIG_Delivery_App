import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Star, Truck, Phone, Mail } from 'lucide-react';

export function BrokerCarriers() {
  const [searchTerm, setSearchTerm] = useState('');

  const carriers = [
    { 
      id: 'CR-1001',
      name: 'Fast Freight LLC',
      equipment: 'Dry Van, Flatbed',
      activeLoads: 8,
      completedJobs: 247,
      rating: 4.8,
      phone: '(555) 123-4567',
      email: 'dispatch@fastfreight.com',
      status: 'Active'
    },
    { 
      id: 'CR-1002',
      name: 'Texas Transport',
      equipment: 'Flatbed, Reefer',
      activeLoads: 5,
      completedJobs: 189,
      rating: 4.6,
      phone: '(555) 234-5678',
      email: 'ops@texastransport.com',
      status: 'Active'
    },
    { 
      id: 'CR-1003',
      name: 'Midwest Carriers',
      equipment: 'Dry Van, Reefer',
      activeLoads: 12,
      completedJobs: 456,
      rating: 4.9,
      phone: '(555) 345-6789',
      email: 'info@midwestcarriers.com',
      status: 'Active'
    },
    { 
      id: 'CR-1004',
      name: 'East Coast Express',
      equipment: 'All Types',
      activeLoads: 0,
      completedJobs: 321,
      rating: 4.7,
      phone: '(555) 456-7890',
      email: 'dispatch@eastcoastexpress.com',
      status: 'Inactive'
    },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Truck className="h-5 w-5" />
            Carrier Network / Directory
          </CardTitle>
          <CardDescription>Manage your carrier relationships and find qualified carriers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search carriers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button>Add Carrier</Button>
          </div>

          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Carrier ID</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Equipment</TableHead>
                  <TableHead>Active Loads</TableHead>
                  <TableHead>Completed</TableHead>
                  <TableHead>Rating</TableHead>
                  <TableHead>Contact</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {carriers.map((carrier) => (
                  <TableRow key={carrier.id}>
                    <TableCell className="font-medium">{carrier.id}</TableCell>
                    <TableCell>{carrier.name}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{carrier.equipment}</TableCell>
                    <TableCell>{carrier.activeLoads}</TableCell>
                    <TableCell>{carrier.completedJobs}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span>{carrier.rating}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-xs">
                          <Phone className="h-3 w-3" />
                          <span>{carrier.phone}</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Mail className="h-3 w-3" />
                          <span>{carrier.email}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={carrier.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                        {carrier.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline">View Profile</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
