import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, MapPin, Package, DollarSign, Truck, Calendar } from 'lucide-react';

export function BrokerLoadBoard() {
  const [searchTerm, setSearchTerm] = useState('');
  const [equipmentFilter, setEquipmentFilter] = useState('all');

  const availableLoads = [
    { 
      id: 'LD-4501', 
      origin: 'Los Angeles, CA', 
      destination: 'Phoenix, AZ',
      pickupDate: '2024-01-20',
      deliveryDate: '2024-01-21',
      equipment: 'Dry Van',
      weight: '42,000 lbs',
      rate: '$1,850',
      distance: '373 mi',
      shipper: 'ABC Manufacturing'
    },
    { 
      id: 'LD-4502', 
      origin: 'Dallas, TX', 
      destination: 'Houston, TX',
      pickupDate: '2024-01-21',
      deliveryDate: '2024-01-21',
      equipment: 'Flatbed',
      weight: '35,000 lbs',
      rate: '$950',
      distance: '239 mi',
      shipper: 'Texas Steel Co'
    },
    { 
      id: 'LD-4503', 
      origin: 'Chicago, IL', 
      destination: 'Atlanta, GA',
      pickupDate: '2024-01-22',
      deliveryDate: '2024-01-24',
      equipment: 'Reefer',
      weight: '38,500 lbs',
      rate: '$2,650',
      distance: '716 mi',
      shipper: 'Fresh Foods Inc'
    },
    { 
      id: 'LD-4504', 
      origin: 'Miami, FL', 
      destination: 'New York, NY',
      pickupDate: '2024-01-23',
      deliveryDate: '2024-01-25',
      equipment: 'Dry Van',
      weight: '44,000 lbs',
      rate: '$3,200',
      distance: '1,282 mi',
      shipper: 'Global Imports'
    },
  ];

  const getEquipmentColor = (equipment: string) => {
    switch (equipment) {
      case 'Dry Van': return 'bg-blue-100 text-blue-800';
      case 'Flatbed': return 'bg-purple-100 text-purple-800';
      case 'Reefer': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Available Freight / Load Board
          </CardTitle>
          <CardDescription>Browse and book available delivery gig jobs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by origin, destination, or load ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={equipmentFilter} onValueChange={setEquipmentFilter}>
              <SelectTrigger className="w-full sm:w-[200px]">
                <SelectValue placeholder="Equipment type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Equipment</SelectItem>
                <SelectItem value="dry-van">Dry Van</SelectItem>
                <SelectItem value="flatbed">Flatbed</SelectItem>
                <SelectItem value="reefer">Reefer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Load ID</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Dates</TableHead>
                  <TableHead>Equipment</TableHead>
                  <TableHead>Weight</TableHead>
                  <TableHead>Rate</TableHead>
                  <TableHead>Distance</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {availableLoads.map((load) => (
                  <TableRow key={load.id}>
                    <TableCell className="font-medium">{load.id}</TableCell>
                    <TableCell>
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="h-3 w-3 text-green-600" />
                          <span>{load.origin}</span>
                        </div>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MapPin className="h-3 w-3 text-red-600" />
                          <span>{load.destination}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="space-y-1 text-sm">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          <span>Pick: {load.pickupDate}</span>
                        </div>
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          <span>Del: {load.deliveryDate}</span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getEquipmentColor(load.equipment)}>
                        {load.equipment}
                      </Badge>
                    </TableCell>
                    <TableCell>{load.weight}</TableCell>
                    <TableCell className="font-semibold text-green-600">{load.rate}</TableCell>
                    <TableCell>{load.distance}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button size="sm">Book</Button>
                        <Button size="sm" variant="outline">Details</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
