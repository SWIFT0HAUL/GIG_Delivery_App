import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Eye, Edit, MoreHorizontal } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';

export function BrokerJobs() {
  const assignedJobs = [
    { id: '1001', client: 'ABC Logistics', route: 'LA → NYC', value: '$2,450', status: 'In Progress', driver: 'John Smith' },
    { id: '1002', client: 'XYZ Shipping', route: 'Chicago → Miami', value: '$1,850', status: 'Assigned', driver: 'Jane Doe' },
    { id: '1003', client: 'Global Transport', route: 'Seattle → Denver', value: '$1,650', status: 'In Transit', driver: 'Mike Johnson' },
  ];

  const pendingJobs = [
    { id: '1004', client: 'Fast Delivery Co', route: 'Dallas → Phoenix', value: '$1,920', status: 'Pending Review', driver: 'Unassigned' },
    { id: '1005', client: 'Prime Logistics', route: 'Boston → Atlanta', value: '$2,100', status: 'Awaiting Approval', driver: 'Unassigned' },
  ];

  const completedJobs = [
    { id: '1000', client: 'Mega Corp', route: 'SF → Portland', value: '$1,750', status: 'Completed', driver: 'Sarah Wilson', completedDate: '2024-01-15' },
    { id: '0999', client: 'Quick Ship', route: 'Las Vegas → Salt Lake', value: '$1,425', status: 'Completed', driver: 'Tom Brown', completedDate: '2024-01-14' },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Assigned': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'In Transit': return 'bg-sky-100 text-sky-800 border-sky-200';
      case 'On Hold': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Pending Review': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Awaiting Approval': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Completed': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const JobTable = ({ jobs, showCompletedDate = false }: { jobs: any[], showCompletedDate?: boolean }) => (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Job ID</TableHead>
          <TableHead>Client</TableHead>
          <TableHead>Route</TableHead>
          <TableHead>Value</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Driver</TableHead>
          {showCompletedDate && <TableHead>Completed</TableHead>}
          <TableHead>Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {jobs.map((job) => (
          <TableRow key={job.id}>
            <TableCell className="font-medium">#{job.id}</TableCell>
            <TableCell>{job.client}</TableCell>
            <TableCell>{job.route}</TableCell>
            <TableCell className="font-semibold">{job.value}</TableCell>
            <TableCell>
              <Badge className={getStatusColor(job.status)}>
                {job.status}
              </Badge>
            </TableCell>
            <TableCell>{job.driver}</TableCell>
            {showCompletedDate && <TableCell>{job.completedDate}</TableCell>}
            <TableCell>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem>
                    <Eye className="h-4 w-4 mr-2" />
                    View Details
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Job
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle>Jobs & Contracts</CardTitle>
        <CardDescription>Manage your assigned jobs and track their progress</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="assigned" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="assigned">Assigned Jobs</TabsTrigger>
            <TabsTrigger value="pending">Pending Approval</TabsTrigger>
            <TabsTrigger value="completed">Completed Jobs</TabsTrigger>
          </TabsList>

          <TabsContent value="assigned" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Active Assignments ({assignedJobs.length})</h3>
              <Button>Create New Job</Button>
            </div>
            <JobTable jobs={assignedJobs} />
          </TabsContent>

          <TabsContent value="pending" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Awaiting Approval ({pendingJobs.length})</h3>
            </div>
            <JobTable jobs={pendingJobs} />
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Completed Jobs ({completedJobs.length})</h3>
            </div>
            <JobTable jobs={completedJobs} showCompletedDate />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}