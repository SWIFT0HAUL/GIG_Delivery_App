import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Check, ExternalLink, FileText, ListChecks, ArrowRight, CheckCircle2, Circle } from 'lucide-react';
import { ProfileCompletionWorkspace } from './ProfileCompletionWorkspace';
import { EmailVerificationForm } from './admin/onboarding/forms/EmailVerificationForm';
import { IDDocumentUploadForm } from './admin/onboarding/forms/IDDocumentUploadForm';
import { TermsAcceptanceForm } from './admin/onboarding/forms/TermsAcceptanceForm';
import { MFASetupForm } from './admin/onboarding/forms/MFASetupForm';
import { TaskStepDialog } from './tasks/TaskStepDialog';
import { useTaskStepSubmission } from '@/hooks/useTaskStepSubmission';
import { DynamicTaskForm } from './tasks/DynamicTaskForm';
interface RedirectStep {
  step_number: number;
  step_name: string;
  step_description: string;
  path: string;
  is_optional: boolean;
}
interface TaskWorkspaceModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  task: {
    id: string;
    name: string;
    description: string;
    category: string;
    custom_link?: string;
    redirect_path?: RedirectStep[];
    task_form_schema?: any;
  };
  onComplete: () => void;
  canComplete: boolean;
  onInteraction: () => void;
  onTaskAutoCompleted?: () => void;
}
export function TaskWorkspaceModal({
  open,
  onOpenChange,
  task,
  onComplete,
  canComplete,
  onInteraction,
  onTaskAutoCompleted
}: TaskWorkspaceModalProps) {
  const navigate = useNavigate();
  const [hasInteracted, setHasInteracted] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeStep, setActiveStep] = useState<RedirectStep | null>(null);
  const [selectedStepIndex, setSelectedStepIndex] = useState<number | null>(null);
  const [stepDialogOpen, setStepDialogOpen] = useState(false);
  const {
    isStepCompleted,
    fetchSubmissions,
    getStepSubmission
  } = useTaskStepSubmission(task?.id || '');
  
  const steps = task.redirect_path || [];
  
  // Filter out skipped payment method steps
  const visibleSteps = steps.filter(step => {
    // For payment method task, check if step should be hidden
    if (task.name === 'Setup Payment Receiving Method' && (step.step_number === 3 || step.step_number === 4)) {
      const step2Submission = getStepSubmission(2);
      if (step2Submission?.submission_data) {
        const paymentMethod = (step2Submission.submission_data as any).payment_method;
        // Hide banking info (step 3) if debit card selected
        if (step.step_number === 3 && paymentMethod === 'debit_card') return false;
        // Hide debit card info (step 4) if direct deposit selected
        if (step.step_number === 4 && paymentMethod === 'direct_deposit') return false;
      }
    }
    return true;
  });
  
  const allStepsDone = visibleSteps.length > 0 && visibleSteps.every(s => isStepCompleted(s.step_number));
  useEffect(() => {
    if (!open) {
      setHasInteracted(false);
      setScrollProgress(0);
    }
  }, [open]);
  useEffect(() => {
    if (open && task?.id) {
      fetchSubmissions();
    }
  }, [open, task?.id]);
  const handleInteraction = () => {
    if (!hasInteracted) {
      setHasInteracted(true);
      onInteraction();
    }
  };
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    const scrolled = target.scrollTop;
    const maxScroll = target.scrollHeight - target.clientHeight;
    const progress = maxScroll > 0 ? scrolled / maxScroll * 100 : 100;
    setScrollProgress(progress);

    // Mark as interacted if user scrolls significantly (more than 20%)
    if (progress > 20) {
      handleInteraction();
    }
  };
  const handleStepClick = (step: RedirectStep, index: number) => {
    handleInteraction();
    try {
      setActiveStep(step);
      setSelectedStepIndex(index);
      setStepDialogOpen(true);
    } catch (error) {
      console.error('Failed to open step dialog:', error);
    }
  };
  const handleNavigateNext = () => {
    if (selectedStepIndex !== null && selectedStepIndex < visibleSteps.length - 1) {
      const nextIndex = selectedStepIndex + 1;
      const nextStep = visibleSteps[nextIndex];
      setActiveStep(nextStep);
      setSelectedStepIndex(nextIndex);
    } else {
      setStepDialogOpen(false);
    }
  };
  const handleStepComplete = async () => {
    await fetchSubmissions();
  };
  const handleCustomLinkClick = () => {
    handleInteraction();
    if (task.custom_link) {
      if (task.custom_link.startsWith('http')) {
        try {
          window.open(task.custom_link, '_blank');
        } catch (error) {
          console.error('Failed to open custom link:', error);
        }
      } else {
        console.error('Invalid external link format. Link must start with http:// or https://');
      }
    }
  };
  return <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[calc(100%-1rem)] sm:max-w-2xl md:max-w-4xl lg:max-w-6xl max-h-[85vh] p-0 overflow-hidden">
        {/* Header with gradient background */}
        <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent pt-6 pb-4 border-b py-0 px-[6px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-2xl font-bold">
              <div className="p-2 bg-primary/10 rounded-lg">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <span className="bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent px-0 py-0 my-0 mx-0 text-lg text-left">
                {task.name}
              </span>
            </DialogTitle>
            <DialogDescription className="text-base mt-2 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              Complete this task to unlock full access
            </DialogDescription>
            <Badge variant="secondary" className="w-fit mt-3 px-3 py-1">{task.category}</Badge>
          </DialogHeader>
        </div>

        <ScrollArea className="px-6 py-4 max-h-[60vh]" onScroll={handleScroll} onClick={handleInteraction}>
          <div className="space-y-6">
            {/* Dynamic form rendering based on task_form_schema */}
            {task.task_form_schema ? (
              <DynamicTaskForm 
                taskId={task.id} 
                onBack={() => {
                  onComplete();
                  onOpenChange(false);
                }} 
              />
            ) : task.name === 'Complete Profile Information' ? <ProfileCompletionWorkspace onComplete={onComplete} onClose={() => onOpenChange(false)} /> : task.name === 'Verify Email' ? <EmailVerificationForm onComplete={onComplete} /> : task.name === 'Upload ID Document' ? <IDDocumentUploadForm onComplete={onComplete} /> : task.name === 'Accept Terms & Conditions' ? <TermsAcceptanceForm onComplete={onComplete} /> : (task.name === 'Setup MFA' || task.name === 'Enable MFA') ? <MFASetupForm onComplete={onComplete} /> : <>
                {/* Task Description */}
                {task.description && <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
                    <CardHeader>
                      <CardTitle className="text-lg flex items-center gap-2">
                        <FileText className="w-5 h-5 text-primary" />
                        Task Instructions
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-foreground/80 whitespace-pre-wrap leading-relaxed">
                        {task.description}
                      </p>
                    </CardContent>
                  </Card>}

            {/* Custom Link */}
            {task.custom_link && <Card className="border-primary/30 bg-gradient-to-br from-blue-500/5 to-transparent hover:shadow-md transition-shadow">
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <div className="p-1.5 bg-blue-500/10 rounded">
                      <ExternalLink className="w-4 h-4 text-blue-500" />
                    </div>
                    External Resource
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Button onClick={handleCustomLinkClick} className="w-full gap-2 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70">
                    <ExternalLink className="w-4 h-4" />
                    Open Task Link
                  </Button>
                </CardContent>
              </Card>}

            {/* Redirect Steps */}
            {task.redirect_path && task.redirect_path.length > 0 && <Card className="border-primary/20">
                <CardHeader className="bg-gradient-to-r from-primary/5 to-transparent">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <div className="p-1.5 bg-primary/10 rounded">
                      <ListChecks className="w-5 h-5 text-primary" />
                    </div>
                    Task Steps
                    <Badge variant="outline" className="ml-auto">{visibleSteps.filter(s => isStepCompleted(s.step_number)).length}/{visibleSteps.length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-1 pt-2">
                  {visibleSteps.map((step, index) => {
                  const completed = isStepCompleted(step.step_number);
                  return <Card key={step.step_number} className={`group p-1.5 hover:shadow-lg transition-all cursor-pointer border-l-2 relative overflow-hidden ${completed ? 'border-l-green-500 bg-gradient-to-r from-green-500/5 to-transparent' : 'border-l-primary hover:border-l-primary/80 hover:from-primary/5 hover:to-transparent'}`} onClick={() => handleStepClick(step, index)}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-1.5 mr-1">
                            {completed ? <div className="p-0.5 bg-green-500/10 rounded-full">
                                <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />
                              </div> : <div className="p-0.5 bg-primary/10 rounded-full group-hover:bg-primary/20 transition-colors">
                                <Circle className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                              </div>}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-1.5 mb-0.5 flex-wrap">
                              <Badge variant={completed ? "default" : "secondary"} className={`text-[10px] px-1.5 py-0 h-4 ${completed ? "bg-green-500" : ""}`}>
                                Step {step.step_number}
                              </Badge>
                              <h4 className="font-semibold text-xs truncate">{step.step_name}</h4>
                              {step.is_optional && <Badge variant="outline" className="text-[9px] px-1 py-0 h-3.5">Optional</Badge>}
                            </div>
                            {step.step_description && <p className="text-[11px] text-muted-foreground line-clamp-1 leading-tight">
                                {step.step_description}
                              </p>}
                          </div>
                          <ArrowRight className="w-3 h-3 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all flex-shrink-0" />
                        </div>
                      </Card>;
                })}
                </CardContent>
              </Card>}

                {/* Interaction Prompt */}
                {!hasInteracted && task.name !== 'Complete Profile Information' && <Card className="border-amber-400/30 bg-gradient-to-br from-amber-400/10 to-transparent">
                    <CardContent className="pt-4 flex items-start gap-3">
                      <div className="p-2 bg-amber-400/20 rounded-lg flex-shrink-0">
                        <FileText className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                      </div>
                      <p className="text-sm text-amber-800 dark:text-amber-200 leading-relaxed pt-1">
                        <strong>Review Required:</strong> Please review the task content and complete any required steps before marking this task as complete.
                      </p>
                    </CardContent>
                  </Card>}
              </>}
          </div>
        </ScrollArea>

        {/* Footer Actions - Hide for tasks with embedded forms or task_form_schema */}
        {!task.task_form_schema && !['Complete Profile Information', 'Verify Email', 'Upload ID Document', 'Accept Terms & Conditions', 'Setup MFA', 'Enable MFA'].includes(task.name) && <div className="flex items-center justify-between px-6 py-4 border-t bg-gradient-to-r from-muted/50 to-transparent">
            <div className="flex items-center gap-2 text-sm">
              {canComplete || allStepsDone ? <div className="flex items-center gap-2 text-green-600 dark:text-green-400 font-medium">
                  <div className="p-1 bg-green-500/10 rounded-full">
                    <Check className="w-4 h-4" />
                  </div>
                  Ready to complete
                </div> : <span className="text-muted-foreground">Review content or complete all steps to enable completion</span>}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => onOpenChange(false)} className="hover:bg-muted">
                Close
              </Button>
              <Button onClick={onComplete} disabled={!(canComplete || allStepsDone)} className={`gap-2 ${canComplete || allStepsDone ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700' : ''}`}>
                <Check className="w-4 h-4" />
                Complete Task
              </Button>
            </div>
          </div>}
      </DialogContent>

      <TaskStepDialog open={stepDialogOpen} onOpenChange={setStepDialogOpen} step={activeStep} taskId={task.id} onStepComplete={handleStepComplete} hasNextStep={selectedStepIndex !== null && selectedStepIndex < visibleSteps.length - 1} onNavigateNext={handleNavigateNext} totalSteps={visibleSteps.length} onTaskAutoCompleted={onTaskAutoCompleted} taskName={task.name} nested={true} />
    </Dialog>;
}