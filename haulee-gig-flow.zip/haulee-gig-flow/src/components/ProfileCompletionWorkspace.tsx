import { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { User, Building2, Camera, Phone, Mail, MapPin, Briefcase, Upload } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { useUserRole } from '@/hooks/useUserRole';

interface ProfileCompletionWorkspaceProps {
  onComplete: () => void;
  onClose?: () => void;
}

export function ProfileCompletionWorkspace({ onComplete, onClose }: ProfileCompletionWorkspaceProps) {
  const { user } = useAuth();
  const { profile } = useUserRole();
  const [isLoading, setIsLoading] = useState(false);
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  
  const [formData, setFormData] = useState({
    // Personal Information
    firstName: '',
    lastName: '',
    email: user?.email || '',
    phone: '',
    address: '',
    emergencyContact: '',
    
    // Job/Company Information
    jobTitle: '',
    companyName: '',
    companyAddress: '',
    taxId: '',
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast.error('Image must be less than 5MB');
        return;
      }
      setProfileImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  const handleCameraClick = () => {
    cameraInputRef.current?.click();
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const isDriver = profile?.role_name === 'driver';

  const handleSubmit = async () => {
    setIsLoading(true);
    try {
      if (!user?.id) {
        toast.error('You must be signed in to save your profile.');
        return;
      }
      let profileImageUrl = null;

      // Upload profile image if provided
      if (profileImage && user?.id) {
        const fileExt = profileImage.name.split('.').pop();
        const fileName = `${user.id}/profile-${Date.now()}.${fileExt}`;
        
        const { error: uploadError } = await supabase.storage
          .from('profiles')
          .upload(fileName, profileImage, {
            upsert: true
          });

        if (uploadError) {
          console.error('Upload error:', uploadError);
          throw uploadError;
        }

        const { data: { publicUrl } } = supabase.storage
          .from('profiles')
          .getPublicUrl(fileName);
        
        profileImageUrl = publicUrl;
      }

      // Save profile data
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          full_name: `${formData.firstName} ${formData.lastName}`.trim(),
          phone: formData.phone,
          updated_at: new Date().toISOString(),
        })
        .eq('id', user?.id);

      if (updateError) {
        console.error('Profile update error:', updateError);
        throw updateError;
      }

      // Save additional profile data to onboarding_data
      const { error: onboardingError } = await supabase
        .from('onboarding_data')
        .upsert(
          {
            user_id: user.id,
            step_number: 1,
            step_title: 'Profile Information',
            step_data: {
              ...formData,
              profileImageUrl,
              completedAt: new Date().toISOString(),
            },
            is_complete: true,
          },
          { onConflict: 'user_id,step_number' }
        );

      if (onboardingError) {
        console.error('Onboarding data error:', onboardingError);
        throw onboardingError;
      }

      toast.success('Profile information saved successfully!');
      
      // Close modal first to give immediate feedback
      if (onClose) {
        onClose();
      }
      
      // Then complete the task (this might take time)
      try {
        await onComplete();
      } catch (completeError) {
        console.error('Error completing task:', completeError);
        // Don't show error to user since profile was saved successfully
      }
    } catch (error: any) {
      console.error('Error saving profile:', error);
      toast.error(error?.message || 'Failed to save profile information');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full max-w-full px-4 sm:px-6 py-4 space-y-6">
      {/* Profile Picture Upload */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <Camera className="h-5 w-5 shrink-0" />
            Profile Picture
          </CardTitle>
          <CardDescription className="text-sm">Upload a professional photo</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
            <div className="w-24 h-24 shrink-0 bg-muted rounded-full flex items-center justify-center overflow-hidden border-2 border-muted">
              {profileImagePreview ? (
                <img src={profileImagePreview} alt="Profile" className="w-full h-full object-cover" />
              ) : (
                <User className="h-12 w-12 text-muted-foreground" />
              )}
            </div>
            <div className="w-full space-y-3">
              <div className="flex flex-col sm:flex-row gap-2">
                <Button 
                  type="button"
                  variant="outline" 
                  size="sm" 
                  onClick={handleCameraClick}
                  className="gap-2 w-full sm:w-auto"
                >
                  <Camera className="h-4 w-4" />
                  Take Photo
                </Button>
                <Button 
                  type="button"
                  variant="outline" 
                  size="sm" 
                  onClick={handleUploadClick}
                  className="gap-2 w-full sm:w-auto"
                >
                  <Upload className="h-4 w-4" />
                  Upload Image
                </Button>
              </div>
              <p className="text-xs text-muted-foreground text-center sm:text-left">JPG, PNG up to 5MB</p>
              
              {/* Hidden file inputs */}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/jpg"
                onChange={handleImageChange}
                className="hidden"
              />
              <input
                ref={cameraInputRef}
                type="file"
                accept="image/*"
                capture="user"
                onChange={handleImageChange}
                className="hidden"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Personal Information */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <User className="h-5 w-5 shrink-0" />
            Personal Information
          </CardTitle>
          <CardDescription className="text-sm">Enter your basic contact details</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">
                <span className="flex items-center gap-2">
                  First Name <span className="text-destructive">*</span>
                </span>
              </Label>
              <Input
                id="firstName"
                value={formData.firstName}
                onChange={(e) => handleInputChange('firstName', e.target.value)}
                placeholder="Enter your first name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">
                <span className="flex items-center gap-2">
                  Last Name <span className="text-destructive">*</span>
                </span>
              </Label>
              <Input
                id="lastName"
                value={formData.lastName}
                onChange={(e) => handleInputChange('lastName', e.target.value)}
                placeholder="Enter your last name"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">
              <span className="flex items-center gap-2">
                <Mail className="h-4 w-4" />
                Email Address <span className="text-destructive">*</span>
              </span>
            </Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              placeholder="your.email@example.com"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">
              <span className="flex items-center gap-2">
                <Phone className="h-4 w-4" />
                Phone Number <span className="text-destructive">*</span>
              </span>
            </Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => handleInputChange('phone', e.target.value)}
              placeholder="+1 (555) 123-4567"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 mb-2">
              <MapPin className="h-4 w-4" />
              <Label></Label>
            </div>
            <AddressAutocomplete
              value={formData.address}
              onAddressSelect={(address) => handleInputChange('address', address.formatted_address || '')}
              placeholder="Start typing your address..."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="emergencyContact">Emergency Contact</Label>
            <Input
              id="emergencyContact"
              value={formData.emergencyContact}
              onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
              placeholder="Name - Phone Number"
            />
          </div>
        </CardContent>
      </Card>

      {/* Job/Company Information */}
      <Card className="w-full">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
            <Briefcase className="h-5 w-5 shrink-0" />
            Professional Information
          </CardTitle>
          <CardDescription className="text-sm">Company and role details (if applicable)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="jobTitle">Job Title / Role</Label>
            <Input
              id="jobTitle"
              value={formData.jobTitle}
              onChange={(e) => handleInputChange('jobTitle', e.target.value)}
              placeholder="e.g., Logistics Manager, Driver, Broker"
              disabled={isDriver}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="companyName">
              <span className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                Company Name
              </span>
            </Label>
            <Input
              id="companyName"
              value={formData.companyName}
              onChange={(e) => handleInputChange('companyName', e.target.value)}
              placeholder="Enter your company name"
              disabled={isDriver}
            />
          </div>

          <div className="space-y-2">
            <Label>Company Address</Label>
            <AddressAutocomplete
              value={formData.companyAddress}
              onAddressSelect={(address) => handleInputChange('companyAddress', address.formatted_address || '')}
              placeholder=""
              disabled={isDriver}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="taxId">Tax ID / EIN (Optional)</Label>
            <Input
              id="taxId"
              value={formData.taxId}
              onChange={(e) => handleInputChange('taxId', e.target.value)}
              placeholder="XX-XXXXXXX"
            />
          </div>
        </CardContent>
      </Card>

      {/* Submit Button */}
      <div className="flex flex-col items-stretch sm:items-end gap-2 w-full">
        {(!formData.firstName || !formData.lastName || !formData.phone) && (
          <p className="text-sm text-amber-600 font-medium text-center sm:text-right">
            Please fill in all required fields (marked with *) to save
          </p>
        )}
        <Button
          onClick={handleSubmit}
          disabled={isLoading || !formData.firstName || !formData.lastName || !formData.phone}
          size="lg"
          className="w-full sm:w-auto"
        >
          {isLoading ? 'Saving...' : 'Save Profile Information'}
        </Button>
      </div>
    </div>
  );
}
