import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { CheckCircle, Camera, FileText, Star, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const ShipperDelivery = () => {
  const { toast } = useToast();
  const [rating, setRating] = useState(0);

  const pendingConfirmations = [
    {
      id: 'SH1240',
      carrier: 'Express Logistics',
      delivered: '2025-02-03 14:30',
      origin: 'Los Angeles, CA',
      destination: 'Denver, CO',
      receivedBy: 'John Smith',
      hasPhoto: true,
      hasSignature: true,
    },
    {
      id: 'SH1241',
      carrier: 'Swift Transport',
      delivered: '2025-02-03 10:15',
      origin: 'Chicago, IL',
      destination: 'Miami, FL',
      receivedBy: 'Sarah Johnson',
      hasPhoto: false,
      hasSignature: true,
    },
  ];

  const confirmDelivery = (shipmentId: string) => {
    toast({
      title: 'Delivery Confirmed',
      description: `Shipment ${shipmentId} has been confirmed as delivered.`,
    });
  };

  const reportIssue = (shipmentId: string) => {
    toast({
      title: 'Issue Reported',
      description: `A support ticket has been created for shipment ${shipmentId}.`,
      variant: 'destructive',
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Delivery Confirmations</CardTitle>
          <CardDescription>Review and confirm completed deliveries</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {pendingConfirmations.map((delivery) => (
            <Card key={delivery.id}>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold text-lg">Shipment {delivery.id}</h3>
                      <p className="text-sm text-muted-foreground">{delivery.carrier}</p>
                    </div>
                    <Badge variant="secondary">Pending Confirmation</Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-muted-foreground">Route</div>
                      <div className="font-medium">
                        {delivery.origin} → {delivery.destination}
                      </div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Delivered At</div>
                      <div className="font-medium">{delivery.delivered}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Received By</div>
                      <div className="font-medium">{delivery.receivedBy}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground">Documentation</div>
                      <div className="flex gap-2">
                        {delivery.hasSignature && (
                          <Badge variant="outline" className="gap-1">
                            <FileText className="h-3 w-3" />
                            Signature
                          </Badge>
                        )}
                        {delivery.hasPhoto && (
                          <Badge variant="outline" className="gap-1">
                            <Camera className="h-3 w-3" />
                            Photo
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-4">
                    <Label className="text-sm font-medium">Delivery Notes</Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Package delivered in good condition. Left at loading dock as requested.
                    </p>
                  </div>

                  <div className="flex flex-col md:flex-row gap-4 border-t pt-4">
                    <div className="flex-1">
                      <Label className="text-sm font-medium mb-2 block">Rate this delivery</Label>
                      <div className="flex gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            key={star}
                            onClick={() => setRating(star)}
                            className="focus:outline-none"
                          >
                            <Star
                              className={`h-6 w-6 ${
                                star <= rating
                                  ? 'fill-yellow-400 text-yellow-400'
                                  : 'text-gray-300'
                              }`}
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => reportIssue(delivery.id)}
                      >
                        <AlertCircle className="h-4 w-4 mr-2" />
                        Report Issue
                      </Button>
                      <Button onClick={() => confirmDelivery(delivery.id)}>
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Confirm Delivery
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Confirmations</CardTitle>
          <CardDescription>Your recently confirmed deliveries</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { id: 'SH1238', date: '2025-02-02', rating: 5 },
              { id: 'SH1237', date: '2025-02-01', rating: 4 },
              { id: 'SH1236', date: '2025-01-31', rating: 5 },
            ].map((confirmation) => (
              <div
                key={confirmation.id}
                className="flex justify-between items-center p-3 border rounded-lg"
              >
                <div>
                  <div className="font-medium">Shipment {confirmation.id}</div>
                  <div className="text-sm text-muted-foreground">
                    Confirmed on {confirmation.date}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(confirmation.rating)].map((_, i) => (
                      <Star
                        key={i}
                        className="h-4 w-4 fill-yellow-400 text-yellow-400"
                      />
                    ))}
                  </div>
                  <Button variant="ghost" size="sm">
                    View
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
