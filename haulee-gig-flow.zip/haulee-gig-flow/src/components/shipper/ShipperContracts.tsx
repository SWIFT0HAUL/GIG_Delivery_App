import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { FileText, Download, Eye, Plus, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

export const ShipperContracts = () => {
  const contracts = [
    {
      id: 'CNT-2025-001',
      carrier: 'Express Logistics',
      type: 'Annual Agreement',
      startDate: '2025-01-01',
      endDate: '2025-12-31',
      status: 'active',
      value: 125000,
      routes: ['CA-NY', 'TX-FL', 'IL-WA'],
    },
    {
      id: 'CNT-2024-042',
      carrier: 'Swift Transport',
      type: 'Volume Commitment',
      startDate: '2024-06-01',
      endDate: '2025-05-31',
      status: 'active',
      value: 85000,
      routes: ['All US'],
    },
    {
      id: 'CNT-2025-003',
      carrier: 'Prime Freight',
      type: 'Spot Agreement',
      startDate: '2025-01-15',
      endDate: '2025-02-15',
      status: 'pending_signature',
      value: 15000,
      routes: ['NY-CA'],
    },
    {
      id: 'CNT-2024-038',
      carrier: 'Budget Carriers',
      type: 'Annual Agreement',
      startDate: '2024-03-01',
      endDate: '2025-02-28',
      status: 'expiring_soon',
      value: 95000,
      routes: ['Regional'],
    },
  ];

  const terms = [
    { label: 'Payment Terms', value: 'Net 30' },
    { label: 'Rate Lock', value: '6 months' },
    { label: 'Fuel Surcharge', value: 'DOE Index +2%' },
    { label: 'Insurance Required', value: '$1M Cargo, $1M Liability' },
    { label: 'Claims Period', value: '9 months from delivery' },
    { label: 'Force Majeure', value: 'Standard clause applies' },
  ];

  const getStatusBadge = (status: string) => {
    const config: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: any }> = {
      active: { variant: 'default', icon: CheckCircle },
      pending_signature: { variant: 'secondary', icon: Clock },
      expiring_soon: { variant: 'destructive', icon: AlertTriangle },
    };
    
    const { variant, icon: Icon } = config[status] || { variant: 'outline', icon: FileText };
    
    return (
      <Badge variant={variant} className="gap-1">
        <Icon className="h-3 w-3" />
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Contracts & Terms</CardTitle>
              <CardDescription>Manage carrier contracts and agreements</CardDescription>
            </div>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Contract
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All Contracts</TabsTrigger>
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="expiring">Expiring Soon</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4 mt-6">
              {contracts.map((contract) => (
                <Card key={contract.id}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row justify-between gap-4">
                      <div className="space-y-3 flex-1">
                        <div className="flex items-center gap-3">
                          <FileText className="h-5 w-5 text-muted-foreground" />
                          <div>
                            <h3 className="font-semibold">{contract.carrier}</h3>
                            <p className="text-sm text-muted-foreground">{contract.id}</p>
                          </div>
                          {getStatusBadge(contract.status)}
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <div className="text-muted-foreground">Type</div>
                            <div className="font-medium">{contract.type}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Start Date</div>
                            <div className="font-medium">
                              {format(new Date(contract.startDate), 'MMM dd, yyyy')}
                            </div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">End Date</div>
                            <div className="font-medium">
                              {format(new Date(contract.endDate), 'MMM dd, yyyy')}
                            </div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Contract Value</div>
                            <div className="font-medium">
                              ${contract.value.toLocaleString()}
                            </div>
                          </div>
                        </div>

                        <div>
                          <div className="text-sm text-muted-foreground mb-2">Covered Routes</div>
                          <div className="flex flex-wrap gap-2">
                            {contract.routes.map((route) => (
                              <Badge key={route} variant="outline">
                                {route}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 md:w-32">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-2" />
                          Download
                        </Button>
                        {contract.status === 'pending_signature' && (
                          <Button size="sm">Sign</Button>
                        )}
                        {contract.status === 'expiring_soon' && (
                          <Button size="sm">Renew</Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="active" className="space-y-4 mt-6">
              {contracts.filter(c => c.status === 'active').map((contract) => (
                <Card key={contract.id}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{contract.carrier}</h3>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(contract.startDate), 'MMM dd, yyyy')} - {format(new Date(contract.endDate), 'MMM dd, yyyy')}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">${contract.value.toLocaleString()}</div>
                        <Button variant="outline" size="sm" className="mt-2">
                          View Details
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="pending" className="space-y-4 mt-6">
              {contracts.filter(c => c.status === 'pending_signature').map((contract) => (
                <Card key={contract.id}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{contract.carrier}</h3>
                        <p className="text-sm text-muted-foreground">{contract.type}</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">Review</Button>
                        <Button size="sm">Sign Now</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="expiring" className="space-y-4 mt-6">
              {contracts.filter(c => c.status === 'expiring_soon').map((contract) => (
                <Card key={contract.id} className="border-destructive">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <div className="flex items-center gap-2">
                          <AlertTriangle className="h-5 w-5 text-destructive" />
                          <h3 className="font-semibold">{contract.carrier}</h3>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Expires: {format(new Date(contract.endDate), 'MMM dd, yyyy')}
                        </p>
                      </div>
                      <Button size="sm">Renew Contract</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Standard Terms & Conditions</CardTitle>
          <CardDescription>Default terms applied to all new contracts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {terms.map((term, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="text-sm font-medium text-muted-foreground mb-1">
                  {term.label}
                </div>
                <div className="font-semibold">{term.value}</div>
              </div>
            ))}
          </div>
          <Button variant="outline" className="mt-4">
            Edit Standard Terms
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
