import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, FileText, DollarSign, Download, Plus, Edit } from 'lucide-react';

export function ShipperPayments() {
  const quotes = [
    {
      id: 'Q001',
      shipmentId: 'SH1240',
      carrier: 'Prime Logistics',
      route: 'San Francisco, CA → Portland, OR',
      service: 'Standard LTL',
      amount: '$1,200',
      validUntil: '2024-01-30',
      status: 'Pending',
      details: 'Office furniture shipment'
    },
    {
      id: 'Q002',
      shipmentId: 'SH1241',
      carrier: 'Express Freight',
      route: 'Boston, MA → Atlanta, GA',
      service: 'Temperature Controlled',
      amount: '$3,500',
      validUntil: '2024-02-01',
      status: 'Approved',
      details: 'Medical equipment'
    },
    {
      id: 'Q003',
      shipmentId: 'SH1242',
      carrier: 'Swift Transport',
      route: 'Miami, FL → Chicago, IL',
      service: 'Expedited FTL',
      amount: '$2,850',
      validUntil: '2024-01-28',
      status: 'Expired',
      details: 'Industrial machinery'
    }
  ];

  const paymentMethods = [
    {
      id: 'pm1',
      type: 'Credit Card',
      last4: '4242',
      brand: 'Visa',
      expiry: '12/26',
      isDefault: true,
      name: 'Business Card'
    },
    {
      id: 'pm2',
      type: 'Bank Account',
      last4: '5678',
      bank: 'First National Bank',
      accountType: 'Checking',
      isDefault: false,
      name: 'Business Checking'
    },
    {
      id: 'pm3',
      type: 'Credit Card',
      last4: '9876',
      brand: 'Mastercard',
      expiry: '08/25',
      isDefault: false,
      name: 'Backup Card'
    }
  ];

  const invoices = [
    {
      id: 'INV-2024-001',
      shipmentId: 'SH1234',
      carrier: 'Prime Logistics',
      amount: '$2,450',
      issueDate: '2024-01-20',
      dueDate: '2024-02-19',
      status: 'Paid',
      paidDate: '2024-01-22'
    },
    {
      id: 'INV-2024-002',
      shipmentId: 'SH1235',
      carrier: 'Express Freight',
      amount: '$4,200',
      issueDate: '2024-01-21',
      dueDate: '2024-02-20',
      status: 'Due',
      paidDate: null
    },
    {
      id: 'INV-2024-003',
      shipmentId: 'SH1230',
      carrier: 'Reliable Freight',
      amount: '$1,950',
      issueDate: '2024-01-18',
      dueDate: '2024-02-17',
      status: 'Paid',
      paidDate: '2024-01-19'
    },
    {
      id: 'INV-2024-004',
      shipmentId: 'SH1229',
      carrier: 'Mountain Express',
      amount: '$2,800',
      issueDate: '2024-01-14',
      dueDate: '2024-02-13',
      status: 'Overdue',
      paidDate: null
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Pending': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Approved': return 'bg-green-100 text-green-800 border-green-200';
      case 'Expired': return 'bg-red-100 text-red-800 border-red-200';
      case 'Paid': return 'bg-green-100 text-green-800 border-green-200';
      case 'Due': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Overdue': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPaymentMethodIcon = (type: string) => {
    return <CreditCard className="h-4 w-4" />;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Payments & Billing</CardTitle>
        <CardDescription>Manage quotes, payment methods, and invoices</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="quotes" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="quotes">Quotes</TabsTrigger>
            <TabsTrigger value="payment-methods">Payment Methods</TabsTrigger>
            <TabsTrigger value="invoices">Invoices & History</TabsTrigger>
          </TabsList>

          <TabsContent value="quotes" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Shipping Quotes ({quotes.length})</h3>
              <Button>Request New Quote</Button>
            </div>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Quote ID</TableHead>
                  <TableHead>Shipment</TableHead>
                  <TableHead>Carrier</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Service</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Valid Until</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {quotes.map((quote) => (
                  <TableRow key={quote.id}>
                    <TableCell className="font-medium">{quote.id}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">#{quote.shipmentId}</div>
                        <div className="text-sm text-muted-foreground">{quote.details}</div>
                      </div>
                    </TableCell>
                    <TableCell>{quote.carrier}</TableCell>
                    <TableCell className="text-sm">{quote.route}</TableCell>
                    <TableCell>{quote.service}</TableCell>
                    <TableCell className="font-semibold">{quote.amount}</TableCell>
                    <TableCell>{quote.validUntil}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(quote.status)}>
                        {quote.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        {quote.status === 'Pending' && (
                          <>
                            <Button size="sm">Accept</Button>
                            <Button size="sm" variant="outline">Decline</Button>
                          </>
                        )}
                        {quote.status === 'Approved' && (
                          <Button size="sm">Book Now</Button>
                        )}
                        <Button size="sm" variant="outline">View</Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          <TabsContent value="payment-methods" className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Payment Methods</h3>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Payment Method
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {paymentMethods.map((method) => (
                <Card key={method.id} className={method.isDefault ? 'ring-2 ring-primary' : ''}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        {getPaymentMethodIcon(method.type)}
                        <span className="font-medium">{method.type}</span>
                      </div>
                      {method.isDefault && (
                        <Badge variant="default">Default</Badge>
                      )}
                    </div>
                    <div className="space-y-1">
                      <div className="font-medium">{method.name}</div>
                      {method.type === 'Credit Card' ? (
                        <>
                          <div className="text-sm text-muted-foreground">
                            {method.brand} •••• {method.last4}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Expires {method.expiry}
                          </div>
                        </>
                      ) : (
                        <>
                          <div className="text-sm text-muted-foreground">
                            {method.bank} •••• {method.last4}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {method.accountType} Account
                          </div>
                        </>
                      )}
                    </div>
                    <div className="flex space-x-2 mt-4">
                      <Button size="sm" variant="outline">
                        <Edit className="h-3 w-3 mr-1" />
                        Edit
                      </Button>
                      {!method.isDefault && (
                        <Button size="sm" variant="outline">
                          Set Default
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Add New Payment Method Form */}
            <Card>
              <CardHeader>
                <CardTitle>Add New Payment Method</CardTitle>
                <CardDescription>Add a credit card or bank account for payments</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="method-type">Payment Type</Label>
                    <select className="w-full p-2 border border-input rounded-md">
                      <option>Credit Card</option>
                      <option>Bank Account (ACH)</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="method-name">Name for this method</Label>
                    <Input id="method-name" placeholder="e.g., Business Card" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="card-number">Card Number</Label>
                    <Input id="card-number" placeholder="1234 5678 9012 3456" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="card-name">Cardholder Name</Label>
                    <Input id="card-name" placeholder="John Smith" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="expiry">Expiry Date</Label>
                    <Input id="expiry" placeholder="MM/YY" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cvv">CVV</Label>
                    <Input id="cvv" placeholder="123" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="zip">ZIP Code</Label>
                    <Input id="zip" placeholder="12345" />
                  </div>
                </div>
                <Button>Add Payment Method</Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="invoices" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold">Invoices & Payment History</h3>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export All
              </Button>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Spent (MTD)</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$11,400</div>
                  <p className="text-xs text-muted-foreground">-8% from last month</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Outstanding</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$7,000</div>
                  <p className="text-xs text-muted-foreground">2 invoices due</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Overdue</CardTitle>
                  <FileText className="h-4 w-4 text-red-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">$2,800</div>
                  <p className="text-xs text-muted-foreground">1 invoice overdue</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg Cost/Shipment</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$2,850</div>
                  <p className="text-xs text-muted-foreground">Based on last 10</p>
                </CardContent>
              </Card>
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice ID</TableHead>
                  <TableHead>Shipment</TableHead>
                  <TableHead>Carrier</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Issue Date</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {invoices.map((invoice) => (
                  <TableRow key={invoice.id}>
                    <TableCell className="font-medium">{invoice.id}</TableCell>
                    <TableCell>#{invoice.shipmentId}</TableCell>
                    <TableCell>{invoice.carrier}</TableCell>
                    <TableCell className="font-semibold">{invoice.amount}</TableCell>
                    <TableCell>{invoice.issueDate}</TableCell>
                    <TableCell>{invoice.dueDate}</TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(invoice.status)}>
                        {invoice.status}
                      </Badge>
                      {invoice.paidDate && (
                        <div className="text-xs text-muted-foreground mt-1">
                          Paid: {invoice.paidDate}
                        </div>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          <FileText className="h-3 w-3 mr-1" />
                          View
                        </Button>
                        <Button size="sm" variant="outline">
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                        {(invoice.status === 'Due' || invoice.status === 'Overdue') && (
                          <Button size="sm">Pay Now</Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}