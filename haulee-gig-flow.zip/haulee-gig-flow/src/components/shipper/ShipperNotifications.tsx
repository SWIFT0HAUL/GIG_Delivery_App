import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Settings, CheckCheck } from 'lucide-react';
import { useNotifications } from '@/hooks/useNotifications';
import { NotificationCard } from '@/components/notifications/NotificationCard';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export function ShipperNotifications() {
  const navigate = useNavigate();
  const { notifications, loading, unreadCount, markAsRead, markAllAsRead } = useNotifications();
  const [savingPreferences, setSavingPreferences] = useState(false);

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      toast.success('Notification deleted');
    } catch (error) {
      console.error('Error deleting notification:', error);
      toast.error('Failed to delete notification');
    }
  };

  const handleSavePreferences = async () => {
    setSavingPreferences(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setSavingPreferences(false);
    toast.success('Notification preferences saved');
  };

  const recentNotifications = notifications.slice(0, 5);

  const notificationSettings = [
    { id: 'shipment_updates', label: 'Shipment Updates', description: 'Pickup, delivery, and tracking updates', enabled: true },
    { id: 'quote_notifications', label: 'Quote Notifications', description: 'New quotes and pricing updates', enabled: true },
    { id: 'payment_reminders', label: 'Payment Reminders', description: 'Invoice due dates and payment confirmations', enabled: true },
    { id: 'carrier_communications', label: 'Carrier Communications', description: 'Messages and updates from carriers and drivers', enabled: true },
    { id: 'schedule_reminders', label: 'Schedule Reminders', description: 'Upcoming pickups and delivery appointments', enabled: true },
    { id: 'system_alerts', label: 'System Alerts', description: 'Platform updates and maintenance notifications', enabled: false }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Notifications</h2>
          <p className="text-muted-foreground">Stay updated with your shipments and business activities</p>
        </div>
        <Badge variant="secondary" className="text-lg px-4 py-2">
          {unreadCount} Unread
        </Badge>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Recent Notifications</CardTitle>
                <CardDescription>Your latest shipment and business updates</CardDescription>
              </div>
              {unreadCount > 0 && (
                <Button variant="outline" size="sm" onClick={markAllAsRead}>
                  <CheckCheck className="h-4 w-4 mr-2" />
                  Mark All Read
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full" />
              </div>
            ) : recentNotifications.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No notifications yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentNotifications.map((notification) => (
                  <NotificationCard
                    key={notification.id}
                    notification={notification}
                    onMarkRead={markAsRead}
                    onDelete={handleDelete}
                  />
                ))}
              </div>
            )}

            <div className="pt-4">
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => navigate('/notifications')}
              >
                View All Notifications
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Notification Settings
            </CardTitle>
            <CardDescription>Customize your notification preferences</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {notificationSettings.map((setting) => (
                <div key={setting.id} className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="text-sm font-medium">{setting.label}</h4>
                    <p className="text-sm text-muted-foreground">{setting.description}</p>
                  </div>
                  <Switch checked={setting.enabled} />
                </div>
              ))}

              <div className="mt-8 pt-6 border-t">
                <h4 className="text-sm font-medium mb-4">Delivery Methods</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium">Email Notifications</span>
                      <p className="text-sm text-muted-foreground">Receive notifications via email</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium">Push Notifications</span>
                      <p className="text-sm text-muted-foreground">Browser push notifications</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium">SMS Alerts</span>
                      <p className="text-sm text-muted-foreground">Critical notifications via SMS</p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-6 border-t">
                <h4 className="text-sm font-medium mb-4">Notification Timing</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium">Business Hours Only</span>
                      <p className="text-sm text-muted-foreground">Only receive notifications during 8 AM - 6 PM</p>
                    </div>
                    <Switch />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-sm font-medium">Daily Summary</span>
                      <p className="text-sm text-muted-foreground">Receive a daily summary email at 6 PM</p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                </div>
              </div>

              <Button 
                className="w-full mt-6" 
                onClick={handleSavePreferences}
                disabled={savingPreferences}
              >
                {savingPreferences ? 'Saving...' : 'Save Preferences'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
