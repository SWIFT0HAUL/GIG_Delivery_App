import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { MessageSquare, Send, Search, Paperclip } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const ShipperMessages = () => {
  const { toast } = useToast();
  const [selectedThread, setSelectedThread] = useState(1);
  const [message, setMessage] = useState('');

  const threads = [
    {
      id: 1,
      name: 'Express Logistics',
      lastMessage: 'Your shipment SH1240 has been picked up',
      time: '10:30 AM',
      unread: 2,
      online: true,
    },
    {
      id: 2,
      name: 'Swift Transport',
      lastMessage: 'Rate quote for LA-NYC route attached',
      time: '9:15 AM',
      unread: 0,
      online: false,
    },
    {
      id: 3,
      name: 'Support Team',
      lastMessage: 'We\'ve resolved your billing inquiry',
      time: 'Yesterday',
      unread: 1,
      online: true,
    },
    {
      id: 4,
      name: 'Prime Freight',
      lastMessage: 'Delivery confirmed for SH1236',
      time: 'Feb 2',
      unread: 0,
      online: false,
    },
  ];

  const messages = [
    {
      id: 1,
      sender: 'Express Logistics',
      message: 'Hello! Your shipment SH1240 has been picked up from Los Angeles warehouse.',
      time: '10:30 AM',
      isOwn: false,
    },
    {
      id: 2,
      sender: 'You',
      message: 'Great! What\'s the estimated delivery time?',
      time: '10:32 AM',
      isOwn: true,
    },
    {
      id: 3,
      sender: 'Express Logistics',
      message: 'Expected delivery is Thursday, Feb 6th by 3 PM. We\'ll send real-time updates.',
      time: '10:33 AM',
      isOwn: false,
    },
    {
      id: 4,
      sender: 'You',
      message: 'Perfect, thank you!',
      time: '10:35 AM',
      isOwn: true,
    },
  ];

  const sendMessage = () => {
    if (!message.trim()) return;
    
    toast({
      title: 'Message Sent',
      description: 'Your message has been delivered.',
    });
    setMessage('');
  };

  return (
    <div className="space-y-6">
      <Card className="h-[calc(100vh-12rem)]">
        <CardHeader>
          <CardTitle>Messages & Communication</CardTitle>
          <CardDescription>Chat with carriers, support, and partners</CardDescription>
        </CardHeader>
        <CardContent className="h-[calc(100%-5rem)]">
          <div className="flex gap-4 h-full">
            {/* Threads List */}
            <div className="w-80 border-r pr-4 space-y-2">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search messages..."
                  className="pl-10"
                />
              </div>
              <ScrollArea className="h-[calc(100%-3rem)]">
                {threads.map((thread) => (
                  <button
                    key={thread.id}
                    onClick={() => setSelectedThread(thread.id)}
                    className={`w-full text-left p-3 rounded-lg mb-2 transition-colors ${
                      selectedThread === thread.id
                        ? 'bg-primary/10 border border-primary'
                        : 'hover:bg-muted'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="relative">
                        <Avatar>
                          <AvatarFallback>{thread.name[0]}</AvatarFallback>
                        </Avatar>
                        {thread.online && (
                          <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-background" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-1">
                          <div className="font-semibold truncate">{thread.name}</div>
                          <div className="text-xs text-muted-foreground">{thread.time}</div>
                        </div>
                        <div className="flex justify-between items-center">
                          <div className="text-sm text-muted-foreground truncate">
                            {thread.lastMessage}
                          </div>
                          {thread.unread > 0 && (
                            <Badge variant="default" className="ml-2">
                              {thread.unread}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </ScrollArea>
            </div>

            {/* Chat Area */}
            <div className="flex-1 flex flex-col">
              {/* Chat Header */}
              <div className="flex items-center justify-between pb-4 border-b">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>
                      {threads.find(t => t.id === selectedThread)?.name[0]}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">
                      {threads.find(t => t.id === selectedThread)?.name}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {threads.find(t => t.id === selectedThread)?.online ? 'Online' : 'Offline'}
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm">View Profile</Button>
              </div>

              {/* Messages */}
              <ScrollArea className="flex-1 py-4">
                <div className="space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${msg.isOwn ? 'justify-end' : 'justify-start'}`}
                    >
                      <div className={`max-w-md ${msg.isOwn ? 'order-2' : 'order-1'}`}>
                        <div
                          className={`rounded-lg p-3 ${
                            msg.isOwn
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <div className="text-sm">{msg.message}</div>
                        </div>
                        <div className={`text-xs text-muted-foreground mt-1 ${
                          msg.isOwn ? 'text-right' : 'text-left'
                        }`}>
                          {msg.time}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="border-t pt-4">
                <div className="flex gap-2">
                  <Button variant="outline" size="icon">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Type your message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    className="flex-1"
                  />
                  <Button onClick={sendMessage}>
                    <Send className="h-4 w-4 mr-2" />
                    Send
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
