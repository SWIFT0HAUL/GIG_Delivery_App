import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Star, Search, CheckCircle, TrendingUp, Award, Truck } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const ShipperCarriers = () => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const carriers = [
    {
      id: 1,
      name: 'Express Logistics',
      rating: 4.8,
      completedJobs: 1247,
      onTimeRate: 97.5,
      specialties: ['FTL', 'Expedited', 'Reefer'],
      verified: true,
      preferred: true,
      responseTime: '< 2 hours',
      insurance: '$1M',
    },
    {
      id: 2,
      name: 'Swift Transport',
      rating: 4.6,
      completedJobs: 892,
      onTimeRate: 95.2,
      specialties: ['LTL', 'Dry Van'],
      verified: true,
      preferred: false,
      responseTime: '< 4 hours',
      insurance: '$500K',
    },
    {
      id: 3,
      name: 'Prime Freight',
      rating: 4.9,
      completedJobs: 1543,
      onTimeRate: 98.1,
      specialties: ['FTL', 'Flatbed', 'Oversized'],
      verified: true,
      preferred: true,
      responseTime: '< 1 hour',
      insurance: '$2M',
    },
    {
      id: 4,
      name: 'Rapid Delivery',
      rating: 4.5,
      completedJobs: 634,
      onTimeRate: 93.8,
      specialties: ['Expedited', 'Same-Day'],
      verified: true,
      preferred: false,
      responseTime: '< 3 hours',
      insurance: '$750K',
    },
  ];

  const inviteCarrier = (carrierName: string) => {
    toast({
      title: 'Invitation Sent',
      description: `Invitation sent to ${carrierName}. They'll be added to your preferred carriers once accepted.`,
    });
  };

  const removeCarrier = (carrierName: string) => {
    toast({
      title: 'Carrier Removed',
      description: `${carrierName} has been removed from your preferred carriers.`,
      variant: 'destructive',
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Carrier Management</CardTitle>
          <CardDescription>Find, manage, and work with trusted carriers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="relative mb-6">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search carriers by name, specialty, or service area..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <Tabs defaultValue="all">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">All Carriers</TabsTrigger>
              <TabsTrigger value="preferred">Preferred</TabsTrigger>
              <TabsTrigger value="verified">Verified</TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="space-y-4 mt-6">
              {carriers.map((carrier) => (
                <Card key={carrier.id}>
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarFallback>
                          <Truck className="h-8 w-8" />
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1 space-y-3">
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-semibold text-lg">{carrier.name}</h3>
                          {carrier.verified && (
                            <Badge variant="secondary" className="gap-1">
                              <CheckCircle className="h-3 w-3" />
                              Verified
                            </Badge>
                          )}
                          {carrier.preferred && (
                            <Badge variant="default" className="gap-1">
                              <Award className="h-3 w-3" />
                              Preferred
                            </Badge>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-4 text-sm">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                            <span className="font-medium">{carrier.rating}</span>
                          </div>
                          <div className="text-muted-foreground">
                            {carrier.completedJobs} completed jobs
                          </div>
                          <div className="flex items-center gap-1">
                            <TrendingUp className="h-4 w-4 text-green-500" />
                            <span>{carrier.onTimeRate}% on-time</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2">
                          {carrier.specialties.map((specialty) => (
                            <Badge key={specialty} variant="outline">
                              {specialty}
                            </Badge>
                          ))}
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm pt-2 border-t">
                          <div>
                            <div className="text-muted-foreground">Response Time</div>
                            <div className="font-medium">{carrier.responseTime}</div>
                          </div>
                          <div>
                            <div className="text-muted-foreground">Insurance</div>
                            <div className="font-medium">{carrier.insurance}</div>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col gap-2 md:w-32">
                        {carrier.preferred ? (
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => removeCarrier(carrier.name)}
                          >
                            Remove
                          </Button>
                        ) : (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => inviteCarrier(carrier.name)}
                          >
                            Add to Preferred
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          View Profile
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="preferred" className="space-y-4 mt-6">
              {carriers.filter(c => c.preferred).map((carrier) => (
                <Card key={carrier.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback>
                            <Truck className="h-6 w-6" />
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold">{carrier.name}</h3>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            {carrier.rating} • {carrier.completedJobs} jobs
                          </div>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">View Details</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>

            <TabsContent value="verified" className="space-y-4 mt-6">
              {carriers.filter(c => c.verified).map((carrier) => (
                <Card key={carrier.id}>
                  <CardContent className="pt-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback>
                            <Truck className="h-6 w-6" />
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-semibold">{carrier.name}</h3>
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Insurance: {carrier.insurance}
                          </div>
                        </div>
                      </div>
                      <Button variant="outline" size="sm">View Details</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};
