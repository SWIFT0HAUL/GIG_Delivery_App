import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';

interface ShipperEditJobDialogProps {
  job: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onJobUpdated?: () => void;
}

export function ShipperEditJobDialog({ job, open, onOpenChange, onJobUpdated }: ShipperEditJobDialogProps) {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    pay_amount: '',
    equipment_type: '',
    pickup_time: '',
    delivery_time: '',
    special_instructions: '',
    cargo_weight: '',
    pickup_contact_name: '',
    pickup_contact_phone: '',
    delivery_contact_name: '',
    delivery_contact_phone: '',
  });

  useEffect(() => {
    if (job) {
      setFormData({
        title: job.title || '',
        pay_amount: job.pay_amount || '',
        equipment_type: job.equipment_type || '',
        pickup_time: job.pickup_time ? new Date(job.pickup_time).toISOString().slice(0, 16) : '',
        delivery_time: job.delivery_time ? new Date(job.delivery_time).toISOString().slice(0, 16) : '',
        special_instructions: job.special_instructions || '',
        cargo_weight: job.cargo_weight || '',
        pickup_contact_name: job.pickup_contact_name || '',
        pickup_contact_phone: job.pickup_contact_phone || '',
        delivery_contact_name: job.delivery_contact_name || '',
        delivery_contact_phone: job.delivery_contact_phone || '',
      });
    }
  }, [job]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const updateData: any = {
        title: formData.title,
        pay_amount: formData.pay_amount ? parseFloat(formData.pay_amount) : null,
        equipment_type: formData.equipment_type,
        pickup_time: formData.pickup_time || null,
        delivery_time: formData.delivery_time || null,
        special_instructions: formData.special_instructions,
        cargo_weight: formData.cargo_weight ? parseFloat(formData.cargo_weight) : null,
        pickup_contact_name: formData.pickup_contact_name,
        pickup_contact_phone: formData.pickup_contact_phone,
        delivery_contact_name: formData.delivery_contact_name,
        delivery_contact_phone: formData.delivery_contact_phone,
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from('jobs')
        .update(updateData)
        .eq('id', job.id);

      if (error) throw error;

      toast.success('Job updated successfully');
      onOpenChange(false);
      if (onJobUpdated) {
        onJobUpdated();
      }
    } catch (error: any) {
      console.error('Error updating job:', error);
      toast.error(error.message || 'Failed to update job');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!job) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Job</DialogTitle>
          <DialogDescription>
            Update the job details below. Changes will be saved immediately.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <Label htmlFor="title">Job Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Enter job title"
                required
              />
            </div>

            <div>
              <Label htmlFor="pay_amount">Pay Amount ($)</Label>
              <Input
                id="pay_amount"
                type="number"
                step="0.01"
                value={formData.pay_amount}
                onChange={(e) => setFormData({ ...formData, pay_amount: e.target.value })}
                placeholder="0.00"
              />
            </div>

            <div>
              <Label htmlFor="equipment_type">Equipment Type</Label>
              <Select
                value={formData.equipment_type}
                onValueChange={(value) => setFormData({ ...formData, equipment_type: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select equipment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dry_van">Dry Van</SelectItem>
                  <SelectItem value="flatbed">Flatbed</SelectItem>
                  <SelectItem value="reefer">Reefer</SelectItem>
                  <SelectItem value="box_truck">Box Truck</SelectItem>
                  <SelectItem value="step_deck">Step Deck</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="pickup_time">Pickup Time</Label>
              <Input
                id="pickup_time"
                type="datetime-local"
                value={formData.pickup_time}
                onChange={(e) => setFormData({ ...formData, pickup_time: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="delivery_time">Delivery Time</Label>
              <Input
                id="delivery_time"
                type="datetime-local"
                value={formData.delivery_time}
                onChange={(e) => setFormData({ ...formData, delivery_time: e.target.value })}
              />
            </div>

            <div>
              <Label htmlFor="cargo_weight">Cargo Weight (lbs)</Label>
              <Input
                id="cargo_weight"
                type="number"
                step="0.01"
                value={formData.cargo_weight}
                onChange={(e) => setFormData({ ...formData, cargo_weight: e.target.value })}
                placeholder="0"
              />
            </div>

            <div>
              <Label htmlFor="pickup_contact_name">Pickup Contact Name</Label>
              <Input
                id="pickup_contact_name"
                value={formData.pickup_contact_name}
                onChange={(e) => setFormData({ ...formData, pickup_contact_name: e.target.value })}
                placeholder="Contact name"
              />
            </div>

            <div>
              <Label htmlFor="pickup_contact_phone">Pickup Contact Phone</Label>
              <Input
                id="pickup_contact_phone"
                type="tel"
                value={formData.pickup_contact_phone}
                onChange={(e) => setFormData({ ...formData, pickup_contact_phone: e.target.value })}
                placeholder="Phone number"
              />
            </div>

            <div>
              <Label htmlFor="delivery_contact_name">Delivery Contact Name</Label>
              <Input
                id="delivery_contact_name"
                value={formData.delivery_contact_name}
                onChange={(e) => setFormData({ ...formData, delivery_contact_name: e.target.value })}
                placeholder="Contact name"
              />
            </div>

            <div>
              <Label htmlFor="delivery_contact_phone">Delivery Contact Phone</Label>
              <Input
                id="delivery_contact_phone"
                type="tel"
                value={formData.delivery_contact_phone}
                onChange={(e) => setFormData({ ...formData, delivery_contact_phone: e.target.value })}
                placeholder="Phone number"
              />
            </div>

            <div className="col-span-2">
              <Label htmlFor="special_instructions">Special Instructions</Label>
              <Textarea
                id="special_instructions"
                value={formData.special_instructions}
                onChange={(e) => setFormData({ ...formData, special_instructions: e.target.value })}
                placeholder="Enter any special instructions or notes"
                rows={3}
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
