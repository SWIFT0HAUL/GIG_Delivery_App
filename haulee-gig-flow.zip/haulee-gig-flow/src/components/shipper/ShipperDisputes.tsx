import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertTriangle, FileText, MessageSquare, CheckCircle, Clock, Upload } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { z } from 'zod';

const disputeSchema = z.object({
  job_id: z.string().trim().min(8, 'Job ID must be at least 8 characters').max(100),
  dispute_type: z.string().min(1, 'Dispute type is required'),
  description: z.string().trim().min(10, 'Description must be at least 10 characters').max(2000, 'Description is too long'),
});

export const ShipperDisputes = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [isOpen, setIsOpen] = useState(false);
  const [formData, setFormData] = useState({
    job_id: '',
    dispute_type: '',
    description: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Fetch disputes
  const { data: disputes = [], refetch } = useQuery({
    queryKey: ['shipper-disputes', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      
      const { data, error } = await supabase
        .from('disputes')
        .select(`
          *,
          job:jobs(id, title, pickup_location, delivery_location)
        `)
        .eq('reporter_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
    enabled: !!user?.id,
  });

  // Create dispute mutation
  const createDisputeMutation = useMutation({
    mutationFn: async (data: z.infer<typeof disputeSchema>) => {
      if (!user?.id) throw new Error('Not authenticated');

      // Find job by partial UUID (first 8 characters)
      const { data: jobs, error: jobError } = await supabase
        .from('jobs')
        .select('id')
        .filter('id::text', 'ilike', `${data.job_id}%`)
        .limit(1);

      if (jobError) throw jobError;
      if (!jobs || jobs.length === 0) {
        throw new Error('Job not found with that ID');
      }

      const fullJobId = jobs[0].id;

      const { data: dispute, error } = await supabase
        .from('disputes')
        .insert({
          reporter_id: user.id,
          job_id: fullJobId,
          dispute_type: data.dispute_type,
          description: data.description,
          status: 'open',
          priority: 'medium',
        })
        .select()
        .single();

      if (error) throw error;
      return dispute;
    },
    onSuccess: () => {
      toast({ title: 'Dispute Filed', description: 'Your dispute has been submitted successfully.' });
      queryClient.invalidateQueries({ queryKey: ['shipper-disputes'] });
      setIsOpen(false);
      setFormData({ job_id: '', dispute_type: '', description: '' });
      setErrors({});
    },
    onError: (error) => {
      toast({ title: 'Error', description: error.message || 'Failed to file dispute', variant: 'destructive' });
      console.error('Dispute creation error:', error);
    },
  });

  const handleSubmit = () => {
    try {
      const validated = disputeSchema.parse(formData);
      setErrors({});
      createDisputeMutation.mutate(validated);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const fieldErrors: Record<string, string> = {};
        error.errors.forEach((err) => {
          if (err.path[0]) fieldErrors[err.path[0] as string] = err.message;
        });
        setErrors(fieldErrors);
      }
    }
  };

  const getStatusBadge = (status: string) => {
    const config: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: any }> = {
      under_review: { variant: 'secondary', icon: Clock },
      pending_docs: { variant: 'outline', icon: FileText },
      resolved: { variant: 'default', icon: CheckCircle },
    };
    
    const { variant, icon: Icon } = config[status] || { variant: 'outline', icon: AlertTriangle };
    
    return (
      <Badge variant={variant} className="gap-1">
        <Icon className="h-3 w-3" />
        {status.replace('_', ' ')}
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Claims & Disputes</CardTitle>
              <CardDescription>Manage cargo claims and service disputes</CardDescription>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button>
                  <AlertTriangle className="h-4 w-4 mr-2" />
                  File New Claim
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>File New Claim or Dispute</DialogTitle>
                  <DialogDescription>
                    Provide details about your claim. Our team will review within 2 business days.
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Job ID</Label>
                    <Input 
                      placeholder="Enter first 8 characters (e.g., c1966689)" 
                      value={formData.job_id}
                      onChange={(e) => setFormData({ ...formData, job_id: e.target.value })}
                      maxLength={36}
                    />
                    {errors.job_id && <p className="text-sm text-destructive">{errors.job_id}</p>}
                    <p className="text-xs text-muted-foreground">
                      You can enter just the first 8 characters
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label>Dispute Type</Label>
                    <Select value={formData.dispute_type} onValueChange={(value) => setFormData({ ...formData, dispute_type: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select dispute type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="payment">Payment Issue</SelectItem>
                        <SelectItem value="damage">Cargo Damage</SelectItem>
                        <SelectItem value="missing">Missing Items</SelectItem>
                        <SelectItem value="late">Late Delivery</SelectItem>
                        <SelectItem value="service">Service Issue</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    {errors.dispute_type && <p className="text-sm text-destructive">{errors.dispute_type}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label>Description</Label>
                    <Textarea
                      placeholder="Provide detailed description of the issue (min 10 characters)..."
                      rows={4}
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      maxLength={2000}
                    />
                    {errors.description && <p className="text-sm text-destructive">{errors.description}</p>}
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={handleSubmit} disabled={createDisputeMutation.isPending}>
                      {createDisputeMutation.isPending ? 'Submitting...' : 'Submit Claim'}
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {disputes.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No disputes found. File a new claim if you have an issue.
            </div>
          ) : (
            disputes.map((dispute: any) => (
              <Card key={dispute.id}>
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-semibold">#{dispute.id.slice(0, 8)}</h3>
                          {getStatusBadge(dispute.status)}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          Job: {dispute.job?.title || 'N/A'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Type</div>
                        <div className="font-medium capitalize">{dispute.dispute_type}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Filed Date</div>
                        <div className="font-medium">
                          {new Date(dispute.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Priority</div>
                        <div className="font-medium capitalize">{dispute.priority}</div>
                      </div>
                    </div>

                    <div className="border-t pt-4">
                      <Label className="text-sm font-medium">Description</Label>
                      <p className="text-sm text-muted-foreground mt-1">
                        {dispute.description}
                      </p>
                    </div>

                    {dispute.resolution_notes && (
                      <div className="border-t pt-4 bg-muted/50 -mx-6 -mb-6 px-6 py-4 rounded-b-lg">
                        <Label className="text-sm font-medium flex items-center gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          Resolution
                        </Label>
                        <p className="text-sm mt-1">{dispute.resolution_notes}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Open Claims</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {disputes.filter((d: any) => d.status === 'open' || d.status === 'under_review').length}
            </div>
            <p className="text-sm text-muted-foreground mt-1">Active disputes</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Resolved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {disputes.filter((d: any) => d.status === 'resolved' || d.status === 'closed').length}
            </div>
            <p className="text-sm text-muted-foreground mt-1">All time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Total Claims</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{disputes.length}</div>
            <p className="text-sm text-muted-foreground mt-1">All disputes</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
