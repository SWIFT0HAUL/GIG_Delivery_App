import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, MapPin, Package, Calendar, Truck } from 'lucide-react';
import { toast } from 'sonner';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { VEHICLE_CATEGORIES } from '@/lib/vehicleConfig';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export function ShipperCreateJob() {
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [pickupAddress, setPickupAddress] = React.useState('');
  const [deliveryAddress, setDeliveryAddress] = React.useState('');
  const [calculatedDistance, setCalculatedDistance] = React.useState('');
  const [calculatedDuration, setCalculatedDuration] = React.useState('');
  const [selectedShipmentType, setSelectedShipmentType] = React.useState<'ltl' | 'ftl' | 'expedited'>('ltl');
  const [selectedVehicleType, setSelectedVehicleType] = React.useState('');
  const [selectedJobType, setSelectedJobType] = React.useState<'pickup_now' | 'scheduled' | 'route'>('scheduled');

  const handlePostJob = async () => {
    if (!user) {
      toast.error('You must be logged in to create a job');
      return;
    }

    if (!selectedVehicleType) {
      toast.error('Please select a vehicle type');
      return;
    }

    if (!pickupAddress || !deliveryAddress) {
      toast.error('Please enter both pickup and delivery addresses');
      return;
    }

    setIsSubmitting(true);

    try {
      const pickupDateInput = (document.getElementById('pickup-date') as HTMLInputElement)?.value;
      const deliveryDateInput = (document.getElementById('delivery-date') as HTMLInputElement)?.value;
      const jobTitle = (document.getElementById('cargo-description') as HTMLInputElement)?.value || 'New Shipment';
      const payAmount = (document.getElementById('cargo-value') as HTMLInputElement)?.value;

      const { error } = await supabase.from('jobs').insert({
        title: jobTitle,
        shipper_id: user.id,
        created_by: user.id,
        status: 'posted',
        priority: selectedJobType,
        equipment_type: selectedVehicleType,
        pickup_location: { address: pickupAddress },
        delivery_location: { address: deliveryAddress },
        pickup_time: pickupDateInput ? new Date(pickupDateInput).toISOString() : null,
        delivery_time: deliveryDateInput ? new Date(deliveryDateInput).toISOString() : null,
        distance_miles: calculatedDistance ? parseFloat(calculatedDistance) : null,
        estimated_duration: calculatedDuration ? parseInt(calculatedDuration) : null,
        pay_amount: payAmount ? parseFloat(payAmount) : null,
      });

      if (error) throw error;

      toast.success('Job posted successfully!');
      
      // Reset form
      setPickupAddress('');
      setDeliveryAddress('');
      setCalculatedDistance('');
      setCalculatedDuration('');
      setSelectedVehicleType('');
    } catch (error: any) {
      console.error('Error creating job:', error);
      toast.error(error.message || 'Failed to create job');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Auto-calculation disabled - users can manually enter distance and duration
  
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Plus className="h-5 w-5" />
            <span>Create New Shipment</span>
          </CardTitle>
          <CardDescription>Fill out the details for your new shipping request</CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          {/* Priority Selection */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Priority</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div 
                className={`p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                  selectedJobType === 'pickup_now' ? 'border-primary bg-primary/5' : ''
                }`}
                onClick={() => setSelectedJobType('pickup_now')}
              >
                <div className="flex items-center space-x-3">
                  <Truck className={`h-6 w-6 ${selectedJobType === 'pickup_now' ? 'text-primary' : ''}`} />
                  <div>
                    <div className="font-medium">Pick Up Now</div>
                    <div className="text-sm text-muted-foreground">Immediate pickup needed</div>
                  </div>
                </div>
              </div>
              <div 
                className={`p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                  selectedJobType === 'scheduled' ? 'border-primary bg-primary/5' : ''
                }`}
                onClick={() => setSelectedJobType('scheduled')}
              >
                <div className="flex items-center space-x-3">
                  <Calendar className={`h-6 w-6 ${selectedJobType === 'scheduled' ? 'text-primary' : ''}`} />
                  <div>
                    <div className="font-medium">Scheduled</div>
                    <div className="text-sm text-muted-foreground">Schedule for later</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Shipment Type */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Shipment Type</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div 
                className={`p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                  selectedShipmentType === 'ltl' ? 'border-primary bg-primary/5' : ''
                }`}
                onClick={() => setSelectedShipmentType('ltl')}
              >
                <div className="flex items-center space-x-3">
                  <Package className={`h-6 w-6 ${selectedShipmentType === 'ltl' ? 'text-primary' : ''}`} />
                  <div>
                    <div className="font-medium">LTL (Less Than Truckload)</div>
                    <div className="text-sm text-muted-foreground">Partial truck capacity</div>
                  </div>
                </div>
              </div>
              <div 
                className={`p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                  selectedShipmentType === 'ftl' ? 'border-primary bg-primary/5' : ''
                }`}
                onClick={() => setSelectedShipmentType('ftl')}
              >
                <div className="flex items-center space-x-3">
                  <Truck className={`h-6 w-6 ${selectedShipmentType === 'ftl' ? 'text-primary' : ''}`} />
                  <div>
                    <div className="font-medium">FTL (Full Truckload)</div>
                    <div className="text-sm text-muted-foreground">Entire truck capacity</div>
                  </div>
                </div>
              </div>
              <div 
                className={`p-4 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors ${
                  selectedShipmentType === 'expedited' ? 'border-primary bg-primary/5' : ''
                }`}
                onClick={() => setSelectedShipmentType('expedited')}
              >
                <div className="flex items-center space-x-3">
                  <MapPin className={`h-6 w-6 ${selectedShipmentType === 'expedited' ? 'text-primary' : ''}`} />
                  <div>
                    <div className="font-medium">Expedited</div>
                    <div className="text-sm text-muted-foreground">Priority shipping</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Pickup & Delivery Information */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-green-500" />
                  <span>Pickup Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="pickup-company">Company Name</Label>
                  <Input id="pickup-company" placeholder="e.g., ABC Manufacturing" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pickup-contact">Contact Person</Label>
                  <Input id="pickup-contact" placeholder="John Smith" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pickup-phone">Phone Number</Label>
                  <Input id="pickup-phone" placeholder="(555) 123-4567" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pickup-address">Address</Label>
                  <AddressAutocomplete
                    value={pickupAddress}
                    onAddressSelect={(address) => setPickupAddress(address.formatted_address)}
                    placeholder="Start typing pickup address..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="pickup-date">Pickup Date</Label>
                    <Input id="pickup-date" type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="pickup-time">Time Window</Label>
                    <select className="w-full p-2 border border-input rounded-md">
                      <option>8:00 AM - 12:00 PM</option>
                      <option>12:00 PM - 5:00 PM</option>
                      <option>Flexible</option>
                      <option>Appointment Required</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pickup-notes">Special Instructions</Label>
                  <Textarea id="pickup-notes" placeholder="Loading dock instructions, access requirements, etc." />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="h-5 w-5 text-red-500" />
                  <span>Delivery Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="delivery-company">Company Name</Label>
                  <Input id="delivery-company" placeholder="e.g., XYZ Distribution" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-contact">Contact Person</Label>
                  <Input id="delivery-contact" placeholder="Jane Doe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-phone">Phone Number</Label>
                  <Input id="delivery-phone" placeholder="(555) 987-6543" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-address">Address</Label>
                  <AddressAutocomplete
                    value={deliveryAddress}
                    onAddressSelect={(address) => setDeliveryAddress(address.formatted_address)}
                    placeholder="Start typing delivery address..."
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="delivery-date">Delivery Date</Label>
                    <Input id="delivery-date" type="date" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="delivery-time">Time Window</Label>
                    <select className="w-full p-2 border border-input rounded-md">
                      <option>8:00 AM - 12:00 PM</option>
                      <option>12:00 PM - 5:00 PM</option>
                      <option>Flexible</option>
                      <option>Appointment Required</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="delivery-notes">Special Instructions</Label>
                  <Textarea id="delivery-notes" placeholder="Unloading requirements, access restrictions, etc." />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Cargo Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Package className="h-5 w-5" />
                <span>Cargo Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cargo-description">Cargo Description</Label>
                  <Input id="cargo-description" placeholder="e.g., Electronics, Machinery, Consumer Goods" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cargo-category">Category</Label>
                  <select className="w-full p-2 border border-input rounded-md">
                    <option>General Freight</option>
                    <option>Electronics</option>
                    <option>Machinery</option>
                    <option>Food & Beverage</option>
                    <option>Chemicals</option>
                    <option>Fragile Items</option>
                    <option>Hazardous Materials</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="vehicle-type">Vehicle Type *</Label>
                  <Select value={selectedVehicleType} onValueChange={setSelectedVehicleType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select vehicle type" />
                    </SelectTrigger>
                    <SelectContent className="max-h-[300px]">
                      {VEHICLE_CATEGORIES.map((category) => (
                        <React.Fragment key={category.id}>
                          <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                            {category.icon} {category.name}
                          </div>
                          {category.vehicle_types.map((vehicle) => (
                            <SelectItem 
                              key={vehicle.name} 
                              value={vehicle.name}
                              className="pl-6"
                            >
                              {vehicle.name} ({vehicle.capacity})
                            </SelectItem>
                          ))}
                        </React.Fragment>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="calculated-distance">Distance (miles)</Label>
                  <Input 
                    id="calculated-distance" 
                    value={calculatedDistance}
                    onChange={(e) => setCalculatedDistance(e.target.value)}
                    placeholder="Enter distance"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="calculated-duration">Duration (minutes)</Label>
                  <Input 
                    id="calculated-duration" 
                    value={calculatedDuration}
                    onChange={(e) => setCalculatedDuration(e.target.value)}
                    placeholder="Enter duration"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cargo-weight">Weight (lbs)</Label>
                  <Input id="cargo-weight" placeholder="1000" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cargo-length">Length (ft)</Label>
                  <Input id="cargo-length" placeholder="8" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cargo-width">Width (ft)</Label>
                  <Input id="cargo-width" placeholder="4" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cargo-height">Height (ft)</Label>
                  <Input id="cargo-height" placeholder="6" />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cargo-pieces">Number of Pieces</Label>
                  <Input id="cargo-pieces" placeholder="5" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cargo-value">Declared Value ($)</Label>
                  <Input id="cargo-value" placeholder="10000" />
                </div>
              </div>

              <div className="space-y-4">
                <h4 className="font-medium">Special Requirements</h4>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="flex items-center space-x-2">
                    <Switch id="temperature-controlled" />
                    <Label htmlFor="temperature-controlled" className="text-sm">Temperature Controlled</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="fragile" />
                    <Label htmlFor="fragile" className="text-sm">Fragile</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="hazmat" />
                    <Label htmlFor="hazmat" className="text-sm">Hazardous Materials</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="stackable" />
                    <Label htmlFor="stackable" className="text-sm">Stackable</Label>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Additional Services */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Services</CardTitle>
              <CardDescription>Optional services to enhance your shipment</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">Insurance Coverage</div>
                    <div className="text-sm text-muted-foreground">Protect your cargo value</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch />
                    <Badge variant="secondary">+$25</Badge>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">Liftgate Service</div>
                    <div className="text-sm text-muted-foreground">Hydraulic lift for heavy items</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch />
                    <Badge variant="secondary">+$75</Badge>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">Inside Delivery</div>
                    <div className="text-sm text-muted-foreground">Delivery inside the building</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch />
                    <Badge variant="secondary">+$50</Badge>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <div className="font-medium">White Glove Service</div>
                    <div className="text-sm text-muted-foreground">Premium handling and setup</div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch />
                    <Badge variant="secondary">+$150</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Budget & Preferences */}
          <Card>
            <CardHeader>
              <CardTitle>Budget & Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="budget">Budget Range</Label>
                  <select className="w-full p-2 border border-input rounded-md">
                    <option>$500 - $1,000</option>
                    <option>$1,000 - $2,500</option>
                    <option>$2,500 - $5,000</option>
                    <option>$5,000+</option>
                    <option>Get best quote</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="priority">Priority Level</Label>
                  <select className="w-full p-2 border border-input rounded-md">
                    <option>Standard</option>
                    <option>Expedited</option>
                    <option>Emergency</option>
                  </select>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="special-requests">Special Requests</Label>
                <Textarea id="special-requests" placeholder="Any additional requirements or special handling instructions..." />
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="space-y-4 pt-6 border-t">
            <div className="flex items-center space-x-2">
              <Checkbox id="signature-required" />
              <Label htmlFor="signature-required" className="text-sm font-normal cursor-pointer">
                Signature required upon delivery
              </Label>
            </div>

            <div className="flex justify-between items-center">
              <Button variant="outline" onClick={() => toast.success('Job saved as draft!')}>Save as Draft</Button>
              <div className="space-x-4">
                <Button variant="outline" onClick={() => toast.info('Quote request feature coming soon!')}>Request Quote</Button>
                <Button onClick={handlePostJob} disabled={isSubmitting}>
                  {isSubmitting ? 'Posting...' : 'Post Job'}
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}