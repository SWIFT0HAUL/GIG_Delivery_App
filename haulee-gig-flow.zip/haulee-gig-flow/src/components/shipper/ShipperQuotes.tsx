import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Calculator, TrendingDown, TrendingUp, Star } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const ShipperQuotes = () => {
  const { toast } = useToast();
  const [quoteResults, setQuoteResults] = useState<any[]>([]);
  const [calculating, setCalculating] = useState(false);

  const calculateQuotes = () => {
    setCalculating(true);
    setTimeout(() => {
      setQuoteResults([
        {
          carrier: 'Express Logistics',
          price: 2450.00,
          estimatedDays: 3,
          rating: 4.8,
          savings: 0,
          recommended: true,
        },
        {
          carrier: 'Swift Transport',
          price: 2180.00,
          estimatedDays: 4,
          rating: 4.6,
          savings: 270,
          recommended: false,
        },
        {
          carrier: 'Budget Freight',
          price: 1890.00,
          estimatedDays: 5,
          rating: 4.2,
          savings: 560,
          recommended: false,
        },
        {
          carrier: 'Premium Carriers',
          price: 2890.00,
          estimatedDays: 2,
          rating: 4.9,
          savings: -440,
          recommended: false,
        },
      ]);
      setCalculating(false);
    }, 1500);
  };

  const requestQuote = (carrier: string) => {
    toast({
      title: 'Quote Requested',
      description: `Formal quote request sent to ${carrier}. You'll receive a response within 24 hours.`,
    });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Rate Quote Calculator</CardTitle>
          <CardDescription>Get instant rate estimates from multiple carriers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
            <div className="space-y-2">
              <Label>Origin</Label>
              <Input placeholder="City, State or ZIP" />
            </div>
            <div className="space-y-2">
              <Label>Destination</Label>
              <Input placeholder="City, State or ZIP" />
            </div>
            <div className="space-y-2">
              <Label>Weight (lbs)</Label>
              <Input type="number" placeholder="Enter weight" />
            </div>
            <div className="space-y-2">
              <Label>Shipment Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ltl">LTL (Less Than Truckload)</SelectItem>
                  <SelectItem value="ftl">FTL (Full Truckload)</SelectItem>
                  <SelectItem value="partial">Partial Truckload</SelectItem>
                  <SelectItem value="expedited">Expedited</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Freight Class</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="50">Class 50</SelectItem>
                  <SelectItem value="55">Class 55</SelectItem>
                  <SelectItem value="60">Class 60</SelectItem>
                  <SelectItem value="65">Class 65</SelectItem>
                  <SelectItem value="70">Class 70</SelectItem>
                  <SelectItem value="85">Class 85</SelectItem>
                  <SelectItem value="92.5">Class 92.5</SelectItem>
                  <SelectItem value="100">Class 100</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Required Services</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select services" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="liftgate">Liftgate Required</SelectItem>
                  <SelectItem value="inside">Inside Delivery</SelectItem>
                  <SelectItem value="appointment">Appointment Required</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <Button onClick={calculateQuotes} disabled={calculating} className="w-full">
            <Calculator className="h-4 w-4 mr-2" />
            {calculating ? 'Calculating...' : 'Calculate Quotes'}
          </Button>
        </CardContent>
      </Card>

      {quoteResults.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Available Quotes</h3>
          {quoteResults.map((quote, index) => (
            <Card key={index} className={quote.recommended ? 'border-primary' : ''}>
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-lg">{quote.carrier}</h4>
                      {quote.recommended && (
                        <Badge variant="default">Recommended</Badge>
                      )}
                      <div className="flex items-center gap-1 text-sm">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        <span>{quote.rating}</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Estimated delivery: {quote.estimatedDays} days
                    </p>
                    {quote.savings !== 0 && (
                      <div className="flex items-center gap-1 mt-1">
                        {quote.savings > 0 ? (
                          <>
                            <TrendingDown className="h-4 w-4 text-green-500" />
                            <span className="text-sm text-green-500">
                              Save ${quote.savings.toFixed(2)}
                            </span>
                          </>
                        ) : (
                          <>
                            <TrendingUp className="h-4 w-4 text-red-500" />
                            <span className="text-sm text-red-500">
                              ${Math.abs(quote.savings).toFixed(2)} premium
                            </span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="text-2xl font-bold">${quote.price.toFixed(2)}</div>
                      <div className="text-sm text-muted-foreground">per shipment</div>
                    </div>
                    <Button onClick={() => requestQuote(quote.carrier)}>
                      Request Quote
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
