import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MapPin, Truck, Clock, CheckCircle, Search, Navigation } from 'lucide-react';

export function ShipperTracking() {
  const trackedShipments = [
    {
      id: 'SH1234',
      description: 'Electronics Equipment',
      route: 'Los Angeles, CA → New York, NY',
      driver: 'Mike Johnson',
      carrier: 'Prime Logistics',
      status: 'In Transit',
      currentLocation: 'Denver, CO',
      estimatedArrival: '2024-01-25 2:30 PM',
      progress: 65,
      milestones: [
        { location: 'Los Angeles, CA', status: 'completed', time: '2024-01-20 8:00 AM', description: 'Package picked up' },
        { location: 'Phoenix, AZ', status: 'completed', time: '2024-01-21 11:30 AM', description: 'In transit' },
        { location: 'Denver, CO', status: 'current', time: '2024-01-22 9:15 AM', description: 'Currently here' },
        { location: 'Chicago, IL', status: 'upcoming', time: 'Est. 2024-01-23 7:00 PM', description: 'Next stop' },
        { location: 'New York, NY', status: 'upcoming', time: 'Est. 2024-01-25 2:30 PM', description: 'Final destination' }
      ]
    },
    {
      id: 'SH1235',
      description: 'Industrial Machinery',
      route: 'Chicago, IL → Miami, FL',
      driver: 'Sarah Williams',
      carrier: 'Express Freight',
      status: 'Picked Up',
      currentLocation: 'Chicago, IL',
      estimatedArrival: '2024-01-26 10:00 AM',
      progress: 25,
      milestones: [
        { location: 'Chicago, IL', status: 'completed', time: '2024-01-21 10:00 AM', description: 'Package picked up' },
        { location: 'Indianapolis, IN', status: 'upcoming', time: 'Est. 2024-01-22 4:00 PM', description: 'Next stop' },
        { location: 'Atlanta, GA', status: 'upcoming', time: 'Est. 2024-01-24 8:00 AM', description: 'In transit' },
        { location: 'Miami, FL', status: 'upcoming', time: 'Est. 2024-01-26 10:00 AM', description: 'Final destination' }
      ]
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'In Transit': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Picked Up': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Delivered': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getMilestoneStatus = (status: string) => {
    switch (status) {
      case 'completed': return { icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-100' };
      case 'current': return { icon: Navigation, color: 'text-blue-500', bg: 'bg-blue-100' };
      case 'upcoming': return { icon: Clock, color: 'text-gray-400', bg: 'bg-gray-100' };
      default: return { icon: Clock, color: 'text-gray-400', bg: 'bg-gray-100' };
    }
  };

  return (
    <div className="space-y-6">
      {/* Track by ID */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Search className="h-5 w-5" />
            <span>Track Shipment</span>
          </CardTitle>
          <CardDescription>Enter a shipment ID to track its current status and location</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4">
            <Input 
              placeholder="Enter shipment ID (e.g., SH1234)" 
              className="flex-1"
            />
            <Button>
              <Search className="h-4 w-4 mr-2" />
              Track
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Active Shipments Tracking */}
      <div className="space-y-6">
        {trackedShipments.map((shipment) => (
          <Card key={shipment.id}>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <Truck className="h-5 w-5" />
                    <span>#{shipment.id} - {shipment.description}</span>
                  </CardTitle>
                  <CardDescription className="flex items-center space-x-2 mt-2">
                    <MapPin className="h-4 w-4" />
                    <span>{shipment.route}</span>
                  </CardDescription>
                </div>
                <Badge className={getStatusColor(shipment.status)}>
                  {shipment.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Current Status */}
              <div className="bg-muted/30 p-4 rounded-lg">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Current Location</div>
                    <div className="flex items-center space-x-2 mt-1">
                      <Navigation className="h-4 w-4 text-blue-500" />
                      <span className="font-medium">{shipment.currentLocation}</span>
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Driver</div>
                    <div className="font-medium mt-1">{shipment.driver}</div>
                    <div className="text-sm text-muted-foreground">{shipment.carrier}</div>
                  </div>
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Estimated Arrival</div>
                    <div className="flex items-center space-x-2 mt-1">
                      <Clock className="h-4 w-4 text-green-500" />
                      <span className="font-medium">{shipment.estimatedArrival}</span>
                    </div>
                  </div>
                </div>
                
                {/* Progress Bar */}
                <div className="mt-4">
                  <div className="flex justify-between text-sm mb-2">
                    <span>Progress</span>
                    <span>{shipment.progress}%</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-primary h-2 rounded-full transition-all duration-300" 
                      style={{ width: `${shipment.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              {/* Timeline */}
              <div>
                <h4 className="font-medium mb-4">Shipment Timeline</h4>
                <div className="space-y-4">
                  {shipment.milestones.map((milestone, index) => {
                    const statusConfig = getMilestoneStatus(milestone.status);
                    const StatusIcon = statusConfig.icon;
                    
                    return (
                      <div key={index} className="flex items-start space-x-4">
                        <div className={`p-2 rounded-full ${statusConfig.bg}`}>
                          <StatusIcon className={`h-4 w-4 ${statusConfig.color}`} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between">
                            <div className="font-medium">{milestone.location}</div>
                            <div className="text-sm text-muted-foreground">{milestone.time}</div>
                          </div>
                          <div className="text-sm text-muted-foreground">{milestone.description}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-4 pt-4 border-t">
                <Button variant="outline">
                  <MapPin className="h-4 w-4 mr-2" />
                  View on Map
                </Button>
                <Button variant="outline">
                  <Truck className="h-4 w-4 mr-2" />
                  Contact Driver
                </Button>
                <Button variant="outline">
                  Share Tracking
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tracking Features */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Real-Time Updates</CardTitle>
            <CardDescription>Get notified about your shipment progress</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm">Live GPS tracking enabled</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
              <span className="text-sm">Automatic status updates</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>
              <span className="text-sm">Driver communication available</span>
            </div>
            <div className="flex items-center space-x-3">
              <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
              <span className="text-sm">Delivery confirmation with photos</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Tracking Options</CardTitle>
            <CardDescription>Customize how you receive updates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm">Email notifications</span>
              <Badge variant="secondary">Enabled</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">SMS updates</span>
              <Badge variant="secondary">Enabled</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Push notifications</span>
              <Badge variant="secondary">Enabled</Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm">Share with recipients</span>
              <Badge variant="outline">Disabled</Badge>
            </div>
            <Button variant="outline" className="w-full mt-4">
              Manage Preferences
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}