import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Repeat, Calendar, MapPin, DollarSign, Pause, Play, Edit } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export const ShipperRecurring = () => {
  const { toast } = useToast();

  const recurringShipments = [
    {
      id: 'REC-001',
      name: 'Weekly LA to NY Electronics',
      origin: 'Los Angeles, CA',
      destination: 'New York, NY',
      frequency: 'Weekly',
      nextScheduled: '2025-02-10',
      active: true,
      estimatedCost: 2450.00,
      carrier: 'Express Logistics',
      lastRun: '2025-02-03',
    },
    {
      id: 'REC-002',
      name: 'Bi-Weekly Chicago Distribution',
      origin: 'Chicago, IL',
      destination: 'Miami, FL',
      frequency: 'Bi-Weekly',
      nextScheduled: '2025-02-15',
      active: true,
      estimatedCost: 1890.00,
      carrier: 'Swift Transport',
      lastRun: '2025-02-01',
    },
    {
      id: 'REC-003',
      name: 'Monthly Seattle Inventory',
      origin: 'Seattle, WA',
      destination: 'Boston, MA',
      frequency: 'Monthly',
      nextScheduled: '2025-03-01',
      active: false,
      estimatedCost: 3200.00,
      carrier: 'Prime Freight',
      lastRun: '2025-01-01',
    },
    {
      id: 'REC-004',
      name: 'Daily Local Deliveries',
      origin: 'Houston, TX',
      destination: 'Various (Houston Metro)',
      frequency: 'Daily',
      nextScheduled: '2025-02-04',
      active: true,
      estimatedCost: 450.00,
      carrier: 'Rapid Delivery',
      lastRun: '2025-02-03',
    },
  ];

  const toggleActive = (id: string, name: string, currentStatus: boolean) => {
    toast({
      title: currentStatus ? 'Schedule Paused' : 'Schedule Activated',
      description: `${name} has been ${currentStatus ? 'paused' : 'activated'}.`,
    });
  };

  const getFrequencyBadge = (frequency: string) => {
    const variants: Record<string, string> = {
      Daily: 'default',
      Weekly: 'secondary',
      'Bi-Weekly': 'outline',
      Monthly: 'outline',
    };
    return <Badge variant={variants[frequency] as any}>{frequency}</Badge>;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Recurring Shipments</CardTitle>
              <CardDescription>Automate your regular shipping schedules</CardDescription>
            </div>
            <Button>
              <Repeat className="h-4 w-4 mr-2" />
              Create Schedule
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {recurringShipments.map((shipment) => (
            <Card key={shipment.id}>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-3">
                      <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                        shipment.active ? 'bg-primary/10' : 'bg-muted'
                      }`}>
                        <Repeat className={`h-5 w-5 ${
                          shipment.active ? 'text-primary' : 'text-muted-foreground'
                        }`} />
                      </div>
                      <div>
                        <h3 className="font-semibold">{shipment.name}</h3>
                        <p className="text-sm text-muted-foreground">{shipment.id}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getFrequencyBadge(shipment.frequency)}
                      <Switch
                        checked={shipment.active}
                        onCheckedChange={() => toggleActive(shipment.id, shipment.name, shipment.active)}
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <MapPin className="h-4 w-4" />
                        <span>Route</span>
                      </div>
                      <div className="font-medium">
                        {shipment.origin} → {shipment.destination}
                      </div>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <DollarSign className="h-4 w-4" />
                        <span>Estimated Cost</span>
                      </div>
                      <div className="font-medium">${shipment.estimatedCost.toFixed(2)}</div>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-muted-foreground mb-1">
                        <Calendar className="h-4 w-4" />
                        <span>Next Scheduled</span>
                      </div>
                      <div className="font-medium">{shipment.nextScheduled}</div>
                    </div>
                    <div>
                      <div className="text-muted-foreground mb-1">Preferred Carrier</div>
                      <div className="font-medium">{shipment.carrier}</div>
                    </div>
                  </div>

                  <div className="flex justify-between items-center pt-3 border-t">
                    <div className="text-sm text-muted-foreground">
                      Last run: {shipment.lastRun}
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit Schedule
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                      >
                        {shipment.active ? (
                          <>
                            <Pause className="h-4 w-4 mr-2" />
                            Pause
                          </>
                        ) : (
                          <>
                            <Play className="h-4 w-4 mr-2" />
                            Resume
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Active Schedules</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {recurringShipments.filter(s => s.active).length}
            </div>
            <p className="text-sm text-muted-foreground mt-1">Currently running</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Monthly Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$3.2K</div>
            <p className="text-sm text-muted-foreground mt-1">vs spot pricing</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Next Shipment</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">Tomorrow</div>
            <p className="text-sm text-muted-foreground mt-1">REC-001 scheduled</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Total Value</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$87K</div>
            <p className="text-sm text-muted-foreground mt-1">Annual contract value</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Schedule Benefits</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="font-semibold flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-green-500" />
                Cost Savings
              </div>
              <p className="text-sm text-muted-foreground">
                Save up to 15% with volume commitments and predictable pricing
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-semibold flex items-center gap-2">
                <Calendar className="h-5 w-5 text-blue-500" />
                Reliable Scheduling
              </div>
              <p className="text-sm text-muted-foreground">
                Guaranteed capacity and priority booking for your regular routes
              </p>
            </div>
            <div className="space-y-2">
              <div className="font-semibold flex items-center gap-2">
                <Repeat className="h-5 w-5 text-purple-500" />
                Automation
              </div>
              <p className="text-sm text-muted-foreground">
                Set it and forget it - shipments are automatically created and dispatched
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
