import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart3, TrendingUp, TrendingDown, Download, Calendar } from 'lucide-react';

export const ShipperAnalytics = () => {
  const metrics = [
    { label: 'Total Shipments', value: '247', change: '+12%', trend: 'up' },
    { label: 'On-Time Delivery', value: '96.8%', change: '+2.1%', trend: 'up' },
    { label: 'Average Cost', value: '$2,145', change: '-5.3%', trend: 'down' },
    { label: 'Transit Time', value: '2.8 days', change: '-0.3', trend: 'down' },
  ];

  const topRoutes = [
    { route: 'Los Angeles, CA → New York, NY', shipments: 45, avgCost: 2450, onTime: 98 },
    { route: 'Chicago, IL → Miami, FL', shipments: 38, avgCost: 1890, onTime: 95 },
    { route: 'Seattle, WA → Boston, MA', shipments: 32, avgCost: 3200, onTime: 97 },
    { route: 'Houston, TX → Phoenix, AZ', shipments: 28, avgCost: 1450, onTime: 94 },
  ];

  const carrierPerformance = [
    { name: 'Express Logistics', shipments: 89, onTime: 98, rating: 4.8, cost: 2.45 },
    { name: 'Swift Transport', shipments: 67, onTime: 95, rating: 4.6, cost: 2.18 },
    { name: 'Prime Freight', shipments: 54, onTime: 97, rating: 4.9, cost: 2.89 },
    { name: 'Budget Carriers', shipments: 37, onTime: 92, rating: 4.2, cost: 1.89 },
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Analytics & Reports</CardTitle>
              <CardDescription>Track performance and identify optimization opportunities</CardDescription>
            </div>
            <div className="flex gap-2">
              <Select defaultValue="30days">
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7days">Last 7 days</SelectItem>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="90days">Last 90 days</SelectItem>
                  <SelectItem value="12months">Last 12 months</SelectItem>
                </SelectContent>
              </Select>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {metrics.map((metric, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    <div className="text-sm text-muted-foreground">{metric.label}</div>
                    <div className="text-2xl font-bold">{metric.value}</div>
                    <div className={`text-sm flex items-center gap-1 ${
                      metric.trend === 'up' ? 'text-green-500' : 'text-blue-500'
                    }`}>
                      {metric.trend === 'up' ? (
                        <TrendingUp className="h-4 w-4" />
                      ) : (
                        <TrendingDown className="h-4 w-4" />
                      )}
                      <span>{metric.change}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="routes">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="routes">Top Routes</TabsTrigger>
          <TabsTrigger value="carriers">Carrier Performance</TabsTrigger>
          <TabsTrigger value="costs">Cost Analysis</TabsTrigger>
        </TabsList>

        <TabsContent value="routes" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Top Shipping Routes</CardTitle>
              <CardDescription>Your most frequently used routes and their performance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {topRoutes.map((route, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-semibold">{route.route}</h4>
                        <p className="text-sm text-muted-foreground">
                          {route.shipments} shipments
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">${route.avgCost}</div>
                        <div className="text-sm text-muted-foreground">avg cost</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <div className="flex-1">
                        <div className="text-muted-foreground mb-1">On-Time Rate</div>
                        <div className="w-full bg-muted rounded-full h-2">
                          <div
                            className="bg-green-500 h-2 rounded-full"
                            style={{ width: `${route.onTime}%` }}
                          />
                        </div>
                      </div>
                      <div className="font-semibold">{route.onTime}%</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="carriers" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Carrier Performance Comparison</CardTitle>
              <CardDescription>Evaluate your carriers across key metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {carrierPerformance.map((carrier, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-semibold">{carrier.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {carrier.shipments} shipments • {carrier.rating} ⭐
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="font-semibold">${carrier.cost}/mile</div>
                        <div className="text-sm text-muted-foreground">avg rate</div>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">On-Time Performance</div>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-muted rounded-full h-2">
                            <div
                              className="bg-primary h-2 rounded-full"
                              style={{ width: `${carrier.onTime}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold">{carrier.onTime}%</span>
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Volume Share</div>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 bg-muted rounded-full h-2">
                            <div
                              className="bg-secondary h-2 rounded-full"
                              style={{ width: `${(carrier.shipments / 247) * 100}%` }}
                            />
                          </div>
                          <span className="text-sm font-semibold">
                            {Math.round((carrier.shipments / 247) * 100)}%
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="costs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Cost Breakdown & Trends</CardTitle>
              <CardDescription>Analyze your shipping costs over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm text-muted-foreground">Total Spend (YTD)</div>
                      <div className="text-3xl font-bold mt-2">$542,340</div>
                      <div className="text-sm text-green-500 mt-2">-8.3% vs last year</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm text-muted-foreground">Avg Cost per Shipment</div>
                      <div className="text-3xl font-bold mt-2">$2,145</div>
                      <div className="text-sm text-green-500 mt-2">-$120 improvement</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-sm text-muted-foreground">Cost per Mile</div>
                      <div className="text-3xl font-bold mt-2">$2.38</div>
                      <div className="text-sm text-muted-foreground mt-2">Industry avg: $2.65</div>
                    </CardContent>
                  </Card>
                </div>

                <div className="border rounded-lg p-4">
                  <h4 className="font-semibold mb-4">Cost Distribution</h4>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Base Rate</span>
                        <span className="font-medium">$389,450 (72%)</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-primary h-2 rounded-full" style={{ width: '72%' }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Fuel Surcharge</span>
                        <span className="font-medium">$81,350 (15%)</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-secondary h-2 rounded-full" style={{ width: '15%' }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Accessorial Charges</span>
                        <span className="font-medium">$54,234 (10%)</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-accent h-2 rounded-full" style={{ width: '10%' }} />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Insurance & Other</span>
                        <span className="font-medium">$17,306 (3%)</span>
                      </div>
                      <div className="w-full bg-muted rounded-full h-2">
                        <div className="bg-muted-foreground h-2 rounded-full" style={{ width: '3%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
