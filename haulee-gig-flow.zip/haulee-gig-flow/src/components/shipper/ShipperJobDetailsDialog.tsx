import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { MapPin, Calendar, DollarSign, Truck, Package, User, FileText, Clock, CheckCircle2, XCircle, Image as ImageIcon } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface Job {
  id: string;
  title: string;
  status: string;
  pickup_location: any;
  delivery_location: any;
  pickup_time: string | null;
  delivery_time: string | null;
  actual_delivery_time: string | null;
  created_at: string;
  completed_at: string | null;
  cancelled_at: string | null;
  pay_amount: number | null;
  distance_miles: number | null;
  estimated_duration: number | null;
  equipment_type: string | null;
  cargo_details: any;
  special_instructions: string | null;
  proof_of_delivery_url: string | null;
  assigned_driver_id: string | null;
  carrier_id: string | null;
  description: string | null;
  cancellation_reason: string | null;
  metadata: any;
  rating: number | null;
}

interface ShipperJobDetailsDialogProps {
  job: Job | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ShipperJobDetailsDialog({ job, open, onOpenChange }: ShipperJobDetailsDialogProps) {
  // Fetch pickup photo from job_assignments
  const { data: jobAssignment } = useQuery({
    queryKey: ['job-assignment', job?.id],
    queryFn: async () => {
      if (!job?.id) return null;
      
      const { data, error } = await supabase
        .from('job_assignments')
        .select('pickup_photo_url, started_at')
        .eq('job_id', job.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching job assignment:', error);
        return null;
      }
      
      return data;
    },
    enabled: !!job?.id && open,
  });

  // Fetch from carrier_job_assignments as well
  const { data: carrierAssignment } = useQuery({
    queryKey: ['carrier-job-assignment', job?.id],
    queryFn: async () => {
      if (!job?.id) return null;
      
      const { data, error } = await supabase
        .from('carrier_job_assignments')
        .select('started_at, notes')
        .eq('job_id', job.id)
        .maybeSingle();

      if (error) {
        console.error('Error fetching carrier assignment:', error);
        return null;
      }
      
      return data;
    },
    enabled: !!job?.id && open,
  });

  if (!job) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered':
      case 'completed':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const formatStatus = (status: string) => {
    return status.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
  };

  const getLocationAddress = (location: any) => {
    if (!location) return 'N/A';
    if (typeof location === 'string') return location;
    return location.address || 'N/A';
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-2xl">Job Details</DialogTitle>
            <Badge className={getStatusColor(job.status)}>
              {formatStatus(job.status)}
            </Badge>
          </div>
        </DialogHeader>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
            <TabsTrigger value="delivery">Delivery Details</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Job Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Job ID</div>
                    <div className="font-medium">#{job.id.slice(0, 8)}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Title</div>
                    <div className="font-medium">{job.title || 'Delivery Job'}</div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Pay Amount</div>
                    <div className="font-medium flex items-center">
                      <DollarSign className="h-4 w-4 mr-1" />
                      {job.pay_amount ? `$${job.pay_amount}` : 'N/A'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Distance</div>
                    <div className="font-medium">
                      {job.distance_miles ? `${job.distance_miles} miles` : 'N/A'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Equipment Type</div>
                    <div className="font-medium flex items-center">
                      <Truck className="h-4 w-4 mr-1" />
                      {job.equipment_type || 'N/A'}
                    </div>
                  </div>
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Duration</div>
                    <div className="font-medium">
                      {job.estimated_duration ? `${job.estimated_duration} mins` : 'N/A'}
                    </div>
                  </div>
                </div>

                {job.description && (
                  <div>
                    <div className="text-sm text-muted-foreground mb-1">Description</div>
                    <div className="font-medium">{job.description}</div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Route Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex items-center text-sm text-muted-foreground mb-2">
                    <MapPin className="h-4 w-4 mr-2 text-green-600" />
                    Pickup Location
                  </div>
                  <div className="font-medium ml-6">{getLocationAddress(job.pickup_location)}</div>
                  {job.pickup_time && (
                    <div className="text-sm text-muted-foreground ml-6 mt-1">
                      Scheduled: {format(new Date(job.pickup_time), 'MMM dd, yyyy h:mm a')}
                    </div>
                  )}
                </div>
                <div>
                  <div className="flex items-center text-sm text-muted-foreground mb-2">
                    <MapPin className="h-4 w-4 mr-2 text-red-600" />
                    Delivery Location
                  </div>
                  <div className="font-medium ml-6">{getLocationAddress(job.delivery_location)}</div>
                  {job.delivery_time && (
                    <div className="text-sm text-muted-foreground ml-6 mt-1">
                      Scheduled: {format(new Date(job.delivery_time), 'MMM dd, yyyy h:mm a')}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {job.special_instructions && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <FileText className="h-5 w-5 mr-2" />
                    Special Instructions
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm">{job.special_instructions}</p>
                </CardContent>
              </Card>
            )}

            {job.cargo_details && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Package className="h-5 w-5 mr-2" />
                    Cargo Details
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <pre className="text-sm bg-muted p-3 rounded-md overflow-auto">
                    {JSON.stringify(job.cargo_details, null, 2)}
                  </pre>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="timeline" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Job Timeline</CardTitle>
                <CardDescription>Track the progress of your shipment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="mt-1">
                      <CheckCircle2 className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <div className="font-medium">Job Created</div>
                      <div className="text-sm text-muted-foreground">
                        {format(new Date(job.created_at), 'MMM dd, yyyy h:mm a')}
                      </div>
                    </div>
                  </div>

                  {(job.metadata?.actual_pickup_time || jobAssignment?.started_at || carrierAssignment?.started_at) && (
                    <div className="flex items-start space-x-3">
                      <div className="mt-1">
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">Picked Up</div>
                        <div className="text-sm text-muted-foreground">
                          {format(
                            new Date(
                              job.metadata?.actual_pickup_time || 
                              jobAssignment?.started_at || 
                              carrierAssignment?.started_at
                            ), 
                            'MMM dd, yyyy h:mm a'
                          )}
                        </div>
                        {(job.metadata?.pickup_photo_url || jobAssignment?.pickup_photo_url) && (
                          <div className="mt-2">
                            <img 
                              src={job.metadata?.pickup_photo_url || jobAssignment?.pickup_photo_url} 
                              alt="Pickup proof" 
                              className="w-32 h-32 object-cover rounded border"
                              loading="lazy"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {job.completed_at && job.status === 'completed' && (
                    <div className="flex items-start space-x-3">
                      <div className="mt-1">
                        <CheckCircle2 className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <div className="font-medium">Delivery Completed</div>
                        <div className="text-sm text-muted-foreground">
                          {format(new Date(job.completed_at), 'MMM dd, yyyy h:mm a')}
                        </div>
                      </div>
                    </div>
                  )}

                  {job.cancelled_at && job.status === 'cancelled' && (
                    <div className="flex items-start space-x-3">
                      <div className="mt-1">
                        <XCircle className="h-5 w-5 text-red-600" />
                      </div>
                      <div>
                        <div className="font-medium">Job Cancelled</div>
                        <div className="text-sm text-muted-foreground">
                          {format(new Date(job.cancelled_at), 'MMM dd, yyyy h:mm a')}
                        </div>
                        {job.cancellation_reason && (
                          <div className="text-sm text-muted-foreground mt-1">
                            Reason: {job.cancellation_reason}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="delivery" className="space-y-4 mt-4">
            {job.status === 'completed' || job.status === 'delivered' ? (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Delivery Information</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      {job.actual_delivery_time && (
                        <div>
                          <div className="text-sm text-muted-foreground mb-1">Actual Delivery Time</div>
                          <div className="font-medium">
                            {format(new Date(job.actual_delivery_time), 'MMM dd, yyyy h:mm a')}
                          </div>
                        </div>
                      )}
                      {job.rating && (
                        <div>
                          <div className="text-sm text-muted-foreground mb-1">Rating</div>
                          <div className="font-medium">{job.rating} / 5</div>
                        </div>
                      )}
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Drop-off Location Type</div>
                      <div className="font-medium">{job.metadata?.dropoff_location_type || 'N/A'}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Specific Delivery Area</div>
                      <div className="font-medium">{job.metadata?.specific_delivery_area || job.metadata?.actual_dropoff_location || 'N/A'}</div>
                    </div>

                    <div>
                      <div className="text-sm text-muted-foreground mb-1">Customer Name</div>
                      <div className="font-medium">{job.metadata?.recipient_name || 'N/A'}</div>
                    </div>

                    {job.metadata?.delivery_notes && (
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Delivery Notes</div>
                        <div className="font-medium">{job.metadata.delivery_notes}</div>
                      </div>
                    )}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Proof of Delivery</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm text-muted-foreground mb-2">Delivery Photo</div>
                      {job.proof_of_delivery_url ? (
                        <img 
                          src={job.proof_of_delivery_url} 
                          alt="Proof of delivery" 
                          className="w-full max-w-md rounded border"
                          loading="lazy"
                        />
                      ) : (
                        <div className="text-muted-foreground">No delivery photo available</div>
                      )}
                    </div>
                    <div>
                      <div className="text-sm text-muted-foreground mb-2">Customer Signature</div>
                      {job.metadata?.signature_url ? (
                        <img 
                          src={job.metadata.signature_url} 
                          alt="Customer signature" 
                          className="w-full max-w-md rounded border bg-white"
                          loading="lazy"
                        />
                      ) : (
                        <div className="text-muted-foreground">No signature available</div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </>
            ) : job.status === 'cancelled' ? (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Cancellation Details</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {job.cancelled_at && (
                      <div>
                        <div className="text-sm text-muted-foreground">Cancelled At</div>
                        <div className="font-medium">
                          {format(new Date(job.cancelled_at), 'MMM dd, yyyy h:mm a')}
                        </div>
                      </div>
                    )}
                    {job.cancellation_reason && (
                      <div>
                        <div className="text-sm text-muted-foreground">Reason</div>
                        <div className="font-medium">{job.cancellation_reason}</div>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                Delivery details will be available once the job is completed
              </div>
            )}
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
