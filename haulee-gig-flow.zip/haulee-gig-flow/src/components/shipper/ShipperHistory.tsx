import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Calendar as CalendarIcon, Download, Eye, Filter, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { ShipperShipmentDetailsDialog } from './ShipperShipmentDetailsDialog';
import { supabase } from '@/integrations/supabase/client';
import { useQuery } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

export const ShipperHistory = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [dateRange, setDateRange] = useState<{ from?: Date; to?: Date }>({});
  const [dateRangeOpen, setDateRangeOpen] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<any>(null);
  const [isDetailsDialogOpen, setIsDetailsDialogOpen] = useState(false);
  const { toast } = useToast();

  const { data: shipmentHistory = [], isLoading } = useQuery({
    queryKey: ['shipper-history'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        .from('jobs')
        .select(`
          id,
          title,
          status,
          carrier_display_name,
          driver_display_name,
          pay_amount,
          pickup_location,
          delivery_location,
          pickup_time,
          delivery_time,
          completed_at,
          cancelled_at,
          created_at
        `)
        .or(`created_by.eq.${user.id},shipper_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (error) {
        toast({
          variant: 'destructive',
          title: 'Error loading shipment history',
          description: error.message,
        });
        throw error;
      }

      const rows = data || [];
      const completedRows = rows.filter((job: any) => {
        const s = (job.status || '').toLowerCase();
        return ['delivered', 'completed', 'cancelled'].includes(s) || job.completed_at || job.cancelled_at;
      });

      return completedRows.map((job: any) => {
        const carrierName = job.carrier_display_name || job.driver_display_name || 'N/A';
        
        return {
          id: job.id.slice(0, 8).toUpperCase(),
          date: job.created_at,
          origin: job.pickup_location?.address || 'N/A',
          destination: job.delivery_location?.address || 'N/A',
          carrier: carrierName,
          status: job.status,
          cost: job.pay_amount || 0,
          deliveryDate: job.completed_at || job.cancelled_at || null,
        };
      });
    },
  });

  const handleViewDetails = (shipment: any) => {
    setSelectedShipment(shipment);
    setIsDetailsDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
      delivered: 'default',
      cancelled: 'destructive',
    };
    return <Badge variant={variants[status] || 'secondary'}>{status}</Badge>;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Shipment History</CardTitle>
          <CardDescription>View and manage your past shipments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by shipment ID, origin, or destination..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Popover open={dateRangeOpen} onOpenChange={setDateRangeOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full md:w-auto">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  Date Range
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  mode="single"
                  selected={dateRange.from}
                  onSelect={(date) => {
                    setDateRange({ ...dateRange, from: date });
                    setDateRangeOpen(false);
                  }}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Shipment ID</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Route</TableHead>
                  <TableHead>Carrier</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Delivered</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8">
                      <Loader2 className="h-6 w-6 animate-spin mx-auto" />
                    </TableCell>
                  </TableRow>
                ) : shipmentHistory.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                      No shipment history found
                    </TableCell>
                  </TableRow>
                ) : (
                  shipmentHistory.map((shipment) => (
                    <TableRow key={shipment.id}>
                      <TableCell className="font-medium">{shipment.id}</TableCell>
                      <TableCell>{format(new Date(shipment.date), 'MMM dd, yyyy')}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{shipment.origin}</div>
                          <div className="text-muted-foreground">→ {shipment.destination}</div>
                        </div>
                      </TableCell>
                      <TableCell>{shipment.carrier}</TableCell>
                      <TableCell>{getStatusBadge(shipment.status)}</TableCell>
                      <TableCell>${shipment.cost.toFixed(2)}</TableCell>
                      <TableCell>
                        {shipment.deliveryDate ? format(new Date(shipment.deliveryDate), 'MMM dd, yyyy') : '-'}
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm" onClick={() => handleViewDetails(shipment)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          </CardContent>
      </Card>

      <ShipperShipmentDetailsDialog
        shipment={selectedShipment}
        open={isDetailsDialogOpen}
        onOpenChange={setIsDetailsDialogOpen}
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Total Shipments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">247</div>
            <p className="text-sm text-muted-foreground mt-1">All time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">96.8%</div>
            <p className="text-sm text-muted-foreground mt-1">Delivered on time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Total Spent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">$542K</div>
            <p className="text-sm text-muted-foreground mt-1">Lifetime value</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
