import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Package, MapPin, Calendar, DollarSign, Truck, Clock } from 'lucide-react';
import { format } from 'date-fns';

interface Shipment {
  id: string;
  date: string;
  origin: string;
  destination: string;
  carrier: string;
  status: string;
  cost: number;
  deliveryDate: string | null;
}

interface ShipperShipmentDetailsDialogProps {
  shipment: Shipment | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const ShipperShipmentDetailsDialog: React.FC<ShipperShipmentDetailsDialogProps> = ({
  shipment,
  open,
  onOpenChange,
}) => {
  if (!shipment) return null;

  const getStatusBadge = (status: string) => {
    const variants: Record<string, 'default' | 'secondary' | 'destructive'> = {
      delivered: 'default',
      cancelled: 'destructive',
    };
    return <Badge variant={variants[status] || 'secondary'}>{status}</Badge>;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="h-5 w-5" />
            Shipment Details - {shipment.id}
          </DialogTitle>
          <DialogDescription>
            View complete shipment information
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and Basic Info */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Status</p>
              {getStatusBadge(shipment.status)}
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Shipment ID</p>
              <p className="font-medium">{shipment.id}</p>
            </div>
          </div>

          <Separator />

          {/* Route Information */}
          <div className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <MapPin className="h-4 w-4" />
              Route Information
            </h3>
            <div className="grid grid-cols-1 gap-4">
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">Origin</p>
                <p className="font-medium">{shipment.origin}</p>
              </div>
              <div className="p-3 rounded-lg bg-muted/50">
                <p className="text-sm text-muted-foreground mb-1">Destination</p>
                <p className="font-medium">{shipment.destination}</p>
              </div>
            </div>
          </div>

          <Separator />

          {/* Carrier and Dates */}
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                  <Truck className="h-3 w-3" />
                  Carrier
                </p>
                <p className="font-medium">{shipment.carrier}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                  <DollarSign className="h-3 w-3" />
                  Cost
                </p>
                <p className="font-medium">${shipment.cost.toFixed(2)}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  Shipment Date
                </p>
                <p className="font-medium">{format(new Date(shipment.date), 'MMM dd, yyyy')}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1 flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  Delivery Date
                </p>
                <p className="font-medium">
                  {shipment.deliveryDate ? format(new Date(shipment.deliveryDate), 'MMM dd, yyyy') : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
