import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { MapPin, Plus, Edit, Trash2, Star, Building2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';

export const ShipperLocations = () => {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [locationAddress, setLocationAddress] = useState('');

  const locations = [
    {
      id: 1,
      name: 'Main Warehouse',
      type: 'warehouse',
      address: '1234 Commerce Dr',
      city: 'Los Angeles',
      state: 'CA',
      zip: '90001',
      country: 'USA',
      contact: 'John Smith',
      phone: '(555) 123-4567',
      favorite: true,
      notes: 'Dock hours: 6AM - 6PM, Mon-Fri',
    },
    {
      id: 2,
      name: 'East Coast Distribution',
      type: 'distribution',
      address: '5678 Industrial Blvd',
      city: 'New York',
      state: 'NY',
      zip: '10001',
      country: 'USA',
      contact: 'Sarah Johnson',
      phone: '(555) 987-6543',
      favorite: true,
      notes: '24/7 access, security code required',
    },
    {
      id: 3,
      name: 'Chicago Fulfillment Center',
      type: 'fulfillment',
      address: '9012 Logistics Way',
      city: 'Chicago',
      state: 'IL',
      zip: '60601',
      country: 'USA',
      contact: 'Mike Wilson',
      phone: '(555) 456-7890',
      favorite: false,
      notes: 'Appointment required 24hrs in advance',
    },
    {
      id: 4,
      name: 'Miami Customer Delivery',
      type: 'customer',
      address: '3456 Ocean Ave',
      city: 'Miami',
      state: 'FL',
      zip: '33101',
      country: 'USA',
      contact: 'Lisa Martinez',
      phone: '(555) 321-0987',
      favorite: false,
      notes: 'Residential delivery, call ahead',
    },
  ];

  const addLocation = () => {
    toast({
      title: 'Location Added',
      description: 'New location has been saved to your address book.',
    });
    setIsOpen(false);
  };

  const toggleFavorite = (locationName: string) => {
    toast({
      title: 'Favorite Updated',
      description: `${locationName} has been ${Math.random() > 0.5 ? 'added to' : 'removed from'} favorites.`,
    });
  };

  const deleteLocation = (locationName: string) => {
    toast({
      title: 'Location Deleted',
      description: `${locationName} has been removed from your address book.`,
      variant: 'destructive',
    });
  };

  const getTypeIcon = (type: string) => {
    return type === 'customer' ? MapPin : Building2;
  };

  const getTypeBadge = (type: string) => {
    const variants: Record<string, string> = {
      warehouse: 'default',
      distribution: 'secondary',
      fulfillment: 'outline',
      customer: 'outline',
    };
    return <Badge variant={variants[type] as any}>{type}</Badge>;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle>Address & Location Management</CardTitle>
              <CardDescription>Manage your pickup and delivery locations</CardDescription>
            </div>
            <Dialog open={isOpen} onOpenChange={setIsOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Location
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Add New Location</DialogTitle>
                  <DialogDescription>
                    Add a new address to your saved locations
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div className="space-y-2">
                    <Label>Location Name *</Label>
                    <Input placeholder="e.g., Main Warehouse, Customer Site" />
                  </div>
                  <div className="space-y-2">
                    <Label>Location Type *</Label>
                    <select className="w-full border rounded-md p-2">
                      <option>Warehouse</option>
                      <option>Distribution Center</option>
                      <option>Fulfillment Center</option>
                      <option>Customer Location</option>
                      <option>Retail Store</option>
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Street Address *</Label>
                    <AddressAutocomplete
                      value={locationAddress}
                      onAddressSelect={(address) => setLocationAddress(address.formatted_address || '')}
                      placeholder="Start typing address..."
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>City *</Label>
                      <Input placeholder="City" />
                    </div>
                    <div className="space-y-2">
                      <Label>State *</Label>
                      <Input placeholder="State" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>ZIP Code *</Label>
                      <Input placeholder="ZIP" />
                    </div>
                    <div className="space-y-2">
                      <Label>Country *</Label>
                      <Input placeholder="Country" defaultValue="USA" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Contact Person</Label>
                      <Input placeholder="Contact name" />
                    </div>
                    <div className="space-y-2">
                      <Label>Phone Number</Label>
                      <Input placeholder="(555) 123-4567" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Delivery Notes</Label>
                    <Input placeholder="Special instructions, hours, access codes, etc." />
                  </div>
                  <div className="flex justify-end gap-2 pt-4">
                    <Button variant="outline" onClick={() => setIsOpen(false)}>
                      Cancel
                    </Button>
                    <Button onClick={addLocation}>Add Location</Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {locations.map((location) => {
            const TypeIcon = getTypeIcon(location.type);
            return (
              <Card key={location.id}>
                <CardContent className="pt-6">
                  <div className="flex flex-col md:flex-row gap-4">
                    <div className="flex-shrink-0">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                        <TypeIcon className="h-6 w-6 text-primary" />
                      </div>
                    </div>
                    
                    <div className="flex-1 space-y-3">
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h3 className="font-semibold text-lg">{location.name}</h3>
                          {getTypeBadge(location.type)}
                          {location.favorite && (
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleFavorite(location.name)}
                          >
                            <Star className={`h-4 w-4 ${location.favorite ? 'fill-yellow-400 text-yellow-400' : ''}`} />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteLocation(location.name)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="text-sm">
                        <div className="font-medium">{location.address}</div>
                        <div className="text-muted-foreground">
                          {location.city}, {location.state} {location.zip}
                        </div>
                        <div className="text-muted-foreground">{location.country}</div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm pt-2 border-t">
                        <div>
                          <div className="text-muted-foreground">Contact</div>
                          <div className="font-medium">{location.contact}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">Phone</div>
                          <div className="font-medium">{location.phone}</div>
                        </div>
                      </div>

                      {location.notes && (
                        <div className="text-sm border-t pt-2">
                          <div className="text-muted-foreground mb-1">Notes</div>
                          <div>{location.notes}</div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Total Locations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{locations.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Warehouses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {locations.filter(l => l.type === 'warehouse').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Distribution Centers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {locations.filter(l => l.type === 'distribution').length}
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Favorites</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {locations.filter(l => l.favorite).length}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
