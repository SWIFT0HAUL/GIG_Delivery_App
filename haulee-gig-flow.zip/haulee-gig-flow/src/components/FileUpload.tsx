import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Upload, Camera, File, X, CheckCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface FileUploadProps {
  field: string;
  label: string;
  value?: string;
  onChange: (field: string, fileUrl: string | null) => void;
  acceptedTypes?: string;
  disabled?: boolean;
}

export const FileUpload: React.FC<FileUploadProps> = ({
  field,
  label,
  value,
  onChange,
  acceptedTypes = "image/*,.pdf,.doc,.docx",
  disabled = false
}) => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const uploadFile = async (file: File) => {
    try {
      setUploading(true);
      setUploadProgress(0);

      const user = (await supabase.auth.getUser()).data.user;
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Get user's storage info (bucket and path with account number)
      const { data: uploadInfo, error: infoError } = await supabase
        .rpc('get_user_upload_info');

      if (infoError || !uploadInfo?.[0]) {
        throw new Error('Could not get storage information. Please ensure your account is fully set up.');
      }

      const { storage_path, bucket_name } = uploadInfo[0];

      // Create unique filename
      const fileExt = file.name.split('.').pop();
      const fileName = `${storage_path}${field}_${Date.now()}.${fileExt}`;

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => Math.min(prev + 10, 90));
      }, 100);

      const { data, error } = await supabase.storage
        .from(bucket_name)
        .upload(fileName, file);

      clearInterval(progressInterval);
      setUploadProgress(100);

      if (error) {
        throw error;
      }

      // Get public URL for the uploaded file
      const { data: { publicUrl } } = supabase.storage
        .from(bucket_name)
        .getPublicUrl(fileName);

      onChange(field, publicUrl);
      
      toast({
        title: "File uploaded successfully",
        description: `${file.name} has been uploaded.`,
      });

    } catch (error: any) {
      console.error('Upload error:', error);
      toast({
        title: "Upload failed",
        description: error.message || "Failed to upload file",
        variant: "destructive",
      });
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file size (max 10MB)
      if (file.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select a file smaller than 10MB",
          variant: "destructive",
        });
        return;
      }
      uploadFile(file);
    }
  };

  const handleRemoveFile = async () => {
    if (value) {
      try {
        // Get user's storage info
        const { data: uploadInfo } = await supabase.rpc('get_user_upload_info');
        
        if (!uploadInfo?.[0]) {
          throw new Error('Could not get storage information');
        }

        const { bucket_name } = uploadInfo[0];

        // Extract full path from URL
        const url = new URL(value);
        const pathParts = url.pathname.split('/storage/v1/object/public/');
        if (pathParts.length > 1) {
          const fullPath = pathParts[1].split('/').slice(1).join('/'); // Remove bucket name
          await supabase.storage.from(bucket_name).remove([fullPath]);
        }
        
        onChange(field, null);
        toast({
          title: "File removed",
          description: "File has been deleted successfully.",
        });
      } catch (error) {
        console.error('Error removing file:', error);
        toast({
          title: "Error removing file",
          description: "Could not remove the file. Please try again.",
          variant: "destructive",
        });
      }
    }
  };

  const getFileName = (url: string) => {
    try {
      const urlObj = new URL(url);
      const pathParts = urlObj.pathname.split('/');
      return pathParts[pathParts.length - 1];
    } catch {
      return 'Uploaded file';
    }
  };

  return (
    <div className="space-y-2">
      <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-6">
        <div className="text-center">
          {value ? (
            <div className="space-y-3">
              <CheckCircle className="mx-auto h-8 w-8 text-accent" />
              <div className="flex items-center justify-center space-x-2">
                <File className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium text-accent">
                  {getFileName(value)}
                </span>
              </div>
              <div className="flex gap-2 justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(value, '_blank')}
                  disabled={disabled}
                >
                  View
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRemoveFile}
                  disabled={disabled || uploading}
                >
                  <X className="h-4 w-4 mr-2" />
                  Remove
                </Button>
              </div>
            </div>
          ) : uploading ? (
            <div className="space-y-3">
              <Upload className="mx-auto h-8 w-8 text-primary animate-pulse" />
              <div className="text-sm text-muted-foreground">
                Uploading... {uploadProgress}%
              </div>
              <div className="w-full bg-muted rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300"
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <Upload className="mx-auto h-8 w-8 text-muted-foreground" />
              <div className="text-sm text-muted-foreground mb-3">
                Upload {label}
              </div>
              <div className="flex gap-2 justify-center">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => cameraInputRef.current?.click()}
                  disabled={disabled}
                >
                  <Camera className="h-4 w-4 mr-2" />
                  Camera
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={disabled}
                >
                  <Upload className="h-4 w-4 mr-2" />
                  File
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Hidden file inputs */}
      <Input
        ref={fileInputRef}
        type="file"
        accept={acceptedTypes}
        onChange={handleFileSelect}
        className="hidden"
        disabled={disabled}
      />
      <Input
        ref={cameraInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        onChange={handleFileSelect}
        className="hidden"
        disabled={disabled}
      />
    </div>
  );
};