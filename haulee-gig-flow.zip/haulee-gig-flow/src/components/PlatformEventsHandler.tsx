import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePlatformEvents } from '@/contexts/PlatformEventsContext';
import { useAuth } from '@/contexts/AuthContext';
import { useRealtimeSync } from '@/hooks/useRealtimeSync';
import { crossTabSync } from '@/lib/crossTabSync';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

export function PlatformEventsHandler() {
  const { subscribe } = usePlatformEvents();
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  // Initialize realtime sync
  useRealtimeSync();

  // Cross-tab sync listeners
  useEffect(() => {
    const unsubLogout = crossTabSync.on('LOGOUT', () => {
      console.log('📡 Cross-tab logout detected');
      signOut();
    });

    const unsubRoleChange = crossTabSync.on('ROLE_CHANGE', async () => {
      console.log('📡 Cross-tab role change detected');
      toast({
        title: "Role Updated",
        description: "Your role has been updated. Refreshing...",
      });
      setTimeout(() => window.location.reload(), 1000);
    });

    const unsubUserDeleted = crossTabSync.on('USER_DELETED', () => {
      console.log('📡 Cross-tab user deletion detected');
      signOut();
    });

    const unsubForceReload = crossTabSync.on('FORCE_RELOAD', () => {
      console.log('📡 Cross-tab force reload detected');
      window.location.reload();
    });

    return () => {
      unsubLogout();
      unsubRoleChange();
      unsubUserDeleted();
      unsubForceReload();
    };
  }, [signOut]);

  // Platform event handlers
  useEffect(() => {
    const unsubscribers: Array<() => void> = [];

    // Handle user deletion
    unsubscribers.push(
      subscribe('AUTH_USER_DELETED', () => {
        console.log('🚨 User deleted - forcing sign out');
        crossTabSync.send('USER_DELETED');
        toast({
          title: "Account Deleted",
          description: "Your account has been deleted.",
          variant: "destructive",
        });
        signOut();
      })
    );

    // Handle deactivation
    unsubscribers.push(
      subscribe('USER_DEACTIVATED', () => {
        console.log('⚠️ User deactivated');
        toast({
          title: "Account Deactivated",
          description: "Your account has been deactivated. Redirecting...",
          variant: "destructive",
        });
        setTimeout(() => navigate('/status-and-tasks'), 1500);
      })
    );

    // Handle activation
    unsubscribers.push(
      subscribe('USER_ACTIVATED', () => {
        console.log('✅ User activated');
        toast({
          title: "Account Activated",
          description: "Your account has been activated! Redirecting to dashboard...",
        });
        setTimeout(() => window.location.reload(), 1500);
      })
    );

    // Handle role changes
    unsubscribers.push(
      subscribe('ROLE_CHANGED', async (event) => {
        console.log('🔄 Role changed:', event.payload);
        crossTabSync.send('ROLE_CHANGE', event.payload);
        
        toast({
          title: "Role Updated",
          description: `Your role has been changed. Refreshing...`,
        });

        // Refresh session to get new metadata
        await supabase.auth.refreshSession();
        
        setTimeout(() => window.location.reload(), 1500);
      })
    );

    // Handle approval
    unsubscribers.push(
      subscribe('USER_APPROVED', () => {
        console.log('✅ User approved');
        toast({
          title: "Account Approved",
          description: "Your account has been approved! Refreshing...",
        });
        setTimeout(() => window.location.reload(), 1500);
      })
    );

    // Handle session expiration
    unsubscribers.push(
      subscribe('AUTH_SESSION_EXPIRED', () => {
        console.log('⏰ Session expired');
        toast({
          title: "Session Expired",
          description: "Your session has expired. Please sign in again.",
          variant: "destructive",
        });
        signOut();
      })
    );

    // Handle token refresh
    unsubscribers.push(
      subscribe('AUTH_TOKEN_REFRESHED', async () => {
        console.log('🔄 Token refreshed - checking for metadata updates');
        // Session already refreshed, just log
      })
    );

    return () => {
      unsubscribers.forEach(unsub => unsub());
    };
  }, [subscribe, signOut, navigate, user]);

  return null;
}
