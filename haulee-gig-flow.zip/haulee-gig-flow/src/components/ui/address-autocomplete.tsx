import { useEffect, useState, useRef } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';

interface AddressAutocompleteProps {
  onAddressSelect: (address: {
    street_number?: string;
    apt_suite?: string;
    city?: string;
    state?: string;
    zip?: string;
    formatted_address?: string;
    lat?: number;
    lng?: number;
    postal_code?: string;
  }) => void;
  label?: string;
  placeholder?: string;
  required?: boolean;
  defaultValue?: string;
  value?: string;
  className?: string;
  error?: string;
  disabled?: boolean;
}

interface Suggestion {
  description: string;
  place_id: string;
}

export function AddressAutocomplete({
  onAddressSelect,
  label = "Address",
  placeholder = "Start typing your address...",
  required = false,
  defaultValue = "",
  value,
  className = "",
  error,
  disabled = false
}: AddressAutocompleteProps) {
  const [inputValue, setInputValue] = useState(value || defaultValue);
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const debounceTimeout = useRef<NodeJS.Timeout>();
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (value !== undefined) {
      setInputValue(value);
    }
  }, [value]);

  // Close suggestions when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const fetchSuggestions = async (input: string) => {
    // Validate and sanitize input
    const trimmedInput = input.trim();
    if (trimmedInput.length < 3) {
      setSuggestions([]);
      return;
    }

    // Limit input length for security
    const validatedInput = trimmedInput.slice(0, 200);

    setIsLoading(true);
    setShowSuggestions(true);
    try {
      const { data, error } = await supabase.functions.invoke('autocomplete', {
        body: { q: validatedInput },
      });

      if (error) {
        throw error;
      }

      if (data?.suggestions) {
        setSuggestions(data.suggestions);
      } else {
        setSuggestions([]);
      }
    } catch (err) {
      console.error('Error fetching suggestions:', err);
      setSuggestions([]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);

    // Debounce the API call
    if (debounceTimeout.current) {
      clearTimeout(debounceTimeout.current);
    }

    debounceTimeout.current = setTimeout(() => {
      fetchSuggestions(newValue);
    }, 300);
  };

  const handleSuggestionClick = async (suggestion: Suggestion) => {
    setInputValue(suggestion.description);
    setShowSuggestions(false);
    setSuggestions([]);

    // Fetch place details with validated place_id
    try {
      const { data, error } = await supabase.functions.invoke('place-details', {
        body: { place_id: suggestion.place_id },
      });

      if (error) throw error;
      if (data) onAddressSelect(data);
    } catch (err) {
      console.error('Error fetching place details:', err);
    }
  };

  return (
    <div className="space-y-2" ref={wrapperRef}>
      <Label htmlFor="address-autocomplete">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      <div className="relative">
        <Input
          id="address-autocomplete"
          type="text"
          placeholder={placeholder}
          value={inputValue}
          onChange={handleInputChange}
          required={required}
          className={className}
          autoComplete="off"
          disabled={disabled}
        />
        {isLoading && (
          <div className="absolute right-3 top-1/2 -translate-y-1/2">
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        )}
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute z-50 w-full mt-1 bg-background border border-border rounded-md shadow-lg max-h-60 overflow-auto">
            {suggestions.map((suggestion, index) => (
              <div
                key={suggestion.place_id || index}
                className="px-4 py-2 cursor-pointer hover:bg-accent transition-colors"
                onClick={() => handleSuggestionClick(suggestion)}
              >
                {suggestion.description}
              </div>
            ))}
          </div>
        )}
      </div>
      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
}
