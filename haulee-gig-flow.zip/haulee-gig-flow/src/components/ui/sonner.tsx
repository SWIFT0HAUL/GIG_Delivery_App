import { useTheme } from "next-themes";
import { Toaster as Sonner, toast } from "sonner";

type ToasterProps = React.ComponentProps<typeof Sonner>;

const Toaster = ({ ...props }: ToasterProps) => {
  const { theme = "system" } = useTheme();

  return (
    <Sonner
      theme={theme as ToasterProps["theme"]}
      className="toaster group"
      duration={2000}
      closeButton={true}
      richColors
      visibleToasts={5}
      toastOptions={{
        duration: 2000,
        unstyled: false,
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg transition-all duration-200",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground",
        },
      }}
      {...props}
    />
  );
};

// Wrap toast methods to enforce duration
const wrappedToast = {
  success: (message: string, data?: any) => {
    const options = { ...data, duration: data?.duration ? Math.min(data.duration, 2000) : 2000 };
    return toast.success(message, options);
  },
  error: (message: string, data?: any) => {
    const options = { ...data, duration: data?.duration ? Math.min(data.duration, 2000) : 2000 };
    return toast.error(message, options);
  },
  info: (message: string, data?: any) => {
    const options = { ...data, duration: data?.duration ? Math.min(data.duration, 2000) : 2000 };
    return toast.info(message, options);
  },
  warning: (message: string, data?: any) => {
    const options = { ...data, duration: data?.duration ? Math.min(data.duration, 2000) : 2000 };
    return toast.warning(message, options);
  },
  message: (message: string, data?: any) => {
    const options = { ...data, duration: data?.duration ? Math.min(data.duration, 2000) : 2000 };
    return toast.message(message, options);
  },
  loading: toast.loading,
  custom: toast.custom,
  dismiss: toast.dismiss,
};

export { Toaster, wrappedToast as toast };
