import React from 'react';
import { useSystemAccessValidation } from '@/hooks/useSystemAccessValidation';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ShieldAlert } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface TaskAccessGuardProps {
  taskId: string;
  action: 'view' | 'submit' | 'approve' | 'edit' | 'delete';
  children: React.ReactNode;
  fallback?: React.ReactNode;
  showAlert?: boolean;
}

export const TaskAccessGuard: React.FC<TaskAccessGuardProps> = ({
  taskId,
  action,
  children,
  fallback,
  showAlert = true,
}) => {
  const { validateTaskAccess, isSuperAdmin } = useSystemAccessValidation();
  const [hasAccess, setHasAccess] = React.useState<boolean | null>(null);
  const [reason, setReason] = React.useState<string>('');
  const [requiredPermission, setRequiredPermission] = React.useState<string>('');

  React.useEffect(() => {
    if (isSuperAdmin) {
      setHasAccess(true);
      return;
    }

    validateTaskAccess(taskId, action).then(result => {
      setHasAccess(result.hasAccess);
      setReason(result.reason || '');
      setRequiredPermission(result.requiredPermission || '');
    });
  }, [taskId, action, isSuperAdmin]);

  if (hasAccess === null) {
    return <Skeleton className="h-20 w-full" />;
  }

  if (!hasAccess) {
    return fallback || (showAlert ? (
      <Alert variant="destructive">
        <ShieldAlert className="h-4 w-4" />
        <AlertTitle>Access Denied</AlertTitle>
        <AlertDescription>
          {reason}
          {requiredPermission && (
            <p className="text-xs mt-1">Required: {requiredPermission}</p>
          )}
        </AlertDescription>
      </Alert>
    ) : null);
  }

  return <>{children}</>;
};
