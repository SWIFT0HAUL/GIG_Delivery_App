import React from 'react';
import { useSystemAccessValidation } from '@/hooks/useSystemAccessValidation';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { ShieldAlert, Lock, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

interface SystemAccessGuardProps {
  children: React.ReactNode;
  resource?: string;
  action?: 'create' | 'read' | 'update' | 'delete' | 'approve' | 'export';
  requireKYC?: boolean;
  requireApproval?: boolean;
  requireAdmin?: boolean;
  requireSuperAdmin?: boolean;
  fallback?: React.ReactNode;
  showAlert?: boolean;
  redirectOnFail?: string;
}

export const SystemAccessGuard: React.FC<SystemAccessGuardProps> = ({
  children,
  resource,
  action,
  requireKYC = false,
  requireApproval = false,
  requireAdmin = false,
  requireSuperAdmin = false,
  fallback,
  showAlert = true,
  redirectOnFail,
}) => {
  const {
    validateResourceAccess,
    validateKYCRequirement,
    isSuperAdmin,
    isAdmin,
    isApproved,
    hasAdminAccess,
  } = useSystemAccessValidation();
  const navigate = useNavigate();
  const [kycValid, setKycValid] = React.useState(true);
  const [kycChecked, setKycChecked] = React.useState(false);

  // Check KYC if required
  React.useEffect(() => {
    if (requireKYC) {
      validateKYCRequirement().then(result => {
        setKycValid(result.hasAccess);
        setKycChecked(true);
      });
    } else {
      setKycChecked(true);
    }
  }, [requireKYC]);

  // Super admin bypasses all checks
  if (isSuperAdmin) {
    return <>{children}</>;
  }

  // Check approval requirement
  if (requireApproval && !isApproved) {
    if (redirectOnFail) {
      navigate(redirectOnFail);
      return null;
    }
    
    return fallback || (showAlert ? (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>Account Not Approved</AlertTitle>
        <AlertDescription>
          Your account needs to be approved by an administrator before you can access this feature.
        </AlertDescription>
      </Alert>
    ) : null);
  }

  // Check super admin requirement
  if (requireSuperAdmin && !isSuperAdmin) {
    if (redirectOnFail) {
      navigate(redirectOnFail);
      return null;
    }
    
    return fallback || (showAlert ? (
      <Alert variant="destructive">
        <Lock className="h-4 w-4" />
        <AlertTitle>Super Admin Access Required</AlertTitle>
        <AlertDescription>
          This feature requires super administrator privileges.
        </AlertDescription>
      </Alert>
    ) : null);
  }

  // Check admin requirement
  if (requireAdmin && !hasAdminAccess) {
    if (redirectOnFail) {
      navigate(redirectOnFail);
      return null;
    }
    
    return fallback || (showAlert ? (
      <Alert variant="destructive">
        <ShieldAlert className="h-4 w-4" />
        <AlertTitle>Admin Access Required</AlertTitle>
        <AlertDescription>
          This feature requires administrator privileges.
        </AlertDescription>
      </Alert>
    ) : null);
  }

  // Check KYC requirement
  if (requireKYC && kycChecked && !kycValid) {
    if (redirectOnFail) {
      navigate(redirectOnFail);
      return null;
    }
    
    return fallback || (showAlert ? (
      <Alert variant="destructive">
        <AlertTriangle className="h-4 w-4" />
        <AlertTitle>KYC Verification Required</AlertTitle>
        <AlertDescription className="space-y-2">
          <p>You need to complete KYC verification to access this feature.</p>
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => navigate('/kyc-verification')}
          >
            Complete KYC
          </Button>
        </AlertDescription>
      </Alert>
    ) : null);
  }

  // Check resource-specific permission
  if (resource && action) {
    const result = validateResourceAccess(resource, action);
    
    if (!result.hasAccess) {
      if (redirectOnFail) {
        navigate(redirectOnFail);
        return null;
      }
      
      return fallback || (showAlert ? (
        <Alert variant="destructive">
          <ShieldAlert className="h-4 w-4" />
          <AlertTitle>Access Denied</AlertTitle>
          <AlertDescription>
            {result.reason}
            {result.requiredPermission && (
              <p className="text-xs mt-1">Required: {result.requiredPermission}</p>
            )}
          </AlertDescription>
        </Alert>
      ) : null);
    }
  }

  return <>{children}</>;
};
