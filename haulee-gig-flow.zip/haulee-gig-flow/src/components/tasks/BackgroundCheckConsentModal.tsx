import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { AlertCircle, FileSignature, Shield } from 'lucide-react';
import { toast } from 'sonner';

interface BackgroundCheckConsentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (consentData: Record<string, any>) => void;
  existingData?: Record<string, any>;
  nested?: boolean;
}

export function BackgroundCheckConsentModal({ 
  open, 
  onOpenChange, 
  onSubmit,
  existingData,
  nested = false 
}: BackgroundCheckConsentModalProps) {
  const [formData, setFormData] = useState({
    full_name: existingData?.full_name || '',
    date_of_birth: existingData?.date_of_birth || '',
    ssn_last_4: existingData?.ssn_last_4 || '',
    current_address: existingData?.current_address || '',
    city: existingData?.city || '',
    state: existingData?.state || '',
    zip_code: existingData?.zip_code || '',
    phone_number: existingData?.phone_number || '',
    email: existingData?.email || '',
    signature: existingData?.signature || '',
  });

  const [consents, setConsents] = useState({
    authorize_background_check: existingData?.authorize_background_check || false,
    certify_information_accurate: existingData?.certify_information_accurate || false,
    acknowledge_fcra_rights: existingData?.acknowledge_fcra_rights || false,
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleConsentChange = (field: string, value: boolean) => {
    setConsents(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): boolean => {
    // Check all required fields
    const requiredFields = [
      'full_name', 'date_of_birth', 'ssn_last_4', 'current_address', 
      'city', 'state', 'zip_code', 'phone_number', 'email', 'signature'
    ];

    for (const field of requiredFields) {
      if (!formData[field as keyof typeof formData]) {
        toast.error(`Please fill in ${field.replace(/_/g, ' ')}`);
        return false;
      }
    }

    // Validate SSN last 4
    if (!/^\d{4}$/.test(formData.ssn_last_4)) {
      toast.error('SSN last 4 digits must be exactly 4 numbers');
      return false;
    }

    // Validate all consents are checked
    if (!consents.authorize_background_check || !consents.certify_information_accurate || !consents.acknowledge_fcra_rights) {
      toast.error('Please acknowledge all consent statements');
      return false;
    }

    return true;
  };

  const handleSubmit = () => {
    if (!validateForm()) return;

    const consentData = {
      ...formData,
      ...consents,
      consent_timestamp: new Date().toISOString(),
      consent_ip: 'client-side', // In production, get from backend
      third_party_provider: 'Checkr',
    };

    onSubmit(consentData);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent nested={nested} className={nested ? "max-w-full h-[calc(100%-2rem)] overflow-y-auto p-0" : "max-w-4xl max-h-[90vh] p-0"}>
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-xl">Background Check Consent Form</DialogTitle>
              <DialogDescription className="text-sm mt-1">
                Powered by Checkr - Industry-leading background screening
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="px-6 py-4 max-h-[calc(90vh-200px)]">
          <div className="space-y-6">
            {/* Important Notice */}
            <Card className="border-yellow-500/30 bg-yellow-500/5">
              <CardContent className="pt-4">
                <div className="flex gap-3">
                  <AlertCircle className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div className="space-y-2 text-sm">
                    <p className="font-semibold text-yellow-900 dark:text-yellow-100">
                      Important: FCRA Disclosure & Authorization
                    </p>
                    <p className="text-yellow-800 dark:text-yellow-200 leading-relaxed">
                      This background check is conducted by <strong>Checkr, Inc.</strong>, a third-party consumer reporting agency, 
                      in accordance with the Fair Credit Reporting Act (FCRA). Your information will be used solely for employment 
                      eligibility verification purposes.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Personal Information */}
            <Card>
              <CardContent className="pt-6 space-y-4">
                <h3 className="font-semibold text-lg mb-4">Personal Information</h3>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="full_name">
                      Full Legal Name <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => handleInputChange('full_name', e.target.value)}
                      placeholder="First Middle Last"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date_of_birth">
                      Date of Birth <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="date_of_birth"
                      type="date"
                      value={formData.date_of_birth}
                      onChange={(e) => handleInputChange('date_of_birth', e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="ssn_last_4">
                      SSN (Last 4 Digits) <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="ssn_last_4"
                      maxLength={4}
                      value={formData.ssn_last_4}
                      onChange={(e) => handleInputChange('ssn_last_4', e.target.value.replace(/\D/g, ''))}
                      placeholder="1234"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone_number">
                      Phone Number <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="phone_number"
                      type="tel"
                      value={formData.phone_number}
                      onChange={(e) => handleInputChange('phone_number', e.target.value)}
                      placeholder="(555) 123-4567"
                    />
                  </div>

                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="email">
                      Email Address <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleInputChange('email', e.target.value)}
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>

                <h4 className="font-semibold mt-6 mb-3">Current Address</h4>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2 md:col-span-2">
                    <Label htmlFor="current_address">
                      Street Address <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="current_address"
                      value={formData.current_address}
                      onChange={(e) => handleInputChange('current_address', e.target.value)}
                      placeholder="123 Main Street, Apt 4B"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="city">
                      City <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => handleInputChange('city', e.target.value)}
                      placeholder="New York"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="state">
                      State <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="state"
                      maxLength={2}
                      value={formData.state}
                      onChange={(e) => handleInputChange('state', e.target.value.toUpperCase())}
                      placeholder="NY"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="zip_code">
                      ZIP Code <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="zip_code"
                      value={formData.zip_code}
                      onChange={(e) => handleInputChange('zip_code', e.target.value)}
                      placeholder="10001"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Consent Statements */}
            <Card className="border-primary/30">
              <CardContent className="pt-6 space-y-4">
                <h3 className="font-semibold text-lg mb-4">Consent & Authorization</h3>
                
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 rounded-lg bg-muted/50">
                    <Checkbox
                      id="authorize_background_check"
                      checked={consents.authorize_background_check}
                      onCheckedChange={(v) => handleConsentChange('authorize_background_check', Boolean(v))}
                      className="mt-1"
                    />
                    <label htmlFor="authorize_background_check" className="text-sm leading-relaxed cursor-pointer">
                      <strong>I authorize Checkr, Inc.</strong> to conduct a comprehensive background check, which may include 
                      criminal records, driving records, employment verification, education verification, and other relevant 
                      information necessary for employment eligibility.
                    </label>
                  </div>

                  <div className="flex items-start space-x-3 p-4 rounded-lg bg-muted/50">
                    <Checkbox
                      id="certify_information_accurate"
                      checked={consents.certify_information_accurate}
                      onCheckedChange={(v) => handleConsentChange('certify_information_accurate', Boolean(v))}
                      className="mt-1"
                    />
                    <label htmlFor="certify_information_accurate" className="text-sm leading-relaxed cursor-pointer">
                      <strong>I certify</strong> that all information provided above is true, accurate, and complete to the 
                      best of my knowledge. I understand that any false or misleading information may result in 
                      disqualification from employment.
                    </label>
                  </div>

                  <div className="flex items-start space-x-3 p-4 rounded-lg bg-muted/50">
                    <Checkbox
                      id="acknowledge_fcra_rights"
                      checked={consents.acknowledge_fcra_rights}
                      onCheckedChange={(v) => handleConsentChange('acknowledge_fcra_rights', Boolean(v))}
                      className="mt-1"
                    />
                    <label htmlFor="acknowledge_fcra_rights" className="text-sm leading-relaxed cursor-pointer">
                      <strong>I acknowledge</strong> that I have received and reviewed the "Summary of Your Rights Under 
                      the Fair Credit Reporting Act" and understand my rights regarding consumer reports obtained for 
                      employment purposes.
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Digital Signature */}
            <Card className="border-primary/30">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <FileSignature className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold text-lg">Digital Signature</h3>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="signature">
                      Type your full legal name to sign <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="signature"
                      value={formData.signature}
                      onChange={(e) => handleInputChange('signature', e.target.value)}
                      placeholder="Type your full name"
                      className="font-serif text-lg"
                    />
                    <p className="text-xs text-muted-foreground">
                      By typing your name above, you are providing a legally binding electronic signature 
                      equivalent to a handwritten signature.
                    </p>
                  </div>

                  <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded">
                    <p>
                      <strong>Date:</strong> {new Date().toLocaleDateString('en-US', { 
                        month: 'long', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="flex justify-between items-center gap-3 px-6 py-4 border-t bg-muted/30">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            className="gap-2 bg-gradient-to-r from-primary to-primary/80"
          >
            <FileSignature className="h-4 w-4" />
            Submit Consent Form
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
