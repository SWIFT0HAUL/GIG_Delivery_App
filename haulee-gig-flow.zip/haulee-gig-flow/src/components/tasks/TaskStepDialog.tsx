import { useState, useMemo, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Combobox } from '@/components/ui/combobox';
import { ArrowRight, ExternalLink, Upload, CheckCircle2, FileText, FileSignature } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';
import { BackgroundCheckConsentModal } from './BackgroundCheckConsentModal';
import { usePlatformSettings } from '@/contexts/PlatformSettingsContext';

export interface TaskStepField {
  field_name: string;
  field_type: 'text' | 'textarea' | 'file_upload' | 'number' | 'date' | 'select' | 'combobox';
  field_label: string;
  required: boolean;
  accept?: string;
  bucket_name?: string;
  folder?: string;
  placeholder?: string;
  options?: { value: string; label: string }[] | string[];
  depends_on?: string;
  options_by_make?: Record<string, string[]>;
}

export interface TaskStep {
  step_number: number;
  step_name: string;
  step_description: string;
  path: string;
  is_optional: boolean;
  step_type?: 'informational' | 'data_collection';
  fields?: TaskStepField[];
}

interface TaskStepDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  step: TaskStep | null;
  taskId: string;
  onStepComplete: () => void;
  hasNextStep?: boolean;
  onNavigateNext?: () => void;
  totalSteps?: number;
  onTaskAutoCompleted?: () => void;
  taskName?: string;
  nested?: boolean;
}

export function TaskStepDialog({ 
  open, 
  onOpenChange, 
  step, 
  taskId, 
  onStepComplete,
  hasNextStep = false,
  onNavigateNext,
  totalSteps,
  onTaskAutoCompleted,
  taskName,
  nested = false
}: TaskStepDialogProps) {
  const { user } = useAuth();
  const { settings } = usePlatformSettings();
  const [confirmed, setConfirmed] = useState(false);
  const [notes, setNotes] = useState('');
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [uploading, setUploading] = useState<Record<string, boolean>>({});
  const [submitting, setSubmitting] = useState(false);
  const [showConsentModal, setShowConsentModal] = useState(false);

  const isExternal = useMemo(() => !!step?.path && step.path.startsWith('http'), [step]);
  const isDataCollection = useMemo(() => step?.step_type === 'data_collection', [step]);
  const isInformational = useMemo(() => !step?.step_type || step?.step_type === 'informational', [step]);

  useEffect(() => {
    if (open && step) {
      // Reset form when dialog opens
      setConfirmed(false);
      setNotes('');
      setFormData({});
      
      // Load existing submission if any
      loadExistingSubmission();
    }
  }, [open, step]);

  const loadExistingSubmission = async () => {
    if (!user || !step) return;

    try {
      const { data, error } = await supabase
        .from('task_step_submissions')
        .select('*')
        .eq('user_id', user.id)
        .eq('task_id', taskId)
        .eq('step_number', step.step_number)
        .maybeSingle();

      if (error) throw error;
      
      if (data) {
        setFormData((data.submission_data as Record<string, any>) || {});
        setNotes(data.notes || '');
        setConfirmed(true);
      }
    } catch (error) {
      console.error('Error loading submission:', error);
    }
  };

  const handleFileUpload = async (fieldName: string, file: File, field: TaskStepField) => {
    if (!user) {
      toast.error('You must be logged in to upload files');
      return;
    }

    // Validate file size (20MB limit)
    if (file.size > 20 * 1024 * 1024) {
      toast.error('File size must be less than 20MB');
      return;
    }

    setUploading(prev => ({ ...prev, [fieldName]: true }));

    try {
      const bucketName = field.bucket_name || 'task-submissions';
      const folder = field.folder || 'documents';
      const fileExt = file.name.split('.').pop();
      const fileName = `${folder}/${user.id}/${taskId}/${step?.step_number}/${fieldName}_${Date.now()}.${fileExt}`;

      const { data, error } = await supabase.storage
        .from(bucketName)
        .upload(fileName, file, { upsert: true });

      if (error) throw error;

      // Store the storage path (not the full URL) so we can generate signed URLs later
      setFormData(prev => ({ ...prev, [fieldName]: data.path }));
      toast.success('File uploaded successfully');
    } catch (error: any) {
      console.error('Upload error:', error);
      toast.error(error.message || 'Failed to upload file');
    } finally {
      setUploading(prev => ({ ...prev, [fieldName]: false }));
    }
  };

  const handleInputChange = (fieldName: string, value: any) => {
    setFormData((prev) => {
      const newData = { ...prev, [fieldName]: value };
      
      // If changing vehicle_make, clear vehicle_model
      if (fieldName === 'vehicle_make' && prev.vehicle_model) {
        newData.vehicle_model = '';
      }
      
      return newData;
    });
  };

  const validateForm = (): boolean => {
    if (isDataCollection && step?.fields) {
      for (const field of step.fields) {
        if (field.required && !formData[field.field_name]) {
          toast.error(`${field.field_label} is required`);
          return false;
        }
      }
    }
    return true;
  };

  const handleSubmit = async () => {
    if (!user || !step) return;

    if (isDataCollection && !validateForm()) {
      return;
    }

    if (isInformational && !confirmed) {
      toast.error('Please confirm you have read the instructions');
      return;
    }

    setSubmitting(true);

    try {
      const { error } = await supabase
        .from('task_step_submissions')
        .upsert({
          user_id: user.id,
          task_id: taskId,
          step_number: step.step_number,
          submission_data: isDataCollection ? formData : {},
          notes: notes,
          status: 'submitted'
        }, {
          onConflict: 'user_id,task_id,step_number'
        });

      if (error) throw error;

      // Handle conditional step skipping for payment method selection
      if (step.step_number === 2 && formData.payment_method) {
        // Auto-skip the step that wasn't selected
        const stepToSkip = formData.payment_method === 'direct_deposit' ? 4 : 3;
        
        // Mark the skipped step as completed with a note
        await supabase
          .from('task_step_submissions')
          .upsert({
            user_id: user.id,
            task_id: taskId,
            step_number: stepToSkip,
            submission_data: { skipped: true, reason: `User selected ${formData.payment_method}` },
            notes: 'Auto-skipped based on payment method selection',
            status: 'submitted'
          }, {
            onConflict: 'user_id,task_id,step_number'
          });

        toast.success(`Step completed successfully. ${formData.payment_method === 'direct_deposit' ? 'Banking information' : 'Debit card information'} step selected.`);
      } else {
        toast.success('Step completed successfully');
      }

      // Auto-complete task if all steps are done
      if (totalSteps) {
        const { data: allSubmissions } = await supabase
          .from('task_step_submissions')
          .select('step_number')
          .eq('user_id', user.id)
          .eq('task_id', taskId);

        if (allSubmissions && allSubmissions.length === totalSteps) {
          // All steps completed - auto-complete the task
          const { error: updateError } = await supabase
            .from('task_assignments')
            .update({
              status: 'completed',
              completed_at: new Date().toISOString(),
              approval_status: 'pending_approval',
              updated_at: new Date().toISOString()
            })
            .eq('task_id', taskId)
            .eq('user_id', user.id);

          if (!updateError) {
            toast.success('Task auto-completed! Awaiting admin approval.');
            onTaskAutoCompleted?.();
            onOpenChange(false);
            return;
          }
        }
      }

      onStepComplete();
      
      // Don't close if navigating to next step
      if (!hasNextStep || !onNavigateNext) {
        onOpenChange(false);
      }
    } catch (error: any) {
      console.error('Submission error:', error);
      toast.error(error.message || 'Failed to submit step');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConsentSubmit = (consentData: Record<string, any>) => {
    setFormData(prev => ({ ...prev, consent_agreement: consentData }));
    toast.success('Consent form completed successfully');
  };

  const isBackgroundCheckConsentStep = 
    taskName === 'Complete Background Check' && 
    step?.step_number === 2 && 
    step?.step_type === 'data_collection';

  const isBackgroundCheckStep3 = 
    taskName === 'Complete Background Check' && 
    step?.step_number === 3;

  const renderField = (field: TaskStepField) => {
    const value = formData[field.field_name];
    const isUploading = uploading[field.field_name];

    // Special handling for background check consent form
    if (isBackgroundCheckConsentStep && field.field_type === 'file_upload' && field.field_name === 'consent_agreement') {
      return (
        <div key={field.field_name} className="space-y-3">
          <Label>
            {field.field_label} {field.required && <span className="text-destructive">*</span>}
          </Label>
          <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
            <CardContent className="pt-4 space-y-3">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <FileSignature className="h-4 w-4" />
                <p>Complete the digital consent form powered by Checkr</p>
              </div>
              <Button
                type="button"
                variant="default"
                onClick={() => setShowConsentModal(true)}
                className="w-full gap-2"
              >
                <FileSignature className="h-4 w-4" />
                {formData.consent_agreement ? 'View/Edit Consent Form' : 'Fill Out Consent Form'}
              </Button>
              {formData.consent_agreement && (
                <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                  <CheckCircle2 className="h-4 w-4" />
                  <span>Consent form completed</span>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    switch (field.field_type) {
      case 'file_upload':
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                disabled={isUploading}
                onClick={() => {
                  const input = document.createElement('input');
                  input.type = 'file';
                  input.accept = field.accept || '*';
                  input.onchange = (e: any) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(field.field_name, file, field);
                  };
                  input.click();
                }}
                className="w-full"
              >
                <Upload className="h-4 w-4 mr-2" />
                {isUploading ? 'Uploading...' : value ? 'Change File' : 'Upload File'}
              </Button>
              {value && (
                <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
              )}
            </div>
          </div>
        );

      case 'textarea':
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Textarea
              value={value || ''}
              onChange={(e) => handleInputChange(field.field_name, e.target.value)}
              placeholder={field.placeholder}
            />
          </div>
        );

      case 'number':
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              type="number"
              value={value || ''}
              onChange={(e) => handleInputChange(field.field_name, e.target.value)}
              placeholder={field.placeholder}
            />
          </div>
        );

      case 'date':
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              type="date"
              value={value || ''}
              onChange={(e) => handleInputChange(field.field_name, e.target.value)}
            />
          </div>
        );

      case 'combobox':
        // Handle dependent field filtering (e.g., vehicle_model depends on vehicle_make)
        let availableOptions: string[] = [];
        
        if (field.depends_on && field.options_by_make) {
          const dependentValue = formData[field.depends_on];
          availableOptions = dependentValue ? (field.options_by_make[dependentValue] || []) : [];
        } else if (field.options) {
          availableOptions = Array.isArray(field.options) ? field.options.map(opt => 
            typeof opt === 'string' ? opt : opt.value
          ) : [];
        }
        
        const comboboxOptions = availableOptions.map((option) => ({
          value: option,
          label: option
        }));
        
        const isDisabled = field.depends_on && !formData[field.depends_on];
        
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Combobox
              options={comboboxOptions}
              value={value || ''}
              onValueChange={(val) => handleInputChange(field.field_name, val)}
              placeholder={isDisabled ? field.placeholder : 'Search or select...'}
              searchPlaceholder="Search..."
              emptyText="No results found."
              disabled={isDisabled}
            />
          </div>
        );

      case 'select':
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Select value={value || ''} onValueChange={(val) => handleInputChange(field.field_name, val)}>
              <SelectTrigger>
                <SelectValue placeholder={field.placeholder || 'Select an option'} />
              </SelectTrigger>
              <SelectContent className="z-[100] bg-popover">
                {field.options?.map((option) => {
                  const optionValue = typeof option === 'string' ? option : option.value;
                  const optionLabel = typeof option === 'string' ? option : option.label;
                  return (
                    <SelectItem key={optionValue} value={optionValue}>
                      {optionLabel}
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </div>
        );

      case 'text':
      default:
        return (
          <div key={field.field_name} className="space-y-2">
            <Label>
              {field.field_label} {field.required && <span className="text-destructive">*</span>}
            </Label>
            <Input
              type="text"
              value={value || ''}
              onChange={(e) => handleInputChange(field.field_name, e.target.value)}
              placeholder={field.placeholder}
            />
          </div>
        );
    }
  };

  if (!step) return null;

  return (
    <Dialog open={open} onOpenChange={(v) => { 
      setConfirmed(false); 
      setNotes(''); 
      setFormData({});
      onOpenChange(v); 
    }}>
      <DialogContent nested={nested} className={nested ? "max-w-full h-[calc(100%-2rem)] overflow-y-auto" : "max-w-[calc(100%-1rem)] sm:max-w-2xl md:max-w-4xl lg:max-w-6xl max-h-[90vh] overflow-hidden p-0"}>
        {/* Header with gradient */}
        <div className="bg-gradient-to-r from-primary/10 via-primary/5 to-transparent px-6 pt-2 pb-2 border-b">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Badge variant={step.is_optional ? 'outline' : 'default'} className="px-2 py-0.5 text-sm">
                Step {step.step_number}
              </Badge>
              <span className="text-lg font-bold">{step.step_name}</span>
            </DialogTitle>
            <DialogDescription className="mt-0.5 flex items-center gap-2 text-xs">
              {isInformational ? (
                <>
                  <FileText className="w-4 h-4" />
                  Review the information below and confirm when ready
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  Complete the required fields below
                </>
              )}
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="space-y-4 px-6 py-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          {step.step_description && (
            <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
              <CardContent className="pt-4">
                <p className="text-sm text-foreground/80 leading-relaxed">{step.step_description}</p>
              </CardContent>
            </Card>
          )}

          {/* Special handling for Background Check Step 3 - Redirect to Checkr + Form */}
          {isBackgroundCheckStep3 && (
            <>
              <Card className="border-primary/30 bg-gradient-to-br from-primary/5 to-transparent">
                <CardContent className="space-y-4 pt-6">
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <ExternalLink className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Complete Your Background Check on Checkr</p>
                        <p className="text-sm text-muted-foreground">
                          Click the button below to be redirected to Checkr's secure portal where you'll complete your background check. 
                          After completing it on Checkr, return here and fill in the confirmation details below.
                        </p>
                      </div>
                    </div>
                    <Button
                      type="button"
                      variant="default"
                      onClick={() => window.open(settings.checkrPortalUrl || 'https://candidate.checkr.com', '_blank')}
                      className="w-full gap-2"
                    >
                      <ExternalLink className="h-4 w-4" />
                      Go to Checkr Portal
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Confirmation fields after Checkr completion */}
              {step.fields && step.fields.length > 0 && (
                <Card className="border-primary/30">
                  <CardContent className="space-y-4 pt-6">
                    <p className="text-sm font-medium mb-4">After completing your background check on Checkr, please provide the following information:</p>
                    {step.fields.map(field => renderField(field))}
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {/* Data collection fields for all other steps */}
          {isDataCollection && step.fields && !isBackgroundCheckStep3 && (
            <Card className="border-primary/30">
              <CardContent className="space-y-4 pt-6">
                {step.fields.map(field => renderField(field))}
              </CardContent>
            </Card>
          )}

          {/* Confirmation checkbox for informational steps */}
          {isInformational && (
            <Card className="border-green-500/30 bg-gradient-to-br from-green-500/5 to-transparent">
              <CardContent className="pt-4">
                <div className="flex items-start space-x-3">
                  <Checkbox 
                    id="confirm" 
                    checked={confirmed} 
                    onCheckedChange={(v) => setConfirmed(Boolean(v))}
                    className="mt-1"
                  />
                  <label 
                    htmlFor="confirm" 
                    className="text-sm leading-relaxed cursor-pointer select-none"
                  >
                    I confirm I have reviewed this information and understand the requirements
                  </label>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Notes section */}
          <Card className="border-primary/20">
            <CardContent className="pt-4 space-y-2">
              <Label className="flex items-center gap-2 text-sm font-medium">
                <FileText className="w-4 h-4" />
                Additional Notes (optional)
              </Label>
              <Textarea 
                value={notes} 
                onChange={(e) => setNotes(e.target.value)} 
                placeholder="Add any relevant notes or questions for admin review..." 
                className="min-h-[80px]"
              />
            </CardContent>
          </Card>
        </div>

        {/* Footer with actions */}
        <div className="flex justify-between items-center gap-3 px-6 py-4 border-t bg-gradient-to-r from-muted/50 to-transparent">
          <Button variant="outline" onClick={() => onOpenChange(false)} className="hover:bg-muted">
            Close
          </Button>
          <div className="flex gap-2">
            {hasNextStep && onNavigateNext ? (
              <Button 
                disabled={
                  submitting || 
                  (isInformational && !confirmed) ||
                  (isDataCollection && Object.values(uploading).some(v => v))
                } 
                onClick={async () => {
                  await handleSubmit();
                  if (!submitting) {
                    // After completing step 2 (payment method selection), navigate appropriately
                    if (step && step.step_number === 2 && formData.payment_method) {
                      // Close dialog and let user click on the next relevant step
                      onOpenChange(false);
                      toast.info(
                        formData.payment_method === 'direct_deposit' 
                          ? 'Now complete the Banking Information step' 
                          : 'Now complete the Debit Card Information step'
                      );
                    } else {
                      setTimeout(() => onNavigateNext(), 500);
                    }
                  }
                }}
                className="gap-2 bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70"
              >
                {submitting ? 'Submitting...' : (
                  <>
                    Continue
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </Button>
            ) : (
              <Button 
                disabled={
                  submitting || 
                  (isInformational && !confirmed) ||
                  (isDataCollection && Object.values(uploading).some(v => v))
                } 
                onClick={handleSubmit}
                className="gap-2 bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700"
              >
                {submitting ? 'Submitting...' : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    Complete Step
                  </>
                )}
              </Button>
            )}
          </div>
        </div>
      </DialogContent>

      {/* Background Check Consent Modal */}
      <BackgroundCheckConsentModal
        open={showConsentModal}
        onOpenChange={setShowConsentModal}
        onSubmit={handleConsentSubmit}
        existingData={formData.consent_agreement}
        nested={nested}
      />
    </Dialog>
  );
}
