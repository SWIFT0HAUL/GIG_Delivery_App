import { useState, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Upload, File, X, Camera } from "lucide-react";

interface TaskFileUploadProps {
  taskId: string;
  userId: string;
  fieldName: string;
  currentFileUrl?: string;
  onFileUploaded: (url: string) => void;
  disabled?: boolean;
  required?: boolean;
  label?: string;
  isAvatar?: boolean;
}

export function TaskFileUpload({
  taskId,
  userId,
  fieldName,
  currentFileUrl,
  onFileUploaded,
  disabled = false,
  required = false,
  label = "Upload File",
  isAvatar = false,
}: TaskFileUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [fileUrl, setFileUrl] = useState(currentFileUrl || "");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      toast.error("File size must be less than 10MB");
      return;
    }

    setUploading(true);
    try {
      const fileExt = file.name.split(".").pop();
      const fileName = `${fieldName}_${Date.now()}.${fileExt}`;
      const filePath = `${taskId}/${userId}/${fileName}`;

      // Upload to Supabase Storage
      const { error: uploadError } = await supabase.storage
        .from("task_uploads")
        .upload(filePath, file, {
          cacheControl: "3600",
          upsert: false,
        });

      if (uploadError) throw uploadError;

      // Get public URL
      const { data } = supabase.storage
        .from("task_uploads")
        .getPublicUrl(filePath);

      const publicUrl = data.publicUrl;
      setFileUrl(publicUrl);
      onFileUploaded(publicUrl);
      
      toast.success("File uploaded successfully");
    } catch (error: any) {
      console.error("Error uploading file:", error);
      toast.error("Failed to upload file");
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveFile = () => {
    setFileUrl("");
    onFileUploaded("");
  };

  const handleCameraClick = () => {
    cameraInputRef.current?.click();
  };

  const handleFileClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-2">
      {fileUrl ? (
        isAvatar ? (
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-border bg-muted">
                <img
                  src={fileUrl}
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </div>
              {!disabled && (
                <Button
                  type="button"
                  variant="destructive"
                  size="icon"
                  onClick={handleRemoveFile}
                  className="absolute -top-2 -right-2 rounded-full h-8 w-8"
                >
                  <X className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        ) : (
          <div className="flex items-start gap-2 p-3 border rounded-md bg-muted/50">
            <File className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
            <a
              href={fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm flex-1 hover:underline break-all overflow-wrap-anywhere min-w-0"
            >
              {fileUrl.split("/").pop()}
            </a>
            {!disabled && (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={handleRemoveFile}
                className="flex-shrink-0"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
        )
      ) : (
        <div className="space-y-2">
          {isAvatar && (
            <div className="flex justify-center mb-4">
              <div className="w-32 h-32 rounded-full border-4 border-dashed border-muted-foreground/25 flex items-center justify-center bg-muted/50">
                <Upload className="h-8 w-8 text-muted-foreground/50" />
              </div>
            </div>
          )}
          
          <div className="flex gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={handleFileClick}
              disabled={uploading || disabled}
              className="flex-1 gap-2"
            >
              <Upload className="h-4 w-4" />
              Upload
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={handleCameraClick}
              disabled={uploading || disabled}
              className="flex-1 gap-2"
            >
              <Camera className="h-4 w-4" />
              Camera
            </Button>
          </div>
          
          {/* Hidden file inputs */}
          <Input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleFileUpload}
            disabled={uploading || disabled}
            required={required}
            className="hidden"
          />
          <Input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            disabled={uploading || disabled}
            required={required}
            className="hidden"
          />
          
          {uploading && (
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-primary"></div>
              <span>Uploading...</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
