import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { ArrowLeft, Save, Send } from "lucide-react";
import { TaskFileUpload } from "./TaskFileUpload";
import { MFASetupForm } from "@/components/admin/onboarding/forms/MFASetupForm";
import { getTaskFormSchema } from "@/schemas/taskFormSchemas";
import { getModelsForMake, VEHICLE_MODELS } from "@/lib/vehicleModels";
import { ALL_VEHICLE_TYPES, VEHICLE_COLORS } from "@/lib/vehicleConfig";

interface FormField {
  label: string;
  name: string;
  type: "text" | "number" | "textarea" | "select" | "checkbox" | "checkbox-group" | "date" | "file" | "link" | "file_or_link" | "vehicle-list";
  required?: boolean;
  options?: string[];
  placeholder?: string;
  url?: string;
  show_when?: {
    field: string;
    value: string;
  };
  validation?: {
    pattern?: string;
    minLength?: number;
    maxLength?: number;
    patternMessage?: string;
  };
  disabled?: boolean;
}

interface TaskFormSchema {
  layout?: { columns?: number };
  fields: FormField[];
}

interface DynamicTaskFormProps {
  taskId: string;
  onBack: () => void;
}

export function DynamicTaskForm({ taskId, onBack }: DynamicTaskFormProps) {
  const { user } = useAuth();
  const [task, setTask] = useState<any>(null);
  const [formSchema, setFormSchema] = useState<TaskFormSchema | null>(null);
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [isReadOnly, setIsReadOnly] = useState(false);
  const [isSubmitDisabled, setIsSubmitDisabled] = useState(true);
  const [fileOrLinkMode, setFileOrLinkMode] = useState<Record<string, 'file' | 'link'>>({});
  const [vehicles, setVehicles] = useState<any[]>([]);

  useEffect(() => {
    if (taskId && user) {
      console.log("🔄 Loading task and responses for taskId:", taskId);
      loadTask();
      loadResponses();
    }
  }, [taskId, user]);

  // Sync vehicles state with formValues when vehicle-list data changes
  useEffect(() => {
    if (!formSchema) return;
    
    // Find vehicle-list fields and sync their values to vehicles state
    const vehicleListFields = formSchema.fields.filter(f => f.type === "vehicle-list");
    vehicleListFields.forEach(field => {
      const value = formValues[field.name];
      if (Array.isArray(value) && value.length > 0) {
        setVehicles(value);
      }
    });
  }, [formValues, formSchema]);

  // Validate form whenever formValues or formSchema changes
  useEffect(() => {
    if (formSchema) {
      validateForm(formValues);
    }
  }, [formValues, formSchema]);

  // Initialize checkbox fields to boolean false and checkbox-group to empty arrays
  // Only set defaults if field doesn't already have a value (to preserve loaded data)
  useEffect(() => {
    if (!formSchema) return;
    console.log("🔧 Initializing defaults, current formValues:", formValues);
    setFormValues((prev) => {
      const next = { ...prev } as Record<string, any>;
      let changedCount = 0;
      formSchema.fields.forEach((field) => {
        if (field.type === "checkbox") {
          const name = field.name;
          // Only set default if the field has never been set (undefined)
          if (!(name in next)) {
            next[name] = false;
            changedCount++;
          }
        } else if (field.type === "checkbox-group") {
          const name = field.name;
          // Only set default if the field has never been set (undefined)
          if (!(name in next)) {
            next[name] = [];
            changedCount++;
          }
        }
      });
      console.log(`🔧 Set ${changedCount} default values, final values:`, next);
      return next;
    });
  }, [formSchema]);

  const loadTask = async () => {
    try {
      // First try custom_tasks (existing system)
      const { data: customData, error: customError } = await supabase
        .from("custom_tasks" as any)
        .select("id, name, category, description, task_form_schema, status")
        .eq("id", taskId)
        .maybeSingle();

      let taskData: any = null;

      if (!customError && customData) {
        // Map custom_tasks fields to expected format
        taskData = {
          id: (customData as any).id,
          task_name: (customData as any).name,
          task_category: (customData as any).category,
          task_description: (customData as any).description,
          task_form_schema: (customData as any).task_form_schema,
          status: (customData as any).status || 'Pending',
        };
      } else {
        // If not found, try tasks table (new system)
        const { data: tasksData, error: tasksError } = await supabase
          .from("tasks" as any)
          .select("*")
          .eq("id", taskId)
          .maybeSingle();
        
        if (tasksError) throw tasksError;
        taskData = tasksData;
      }

      if (!taskData) throw new Error("Task not found");

      setTask(taskData);
      // Read-only if Completed, but allow editing if reopened as "Action Required"
      const status = taskData.status;
      setIsReadOnly(status === "Completed");

      // Parse form schema - first check database, then fall back to predefined schemas
      let schema: TaskFormSchema | null = null;
      
      if (taskData.task_form_schema) {
        try {
          schema = typeof taskData.task_form_schema === 'string' 
            ? JSON.parse(taskData.task_form_schema) 
            : taskData.task_form_schema;
          
          // Fix insurance_provider field if it's incorrectly set as text
          if (schema?.fields) {
            const newFields: FormField[] = [];
            schema.fields.forEach(field => {
              if (field.name === 'insurance_provider' && field.type === 'text') {
                // Convert to select
                newFields.push({
                  ...field,
                  type: 'select' as const,
                  options: [
                    "State Farm", "Geico", "Progressive", "Allstate", "USAA",
                    "Liberty Mutual", "Farmers", "Nationwide", "American Family",
                    "Travelers", "AAA", "Mercury", "Safeco", "The Hartford",
                    "Esurance", "MetLife", "Kemper", "The General", "Bristol West",
                    "Dairyland", "National General", "Other"
                  ]
                });
                // Add conditional "Other" text field
                newFields.push({
                  label: "Please specify insurance provider",
                  name: "insurance_provider_other",
                  type: "text" as const,
                  required: true,
                  placeholder: "Enter insurance provider name",
                  show_when: {
                    field: "insurance_provider",
                    value: "Other"
                  }
                });
              } else if (field.name === 'insurance_provider' && field.type === 'select') {
                // Already a select, just add the conditional field after it
                newFields.push(field);
                // Check if the "other" field doesn't already exist
                const hasOtherField = schema.fields.some(f => f.name === 'insurance_provider_other');
                if (!hasOtherField) {
                  newFields.push({
                    label: "Please specify insurance provider",
                    name: "insurance_provider_other",
                    type: "text" as const,
                    required: true,
                    placeholder: "Enter insurance provider name",
                    show_when: {
                      field: "insurance_provider",
                      value: "Other"
                    }
                  });
                }
              } else if (field.name === 'coverage_type' && field.type === 'select') {
                // Convert coverage_type to checkbox-group for multiple selection
                newFields.push({
                  ...field,
                  type: 'checkbox-group' as const
                });
              } else if ((field.name === 'vehicle_type' || field.name === 'vehicle_types' || field.name === 'vehicle_list') && (field.type === 'text' || field.type === 'select' || field.type === 'textarea')) {
                // Replace with vehicle list component
                newFields.push({
                  label: field.label || "Vehicle Information",
                  name: field.name,
                  type: "vehicle-list" as const,
                  required: field.required
                });
              } else if (field.name === 'fleet_insurance') {
                // Skip fleet_insurance field - removed per user request
              } else {
                newFields.push(field);
              }
            });
            // Normalize file upload field types
            schema.fields = newFields.map((f: any) =>
              (f.type === 'file_upload' || f.type === 'upload') ? { ...f, type: 'file' } : f
            );
          }
        } catch (e) {
          console.warn("Failed to parse task_form_schema from database:", e);
        }
      }
      
      // If no schema in database, try to load from predefined schemas
      if (!schema && taskData.task_name) {
        const predefinedSchema = getTaskFormSchema(taskData.task_name);
        if (predefinedSchema) {
          // Convert multi-step schema to single-page form
          schema = {
            layout: { columns: 1 },
            fields: predefinedSchema.flatMap((step: any) => {
              const stepFields = step.fields || [];
              // If step has conditional_display, apply it to all fields in this step
              if (step.conditional_display) {
                return stepFields.map((field: any) => ({
                  ...field,
                  show_when: {
                    field: step.conditional_display.field,
                    value: step.conditional_display.values // Pass all values
                  }
                }));
              }
              return stepFields;
            }).filter((field: any) => field)
            .map((field: any) => ({
              name: field.field_name,
              type: (field.field_type === 'file_upload' || field.field_type === 'upload') ? 'file' : field.field_type,
              label: field.field_label,
              required: field.required,
              options: field.options,
              placeholder: field.placeholder,
              url: field.url,
              show_when: field.show_when,
              validation: field.validation,
              disabled: field.disabled
            }))
          };
        }
      }
      
      // Ensure profile photo field exists for profile completion tasks
      if (schema && taskData.task_name && ["Complete Profile Information", "Profile Completion"].includes(taskData.task_name)) {
        const hasProfilePhoto = schema.fields.some((f: any) => f.name === 'profile_photo');
        if (!hasProfilePhoto) {
          schema.fields.unshift({ name: 'profile_photo', type: 'file', label: 'Profile Photo', required: true });
        }
      }
      
      if (schema) {
        setFormSchema(schema);
      } else {
        toast.error("This task's form isn't configured yet.");
      }
    } catch (error: any) {
      console.error("Error loading task:", error);
      toast.error("Failed to load task");
    } finally {
      setLoading(false);
    }
  };

  const loadResponses = async () => {
    try {
      const { data, error } = await supabase
        .from("task_responses" as any)
        .select("*")
        .eq("task_id", taskId)
        .eq("user_id", user?.id);

      if (error) throw error;

      const values: Record<string, any> = {};
      
      data?.forEach((response: any) => {
        // Skip loading certification/agreement checkboxes - they should always start unchecked
        if (response.field_type === "checkbox" && 
            (response.field_name === "certification" || 
             response.field_name === "agree_terms" ||
             response.field_label?.toLowerCase().includes("certify") ||
             response.field_label?.toLowerCase().includes("agree"))) {
          return; // Skip this field
        }
        
        if (response.field_type === "checkbox") {
          values[response.field_name] = response.field_value === "true";
        } else if (response.field_type === "checkbox-group") {
          try {
            values[response.field_name] = JSON.parse(response.field_value);
          } catch {
            values[response.field_name] = [];
          }
        } else if (response.field_type === "vehicle-list") {
          try {
            const parsed = JSON.parse(response.field_value);
            values[response.field_name] = parsed;
            setVehicles(parsed);
          } catch {
            values[response.field_name] = [];
            setVehicles([]);
          }
        } else if (response.field_type === "file") {
          values[response.field_name] = response.uploaded_file_url;
        } else {
          values[response.field_name] = response.field_value;
        }
      });
      
      console.log("✅ Loaded responses from DB:", values);
      setFormValues(values);
    } catch (error: any) {
      console.error("Error loading responses:", error);
    }
  };

  const handleFieldChange = (fieldName: string, value: any, fieldType: string, fieldLabel: string) => {
    setFormValues((prev) => {
      const newValues = { ...prev, [fieldName]: value };
      
      // If vehicle_make changes, clear vehicle_model
      if (fieldName === 'vehicle_make') {
        newValues.vehicle_model = '';
      }
      
      return newValues;
    });
    
    // Autosave after 5 seconds of no changes
    if (!isReadOnly) {
      setTimeout(() => {
        saveFieldResponse(fieldName, value, fieldType, fieldLabel);
      }, 5000);
    }
  };

  // Helper function to check if a field should be shown
  const shouldShowField = (field: FormField): boolean => {
    if (!field.show_when) return true;
    
    const conditionField = field.show_when.field;
    const conditionValue = field.show_when.value;
    const currentValue = formValues[conditionField];
    
    // Handle both string and array comparison
    if (Array.isArray(conditionValue)) {
      return conditionValue.some(val => String(currentValue) === String(val));
    }
    
    return String(currentValue) === String(conditionValue);
  };

  // Get visible fields based on conditional logic
  const getVisibleFields = (): FormField[] => {
    if (!formSchema) return [];
    return formSchema.fields.filter(shouldShowField);
  };

  // Real-time validation for submit button
  const validateForm = (values: Record<string, any>) => {
    if (!formSchema) {
      setIsSubmitDisabled(true);
      return;
    }

    console.log("\n📋 Checking Form:");
    const visibleFields = getVisibleFields();
    console.log("Visible Fields:", visibleFields.map(f => f.name));
    
    const allRequiredFilled = visibleFields.every((field) => {
      if (!field.required) return true;
      const value = values[field.name];
      
      console.log(`  - ${field.label} (${field.name}): "${value}" (type: ${field.type})`);
      
      if (field.type === "checkbox") {
        const isValid = value === true;
        console.log(`    ✓ Checkbox validation: ${isValid ? '✅ PASS' : '❌ FAIL'}`);
        return isValid;
      }
      
      if (field.type === "checkbox-group") {
        const isValid = Array.isArray(value) && value.length > 0;
        console.log(`    ✓ Checkbox-group validation: ${isValid ? '✅ PASS' : '❌ FAIL'}`);
        return isValid;
      }
      
      if (field.type === "vehicle-list") {
        const isValid = Array.isArray(value) && value.length > 0;
        console.log(`    ✓ Vehicle-list validation: ${isValid ? '✅ PASS' : '❌ FAIL'}`);
        return isValid;
      }
      
      const isValid = value !== undefined && value !== null && value !== "";
      console.log(`    ✓ Field validation: ${isValid ? '✅ PASS' : '❌ FAIL'}`);
      return isValid;
    });

    console.log("\n🎯 FINAL RESULT - All required filled:", allRequiredFilled);
    console.log("🎯 Submit button disabled:", !allRequiredFilled);
    setIsSubmitDisabled(!allRequiredFilled);
  };

  const saveFieldResponse = async (fieldName: string, value: any, fieldType: string, fieldLabel: string) => {
    if (!user) return;

    try {
      const responseData = {
        task_id: taskId,
        user_id: user.id,
        field_name: fieldName,
        field_label: fieldLabel,
        field_type: fieldType,
        field_value: fieldType === "checkbox" 
          ? String(value) 
          : fieldType === "checkbox-group"
          ? JSON.stringify(value)
          : fieldType === "vehicle-list"
          ? JSON.stringify(value)
          : value,
        uploaded_file_url: fieldType === "file" ? value : null,
        updated_at: new Date().toISOString(),
      };

      const { error } = await supabase
        .from("task_responses" as any)
        .upsert(responseData, {
          onConflict: "task_id,user_id,field_name",
        });

      if (error) throw error;

      console.log(`Saved field: ${fieldName}, task_id: ${taskId}`);
    } catch (error: any) {
      console.error("Error saving field response:", error);
      toast.error(`Failed to save ${fieldLabel}`);
    }
  };

  const handleSaveProgress = async () => {
    if (!formSchema || !user) return;

    setSaving(true);
    
    try {
      for (const field of formSchema.fields) {
        const value = formValues[field.name];
        if (value !== undefined && value !== null && value !== "") {
          await saveFieldResponse(field.name, value, field.type, field.label);
        }
      }
      toast.success("Progress saved");
      onBack();
    } catch (error: any) {
      console.error("Error saving progress:", error);
      toast.error("Failed to save progress");
    } finally {
      setSaving(false);
    }
  };

  const handleSubmit = async () => {
    if (!formSchema || !user) return;

    // Validate required fields
    const missingFields: string[] = [];
    const visibleFields = getVisibleFields();
    
    visibleFields.forEach((field) => {
      if (field.required) {
        const value = formValues[field.name];
        if (value === undefined || value === null || value === "" || value === false) {
          missingFields.push(field.label);
        }
      }
    });

    if (missingFields.length > 0) {
      toast.error(`Please complete required fields: ${missingFields.join(", ")}`);
      return;
    }

    setSaving(true);
    try {
      for (const field of formSchema.fields) {
        const value = formValues[field.name];
        if (value !== undefined && value !== null && value !== "") {
          await saveFieldResponse(field.name, value, field.type, field.label);
        }
      }

      // Mark the user's task assignment as completed
      console.log("Attempting to mark assignment completed for task:", taskId, "user:", user.id);
      const now = new Date().toISOString();
      const { data: updatedByTask, error: updateErr1 } = await supabase
        .from('task_assignments' as any)
        .update({
          status: 'completed',
          approval_status: 'pending_approval',
          completed_at: now,
          updated_at: now,
        })
        .eq('task_id', taskId)
        .eq('user_id', user.id)
        .select('id');

      if (updateErr1) {
        console.error('Failed to update task_assignments by task_id/user_id:', updateErr1);
        throw updateErr1;
      }

      if (!updatedByTask || updatedByTask.length === 0) {
        console.error('No assignment row found for this task/user to update.');
        throw new Error('Assignment not found for this task');
      }

      setIsReadOnly(true);
      toast.success("Task submitted successfully!");
      
      // Close the form and navigate back
      onBack();
    } catch (error: any) {
      console.error("Error submitting task:", error);
      toast.error(error?.message || "Failed to submit task");
    } finally {
      setSaving(false);
    }
  };

  const renderField = (field: FormField) => {
    const fieldName = field.name;
    const fieldLabel = field.label;
    const value = formValues[fieldName] || (field.type === "checkbox" ? false : "");
    const fieldId = `field-${fieldName}`;

    switch (field.type) {
      case "text":
        const isTextMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-2">
            <Label htmlFor={fieldId}>
              {fieldLabel}
              {field.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            <Input
              id={fieldId}
              type="text"
              value={value}
              onChange={(e) => {
                let newValue = e.target.value;
                
                // Auto-uppercase for VIN fields
                if (field.name === 'vehicle_vin') {
                  newValue = newValue.toUpperCase();
                }
                
                // Enforce maxLength during typing
                if (field.validation?.maxLength && newValue.length > field.validation.maxLength) {
                  return;
                }
                
                handleFieldChange(fieldName, newValue, field.type, fieldLabel);
              }}
              placeholder={field.placeholder}
              disabled={isReadOnly || field.disabled}
              required={field.required}
              maxLength={field.validation?.maxLength}
              minLength={field.validation?.minLength}
              pattern={field.validation?.pattern}
              title={field.validation?.patternMessage}
              className={isTextMissing ? "border-destructive" : ""}
            />
            {isTextMissing && (
              <p className="text-xs text-destructive">This field is required</p>
            )}
            {field.validation?.patternMessage && (
              <p className="text-xs text-muted-foreground">
                {field.validation.patternMessage}
              </p>
            )}
          </div>
        );

      case "number":
        const isNumberMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-2">
            <Label htmlFor={fieldId}>
              {fieldLabel}
              {field.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            <Input
              id={fieldId}
              type="number"
              value={value}
              onChange={(e) => handleFieldChange(fieldName, e.target.value, field.type, fieldLabel)}
              placeholder={field.placeholder}
              disabled={isReadOnly}
              required={field.required}
              className={isNumberMissing ? "border-destructive" : ""}
            />
            {isNumberMissing && (
              <p className="text-xs text-destructive">This field is required</p>
            )}
          </div>
        );

      case "textarea":
        const isTextareaMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-2">
            <Label htmlFor={fieldId}>
              {fieldLabel}
              {field.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            <Textarea
              id={fieldId}
              value={value}
              onChange={(e) => handleFieldChange(fieldName, e.target.value, field.type, fieldLabel)}
              placeholder={field.placeholder}
              disabled={isReadOnly}
              required={field.required}
              rows={4}
              className={isTextareaMissing ? "border-destructive" : ""}
            />
            {isTextareaMissing && (
              <p className="text-xs text-destructive">This field is required</p>
            )}
          </div>
        );

      case "select":
        // Dynamic model options based on selected make
        let selectOptions = field.options || [];
        if (field.name === 'vehicle_model') {
          const vehicleMakeKey = 'vehicle_make';
          const selectedMake = formValues[vehicleMakeKey];
          if (selectedMake) {
            selectOptions = getModelsForMake(selectedMake);
          } else {
            selectOptions = ['Select a make first'];
          }
        }
        
        const isSelectMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-2">
            <Label htmlFor={fieldId}>
              {fieldLabel}
              {field.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            <Select
              value={value}
              onValueChange={(val) => handleFieldChange(fieldName, val, field.type, fieldLabel)}
              disabled={isReadOnly || (field.name === 'vehicle_model' && !formValues['vehicle_make'])}
            >
              <SelectTrigger id={fieldId} className={isSelectMissing ? "border-destructive" : ""}>
                <SelectValue placeholder={field.placeholder || "Select..."} />
              </SelectTrigger>
              <SelectContent className="bg-background z-50">
                {selectOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {isSelectMissing && (
              <p className="text-xs text-destructive">This field is required</p>
            )}
          </div>
        );

      case "checkbox":
        const isCheckboxMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-1">
            <div className="flex items-center space-x-2">
            <Checkbox
              id={fieldId}
              checked={!!value}
              onCheckedChange={(checked) => handleFieldChange(fieldName, checked === true, field.type, fieldLabel)}
              disabled={isReadOnly}
              required={field.required}
            />
              <Label htmlFor={fieldId} className="cursor-pointer">
                {fieldLabel}
                {field.required && <span className="text-destructive ml-1">*</span>}
              </Label>
            </div>
            {isCheckboxMissing && (
              <p className="text-xs text-destructive ml-6">This checkbox must be checked</p>
            )}
          </div>
        );

      case "checkbox-group":
        const checkboxGroupValue = Array.isArray(value) ? value : [];
        const isCheckboxGroupMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-2">
            <Label>
              {fieldLabel}
              {field.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            <div className="space-y-2">
              {(field.options || []).map((option) => {
                const optionId = `${fieldId}-${option}`;
                const isChecked = checkboxGroupValue.includes(option);
                return (
                  <div key={option} className="flex items-center space-x-2">
                    <Checkbox
                      id={optionId}
                      checked={isChecked}
                      onCheckedChange={(checked) => {
                        const newValue = checked
                          ? [...checkboxGroupValue, option]
                          : checkboxGroupValue.filter((v) => v !== option);
                        handleFieldChange(fieldName, newValue, field.type, fieldLabel);
                      }}
                      disabled={isReadOnly}
                    />
                    <Label htmlFor={optionId} className="cursor-pointer font-normal">
                      {option}
                    </Label>
                  </div>
                );
              })}
            </div>
            {isCheckboxGroupMissing && (
              <p className="text-xs text-destructive">Please select at least one option</p>
            )}
          </div>
        );

      case "date":
        const isDateMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-2">
            <Label htmlFor={fieldId}>
              {fieldLabel}
              {field.required && <span className="text-destructive ml-1">*</span>}
            </Label>
            <Input
              id={fieldId}
              type="date"
              value={value}
              onChange={(e) => handleFieldChange(fieldName, e.target.value, field.type, fieldLabel)}
              disabled={isReadOnly}
              required={field.required}
              className={isDateMissing ? "border-destructive" : ""}
            />
            {isDateMissing && (
              <p className="text-xs text-destructive">This field is required</p>
            )}
          </div>
        );

      case "file":
        const isFileMissing = isFieldMissing(fieldName, field.type, field.required);
        const isAvatarField = fieldName === 'profile_photo' || fieldLabel.toLowerCase().includes('profile photo') || fieldLabel.toLowerCase().includes('avatar');
        return (
          <div key={fieldName} className="space-y-2">
            {!isAvatarField && (
              <Label htmlFor={fieldId}>
                {fieldLabel}
                {field.required && <span className="text-destructive ml-1">*</span>}
              </Label>
            )}
            <TaskFileUpload
              taskId={taskId}
              userId={user?.id || ""}
              fieldName={fieldName}
              currentFileUrl={value}
              onFileUploaded={(url) => handleFieldChange(fieldName, url, field.type, fieldLabel)}
              disabled={isReadOnly}
              required={field.required}
              label={field.label}
              isAvatar={isAvatarField}
            />
            {isFileMissing && (
              <p className="text-xs text-destructive">Please upload a file</p>
            )}
          </div>
        );

      case "link":
        return (
          <div key={fieldName} className="space-y-2">
            <Label>{fieldLabel}</Label>
            <a
              href={field.url || "#"}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-accent hover:text-accent-foreground transition-colors"
            >
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5 text-primary"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                    />
                  </svg>
                </div>
                <div>
                  <p className="font-medium">View Document</p>
                  <p className="text-sm text-muted-foreground">{field.placeholder || "Click to open"}</p>
                </div>
              </div>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                className="h-5 w-5 text-muted-foreground"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                />
              </svg>
            </a>
          </div>
        );

      case "file_or_link":
        const mode = fileOrLinkMode[fieldName] || 'file';
        const isFileOrLinkMissing = isFieldMissing(fieldName, field.type, field.required);
        return (
          <div key={fieldName} className="space-y-3">
            <div className="flex items-center justify-between">
              <Label htmlFor={fieldId}>
                {fieldLabel}
                {field.required && <span className="text-destructive ml-1">*</span>}
              </Label>
              <div className="flex gap-2">
                <Button
                  type="button"
                  size="sm"
                  variant={mode === 'file' ? 'default' : 'outline'}
                  onClick={() => {
                    setFileOrLinkMode(prev => ({ ...prev, [fieldName]: 'file' }));
                    handleFieldChange(fieldName, '', field.type, fieldLabel);
                  }}
                  disabled={isReadOnly}
                  className="h-8"
                >
                  Upload File
                </Button>
                <Button
                  type="button"
                  size="sm"
                  variant={mode === 'link' ? 'default' : 'outline'}
                  onClick={() => {
                    setFileOrLinkMode(prev => ({ ...prev, [fieldName]: 'link' }));
                    handleFieldChange(fieldName, '', field.type, fieldLabel);
                  }}
                  disabled={isReadOnly}
                  className="h-8"
                >
                  Provide Link
                </Button>
              </div>
            </div>
            
            {mode === 'file' ? (
              <TaskFileUpload
                taskId={taskId}
                userId={user?.id || ""}
                fieldName={fieldName}
                currentFileUrl={value}
                onFileUploaded={(url) => handleFieldChange(fieldName, url, 'file', fieldLabel)}
                disabled={isReadOnly}
                required={field.required}
                label={field.label}
              />
            ) : (
              <div className="space-y-2">
                <Textarea
                  id={fieldId}
                  value={value || ''}
                  onChange={(e) => handleFieldChange(fieldName, e.target.value, 'text', fieldLabel)}
                  placeholder="https://example.com/document.pdf"
                  disabled={isReadOnly}
                  required={field.required}
                  rows={3}
                  className={`break-all resize-none ${isFileOrLinkMissing ? 'border-destructive' : ''}`}
                />
              </div>
            )}
            {isFileOrLinkMissing && (
              <p className="text-xs text-destructive">
                {mode === 'file' ? 'Please upload a file' : 'Please provide a link'}
              </p>
            )}
          </div>
          );

      case "vehicle-list":
        // Always bind to local state for instant UI updates
        const vehicleListValue = vehicles;
        const isVehicleListMissing = isFieldMissing(fieldName, field.type, field.required);
        
        const addVehicle = () => {
          const newVehicle = {
            id: Date.now().toString(),
            make: '',
            model: '',
            year: '',
            type_category: '',
            vin: '',
            license_plate: '',
            color: ''
          };
          setVehicles(prev => {
            const updated = [...prev, newVehicle];
            handleFieldChange(fieldName, updated, field.type, fieldLabel);
            return updated;
          });
        };
        
        const removeVehicle = (vehicleId: string) => {
          setVehicles(prev => {
            const updated = prev.filter((v: any) => v.id !== vehicleId);
            handleFieldChange(fieldName, updated, field.type, fieldLabel);
            return updated;
          });
        };
        
        const updateVehicle = (vehicleId: string, vehicleField: string, value: any) => {
          setVehicles(prev => {
            const updated = prev.map((v: any) => 
              v.id === vehicleId ? { ...v, [vehicleField]: value } : v
            );
            console.log('Vehicle updated', { vehicleId, vehicleField, value });
            handleFieldChange(fieldName, updated, field.type, fieldLabel);
            return updated;
          });
        };
        
        return (
          <div key={fieldName} className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>
                {fieldLabel}
                {field.required && <span className="text-destructive ml-1">*</span>}
              </Label>
              <Button
                type="button"
                size="sm"
                onClick={addVehicle}
                disabled={isReadOnly}
                className="h-8"
              >
                + Add Vehicle
              </Button>
            </div>
            
            {vehicleListValue.length === 0 && (
              <div className="text-center py-8 border-2 border-dashed border-border rounded-lg">
                <p className="text-muted-foreground">No vehicles added yet</p>
                <p className="text-sm text-muted-foreground mt-1">Click "Add Vehicle" to get started</p>
              </div>
            )}
            
            <div className="space-y-4">
              {vehicleListValue.map((vehicle: any, index: number) => (
                <Card key={vehicle.id} className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold">Vehicle {index + 1}</h4>
                    <Button
                      type="button"
                      size="sm"
                      variant="destructive"
                      onClick={() => removeVehicle(vehicle.id)}
                      disabled={isReadOnly}
                    >
                      Remove
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Vehicle Make *</Label>
                      <Select
                        value={vehicle.make || undefined}
                        onValueChange={(val) => {
                          updateVehicle(vehicle.id, 'make', val);
                          updateVehicle(vehicle.id, 'model', '');
                        }}
                        disabled={isReadOnly}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select make" />
                        </SelectTrigger>
                        <SelectContent className="bg-background border border-border shadow-lg z-[100] max-h-[300px] overflow-y-auto">
                          {Object.keys(VEHICLE_MODELS).sort().map((make) => (
                            <SelectItem key={make} value={make} className="cursor-pointer hover:bg-accent">
                              {make}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Vehicle Model *</Label>
                      <Select
                        value={vehicle.model || undefined}
                        onValueChange={(val) => updateVehicle(vehicle.id, 'model', val)}
                        disabled={isReadOnly || !vehicle.make}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder={vehicle.make ? "Select model" : "Select make first"} />
                        </SelectTrigger>
                        <SelectContent className="bg-background border border-border shadow-lg z-[100] max-h-[300px] overflow-y-auto">
                          {vehicle.make && getModelsForMake(vehicle.make).map((model) => (
                            <SelectItem key={model} value={model} className="cursor-pointer hover:bg-accent">
                              {model}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Vehicle Year *</Label>
                      <Select
                        value={vehicle.year || undefined}
                        onValueChange={(val) => updateVehicle(vehicle.id, 'year', val)}
                        disabled={isReadOnly}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select year" />
                        </SelectTrigger>
                        <SelectContent className="bg-background border border-border shadow-lg z-[100] max-h-[300px] overflow-y-auto">
                          {Array.from({ length: new Date().getFullYear() - 1989 }, (_, i) => 
                            String(new Date().getFullYear() + 1 - i)
                          ).map((year) => (
                            <SelectItem key={year} value={year} className="cursor-pointer hover:bg-accent">
                              {year}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Vehicle Type/Category *</Label>
                      <Select
                        value={vehicle.type_category || undefined}
                        onValueChange={(val) => updateVehicle(vehicle.id, 'type_category', val)}
                        disabled={isReadOnly}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select type" />
                        </SelectTrigger>
                        <SelectContent className="bg-background border border-border shadow-lg z-[100] max-h-[300px] overflow-y-auto">
                          {ALL_VEHICLE_TYPES.map((type) => (
                            <SelectItem key={type.value} value={type.label} className="cursor-pointer hover:bg-accent">
                              {type.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2 md:col-span-2">
                      <Label>Vehicle Identification Number (VIN) *</Label>
                      <Input
                        type="text"
                        value={vehicle.vin || ''}
                        onChange={(e) => {
                          let newValue = e.target.value.toUpperCase();
                          if (newValue.length <= 17) {
                            updateVehicle(vehicle.id, 'vin', newValue);
                          }
                        }}
                        placeholder="Enter 17-character VIN"
                        disabled={isReadOnly}
                        maxLength={17}
                        pattern="^[A-HJ-NPR-Z0-9]{17}$"
                      />
                      <p className="text-xs text-muted-foreground">
                        VIN must be exactly 17 characters (letters and numbers, excluding I, O, Q)
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>License Plate Number</Label>
                      <Input
                        type="text"
                        value={vehicle.license_plate || ''}
                        onChange={(e) => updateVehicle(vehicle.id, 'license_plate', e.target.value)}
                        placeholder="Enter license plate"
                        disabled={isReadOnly}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Vehicle Color</Label>
                      <Select
                        value={vehicle.color || ''}
                        onValueChange={(value) => updateVehicle(vehicle.id, 'color', value)}
                        disabled={isReadOnly}
                      >
                        <SelectTrigger className="bg-background">
                          <SelectValue placeholder="Select vehicle color" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover z-50 max-h-[300px] overflow-y-auto">
                          {VEHICLE_COLORS.map((color) => (
                            <SelectItem key={color} value={color} className="cursor-pointer hover:bg-accent">
                              {color}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
            
            {isVehicleListMissing && (
              <p className="text-xs text-destructive">Please add at least one vehicle</p>
            )}
          </div>
        );

      default:
        return null;
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  // Handle special task types without form schema
  if (!formSchema) {
    const taskName = task?.task_name || task?.name;
    
    if (taskName === 'Enable MFA' || taskName === 'Setup MFA') {
      return (
        <div className="w-full max-w-2xl mx-auto space-y-4">
          <Button onClick={onBack} variant="ghost" className="mb-4">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <MFASetupForm onComplete={async () => {
            // Mark task as completed
            try {
              const { error } = await supabase
                .from("task_assignments" as any)
                .update({ status: 'completed', completed_at: new Date().toISOString() })
                .eq('task_id', taskId)
                .eq('user_id', user?.id);
              
              if (error) throw error;
              toast.success("MFA setup completed!");
              onBack();
            } catch (error) {
              console.error("Error completing task:", error);
              toast.error("Failed to complete task");
            }
          }} />
        </div>
      );
    }
    
    return (
      <div className="w-full max-w-2xl mx-auto space-y-4">
        <p className="text-muted-foreground text-center py-8">
          This task's form isn't configured yet.
        </p>
        <Button onClick={onBack} variant="outline" className="w-full">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Close
        </Button>
      </div>
    );
  }

  const columns = formSchema.layout?.columns || 1;

  // Helper to check if a required field is missing
  const isFieldMissing = (fieldName: string, fieldType: string, required?: boolean) => {
    if (!required) return false;
    const value = formValues[fieldName];
    
    if (fieldType === "checkbox") {
      return value !== true;
    }
    if (fieldType === "checkbox-group") {
      return !Array.isArray(value) || value.length === 0;
    }
    if (fieldType === "vehicle-list") {
      return !Array.isArray(value) || value.length === 0;
    }
    return value === undefined || value === null || value === "";
  };

  return (
    <div className="w-full space-y-4 sm:space-y-6">
      {/* Task Description */}
      {task.task_description && (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground">{task.task_description}</p>
        </div>
      )}

      {/* Form */}
      <Card className="w-full">
        <CardHeader className="px-4 sm:px-6">
          {isReadOnly && (
            <Badge variant="secondary" className="w-fit">
              Read-Only (Completed)
            </Badge>
          )}
        </CardHeader>
        <CardContent className="px-4 sm:px-6 overflow-visible">
          <div
            className="grid gap-4 sm:gap-6 w-full"
            style={{
              gridTemplateColumns: columns > 1 ? `repeat(auto-fit, minmax(min(100%, 280px), 1fr))` : '1fr',
            }}
          >
            {getVisibleFields().map(renderField)}
          </div>
        </CardContent>
        <CardFooter className="flex flex-col gap-3 px-4 sm:px-6">
          <Button 
            onClick={handleSubmit} 
            disabled={saving || isReadOnly || isSubmitDisabled}
            className="w-full"
          >
            <Send className="mr-2 h-4 w-4" />
            Submit Task
          </Button>
          <Button
            onClick={handleSaveProgress}
            variant="outline"
            disabled={saving || isReadOnly}
            className="w-full"
          >
            <Save className="mr-2 h-4 w-4" />
            Save Progress
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
