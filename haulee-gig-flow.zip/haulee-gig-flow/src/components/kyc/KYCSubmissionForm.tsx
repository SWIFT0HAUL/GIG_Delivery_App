import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { FileUpload } from '@/components/onboarding/FileUpload';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, AlertTriangle, Clock, Shield, FileText } from 'lucide-react';

interface KYCStatus {
  id?: string;
  status: string;
  submitted_at?: string;
  rejection_reason?: string;
  admin_notes?: string;
}

export function KYCSubmissionForm() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [kycStatus, setKycStatus] = useState<KYCStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [governmentId, setGovernmentId] = useState<string | null>(null);
  const [proofOfAddress, setProofOfAddress] = useState<string | null>(null);
  const [selfie, setSelfie] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      checkKYCStatus();
    }
  }, [user]);

  const checkKYCStatus = async () => {
    try {
      console.log('Checking KYC status for user:', user?.id);
      
      const { data, error } = await supabase
        .from('kyc_submissions' as any)
        .select('*')
        .eq('user_id', user?.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('KYC status check error:', error);
        throw error;
      }
      
      if (data) {
        console.log('Found existing KYC submission:', data);
        const kycData = data as any;
        setKycStatus(kycData);
        setGovernmentId(kycData.government_id_path);
        setProofOfAddress(kycData.proof_of_address_path);
        setSelfie(kycData.selfie_path);
      } else {
        console.log('No KYC submission found, status: not_submitted');
        setKycStatus({ status: 'not_submitted' });
      }
    } catch (error: any) {
      console.error('Error checking KYC status:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to check KYC status",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    if (!governmentId || !proofOfAddress) {
      toast({
        title: "Missing Documents",
        description: "Please upload both Government ID and Proof of Address",
        variant: "destructive"
      });
      return;
    }

    try {
      setSubmitting(true);
      console.log('Submitting KYC documents for user:', user?.id);

      const submissionData = {
        user_id: user?.id,
        government_id_path: governmentId,
        proof_of_address_path: proofOfAddress,
        selfie_path: selfie,
        status: 'pending',
        submitted_at: new Date().toISOString()
      };

      console.log('Submission data:', submissionData);

      if (kycStatus?.id) {
        // Update existing submission
        console.log('Updating existing KYC submission:', kycStatus.id);
        const { error } = await supabase
          .from('kyc_submissions' as any)
          .update(submissionData)
          .eq('id', kycStatus.id);

        if (error) {
          console.error('Update error:', error);
          throw error;
        }
      } else {
        // Create new submission
        console.log('Creating new KYC submission');
        const { error } = await supabase
          .from('kyc_submissions' as any)
          .insert(submissionData);

        if (error) {
          console.error('Insert error:', error);
          throw error;
        }
      }

      // Update profile KYC status
      console.log('Updating profile KYC status');
      const { error: profileError } = await supabase
        .from('profiles' as any)
        .update({ kyc_status: 'pending' } as any)
        .eq('id', user?.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
        // Don't throw, submission was successful
      }

      toast({
        title: "KYC Submitted",
        description: "Your documents have been submitted for review"
      });

      console.log('KYC submission successful');
      checkKYCStatus();
    } catch (error: any) {
      console.error('Error submitting KYC:', error);
      toast({
        title: "Submission Failed",
        description: error.message || "Failed to submit KYC documents",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusBadge = () => {
    if (!kycStatus) return null;

    switch (kycStatus.status) {
      case 'not_submitted':
        return <Badge variant="outline" className="bg-gray-50 text-gray-700"><FileText className="w-3 h-3 mr-1" />Not Submitted</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700"><Clock className="w-3 h-3 mr-1" />Under Review</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-50 text-green-700"><CheckCircle className="w-3 h-3 mr-1" />Verified</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-50 text-red-700"><AlertTriangle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'more_info_needed':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700"><AlertTriangle className="w-3 h-3 mr-1" />More Info Needed</Badge>;
      default:
        return null;
    }
  };

  if (loading) {
    return <div className="text-center py-8">Loading KYC status...</div>;
  }

  if (kycStatus?.status === 'approved') {
    return (
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-green-600" />
              KYC Verification
            </CardTitle>
            {getStatusBadge()}
          </div>
          <CardDescription>Your identity has been verified</CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="bg-green-50 border-green-200">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <AlertDescription className="text-green-800">
              Your identity has been successfully verified. You have full access to all platform features.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-6 w-6" />
            KYC Verification
          </CardTitle>
          {getStatusBadge()}
        </div>
        <CardDescription>
          Complete your identity verification to unlock all platform features
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {kycStatus?.status === 'pending' && (
          <Alert className="bg-yellow-50 border-yellow-200">
            <Clock className="h-4 w-4 text-yellow-600" />
            <AlertDescription className="text-yellow-800">
              Your documents are being reviewed. This usually takes 1-2 business days.
            </AlertDescription>
          </Alert>
        )}

        {kycStatus?.status === 'rejected' && kycStatus.rejection_reason && (
          <Alert variant="destructive">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Rejection Reason:</strong> {kycStatus.rejection_reason}
              <br />
              Please resubmit with corrected documents.
            </AlertDescription>
          </Alert>
        )}

        {kycStatus?.status === 'more_info_needed' && kycStatus.admin_notes && (
          <Alert className="bg-blue-50 border-blue-200">
            <AlertTriangle className="h-4 w-4 text-blue-600" />
            <AlertDescription className="text-blue-800">
              <strong>Additional Information Needed:</strong> {kycStatus.admin_notes}
            </AlertDescription>
          </Alert>
        )}

        {(kycStatus?.status === 'not_submitted' || 
          kycStatus?.status === 'rejected' || 
          kycStatus?.status === 'more_info_needed') && (
          <div className="space-y-4">
            <Alert>
              <AlertDescription>
                <strong>Required Documents:</strong>
                <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
                  <li>Government-issued ID (passport, driver's license, or national ID)</li>
                  <li>Proof of address (utility bill, bank statement - not older than 3 months)</li>
                  <li>Optional: A selfie with your ID</li>
                </ul>
              </AlertDescription>
            </Alert>

            <FileUpload
              label="Government-Issued ID"
              fieldName="government_id"
              value={governmentId}
              onChange={setGovernmentId}
              required
            />

            <FileUpload
              label="Proof of Address"
              fieldName="proof_of_address"
              value={proofOfAddress}
              onChange={setProofOfAddress}
              required
            />

            <FileUpload
              label="Selfie with ID (Optional)"
              fieldName="selfie"
              value={selfie}
              onChange={setSelfie}
              options={['camera']}
            />

            <Button 
              onClick={handleSubmit} 
              disabled={submitting || !governmentId || !proofOfAddress}
              className="w-full"
            >
              {submitting ? 'Submitting...' : kycStatus?.id ? 'Resubmit Documents' : 'Submit for Verification'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
