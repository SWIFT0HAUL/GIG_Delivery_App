import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShieldAlert } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export const NoPermissions: React.FC = () => {
  const { user } = useAuth();
  const [requesting, setRequesting] = useState(false);

  const handleRequestAccess = async () => {
    if (!user) return;

    try {
      setRequesting(true);

      // Get admin users by checking user_roles table
      const { data: adminUsers } = await supabase
        .from('user_roles')
        .select('user_id')
        .in('role', ['admin', 'super_admin']);

      if (!adminUsers || adminUsers.length === 0) {
        toast({
          title: "No Administrators",
          description: "There are no administrators to notify. Please contact support.",
          variant: "destructive"
        });
        return;
      }

      // Send notification to all admins
      const notifications = adminUsers.map(admin => ({
        user_id: admin.user_id,
        sender_id: user.id,
        type: 'system' as const,
        title: 'Access Request',
        message: `User ${user.email || user.id} has requested access permissions for ${window.location.pathname}${window.location.search}.`,
        is_read: false
      }));

      const { error } = await supabase
        .from('notifications')
        .insert(notifications);

      if (error) throw error;

      toast({
        title: "Request Sent",
        description: "Your access request has been sent to administrators.",
      });
    } catch (error) {
      console.error('Error requesting access:', error);
      toast({
        title: "Error",
        description: "Failed to send access request. Please try again.",
        variant: "destructive"
      });
    } finally {
      setRequesting(false);
    }
  };

  return (
    <div className="flex items-center justify-center min-h-[60vh]">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <ShieldAlert className="h-16 w-16 text-muted-foreground" />
          </div>
          <CardTitle>No Permissions Assigned</CardTitle>
          <CardDescription>
            You don't have any permissions assigned to your role yet. Please contact your administrator to request access.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center">
          <Button onClick={handleRequestAccess} disabled={requesting}>
            {requesting ? "Sending Request..." : "Request Access"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
