import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import * as Icons from 'lucide-react';
import { Menu } from '@/hooks/useRBACMenu';
import { useNotifications } from '@/hooks/useNotifications';

interface SidebarProps {
  menus: Menu[];
}

// Map category names to display titles
const categoryTitles: Record<string, string> = {
  'Admin-Core': 'CORE',
  'Admin-Content': 'CONTENT',
  'Admin-Financial': 'FINANCIALS',
  'Admin-Platform': 'PLATFORM',
  'Admin-Security': 'SECURITY',
  'Admin-Support': 'MONITORING & SUPPORT',
};

export const Sidebar: React.FC<SidebarProps> = ({ menus }) => {
  const location = useLocation();
  const { unreadCount } = useNotifications();

  const getIcon = (iconName: string | null) => {
    if (!iconName) return <Icons.Circle className="h-4 w-4" />;
    const Icon = (Icons as any)[iconName] || Icons.Circle;
    return <Icon className="h-4 w-4" />;
  };

  // Filter active menus and those with display mode not hidden
  const visibleMenus = menus.filter(menu => 
    menu.is_active && (!menu.display_mode || menu.display_mode !== 'hidden')
  );
  const groupedMenus = visibleMenus.reduce((acc, menu) => {
    const category = menu.category || 'Other';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(menu);
    return acc;
  }, {} as Record<string, Menu[]>);

  // Sort categories by the first menu's display_order in each group
  const sortedCategories = Object.keys(groupedMenus).sort((a, b) => {
    const aFirstOrder = groupedMenus[a][0]?.display_order || 0;
    const bFirstOrder = groupedMenus[b][0]?.display_order || 0;
    return aFirstOrder - bFirstOrder;
  });

  return (
    <aside className="hidden md:block fixed left-0 top-0 w-64 h-screen border-r bg-card z-30">
      <div className="h-16 px-6 border-b flex-shrink-0 flex items-center">
        <div className="flex items-center gap-2">
          <Icons.Truck className="h-6 w-6 text-primary" />
          <span className="text-xl font-bold">Haulee</span>
        </div>
      </div>
      
      <ScrollArea className="h-[calc(100vh-64px)]">
        <div className="p-4 space-y-4">
          {sortedCategories.map((category) => (
            <div key={category} className="space-y-2">
              {/* Category Header */}
              {categoryTitles[category] && (
                <h3 className="px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  {categoryTitles[category]}
                </h3>
              )}
              
              {/* Menu Items */}
              {groupedMenus[category]
                .sort((a, b) => a.display_order - b.display_order)
                .map((menu) => {
                  const isDisabled = menu.display_mode === 'disabled';
                  
                  return (
                    <div key={menu.id} className="relative group">
                      <Link 
                        to={isDisabled ? '#' : menu.path}
                        onClick={(e) => isDisabled && e.preventDefault()}
                        className={cn(isDisabled && "pointer-events-none")}
                      >
                        <Button
                          variant={location.pathname === menu.path ? "secondary" : "ghost"}
                          className={cn(
                            "w-full justify-start gap-2",
                            location.pathname === menu.path && "bg-secondary",
                            isDisabled && "opacity-50"
                          )}
                          disabled={isDisabled}
                        >
                          {getIcon(menu.icon)}
                          <span className="flex-1 text-left">{menu.name}</span>
                          {menu.name === 'Notifications' && unreadCount > 0 && (
                            <Badge variant="destructive" className="h-5 px-1.5 text-[10px] ml-auto">
                              {unreadCount > 9 ? '9+' : unreadCount}
                            </Badge>
                          )}
                        </Button>
                      </Link>
                      {isDisabled && (
                        <div className="absolute inset-0 bg-background/30 backdrop-blur-[1px] rounded cursor-not-allowed flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <span className="text-xs text-muted-foreground bg-background/80 px-2 py-1 rounded">
                            Disabled
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })}
            </div>
          ))}
        </div>
      </ScrollArea>
    </aside>
  );
};