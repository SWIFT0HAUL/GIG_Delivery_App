import React, { useEffect, useRef } from 'react';

interface StickyHorizontalScrollbarProps {
  targetRef: React.RefObject<HTMLElement>;
  height?: number; // in pixels
  className?: string;
  hideOnMobile?: boolean; // hide on mobile to avoid overlap with bottom nav
}

export const StickyHorizontalScrollbar: React.FC<StickyHorizontalScrollbarProps> = ({
  targetRef,
  height = 14,
  className = '',
  hideOnMobile = true,
}) => {
  const barRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const target = targetRef.current;
    const bar = barRef.current as HTMLDivElement | null;
    const inner = innerRef.current as HTMLDivElement | null;
    if (!target || !bar || !inner) return;

    let syncing = false;

    const update = () => {
      // Match the inner width to the scrollable content width
      inner.style.width = `${target.scrollWidth}px`;
      // Keep positions in sync
      bar.scrollLeft = target.scrollLeft;
    };

    const onBarScroll = () => {
      if (syncing) return;
      syncing = true;
      target.scrollLeft = bar.scrollLeft;
      syncing = false;
    };

    const onTargetScroll = () => {
      if (syncing) return;
      syncing = true;
      bar.scrollLeft = target.scrollLeft;
      syncing = false;
    };

    const ro = new ResizeObserver(update);
    ro.observe(target);
    window.addEventListener('resize', update);
    bar.addEventListener('scroll', onBarScroll, { passive: true });
    target.addEventListener('scroll', onTargetScroll, { passive: true });

    update();

    return () => {
      ro.disconnect();
      window.removeEventListener('resize', update);
      bar.removeEventListener('scroll', onBarScroll as EventListener);
      target.removeEventListener('scroll', onTargetScroll as EventListener);
    };
  }, [targetRef]);

  const visibility = hideOnMobile ? 'hidden md:block' : '';
  // Use semantic tokens for theming
  const baseClasses = 'fixed left-0 right-0 bottom-0 z-[95] bg-background/60 supports-[backdrop-filter]:bg-background/40 border-t border-border';

  return (
    <div
      ref={barRef}
      className={`${baseClasses} ${visibility} ${className}`}
      style={{ height, overflowX: 'auto', overflowY: 'hidden' }}
      aria-label="Sticky horizontal scrollbar"
      role="scrollbar"
    >
      {/* The inner spacer creates the horizontal scroll width */}
      <div ref={innerRef} style={{ height: height - 2 }} />
    </div>
  );
};
