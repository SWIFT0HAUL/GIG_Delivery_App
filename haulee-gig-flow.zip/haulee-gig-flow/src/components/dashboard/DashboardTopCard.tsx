import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Switch } from '@/components/ui/switch';
import { Star } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface DashboardTopCardProps {
  companyName?: string;
  motivationalText: string;
  showOnlineToggle?: boolean;
  avatarUrl?: string;
}

export const DashboardTopCard: React.FC<DashboardTopCardProps> = ({
  companyName,
  motivationalText,
  showOnlineToggle = false,
  avatarUrl,
}) => {
  const { user } = useAuth();
  const [isOnline, setIsOnline] = useState(true);
  const [rating, setRating] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [resolvedAvatar, setResolvedAvatar] = useState<string | undefined>(avatarUrl);

  useEffect(() => {
    if (!user?.id) return;

    const fetchDriverData = async () => {
      try {
        // Fetch driver status
        if (showOnlineToggle) {
          const { data: statusData } = await supabase
            .from('driver_status')
            .select('is_online')
            .eq('driver_id', user.id)
            .single();
          
          if (statusData) {
            setIsOnline(statusData.is_online);
          }
        }

        // Fetch average rating
        const { data: ratingsData } = await supabase
          .from('driver_ratings')
          .select('rating')
          .eq('driver_id', user.id);

        if (ratingsData && ratingsData.length > 0) {
          const avgRating = ratingsData.reduce((sum, r) => sum + (r.rating || 0), 0) / ratingsData.length;
          setRating(Number(avgRating.toFixed(1)));
        }
      } catch (error) {
        console.error('Error fetching driver data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDriverData();
  }, [user?.id, showOnlineToggle]);

  useEffect(() => {
    if (avatarUrl) {
      setResolvedAvatar(avatarUrl);
      return;
    }
    if (user?.user_metadata?.avatar_url) {
      setResolvedAvatar(user.user_metadata.avatar_url);
      return;
    }
    if (!user?.id) return;
    supabase
      .from('profiles')
      .select('avatar_url')
      .eq('id', user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (data?.avatar_url) setResolvedAvatar(data.avatar_url);
      });
  }, [avatarUrl, user?.id]);

  const handleOnlineToggle = async (checked: boolean) => {
    if (!user?.id) return;

    try {
      const { error } = await supabase
        .from('driver_status')
        .upsert({
          driver_id: user.id,
          is_online: checked,
          status_updated_at: new Date().toISOString(),
        }, {
          onConflict: 'driver_id'
        });

      if (!error) {
        setIsOnline(checked);
      }
    } catch (error) {
      console.error('Error updating online status:', error);
    }
  };

  const initials = companyName
    ? companyName.split(' ').map(n => n[0]).join('').toUpperCase()
    : 'C';

  return (
    <Card className="p-3 sm:p-4 mb-4 relative w-full max-w-full">
      <div className="flex items-start gap-3 sm:gap-4">
        <div className="flex flex-col items-center gap-2">
          <Avatar className="h-14 w-14 sm:h-16 sm:w-16">
            <AvatarImage src={resolvedAvatar} />
            <AvatarFallback className="text-sm sm:text-base">{initials}</AvatarFallback>
          </Avatar>
          <div className="flex items-center gap-0.5">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                className={cn(
                  "h-3 w-3 sm:h-3.5 sm:w-3.5",
                  star <= rating
                    ? "fill-yellow-400 text-yellow-400"
                    : "fill-muted text-muted"
                )}
              />
            ))}
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <h2 className="text-lg sm:text-xl font-bold mb-1 truncate">
            Welcome, {companyName || 'Company'}
          </h2>
          <p className="text-xs sm:text-sm text-muted-foreground">{motivationalText}</p>
        </div>
      </div>

      {showOnlineToggle && (
        <div className="absolute bottom-3 right-3 sm:bottom-4 sm:right-4">
          <div className="flex items-center gap-1 bg-background/95 backdrop-blur-sm border border-border rounded-full px-2 py-1 sm:px-2.5 sm:py-1.5 shadow-sm">
            <span className={cn(
              "text-[10px] sm:text-[11px] font-medium whitespace-nowrap",
              isOnline ? "text-green-600 dark:text-green-400" : "text-muted-foreground"
            )}>
              {isOnline ? 'Online' : 'Offline'}
            </span>
            <Switch
              checked={isOnline}
              onCheckedChange={handleOnlineToggle}
              disabled={loading}
              className="scale-[0.55] sm:scale-[0.66]"
            />
          </div>
        </div>
      )}
    </Card>
  );
};
