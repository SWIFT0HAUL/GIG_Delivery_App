import React from 'react';
import { createPortal } from 'react-dom';
import { Package, Briefcase, MapPin, DollarSign, User, Navigation as NavigationIcon } from 'lucide-react';
import { cn } from '@/lib/utils';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const navItems = [
    { value: 'available', label: 'Available', icon: Briefcase },
    { value: 'jobs', label: 'My Jobs', icon: MapPin },
    { value: 'earnings', label: 'Earnings', icon: DollarSign },
    { value: 'profile', label: 'Settings', icon: User },
  ];

  return createPortal(
    <nav className="fixed bottom-0 left-0 right-0 z-[100] md:hidden pb-safe">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 pb-4">
        <div className="relative bg-card/95 backdrop-blur-xl border border-border/50 rounded-2xl shadow-2xl shadow-black/10">
          {/* Active indicator background */}
          <div className="relative grid grid-cols-4 h-16 sm:h-18 p-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.value;
              
              return (
                <button
                  key={item.value}
                  onClick={() => onTabChange(item.value)}
                  className={cn(
                    "relative flex flex-col items-center justify-center gap-1 transition-all duration-300 rounded-xl",
                    isActive 
                      ? "text-primary" 
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {/* Active pill background */}
                  {isActive && (
                    <div className="absolute inset-0 bg-primary/10 rounded-xl animate-in fade-in zoom-in-95 duration-300" />
                  )}
                  
                  {/* Active top indicator */}
                  {isActive && (
                    <div className="absolute top-1 left-1/2 -translate-x-1/2 w-8 h-1 bg-primary rounded-full animate-in slide-in-from-top-2 duration-300" />
                  )}
                  
                  <div className="relative flex flex-col items-center gap-0.5 z-10">
                    <Icon 
                      className={cn(
                        "h-5 w-5 sm:h-6 sm:w-6 transition-all duration-300",
                        isActive && "scale-110"
                      )} 
                    />
                    <span className={cn(
                      "text-[9px] sm:text-[10px] font-medium transition-all duration-300",
                      isActive && "font-semibold"
                    )}>
                      {item.label}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>,
    document.body
  );
};
