import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Bell, Settings, Mail, Phone, Calendar, LogOut, History, Receipt, HelpCircle, Star, Package, User, AlertTriangle, Menu } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useNavigate, useLocation } from 'react-router-dom';
import { useUserRole } from '@/hooks/useUserRole';
import { NotificationBadge } from '@/components/NotificationBadge';

export const Header: React.FC = () => {
  const { user, signOut } = useAuth();
  const { profile, isSuperAdmin } = useUserRole();
  const navigate = useNavigate();
  const location = useLocation();
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [accountNumber, setAccountNumber] = useState<string>('');

  // Check if we're on a home/dashboard route
  const isOnDashboard = location.pathname.endsWith('-home') || location.pathname === '/dashboard';

  useEffect(() => {
    if (!user) return;

    const fetchNotifications = async () => {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('user_id', user.id)
        .eq('is_read', false)
        .order('created_at', { ascending: false })
        .limit(5);

      if (data) {
        setNotifications(data);
        setUnreadCount(data.length);
      }
    };

    const fetchAccountNumber = async () => {
      const { data } = await supabase
        .from('user_account_number')
        .select('account_number')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (data) {
        setAccountNumber(data.account_number);
      }
    };

    fetchNotifications();
    fetchAccountNumber();

    // Real-time subscription for notifications
    const channel = supabase
      .channel('notifications-changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'notifications', filter: `user_id=eq.${user.id}` }, 
        () => {
          fetchNotifications();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const handleMarkAsRead = async (notificationId: string) => {
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .eq('id', notificationId);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/auth');
  };

  const handleSettings = () => {
    navigate('/settings');
  };

  const getInitials = (name: string) => {
    if (!name) return 'U';
    return name.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();
  };

  // Get dashboard base path based on user role
  const getDashboardPath = () => {
    const roleName = profile?.role_name;
    if (!roleName) return '/dashboard';
    
    switch (roleName) {
      case 'driver':
        return '/driver-dashboard';
      case 'shipper':
        return '/shipper-dashboard';
      case 'broker':
        return '/broker-dashboard';
      case 'carrier':
        return '/carrier-dashboard';
      case 'vendor':
        return '/vendor-dashboard';
      case 'admin':
      case 'super_admin':
        return '/admin';
      default:
        return '/dashboard';
    }
  };

  return (
    <header className="border-b bg-card h-16">
      <div className="max-w-7xl mx-auto px-3 sm:px-4 h-full flex items-center justify-between">
        <div className="flex items-center gap-4">
        {/* Driver Quick Navigation Dropdown */}
        {profile?.role_name === 'driver' && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="gap-2">
                <Menu className="h-4 w-4" />
                <span className="hidden sm:inline">Quick Menu</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48 bg-card z-50">
              <div className="flex items-center gap-3 p-3">
                <Avatar className="h-12 w-12">
                  <AvatarImage src={user?.user_metadata?.avatar_url} />
                  <AvatarFallback>
                    {getInitials(user?.user_metadata?.first_name && user?.user_metadata?.last_name
                      ? `${user.user_metadata.first_name} ${user.user_metadata.last_name}`
                      : user?.email || 'User')}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col">
                  <span className="text-sm font-medium">
                    {user?.user_metadata?.first_name && user?.user_metadata?.last_name
                      ? `${user.user_metadata.first_name} ${user.user_metadata.last_name}`
                      : user?.email}
                  </span>
                  {accountNumber && (
                    <span className="text-xs text-muted-foreground">#{accountNumber}</span>
                  )}
                </div>
              </div>
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Quick Navigation</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => navigate(`${getDashboardPath()}/driver-home`)}>
                <Package className="mr-2 h-4 w-4" />
                Dashboard
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${getDashboardPath()}/driver-schedule`)}>
                <Calendar className="mr-2 h-4 w-4" />
                Schedule
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${getDashboardPath()}/driver-ratings`)}>
                <Star className="mr-2 h-4 w-4" />
                Ratings
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${getDashboardPath()}/driver-history`)}>
                <History className="mr-2 h-4 w-4" />
                History
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${getDashboardPath()}/driver-expenses`)}>
                <Receipt className="mr-2 h-4 w-4" />
                Expenses
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => navigate(`${getDashboardPath()}/driver-disputes`)}>
                <AlertTriangle className="mr-2 h-4 w-4" />
                Disputes
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
        
        {isOnDashboard && profile?.role_name !== 'driver' && (
          <h1 className="text-xl font-semibold">Dashboard</h1>
        )}
      </div>
      
      <div className="flex items-center gap-2">
        {/* Notifications Dropdown */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <Badge 
                  variant="destructive" 
                  className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                >
                  {unreadCount}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80">
            <DropdownMenuLabel>Notifications</DropdownMenuLabel>
            <DropdownMenuSeparator />
            {notifications.length === 0 ? (
              <div className="p-4 text-center text-sm text-muted-foreground">
                No new notifications
              </div>
            ) : (
              notifications.map((notification) => (
                <DropdownMenuItem 
                  key={notification.id}
                  className="flex flex-col items-start p-3 cursor-pointer"
                  onClick={() => handleMarkAsRead(notification.id)}
                >
                  <p className="text-sm">{notification.message}</p>
                  <span className="text-xs text-muted-foreground mt-1">
                    {new Date(notification.created_at).toLocaleString()}
                  </span>
                </DropdownMenuItem>
              ))
            )}
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Settings Button - Only for Super Admin */}
        {isSuperAdmin() && (
          <Button 
            variant="ghost" 
            size="icon"
            onClick={handleSettings}
          >
            <Settings className="h-5 w-5" />
          </Button>
        )}

        {/* Support/Help Button */}
        <Button 
          variant="ghost" 
          size="icon"
          onClick={() => navigate('/support')}
        >
          <HelpCircle className="h-5 w-5" />
        </Button>
      </div>
      </div>
    </header>
  );
};