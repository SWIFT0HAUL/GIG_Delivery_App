import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Settings, Save, RefreshCw, Database, Shield } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface PlatformSetting {
  setting_key: string;
  setting_value: any;
  description?: string;
}

export const SuperAdminSystemSettings = () => {
  const [settings, setSettings] = useState<PlatformSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  const fetchSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('platform_settings')
        .select('setting_key, setting_value, description')
        .order('setting_key');
      
      if (error) throw error;
      setSettings(data || []);
    } catch (error) {
      console.error('Error fetching settings:', error);
      toast({
        title: "Error",
        description: "Failed to fetch system settings",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const updateSetting = async (key: string, value: any) => {
    try {
      setSaving(key);
      const { error } = await supabase.rpc('update_platform_setting', {
        p_setting_key: key,
        p_setting_value: value
      });
      
      if (error) throw error;
      
      toast({
        title: "Success",
        description: `Setting ${key} updated successfully`,
      });
      
      fetchSettings();
    } catch (error) {
      console.error('Error updating setting:', error);
      toast({
        title: "Error",
        description: `Failed to update setting ${key}`,
        variant: "destructive",
      });
    } finally {
      setSaving(null);
    }
  };

  const clearCache = async () => {
    try {
      // This would typically clear application cache
      toast({
        title: "Cache Cleared",
        description: "Application cache has been cleared",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear cache",
        variant: "destructive",
      });
    }
  };

  const runMaintenance = async () => {
    try {
      // This would run database maintenance tasks
      toast({
        title: "Maintenance Started",
        description: "Database maintenance tasks are running in the background",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to run maintenance tasks",
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading Settings...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Settings className="h-5 w-5" />
            <span>System Settings</span>
          </CardTitle>
          <CardDescription>
            Configure platform-wide settings and system behavior
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {settings.map((setting) => (
            <div key={setting.setting_key} className="space-y-2">
              <Label htmlFor={setting.setting_key}>{setting.setting_key}</Label>
              {setting.description && (
                <p className="text-sm text-muted-foreground">{setting.description}</p>
              )}
              
              {typeof setting.setting_value === 'boolean' ? (
                <div className="flex items-center space-x-2">
                  <Switch
                    id={setting.setting_key}
                    checked={setting.setting_value}
                    onCheckedChange={(checked) => updateSetting(setting.setting_key, checked)}
                    disabled={saving === setting.setting_key}
                  />
                  <span>{setting.setting_value ? 'Enabled' : 'Disabled'}</span>
                </div>
              ) : typeof setting.setting_value === 'string' && setting.setting_value.length > 100 ? (
                <div className="space-y-2">
                  <Textarea
                    id={setting.setting_key}
                    value={setting.setting_value}
                    onChange={(e) => {
                      const newSettings = settings.map(s => 
                        s.setting_key === setting.setting_key 
                          ? { ...s, setting_value: e.target.value }
                          : s
                      );
                      setSettings(newSettings);
                    }}
                    disabled={saving === setting.setting_key}
                    rows={4}
                  />
                  <Button
                    size="sm"
                    onClick={() => updateSetting(setting.setting_key, setting.setting_value)}
                    disabled={saving === setting.setting_key}
                  >
                    {saving === setting.setting_key ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                    Save
                  </Button>
                </div>
              ) : (
                <div className="space-y-2">
                  <Input
                    id={setting.setting_key}
                    value={typeof setting.setting_value === 'object' ? JSON.stringify(setting.setting_value) : setting.setting_value}
                    onChange={(e) => {
                      const newSettings = settings.map(s => 
                        s.setting_key === setting.setting_key 
                          ? { ...s, setting_value: e.target.value }
                          : s
                      );
                      setSettings(newSettings);
                    }}
                    disabled={saving === setting.setting_key}
                  />
                  <Button
                    size="sm"
                    onClick={() => {
                      let value = setting.setting_value;
                      if (typeof value === 'string' && (value.startsWith('{') || value.startsWith('['))) {
                        try {
                          value = JSON.parse(value);
                        } catch (e) {
                          // Keep as string if JSON parse fails
                        }
                      }
                      updateSetting(setting.setting_key, value);
                    }}
                    disabled={saving === setting.setting_key}
                  >
                    {saving === setting.setting_key ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                    Save
                  </Button>
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Database className="h-5 w-5" />
            <span>System Maintenance</span>
          </CardTitle>
          <CardDescription>
            Perform system maintenance and optimization tasks
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex space-x-4">
            <Button onClick={clearCache} variant="outline">
              <RefreshCw className="h-4 w-4 mr-2" />
              Clear Cache
            </Button>
            <Button onClick={runMaintenance} variant="outline">
              <Database className="h-4 w-4 mr-2" />
              Run Maintenance
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-5 w-5" />
            <span>Security Settings</span>
          </CardTitle>
          <CardDescription>
            Configure security policies and access controls
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Security settings interface coming soon...
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
