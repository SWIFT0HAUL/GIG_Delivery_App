import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { 
  Upload, 
  Download, 
  Eye, 
  Edit, 
  Trash2, 
  Search, 
  Filter,
  FileText,
  CheckCircle,
  Clock,
  Info,
  Book,
  ChevronRight
} from 'lucide-react';
import { toast } from 'sonner';
import PdfViewer from './PdfViewer';

interface Document {
  id: string;
  document_name: string;
  version_number: string;
  category: 'sop' | 'policy' | 'tutorial' | 'release_note' | 'archived';
  file_path: string;
  file_size: number | null;
  description: string | null;
  linked_module: string | null;
  uploaded_by: string | null;
  approved_by: string | null;
  is_approved: boolean;
  is_archived: boolean;
  created_at: string;
  updated_at: string;
}

interface DocumentVersion {
  id: string;
  document_id: string;
  version_number: string;
  file_path: string;
  uploaded_by: string | null;
  created_at: string;
}

export const DocumentationCenter: React.FC = () => {
  const { user } = useAuth();
  const { hasSuperAdminAccess } = useUserRole();
  const [documents, setDocuments] = useState<Document[]>([]);
  const [versions, setVersions] = useState<Record<string, DocumentVersion[]>>({});
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('sop');
  const [uploadDialogOpen, setUploadDialogOpen] = useState(false);
  const [viewDialogOpen, setViewDialogOpen] = useState(false);
  const [selectedDocument, setSelectedDocument] = useState<Document | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string>('');
  const [uploading, setUploading] = useState(false);

  // Upload form state
  const [uploadForm, setUploadForm] = useState({
    document_name: '',
    version_number: '1.0',
    category: 'sop' as Document['category'],
    description: '',
    linked_module: '',
    file: null as File | null,
  });

  useEffect(() => {
    fetchDocuments();
  }, []);

  // Revoke blob URLs when dialog closes or on unmount to avoid leaks and Edge blocking
  useEffect(() => {
    if (!viewDialogOpen && pdfUrl?.startsWith('blob:')) {
      try { URL.revokeObjectURL(pdfUrl); } catch {}
      setPdfUrl('');
    }
    return () => {
      if (pdfUrl?.startsWith('blob:')) {
        try { URL.revokeObjectURL(pdfUrl); } catch {}
      }
    };
  }, [viewDialogOpen]);
  const fetchDocuments = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('admin_documents')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setDocuments(data || []);
    } catch (error) {
      console.error('Error fetching documents:', error);
      toast.error('Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const fetchVersions = async (documentId: string) => {
    try {
      const { data, error } = await supabase
        .from('document_versions')
        .select('*')
        .eq('document_id', documentId)
        .order('created_at', { ascending: false })
        .limit(3);

      if (error) throw error;
      setVersions(prev => ({ ...prev, [documentId]: data || [] }));
    } catch (error) {
      console.error('Error fetching versions:', error);
    }
  };

  const handleUpload = async () => {
    if (!uploadForm.file || !uploadForm.document_name) {
      toast.error('Please provide document name and file');
      return;
    }

    if (uploading) return; // Prevent multiple submissions

    try {
      setUploading(true);
      const category = uploadForm.category;
      const fileName = `${Date.now()}_${uploadForm.file.name}`;
      const filePath = `${category}/${fileName}`;

      // Upload file to storage
      const { error: uploadError } = await supabase.storage
        .from('admin_docs')
        .upload(filePath, uploadForm.file);

      if (uploadError) throw uploadError;

      // Insert document record
      const { data: docData, error: docError } = await supabase
        .from('admin_documents')
        .insert({
          document_name: uploadForm.document_name,
          version_number: uploadForm.version_number,
          category: uploadForm.category,
          file_path: filePath,
          file_size: uploadForm.file.size,
          description: uploadForm.description || null,
          linked_module: uploadForm.linked_module || null,
          uploaded_by: user?.id,
          is_approved: hasSuperAdminAccess(),
        })
        .select()
        .single();

      if (docError) throw docError;

      // Log activity
      await supabase.rpc('log_document_activity', {
        p_document_id: docData.id,
        p_action: 'UPLOAD',
        p_document_name: uploadForm.document_name,
        p_metadata: { version: uploadForm.version_number },
      });

      toast.success('Document uploaded successfully');
      setUploadDialogOpen(false);
      resetUploadForm();
      fetchDocuments();
    } catch (error) {
      console.error('Error uploading document:', error);
      toast.error('Failed to upload document');
    } finally {
      setUploading(false);
    }
  };

  const handleView = async (doc: Document) => {
    try {
      // Generate a fresh signed URL
      const { data, error } = await supabase.storage
        .from('admin_docs')
        .createSignedUrl(doc.file_path, 3600); // 1 hour expiry

      if (error) throw error;

      // Construct absolute URL
      const supabaseUrl = supabase.storage
        .from('admin_docs')
        .getPublicUrl('')
        .data.publicUrl.split('/object/public/')[0];
      const absoluteUrl = data.signedUrl.startsWith('http')
        ? data.signedUrl
        : `${supabaseUrl}${data.signedUrl}`;

      // Open in new window
      window.open(absoluteUrl, '_blank', 'noopener,noreferrer');
      
      toast.success('Document opened in new window');
    } catch (error) {
      console.error('Error generating signed URL:', error);
      toast.error('Failed to load document');
    }
  };
  const handleDownload = async (doc: Document) => {
    try {
      const { data, error } = await supabase.storage
        .from('admin_docs')
        .download(doc.file_path);

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.document_name;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      // Log activity
      await supabase.rpc('log_document_activity', {
        p_document_id: doc.id,
        p_action: 'DOWNLOAD',
        p_document_name: doc.document_name,
      });

      toast.success('Document downloaded');
    } catch (error) {
      console.error('Error downloading document:', error);
      toast.error('Failed to download document');
    }
  };

  const handleDelete = async (doc: Document) => {
    if (!confirm(`Are you sure you want to delete "${doc.document_name}"?`)) return;

    try {
      // Delete from storage
      const { error: storageError } = await supabase.storage
        .from('admin_docs')
        .remove([doc.file_path]);

      if (storageError) throw storageError;

      // Delete from database
      const { error: dbError } = await supabase
        .from('admin_documents')
        .delete()
        .eq('id', doc.id);

      if (dbError) throw dbError;

      // Log activity
      await supabase.rpc('log_document_activity', {
        p_document_id: doc.id,
        p_action: 'DELETE',
        p_document_name: doc.document_name,
      });

      toast.success('Document deleted successfully');
      fetchDocuments();
    } catch (error) {
      console.error('Error deleting document:', error);
      toast.error('Failed to delete document');
    }
  };

  const handleApprove = async (doc: Document) => {
    if (!hasSuperAdminAccess()) {
      toast.error('Only Super Admins can approve documents');
      return;
    }

    try {
      const { error } = await supabase
        .from('admin_documents')
        .update({ 
          is_approved: true, 
          approved_by: user?.id 
        })
        .eq('id', doc.id);

      if (error) throw error;

      // Log activity
      await supabase.rpc('log_document_activity', {
        p_document_id: doc.id,
        p_action: 'APPROVE',
        p_document_name: doc.document_name,
      });

      toast.success('Document approved');
      fetchDocuments();
    } catch (error) {
      console.error('Error approving document:', error);
      toast.error('Failed to approve document');
    }
  };

  const resetUploadForm = () => {
    setUploadForm({
      document_name: '',
      version_number: '1.0',
      category: 'sop',
      description: '',
      linked_module: '',
      file: null,
    });
  };

  const filteredDocuments = documents.filter(doc => {
    const matchesSearch = doc.document_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doc.description?.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'archived' 
      ? doc.is_archived 
      : doc.category === selectedCategory && !doc.is_archived;
    return matchesSearch && matchesCategory;
  });

  const categoryLabels: Record<string, string> = {
    sop: 'SOPs',
    policy: 'Policies',
    tutorial: 'Tutorials',
    release_note: 'Release Notes',
    archived: 'Archived Docs',
  };

  const categoryDescriptions: Record<string, { title: string; description: string; usage: string }> = {
    sop: {
      title: 'Standard Operating Procedures (SOPs)',
      description: 'Step-by-step instructions for performing tasks and processes on the platform.',
      usage: 'Browse documents relevant to your role or task. Follow instructions carefully.',
    },
    policy: {
      title: 'Policies',
      description: 'Company and platform policies that define rules, standards, and best practices.',
      usage: 'Read policies applicable to your role before taking actions.',
    },
    tutorial: {
      title: 'Tutorials',
      description: 'Step-by-step guides and tutorials for using the platform with screenshots, tips, and practical examples.',
      usage: 'Follow instructions carefully to complete tasks or training.',
    },
    release_note: {
      title: 'Release Notes',
      description: 'Platform updates, version histories, and changelogs explaining new features, improvements, bug fixes, and known issues.',
      usage: 'Review updates and changes to the platform.',
    },
    archived: {
      title: 'Archives',
      description: 'Deprecated or old versions of documents for historical reference.',
      usage: 'Access archived documents only when necessary.',
    },
  };

  return (
    <div className="space-y-6">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <span>Platform Settings</span>
        <ChevronRight className="h-4 w-4" />
        <span>Admin Resources</span>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground font-medium">Documentation Center</span>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Book className="h-8 w-8 text-primary" />
            Documentation Center
          </h1>
          <p className="text-muted-foreground mt-1">
            Manage SOPs, policies, tutorials, and release notes
          </p>
        </div>
      </div>

      {/* Upload Dialog */}
      <Dialog open={uploadDialogOpen} onOpenChange={setUploadDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Upload New Document</DialogTitle>
            <DialogDescription>
              Add a new document to the documentation center
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="doc-name">Document Name *</Label>
              <Input
                id="doc-name"
                value={uploadForm.document_name}
                onChange={(e) => setUploadForm({ ...uploadForm, document_name: e.target.value })}
                placeholder="e.g., User Pre-Approval Verification SOP"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="version">Version Number *</Label>
                <Input
                  id="version"
                  value={uploadForm.version_number}
                  onChange={(e) => setUploadForm({ ...uploadForm, version_number: e.target.value })}
                  placeholder="1.0"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="category">Category *</Label>
                <select
                  id="category"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={uploadForm.category}
                  onChange={(e) => setUploadForm({ ...uploadForm, category: e.target.value as Document['category'] })}
                >
                  <option value="sop">SOP</option>
                  <option value="policy">Policy</option>
                  <option value="tutorial">Tutorial</option>
                  <option value="release_note">Release Note</option>
                </select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="linked-module">Linked Module (Optional)</Label>
              <Input
                id="linked-module"
                value={uploadForm.linked_module}
                onChange={(e) => setUploadForm({ ...uploadForm, linked_module: e.target.value })}
                placeholder="e.g., User Management, Task Assignment"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={uploadForm.description}
                onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                placeholder="Brief description of the document"
                rows={3}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="file">Upload File (PDF, Video, Image, Doc) *</Label>
              <Input
                id="file"
                type="file"
                accept=".pdf,.mp4,.mov,.avi,.webm,.jpg,.jpeg,.png,.gif,.webp,.doc,.docx,.xls,.xlsx,.ppt,.pptx"
                onChange={(e) => setUploadForm({ ...uploadForm, file: e.target.files?.[0] || null })}
              />
              <p className="text-xs text-muted-foreground">
                Supported: PDF, Videos (MP4, MOV, AVI, WEBM), Images (JPG, PNG, GIF, WEBP), Office docs
              </p>
            </div>
            <Button 
              onClick={handleUpload} 
              className="w-full"
              disabled={uploading || !uploadForm.file || !uploadForm.document_name}
            >
              {uploading ? (
                <>
                  <Upload className="mr-2 h-4 w-4 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Upload Document
                </>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Search and Filter */}
      <div className="flex gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search documents..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="sop">SOPs</TabsTrigger>
          <TabsTrigger value="policy">Policies</TabsTrigger>
          <TabsTrigger value="tutorial">Tutorials</TabsTrigger>
          <TabsTrigger value="release_note">Release Notes</TabsTrigger>
          <TabsTrigger value="archived">Archived</TabsTrigger>
        </TabsList>

        {['sop', 'policy', 'tutorial', 'release_note', 'archived'].map((category) => (
          <TabsContent key={category} value={category} className="space-y-4">
            {/* Category Description */}
            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                <div className="space-y-2">
                  <p className="font-semibold">{categoryDescriptions[category].title}</p>
                  <p className="text-sm">{categoryDescriptions[category].description}</p>
                  <p className="text-sm text-muted-foreground">
                    <strong>How to use:</strong> {categoryDescriptions[category].usage}
                  </p>
                </div>
              </AlertDescription>
            </Alert>

            {/* Upload Button for Category */}
            {category !== 'archived' && (
              <div className="flex justify-end">
                <Button
                  onClick={() => {
                    setUploadForm({ ...uploadForm, category: category as Document['category'] });
                    setUploadDialogOpen(true);
                  }}
                  variant="default"
                  size="sm"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  Upload to {categoryLabels[category]}
                </Button>
              </div>
            )}

            {loading ? (
              <div className="text-center py-8">Loading documents...</div>
            ) : filteredDocuments.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <p className="text-muted-foreground">No documents in this category</p>
                  <p className="text-sm text-muted-foreground mt-2">
                    Upload your first document using the button above
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {filteredDocuments.map((doc) => (
                  <Card key={doc.id} className="shadow-sm hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <h3 className="text-lg font-semibold">{doc.document_name}</h3>
                            <Badge variant="outline">v{doc.version_number}</Badge>
                            {doc.is_approved ? (
                              <Badge variant="default" className="gap-1">
                                <CheckCircle className="h-3 w-3" />
                                Approved
                              </Badge>
                            ) : (
                              <Badge variant="secondary" className="gap-1">
                                <Clock className="h-3 w-3" />
                                Pending
                              </Badge>
                            )}
                          </div>
                          {doc.description && (
                            <p className="text-sm text-muted-foreground mb-2">{doc.description}</p>
                          )}
                          {doc.linked_module && (
                            <div className="flex items-center gap-1 text-sm text-muted-foreground">
                              <Info className="h-3 w-3" />
                              <span>Linked to: {doc.linked_module}</span>
                            </div>
                          )}
                          <div className="text-xs text-muted-foreground mt-2">
                            Added {new Date(doc.created_at).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleView(doc)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDownload(doc)}
                          >
                            <Download className="h-4 w-4" />
                          </Button>
                          {!doc.is_approved && hasSuperAdminAccess() && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleApprove(doc)}
                            >
                              <CheckCircle className="h-4 w-4" />
                            </Button>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDelete(doc)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>

      {/* View Document Dialog */}
      <Dialog open={viewDialogOpen} onOpenChange={setViewDialogOpen}>
        <DialogContent className="max-w-6xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>{selectedDocument?.document_name}</DialogTitle>
            <DialogDescription>
              Version {selectedDocument?.version_number}
            </DialogDescription>
          </DialogHeader>
          <div className="flex-1 overflow-hidden">
            {pdfUrl && selectedDocument && (() => {
              const fileExt = selectedDocument.file_path.split('.').pop()?.toLowerCase();
              const videoFormats = ['mp4', 'mov', 'avi', 'webm'];
              const imageFormats = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
              
              if (videoFormats.includes(fileExt || '')) {
                return (
                  <video
                    src={pdfUrl}
                    controls
                    className="w-full h-full rounded-md border bg-black"
                    title="Video Viewer"
                  >
                    Your browser does not support the video tag.
                  </video>
                );
              } else if (imageFormats.includes(fileExt || '')) {
                return (
                  <img
                    src={pdfUrl}
                    alt={selectedDocument.document_name}
                    className="w-full h-full object-contain rounded-md border"
                  />
                );
              } else if ((fileExt || '') === 'pdf') {
                return (
                  <div className="w-full h-full">
                    <PdfViewer url={pdfUrl} />
                    <div className="mt-2 text-xs text-muted-foreground px-1">
                      Having trouble? <a href={pdfUrl} target="_blank" rel="noreferrer" className="underline">Open PDF in new tab</a>.
                    </div>
                  </div>
                );
              } else {
                return (
                  <iframe
                    src={pdfUrl}
                    className="w-full h-full rounded-md border"
                    title="Document Viewer"
                  />
                );
              }
            })()}
          </div>
          {selectedDocument && versions[selectedDocument.id] && versions[selectedDocument.id].length > 0 && (
            <div className="border-t pt-4">
              <h4 className="font-semibold mb-2">Recent Versions</h4>
              <div className="space-y-2">
                {versions[selectedDocument.id].map((version) => (
                  <div key={version.id} className="flex items-center justify-between text-sm">
                    <span>Version {version.version_number}</span>
                    <span className="text-muted-foreground">
                      {new Date(version.created_at).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};
