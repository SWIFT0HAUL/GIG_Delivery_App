import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FinanceOverview } from './finance/FinanceOverview';
import { FinanceTransactions } from './finance/FinanceTransactions';
import { FinanceInvoices } from './finance/FinanceInvoices';
import { FinancePayouts } from './finance/FinancePayouts';
import { FinanceFunds } from './finance/FinanceFunds';
import { FinanceLedger } from './finance/FinanceLedger';
import { FinanceReports } from './finance/FinanceReports';
import { FinanceDisputes } from './finance/FinanceDisputes';
import { FinanceSettings } from './finance/FinanceSettings';

const FinanceAccounting = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-foreground">
          Finance & Accounting
        </h1>
        <p className="text-muted-foreground">
          Comprehensive financial management and accounting tools
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="grid w-full grid-cols-9 bg-muted/30">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="payouts">Payouts</TabsTrigger>
          <TabsTrigger value="funds">Funds</TabsTrigger>
          <TabsTrigger value="ledger">Ledger</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="disputes">Disputes</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <FinanceOverview />
        </TabsContent>

        <TabsContent value="transactions">
          <FinanceTransactions />
        </TabsContent>

        <TabsContent value="invoices">
          <FinanceInvoices />
        </TabsContent>

        <TabsContent value="payouts">
          <FinancePayouts />
        </TabsContent>

        <TabsContent value="funds">
          <FinanceFunds />
        </TabsContent>

        <TabsContent value="ledger">
          <FinanceLedger />
        </TabsContent>

        <TabsContent value="reports">
          <FinanceReports />
        </TabsContent>

        <TabsContent value="disputes">
          <FinanceDisputes />
        </TabsContent>

        <TabsContent value="settings">
          <FinanceSettings />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FinanceAccounting;