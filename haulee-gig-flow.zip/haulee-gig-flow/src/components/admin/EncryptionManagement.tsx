import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Shield, Key, Lock, AlertTriangle, CheckCircle, Server, Zap } from 'lucide-react';
import { useEncryptedFinancialData } from '@/hooks/useEncryptedFinancialData';

export function EncryptionManagement() {
  const [migrationInProgress, setMigrationInProgress] = useState(false);
  const [migrationComplete, setMigrationComplete] = useState(false);
  const [migrationResults, setMigrationResults] = useState<any>(null);
  const [hasPlainTextData, setHasPlainTextData] = useState(false);
  const { loading, error, migrateExistingData } = useEncryptedFinancialData();

  // Check for plain text data on component mount
  React.useEffect(() => {
    const checkForPlainTextData = async () => {
      try {
        const { data, error} = await supabase
          .from('vendor_merchant_onboarding')
          .select('account_number, routing_number, data_encrypted')
          .or('account_number.not.is.null,routing_number.not.is.null')
          .limit(100);
        
        if (data && data.length > 0) {
          // Check if any records have data_encrypted = false
          const hasUnencrypted = data.some(row => 
            row.data_encrypted === false &&
            (row.account_number || row.routing_number)
          );
          setHasPlainTextData(hasUnencrypted);
        }
      } catch (error) {
        console.error('Error checking for plain text data:', error);
      }
    };

    checkForPlainTextData();
  }, []);

  const handleMigrateData = async () => {
    try {
      setMigrationInProgress(true);
      const results = await migrateExistingData();
      setMigrationResults(results);
      setMigrationComplete(true);
      setHasPlainTextData(false); // Update status after successful migration
    } catch (error) {
      console.error('Migration failed:', error);
    } finally {
      setMigrationInProgress(false);
    }
  };

    return (
    <div className="space-y-6">
      {/* Critical Security Alert for Plain Text Data */}
      {hasPlainTextData && (
        <Alert className="border-destructive/50 bg-destructive/10">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertTitle className="text-destructive">CRITICAL SECURITY ISSUE</AlertTitle>
          <AlertDescription className="text-destructive/80">
            <strong>Sensitive financial data is stored in plain text!</strong>
            <br />
            Banking information (account numbers and routing numbers) is currently unencrypted and vulnerable to data theft.
            <br />
            <strong>Immediate action required:</strong> Run the data migration below to encrypt all financial data.
          </AlertDescription>
        </Alert>
      )}

      {/* Encryption Status Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className={hasPlainTextData ? "border-destructive/50 bg-destructive/10" : "border-accent/50 bg-accent/10"}>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Lock className={`h-4 w-4 ${hasPlainTextData ? 'text-destructive' : 'text-accent'}`} />
              Financial Data Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${hasPlainTextData ? 'text-destructive' : 'text-accent-foreground'}`}>
              {hasPlainTextData ? 'UNENCRYPTED' : 'ENCRYPTED'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {hasPlainTextData 
                ? 'Financial data needs encryption!' 
                : 'AES-256-GCM encryption active'
              }
            </p>
          </CardContent>
        </Card>

        <Card className="border-primary/50 bg-primary/10">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Key className="h-4 w-4 text-primary" />
              Encryption Keys
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">Secured</div>
            <p className="text-xs text-muted-foreground mt-1">
              256-bit keys stored in Supabase Vault
            </p>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Server className="h-4 w-4 text-purple-600" />
              Edge Function
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700">Deployed</div>
            <p className="text-xs text-muted-foreground mt-1">
              Secure processing at the edge
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Migration Status */}
      {migrationComplete && migrationResults && (
        <Alert className="border-accent/50 bg-accent/10">
          <CheckCircle className="h-4 w-4 text-accent" />
          <AlertTitle className="text-accent-foreground">Migration Complete!</AlertTitle>
          <AlertDescription className="text-accent-foreground/80">
            Successfully encrypted {migrationResults.migrated_count} Vendor/Merchant records.
            {migrationResults.errors && migrationResults.errors.length > 0 && (
              <span className="block mt-1 text-orange-700">
                Note: {migrationResults.errors.length} records had issues - check console for details.
              </span>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Error Display */}
      {error && (
        <Alert className="border-destructive/50 bg-destructive/10">
          <AlertTriangle className="h-4 w-4 text-destructive" />
          <AlertTitle className="text-destructive">Encryption Error</AlertTitle>
          <AlertDescription className="text-destructive/80">
            {error}
          </AlertDescription>
        </Alert>
      )}

      {/* Migration Progress */}
      {migrationInProgress && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-yellow-600 animate-pulse" />
              Encrypting Financial Data
            </CardTitle>
            <CardDescription>
              Migrating existing Vendor/Merchant financial data to encrypted storage...
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Progress value={75} className="w-full" />
            <p className="text-sm text-muted-foreground mt-2">
              Processing Vendor/Merchant records and encrypting sensitive financial information
            </p>
          </CardContent>
        </Card>
      )}

      {/* Encryption Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-blue-600" />
            Financial Data Encryption Management
          </CardTitle>
          <CardDescription>
            Manage encryption for sensitive financial data in Vendor/Merchant applications
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Security Features */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <h4 className="font-semibold text-sm">Encryption Features</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  <span className="text-sm">AES-256-GCM encryption</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  <span className="text-sm">Random IV for each encryption</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  <span className="text-sm">Base64 encoded storage</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-3 w-3 text-green-600" />
                  <span className="text-sm">Secure key management</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-3">
              <h4 className="font-semibold text-sm">Protected Data</h4>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Lock className="h-3 w-3 text-blue-600" />
                  <span className="text-sm">Credit card numbers</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock className="h-3 w-3 text-blue-600" />
                  <span className="text-sm">CVV security codes</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock className="h-3 w-3 text-blue-600" />
                  <span className="text-sm">Bank account numbers</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock className="h-3 w-3 text-blue-600" />
                  <span className="text-sm">Routing numbers</span>
                </div>
              </div>
            </div>
          </div>

          {/* Migration Section */}
          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-semibold text-sm">Data Migration {hasPlainTextData && <Badge variant="destructive" className="ml-2">Required</Badge>}</h4>
                <p className="text-sm text-muted-foreground">
                  {hasPlainTextData 
                    ? 'URGENT: Encrypt existing unprotected financial data'
                    : 'Encrypt existing financial data that may be stored in plain text'
                  }
                </p>
              </div>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button 
                    variant={hasPlainTextData ? "destructive" : "outline"}
                    disabled={loading || migrationInProgress}
                    className="flex items-center gap-2"
                  >
                    <Shield className="h-4 w-4" />
                    {migrationInProgress ? 'Encrypting...' : hasPlainTextData ? 'ENCRYPT NOW' : 'Migrate Data'}
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-orange-500" />
                      Encrypt Existing Financial Data
                    </AlertDialogTitle>
                    <AlertDialogDescription>
                      This will encrypt all existing Vendor/Merchant financial data that is currently stored in plain text.
                      <br /><br />
                      <strong>This operation:</strong>
                      <ul className="list-disc pl-4 mt-2 space-y-1">
                        <li>Will encrypt credit card numbers, CVV codes, bank account numbers, and routing numbers</li>
                        <li>Cannot be reversed without the encryption key</li>
                        <li>Will be logged for security audit purposes</li>
                        <li>May take several minutes to complete</li>
                      </ul>
                      <br />
                      Are you sure you want to proceed?
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction 
                      onClick={handleMigrateData}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      Encrypt Financial Data
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>

          {/* Compliance Information */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
              <div>
                <h4 className="font-semibold text-blue-800 text-sm">Compliance & Security</h4>
                <p className="text-sm text-blue-700 mt-1">
                  This encryption system implements PCI DSS Level 1 compliant data protection for credit card information
                  and follows banking industry standards for financial data security.
                </p>
                <div className="flex flex-wrap gap-2 mt-3">
                  <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">
                    PCI DSS Compliant
                  </Badge>
                  <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">
                    FIPS 140-2 Level 1
                  </Badge>
                  <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">
                    AES-256-GCM
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}