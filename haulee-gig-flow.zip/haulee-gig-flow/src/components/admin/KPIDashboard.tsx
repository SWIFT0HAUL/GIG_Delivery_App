import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { 
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, 
  Legend, ResponsiveContainer 
} from 'recharts';
import { 
  TrendingUp, Package, Users, DollarSign, 
  Clock, CheckCircle, RefreshCw, MapPin 
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface KPIMetric {
  label: string;
  value: string | number;
  change?: string;
  icon: any;
  trend?: 'up' | 'down' | 'neutral';
}

export const KPIDashboard = () => {
  const [loading, setLoading] = useState(true);
  const [dateFrom, setDateFrom] = useState<Date>();
  const [dateTo, setDateTo] = useState<Date>();
  const [roleFilter, setRoleFilter] = useState('all');
  const [regionFilter, setRegionFilter] = useState('all');
  const [vehicleFilter, setVehicleFilter] = useState('all');

  const [kpiMetrics, setKpiMetrics] = useState<KPIMetric[]>([]);
  const [jobsTrendData, setJobsTrendData] = useState<any[]>([]);
  const [jobsByStatusData, setJobsByStatusData] = useState<any[]>([]);
  const [revenueByRoleData, setRevenueByRoleData] = useState<any[]>([]);
  const [vehicleUtilizationData, setVehicleUtilizationData] = useState<any[]>([]);
  const [topPerformers, setTopPerformers] = useState<any[]>([]);
  const [performanceIndex, setPerformanceIndex] = useState(85);

  useEffect(() => {
    fetchDashboardData();
  }, [dateFrom, dateTo, roleFilter, regionFilter, vehicleFilter]);

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      // Fetch jobs data
      let jobsQuery = supabase.from('jobs').select('*');
      
      if (dateFrom) {
        jobsQuery = jobsQuery.gte('created_at', dateFrom.toISOString());
      }
      if (dateTo) {
        jobsQuery = jobsQuery.lte('created_at', dateTo.toISOString());
      }

      const { data: jobs } = await jobsQuery;

      // Fetch active drivers
      const { count: activeDrivers } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('role_key', 'driver')
        .eq('is_active', true);

      // Calculate KPIs
      const totalJobs = jobs?.length || 0;
      const completedJobs = jobs?.filter(j => j.status === 'completed').length || 0;
      const onTimeJobs = jobs?.filter(j => j.status === 'completed' && j.actual_delivery_time).length || 0;
      const onTimeRate = completedJobs > 0 ? ((onTimeJobs / completedJobs) * 100).toFixed(1) : '0';

      setKpiMetrics([
        { label: 'Total Jobs', value: totalJobs, change: '+12%', icon: Package, trend: 'up' },
        { label: 'Active Drivers', value: activeDrivers || 0, change: '+5%', icon: Users, trend: 'up' },
        { label: 'Completed Deliveries', value: completedJobs, change: '+8%', icon: CheckCircle, trend: 'up' },
        { label: 'Total Revenue', value: '$45,230', change: '+15%', icon: DollarSign, trend: 'up' },
        { label: 'Avg Delivery Time', value: '2.3h', change: '-10%', icon: Clock, trend: 'down' },
        { label: 'On-Time Rate', value: `${onTimeRate}%`, change: '+3%', icon: TrendingUp, trend: 'up' },
      ]);

      // Jobs trend over time (last 7 days)
      const trendData = [];
      for (let i = 6; i >= 0; i--) {
        const date = new Date();
        date.setDate(date.getDate() - i);
        const dayJobs = jobs?.filter(j => {
          const jobDate = new Date(j.created_at);
          return jobDate.toDateString() === date.toDateString();
        }).length || 0;
        
        trendData.push({
          date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
          jobs: dayJobs,
        });
      }
      setJobsTrendData(trendData);

      // Jobs by status
      const statuses = ['pending', 'assigned', 'in_progress', 'in_transit', 'on_hold', 'completed', 'cancelled'];
      const statusData = statuses.map(status => ({
        status: status.replace('_', ' ').toUpperCase(),
        count: jobs?.filter(j => j.status === status).length || 0,
      }));
      setJobsByStatusData(statusData);

      // Revenue by role (mock data)
      setRevenueByRoleData([
        { name: 'Drivers', value: 35000, color: '#3b82f6' },
        { name: 'Vendors', value: 25000, color: '#8b5cf6' },
        { name: 'Carriers', value: 15000, color: '#ec4899' },
        { name: 'Brokers', value: 10000, color: '#f59e0b' },
      ]);

      // Vehicle utilization (mock data)
      setVehicleUtilizationData([
        { vehicle: 'Van', small: 120, medium: 80, large: 50 },
        { vehicle: 'Box Truck', small: 60, medium: 100, large: 90 },
        { vehicle: 'Semi', small: 20, medium: 40, large: 150 },
        { vehicle: 'Cargo', small: 90, medium: 70, large: 40 },
      ]);

      // Top performers (mock data)
      setTopPerformers([
        { name: 'John Smith', jobs: 145, earnings: '$12,340', onTime: '98%' },
        { name: 'Sarah Johnson', jobs: 132, earnings: '$11,850', onTime: '96%' },
        { name: 'Mike Davis', jobs: 128, earnings: '$11,200', onTime: '95%' },
        { name: 'Emily Brown', jobs: 115, earnings: '$10,500', onTime: '94%' },
        { name: 'David Wilson', jobs: 108, earnings: '$9,850', onTime: '93%' },
      ]);

      // Calculate performance index
      const performanceScore = Math.round((parseFloat(onTimeRate) + (completedJobs / totalJobs * 100)) / 2);
      setPerformanceIndex(performanceScore || 85);

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#3b82f6', '#8b5cf6', '#ec4899', '#f59e0b'];

  if (loading) {
    return (
      <div className="space-y-6 p-6">
        <Skeleton className="h-32 w-full" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-64" />)}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Analytics & Insights</h1>
          <p className="text-muted-foreground">Comprehensive data visualization for operational decisions</p>
        </div>

        {/* Filter Bar */}
        <div className="flex flex-wrap gap-3">
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" className="min-w-[200px] justify-start">
                {dateFrom ? (
                  dateTo ? (
                    `${format(dateFrom, 'MMM dd')} - ${format(dateTo, 'MMM dd')}`
                  ) : (
                    format(dateFrom, 'MMM dd, yyyy')
                  )
                ) : (
                  'Select date range'
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="start">
              <div className="p-3 space-y-2">
                <p className="text-sm font-medium">From</p>
                <Calendar mode="single" selected={dateFrom} onSelect={setDateFrom} />
                <p className="text-sm font-medium">To</p>
                <Calendar mode="single" selected={dateTo} onSelect={setDateTo} />
              </div>
            </PopoverContent>
          </Popover>
          
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              <SelectItem value="driver">Drivers</SelectItem>
              <SelectItem value="shipper">Shippers</SelectItem>
              <SelectItem value="carrier">Carriers</SelectItem>
              <SelectItem value="vendor">Vendors</SelectItem>
            </SelectContent>
          </Select>

          <Select value={regionFilter} onValueChange={setRegionFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Regions</SelectItem>
              <SelectItem value="north">North</SelectItem>
              <SelectItem value="south">South</SelectItem>
              <SelectItem value="east">East</SelectItem>
              <SelectItem value="west">West</SelectItem>
            </SelectContent>
          </Select>

          <Select value={vehicleFilter} onValueChange={setVehicleFilter}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder="Vehicle" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Vehicles</SelectItem>
              <SelectItem value="van">Van</SelectItem>
              <SelectItem value="truck">Box Truck</SelectItem>
              <SelectItem value="semi">Semi</SelectItem>
            </SelectContent>
          </Select>

          <Button variant="outline" size="icon" onClick={fetchDashboardData}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Overview KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {kpiMetrics.map((metric, idx) => (
          <Card key={idx}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <p className="text-xs text-muted-foreground">{metric.label}</p>
                  <p className="text-2xl font-bold">{metric.value}</p>
                  {metric.change && (
                    <p className={`text-xs ${metric.trend === 'up' ? 'text-green-600' : metric.trend === 'down' ? 'text-red-600' : 'text-muted-foreground'}`}>
                      {metric.change}
                    </p>
                  )}
                </div>
                <metric.icon className="h-5 w-5 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Line Chart - Jobs Over Time */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Jobs Completed Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={jobsTrendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }} 
                />
                <Area 
                  type="monotone" 
                  dataKey="jobs" 
                  stroke="hsl(var(--primary))" 
                  fill="hsl(var(--primary) / 0.2)" 
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Bar Chart - Jobs by Status */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Jobs by Status</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={jobsByStatusData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="status" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }} 
                />
                <Bar dataKey="count" fill="hsl(var(--primary))" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Pie Chart - Revenue by Role */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Revenue by Role</CardTitle>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={revenueByRoleData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={90}
                  dataKey="value"
                  label={(entry) => `${entry.name}: $${(entry.value / 1000).toFixed(0)}k`}
                  labelLine={false}
                >
                  {revenueByRoleData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value: any) => `$${value.toLocaleString()}`}
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }} 
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Gauge Chart - Performance Index */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Platform Performance Index</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center justify-center">
            <div className="relative w-40 h-40 flex items-center justify-center">
              <svg className="transform -rotate-90 w-40 h-40">
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="hsl(var(--border))"
                  strokeWidth="12"
                  fill="transparent"
                />
                <circle
                  cx="80"
                  cy="80"
                  r="70"
                  stroke="hsl(var(--primary))"
                  strokeWidth="12"
                  fill="transparent"
                  strokeDasharray={`${(performanceIndex / 100) * 439.6} 439.6`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-3xl font-bold">{performanceIndex}%</span>
                <span className="text-xs text-muted-foreground">Performance</span>
              </div>
            </div>
            <p className="text-sm text-center text-muted-foreground mt-4">
              On-time delivery & completion rate
            </p>
          </CardContent>
        </Card>

        {/* Stacked Column Chart - Vehicle Utilization */}
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-base">Route Volume per Vehicle Type</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={vehicleUtilizationData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="vehicle" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }} 
                />
                <Legend />
                <Bar dataKey="small" stackId="a" fill="#3b82f6" radius={[0, 0, 0, 0]} />
                <Bar dataKey="medium" stackId="a" fill="#8b5cf6" radius={[0, 0, 0, 0]} />
                <Bar dataKey="large" stackId="a" fill="#ec4899" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Deep Dive Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Performers */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Top Performers</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Driver</TableHead>
                  <TableHead className="text-right">Jobs</TableHead>
                  <TableHead className="text-right">Earnings</TableHead>
                  <TableHead className="text-right">On-Time %</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {topPerformers.map((performer, idx) => (
                  <TableRow key={idx}>
                    <TableCell className="font-medium">{performer.name}</TableCell>
                    <TableCell className="text-right">{performer.jobs}</TableCell>
                    <TableCell className="text-right">{performer.earnings}</TableCell>
                    <TableCell className="text-right text-green-600">{performer.onTime}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Recent Activity Timeline</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { time: '2 min ago', event: 'Job #4523 completed by John Smith', icon: CheckCircle, color: 'text-green-600' },
                { time: '15 min ago', event: 'New driver registered: Sarah Connor', icon: Users, color: 'text-blue-600' },
                { time: '1 hour ago', event: 'Route optimization completed for Zone A', icon: MapPin, color: 'text-purple-600' },
                { time: '2 hours ago', event: 'Peak delivery time detected', icon: TrendingUp, color: 'text-orange-600' },
                { time: '3 hours ago', event: '50 jobs dispatched successfully', icon: Package, color: 'text-cyan-600' },
              ].map((activity, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <activity.icon className={`h-5 w-5 mt-0.5 ${activity.color}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{activity.event}</p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
