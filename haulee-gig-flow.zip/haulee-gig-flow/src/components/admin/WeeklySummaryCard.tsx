import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, TrendingUp, Activity, Download } from 'lucide-react';
import { format, startOfWeek, endOfWeek } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

export function WeeklySummaryCard() {
  const { user } = useAuth();
  const [summary, setSummary] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  const weekStart = startOfWeek(new Date(), { weekStartsOn: 1 });
  const weekEnd = endOfWeek(new Date(), { weekStartsOn: 1 });

  useEffect(() => {
    fetchWeeklySummary();
  }, [user]);

  const fetchWeeklySummary = async () => {
    try {
      const { data, error } = await supabase
        .from('timesheet_weekly_summaries')
        .select('*')
        .eq('admin_id', user?.id)
        .eq('week_start', format(weekStart, 'yyyy-MM-dd'))
        .maybeSingle();

      if (error) throw error;
      setSummary(data);
    } catch (error: any) {
      console.error('Error fetching weekly summary:', error);
    } finally {
      setLoading(false);
    }
  };

  const generateSummary = async () => {
    try {
      const { error } = await supabase.rpc('generate_weekly_summary', {
        _admin_id: user?.id,
        _week_start: format(weekStart, 'yyyy-MM-dd')
      });

      if (error) throw error;

      toast.success('Weekly summary generated successfully');
      fetchWeeklySummary();
    } catch (error: any) {
      toast.error('Failed to generate summary: ' + error.message);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-muted-foreground">Loading weekly summary...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Weekly Summary
        </CardTitle>
        <CardDescription>
          {format(weekStart, 'MMM dd')} - {format(weekEnd, 'MMM dd, yyyy')}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {summary ? (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Total Hours</p>
                <p className="text-2xl font-bold">{parseFloat(summary.total_hours).toFixed(1)}h</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Overtime</p>
                <p className="text-2xl font-bold text-orange-500">
                  {parseFloat(summary.overtime_hours).toFixed(1)}h
                </p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-muted-foreground">Activities</p>
                <p className="text-2xl font-bold">{summary.total_activities}</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Badge variant={summary.status === 'generated' ? 'default' : 'secondary'}>
                {summary.status}
              </Badge>
              <Button variant="outline" size="sm" onClick={generateSummary}>
                <TrendingUp className="h-4 w-4 mr-2" />
                Regenerate
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center py-4">
            <p className="text-muted-foreground mb-4">No summary generated yet for this week</p>
            <Button onClick={generateSummary}>
              <Activity className="h-4 w-4 mr-2" />
              Generate Summary
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
