import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Search, Save } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Menu {
  id: string;
  name: string;
  path: string;
  category: string | null;
  icon: string | null;
}

interface Permission {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
}

interface MenuPermission {
  menu_id: string;
  permission_id: string;
}

export const MenuPermissionMapping = () => {
  const { toast } = useToast();
  const [menus, setMenus] = useState<Menu[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [menuPermissions, setMenuPermissions] = useState<Map<string, Set<string>>>(new Map());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);

      // Fetch menus
      const { data: menusData, error: menusError } = await supabase
        .from('menus')
        .select('*')
        .order('category', { ascending: true })
        .order('name', { ascending: true });

      if (menusError) throw menusError;

      // Fetch permissions
      const { data: permissionsData, error: permissionsError } = await supabase
        .from('permissions')
        .select('*')
        .order('category', { ascending: true })
        .order('name', { ascending: true });

      if (permissionsError) throw permissionsError;

      // Fetch existing menu-permission mappings
      const { data: mappingsData, error: mappingsError } = await supabase
        .from('menu_permissions')
        .select('menu_id, permission_id');

      if (mappingsError) throw mappingsError;

      // Build the menu permissions map
      const mappingsMap = new Map<string, Set<string>>();
      mappingsData?.forEach((mapping: MenuPermission) => {
        if (!mappingsMap.has(mapping.menu_id)) {
          mappingsMap.set(mapping.menu_id, new Set());
        }
        mappingsMap.get(mapping.menu_id)!.add(mapping.permission_id);
      });

      setMenus(menusData || []);
      setPermissions(permissionsData || []);
      setMenuPermissions(mappingsMap);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load menu-permission mappings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const togglePermission = (menuId: string, permissionId: string) => {
    const newMappings = new Map(menuPermissions);
    
    if (!newMappings.has(menuId)) {
      newMappings.set(menuId, new Set());
    }

    const menuPerms = newMappings.get(menuId)!;
    
    if (menuPerms.has(permissionId)) {
      menuPerms.delete(permissionId);
    } else {
      menuPerms.add(permissionId);
    }

    setMenuPermissions(newMappings);
    setHasChanges(true);
  };

  const handleSave = async () => {
    try {
      setSaving(true);

      // Delete all existing mappings
      const { error: deleteError } = await supabase
        .from('menu_permissions')
        .delete()
        .neq('id', '00000000-0000-0000-0000-000000000000');

      if (deleteError) throw deleteError;

      // Insert new mappings
      const mappingsToInsert: { menu_id: string; permission_id: string }[] = [];
      menuPermissions.forEach((permissions, menuId) => {
        permissions.forEach(permissionId => {
          mappingsToInsert.push({ menu_id: menuId, permission_id: permissionId });
        });
      });

      if (mappingsToInsert.length > 0) {
        const { error: insertError } = await supabase
          .from('menu_permissions')
          .insert(mappingsToInsert);

        if (insertError) throw insertError;
      }

      toast({
        title: 'Success',
        description: 'Menu-permission mappings saved successfully',
      });
      setHasChanges(false);
    } catch (error) {
      console.error('Error saving mappings:', error);
      toast({
        title: 'Error',
        description: 'Failed to save menu-permission mappings',
        variant: 'destructive',
      });
    } finally {
      setSaving(false);
    }
  };

  const filteredMenus = menus.filter(menu =>
    menu.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    menu.path?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    menu.category?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedPermissions = permissions.reduce((acc, permission) => {
    const category = permission.category || 'Uncategorized';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(permission);
    return acc;
  }, {} as Record<string, Permission[]>);

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Menu-Permission Mapping</CardTitle>
        <CardDescription>
          Configure which permissions are associated with each menu item
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search menus..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="max-w-sm"
          />
          {hasChanges && (
            <Button onClick={handleSave} disabled={saving} className="ml-auto">
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          )}
        </div>

        <ScrollArea className="h-[600px]">
          <div className="space-y-6">
            {filteredMenus.map((menu) => (
              <Card key={menu.id} className="p-4">
                <div className="space-y-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-semibold text-lg">{menu.name}</h3>
                      <p className="text-sm text-muted-foreground">{menu.path}</p>
                      {menu.category && (
                        <Badge variant="outline" className="mt-1">
                          {menu.category}
                        </Badge>
                      )}
                    </div>
                    <Badge variant="secondary">
                      {menuPermissions.get(menu.id)?.size || 0} permissions
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <p className="text-sm font-medium">Associated Permissions:</p>
                    {Object.entries(groupedPermissions).map(([category, perms]) => (
                      <div key={category} className="space-y-2">
                        <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
                          {category}
                        </p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pl-4">
                          {perms.map((permission) => (
                            <div
                              key={permission.id}
                              className="flex items-start space-x-2"
                            >
                              <Checkbox
                                id={`${menu.id}-${permission.id}`}
                                checked={menuPermissions.get(menu.id)?.has(permission.id) || false}
                                onCheckedChange={() => togglePermission(menu.id, permission.id)}
                              />
                              <label
                                htmlFor={`${menu.id}-${permission.id}`}
                                className="text-sm leading-none cursor-pointer"
                              >
                                <div className="font-medium">{permission.name}</div>
                                {permission.description && (
                                  <div className="text-xs text-muted-foreground mt-0.5">
                                    {permission.description}
                                  </div>
                                )}
                              </label>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </ScrollArea>

        {hasChanges && (
          <div className="bg-muted p-3 rounded-md text-sm">
            ⚠️ You have unsaved changes. Click "Save Changes" to apply them.
          </div>
        )}
      </CardContent>
    </Card>
  );
};
