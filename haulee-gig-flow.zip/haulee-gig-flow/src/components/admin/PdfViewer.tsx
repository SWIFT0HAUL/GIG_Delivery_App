import React, { useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';

// Configure worker
pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;

interface PdfViewerProps {
  url: string; // blob or signed URL
}

const PdfViewer: React.FC<PdfViewerProps> = ({ url }) => {
  const [numPages, setNumPages] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);

  function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
    setNumPages(numPages);
    setError(null);
  }

  function onDocumentLoadError(error: Error) {
    console.error('PDF load error:', error);
    setError('Unable to load PDF. Please try again.');
  }

  if (!url) {
    return (
      <div className="flex items-center justify-center h-full p-4">
        <p className="text-muted-foreground">No PDF uploaded or readable</p>
      </div>
    );
  }

  return (
    <div className="w-full h-full overflow-auto">
      {error ? (
        <div className="flex items-center justify-center h-full p-4">
          <p className="text-sm text-destructive-foreground/80">{error}</p>
        </div>
      ) : (
        <div className="flex flex-col items-center p-4 space-y-4">
          <Document
            file={url}
            onLoadSuccess={onDocumentLoadSuccess}
            onLoadError={onDocumentLoadError}
            loading={
              <div className="flex items-center justify-center p-8">
                <p className="text-muted-foreground">Loading PDF...</p>
              </div>
            }
          >
            {numPages &&
              Array.from(new Array(numPages), (_, index) => (
                <Page
                  key={`page_${index + 1}`}
                  pageNumber={index + 1}
                  width={800}
                  className="mb-4 shadow-md"
                  renderTextLayer={false}
                  renderAnnotationLayer={false}
                />
              ))}
          </Document>
        </div>
      )}
    </div>
  );
};

export default PdfViewer;
