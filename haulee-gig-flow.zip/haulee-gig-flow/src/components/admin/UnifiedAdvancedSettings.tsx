import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import { 
  Settings, 
  Sliders, 
  Database, 
  Palette,
  Globe,
  Shield,
  Bell,
  Wrench,
  ChevronRight,
  Home
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { AdvancedSettings } from './settings/AdvancedSettings';
import { PlatformSettings } from './PlatformSettings';
import { DriverSettings } from './settings/DriverSettings';
import { ShipperSettings } from './settings/ShipperSettings';
import { BrokerSettings } from './settings/BrokerSettings';
import { VendorSettings } from './settings/VendorSettings';
import { CarrierSettings } from './settings/CarrierSettings';
import { useUserRole } from '@/hooks/useUserRole';
import { Badge } from '@/components/ui/badge';

type SettingsSection = 
  | 'overview'
  | 'platform'
  | 'database'
  | 'customization'
  | 'integrations'
  | 'security'
  | 'notifications'
  | 'driver'
  | 'shipper'
  | 'broker'
  | 'vendor'
  | 'carrier';

interface NavigationItem {
  id: SettingsSection;
  label: string;
  icon: React.ElementType;
  description: string;
  badge?: string;
  superAdminOnly?: boolean;
}

const navigationItems: NavigationItem[] = [
  {
    id: 'overview',
    label: 'Overview',
    icon: Home,
    description: 'Settings dashboard and quick actions',
  },
  // Platform Settings Section
  {
    id: 'platform',
    label: 'Platform Configuration',
    icon: Globe,
    description: 'General platform settings, currency, timezone',
  },
  {
    id: 'database',
    label: 'Database Settings',
    icon: Database,
    description: 'Advanced database configuration and maintenance',
    badge: 'Advanced',
  },
  {
    id: 'customization',
    label: 'Appearance & Branding',
    icon: Palette,
    description: 'Theme, colors, fonts, and branding',
  },
  {
    id: 'integrations',
    label: 'Integrations & APIs',
    icon: Sliders,
    description: 'Third-party services and API keys',
  },
  {
    id: 'security',
    label: 'Security & Access',
    icon: Shield,
    description: 'Security policies and user permissions',
    superAdminOnly: true,
  },
  {
    id: 'notifications',
    label: 'Notifications',
    icon: Bell,
    description: 'Email, SMS, push settings',
  },
  // User Settings Section
  {
    id: 'driver',
    label: 'Driver Settings',
    icon: Wrench,
    description: 'Driver-specific configuration and preferences',
  },
  {
    id: 'shipper',
    label: 'Shipper Settings',
    icon: Wrench,
    description: 'Shipper-specific configuration and preferences',
  },
  {
    id: 'broker',
    label: 'Broker Settings',
    icon: Wrench,
    description: 'Broker-specific configuration and preferences',
  },
  {
    id: 'vendor',
    label: 'Vendor Settings',
    icon: Wrench,
    description: 'Vendor-specific configuration and preferences',
  },
  {
    id: 'carrier',
    label: 'Carrier Settings',
    icon: Wrench,
    description: 'Carrier-specific configuration and preferences',
  },
];

export function UnifiedAdvancedSettings() {
  const [activeSection, setActiveSection] = useState<SettingsSection>('overview');
  const { isSuperAdmin } = useUserRole();
  const hasSuperAdminAccess = isSuperAdmin();

  const filteredNavItems = navigationItems.filter(
    item => !item.superAdminOnly || hasSuperAdminAccess
  );

  const renderContent = () => {
    switch (activeSection) {
      case 'overview':
        return <SettingsOverview onNavigate={setActiveSection} items={filteredNavItems} />;
      // Platform Settings
      case 'platform':
        return <PlatformSettings />;
      case 'database':
        return <AdvancedSettings />;
      case 'customization':
        return <CustomizationSettings />;
      case 'integrations':
        return <IntegrationsSettings />;
      case 'security':
        return <SecuritySettings />;
      case 'notifications':
        return <NotificationsSettings />;
      // User Settings
      case 'driver':
        return <DriverSettings />;
      case 'shipper':
        return <ShipperSettings />;
      case 'broker':
        return <BrokerSettings />;
      case 'vendor':
        return <VendorSettings />;
      case 'carrier':
        return <CarrierSettings />;
      default:
        return <SettingsOverview onNavigate={setActiveSection} items={filteredNavItems} />;
    }
  };

  return (
    <div className="h-screen bg-background overflow-hidden">
      <ResizablePanelGroup direction="horizontal" className="h-full">
        {/* Sidebar Navigation */}
        <ResizablePanel defaultSize={20} minSize={15} maxSize={35}>
          <aside className="h-full border-r bg-card flex flex-col">
        <div className="p-6 border-b">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-primary/10">
              <Settings className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="text-lg font-semibold">Advanced Settings</h2>
              <p className="text-xs text-muted-foreground">Platform & User Configuration</p>
            </div>
          </div>
        </div>

        <ScrollArea className="flex-1 px-3 py-4">
          <nav className="space-y-4">
            {/* Platform Settings Section */}
            <div>
              <div className="px-3 py-2">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Platform Settings
                </h3>
              </div>
              <div className="space-y-1">
                {filteredNavItems.filter(item => 
                  ['overview', 'platform', 'database', 'customization', 'integrations', 'security', 'notifications'].includes(item.id)
                ).map((item) => {
                  const Icon = item.icon;
                  const isActive = activeSection === item.id;

                  return (
                    <Button
                      key={item.id}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start gap-3 h-auto py-3 px-3 hover:bg-accent/50 transition-all overflow-hidden",
                        isActive && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground shadow-sm"
                      )}
                      onClick={() => setActiveSection(item.id)}
                    >
                      <Icon className={cn("h-4 w-4 flex-shrink-0", isActive && "animate-scale-in")} />
                      <div className="flex-1 text-left min-w-0 overflow-hidden">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-medium text-sm truncate">{item.label}</span>
                          {item.badge && (
                            <Badge variant="secondary" className="text-[10px] h-4 px-1.5 flex-shrink-0">
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                        <p className={cn(
                          "text-xs mt-0.5 line-clamp-1 break-words",
                          isActive ? "text-primary-foreground/80" : "text-muted-foreground"
                        )}>
                          {item.description}
                        </p>
                      </div>
                      {isActive && (
                        <ChevronRight className="h-4 w-4 ml-auto flex-shrink-0 animate-fade-in" />
                      )}
                    </Button>
                  );
                })}
              </div>
            </div>

            {/* User Settings Section */}
            <div>
              <div className="px-3 py-2">
                <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  User Settings
                </h3>
              </div>
              <div className="space-y-1">
                {filteredNavItems.filter(item => 
                  ['driver', 'shipper', 'broker', 'vendor', 'carrier'].includes(item.id)
                ).map((item) => {
                  const Icon = item.icon;
                  const isActive = activeSection === item.id;

                  return (
                    <Button
                      key={item.id}
                      variant="ghost"
                      className={cn(
                        "w-full justify-start gap-3 h-auto py-3 px-3 hover:bg-accent/50 transition-all overflow-hidden",
                        isActive && "bg-primary text-primary-foreground hover:bg-primary hover:text-primary-foreground shadow-sm"
                      )}
                      onClick={() => setActiveSection(item.id)}
                    >
                      <Icon className={cn("h-4 w-4 flex-shrink-0", isActive && "animate-scale-in")} />
                      <div className="flex-1 text-left min-w-0 overflow-hidden">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-medium text-sm truncate">{item.label}</span>
                          {item.badge && (
                            <Badge variant="secondary" className="text-[10px] h-4 px-1.5 flex-shrink-0">
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                        <p className={cn(
                          "text-xs mt-0.5 line-clamp-1 break-words",
                          isActive ? "text-primary-foreground/80" : "text-muted-foreground"
                        )}>
                          {item.description}
                        </p>
                      </div>
                      {isActive && (
                        <ChevronRight className="h-4 w-4 ml-auto flex-shrink-0 animate-fade-in" />
                      )}
                    </Button>
                  );
                })}
              </div>
            </div>
          </nav>
        </ScrollArea>
          </aside>
        </ResizablePanel>

        <ResizableHandle withHandle />

        {/* Main Content Area */}
        <ResizablePanel defaultSize={80}>
          <main className="h-full overflow-hidden">
        <ScrollArea className="h-full">
          <div className="p-6 md:p-8 max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </ScrollArea>
          </main>
        </ResizablePanel>
      </ResizablePanelGroup>
    </div>
  );
}

// Settings Overview Component
function SettingsOverview({ onNavigate, items }: { onNavigate: (section: SettingsSection) => void; items: NavigationItem[] }) {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Settings Overview</h1>
        <p className="text-muted-foreground mt-2">
          Manage your platform configuration, appearance, and integrations
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.filter(item => item.id !== 'overview').map((item) => {
          const Icon = item.icon;
          return (
            <Card 
              key={item.id}
              className="hover:shadow-lg transition-all duration-300 cursor-pointer hover:scale-[1.02] hover:border-primary/50 group overflow-hidden"
              onClick={() => onNavigate(item.id)}
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <div className="p-3 rounded-lg bg-gradient-to-br from-primary/10 to-primary/5 group-hover:from-primary/20 group-hover:to-primary/10 transition-colors flex-shrink-0">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0 overflow-hidden">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <h3 className="font-semibold group-hover:text-primary transition-colors truncate">
                        {item.label}
                      </h3>
                      {item.badge && (
                        <Badge variant="secondary" className="text-[10px] flex-shrink-0">
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 break-words">
                      {item.description}
                    </p>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all flex-shrink-0" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <Wrench className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">Quick Actions</h3>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <Button variant="outline" size="sm" className="justify-start min-w-0" onClick={() => onNavigate('platform')}>
              <Globe className="h-4 w-4 mr-2 flex-shrink-0" />
              <span className="truncate">Platform</span>
            </Button>
            <Button variant="outline" size="sm" className="justify-start min-w-0" onClick={() => onNavigate('customization')}>
              <Palette className="h-4 w-4 mr-2 flex-shrink-0" />
              <span className="truncate">Theme</span>
            </Button>
            <Button variant="outline" size="sm" className="justify-start min-w-0" onClick={() => onNavigate('integrations')}>
              <Sliders className="h-4 w-4 mr-2 flex-shrink-0" />
              <span className="truncate">API Keys</span>
            </Button>
            <Button variant="outline" size="sm" className="justify-start min-w-0" onClick={() => onNavigate('database')}>
              <Database className="h-4 w-4 mr-2 flex-shrink-0" />
              <span className="truncate">Database</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Placeholder components for other sections
function CustomizationSettings() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight break-words">Appearance & Branding</h1>
        <p className="text-muted-foreground mt-2 break-words">Customize your platform&apos;s look and feel</p>
      </div>
      <Card>
        <CardContent className="p-8 text-center">
          <Palette className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground break-words">Theme customization coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}

function IntegrationsSettings() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight break-words">Integrations & APIs</h1>
        <p className="text-muted-foreground mt-2 break-words">Manage third-party services and API keys</p>
      </div>
      <Card>
        <CardContent className="p-8 text-center">
          <Sliders className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground break-words">Integrations management coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}

function SecuritySettings() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold tracking-tight break-words">Security & Access</h1>
        <p className="text-muted-foreground mt-2 break-words">Configure security policies and access controls</p>
      </div>
      <Card>
        <CardContent className="p-8 text-center">
          <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground break-words">Security settings coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}

function NotificationsSettings() {
  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight break-words">Notifications</h1>
        <p className="text-sm md:text-base text-muted-foreground mt-2 break-words">Configure email, SMS, and push notifications</p>
      </div>
      <Card>
        <CardContent className="p-8 text-center">
          <Bell className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-sm md:text-base text-muted-foreground break-words">Notification settings coming soon...</p>
        </CardContent>
      </Card>
    </div>
  );
}
