import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { toast } from 'sonner';
import { Plus, Pencil, Trash2, Search, Eye, EyeOff, Loader2, Users, Settings, List, UserCog } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import * as Icons from 'lucide-react';
import { ALL_SUB_ROLES, getSubRoleLabel } from '@/lib/subRoleConfig';

interface Menu {
  id: string;
  name: string;
  path: string;
  icon: string | null;
  category: string | null;
  display_order: number;
  is_active: boolean;
  display_mode: 'normal' | 'hidden' | 'disabled';
  created_at: string;
}

interface Role {
  id: string;
  role_key: string;
  description: string | null;
}

const ICON_OPTIONS = [
  'Home', 'LayoutDashboard', 'Users', 'Briefcase', 'Package', 'Truck', 'Car', 
  'Store', 'ShoppingCart', 'DollarSign', 'CreditCard', 'FileText', 'BarChart',
  'Settings', 'Bell', 'User', 'Shield', 'Lock', 'MapPin', 'Calendar',
  'Clock', 'CheckCircle', 'AlertCircle', 'TrendingUp', 'Star', 'Heart'
];

export const MenuManagement = () => {
  const [menus, setMenus] = useState<Menu[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [roleAssignDialogOpen, setRoleAssignDialogOpen] = useState(false);
  const [editingMenu, setEditingMenu] = useState<Menu | null>(null);
  const [menuToDelete, setMenuToDelete] = useState<Menu | null>(null);
  const [selectedMenuForRoles, setSelectedMenuForRoles] = useState<Menu | null>(null);
  const [assignedRoles, setAssignedRoles] = useState<string[]>([]);
  const [savingRoles, setSavingRoles] = useState(false);
  const [updatingMenu, setUpdatingMenu] = useState<string | null>(null);
  const [deletingMenu, setDeletingMenu] = useState(false);
  const [subRoleAssignDialogOpen, setSubRoleAssignDialogOpen] = useState(false);
  const [selectedMenuForSubRoles, setSelectedMenuForSubRoles] = useState<Menu | null>(null);
  const [assignedSubRoles, setAssignedSubRoles] = useState<string[]>([]);
  const [savingSubRoles, setSavingSubRoles] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    path: '',
    icon: '',
    category: '',
    display_order: 0,
    is_active: true,
    display_mode: 'normal' as 'normal' | 'hidden' | 'disabled'
  });

  useEffect(() => {
    fetchMenus();
    fetchRoles();
  }, []);

  const fetchMenus = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('menus')
        .select('*')
        .order('display_order', { ascending: true });

      if (error) throw error;
      setMenus((data || []) as Menu[]);
    } catch (error) {
      console.error('Error fetching menus:', error);
      toast.error('Failed to fetch menus');
    } finally {
      setLoading(false);
    }
  };

  const fetchRoles = async () => {
    try {
      const { data, error } = await supabase
        .from('roles')
        .select('id, role_key, description')
        .eq('is_active', true);

      if (error) throw error;
      setRoles(data || []);
    } catch (error) {
      console.error('Error fetching roles:', error);
    }
  };

  const fetchMenuRoles = async (menuId: string) => {
    try {
      const { data, error } = await supabase
        .from('role_menu_permissions')
        .select('role_id')
        .eq('menu_id', menuId);

      if (error) throw error;
      setAssignedRoles(data?.map(r => r.role_id) || []);
    } catch (error) {
      console.error('Error fetching menu roles:', error);
    }
  };

  const fetchMenuSubRoles = async (menuId: string) => {
    try {
      const { data, error } = await supabase
        .from('sub_role_menu_permissions')
        .select('sub_role')
        .eq('menu_id', menuId);

      if (error) throw error;
      setAssignedSubRoles(data?.map(r => r.sub_role) || []);
    } catch (error) {
      console.error('Error fetching menu sub-roles:', error);
    }
  };

  const handleCreate = async () => {
    try {
      const { error } = await supabase
        .from('menus')
        .insert([{
          name: formData.name,
          path: formData.path,
          icon: formData.icon || null,
          category: formData.category || null,
          display_order: formData.display_order,
          is_active: formData.is_active,
          display_mode: formData.display_mode
        }]);

      if (error) throw error;
      
      toast.success('Menu created successfully');
      setDialogOpen(false);
      resetForm();
      fetchMenus();
    } catch (error) {
      console.error('Error creating menu:', error);
      toast.error('Failed to create menu');
    }
  };

  const handleEdit = async () => {
    if (!editingMenu) return;

    try {
      const { error } = await supabase
        .from('menus')
        .update({
          name: formData.name,
          path: formData.path,
          icon: formData.icon || null,
          category: formData.category || null,
          display_order: formData.display_order,
          is_active: formData.is_active,
          display_mode: formData.display_mode
        })
        .eq('id', editingMenu.id);

      if (error) throw error;
      
      toast.success('Menu updated successfully');
      setDialogOpen(false);
      resetForm();
      fetchMenus();
    } catch (error) {
      console.error('Error updating menu:', error);
      toast.error('Failed to update menu');
    }
  };

  const handleDelete = async () => {
    if (!menuToDelete) return;

    try {
      setDeletingMenu(true);
      // First delete role assignments
      await supabase
        .from('role_menu_permissions')
        .delete()
        .eq('menu_id', menuToDelete.id);

      // Then delete the menu
      const { error } = await supabase
        .from('menus')
        .delete()
        .eq('id', menuToDelete.id);

      if (error) throw error;
      
      toast.success('Menu deleted successfully');
      setDeleteDialogOpen(false);
      setMenuToDelete(null);
      fetchMenus();
    } catch (error) {
      console.error('Error deleting menu:', error);
      toast.error('Failed to delete menu');
    } finally {
      setDeletingMenu(false);
    }
  };

  const handleToggleActive = async (menu: Menu) => {
    try {
      setUpdatingMenu(menu.id);
      const { error } = await supabase
        .from('menus')
        .update({ is_active: !menu.is_active })
        .eq('id', menu.id);

      if (error) throw error;
      
      toast.success(`Menu ${!menu.is_active ? 'activated' : 'deactivated'}`);
      fetchMenus();
    } catch (error) {
      console.error('Error toggling menu status:', error);
      toast.error('Failed to update menu status');
    } finally {
      setUpdatingMenu(null);
    }
  };

  const handleSaveRoleAssignments = async () => {
    if (!selectedMenuForRoles) return;

    try {
      setSavingRoles(true);
      // Delete existing assignments
      await supabase
        .from('role_menu_permissions')
        .delete()
        .eq('menu_id', selectedMenuForRoles.id);

      // Insert new assignments
      if (assignedRoles.length > 0) {
        const { error } = await supabase
          .from('role_menu_permissions')
          .insert(
            assignedRoles.map(roleId => ({
              menu_id: selectedMenuForRoles.id,
              role_id: roleId
            }))
          );

        if (error) throw error;
      }

      toast.success('Role assignments updated successfully');
      setRoleAssignDialogOpen(false);
      setSelectedMenuForRoles(null);
      setAssignedRoles([]);
    } catch (error) {
      console.error('Error saving role assignments:', error);
      toast.error('Failed to update role assignments');
    } finally {
      setSavingRoles(false);
    }
  };

  const handleSaveSubRoleAssignments = async () => {
    if (!selectedMenuForSubRoles) return;

    try {
      setSavingSubRoles(true);
      // Delete existing assignments
      await supabase
        .from('sub_role_menu_permissions')
        .delete()
        .eq('menu_id', selectedMenuForSubRoles.id);

      // Insert new assignments
      if (assignedSubRoles.length > 0) {
        const { error } = await supabase
          .from('sub_role_menu_permissions')
          .insert(
            assignedSubRoles.map(subRole => ({
              menu_id: selectedMenuForSubRoles.id,
              sub_role: subRole
            }))
          );

        if (error) throw error;
      }

      toast.success('Sub-role assignments updated successfully');
      setSubRoleAssignDialogOpen(false);
      setSelectedMenuForSubRoles(null);
      setAssignedSubRoles([]);
    } catch (error) {
      console.error('Error saving sub-role assignments:', error);
      toast.error('Failed to update sub-role assignments');
    } finally {
      setSavingSubRoles(false);
    }
  };

  const openCreateDialog = () => {
    resetForm();
    setEditingMenu(null);
    setDialogOpen(true);
  };

  const openEditDialog = (menu: Menu) => {
    setEditingMenu(menu);
    setFormData({
      name: menu.name,
      path: menu.path,
      icon: menu.icon || '',
      category: menu.category || '',
      display_order: menu.display_order,
      is_active: menu.is_active,
      display_mode: menu.display_mode
    });
    setDialogOpen(true);
  };

  const openRoleAssignDialog = async (menu: Menu) => {
    setSelectedMenuForRoles(menu);
    await fetchMenuRoles(menu.id);
    setRoleAssignDialogOpen(true);
  };

  const openSubRoleAssignDialog = async (menu: Menu) => {
    setSelectedMenuForSubRoles(menu);
    await fetchMenuSubRoles(menu.id);
    setSubRoleAssignDialogOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      path: '',
      icon: '',
      category: '',
      display_order: 0,
      is_active: true,
      display_mode: 'normal'
    });
    setEditingMenu(null);
  };

  const toggleRoleAssignment = (roleId: string) => {
    setAssignedRoles(prev =>
      prev.includes(roleId)
        ? prev.filter(id => id !== roleId)
        : [...prev, roleId]
    );
  };

  const toggleSubRoleAssignment = (subRole: string) => {
    setAssignedSubRoles(prev =>
      prev.includes(subRole)
        ? prev.filter(sr => sr !== subRole)
        : [...prev, subRole]
    );
  };

  const getIcon = (iconName: string | null) => {
    if (!iconName) return null;
    const Icon = (Icons as any)[iconName];
    return Icon ? <Icon className="h-4 w-4" /> : null;
  };

  const filteredMenus = menus.filter(menu =>
    menu.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    menu.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (menu.category && menu.category.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Menu Management</CardTitle>
          <CardDescription>Manage navigation menus, display modes, and role assignments</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="menus" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-6">
              <TabsTrigger value="menus" className="flex items-center gap-2">
                <List className="h-4 w-4" />
                Menu Items
              </TabsTrigger>
              <TabsTrigger value="display" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Display Settings
              </TabsTrigger>
              <TabsTrigger value="roles" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                Role Access
              </TabsTrigger>
              <TabsTrigger value="subroles" className="flex items-center gap-2">
                <UserCog className="h-4 w-4" />
                Sub-Role Access
              </TabsTrigger>
            </TabsList>

            {/* Menu Items Tab */}
            <TabsContent value="menus" className="space-y-4">
              <div className="flex items-center justify-between mb-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search menus..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button onClick={openCreateDialog}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Menu
                </Button>
              </div>
              <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Icon</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Path</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Order</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMenus.map((menu) => (
                <TableRow key={menu.id}>
                  <TableCell>{getIcon(menu.icon)}</TableCell>
                  <TableCell className="font-medium">{menu.name}</TableCell>
                  <TableCell className="text-muted-foreground">{menu.path}</TableCell>
                  <TableCell>
                    {menu.category ? (
                      <Badge variant="outline">{menu.category}</Badge>
                    ) : (
                      <span className="text-muted-foreground">-</span>
                    )}
                  </TableCell>
                  <TableCell>{menu.display_order}</TableCell>
                  <TableCell>
                    <Badge variant={menu.is_active ? 'default' : 'secondary'}>
                      {menu.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <TooltipProvider>
                      <div className="flex items-center gap-2">
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openRoleAssignDialog(menu)}
                              disabled={updatingMenu === menu.id}
                            >
                              <Users className="h-4 w-4 mr-1" />
                              Roles
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Manage role access to this menu</p>
                          </TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(menu)}
                              disabled={updatingMenu === menu.id}
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Edit menu details</p>
                          </TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleToggleActive(menu)}
                              disabled={updatingMenu === menu.id}
                            >
                              {updatingMenu === menu.id ? (
                                <Loader2 className="h-4 w-4 animate-spin" />
                              ) : menu.is_active ? (
                                <EyeOff className="h-4 w-4" />
                              ) : (
                                <Eye className="h-4 w-4" />
                              )}
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>{menu.is_active ? 'Deactivate menu' : 'Activate menu'}</p>
                          </TooltipContent>
                        </Tooltip>

                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setMenuToDelete(menu);
                                setDeleteDialogOpen(true);
                              }}
                              disabled={updatingMenu === menu.id}
                              className="hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Delete menu item</p>
                          </TooltipContent>
                        </Tooltip>
                      </div>
                    </TooltipProvider>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TabsContent>

        {/* Display Settings Tab */}
        <TabsContent value="display" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Display Mode Settings</CardTitle>
              <CardDescription>Configure how menu items are displayed in the sidebar</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Menu Name</TableHead>
                    <TableHead>Current Mode</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMenus.map((menu) => (
                    <TableRow key={menu.id}>
                      <TableCell className="font-medium">{menu.name}</TableCell>
                      <TableCell>
                        <Badge variant={
                          menu.display_mode === 'normal' ? 'default' : 
                          menu.display_mode === 'disabled' ? 'outline' : 
                          'secondary'
                        }>
                          {menu.display_mode === 'normal' ? 'Normal - Fully Active' : 
                           menu.display_mode === 'disabled' ? 'Disabled - With Overlay' : 
                           'Hidden - Not Displayed'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Select
                          value={menu.display_mode}
                          onValueChange={async (value: 'normal' | 'hidden' | 'disabled') => {
                            try {
                              const { error } = await supabase
                                .from('menus')
                                .update({ display_mode: value })
                                .eq('id', menu.id);

                              if (error) throw error;
                              toast.success('Display mode updated');
                              fetchMenus();
                            } catch (error) {
                              console.error('Error updating display mode:', error);
                              toast.error('Failed to update display mode');
                            }
                          }}
                        >
                          <SelectTrigger className="w-[200px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="normal">Normal - Fully Active</SelectItem>
                            <SelectItem value="disabled">Disabled - With Overlay</SelectItem>
                            <SelectItem value="hidden">Hidden - Not Displayed</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Role Access Tab */}
        <TabsContent value="roles" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Role-Based Menu Access</CardTitle>
              <CardDescription>Manage which roles can access each menu item</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Menu Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMenus.map((menu) => (
                    <TableRow key={menu.id}>
                      <TableCell className="font-medium">{menu.name}</TableCell>
                      <TableCell>
                        {menu.category ? (
                          <Badge variant="outline">{menu.category}</Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openRoleAssignDialog(menu)}
                        >
                          <Users className="h-4 w-4 mr-2" />
                          Manage Access
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sub-Role Access Tab */}
        <TabsContent value="subroles" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sub-Role Based Menu Access</CardTitle>
              <CardDescription>Manage which sub-roles can access each menu item</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Menu Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMenus.map((menu) => (
                    <TableRow key={menu.id}>
                      <TableCell className="font-medium">{menu.name}</TableCell>
                      <TableCell>
                        {menu.category ? (
                          <Badge variant="outline">{menu.category}</Badge>
                        ) : (
                          <span className="text-muted-foreground">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => openSubRoleAssignDialog(menu)}
                        >
                          <UserCog className="h-4 w-4 mr-2" />
                          Manage Sub-Role Access
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </CardContent>
  </Card>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{editingMenu ? 'Edit Menu' : 'Create Menu'}</DialogTitle>
            <DialogDescription>
              {editingMenu ? 'Update menu details' : 'Add a new menu item to the system'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Name</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Dashboard"
              />
            </div>
            <div>
              <Label>Path</Label>
              <Input
                value={formData.path}
                onChange={(e) => setFormData({ ...formData, path: e.target.value })}
                placeholder="/dashboard"
              />
            </div>
            <div>
              <Label>Icon</Label>
              <Select value={formData.icon} onValueChange={(value) => setFormData({ ...formData, icon: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select an icon" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {ICON_OPTIONS.map((icon) => {
                    const Icon = (Icons as any)[icon];
                    return (
                      <SelectItem key={icon} value={icon}>
                        <div className="flex items-center gap-2">
                          {Icon && <Icon className="h-4 w-4" />}
                          {icon}
                        </div>
                      </SelectItem>
                    );
                  })}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Category</Label>
              <Input
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                placeholder="Main, Settings, etc."
              />
            </div>
            <div>
              <Label>Display Order</Label>
              <Input
                type="number"
                value={formData.display_order}
                onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) || 0 })}
              />
            </div>
            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="is_active"
                checked={formData.is_active}
                onChange={(e) => setFormData({ ...formData, is_active: e.target.checked })}
                className="h-4 w-4"
              />
              <Label htmlFor="is_active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={editingMenu ? handleEdit : handleCreate}>
              {editingMenu ? 'Update' : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Menu</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{menuToDelete?.name}"? This will also remove all role assignments for this menu.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingMenu}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={deletingMenu}>
              {deletingMenu ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                'Delete'
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Role Assignment Dialog */}
      <Dialog open={roleAssignDialogOpen} onOpenChange={setRoleAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Roles to {selectedMenuForRoles?.name}</DialogTitle>
            <DialogDescription>
              Select which roles can access this menu
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {roles.map((role) => (
              <div key={role.id} className="flex items-center gap-2 p-2 border rounded">
                <input
                  type="checkbox"
                  id={`role-${role.id}`}
                  checked={assignedRoles.includes(role.id)}
                  onChange={() => toggleRoleAssignment(role.id)}
                  className="h-4 w-4"
                />
                <Label htmlFor={`role-${role.id}`} className="flex-1 cursor-pointer">
                  <div className="font-medium">{role.role_key}</div>
                  {role.description && (
                    <div className="text-xs text-muted-foreground">{role.description}</div>
                  )}
                </Label>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setRoleAssignDialogOpen(false)}
              disabled={savingRoles}
            >
              Cancel
            </Button>
            <Button onClick={handleSaveRoleAssignments} disabled={savingRoles}>
              {savingRoles ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Assignments'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Sub-Role Assignment Dialog */}
      <Dialog open={subRoleAssignDialogOpen} onOpenChange={setSubRoleAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Sub-Roles to {selectedMenuForSubRoles?.name}</DialogTitle>
            <DialogDescription>
              Select which sub-roles can access this menu
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-[400px] overflow-y-auto">
            {ALL_SUB_ROLES.map((subRole) => (
              <div key={subRole.value} className="flex items-center gap-2 p-2 border rounded">
                <input
                  type="checkbox"
                  id={`subrole-${subRole.value}`}
                  checked={assignedSubRoles.includes(subRole.value)}
                  onChange={() => toggleSubRoleAssignment(subRole.value)}
                  className="h-4 w-4"
                />
                <Label htmlFor={`subrole-${subRole.value}`} className="flex-1 cursor-pointer">
                  <div className="font-medium">{subRole.label}</div>
                  <div className="text-xs text-muted-foreground">{subRole.value}</div>
                </Label>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setSubRoleAssignDialogOpen(false)}
              disabled={savingSubRoles}
            >
              Cancel
            </Button>
            <Button onClick={handleSaveSubRoleAssignments} disabled={savingSubRoles}>
              {savingSubRoles ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                'Save Assignments'
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MenuManagement;