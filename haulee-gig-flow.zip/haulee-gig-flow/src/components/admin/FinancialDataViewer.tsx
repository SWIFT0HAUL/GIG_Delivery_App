import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Eye, Shield, AlertTriangle } from 'lucide-react';
import { useEncryptedFinancialData } from '@/hooks/useEncryptedFinancialData';

interface FinancialDataViewerProps {
  vendorUserId: string;
  vendorName: string;
}

export function FinancialDataViewer({ vendorUserId, vendorName }: FinancialDataViewerProps) {
  const { loading, error, decryptVendorData } = useEncryptedFinancialData();
  const [data, setData] = useState<any>(null);
  const [showFullData, setShowFullData] = useState(false);

  const handleViewFinancialData = async () => {
    try {
      const decryptedData = await decryptVendorData(vendorUserId, false); // Don't mask for admin
      setData(decryptedData);
      setShowFullData(true);
    } catch (error) {
      console.error('Failed to decrypt financial data:', error);
    }
  };

  const maskCardNumber = (cardNumber?: string) => {
    if (!cardNumber) return 'N/A';
    return `****-****-****-${cardNumber.slice(-4)}`;
  };

  const maskAccountNumber = (accountNumber?: string) => {
    if (!accountNumber) return 'N/A';
    return `****${accountNumber.slice(-4)}`;
  };

  return (
    <Card className="border-orange-200 bg-orange-50/50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-orange-600" />
              Financial Data Access
            </CardTitle>
            <CardDescription>
              Secure access to {vendorName}'s financial information
            </CardDescription>
          </div>
          <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-200">
            Admin Only
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-2 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <AlertTriangle className="h-4 w-4 text-yellow-600 flex-shrink-0" />
          <p className="text-sm text-yellow-800">
            All financial data access is logged for security auditing purposes.
          </p>
        </div>

        {!showFullData ? (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="w-full">
                <Eye className="h-4 w-4 mr-2" />
                View Complete Financial Data
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-red-500" />
                  Access Sensitive Financial Data
                </AlertDialogTitle>
                <AlertDialogDescription>
                  You are about to access sensitive financial information for <strong>{vendorName}</strong>. 
                  This action will be logged for security auditing purposes.
                  <br /><br />
                  Only proceed if you have a legitimate business need to access this information.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleViewFinancialData} disabled={loading}>
                  {loading ? 'Loading...' : 'Access Financial Data'}
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        ) : (
          <div className="space-y-4">
            {error && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-800">{error}</p>
              </div>
            )}
            
            {data ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm text-muted-foreground">Banking Information</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Bank Name:</span>
                      <span className="text-sm">{data.bank_name || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Account Holder:</span>
                      <span className="text-sm">{data.cardholder_name || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Account Number:</span>
                      <span className="text-sm font-mono">{data.account_number || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Routing Number:</span>
                      <span className="text-sm font-mono">{data.routing_number || 'N/A'}</span>
                    </div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="font-semibold text-sm text-muted-foreground">Credit Card Information</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Cardholder Name:</span>
                      <span className="text-sm">{data.cardholder_name || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Card Number:</span>
                      <span className="text-sm font-mono">{data.card_number || 'N/A'}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Expiry Date:</span>
                      <span className="text-sm">{data.card_expiry || 'N/A'}</span>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No financial data available.</p>
            )}
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowFullData(false)}
            >
              Hide Financial Data
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}