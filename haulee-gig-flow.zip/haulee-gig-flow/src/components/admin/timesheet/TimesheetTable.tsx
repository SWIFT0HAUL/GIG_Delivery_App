import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { FileText, Activity, CheckCircle, XCircle, Clock, AlertTriangle, AlertCircle, ShieldCheck, Timer } from 'lucide-react';
import { format } from 'date-fns';
import { TimesheetEntry } from './types';

interface TimesheetTableProps {
  timesheets: TimesheetEntry[];
  isSuperAdmin: boolean;
  viewAllTimesheets: boolean;
  onViewDetails: (entry: TimesheetEntry) => void;
  onApprove?: (entryId: string) => void;
  onReject?: (entryId: string) => void;
}

const getStatusBadge = (status: string) => {
  switch (status) {
    case 'approved':
      return <Badge className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0 shadow-sm"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
    case 'rejected':
      return <Badge className="bg-gradient-to-r from-red-500 to-red-600 text-white border-0 shadow-sm"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
    case 'completed':
      return <Badge className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0 shadow-sm"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
    case 'pending_approval':
      return <Badge variant="outline" className="border-2 border-orange-500 text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950/20"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
    case 'auto_timeout':
      return <Badge variant="secondary" className="bg-amber-100 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900"><AlertTriangle className="h-3 w-3 mr-1" />Timeout</Badge>;
    case 'active':
      return <Badge className="bg-gradient-to-r from-purple-500 to-purple-600 text-white animate-pulse border-0 shadow-sm"><Activity className="h-3 w-3 mr-1 animate-pulse" />Active</Badge>;
    case 'adjusted':
      return <Badge variant="outline" className="border-2 border-indigo-500 text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/20"><FileText className="h-3 w-3 mr-1" />Adjusted</Badge>;
    case 'archived':
      return <Badge variant="secondary" className="bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">Archived</Badge>;
    default:
      return <Badge variant="secondary" className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"><AlertCircle className="h-3 w-3 mr-1" />Pending</Badge>;
  }
};

export function TimesheetTable({
  timesheets,
  isSuperAdmin,
  viewAllTimesheets,
  onViewDetails,
  onApprove,
  onReject
}: TimesheetTableProps) {
  if (timesheets.length === 0) {
    return (
      <div className="text-center py-16 animate-fade-in">
        <div className="inline-flex p-4 rounded-full bg-muted/50 mb-4">
          <Clock className="h-8 w-8 text-muted-foreground" />
        </div>
        <p className="text-lg font-medium text-muted-foreground mb-1">No timesheet entries yet</p>
        <p className="text-sm text-muted-foreground/70">Clock in to start tracking your work hours</p>
      </div>
    );
  }

  return (
    <div className="rounded-xl border-2 border-border overflow-hidden shadow-sm bg-card">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/30 hover:bg-muted/30 border-b-2">
            <TableHead className="font-semibold text-foreground">Date</TableHead>
            <TableHead className="font-semibold text-foreground">Clock In</TableHead>
            <TableHead className="font-semibold text-foreground">Clock Out</TableHead>
            <TableHead className="font-semibold text-foreground">Duration</TableHead>
            <TableHead className="font-semibold text-foreground">Type</TableHead>
            <TableHead className="font-semibold text-foreground">Status</TableHead>
            <TableHead className="font-semibold text-foreground">Activities</TableHead>
            <TableHead className="font-semibold text-foreground">Notes</TableHead>
            <TableHead className="font-semibold text-foreground">Details</TableHead>
            {isSuperAdmin && viewAllTimesheets && <TableHead className="font-semibold text-foreground">Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {timesheets.map((entry, index) => (
            <TableRow 
              key={entry.id} 
              className="animate-fade-in hover:bg-muted/30 transition-all duration-200 border-b border-border/50 group"
              style={{ animationDelay: `${index * 50}ms` }}
            >
              <TableCell>
                <div className="font-semibold text-foreground">{format(new Date(entry.date), 'MMM dd, yyyy')}</div>
                <div className="text-xs text-muted-foreground font-medium">{format(new Date(entry.date), 'EEEE')}</div>
              </TableCell>
              <TableCell>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-300 font-mono font-medium">
                  <Clock className="h-3 w-3" />
                  {format(new Date(entry.clock_in), 'HH:mm')}
                </div>
              </TableCell>
              <TableCell>
                {entry.clock_out ? (
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-purple-50 dark:bg-purple-950/20 text-purple-700 dark:text-purple-300 font-mono font-medium">
                    <Clock className="h-3 w-3" />
                    {format(new Date(entry.clock_out), 'HH:mm')}
                  </div>
                ) : (
                  <Badge variant="outline" className="animate-pulse border-2 border-green-500 text-green-600 bg-green-50 dark:bg-green-950/20">
                    <Activity className="h-3 w-3 mr-1 animate-pulse" />
                    Active
                  </Badge>
                )}
              </TableCell>
              <TableCell>
                {entry.total_duration ? (
                  <div className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md font-semibold ${
                    entry.total_duration > 8 
                      ? 'bg-orange-50 dark:bg-orange-950/20 text-orange-700 dark:text-orange-300' 
                      : 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-700 dark:text-emerald-300'
                  }`}>
                    <Timer className="h-3 w-3" />
                    {entry.total_duration.toFixed(2)}h
                  </div>
                ) : (
                  <span className="text-muted-foreground">-</span>
                )}
              </TableCell>
              <TableCell>
                <div className="flex items-center gap-2">
                  {entry.manual_entry ? (
                    <Badge variant="secondary" className="bg-amber-100 dark:bg-amber-950/20 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-900">
                      <FileText className="h-3 w-3 mr-1" />
                      Manual
                    </Badge>
                  ) : (
                    <Badge variant="outline" className="border-2 border-blue-200 dark:border-blue-900 text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/20">
                      <Activity className="h-3 w-3 mr-1" />
                      Auto
                    </Badge>
                  )}
                  {entry.manual_entry && entry.approved_by && (
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger>
                          <div className="p-1 rounded-md bg-green-100 dark:bg-green-950/20">
                            <ShieldCheck className="h-4 w-4 text-green-600 dark:text-green-400" />
                          </div>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p className="font-medium">Super Admin Approved</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                  )}
                </div>
              </TableCell>
              <TableCell>{getStatusBadge(entry.status)}</TableCell>
              <TableCell>
                <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-muted/50 text-foreground font-medium">
                  <Activity className="h-3.5 w-3.5 text-primary" />
                  <span className="text-sm">{entry.activity_count || 0}</span>
                </div>
              </TableCell>
              <TableCell className="max-w-xs">
                <div className="truncate text-sm text-muted-foreground">
                  {entry.manual_entry_reason || entry.adjustment_reason || entry.notes || (
                    <span className="italic opacity-50">No notes</span>
                  )}
                </div>
              </TableCell>
              <TableCell>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => onViewDetails(entry)}
                  className="hover:scale-105 transition-transform duration-200 hover:border-primary hover:text-primary group-hover:shadow-md"
                >
                  <FileText className="h-3 w-3 mr-1.5" />
                  View
                </Button>
              </TableCell>
              {isSuperAdmin && viewAllTimesheets && (
                <TableCell>
                  <div className="flex gap-1.5">
                    {entry.status === 'pending' || entry.status === 'pending_approval' ? (
                      <>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onApprove?.(entry.id)}
                          className="text-green-600 hover:text-green-700 hover:bg-green-50 dark:hover:bg-green-950/20 hover:scale-110 transition-transform"
                        >
                          <CheckCircle className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onReject?.(entry.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/20 hover:scale-110 transition-transform"
                        >
                          <XCircle className="h-4 w-4" />
                        </Button>
                      </>
                    ) : null}
                  </div>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
