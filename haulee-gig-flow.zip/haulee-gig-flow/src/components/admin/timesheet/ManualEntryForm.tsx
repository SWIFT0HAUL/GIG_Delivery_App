import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ShieldAlert } from 'lucide-react';

interface ManualEntryFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: {
    clockIn: string;
    clockOut: string;
    reason: string;
    notes: string;
  }) => Promise<void>;
}

export function ManualEntryForm({ open, onOpenChange, onSubmit }: ManualEntryFormProps) {
  const [manualClockIn, setManualClockIn] = useState('');
  const [manualClockOut, setManualClockOut] = useState('');
  const [manualReason, setManualReason] = useState('');
  const [manualNotes, setManualNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!manualClockIn || !manualClockOut || !manualReason) {
      return;
    }

    // Client-side validation
    const clockInDate = new Date(manualClockIn);
    const clockOutDate = new Date(manualClockOut);
    const now = new Date();
    
    if (clockInDate > now || clockOutDate > now) {
      alert("Cannot create timesheet entries with future timestamps");
      return;
    }
    
    if (clockInDate >= clockOutDate) {
      alert("Clock out time must be after clock in time");
      return;
    }

    setIsSubmitting(true);
    try {
      await onSubmit({
        clockIn: manualClockIn,
        clockOut: manualClockOut,
        reason: manualReason,
        notes: manualNotes
      });
      
      // Reset form
      setManualClockIn('');
      setManualClockOut('');
      setManualReason('');
      setManualNotes('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="animate-scale-in">
        <DialogHeader>
          <DialogTitle>Manual Time Entry</DialogTitle>
          <DialogDescription>
            Create a manual timesheet entry for missed or adjusted time. This will require approval.
          </DialogDescription>
        </DialogHeader>

        <Alert>
          <ShieldAlert className="h-4 w-4" />
          <AlertDescription>
            <strong>Security Notice:</strong> Manual timesheet entries require Super Admin approval.
            Entries cannot have future timestamps or overlap with existing sessions.
          </AlertDescription>
        </Alert>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="manual-clock-in">Clock In *</Label>
            <Input
              id="manual-clock-in"
              type="datetime-local"
              value={manualClockIn}
              onChange={(e) => setManualClockIn(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="manual-clock-out">Clock Out *</Label>
            <Input
              id="manual-clock-out"
              type="datetime-local"
              value={manualClockOut}
              onChange={(e) => setManualClockOut(e.target.value)}
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="manual-reason">Reason *</Label>
            <Textarea
              id="manual-reason"
              placeholder="Why is this manual entry needed? (e.g., Forgot to clock in, System error)"
              value={manualReason}
              onChange={(e) => setManualReason(e.target.value)}
              required
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="manual-notes">Additional Notes (Optional)</Label>
            <Textarea
              id="manual-notes"
              placeholder="Any additional information..."
              value={manualNotes}
              onChange={(e) => setManualNotes(e.target.value)}
              rows={2}
            />
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!manualClockIn || !manualClockOut || !manualReason || isSubmitting}
          >
            {isSubmitting ? 'Submitting...' : 'Submit for Approval'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
