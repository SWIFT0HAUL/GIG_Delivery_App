import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Clock, LogOut, FileText, Timer, Activity } from 'lucide-react';
import { format } from 'date-fns';
import { TimesheetEntry, Task } from './types';

interface ClockInOutCardProps {
  currentSession: TimesheetEntry | null;
  elapsedTime: number;
  availableTasks: Task[];
  onClockIn: (taskId?: string) => void;
  onClockOut: () => void;
  onManualEntry: () => void;
  formatDuration: (seconds: number) => string;
}

export function ClockInOutCard({
  currentSession,
  elapsedTime,
  availableTasks,
  onClockIn,
  onClockOut,
  onManualEntry,
  formatDuration
}: ClockInOutCardProps) {
  const [selectedTaskId, setSelectedTaskId] = useState<string>('');

  const handleClockIn = () => {
    const taskId = !selectedTaskId || selectedTaskId === 'none' ? undefined : selectedTaskId;
    onClockIn(taskId);
    setSelectedTaskId('');
  };

  return (
    <Card className="animate-fade-in bg-gradient-to-br from-background to-muted/20 border-2 shadow-lg hover:shadow-xl transition-all duration-300">
      <CardHeader className="relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full blur-3xl"></div>
        <CardTitle className="flex items-center gap-3 text-2xl relative z-10">
          <div className="p-3 rounded-xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground shadow-lg">
            <Timer className="h-6 w-6" />
          </div>
          <span className="bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
            Time Tracking
          </span>
        </CardTitle>
        <CardDescription className="text-base mt-2">
          {currentSession && !currentSession.clock_out ? 
            'Session in progress - tracking your work time' : 
            'Start tracking your work hours' + (availableTasks.length > 0 ? ' with optional task tracking' : '')
          }
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Task Selection - Only show when no active session */}
        {!currentSession && availableTasks.length > 0 && (
          <div className="space-y-3 animate-scale-in p-4 rounded-lg bg-muted/30 border border-border/50">
            <Label htmlFor="task-select" className="text-sm font-semibold flex items-center gap-2">
              <FileText className="h-4 w-4 text-primary" />
              Select Task (Optional)
            </Label>
            <Select value={selectedTaskId} onValueChange={setSelectedTaskId}>
              <SelectTrigger id="task-select" className="h-11 bg-background">
                <SelectValue placeholder="No task selected" />
              </SelectTrigger>
              <SelectContent className="z-50 bg-background">
                <SelectItem value="none">No task</SelectItem>
                {availableTasks.map((task) => (
                  <SelectItem key={task.id} value={task.id}>
                    {task.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
        
        <div className="flex flex-col gap-6">
          {currentSession && !currentSession.clock_out ? (
            <div className="p-6 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-2 border-primary/20 animate-fade-in">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                  <Activity className="h-4 w-4 animate-pulse text-primary" />
                  Active Session
                </span>
                <Badge className="bg-green-500/20 text-green-700 dark:text-green-300 border-green-500/30 animate-pulse">
                  <span className="relative flex h-2 w-2 mr-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-green-500"></span>
                  </span>
                  LIVE
                </Badge>
              </div>
              <div className="text-5xl font-bold font-mono bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent mb-3">
                {formatDuration(elapsedTime)}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                Started: {format(new Date(currentSession.clock_in), 'MMM dd, yyyy • HH:mm')}
              </div>
            </div>
          ) : (
            <div className="p-6 rounded-2xl border-2 border-dashed border-border/50 text-center">
              <Clock className="h-12 w-12 mx-auto mb-3 text-muted-foreground/40" />
              <p className="text-muted-foreground">No active session</p>
              <p className="text-sm text-muted-foreground/70 mt-1">Click 'Clock In' to start tracking time</p>
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3">
            {currentSession && !currentSession.clock_out ? (
              <Button 
                onClick={onClockOut} 
                variant="destructive" 
                size="lg" 
                className="flex-1 h-14 text-lg font-semibold shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Clock Out
              </Button>
            ) : (
              <Button 
                onClick={handleClockIn} 
                size="lg" 
                className="flex-1 h-14 text-lg font-semibold bg-gradient-to-r from-primary to-primary/90 hover:from-primary/90 hover:to-primary shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
              >
                <Clock className="h-5 w-5 mr-2" />
                Clock In
              </Button>
            )}
            <Button 
              onClick={onManualEntry} 
              variant="outline" 
              size="lg" 
              className="h-14 text-base font-semibold border-2 hover:bg-muted/50 transition-all duration-300 hover:scale-105 hover:border-primary/50"
            >
              <FileText className="h-5 w-5 mr-2" />
              Manual Entry
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
