export interface TimesheetEntry {
  id: string;
  admin_id: string;
  user_id?: string;
  role_key?: string;
  date: string;
  clock_in: string;
  clock_out: string | null;
  total_duration: number | null;
  activity_count: number;
  status: string;
  notes: string | null;
  manual_entry: boolean;
  manual_entry_reason: string | null;
  approved_by: string | null;
  approved_at: string | null;
  last_activity: string | null;
  rejection_reason: string | null;
  adjustment_reason: string | null;
  is_archived: boolean;
  payroll_exported?: boolean;
  payroll_export_date?: string | null;
  payroll_period_start?: string | null;
  payroll_period_end?: string | null;
  job_id?: string | null;
  job_stage?: string | null;
  mileage?: number | null;
  wait_time_minutes?: number;
  break_time_minutes?: number;
}

export interface Task {
  id: string;
  name: string;
  description: string | null;
}

export interface ActivityLog {
  id: string;
  timesheet_id: string;
  activity_type: string;
  activity_description: string | null;
  metadata: any;
  created_at: string;
  task_id?: string | null;
  task_assignment_id?: string | null;
}

export interface JobStage {
  id: string;
  timesheet_id: string;
  job_id: string;
  stage: string;
  started_at: string;
  completed_at: string | null;
  duration_hours: number | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface PayrollExport {
  id: string;
  export_date: string;
  period_start: string;
  period_end: string;
  status: string;
  exported_by: string | null;
  timesheet_ids: string[];
  total_records: number;
  total_hours: number;
  export_file_path: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export type JobStageType = 
  | 'claim' 
  | 'assigned' 
  | 'start' 
  | 'pickup' 
  | 'in_progress' 
  | 'delivered' 
  | 'completed';

export type TimesheetRole = 
  | 'driver' 
  | 'carrier' 
  | 'shipper' 
  | 'vendor' 
  | 'broker' 
  | 'admin' 
  | 'super_admin';