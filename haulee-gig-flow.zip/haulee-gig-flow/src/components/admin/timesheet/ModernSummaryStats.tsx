import { Card, CardContent } from '@/components/ui/card';
import { Clock, TrendingUp, CheckCircle, AlertCircle, Timer, Activity } from 'lucide-react';

interface ModernSummaryStatsProps {
  stats: {
    totalHours: number;
    thisWeek: number;
    pending: number;
    approved: number;
    overtime: number;
  };
}

export function ModernSummaryStats({ stats }: ModernSummaryStatsProps) {
  const statCards = [
    {
      title: 'Total Hours',
      value: `${stats.totalHours.toFixed(1)}h`,
      icon: Clock,
      gradient: 'from-blue-500 to-cyan-500',
      bgGradient: 'from-blue-50 to-cyan-50 dark:from-blue-950/20 dark:to-cyan-950/20',
      iconBg: 'bg-gradient-to-br from-blue-500 to-cyan-500',
      change: null
    },
    {
      title: 'This Week',
      value: `${stats.thisWeek.toFixed(1)}h`,
      icon: TrendingUp,
      gradient: 'from-emerald-500 to-green-500',
      bgGradient: 'from-emerald-50 to-green-50 dark:from-emerald-950/20 dark:to-green-950/20',
      iconBg: 'bg-gradient-to-br from-emerald-500 to-green-500',
      change: stats.thisWeek > 40 ? '+' + (stats.thisWeek - 40).toFixed(1) + 'h' : null
    },
    {
      title: 'Overtime',
      value: `${stats.overtime.toFixed(1)}h`,
      icon: Timer,
      gradient: 'from-orange-500 to-amber-500',
      bgGradient: 'from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20',
      iconBg: 'bg-gradient-to-br from-orange-500 to-amber-500',
      alert: stats.overtime > 5
    },
    {
      title: 'Approved',
      value: stats.approved.toString(),
      icon: CheckCircle,
      gradient: 'from-green-500 to-emerald-500',
      bgGradient: 'from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20',
      iconBg: 'bg-gradient-to-br from-green-500 to-emerald-500',
      subtitle: 'entries'
    },
    {
      title: 'Pending',
      value: stats.pending.toString(),
      icon: AlertCircle,
      gradient: 'from-purple-500 to-pink-500',
      bgGradient: 'from-purple-50 to-pink-50 dark:from-purple-950/20 dark:to-pink-950/20',
      iconBg: 'bg-gradient-to-br from-purple-500 to-pink-500',
      alert: stats.pending > 0,
      subtitle: 'awaiting approval'
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
      {statCards.map((stat, index) => (
        <Card 
          key={stat.title}
          className={`animate-fade-in hover:shadow-lg transition-all duration-300 border-2 hover:scale-105 hover:-translate-y-1 bg-gradient-to-br ${stat.bgGradient} relative overflow-hidden group`}
          style={{ animationDelay: `${index * 100}ms` }}
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br opacity-10 rounded-full blur-2xl group-hover:opacity-20 transition-opacity" 
               style={{ background: `linear-gradient(135deg, currentColor, transparent)` }}></div>
          
          <CardContent className="p-6 relative z-10">
            <div className="flex items-start justify-between mb-4">
              <div className={`p-3 rounded-xl ${stat.iconBg} text-white shadow-lg transform group-hover:scale-110 group-hover:rotate-3 transition-all duration-300`}>
                <stat.icon className="h-6 w-6" />
              </div>
              {stat.alert && (
                <div className="animate-pulse">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                  </span>
                </div>
              )}
            </div>
            
            <div className="space-y-1">
              <p className="text-sm font-medium text-muted-foreground">{stat.title}</p>
              <div className="flex items-baseline gap-2">
                <p className={`text-3xl font-bold bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`}>
                  {stat.value}
                </p>
                {stat.change && (
                  <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 bg-emerald-100 dark:bg-emerald-950/30 px-2 py-0.5 rounded-full">
                    {stat.change}
                  </span>
                )}
              </div>
              {stat.subtitle && (
                <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}