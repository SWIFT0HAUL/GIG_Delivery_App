import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Activity } from 'lucide-react';
import { format, startOfWeek, addDays } from 'date-fns';
import { TimesheetEntry } from './types';

interface AdminActivityChartProps {
  timesheets: TimesheetEntry[];
}

export function AdminActivityChart({ timesheets }: AdminActivityChartProps) {
  // Generate chart data for the last 7 days
  const generateChartData = () => {
    const weekStart = startOfWeek(new Date());
    const data = [];

    for (let i = 0; i < 7; i++) {
      const day = addDays(weekStart, i);
      const dayStr = format(day, 'yyyy-MM-dd');
      const dayName = format(day, 'EEE');
      
      const dayEntries = timesheets.filter(entry => {
        const entryDate = format(new Date(entry.clock_in), 'yyyy-MM-dd');
        return entryDate === dayStr;
      });

      const totalHours = dayEntries.reduce((sum, entry) => sum + (entry.total_duration || 0), 0);
      const totalActivities = dayEntries.reduce((sum, entry) => sum + (entry.activity_count || 0), 0);

      data.push({
        day: dayName,
        hours: parseFloat(totalHours.toFixed(2)),
        activities: totalActivities,
        entries: dayEntries.length
      });
    }

    return data;
  };

  const chartData = generateChartData();

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Weekly Activity Overview
        </CardTitle>
        <CardDescription>
          Hours worked and activities tracked over the past week
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis 
              dataKey="day" 
              tick={{ fill: 'hsl(var(--muted-foreground))' }}
            />
            <YAxis 
              tick={{ fill: 'hsl(var(--muted-foreground))' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: 'hsl(var(--card))',
                border: '1px solid hsl(var(--border))',
                borderRadius: '6px'
              }}
            />
            <Legend />
            <Bar 
              dataKey="hours" 
              fill="hsl(var(--primary))" 
              name="Hours Worked"
              radius={[4, 4, 0, 0]}
            />
            <Bar 
              dataKey="activities" 
              fill="hsl(var(--accent))" 
              name="Activities"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
