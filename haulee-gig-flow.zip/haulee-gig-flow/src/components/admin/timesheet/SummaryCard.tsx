import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LucideIcon } from 'lucide-react';

interface SummaryCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon?: LucideIcon;
  trend?: 'up' | 'down' | 'neutral';
  variant?: 'default' | 'warning' | 'success' | 'info';
}

export function SummaryCard({
  title,
  value,
  subtitle,
  icon: Icon,
  trend,
  variant = 'default'
}: SummaryCardProps) {
  const getVariantStyles = () => {
    switch (variant) {
      case 'warning':
        return 'border-orange-500/20 bg-orange-50/50 dark:bg-orange-950/20';
      case 'success':
        return 'border-green-500/20 bg-green-50/50 dark:bg-green-950/20';
      case 'info':
        return 'border-blue-500/20 bg-blue-50/50 dark:bg-blue-950/20';
      default:
        return '';
    }
  };

  const getValueColor = () => {
    switch (variant) {
      case 'warning':
        return 'text-orange-500';
      case 'success':
        return 'text-green-500';
      case 'info':
        return 'text-blue-500';
      default:
        return '';
    }
  };

  return (
    <Card className={`animate-fade-in hover-scale transition-all ${getVariantStyles()}`}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
          <span>{title}</span>
          {Icon && <Icon className="h-4 w-4 opacity-50" />}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className={`text-2xl font-bold ${getValueColor()}`}>{value}</div>
        {subtitle && (
          <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
            {trend && (
              <span className={trend === 'up' ? 'text-green-500' : trend === 'down' ? 'text-red-500' : ''}>
                {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}
              </span>
            )}
            {subtitle}
          </p>
        )}
      </CardContent>
    </Card>
  );
}
