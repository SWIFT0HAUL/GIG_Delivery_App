import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Edit2, Trash2, CheckCircle, XCircle, Clock, AlertCircle, Users, Filter, Link as LinkIcon, Calendar, ThumbsUp, ThumbsDown, Undo2, Pencil, ArrowRight, Eye, UserPlus, UserMinus } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { format } from 'date-fns';
import { DefaultTaskTemplates } from './DefaultTaskTemplates';

interface CustomTask {
  id: string;
  name: string;
  description: string;
  category: string;
  required: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  custom_link?: string;
  priority?: string;
  due_date?: string;
  assigned_roles?: string[];
  redirect_path?: any[];
}

interface TaskAssignment {
  id: string;
  task_id: string;
  user_id: string;
  status: string;
  created_at: string;
  completed_at?: string;
  updated_at?: string;
  notes?: string;
  approval_status?: string;
  approved_by?: string;
  approved_at?: string;
  rejection_reason?: string;
  task?: CustomTask;
  profiles?: {
    full_name: string;
    email: string;
    role_key: string;
  };
}

interface User {
  id: string;
  full_name: string;
  email: string;
  role_key: string;
  account_number?: string;
  is_approved?: boolean;
}

export function TasksManagement() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [tasks, setTasks] = useState<CustomTask[]>([]);
  const [assignments, setAssignments] = useState<TaskAssignment[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [rejectDialogOpen, setRejectDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<CustomTask | null>(null);
  const [selectedTaskForAssign, setSelectedTaskForAssign] = useState<string | null>(null);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [createSelectedUsers, setCreateSelectedUsers] = useState<string[]>([]);
  const [filterRole, setFilterRole] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterApproval, setFilterApproval] = useState<string>('all');
  const [userSearch, setUserSearch] = useState('');
  const [rejectingAssignment, setRejectingAssignment] = useState<string | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [createUserSearch, setCreateUserSearch] = useState('');
  const [bulkSelectRole, setBulkSelectRole] = useState<string>('');
  const [showPredefinedModal, setShowPredefinedModal] = useState(false);
  const [editingPredefined, setEditingPredefined] = useState<any>(null);
  const [createTaskName, setCreateTaskName] = useState('');
  const [createTaskCategory, setCreateTaskCategory] = useState('');
  const [createSelectedRoles, setCreateSelectedRoles] = useState<string[]>([]);
  const [unassignDialogOpen, setUnassignDialogOpen] = useState(false);
  const [selectedTaskForUnassign, setSelectedTaskForUnassign] = useState<string | null>(null);
  const [viewFormDialogOpen, setViewFormDialogOpen] = useState(false);
  const [viewingTask, setViewingTask] = useState<CustomTask | null>(null);
  
  // Bulk selection states
  const [selectedTasks, setSelectedTasks] = useState<string[]>([]);
  const [selectedPredefined, setSelectedPredefined] = useState<string[]>([]);
  const [selectedCustom, setSelectedCustom] = useState<string[]>([]);
  const [bulkTemplateDialogOpen, setBulkTemplateDialogOpen] = useState(false);
  const [bulkTemplateRoles, setBulkTemplateRoles] = useState<string[]>([]);
  const [bulkCustomTemplateDialogOpen, setBulkCustomTemplateDialogOpen] = useState(false);
  const [bulkCustomTemplateRoles, setBulkCustomTemplateRoles] = useState<string[]>([]);
  const [selectedAssignments, setSelectedAssignments] = useState<string[]>([]);
  const [bulkCreateDialogOpen, setBulkCreateDialogOpen] = useState(false);
  const [tasksToCreate, setTasksToCreate] = useState<string[]>([]);
  const [bulkAssignDialogOpen, setBulkAssignDialogOpen] = useState(false);
  const [bulkUnassignDialogOpen, setBulkUnassignDialogOpen] = useState(false);
  const [bulkAssignUsers, setBulkAssignUsers] = useState<string[]>([]);
  const [bulkAssignSearch, setBulkAssignSearch] = useState('');
  
  // Predefined tasks state - matches database exactly (no apostrophes)
  const [predefinedTasks, setPredefinedTasks] = useState([
    { id: 'p1', category: 'UNIVERSAL TASKS', name: 'Complete Profile Information', assignedRoles: ['driver', 'shipper', 'carrier', 'vendor_merchant', 'broker'] },
    { id: 'p2', category: 'UNIVERSAL TASKS', name: 'Verify Email', assignedRoles: ['driver', 'shipper', 'carrier', 'vendor', 'broker'] },
    { id: 'p3', category: 'UNIVERSAL TASKS', name: 'Upload ID Document', assignedRoles: ['driver', 'shipper', 'carrier', 'vendor', 'broker'] },
    { id: 'p4', category: 'UNIVERSAL TASKS', name: 'Accept Terms & Conditions', assignedRoles: ['driver', 'shipper', 'carrier', 'vendor', 'broker'] },
    { id: 'p5', category: 'UNIVERSAL TASKS', name: 'Setup MFA', assignedRoles: ['driver', 'shipper', 'carrier', 'vendor', 'broker'] },
    { id: 'p6', category: 'DRIVER TASKS', name: 'Upload Drivers License', assignedRoles: ['driver'] },
    { id: 'p7', category: 'DRIVER TASKS', name: 'Upload Vehicle Registration', assignedRoles: ['driver'] },
    { id: 'p8', category: 'DRIVER TASKS', name: 'Upload Insurance Proof', assignedRoles: ['driver'] },
    { id: 'p9', category: 'DRIVER TASKS', name: 'Complete Background Check', assignedRoles: ['driver'] },
    { id: 'p10', category: 'DRIVER TASKS', name: 'Submit W9 Form', assignedRoles: ['driver'] },
    { id: 'p11', category: 'DRIVER TASKS', name: 'Watch Safety Training Video', assignedRoles: ['driver'] },
    { id: 'p12', category: 'DRIVER TASKS', name: 'Schedule Vehicle Inspection', assignedRoles: ['driver'] },
    { id: 'p13', category: 'SHIPPER TASKS', name: 'Add Business Information', assignedRoles: ['shipper'] },
    { id: 'p14', category: 'SHIPPER TASKS', name: 'Upload Business License', assignedRoles: ['shipper'] },
    { id: 'p15', category: 'SHIPPER TASKS', name: 'Add Payment Method', assignedRoles: ['shipper'] },
    { id: 'p16', category: 'SHIPPER TASKS', name: 'Review Shipment Policies', assignedRoles: ['shipper'] },
    { id: 'p17', category: 'SHIPPER TASKS', name: 'Verify Tax Information', assignedRoles: ['shipper'] },
    { id: 'p18', category: 'CARRIER TASKS', name: 'Upload Operating Authority (MC/DOT)', assignedRoles: ['carrier'] },
    { id: 'p19', category: 'CARRIER TASKS', name: 'Upload Insurance Certificate', assignedRoles: ['carrier'] },
    { id: 'p20', category: 'CARRIER TASKS', name: 'Add Drivers', assignedRoles: ['carrier'] },
    { id: 'p21', category: 'CARRIER TASKS', name: 'Upload Vehicle List', assignedRoles: ['carrier'] },
    { id: 'p22', category: 'CARRIER TASKS', name: 'Complete Safety Compliance', assignedRoles: ['carrier'] },
    { id: 'p23', category: 'VENDOR/MERCHANT TASKS', name: 'Upload Business License', assignedRoles: ['vendor_merchant'] },
    { id: 'p24', category: 'VENDOR TASKS', name: 'Add Product Catalog', assignedRoles: ['vendor'] },
    { id: 'p25', category: 'VENDOR TASKS', name: 'Upload W9 / Tax Document', assignedRoles: ['vendor'] },
    { id: 'p26', category: 'VENDOR TASKS', name: 'Setup Payment Receiving Method', assignedRoles: ['vendor'] },
    { id: 'p27', category: 'VENDOR TASKS', name: 'Review Vendor Policies', assignedRoles: ['vendor'] },
    { id: 'p28', category: 'ADMIN (LIMITED) TASKS', name: 'Complete Admin Profile', assignedRoles: ['admin'] },
    { id: 'p29', category: 'ADMIN (LIMITED) TASKS', name: 'Review Platform Guidelines', assignedRoles: ['admin'] },
    { id: 'p30', category: 'ADMIN (LIMITED) TASKS', name: 'Enable MFA', assignedRoles: ['admin'] },
    { id: 'p31', category: 'ADMIN (SUPER) TASKS', name: 'System Access Validation', assignedRoles: ['super_admin'] },
    { id: 'p32', category: 'ADMIN (SUPER) TASKS', name: 'Security Audit Review', assignedRoles: ['super_admin'] },
    { id: 'p33', category: 'ADMIN (SUPER) TASKS', name: 'Create Role Access Table', assignedRoles: ['super_admin'] },
    { id: 'p34', category: 'ADMIN (SUPER) TASKS', name: 'Setup Admin Buckets', assignedRoles: ['super_admin'] },
    { id: 'p35', category: 'ADMIN (SUPER) TASKS', name: 'Activate Safeguard Protocols', assignedRoles: ['super_admin'] },
  ]);
  
  const [taskData, setTaskData] = useState({
    name: '',
    description: '',
    category: 'general',
    required: false,
    custom_link: '',
    priority: 'medium',
    due_date: '',
    assigned_roles: [] as string[],
    redirect_path: [] as any[]
  });

  const [currentStep, setCurrentStep] = useState({
    step_number: 1,
    step_name: '',
    step_description: '',
    path: '',
    is_optional: false
  });

  const handleAddStep = () => {
    if (!currentStep.step_name.trim() || !currentStep.path.trim()) {
      toast({ title: 'Error', description: 'Step name and path are required', variant: 'destructive' });
      return;
    }
    const next = ([...(taskData.redirect_path || [])] as any[]).concat(currentStep);
    setTaskData(prev => ({ ...prev, redirect_path: next }));
    setCurrentStep({ step_number: next.length + 1, step_name: '', step_description: '', path: '', is_optional: false });
  };

  const handleRemoveStep = (stepNumber: number) => {
    const updated = ((taskData.redirect_path || []) as any[])
      .filter((s: any) => s.step_number !== stepNumber)
      .map((s: any, idx: number) => ({ ...s, step_number: idx + 1 }));
    setTaskData(prev => ({ ...prev, redirect_path: updated }));
    setCurrentStep(prev => ({ ...prev, step_number: updated.length + 1 }));
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch tasks
      const { data: tasksData, error: tasksError } = await supabase
        .from('custom_tasks')
        .select('*')
        .order('created_at', { ascending: false });

      if (tasksError) throw tasksError;
      
      // Remove duplicates by ID (keep first occurrence)
      const uniqueTasks = tasksData ? 
        Array.from(new Map(tasksData.map(task => [task.id, task])).values()) : [];
      
      setTasks(uniqueTasks as any);

      // Fetch assignments with user profiles
      const { data: assignmentsData, error: assignmentsError } = await supabase
        .from('task_assignments')
        .select(`
          *,
          task:custom_tasks(*)
        `)
        .order('created_at', { ascending: false });

      if (assignmentsError) throw assignmentsError;
      
      // Fetch user profiles separately and merge
      if (assignmentsData) {
        const userIds = [...new Set(assignmentsData.map(a => a.user_id))];
        const { data: profilesData } = await supabase
          .from('profiles')
          .select('id, full_name, email, role_key')
          .in('id', userIds);
        
        const profilesMap = new Map(profilesData?.map(p => [p.id, p]));
        const enrichedAssignments = assignmentsData.map(a => ({
          ...a,
          profiles: profilesMap.get(a.user_id) || { full_name: 'Unknown User', email: 'N/A', role_key: 'unknown' }
        }));
        setAssignments(enrichedAssignments as any);
      } else {
        setAssignments([]);
      }

      // Fetch all users for assignment (including not approved)
      const { data: usersData, error: usersError } = await supabase
        .from('profiles')
        .select('id, full_name, email, role_key, is_approved')
        .order('full_name');

      if (usersError) throw usersError;

      // Fetch user account numbers
      const { data: accounts, error: accountsError } = await supabase
        .from('user_account_number')
        .select('user_id, account_number');

      if (accountsError) throw accountsError;

      const accountMap = new Map<string, string>(
        (accounts || []).map((a: any) => [a.user_id, a.account_number])
      );

      const combinedUsers = (usersData || []).map(u => ({
        ...u,
        account_number: accountMap.get(u.id)
      }));

      setUsers(combinedUsers || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch tasks data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async () => {
    if (!taskData.name.trim()) {
      toast({
        title: "Error",
        description: "Task name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      // Create the task
      const payload = {
        name: taskData.name,
        description: taskData.description,
        category: taskData.category,
        required: taskData.required,
        custom_link: taskData.custom_link,
        priority: taskData.priority,
        due_date: taskData.due_date || null,
        assigned_roles: taskData.assigned_roles,
        redirect_path: (taskData.redirect_path as any),
        created_by: user?.id,
      } as any;

      const { data: newTask, error: taskError } = await supabase
        .from('custom_tasks')
        .insert(payload)
        .select()
        .single();

      if (taskError) throw taskError;

      // If users are selected, create assignments
      if (createSelectedUsers.length > 0 && newTask) {
        const assignments = createSelectedUsers.map(userId => ({
          task_id: newTask.id,
          user_id: userId,
          assigned_by: user?.id,
          status: 'pending',
          approval_status: 'pending_approval'
        }));

        const { error: assignError } = await supabase
          .from('task_assignments')
          .insert(assignments);

        if (assignError) throw assignError;
      }

      resetForm();
      setCreateDialogOpen(false);
      setCreateSelectedUsers([]);
      setCreateUserSearch('');
      setBulkSelectRole('');
      fetchData();
      
      toast({
        title: "Success",
        description: createSelectedUsers.length > 0 
          ? `Task created and assigned to ${createSelectedUsers.length} user(s)`
          : "Task created successfully"
      });
    } catch (error) {
      console.error('Error creating task:', error);
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive"
      });
    }
  };

  const handleUpdateTask = async () => {
    if (!editingTask || !taskData.name.trim()) {
      toast({
        title: "Error",
        description: "Task name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('custom_tasks')
        .update({
          ...taskData,
          due_date: taskData.due_date || null
        })
        .eq('id', editingTask.id);

      if (error) throw error;

      resetForm();
      setEditDialogOpen(false);
      setEditingTask(null);
      fetchData();
      
      toast({
        title: "Success",
        description: "Task updated successfully"
      });
    } catch (error) {
      console.error('Error updating task:', error);
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive"
      });
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      await supabase.from('task_assignments').delete().eq('task_id', taskId);
      const { error } = await supabase.from('custom_tasks').delete().eq('id', taskId);

      if (error) throw error;

      fetchData();
      toast({
        title: "Success",
        description: "Task deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive"
      });
    }
  };

  const handleAssignTask = async () => {
    if (!selectedTaskForAssign || selectedUsers.length === 0) {
      toast({
        title: "Error",
        description: "Please select users to assign",
        variant: "destructive"
      });
      return;
    }

    try {
      // Check for existing assignments
      const { data: existingAssignments } = await supabase
        .from('task_assignments')
        .select('user_id')
        .eq('task_id', selectedTaskForAssign)
        .in('user_id', selectedUsers);

      const existingUserIds = new Set(existingAssignments?.map(a => a.user_id) || []);
      const newUsers = selectedUsers.filter(userId => !existingUserIds.has(userId));

      if (newUsers.length === 0) {
        toast({
          title: "Info",
          description: "All selected users already have this task assigned",
          variant: "default"
        });
        setAssignDialogOpen(false);
        setSelectedTaskForAssign(null);
        setSelectedUsers([]);
        return;
      }

      const assignments = newUsers.map(userId => ({
        task_id: selectedTaskForAssign,
        user_id: userId,
        assigned_by: user?.id,
        status: 'pending'
      }));

      const { error } = await supabase.from('task_assignments').insert(assignments);

      if (error) throw error;

      setAssignDialogOpen(false);
      setSelectedTaskForAssign(null);
      setSelectedUsers([]);
      fetchData();
      
      const skippedCount = selectedUsers.length - newUsers.length;
      toast({
        title: "Success",
        description: `Task assigned to ${newUsers.length} user(s)${skippedCount > 0 ? ` (${skippedCount} already assigned)` : ''}`
      });
    } catch (error) {
      console.error('Error assigning task:', error);
      toast({
        title: "Error",
        description: "Failed to assign task",
        variant: "destructive"
      });
    }
  };

  const handleUnassignTask = async (assignmentId: string) => {
    try {
      const { error } = await supabase
        .from('task_assignments')
        .delete()
        .eq('id', assignmentId);

      if (error) throw error;

      fetchData();
      toast({
        title: "Success",
        description: "Task assignment removed successfully"
      });
    } catch (error) {
      console.error('Error unassigning task:', error);
      toast({
        title: "Error",
        description: "Failed to remove task assignment",
        variant: "destructive"
      });
    }
  };

  const handleUpdateAssignmentStatus = async (assignmentId: string, status: string) => {
    try {
      // When admin marks as completed, auto-approve it
      const updateData: any = { status };
      
      if (status === 'completed') {
        updateData.completed_at = new Date().toISOString();
        updateData.approval_status = 'approved';
        updateData.approved_by = user?.id;
        updateData.approved_at = new Date().toISOString();
      } else {
        updateData.completed_at = null;
        updateData.approval_status = 'pending_approval';
        updateData.approved_by = null;
        updateData.approved_at = null;
      }

      const { error } = await supabase
        .from('task_assignments')
        .update(updateData)
        .eq('id', assignmentId);

      if (error) throw error;

      fetchData();
      toast({
        title: "Success",
        description: `Task marked as ${status}`
      });
    } catch (error) {
      console.error('Error updating assignment:', error);
      toast({
        title: "Error",
        description: "Failed to update task status",
        variant: "destructive"
      });
    }
  };

  const startEdit = (task: CustomTask) => {
    setEditingTask(task);
    setTaskData({
      name: task.name,
      description: task.description || '',
      category: task.category,
      required: task.required,
      custom_link: task.custom_link || '',
      priority: task.priority || 'medium',
      due_date: task.due_date ? format(new Date(task.due_date), 'yyyy-MM-dd') : '',
      assigned_roles: task.assigned_roles || [],
      redirect_path: (task.redirect_path as any) || []
    });
    setEditDialogOpen(true);
  };

  const resetForm = () => {
    setTaskData({
      name: '',
      description: '',
      category: 'general',
      required: false,
      custom_link: '',
      priority: 'medium',
      due_date: '',
      assigned_roles: [],
      redirect_path: []
    });
    setEditingTask(null);
    setCreateSelectedUsers([]);
    setCreateUserSearch('');
    setBulkSelectRole('');
  };

  const handleBulkSelectByRole = (role: string) => {
    if (!role) return;
    
    const roleUsers = users
      .filter(u => u.role_key === role)
      .map(u => u.id);
    
    setCreateSelectedUsers(prev => {
      const newSet = new Set([...prev, ...roleUsers]);
      return Array.from(newSet);
    });
    
    toast({
      title: "Success",
      description: `Selected ${roleUsers.length} ${role}(s)`
    });
  };

  const handleSelectAllUsers = () => {
    // Select all users from all roles except super_admin
    const allUserIds = users.filter(u => u.role_key !== 'super_admin').map(u => u.id);
    setCreateSelectedUsers(allUserIds);
    
    toast({
      title: "Success",
      description: `Selected all ${allUserIds.length} user(s) from 6 roles`
    });
  };

  const handleClearSelection = () => {
    setCreateSelectedUsers([]);
    setCreateUserSearch('');
    setBulkSelectRole('');
    toast({
      title: "Selection cleared",
      description: "All user selections have been cleared"
    });
  };

  const getPriorityBadge = (priority: string) => {
    const colors = {
      low: 'bg-blue-100 text-blue-800',
      medium: 'bg-yellow-100 text-yellow-800',
      high: 'bg-orange-100 text-orange-800',
      urgent: 'bg-red-100 text-red-800'
    };
    return <Badge className={colors[priority as keyof typeof colors] || colors.medium}>{priority}</Badge>;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case 'in_progress':
        return <Badge variant="default" className="bg-blue-100 text-blue-800"><AlertCircle className="h-3 w-3 mr-1" />In Progress</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getApprovalBadge = (approvalStatus: string) => {
    switch (approvalStatus) {
      case 'approved':
        return <Badge variant="default" className="bg-green-100 text-green-800"><ThumbsUp className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><ThumbsDown className="h-3 w-3 mr-1" />Rejected</Badge>;
      case 'pending_approval':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Needs Approval</Badge>;
      default:
        return <Badge variant="outline">{approvalStatus}</Badge>;
    }
  };

  const handleApproveAssignment = async (assignmentId: string) => {
    try {
      const { error } = await supabase.rpc('approve_task_assignment', {
        p_assignment_id: assignmentId,
        p_approved_by: user?.id
      });

      if (error) throw error;

      fetchData();
      toast({
        title: "Success",
        description: "Task assignment approved"
      });
    } catch (error) {
      console.error('Error approving assignment:', error);
      toast({
        title: "Error",
        description: "Failed to approve task assignment",
        variant: "destructive"
      });
    }
  };

  const handleRejectAssignment = async () => {
    if (!rejectingAssignment || !rejectionReason.trim()) {
      toast({
        title: "Error",
        description: "Please provide a rejection reason",
        variant: "destructive"
      });
      return;
    }

    try {
      // When rejecting, downgrade task status to pending and flag as rejected
      const { error } = await supabase
        .from('task_assignments')
        .update({
          status: 'pending', // Downgrade to pending
          approval_status: 'rejected',
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
          rejection_reason: rejectionReason,
          completed_at: null // Clear completion time
        })
        .eq('id', rejectingAssignment);

      if (error) throw error;

      setRejectDialogOpen(false);
      setRejectingAssignment(null);
      setRejectionReason('');
      fetchData();
      
      toast({
        title: "Task Rejected",
        description: "Task has been downgraded to pending status with rejection reason"
      });
    } catch (error) {
      console.error('Error rejecting assignment:', error);
      toast({
        title: "Error",
        description: "Failed to reject task assignment",
        variant: "destructive"
      });
    }
  };

  const handleResetApproval = async (assignmentId: string) => {
    try {
      const { error } = await supabase
        .from('task_assignments')
        .update({
          approval_status: 'pending_approval',
          approved_by: null,
          approved_at: null,
          rejection_reason: null
        })
        .eq('id', assignmentId);

      if (error) throw error;

      fetchData();
      toast({
        title: "Success",
        description: "Approval status reset"
      });
    } catch (error) {
      console.error('Error resetting approval:', error);
      toast({
        title: "Error",
        description: "Failed to reset approval status",
        variant: "destructive"
      });
    }
  };

  // Bulk action handlers
  const handleBulkDeleteTasks = async () => {
    if (selectedTasks.length === 0) return;
    
    try {
      await supabase.from('task_assignments').delete().in('task_id', selectedTasks);
      const { error } = await supabase.from('custom_tasks').delete().in('id', selectedTasks);
      if (error) throw error;

      setSelectedTasks([]);
      fetchData();
      toast({ title: "Success", description: `Deleted ${selectedTasks.length} tasks` });
    } catch (error) {
      console.error('Error bulk deleting tasks:', error);
      toast({ title: "Error", description: "Failed to delete tasks", variant: "destructive" });
    }
  };

  const handleBulkApproveAssignments = async () => {
    if (selectedAssignments.length === 0) return;
    
    try {
      for (const id of selectedAssignments) {
        await supabase.rpc('approve_task_assignment', {
          p_assignment_id: id,
          p_approved_by: user?.id
        });
      }

      setSelectedAssignments([]);
      fetchData();
      toast({ title: "Success", description: `Approved ${selectedAssignments.length} assignments` });
    } catch (error) {
      console.error('Error bulk approving assignments:', error);
      toast({ title: "Error", description: "Failed to approve assignments", variant: "destructive" });
    }
  };

  const handleBulkRejectAssignments = async (reason: string) => {
    if (selectedAssignments.length === 0 || !reason.trim()) return;
    
    try {
      const { error } = await supabase
        .from('task_assignments')
        .update({
          status: 'pending',
          approval_status: 'rejected',
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
          rejection_reason: reason,
          completed_at: null
        })
        .in('id', selectedAssignments);

      if (error) throw error;

      setSelectedAssignments([]);
      fetchData();
      toast({ title: "Success", description: `Rejected ${selectedAssignments.length} assignments` });
    } catch (error) {
      console.error('Error bulk rejecting assignments:', error);
      toast({ title: "Error", description: "Failed to reject assignments", variant: "destructive" });
    }
  };

  const handleBulkDeleteAssignments = async () => {
    if (selectedAssignments.length === 0) return;
    
    try {
      const { error } = await supabase.from('task_assignments').delete().in('id', selectedAssignments);
      if (error) throw error;

      setSelectedAssignments([]);
      fetchData();
      toast({ title: "Success", description: `Deleted ${selectedAssignments.length} assignments` });
    } catch (error) {
      console.error('Error bulk deleting assignments:', error);
      toast({ title: "Error", description: "Failed to delete assignments", variant: "destructive" });
    }
  };

  const handleBulkDeletePredefined = () => {
    if (selectedPredefined.length === 0) return;
    
    setPredefinedTasks(predefinedTasks.filter(t => !selectedPredefined.includes(t.id)));
    setSelectedPredefined([]);
    toast({ title: "Success", description: `Deleted ${selectedPredefined.length} predefined tasks` });
  };

  const handleBulkUseAsTemplate = async () => {
    if (selectedPredefined.length === 0 || bulkTemplateRoles.length === 0) {
      toast({
        title: "Error",
        description: "Please select tasks and at least one role",
        variant: "destructive"
      });
      return;
    }

    try {
      // Get the actual task IDs from predefined tasks
      const taskNames = predefinedTasks
        .filter(pt => selectedPredefined.includes(pt.id))
        .map(pt => pt.name);

      // Find matching tasks in custom_tasks
      const { data: matchingTasks, error: fetchError } = await supabase
        .from('custom_tasks')
        .select('id, name')
        .in('name', taskNames);

      if (fetchError) throw fetchError;

      if (!matchingTasks || matchingTasks.length === 0) {
        toast({
          title: "Error",
          description: "No matching tasks found in database",
          variant: "destructive"
        });
        return;
      }

      // Check for existing templates to avoid duplicates
      const { data: existing, error: existingError } = await supabase
        .from('default_task_templates')
        .select('task_id, role_key')
        .in('task_id', matchingTasks.map(t => t.id))
        .in('role_key', bulkTemplateRoles);

      if (existingError) throw existingError;

      const existingSet = new Set(
        (existing || []).map(e => `${e.task_id}-${e.role_key}`)
      );

      // Create template records for each task-role combination
      const templateRecords = [];
      for (const task of matchingTasks) {
        for (const role of bulkTemplateRoles) {
          const key = `${task.id}-${role}`;
          if (!existingSet.has(key)) {
            templateRecords.push({
              task_id: task.id,
              role_key: role,
              created_by: user?.id,
              display_order: 0
            });
          }
        }
      }

      if (templateRecords.length === 0) {
        toast({
          title: "Info",
          description: "All selected tasks are already templates for the selected roles",
        });
        setBulkTemplateDialogOpen(false);
        setBulkTemplateRoles([]);
        return;
      }

      const { error: insertError } = await supabase
        .from('default_task_templates')
        .insert(templateRecords);

      if (insertError) throw insertError;

      toast({
        title: "Success",
        description: `Added ${templateRecords.length} task template(s) for ${bulkTemplateRoles.length} role(s)`,
      });

      setSelectedPredefined([]);
      setBulkTemplateDialogOpen(false);
      setBulkTemplateRoles([]);
      fetchData();
    } catch (error: any) {
      console.error('Error adding bulk templates:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to add templates",
        variant: "destructive"
      });
    }
  };

  const handleBulkCustomUseAsTemplate = async () => {
    if (selectedCustom.length === 0 || bulkCustomTemplateRoles.length === 0) {
      toast({
        title: "Error",
        description: "Please select tasks and at least one role",
        variant: "destructive"
      });
      return;
    }

    try {
      // Check for existing templates to avoid duplicates
      const { data: existing, error: existingError } = await supabase
        .from('default_task_templates')
        .select('task_id, role_key')
        .in('task_id', selectedCustom)
        .in('role_key', bulkCustomTemplateRoles);

      if (existingError) throw existingError;

      const existingSet = new Set(
        (existing || []).map(e => `${e.task_id}-${e.role_key}`)
      );

      // Create template records for each task-role combination
      const templateRecords = [];
      for (const taskId of selectedCustom) {
        for (const role of bulkCustomTemplateRoles) {
          const key = `${taskId}-${role}`;
          if (!existingSet.has(key)) {
            templateRecords.push({
              task_id: taskId,
              role_key: role,
              created_by: user?.id,
              display_order: 0
            });
          }
        }
      }

      if (templateRecords.length === 0) {
        toast({
          title: "Info",
          description: "All selected tasks are already templates for the selected roles",
        });
        setBulkCustomTemplateDialogOpen(false);
        setBulkCustomTemplateRoles([]);
        return;
      }

      const { error: insertError } = await supabase
        .from('default_task_templates')
        .insert(templateRecords);

      if (insertError) throw insertError;

      toast({
        title: "Success",
        description: `Added ${templateRecords.length} task template(s) for ${bulkCustomTemplateRoles.length} role(s)`,
      });

      setSelectedCustom([]);
      setBulkCustomTemplateDialogOpen(false);
      setBulkCustomTemplateRoles([]);
      fetchData();
    } catch (error: any) {
      console.error('Error adding bulk templates:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to add templates",
        variant: "destructive"
      });
    }
  };

  const handleBulkCreateTasks = async () => {
    if (tasksToCreate.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one task to create",
        variant: "destructive"
      });
      return;
    }

    try {
      // Get selected predefined tasks
      const selectedPredefinedTasks = predefinedTasks.filter(t => tasksToCreate.includes(t.id));
      
      // Check which tasks already exist in custom_tasks
      const { data: existingTasks } = await supabase
        .from('custom_tasks')
        .select('name')
        .in('name', selectedPredefinedTasks.map(t => t.name));
      
      const existingTaskNames = new Set(existingTasks?.map(t => t.name) || []);
      
      // Filter out tasks that already exist
      const tasksToInsert = selectedPredefinedTasks
        .filter(t => !existingTaskNames.has(t.name))
        .map(task => ({
          name: task.name,
          description: `Complete ${task.name}`,
          category: task.category || 'General',
          required: true,
          priority: 'medium',
          assigned_roles: task.assignedRoles,
          created_by: user?.id
        }));

      if (tasksToInsert.length === 0) {
        toast({
          title: "Info",
          description: "All selected tasks already exist",
        });
        setBulkCreateDialogOpen(false);
        setTasksToCreate([]);
        return;
      }

      // Insert tasks
      const { error } = await supabase
        .from('custom_tasks')
        .insert(tasksToInsert);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Created ${tasksToInsert.length} task(s). ${existingTaskNames.size > 0 ? `${existingTaskNames.size} task(s) already existed.` : ''}`,
      });

      setBulkCreateDialogOpen(false);
      setTasksToCreate([]);
      fetchData();
    } catch (error: any) {
      console.error('Error creating bulk tasks:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create tasks",
        variant: "destructive"
      });
    }
  };

  const handleBulkAssignTasks = async () => {
    if (selectedTasks.length === 0 || bulkAssignUsers.length === 0) {
      toast({
        title: "Error",
        description: "Please select tasks and at least one user",
        variant: "destructive"
      });
      return;
    }

    try {
      const assignments = [];
      for (const taskId of selectedTasks) {
        for (const userId of bulkAssignUsers) {
          assignments.push({
            task_id: taskId,
            user_id: userId,
            assigned_by: user?.id,
            status: 'pending',
            approval_status: 'pending_approval'
          });
        }
      }

      // Check for existing assignments to avoid duplicates
      const { data: existingAssignments } = await supabase
        .from('task_assignments')
        .select('task_id, user_id')
        .in('task_id', selectedTasks)
        .in('user_id', bulkAssignUsers);

      const existingSet = new Set(
        existingAssignments?.map(a => `${a.task_id}-${a.user_id}`) || []
      );

      const filteredAssignments = assignments.filter(
        a => !existingSet.has(`${a.task_id}-${a.user_id}`)
      );

      if (filteredAssignments.length === 0) {
        toast({
          title: "Info",
          description: "All selected tasks are already assigned to selected users",
        });
        setBulkAssignDialogOpen(false);
        setBulkAssignUsers([]);
        return;
      }

      const { error } = await supabase
        .from('task_assignments')
        .insert(filteredAssignments);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Created ${filteredAssignments.length} task assignment(s)`,
      });

      setBulkAssignDialogOpen(false);
      setBulkAssignUsers([]);
      setBulkAssignSearch('');
      setSelectedTasks([]);
      fetchData();
    } catch (error: any) {
      console.error('Error bulk assigning tasks:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to assign tasks",
        variant: "destructive"
      });
    }
  };

  const handleBulkUnassignTasks = async () => {
    if (selectedTasks.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one task",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('task_assignments')
        .delete()
        .in('task_id', selectedTasks);

      if (error) throw error;

      toast({
        title: "Success",
        description: `Removed all assignments for ${selectedTasks.length} task(s)`,
      });

      setBulkUnassignDialogOpen(false);
      setSelectedTasks([]);
      fetchData();
    } catch (error: any) {
      console.error('Error bulk unassigning tasks:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to unassign tasks",
        variant: "destructive"
      });
    }
  };

  // Filter assignments
  const filteredAssignments = assignments.filter(assignment => {
    const roleMatch = filterRole === 'all' || assignment.profiles?.role_key === filterRole;
    const statusMatch = filterStatus === 'all' || assignment.status === filterStatus;
    const approvalMatch = filterApproval === 'all' || assignment.approval_status === filterApproval;
    return roleMatch && statusMatch && approvalMatch;
  });

  // Group tasks by role
  const tasksByRole = tasks.reduce((acc, task) => {
    const roles = task.assigned_roles || ['unassigned'];
    roles.forEach(role => {
      if (!acc[role]) {
        acc[role] = [];
      }
      acc[role].push(task);
    });
    return acc;
  }, {} as Record<string, CustomTask[]>);

  const roleLabels: Record<string, string> = {
    'driver': 'Driver',
    'shipper': 'Shipper',
    'carrier': 'Carrier',
    'vendor': 'Vendor',
    'vendor_merchant': 'Vendor/Merchant',
    'broker': 'Broker',
    'admin': 'Admin',
    'super_admin': 'Super Admin',
    'unassigned': 'Unassigned'
  };

  // Group assignments by user
  const assignmentsByUser = assignments.reduce((acc, assignment) => {
    const userId = assignment.user_id;
    if (!acc[userId]) {
      acc[userId] = {
        user: assignment.profiles || { full_name: 'Unknown', email: '', role_key: '' },
        userId: userId,
        tasks: []
      };
    }
    acc[userId].tasks.push(assignment);
    return acc;
  }, {} as Record<string, { user: any; userId: string; tasks: TaskAssignment[] }>);

  const userAssignmentsList = Object.values(assignmentsByUser).sort((a, b) => 
    (a.user.full_name || '').localeCompare(b.user.full_name || '')
  );

  const filteredUserAssignments = userAssignmentsList.filter(ua => {
    const roleMatch = filterRole === 'all' || ua.user.role_key === filterRole;
    const searchLower = userSearch.toLowerCase();
    const searchMatch = !userSearch || 
      ua.user.full_name?.toLowerCase().includes(searchLower) ||
      ua.user.email?.toLowerCase().includes(searchLower);
    return roleMatch && searchMatch;
  });

  const myAssignments = assignments.filter(a => a.user_id === user?.id);
  const completedAssignments = assignments.filter(a => a.status === 'completed');
  const pendingAssignments = assignments.filter(a => a.status === 'pending');

  // Get account numbers for search
  const getUserAccountNumber = (userId: string) => {
    return users.find(u => u.id === userId)?.account_number || '';
  };

  // Filter assignments with search
  const filterAssignmentsWithSearch = (assignmentsList: TaskAssignment[]) => {
    if (!userSearch) return assignmentsList;
    const searchLower = userSearch.toLowerCase();
    return assignmentsList.filter(a => {
      const accountNumber = getUserAccountNumber(a.user_id);
      return a.profiles?.full_name?.toLowerCase().includes(searchLower) ||
        a.profiles?.email?.toLowerCase().includes(searchLower) ||
        accountNumber.toLowerCase().includes(searchLower);
    });
  };

  const searchedCompletedAssignments = filterAssignmentsWithSearch(completedAssignments);
  const searchedPendingAssignments = filterAssignmentsWithSearch(pendingAssignments);
  const searchedPendingApprovals = filterAssignmentsWithSearch(assignments.filter(a => a.approval_status === 'pending_approval'));

  // Filtered users for create modal (exclude super_admin)
  const filteredUsersForCreate = users.filter(u => {
    // Exclude super_admin role
    if (u.role_key === 'super_admin') return false;
    
    const searchLower = createUserSearch.toLowerCase();
    return (
      u.full_name?.toLowerCase().includes(searchLower) ||
      u.email?.toLowerCase().includes(searchLower) ||
      u.role_key?.toLowerCase().includes(searchLower) ||
      u.account_number?.toLowerCase().includes(searchLower)
    );
  });

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading tasks management...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Tasks Management</h2>
          <p className="text-muted-foreground">Create, assign, and track tasks across the platform</p>
        </div>
        <Button onClick={() => setCreateDialogOpen(true)} className="flex items-center space-x-2">
          <Plus className="h-4 w-4" />
          <span>Create Task</span>
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="grid w-full grid-cols-8">
          <TabsTrigger value="all">All Tasks</TabsTrigger>
          <TabsTrigger value="predefined">Predefined Tasks</TabsTrigger>
          <TabsTrigger value="by-user">By User</TabsTrigger>
          <TabsTrigger value="by-role">By Role</TabsTrigger>
          <TabsTrigger value="approvals">Approvals</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="pending">Pending</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>

        {/* All Tasks Tab */}
        <TabsContent value="all" className="space-y-4">
          {/* Bulk Actions Bar */}
          {tasks.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Checkbox
                      checked={selectedTasks.length === tasks.length}
                      onCheckedChange={(checked) => {
                        setSelectedTasks(checked ? tasks.map(t => t.id) : []);
                      }}
                    />
                    <span className="text-sm font-medium">
                      {selectedTasks.length > 0 ? `${selectedTasks.length} selected` : 'Select All'}
                    </span>
                  </div>
                  {selectedTasks.length > 0 && (
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setBulkAssignDialogOpen(true)}
                      >
                        <UserPlus className="h-4 w-4 mr-1" />
                        Assign ({selectedTasks.length})
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <UserMinus className="h-4 w-4 mr-1" />
                            Unassign All ({selectedTasks.length})
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Unassign All Users</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to remove ALL assignments for {selectedTasks.length} task(s)? This will unassign these tasks from all users.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleBulkUnassignTasks}>
                              Unassign All
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="h-4 w-4 mr-1" />
                            Delete ({selectedTasks.length})
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Tasks</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete {selectedTasks.length} task(s)? This will also remove all assignments.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleBulkDeleteTasks} className="bg-red-600 hover:bg-red-700">
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}
          
          <div className="space-y-6">
            {tasks.length === 0 ? (
              <Card>
                <CardContent className="p-6 text-center">
                  <AlertCircle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No tasks created yet</p>
                </CardContent>
              </Card>
            ) : (
              Object.entries(tasksByRole).map(([role, roleTasks]) => (
                <div key={role} className="space-y-4">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-semibold">{roleLabels[role] || role}</h3>
                    <Badge variant="outline">{roleTasks.length} task{roleTasks.length !== 1 ? 's' : ''}</Badge>
                  </div>
                  <div className="grid gap-4">
                    {roleTasks.map((task) => (
                      <Card key={task.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-start gap-4">
                            <Checkbox
                              checked={selectedTasks.includes(task.id)}
                              onCheckedChange={(checked) => {
                                setSelectedTasks(
                                  checked 
                                    ? [...selectedTasks, task.id]
                                    : selectedTasks.filter(id => id !== task.id)
                                );
                              }}
                              className="mt-1"
                            />
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <h3 className="font-semibold text-lg">{task.name}</h3>
                                <Badge variant="outline">{task.category}</Badge>
                                {task.priority && getPriorityBadge(task.priority)}
                                {task.required && <Badge variant="secondary">Required</Badge>}
                              </div>
                              {task.description && (
                                <p className="text-sm text-muted-foreground mb-2">{task.description}</p>
                              )}
                              <div className="flex flex-wrap gap-2 text-sm">
                                {task.custom_link && (
                                  <div className="flex items-center text-blue-600">
                                    <LinkIcon className="h-3 w-3 mr-1" />
                                    <a href={task.custom_link} target="_blank" rel="noopener noreferrer" className="underline">
                                      Resource Link
                                    </a>
                                  </div>
                                )}
                                {task.due_date && (
                                  <div className="flex items-center text-muted-foreground">
                                    <Calendar className="h-3 w-3 mr-1" />
                                    Due: {format(new Date(task.due_date), 'MMM dd, yyyy')}
                                  </div>
                                )}
                              </div>
                              <p className="text-xs text-muted-foreground mt-2">
                                Created {format(new Date(task.created_at), 'MMM dd, yyyy')}
                              </p>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => navigate(`/task-form?id=${task.id}`)}
                              >
                                <Eye className="h-4 w-4 mr-1" />
                                View Form
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedTaskForAssign(task.id);
                                  setAssignDialogOpen(true);
                                }}
                              >
                                <Users className="h-4 w-4 mr-1" />
                                Assign
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  setSelectedTaskForUnassign(task.id);
                                  setUnassignDialogOpen(true);
                                }}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Unassign
                              </Button>
                              <Button variant="outline" size="sm" onClick={() => startEdit(task)}>
                                <Edit2 className="h-4 w-4" />
                              </Button>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Trash2 className="h-4 w-4 text-red-500" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Delete Task</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Are you sure you want to delete "{task.name}"? This will also remove all assignments.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => handleDeleteTask(task.id)}
                                      className="bg-red-600 hover:bg-red-700"
                                    >
                                      Delete
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </TabsContent>

        {/* Predefined Tasks Tab */}
        <TabsContent value="predefined" className="space-y-4">
          <div className="flex justify-between items-center mb-4">
            <p className="text-sm text-muted-foreground">
              Manage default predefined tasks for all roles
            </p>
            <div className="flex gap-2">
              {selectedPredefined.length > 0 && (
                <>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setBulkTemplateDialogOpen(true)}
                  >
                    <Users className="h-4 w-4 mr-1" />
                    Use as Template ({selectedPredefined.length})
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => {
                      setTasksToCreate(selectedPredefined);
                      setBulkCreateDialogOpen(true);
                    }}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Create Tasks ({selectedPredefined.length})
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4 mr-1" />
                        Delete ({selectedPredefined.length})
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Delete Predefined Tasks</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to delete {selectedPredefined.length} predefined task(s)?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleBulkDeletePredefined} className="bg-red-600 hover:bg-red-700">
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
              <Button onClick={() => { setEditingPredefined(null); setShowPredefinedModal(true); }}>
                <Plus className="mr-2 h-4 w-4" />
                Add Predefined Task
              </Button>
            </div>
          </div>

          {['UNIVERSAL TASKS', 'DRIVER TASKS', 'SHIPPER TASKS', 'CARRIER TASKS', 'VENDOR TASKS', 'ADMIN (LIMITED) TASKS', 'ADMIN (SUPER) TASKS'].map((category) => {
            const categoryTasks = predefinedTasks.filter(t => t.category === category);
            if (categoryTasks.length === 0) return null;

            return (
              <Card key={category} className="p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold">{category}</h3>
                  <Checkbox
                    checked={categoryTasks.every(t => selectedPredefined.includes(t.id))}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setSelectedPredefined([...selectedPredefined, ...categoryTasks.map(t => t.id)]);
                      } else {
                        setSelectedPredefined(selectedPredefined.filter(id => !categoryTasks.find(t => t.id === id)));
                      }
                    }}
                  />
                </div>
                <div className="space-y-2">
                  {categoryTasks.map((task) => (
                    <div key={task.id} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                      <Checkbox
                        checked={selectedPredefined.includes(task.id)}
                        onCheckedChange={(checked) => {
                          setSelectedPredefined(
                            checked
                              ? [...selectedPredefined, task.id]
                              : selectedPredefined.filter(id => id !== task.id)
                          );
                        }}
                      />
                      <div className="flex-1">
                        <p className="font-medium">{task.name}</p>
                        <div className="flex gap-1 mt-1 flex-wrap">
                          {task.assignedRoles.map((role: string) => (
                            <Badge key={role} variant="outline" className="text-xs">
                              {role}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={async () => {
                            // Try to find in loaded tasks first
                            let taskData = tasks.find(t => t.name === task.name);
                            
                            // If not found, try to load from database
                            if (!taskData) {
                              try {
                                const { data, error } = await supabase
                                  .from('custom_tasks')
                                  .select('*')
                                  .eq('name', task.name)
                                  .maybeSingle();
                                
                                if (error) throw error;
                                taskData = data as CustomTask;
                              } catch (error) {
                                console.error('Error loading task:', error);
                              }
                            }
                            
                            if (taskData) {
                              navigate(`/task-form?id=${taskData.id}`);
                            } else {
                              toast({
                                title: "Task Not Found",
                                description: "This predefined task hasn't been created yet. You can create it using the Templates tab.",
                                variant: "destructive"
                              });
                            }
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setEditingPredefined(task);
                            setShowPredefinedModal(true);
                          }}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setPredefinedTasks(predefinedTasks.filter(t => t.id !== task.id));
                            toast({
                              title: "Task deleted",
                              description: "Predefined task has been removed.",
                            });
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => {
                            setTaskData({
                              ...taskData,
                              name: task.name,
                              category: task.category.toLowerCase().replace(/\s+/g, '_'),
                            });
                            setCreateDialogOpen(true);
                          }}
                        >
                          Use Template
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            );
          })}
        </TabsContent>

        {/* By User Tab */}
        <TabsContent value="by-user" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Tasks by User</CardTitle>
                    <CardDescription>View all assigned tasks grouped by user ({filteredUserAssignments.length} users)</CardDescription>
                  </div>
                  <Select value={filterRole} onValueChange={setFilterRole}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue placeholder="Filter by role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Roles</SelectItem>
                      <SelectItem value="driver">Driver</SelectItem>
                      <SelectItem value="shipper">Shipper</SelectItem>
                      <SelectItem value="carrier">Carrier</SelectItem>
                      <SelectItem value="vendor">Vendor</SelectItem>
                      <SelectItem value="broker">Broker</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="relative">
                  <Input
                    placeholder="Search by name, email, or user code..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="max-w-md"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredUserAssignments.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No users with task assignments</p>
              ) : (
                <div className="space-y-6">
                  {filteredUserAssignments.map(({ user, userId, tasks }) => {
                    const pendingCount = tasks.filter(t => t.status === 'pending').length;
                    const inProgressCount = tasks.filter(t => t.status === 'in_progress').length;
                    const completedCount = tasks.filter(t => t.status === 'completed').length;
                    const pendingApprovalCount = tasks.filter(t => t.approval_status === 'pending_approval').length;

                    return (
                      <Card key={userId} className="border-2">
                        <CardHeader className="pb-3">
                          <div className="flex items-start justify-between">
                            <div className="space-y-1">
                              <div className="flex items-center gap-2">
                                <CardTitle className="text-lg">{user.full_name || 'Unknown User'}</CardTitle>
                                <Badge variant="outline">{user.role_key}</Badge>
                              </div>
                              <p className="text-sm text-muted-foreground">{user.email}</p>
                              {getUserAccountNumber(userId) && (
                                <p className="text-xs text-muted-foreground">User Code: {getUserAccountNumber(userId)}</p>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Badge variant="secondary" className="gap-1">
                                <Clock className="h-3 w-3" />
                                {pendingCount} Pending
                              </Badge>
                              <Badge variant="default" className="gap-1">
                                <CheckCircle className="h-3 w-3" />
                                {completedCount} Done
                              </Badge>
                              {pendingApprovalCount > 0 && (
                                <Badge variant="outline" className="gap-1 border-amber-500 text-amber-700">
                                  <AlertCircle className="h-3 w-3" />
                                  {pendingApprovalCount} Needs Approval
                                </Badge>
                              )}
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Task Name</TableHead>
                                <TableHead>Category</TableHead>
                                <TableHead>Priority</TableHead>
                                <TableHead>Status</TableHead>
                                <TableHead>Approval</TableHead>
                                <TableHead>Assigned</TableHead>
                                <TableHead>Actions</TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {tasks.map((task) => (
                                <TableRow key={task.id}>
                                  <TableCell>
                                    <div>
                                      <p className="font-medium">{task.task?.name}</p>
                                      {task.task?.description && (
                                        <p className="text-xs text-muted-foreground line-clamp-1">
                                          {task.task.description}
                                        </p>
                                      )}
                                    </div>
                                  </TableCell>
                                  <TableCell>
                                    <Badge variant="outline" className="text-xs">
                                      {task.task?.category}
                                    </Badge>
                                  </TableCell>
                                  <TableCell>
                                    {task.task?.priority && getPriorityBadge(task.task.priority)}
                                  </TableCell>
                                  <TableCell>{getStatusBadge(task.status)}</TableCell>
                                  <TableCell>
                                    {getApprovalBadge(task.approval_status || 'pending_approval')}
                                  </TableCell>
                                  <TableCell className="text-xs text-muted-foreground">
                                    {format(new Date(task.created_at), 'MMM dd, yyyy')}
                                  </TableCell>
                                  <TableCell>
                                    <div className="flex gap-2">
                                      {task.approval_status === 'pending_approval' && (
                                        <>
                                          <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => handleApproveAssignment(task.id)}
                                            className="h-8"
                                          >
                                            <ThumbsUp className="h-3 w-3" />
                                          </Button>
                                          <Button
                                            size="sm"
                                            variant="outline"
                                            onClick={() => {
                                              setRejectingAssignment(task.id);
                                              setRejectDialogOpen(true);
                                            }}
                                            className="h-8 text-red-600"
                                          >
                                            <ThumbsDown className="h-3 w-3" />
                                          </Button>
                                        </>
                                      )}
                                      <Select
                                        value={task.status}
                                        onValueChange={(value) => handleUpdateAssignmentStatus(task.id, value)}
                                      >
                                        <SelectTrigger className="w-[120px] h-8 text-xs">
                                          <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent>
                                          <SelectItem value="pending">Pending</SelectItem>
                                          <SelectItem value="in_progress">In Progress</SelectItem>
                                          <SelectItem value="completed">Completed</SelectItem>
                                        </SelectContent>
                                      </Select>
                                    </div>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* By Role Tab */}
        <TabsContent value="by-role" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Tasks by Role</CardTitle>
                  <CardDescription>Filter tasks by user role</CardDescription>
                </div>
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    <SelectItem value="driver">Driver</SelectItem>
                    <SelectItem value="shipper">Shipper</SelectItem>
                    <SelectItem value="broker">Broker</SelectItem>
                    <SelectItem value="carrier">Carrier</SelectItem>
                    <SelectItem value="vendor">Vendor</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={filterApproval} onValueChange={setFilterApproval}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Approval status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="pending_approval">Pending Approval</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {filteredAssignments.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No assignments found</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>User Code</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Task</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Approval</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAssignments.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.profiles?.full_name || 'Unknown'}</p>
                            <p className="text-sm text-muted-foreground">{assignment.profiles?.email}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-muted-foreground">
                            {getUserAccountNumber(assignment.user_id) || 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{assignment.profiles?.role_key}</Badge>
                        </TableCell>
                        <TableCell>{assignment.task?.name}</TableCell>
                        <TableCell>{getStatusBadge(assignment.status)}</TableCell>
                        <TableCell>
                          <div className="flex flex-col gap-1">
                            {getApprovalBadge(assignment.approval_status || 'pending_approval')}
                            {assignment.rejection_reason && (
                              <p className="text-xs text-muted-foreground">Reason: {assignment.rejection_reason}</p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            {assignment.approval_status === 'pending_approval' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleApproveAssignment(assignment.id)}
                                  className="h-8"
                                >
                                  <ThumbsUp className="h-4 w-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    setRejectingAssignment(assignment.id);
                                    setRejectDialogOpen(true);
                                  }}
                                  className="h-8 text-red-600"
                                >
                                  <ThumbsDown className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                                {assignment.rejection_reason && (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleResetApproval(assignment.id)}
                                    className="h-8"
                                  >
                                    <Undo2 className="h-4 w-4 mr-1" />
                                    Undo
                                  </Button>
                                )}
                              </>
                            )}
                            {assignment.approval_status === 'rejected' && (
                              <>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleApproveAssignment(assignment.id)}
                                  className="h-8"
                                >
                                  <ThumbsUp className="h-4 w-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleResetApproval(assignment.id)}
                                  className="h-8"
                                >
                                  <Undo2 className="h-4 w-4 mr-1" />
                                  Undo Rejection
                                </Button>
                              </>
                            )}
                            {assignment.approval_status === 'approved' && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleResetApproval(assignment.id)}
                                className="h-8"
                              >
                                <Undo2 className="h-4 w-4 mr-1" />
                                Reset Approval
                              </Button>
                            )}
                            <Select
                              value={assignment.status}
                              onValueChange={(value) => handleUpdateAssignmentStatus(assignment.id, value)}
                            >
                              <SelectTrigger className="w-[140px] h-8">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="pending">Pending</SelectItem>
                                <SelectItem value="in_progress">In Progress</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Completed Tab */}
        <TabsContent value="completed" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Completed Tasks</CardTitle>
                    <CardDescription>{searchedCompletedAssignments.length} tasks completed</CardDescription>
                  </div>
                  {selectedAssignments.length > 0 && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete ({selectedAssignments.length})
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Assignments</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete {selectedAssignments.length} assignment(s)?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={handleBulkDeleteAssignments} className="bg-red-600 hover:bg-red-700">
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
                <div className="relative">
                  <Input
                    placeholder="Search by name, email, or user code..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="max-w-md"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {searchedCompletedAssignments.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No completed tasks</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={searchedCompletedAssignments.every(a => selectedAssignments.includes(a.id))}
                          onCheckedChange={(checked) => {
                            setSelectedAssignments(checked ? searchedCompletedAssignments.map(a => a.id) : []);
                          }}
                        />
                      </TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>User Code</TableHead>
                      <TableHead>Task</TableHead>
                      <TableHead>Completed At</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {searchedCompletedAssignments.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedAssignments.includes(assignment.id)}
                            onCheckedChange={(checked) => {
                              setSelectedAssignments(
                                checked
                                  ? [...selectedAssignments, assignment.id]
                                  : selectedAssignments.filter(id => id !== assignment.id)
                              );
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.profiles?.full_name || 'Unknown'}</p>
                            <Badge variant="outline" className="mt-1">{assignment.profiles?.role_key}</Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-muted-foreground">
                            {getUserAccountNumber(assignment.user_id) || 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.task?.name}</p>
                            <p className="text-sm text-muted-foreground">{assignment.task?.description}</p>
                          </div>
                        </TableCell>
                        <TableCell>
                          {assignment.completed_at ? format(new Date(assignment.completed_at), 'MMM dd, yyyy HH:mm') : 'N/A'}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Approvals Tab */}
        <TabsContent value="approvals" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pending Approvals</CardTitle>
                    <CardDescription>Review and approve/reject task assignments</CardDescription>
                  </div>
                  {selectedAssignments.length > 0 && (
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={handleBulkApproveAssignments}
                        disabled={selectedAssignments.some(id => {
                          const assignment = searchedPendingApprovals.find(a => a.id === id);
                          return assignment?.status !== 'completed';
                        })}
                      >
                        <ThumbsUp className="h-4 w-4 mr-1" />
                        Approve ({selectedAssignments.length})
                      </Button>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            size="sm" 
                            variant="destructive"
                            disabled={selectedAssignments.some(id => {
                              const assignment = searchedPendingApprovals.find(a => a.id === id);
                              return assignment?.status !== 'completed';
                            })}
                          >
                            <ThumbsDown className="h-4 w-4 mr-1" />
                            Reject ({selectedAssignments.length})
                          </Button>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>Bulk Reject Assignments</DialogTitle>
                            <DialogDescription>
                              Provide a reason for rejecting {selectedAssignments.length} assignment(s)
                            </DialogDescription>
                          </DialogHeader>
                          <Textarea
                            placeholder="Rejection reason..."
                            value={rejectionReason}
                            onChange={(e) => setRejectionReason(e.target.value)}
                            rows={3}
                          />
                          <DialogFooter>
                            <Button variant="outline" onClick={() => setRejectionReason('')}>Cancel</Button>
                            <Button 
                              variant="destructive" 
                              onClick={() => {
                                handleBulkRejectAssignments(rejectionReason);
                                setRejectionReason('');
                              }}
                            >
                              Reject
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>
                    </div>
                  )}
                </div>
                <div className="relative">
                  <Input
                    placeholder="Search by name, email, or user code..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="max-w-md"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {searchedPendingApprovals.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No pending approvals</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={searchedPendingApprovals.every(a => selectedAssignments.includes(a.id))}
                          onCheckedChange={(checked) => {
                            setSelectedAssignments(checked ? searchedPendingApprovals.map(a => a.id) : []);
                          }}
                        />
                      </TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>User Code</TableHead>
                      <TableHead>Task</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Assigned</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {searchedPendingApprovals.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedAssignments.includes(assignment.id)}
                            onCheckedChange={(checked) => {
                              setSelectedAssignments(
                                checked
                                  ? [...selectedAssignments, assignment.id]
                                  : selectedAssignments.filter(id => id !== assignment.id)
                              );
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.profiles?.full_name || 'Unknown'}</p>
                            <Badge variant="outline" className="mt-1">{assignment.profiles?.role_key}</Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-muted-foreground">
                            {getUserAccountNumber(assignment.user_id) || 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.task?.name}</p>
                            <p className="text-sm text-muted-foreground">{assignment.task?.description}</p>
                          </div>
                        </TableCell>
                        <TableCell>{assignment.task?.priority && getPriorityBadge(assignment.task.priority)}</TableCell>
                        <TableCell>{format(new Date(assignment.created_at), 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              onClick={() => handleApproveAssignment(assignment.id)}
                              disabled={assignment.status !== 'completed'}
                            >
                              <ThumbsUp className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => {
                                setRejectingAssignment(assignment.id);
                                setRejectDialogOpen(true);
                              }}
                              disabled={assignment.status !== 'completed'}
                            >
                              <ThumbsDown className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                            {assignment.rejection_reason && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleResetApproval(assignment.id)}
                              >
                                <Undo2 className="h-4 w-4 mr-1" />
                                Undo
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pending Tab */}
        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Pending Tasks</CardTitle>
                    <CardDescription>{searchedPendingAssignments.length} tasks pending</CardDescription>
                  </div>
                  {selectedAssignments.length > 0 && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4 mr-1" />
                          Delete ({selectedAssignments.length})
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete Assignments</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete {selectedAssignments.length} assignment(s)?
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={handleBulkDeleteAssignments} className="bg-red-600 hover:bg-red-700">
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                </div>
                <div className="relative">
                  <Input
                    placeholder="Search by name, email, or user code..."
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    className="max-w-md"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {searchedPendingAssignments.length === 0 ? (
                <p className="text-muted-foreground text-center py-4">No pending tasks</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox
                          checked={searchedPendingAssignments.every(a => selectedAssignments.includes(a.id))}
                          onCheckedChange={(checked) => {
                            setSelectedAssignments(checked ? searchedPendingAssignments.map(a => a.id) : []);
                          }}
                        />
                      </TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>User Code</TableHead>
                      <TableHead>Task</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Assigned</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {searchedPendingAssignments.map((assignment) => (
                      <TableRow key={assignment.id}>
                        <TableCell>
                          <Checkbox
                            checked={selectedAssignments.includes(assignment.id)}
                            onCheckedChange={(checked) => {
                              setSelectedAssignments(
                                checked
                                  ? [...selectedAssignments, assignment.id]
                                  : selectedAssignments.filter(id => id !== assignment.id)
                              );
                            }}
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.profiles?.full_name || 'Unknown'}</p>
                            <Badge variant="outline" className="mt-1">{assignment.profiles?.role_key}</Badge>
                          </div>
                        </TableCell>
                        <TableCell>
                          <span className="text-sm text-muted-foreground">
                            {getUserAccountNumber(assignment.user_id) || 'N/A'}
                          </span>
                        </TableCell>
                        <TableCell>
                          <div>
                            <p className="font-medium">{assignment.task?.name}</p>
                            <p className="text-sm text-muted-foreground">{assignment.task?.description}</p>
                          </div>
                        </TableCell>
                        <TableCell>{assignment.task?.priority && getPriorityBadge(assignment.task.priority)}</TableCell>
                        <TableCell>{format(new Date(assignment.created_at), 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleUpdateAssignmentStatus(assignment.id, 'in_progress')}
                          >
                            Start
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Templates Tab */}
        <TabsContent value="templates" className="space-y-4">
          <DefaultTaskTemplates />
        </TabsContent>
      </Tabs>

      {/* Create Task Dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Task</DialogTitle>
            <DialogDescription>Add a new task and optionally assign to users immediately</DialogDescription>
          </DialogHeader>
          <div className="grid gap-6 py-4">
            {/* Task Details Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Task Details</h3>
            <div className="grid gap-2">
              <Label htmlFor="name">Task Name *</Label>
              <Input
                id="name"
                value={taskData.name}
                onChange={(e) => setTaskData({ ...taskData, name: e.target.value })}
                placeholder="Enter task name"
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={taskData.description}
                onChange={(e) => setTaskData({ ...taskData, description: e.target.value })}
                placeholder="Enter task description"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="category">Category</Label>
                <Select value={taskData.category} onValueChange={(value) => setTaskData({ ...taskData, category: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="verification">Verification</SelectItem>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="documentation">Documentation</SelectItem>
                    <SelectItem value="compliance">Compliance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="priority">Priority</Label>
                <Select value={taskData.priority} onValueChange={(value) => setTaskData({ ...taskData, priority: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="due_date">Due Date</Label>
              <Input
                id="due_date"
                type="date"
                value={taskData.due_date}
                onChange={(e) => setTaskData({ ...taskData, due_date: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="link">Resource Link (Optional)</Label>
              <Input
                id="link"
                value={taskData.custom_link}
                onChange={(e) => setTaskData({ ...taskData, custom_link: e.target.value })}
                placeholder="https://example.com"
              />
            </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="required"
                  checked={taskData.required}
                  onChange={(e) => setTaskData({ ...taskData, required: e.target.checked })}
                  className="h-4 w-4"
                />
                <Label htmlFor="required">Required Task</Label>
              </div>
            </div>

            {/* Task Completion Path Section */}
            <div className="space-y-4 border-t pt-4">
              <div>
                <h3 className="text-lg font-semibold">Task Completion Path (Optional)</h3>
                <p className="text-sm text-muted-foreground">Define a step-by-step path for completing this task</p>
              </div>

              {/* Display existing steps */}
              {taskData.redirect_path && taskData.redirect_path.length > 0 && (
                <div className="space-y-2">
                  {taskData.redirect_path.map((step: any, index: number) => (
                    <Card key={index} className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant="outline">Step {step.step_number}</Badge>
                            <h4 className="font-semibold">{step.step_name}</h4>
                            {step.is_optional && <Badge variant="secondary">Optional</Badge>}
                          </div>
                          {step.step_description && (
                            <p className="text-sm text-muted-foreground mb-2">{step.step_description}</p>
                          )}
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <ArrowRight className="h-3 w-3" />
                            <code className="bg-muted px-2 py-0.5 rounded text-xs">{step.path}</code>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveStep(step.step_number)}
                          className="h-8 w-8 p-0"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Add new step form */}
              <Card className="p-4">
                <div className="space-y-3">
                  <div className="grid gap-2">
                    <Label htmlFor="step-name">Step Name *</Label>
                    <Input
                      id="step-name"
                      placeholder="e.g., Complete Profile"
                      value={currentStep.step_name}
                      onChange={(e) => setCurrentStep({ ...currentStep, step_name: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="step-path">Path/URL *</Label>
                    <Input
                      id="step-path"
                      placeholder="e.g., /profile or https://example.com"
                      value={currentStep.path}
                      onChange={(e) => setCurrentStep({ ...currentStep, path: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="step-description">Description (Optional)</Label>
                    <Textarea
                      id="step-description"
                      placeholder="Additional details about this step"
                      value={currentStep.step_description}
                      onChange={(e) => setCurrentStep({ ...currentStep, step_description: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="step-optional"
                      checked={currentStep.is_optional}
                      onChange={(e) => setCurrentStep({ ...currentStep, is_optional: e.target.checked })}
                      className="h-4 w-4"
                    />
                    <Label htmlFor="step-optional">Optional Step</Label>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleAddStep}
                    className="w-full"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Step
                  </Button>
                </div>
              </Card>
            </div>

            {/* User Assignment Section */}
            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold">Assign to Users (Optional)</h3>
                  <p className="text-sm text-muted-foreground">Select users to assign this task immediately, or assign later</p>
                </div>
                <Badge variant="secondary">{createSelectedUsers.length} selected</Badge>
              </div>

              {/* Bulk Selection Tools */}
              <div className="flex flex-wrap gap-2">
                <Select value={bulkSelectRole} onValueChange={(value) => {
                  setBulkSelectRole(value);
                  handleBulkSelectByRole(value);
                }}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Select by role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="driver">All Drivers</SelectItem>
                    <SelectItem value="shipper">All Shippers</SelectItem>
                    <SelectItem value="broker">All Brokers</SelectItem>
                    <SelectItem value="carrier">All Carriers</SelectItem>
                    <SelectItem value="vendor">All Vendors</SelectItem>
                    <SelectItem value="admin">All Admins</SelectItem>
                  </SelectContent>
                </Select>
                <Button 
                  type="button"
                  variant="outline" 
                  size="sm"
                  onClick={handleSelectAllUsers}
                >
                  <Users className="h-4 w-4 mr-1" />
                  Select All (6)
                </Button>
                <Button 
                  type="button"
                  variant="outline" 
                  size="sm"
                  onClick={handleClearSelection}
                  disabled={createSelectedUsers.length === 0}
                >
                  Clear Selection
                </Button>
              </div>

              {/* Search Users */}
              <div className="grid gap-2">
                <Label htmlFor="user-search">Search Users</Label>
                <Input
                  id="user-search"
                  placeholder="User Code, name, email, or role..."
                  value={createUserSearch}
                  onChange={(e) => setCreateUserSearch(e.target.value)}
                />
              </div>

              {/* User List */}
              <div className="border rounded-md max-h-[300px] overflow-y-auto">
                {!createUserSearch.trim() ? (
                  <div className="p-4 text-center text-muted-foreground">
                    Enter name, email, or user code to search users
                  </div>
                ) : filteredUsersForCreate.length === 0 ? (
                  <div className="p-4 text-center text-muted-foreground">
                    No users found
                  </div>
                ) : (
                  <div className="divide-y">
                    {filteredUsersForCreate.map((user) => (
                      <div 
                        key={user.id} 
                        className="flex items-center space-x-3 p-3 hover:bg-accent cursor-pointer"
                        onClick={() => {
                          setCreateSelectedUsers(prev => 
                            prev.includes(user.id)
                              ? prev.filter(id => id !== user.id)
                              : [...prev, user.id]
                          );
                        }}
                      >
                        <Checkbox
                          checked={createSelectedUsers.includes(user.id)}
                          onCheckedChange={() => {}}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium truncate">{user.full_name}</p>
                            {user.account_number && (
                              <Badge variant="secondary" className="text-xs shrink-0">
                                #{user.account_number}
                              </Badge>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                            <Badge variant="outline" className="text-xs shrink-0">{user.role_key}</Badge>
                            {user.is_approved === false && (
                              <Badge variant="destructive" className="text-xs shrink-0">Not Approved</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {createSelectedUsers.length > 0 && (
                <div className="bg-muted p-3 rounded-md">
                  <p className="text-sm font-medium mb-2">Selected Users ({createSelectedUsers.length}):</p>
                  <div className="flex flex-wrap gap-1">
                    {createSelectedUsers.map(userId => {
                      const selectedUser = users.find(u => u.id === userId);
                      return selectedUser ? (
                        <Badge key={userId} variant="secondary" className="text-xs">
                          {selectedUser.full_name}
                        </Badge>
                      ) : null;
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleCreateTask}>
              {createSelectedUsers.length > 0 
                ? `Create & Assign to ${createSelectedUsers.length} User(s)` 
                : 'Create Task'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Task Dialog */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Task</DialogTitle>
            <DialogDescription>Update task details</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="edit-name">Task Name *</Label>
              <Input
                id="edit-name"
                value={taskData.name}
                onChange={(e) => setTaskData({ ...taskData, name: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={taskData.description}
                onChange={(e) => setTaskData({ ...taskData, description: e.target.value })}
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-category">Category</Label>
                <Select value={taskData.category} onValueChange={(value) => setTaskData({ ...taskData, category: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="general">General</SelectItem>
                    <SelectItem value="verification">Verification</SelectItem>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="documentation">Documentation</SelectItem>
                    <SelectItem value="compliance">Compliance</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-priority">Priority</Label>
                <Select value={taskData.priority} onValueChange={(value) => setTaskData({ ...taskData, priority: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-due_date">Due Date</Label>
              <Input
                id="edit-due_date"
                type="date"
                value={taskData.due_date}
                onChange={(e) => setTaskData({ ...taskData, due_date: e.target.value })}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="edit-link">Resource Link (Optional)</Label>
              <Input
                id="edit-link"
                value={taskData.custom_link}
                onChange={(e) => setTaskData({ ...taskData, custom_link: e.target.value })}
              />
            </div>
            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="edit-required"
                checked={taskData.required}
                onChange={(e) => setTaskData({ ...taskData, required: e.target.checked })}
                className="h-4 w-4"
              />
              <Label htmlFor="edit-required">Required Task</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdateTask}>Update Task</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Task Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Assign Task to Users</DialogTitle>
            <DialogDescription>Select users to assign this task</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4 max-h-[400px] overflow-y-auto">
            {users.map((user) => (
              <div key={user.id} className="flex items-center space-x-3 p-2 hover:bg-accent rounded">
                <input
                  type="checkbox"
                  checked={selectedUsers.includes(user.id)}
                  onChange={(e) => {
                    if (e.target.checked) {
                      setSelectedUsers([...selectedUsers, user.id]);
                    } else {
                      setSelectedUsers(selectedUsers.filter(id => id !== user.id));
                    }
                  }}
                  className="h-4 w-4"
                />
                <div className="flex-1">
                  <p className="font-medium">{user.full_name}</p>
                  <div className="flex items-center space-x-2">
                    <p className="text-sm text-muted-foreground">{user.email}</p>
                    <Badge variant="outline" className="text-xs">{user.role_key}</Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAssignTask} disabled={selectedUsers.length === 0}>
              Assign to {selectedUsers.length} user(s)
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Reject Task Dialog */}
      <Dialog open={rejectDialogOpen} onOpenChange={setRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Task Assignment</DialogTitle>
            <DialogDescription>Please provide a reason for rejection</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="rejection-reason">Rejection Reason *</Label>
              <Textarea
                id="rejection-reason"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                placeholder="Enter reason for rejecting this task assignment..."
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setRejectDialogOpen(false);
              setRejectingAssignment(null);
              setRejectionReason('');
            }}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleRejectAssignment}
              disabled={!rejectionReason.trim()}
            >
              <ThumbsDown className="h-4 w-4 mr-1" />
              Reject Assignment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Unassign Task Dialog */}
      <Dialog open={unassignDialogOpen} onOpenChange={setUnassignDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Unassign Task from Users</DialogTitle>
            <DialogDescription>Remove task assignments from specific users</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4 max-h-[400px] overflow-y-auto">
            {selectedTaskForUnassign && assignments
              .filter(a => a.task_id === selectedTaskForUnassign)
              .map((assignment) => (
                <div key={assignment.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-accent">
                  <div className="flex-1">
                    <p className="font-medium">{assignment.profiles?.full_name}</p>
                    <div className="flex items-center space-x-2">
                      <p className="text-sm text-muted-foreground">{assignment.profiles?.email}</p>
                      <Badge variant="outline" className="text-xs">{assignment.profiles?.role_key}</Badge>
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <Badge variant={assignment.status === 'completed' ? 'default' : 'secondary'} className="text-xs">
                        {assignment.status}
                      </Badge>
                      {assignment.approval_status && (
                        <Badge variant="outline" className="text-xs">
                          {assignment.approval_status}
                        </Badge>
                      )}
                    </div>
                  </div>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Remove Assignment</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to remove this task assignment from {assignment.profiles?.full_name}?
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleUnassignTask(assignment.id)}
                          className="bg-red-600 hover:bg-red-700"
                        >
                          Remove
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              ))}
            {selectedTaskForUnassign && assignments.filter(a => a.task_id === selectedTaskForUnassign).length === 0 && (
              <p className="text-center text-muted-foreground py-8">No users assigned to this task</p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setUnassignDialogOpen(false);
              setSelectedTaskForUnassign(null);
            }}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Predefined Task Modal */}
      <Dialog open={showPredefinedModal} onOpenChange={setShowPredefinedModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPredefined ? 'Edit' : 'Add'} Predefined Task</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Task Name</Label>
              <Input
                placeholder="Enter task name"
                defaultValue={editingPredefined?.name || ''}
                id="predefined-task-name"
              />
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Select defaultValue={editingPredefined?.category || 'UNIVERSAL TASKS'} onValueChange={(val) => {
                (document.getElementById('predefined-category') as any).value = val;
              }}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UNIVERSAL TASKS">UNIVERSAL TASKS</SelectItem>
                  <SelectItem value="DRIVER TASKS">DRIVER TASKS</SelectItem>
                  <SelectItem value="SHIPPER TASKS">SHIPPER TASKS</SelectItem>
                  <SelectItem value="CARRIER TASKS">CARRIER TASKS</SelectItem>
                  <SelectItem value="VENDOR TASKS">VENDOR TASKS</SelectItem>
                  <SelectItem value="ADMIN (LIMITED) TASKS">ADMIN (LIMITED) TASKS</SelectItem>
                  <SelectItem value="ADMIN (SUPER) TASKS">ADMIN (SUPER) TASKS</SelectItem>
                </SelectContent>
              </Select>
              <input type="hidden" id="predefined-category" defaultValue={editingPredefined?.category || 'UNIVERSAL TASKS'} />
            </div>

            <div className="space-y-2">
              <Label>Assigned Roles</Label>
              <div className="grid grid-cols-2 gap-2">
                {['driver', 'shipper', 'carrier', 'vendor', 'broker', 'admin', 'super_admin'].map((role) => (
                  <label key={role} className="flex items-center space-x-2">
                    <Checkbox
                      id={`predefined-role-${role}`}
                      defaultChecked={editingPredefined?.assignedRoles?.includes(role)}
                    />
                    <span className="text-sm capitalize">{role.replace('_', ' ')}</span>
                  </label>
                ))}
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPredefinedModal(false)}>
              Cancel
            </Button>
            <Button onClick={() => {
              const name = (document.getElementById('predefined-task-name') as HTMLInputElement).value;
              const category = (document.getElementById('predefined-category') as HTMLInputElement).value;
              const assignedRoles = ['driver', 'shipper', 'carrier', 'vendor', 'broker', 'admin', 'super_admin']
                .filter(role => (document.getElementById(`predefined-role-${role}`) as HTMLInputElement).checked);

              if (!name.trim()) {
                toast({
                  title: "Error",
                  description: "Task name is required",
                  variant: "destructive",
                });
                return;
              }

              if (assignedRoles.length === 0) {
                toast({
                  title: "Error",
                  description: "Select at least one role",
                  variant: "destructive",
                });
                return;
              }

              if (editingPredefined) {
                setPredefinedTasks(predefinedTasks.map(t => 
                  t.id === editingPredefined.id 
                    ? { ...t, name, category, assignedRoles }
                    : t
                ));
                toast({
                  title: "Task updated",
                  description: "Predefined task has been updated successfully.",
                });
              } else {
                const newTask = {
                  id: `p${Date.now()}`,
                  category,
                  name,
                  assignedRoles,
                };
                setPredefinedTasks([...predefinedTasks, newTask]);
                toast({
                  title: "Task added",
                  description: "New predefined task has been added successfully.",
                });
              }

              setShowPredefinedModal(false);
              setEditingPredefined(null);
            }}>
              {editingPredefined ? 'Update' : 'Add'} Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Task Form Dialog */}
      <Dialog open={viewFormDialogOpen} onOpenChange={setViewFormDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Eye className="h-5 w-5" />
              <span>View Task Form: {viewingTask?.name}</span>
            </DialogTitle>
            <DialogDescription>
              Complete task details and configuration
            </DialogDescription>
          </DialogHeader>

          {viewingTask && (
            <div className="space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label className="text-muted-foreground">Task Name</Label>
                    <p className="font-medium">{viewingTask.name}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Description</Label>
                    <p className="text-sm">{viewingTask.description || 'No description provided'}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Category</Label>
                      <Badge variant="outline" className="mt-1">{viewingTask.category}</Badge>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Priority</Label>
                      {viewingTask.priority && getPriorityBadge(viewingTask.priority)}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Required</Label>
                      <p className="text-sm">{viewingTask.required ? 'Yes' : 'No'}</p>
                    </div>
                    {viewingTask.due_date && (
                      <div>
                        <Label className="text-muted-foreground">Due Date</Label>
                        <p className="text-sm">{format(new Date(viewingTask.due_date), 'MMM dd, yyyy')}</p>
                      </div>
                    )}
                  </div>
                  {viewingTask.assigned_roles && viewingTask.assigned_roles.length > 0 && (
                    <div>
                      <Label className="text-muted-foreground">Assigned Roles</Label>
                      <div className="flex flex-wrap gap-2 mt-1">
                        {viewingTask.assigned_roles.map((role) => (
                          <Badge key={role} variant="secondary">{role}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Custom Link */}
              {viewingTask.custom_link && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <LinkIcon className="h-4 w-4" />
                      Resource Link
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <a 
                      href={viewingTask.custom_link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline break-all"
                    >
                      {viewingTask.custom_link}
                    </a>
                  </CardContent>
                </Card>
              )}

              {/* Completion Steps */}
              {viewingTask.redirect_path && Array.isArray(viewingTask.redirect_path) && viewingTask.redirect_path.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ArrowRight className="h-4 w-4" />
                      Task Completion Path ({viewingTask.redirect_path.length} Steps)
                    </CardTitle>
                    <CardDescription>
                      User will follow these steps to complete the task
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {viewingTask.redirect_path.map((step: any, index: number) => (
                        <Card key={index} className="bg-muted/50">
                          <CardContent className="p-4">
                            <div className="flex items-start gap-3">
                              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                                {step.step_number || index + 1}
                              </div>
                              <div className="flex-1 space-y-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-semibold">{step.step_name}</h4>
                                  {step.is_optional && (
                                    <Badge variant="outline" className="text-xs">Optional</Badge>
                                  )}
                                </div>
                                {step.step_description && (
                                  <p className="text-sm text-muted-foreground">{step.step_description}</p>
                                )}
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-1 text-xs text-primary">
                                    <ArrowRight className="h-3 w-3" />
                                    <code className="bg-muted px-2 py-1 rounded">{step.path}</code>
                                  </div>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => {
                                      if (step.path.startsWith('http')) {
                                        try {
                                          window.open(step.path, '_blank');
                                          toast({
                                            title: "External Link Opened",
                                            description: "Check your new browser tab",
                                          });
                                        } catch (error) {
                                          toast({
                                            title: "Error",
                                            description: "Failed to open external link",
                                            variant: "destructive"
                                          });
                                        }
                                      } else {
                                        toast({
                                          title: "Internal Navigation",
                                          description: `Would navigate to: ${step.path}`,
                                        });
                                      }
                                    }}
                                    className="gap-1"
                                  >
                                    <ArrowRight className="h-3 w-3" />
                                    Test
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Metadata */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Metadata</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created:</span>
                    <span>{format(new Date(viewingTask.created_at), 'MMM dd, yyyy HH:mm')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Updated:</span>
                    <span>{format(new Date(viewingTask.updated_at), 'MMM dd, yyyy HH:mm')}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setViewFormDialogOpen(false)}>
              Close
            </Button>
            <Button onClick={() => {
              if (viewingTask) {
                setViewFormDialogOpen(false);
                startEdit(viewingTask);
              }
            }}>
              <Edit2 className="h-4 w-4 mr-2" />
              Edit Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Bulk Use as Template Dialog - Predefined Tasks */}
      <Dialog open={bulkTemplateDialogOpen} onOpenChange={setBulkTemplateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Use as Template</DialogTitle>
            <DialogDescription>
              Select roles to apply these {selectedPredefined.length} task(s) as templates
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Roles</label>
              {['driver', 'carrier', 'shipper', 'broker', 'vendor', 'vendor_merchant', 'admin'].map((role) => (
                <div key={role} className="flex items-center space-x-2">
                  <Checkbox
                    id={`bulk-role-${role}`}
                    checked={bulkTemplateRoles.includes(role)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setBulkTemplateRoles([...bulkTemplateRoles, role]);
                      } else {
                        setBulkTemplateRoles(bulkTemplateRoles.filter(r => r !== role));
                      }
                    }}
                  />
                  <label
                    htmlFor={`bulk-role-${role}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                  >
                    {role.replace('_', ' ')}
                  </label>
                </div>
              ))}
            </div>
            {bulkTemplateRoles.length > 0 && (
              <div className="text-sm text-muted-foreground">
                This will create {selectedPredefined.length * bulkTemplateRoles.length} template(s)
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setBulkTemplateDialogOpen(false);
                  setBulkTemplateRoles([]);
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleBulkUseAsTemplate}
                disabled={bulkTemplateRoles.length === 0}
              >
                Apply Templates
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk Use as Template Dialog - Custom Tasks */}
      <Dialog open={bulkCustomTemplateDialogOpen} onOpenChange={setBulkCustomTemplateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Use as Template</DialogTitle>
            <DialogDescription>
              Select roles to apply these {selectedCustom.length} task(s) as templates
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Select Roles</label>
              {['driver', 'carrier', 'shipper', 'broker', 'vendor', 'vendor_merchant', 'admin'].map((role) => (
                <div key={role} className="flex items-center space-x-2">
                  <Checkbox
                    id={`bulk-custom-role-${role}`}
                    checked={bulkCustomTemplateRoles.includes(role)}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setBulkCustomTemplateRoles([...bulkCustomTemplateRoles, role]);
                      } else {
                        setBulkCustomTemplateRoles(bulkCustomTemplateRoles.filter(r => r !== role));
                      }
                    }}
                  />
                  <label
                    htmlFor={`bulk-custom-role-${role}`}
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 capitalize"
                  >
                    {role.replace('_', ' ')}
                  </label>
                </div>
              ))}
            </div>
            {bulkCustomTemplateRoles.length > 0 && (
              <div className="text-sm text-muted-foreground">
                This will create {selectedCustom.length * bulkCustomTemplateRoles.length} template(s)
              </div>
            )}
            <div className="flex justify-end gap-2">
              <Button
                variant="outline"
                onClick={() => {
                  setBulkCustomTemplateDialogOpen(false);
                  setBulkCustomTemplateRoles([]);
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleBulkCustomUseAsTemplate}
                disabled={bulkCustomTemplateRoles.length === 0}
              >
                Apply Templates
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk Create Tasks Dialog */}
      <Dialog open={bulkCreateDialogOpen} onOpenChange={setBulkCreateDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Bulk Tasks</DialogTitle>
            <DialogDescription>
              Select tasks to create from the predefined list
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              {tasksToCreate.length} task(s) selected
            </div>
            
            {/* Group by category */}
            {['UNIVERSAL TASKS', 'DRIVER TASKS', 'SHIPPER TASKS', 'CARRIER TASKS', 'VENDOR TASKS', 'VENDOR/MERCHANT TASKS', 'ADMIN (LIMITED) TASKS', 'ADMIN (SUPER) TASKS'].map((category) => {
              const categoryTasks = predefinedTasks.filter(t => 
                t.category === category && tasksToCreate.includes(t.id)
              );
              if (categoryTasks.length === 0) return null;

              return (
                <div key={category} className="space-y-2">
                  <h4 className="font-semibold text-sm">{category}</h4>
                  <div className="space-y-1 pl-4">
                    {categoryTasks.map((task) => (
                      <div key={task.id} className="flex items-center gap-2 p-2 bg-muted/50 rounded">
                        <Checkbox
                          checked={true}
                          onCheckedChange={(checked) => {
                            if (!checked) {
                              setTasksToCreate(tasksToCreate.filter(id => id !== task.id));
                            }
                          }}
                        />
                        <div className="flex-1">
                          <p className="text-sm font-medium">{task.name}</p>
                          <div className="flex gap-1 mt-1">
                            {task.assignedRoles.map((role: string) => (
                              <Badge key={role} variant="outline" className="text-xs">
                                {role}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}

            {tasksToCreate.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No tasks selected
              </p>
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setBulkCreateDialogOpen(false);
                  setTasksToCreate([]);
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleBulkCreateTasks}
                disabled={tasksToCreate.length === 0}
              >
                <Plus className="h-4 w-4 mr-2" />
                Create {tasksToCreate.length} Task(s)
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bulk Assign Tasks Dialog */}
      <Dialog open={bulkAssignDialogOpen} onOpenChange={setBulkAssignDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Assign Tasks to Users</DialogTitle>
            <DialogDescription>
              Select users to assign {selectedTasks.length} task(s) to
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Search Users</Label>
              <Input
                placeholder="Search by name, email, or account number..."
                value={bulkAssignSearch}
                onChange={(e) => setBulkAssignSearch(e.target.value)}
              />
            </div>

            <div className="text-sm text-muted-foreground">
              {bulkAssignUsers.length} user(s) selected
            </div>

            <div className="border rounded-lg max-h-96 overflow-y-auto">
              {users
                .filter(u => u.role_key !== 'super_admin')
                .filter(u => {
                  const searchLower = bulkAssignSearch.toLowerCase();
                  return (
                    u.full_name?.toLowerCase().includes(searchLower) ||
                    u.email?.toLowerCase().includes(searchLower) ||
                    u.account_number?.toLowerCase().includes(searchLower)
                  );
                })
                .map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center gap-3 p-3 border-b last:border-b-0 hover:bg-muted/50"
                  >
                    <Checkbox
                      checked={bulkAssignUsers.includes(user.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setBulkAssignUsers([...bulkAssignUsers, user.id]);
                        } else {
                          setBulkAssignUsers(bulkAssignUsers.filter(id => id !== user.id));
                        }
                      }}
                    />
                    <div className="flex-1">
                      <p className="font-medium">{user.full_name}</p>
                      <div className="flex gap-2 items-center text-sm text-muted-foreground">
                        <span>{user.email}</span>
                        {user.account_number && (
                          <>
                            <span>•</span>
                            <span>#{user.account_number}</span>
                          </>
                        )}
                      </div>
                    </div>
                    <Badge variant="outline">{user.role_key}</Badge>
                    {!user.is_approved && (
                      <Badge variant="secondary">Not Approved</Badge>
                    )}
                  </div>
                ))}
            </div>

            {bulkAssignUsers.length > 0 && (
              <div className="text-sm text-muted-foreground bg-muted p-3 rounded">
                This will create {selectedTasks.length * bulkAssignUsers.length} assignment(s)
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setBulkAssignDialogOpen(false);
                  setBulkAssignUsers([]);
                  setBulkAssignSearch('');
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleBulkAssignTasks}
                disabled={bulkAssignUsers.length === 0}
              >
                <UserPlus className="h-4 w-4 mr-2" />
                Assign to {bulkAssignUsers.length} User(s)
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}