import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { 
  FileText, 
  Download, 
  CheckCircle, 
  XCircle, 
  Clock,
  Eye,
  FileUp,
  Calendar,
  User
} from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';

interface TaskSubmission {
  id: string;
  task_id: string;
  task_name: string;
  step_number: number;
  submission_data: Record<string, any>;
  status: string;
  created_at: string;
  updated_at: string;
  reviewed_at?: string;
  reviewed_by?: string;
  admin_notes?: string;
}

interface GroupedTask {
  task_id: string;
  task_name: string;
  steps: TaskSubmission[];
  overall_status: 'pending' | 'approved' | 'rejected' | 'mixed';
}

interface TaskSubmissionsViewerProps {
  userId: string;
  userEmail?: string;
  onUpdate?: () => void;
}

export function TaskSubmissionsViewer({ userId, userEmail, onUpdate }: TaskSubmissionsViewerProps) {
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [groupedTasks, setGroupedTasks] = useState<GroupedTask[]>([]);
  const [loading, setLoading] = useState(true);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [adminNotes, setAdminNotes] = useState<Record<string, string>>({});

  useEffect(() => {
    if (userId) {
      fetchSubmissions();
    }
  }, [userId]);

  const fetchSubmissions = async () => {
    try {
      setLoading(true);
      
      // First get task step submissions
      const { data: submissionsData, error: submissionsError } = await supabase
        .from('task_step_submissions')
        .select('*')
        .eq('user_id', userId)
        .order('submitted_at', { ascending: false });

      if (submissionsError) {
        console.error('Error fetching submissions:', submissionsError);
        throw submissionsError;
      }

      // If no submissions, return empty array
      if (!submissionsData || submissionsData.length === 0) {
        setSubmissions([]);
        return;
      }

      // Get unique task IDs
      const taskIds = [...new Set(submissionsData.map(sub => sub.task_id))];
      
      // Fetch task details only if we have task IDs
      let tasksMap = new Map();
      if (taskIds.length > 0) {
        const { data: tasksData, error: tasksError } = await supabase
          .from('custom_tasks')
          .select('id, name, category')
          .in('id', taskIds);

        if (tasksError) {
          console.error('Error fetching tasks:', tasksError);
          throw tasksError;
        }

        tasksMap = new Map(tasksData?.map(task => [task.id, task]) || []);
      }

      const formatted = submissionsData.map((sub: any) => {
        const task = tasksMap.get(sub.task_id);
        return {
          id: sub.id,
          task_id: sub.task_id,
          task_name: task?.name || 'Unknown Task',
          step_number: sub.step_number,
          submission_data: sub.submission_data || {},
          status: sub.status || 'submitted',
          created_at: sub.submitted_at || sub.updated_at,
          updated_at: sub.updated_at,
          reviewed_at: sub.reviewed_at,
          reviewed_by: sub.reviewed_by,
          admin_notes: sub.admin_notes
        };
      });

      setSubmissions(formatted);
      
      // Group submissions by task
      const grouped = formatted.reduce((acc: GroupedTask[], submission) => {
        const existingTask = acc.find(t => t.task_id === submission.task_id);
        
        if (existingTask) {
          existingTask.steps.push(submission);
        } else {
          acc.push({
            task_id: submission.task_id,
            task_name: submission.task_name,
            steps: [submission],
            overall_status: 'pending'
          });
        }
        
        return acc;
      }, []);
      
      // Determine overall status for each task
      grouped.forEach(task => {
        const statuses = task.steps.map(s => s.status);
        if (statuses.every(s => s === 'approved')) {
          task.overall_status = 'approved';
        } else if (statuses.some(s => s === 'rejected')) {
          task.overall_status = 'rejected';
        } else if (statuses.every(s => s === 'submitted' || s === 'pending')) {
          task.overall_status = 'pending';
        } else {
          task.overall_status = 'mixed';
        }
        
        // Sort steps by step_number
        task.steps.sort((a, b) => a.step_number - b.step_number);
      });
      
      setGroupedTasks(grouped);
    } catch (error: any) {
      console.error('Error fetching submissions:', error);
      toast.error('Failed to load task submissions: ' + (error.message || 'Unknown error'));
      setSubmissions([]);
      setGroupedTasks([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadFile = async (fileRef: string) => {
    try {
      // Known buckets in this project. Note: 'license' and 'documents' are typically folders, not buckets.
      const realBuckets = ['task-submissions', 'driver', 'profiles', 'pickup-photos', 'user-documents', 'carrier', 'driver-documents', 'user-uploads'];

      // 1) Normalize an initial bucket + path
      let initialBucket: string | null = null;
      let path = fileRef;

      if (fileRef.startsWith('http')) {
        const match = fileRef.match(/\/storage\/v1\/object\/public\/([^/]+)\/(.+)/);
        if (match) {
          initialBucket = match[1];
          path = match[2];
        }
      }

      // First segment of the reference (may be a folder or a bucket)
      const firstSlash = fileRef.indexOf('/');
      const firstSegment = firstSlash > -1 ? fileRef.slice(0, firstSlash) : fileRef;

      if (!initialBucket) {
        if (realBuckets.includes(firstSegment)) {
          initialBucket = firstSegment;
          path = fileRef.slice(firstSegment.length + 1);
        } else {
          // Default to task-submissions if no explicit bucket detected
          initialBucket = 'task-submissions';
          path = fileRef;
        }
      }

      // 2) Build candidate buckets (try detected bucket, then known buckets, then the first segment if custom bucket exists)
      const candidateBuckets = Array.from(new Set([
        initialBucket,
        ...realBuckets,
        ...(firstSegment && !realBuckets.includes(firstSegment) ? [firstSegment] : [])
      ].filter(Boolean))) as string[];

      // 3) Build candidate paths (try variations)
      const candidatePaths = new Set<string>();
      candidatePaths.add(path);

      // If path accidentally includes a bucket prefix, try without it
      for (const b of realBuckets) {
        if (path.startsWith(`${b}/`)) candidatePaths.add(path.replace(new RegExp(`^${b}/`), ''));
      }

      // Swap common folder names used by older forms
      if (path.startsWith('license/')) candidatePaths.add(path.replace(/^license\//, 'documents/'));
      if (path.startsWith('documents/')) candidatePaths.add(path.replace(/^documents\//, 'license/'));

      // Also consider that the first segment may be a folder, not a bucket
      if (firstSegment && path.startsWith(firstSegment + '/')) {
        candidatePaths.add(path.slice(firstSegment.length + 1));
      }

      // Some buckets (like `driver`) historically kept an extra leading folder with same name
      if (!path.startsWith('driver/')) candidatePaths.add(`driver/${path}`);
      if (path.startsWith('driver/')) candidatePaths.add(path.replace(/^driver\//, ''));

      // 4) Try all combinations until one succeeds
      console.info('[KYC] File download attempt', {
        original: fileRef,
        initialBucket,
        candidateBuckets,
        candidatePaths: Array.from(candidatePaths),
      });

      for (const b of candidateBuckets) {
        for (const p of candidatePaths) {
          try {
            console.info('[KYC] Trying', { bucket: b, path: p });
            const { data, error } = await supabase.storage.from(b).createSignedUrl(p, 3600);
            if (!error && data?.signedUrl) {
              window.open(data.signedUrl, '_blank');
              return;
            }
          } catch (e) {
            // continue trying others
          }
        }
      }

      throw new Error('Object not found in any bucket/path combination');
    } catch (error: any) {
      console.error('Error downloading file:', error);
      toast.error(`Failed to download file: ${error.message || 'Unknown error'}`);
    }
  };

  const handleApproveTask = async (taskId: string) => {
    try {
      setProcessingId(taskId);

      // Update all task step submissions for this task
      const { error: submissionError } = await supabase
        .from('task_step_submissions')
        .update({
          status: 'approved',
          reviewed_at: new Date().toISOString(),
          admin_notes: adminNotes[taskId] || null
        })
        .eq('user_id', userId)
        .eq('task_id', taskId);

      if (submissionError) throw submissionError;

      // Update task assignment
      const { error: assignmentError } = await supabase
        .from('task_assignments')
        .update({
          approval_status: 'approved',
          approved_at: new Date().toISOString()
        })
        .eq('task_id', taskId)
        .eq('user_id', userId);

      if (assignmentError) throw assignmentError;

      toast.success('Task approved successfully! All steps have been approved.');

      await fetchSubmissions();
      if (onUpdate) onUpdate();
    } catch (error: any) {
      console.error('Error approving task:', error);
      toast.error('Failed to approve task');
    } finally {
      setProcessingId(null);
    }
  };

  const handleRejectTask = async (taskId: string) => {
    try {
      setProcessingId(taskId);

      // Update all task step submissions for this task
      const { error } = await supabase
        .from('task_step_submissions')
        .update({
          status: 'rejected',
          reviewed_at: new Date().toISOString(),
          admin_notes: adminNotes[taskId] || 'Task rejected'
        })
        .eq('user_id', userId)
        .eq('task_id', taskId);

      if (error) throw error;

      // Update task assignment
      const { error: assignmentError } = await supabase
        .from('task_assignments')
        .update({
          approval_status: 'rejected',
          approved_at: new Date().toISOString()
        })
        .eq('task_id', taskId)
        .eq('user_id', userId);

      if (assignmentError) throw assignmentError;

      toast.success('Task rejected');
      await fetchSubmissions();
      if (onUpdate) onUpdate();
    } catch (error: any) {
      console.error('Error rejecting task:', error);
      toast.error('Failed to reject task');
    } finally {
      setProcessingId(null);
    }
  };

  const renderFieldValue = (key: string, value: any, submissionId: string) => {
    const looksLikeFileString = (v: string) => {
      const lower = v.toLowerCase();
      const hasExt = /\.(pdf|png|jpg|jpeg|webp|gif|heic|doc|docx|xls|xlsx|csv|txt)$/i.test(lower);
      return (
        lower.includes('/storage/v1/object/public/') ||
        hasExt ||
        lower.startsWith('task-submissions/') ||
        lower.startsWith('documents/') ||
        lower.startsWith('driver/') ||
        lower.startsWith('profiles/') ||
        key.toLowerCase().includes('file') ||
        key.toLowerCase().includes('upload') ||
        key.toLowerCase().includes('document')
      );
    };

    const extractFileRef = (input: any): string | null => {
      if (!input) return null;
      if (typeof input === 'string') return input;
      if (typeof input === 'object') {
        const candidates = ['path', 'file', 'file_path', 'url', 'publicUrl'];
        for (const k of candidates) {
          if (typeof input[k] === 'string' && input[k]) return input[k];
        }
      }
      return null;
    };

    // String that looks like a file
    if (typeof value === 'string' && looksLikeFileString(value)) {
      return (
        <div className="flex items-center gap-2">
          <FileUp className="h-4 w-4 text-primary" />
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleDownloadFile(value)}
            className="text-xs"
          >
            <Download className="h-3 w-3 mr-1" />
            View File
          </Button>
        </div>
      );
    }

    // Handle arrays - show file buttons when applicable
    if (Array.isArray(value)) {
      return (
        <div className="space-y-1">
          {value.map((item, idx) => {
            const ref = extractFileRef(item);
            const isFile = typeof item === 'string' ? looksLikeFileString(item) : !!ref;
            if (isFile) {
              const toOpen = typeof item === 'string' ? item : (ref as string);
              return (
                <div key={idx} className="flex items-center gap-2">
                  <FileUp className="h-4 w-4 text-primary" />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDownloadFile(toOpen)}
                    className="text-xs"
                  >
                    <Download className="h-3 w-3 mr-1" />
                    View File
                  </Button>
                </div>
              );
            }
            return (
              <Badge key={idx} variant="outline" className="mr-1">
                {typeof item === 'object' ? JSON.stringify(item) : String(item)}
              </Badge>
            );
          })}
        </div>
      );
    }

    // Handle objects - try to extract a file reference
    if (typeof value === 'object' && value !== null) {
      const ref = extractFileRef(value);
      if (ref && looksLikeFileString(ref)) {
        return (
          <div className="flex items-center gap-2">
            <FileUp className="h-4 w-4 text-primary" />
            <Button
              variant="outline"
              size="sm"
              onClick={() => handleDownloadFile(ref)}
              className="text-xs"
            >
              <Download className="h-3 w-3 mr-1" />
              View File
            </Button>
          </div>
        );
      }

      return (
        <pre className="text-xs bg-muted p-2 rounded overflow-auto">
          {JSON.stringify(value, null, 2)}
        </pre>
      );
    }

    // Default
    return <span className="text-sm">{String(value)}</span>;
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      case 'submitted':
      case 'pending':
        return <Badge variant="secondary"><Clock className="h-3 w-3 mr-1" />Pending Review</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (groupedTasks.length === 0) {
    return (
      <Card>
        <CardContent className="py-8">
          <Alert>
            <FileText className="h-4 w-4" />
            <AlertDescription>
              No task submissions found for this user.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-semibold">Task Submissions</h3>
          <p className="text-sm text-muted-foreground">
            Review and approve user-submitted tasks
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchSubmissions}>
          <Eye className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {groupedTasks.map((task) => (
        <Card key={task.task_id}>
          <CardHeader>
            <div className="flex items-start justify-between">
              <div className="space-y-1">
                <CardTitle className="text-base flex items-center gap-2">
                  <FileText className="h-4 w-4" />
                  {task.task_name}
                </CardTitle>
                <CardDescription className="flex items-center gap-2 text-xs">
                  <Calendar className="h-3 w-3" />
                  {task.steps.length} step{task.steps.length !== 1 ? 's' : ''} submitted
                </CardDescription>
              </div>
              {getStatusBadge(task.overall_status)}
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* All Steps */}
            {task.steps.map((step, idx) => (
              <div key={step.id}>
                {idx > 0 && <Separator className="my-4" />}
                <div className="space-y-3">
                  <h4 className="text-sm font-semibold">Step {step.step_number}:</h4>
                  <div className="grid gap-3 pl-4">
                    {Object.entries(step.submission_data).map(([key, value]) => (
                      <div key={key} className="grid grid-cols-3 gap-2 items-start">
                        <span className="text-sm font-medium text-muted-foreground capitalize">
                          {key.replace(/_/g, ' ')}:
                        </span>
                        <div className="col-span-2">
                          {renderFieldValue(key, value, step.id)}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {/* Show previous admin notes if any */}
                  {step.admin_notes && (
                    <Alert className="ml-4">
                      <User className="h-4 w-4" />
                      <AlertDescription>
                        <strong>Step {step.step_number} Notes:</strong> {step.admin_notes}
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </div>
            ))}

            {/* Admin Notes for entire task */}
            {task.overall_status === 'pending' && (
              <>
                <Separator />
                <div className="space-y-2">
                  <label className="text-sm font-medium">Admin Notes (Optional)</label>
                  <Textarea
                    placeholder="Add notes about this task..."
                    value={adminNotes[task.task_id] || ''}
                    onChange={(e) => setAdminNotes({ ...adminNotes, [task.task_id]: e.target.value })}
                    rows={2}
                  />
                </div>
              </>
            )}

            {/* Action Buttons - Only for pending tasks */}
            {task.overall_status === 'pending' && (
              <>
                <Separator />
                <div className="flex gap-2 justify-end">
                  <Button
                    variant="outline"
                    onClick={() => handleRejectTask(task.task_id)}
                    disabled={processingId === task.task_id}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject Task
                  </Button>
                  <Button
                    onClick={() => handleApproveTask(task.task_id)}
                    disabled={processingId === task.task_id}
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Approve Task
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
