import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { MapPin, User, Navigation, Zap, TrendingUp, Loader2 } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DispatchMap, DispatchMapRef } from '@/components/maps/DispatchMap';
import { toast } from 'sonner';
import { calculateDistance } from '@/lib/locationUtils';

interface DispatchAssignmentProps {
  filters: any;
}

export const DispatchAssignment = ({ filters }: DispatchAssignmentProps) => {
  const [selectedJob, setSelectedJob] = useState<string | null>(null);
  const [selectedDriver, setSelectedDriver] = useState<string | null>(null);
  const [isAutoAssigning, setIsAutoAssigning] = useState(false);
  const mapRef = React.useRef<DispatchMapRef>(null);
  const queryClient = useQueryClient();

  // Fetch unassigned jobs
  const { data: allUnassignedJobs } = useQuery({
    queryKey: ['unassigned-jobs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('status', 'pending')
        .is('shipper_id', null)
        .limit(50);
      
      if (error) throw error;
      return data || [];
    }
  });

  // Filter unassigned jobs based on search
  const unassignedJobs = React.useMemo(() => {
    if (!allUnassignedJobs) return [];
    
    const searchLower = filters.searchQuery.toLowerCase().trim();
    if (!searchLower) return allUnassignedJobs.slice(0, 10);

    const filtered = allUnassignedJobs.filter(job => {
      if (job.id.toLowerCase().includes(searchLower)) return true;
      if (job.title?.toLowerCase().includes(searchLower)) return true;
      
      const pickupLoc = job.pickup_location as any;
      if (pickupLoc?.address?.toLowerCase().includes(searchLower)) return true;
      if (pickupLoc?.city?.toLowerCase().includes(searchLower)) return true;
      
      const deliveryLoc = job.delivery_location as any;
      if (deliveryLoc?.address?.toLowerCase().includes(searchLower)) return true;
      if (deliveryLoc?.city?.toLowerCase().includes(searchLower)) return true;
      
      return false;
    });
    
    return filtered.slice(0, 10);
  }, [allUnassignedJobs, filters.searchQuery]);

  // Fetch available drivers with their current job assignments and status
  const { data: availableDrivers } = useQuery({
    queryKey: ['available-drivers'],
    queryFn: async () => {
      // First get drivers
      const { data: drivers, error: driversError } = await supabase
        .from('profiles')
        .select('*')
        .eq('role_key', 'driver')
        .eq('is_active', true);
      
      if (driversError) throw driversError;
      if (!drivers) return [];

      // Get driver statuses
      const { data: statuses } = await supabase
        .from('driver_status')
        .select('*')
        .in('driver_id', drivers.map(d => d.id));

      // Get active assignments for all drivers
      const { data: assignments } = await supabase
        .from('job_assignments')
        .select('driver_id, status, id')
        .in('driver_id', drivers.map(d => d.id))
        .in('status', ['assigned', 'in_progress', 'picked_up']);
      
      // Combine data
      return drivers.map(driver => {
        const driverStatus = statuses?.find(s => s.driver_id === driver.id);
        const driverAssignments = assignments?.filter(a => a.driver_id === driver.id) || [];
        
        return {
          ...driver,
          activeJobCount: driverAssignments.length,
          isOnline: driverStatus?.is_online || false,
          lastLocation: driverStatus?.last_location || null
        };
      });
    },
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  // Real load balance data
  const loadBalanceData = React.useMemo(() => {
    if (!availableDrivers) return [];
    
    return availableDrivers
      .sort((a, b) => b.activeJobCount - a.activeJobCount)
      .slice(0, 10)
      .map(driver => ({
        driver: driver.full_name || driver.email?.split('@')[0] || 'Unknown',
        jobs: driver.activeJobCount
      }));
  }, [availableDrivers]);

  // Manual assignment mutation
  const manualAssignMutation = useMutation({
    mutationFn: async ({ jobId, driverId }: { jobId: string; driverId: string }) => {
      // Create job assignment
      const { error: assignError } = await supabase
        .from('job_assignments')
        .insert({
          job_id: jobId,
          driver_id: driverId,
          status: 'assigned'
        });
      
      if (assignError) throw assignError;

      // Update job status
      const { error: jobError } = await supabase
        .from('jobs')
        .update({ 
          status: 'assigned',
          assigned_driver_id: driverId 
        })
        .eq('id', jobId);
      
      if (jobError) throw jobError;

      // Create notification for driver
      const job = unassignedJobs.find(j => j.id === jobId);
      if (job) {
        await supabase.from('notifications').insert({
          user_id: driverId,
          title: 'New Job Assigned',
          message: `You have been assigned to job: ${job.title}\nPickup: ${(job.pickup_location as any)?.address || 'N/A'}\nDelivery: ${(job.delivery_location as any)?.address || 'N/A'}`,
          type: 'system',
          link: '/driver-dashboard/my-jobs',
          metadata: {
            job_id: jobId,
            status: 'assigned'
          }
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['available-drivers'] });
      toast.success('Job assigned successfully');
      setSelectedJob(null);
      setSelectedDriver(null);
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to assign job');
    }
  });

  // Calculate distance between driver and job
  const calculateDriverDistance = (driver: any, job: any) => {
    if (!driver.lastLocation || !job.pickup_location) return null;
    
    const driverCoords = {
      lat: driver.lastLocation.latitude || driver.lastLocation.lat,
      lng: driver.lastLocation.longitude || driver.lastLocation.lng
    };
    
    const jobCoords = (job.pickup_location as any).coordinates;
    if (!jobCoords) return null;
    
    const distanceMeters = calculateDistance(driverCoords, {
      lat: jobCoords.lat || jobCoords.latitude,
      lng: jobCoords.lng || jobCoords.longitude
    });
    
    return (distanceMeters / 1609.34).toFixed(1); // Convert to miles
  };

  // Auto-assign logic
  const handleAutoAssign = async () => {
    if (!unassignedJobs?.length || !availableDrivers?.length) {
      toast.error('No jobs or drivers available');
      return;
    }

    setIsAutoAssigning(true);
    let assigned = 0;
    let failed = 0;

    try {
      // Sort drivers by current load (ascending - least loaded first)
      const sortedDrivers = [...availableDrivers]
        .filter(d => d.isOnline)
        .sort((a, b) => a.activeJobCount - b.activeJobCount);

      if (sortedDrivers.length === 0) {
        toast.error('No online drivers available');
        setIsAutoAssigning(false);
        return;
      }

      // Assign jobs round-robin to balance load
      for (let i = 0; i < unassignedJobs.length; i++) {
        const job = unassignedJobs[i];
        const driver = sortedDrivers[i % sortedDrivers.length];

        try {
          await manualAssignMutation.mutateAsync({
            jobId: job.id,
            driverId: driver.id
          });
          assigned++;
        } catch (error) {
          console.error(`Failed to assign job ${job.id}:`, error);
          failed++;
        }

        // Small delay to avoid overwhelming the database
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      toast.success(`Auto-assigned ${assigned} job(s). ${failed > 0 ? `${failed} failed.` : ''}`);
    } catch (error: any) {
      toast.error(error.message || 'Auto-assign failed');
    } finally {
      setIsAutoAssigning(false);
    }
  };

  const handleManualAssign = () => {
    if (!selectedJob || !selectedDriver) {
      toast.error('Please select both a job and a driver');
      return;
    }
    
    manualAssignMutation.mutate({
      jobId: selectedJob,
      driverId: selectedDriver
    });
  };

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {/* Left Column: Job Queue */}
      <div className="lg:col-span-1 space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Unassigned Jobs
              <Badge variant="destructive">{unassignedJobs?.length || 0}</Badge>
            </CardTitle>
            <CardDescription>
              Jobs waiting for driver assignment
              {filters.searchQuery && ` - Filtered by: "${filters.searchQuery}"`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {!unassignedJobs || unassignedJobs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  {filters.searchQuery ? `No unassigned jobs matching "${filters.searchQuery}"` : 'No unassigned jobs'}
                </div>
              ) : (
                unassignedJobs.map((job) => (
                <div
                  key={job.id}
                  onClick={() => setSelectedJob(job.id)}
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    selectedJob === job.id ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <span className="font-mono text-sm font-semibold">#{job.id.slice(0, 8)}</span>
                    <Badge variant="outline">${job.pay_amount}</Badge>
                  </div>
                  <div className="space-y-1 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-3 w-3 text-green-500" />
                      <span className="truncate">{(job.pickup_location as any)?.address || 'Pickup Location'}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <MapPin className="h-3 w-3 text-red-500" />
                      <span className="truncate">{(job.delivery_location as any)?.address || 'Delivery Location'}</span>
                    </div>
                  </div>
                </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Assignment Tools */}
        <Card>
          <CardHeader>
            <CardTitle>Assignment Tools</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button 
              className="w-full" 
              variant="default"
              onClick={handleAutoAssign}
              disabled={isAutoAssigning || !unassignedJobs?.length || !availableDrivers?.length}
            >
              {isAutoAssigning ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Assigning...
                </>
              ) : (
                <>
                  <Zap className="h-4 w-4 mr-2" />
                  Auto-Assign All ({unassignedJobs?.length || 0})
                </>
              )}
            </Button>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={handleManualAssign}
              disabled={!selectedJob || !selectedDriver || manualAssignMutation.isPending}
            >
              {manualAssignMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Assigning...
                </>
              ) : (
                'Manual Assign Selected'
              )}
            </Button>
            <Separator />
            <div className="text-sm text-muted-foreground">
              <p>Auto-assign considers:</p>
              <ul className="list-disc list-inside mt-2 space-y-1">
                <li>Driver distance</li>
                <li>Driver rating</li>
                <li>Current load</li>
                <li>Availability</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Right Column: Map & Driver List */}
      <div className="lg:col-span-2 space-y-4">
        {/* Map Card with colored header */}
        <Card className="border-primary/20">
          <CardHeader className="bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-primary" />
                  Nearby Available Drivers
                </CardTitle>
                <CardDescription>Real-time driver locations and job sites</CardDescription>
              </div>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => mapRef.current?.centerMap()}
                className="bg-background"
              >
                <Navigation className="h-4 w-4 mr-2" />
                Center Map
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[400px] relative">
              <DispatchMap 
                ref={mapRef}
                unassignedJobs={unassignedJobs}
                availableDrivers={availableDrivers}
                selectedJobId={selectedJob}
                selectedDriverId={selectedDriver}
              />
              <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm border rounded-lg p-2 text-xs space-y-1">
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 bg-red-500 rounded-full"></div>
                  <span>Unassigned Jobs</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-3 w-3 bg-blue-500 rounded-full"></div>
                  <span>Available Drivers</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Driver List */}
        <Card>
          <CardHeader>
            <CardTitle>Available Drivers ({availableDrivers?.length || 0})</CardTitle>
            <CardDescription>Select a driver for manual assignment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3 sm:grid-cols-2">
              {availableDrivers?.map((driver) => (
                <div
                  key={driver.id}
                  onClick={() => setSelectedDriver(driver.id)}
                  className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                    selectedDriver === driver.id ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`${driver.isOnline ? 'bg-green-500/10' : 'bg-gray-500/10'} p-2 rounded-full relative`}>
                      <User className={`h-5 w-5 ${driver.isOnline ? 'text-green-500' : 'text-gray-500'}`} />
                      {driver.isOnline && (
                        <span className="absolute top-0 right-0 h-2 w-2 bg-green-500 rounded-full"></span>
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold">{driver.full_name || 'Unknown Driver'}</p>
                        <Badge variant={driver.isOnline ? 'default' : 'secondary'} className="text-xs">
                          {driver.isOnline ? 'Online' : 'Offline'}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{driver.email}</p>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-sm">
                    <div className="flex items-center gap-1">
                      <Navigation className="h-3 w-3" />
                      <span className="text-muted-foreground">
                        {selectedJob && unassignedJobs.find(j => j.id === selectedJob) 
                          ? calculateDriverDistance(driver, unassignedJobs.find(j => j.id === selectedJob)) 
                            ? `${calculateDriverDistance(driver, unassignedJobs.find(j => j.id === selectedJob))} mi`
                            : 'N/A'
                          : 'Select job'}
                      </span>
                    </div>
                    <Badge variant="outline">{driver.activeJobCount} active</Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Load Balance Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Load Balance</CardTitle>
            <CardDescription>Current job distribution across drivers</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={loadBalanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="driver" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="jobs" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
