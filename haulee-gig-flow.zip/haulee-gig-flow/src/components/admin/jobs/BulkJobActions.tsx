import React, { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Users, AlertTriangle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface BulkJobActionsProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  selectedJobIds: string[];
  onComplete: () => void;
}

export const BulkJobActions = ({ open, onOpenChange, selectedJobIds, onComplete }: BulkJobActionsProps) => {
  const queryClient = useQueryClient();
  const [action, setAction] = useState<string>('');
  const [driverId, setDriverId] = useState<string>('');
  const [statusValue, setStatusValue] = useState<string>('');
  const [messageText, setMessageText] = useState<string>('');

  // Fetch available drivers
  const { data: drivers } = useQuery({
    queryKey: ['drivers-for-bulk'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email')
        .eq('role_key', 'driver')
        .eq('is_active', true)
        .eq('is_approved', true);
      
      if (error) throw error;
      return data || [];
    },
    enabled: open && (action === 'assign' || action === 'reassign'),
  });

  const bulkMutation = useMutation({
    mutationFn: async () => {
      if (!action) throw new Error('Please select an action');

      switch (action) {
        case 'assign':
        case 'reassign':
          if (!driverId) throw new Error('Please select a driver');
          
          // Delete existing assignments if reassigning
          if (action === 'reassign') {
            await supabase
              .from('job_assignments')
              .delete()
              .in('job_id', selectedJobIds);
          }

          // Create new assignments
          const assignments = selectedJobIds.map(jobId => ({
            job_id: jobId,
            driver_id: driverId,
            status: 'planned',
            assigned_at: new Date().toISOString()
          }));

          await supabase.from('job_assignments').insert(assignments);

          // Update jobs table
          await supabase
            .from('jobs')
            .update({ 
              assigned_driver_id: driverId,
              status: 'planned',
              updated_at: new Date().toISOString()
            })
            .in('id', selectedJobIds);
          break;

        case 'update_status':
          if (!statusValue) throw new Error('Please select a status');
          
          const updateData: any = {
            status: statusValue,
            updated_at: new Date().toISOString()
          };

          if (statusValue === 'assigned') updateData.accepted_at = new Date().toISOString();
          if (statusValue === 'in_progress') updateData.started_at = new Date().toISOString();
          if (statusValue === 'delivered') {
            updateData.completed_at = new Date().toISOString();
            updateData.actual_delivery_time = new Date().toISOString();
          }
          if (statusValue === 'completed') updateData.completed_at = new Date().toISOString();
          if (statusValue === 'cancelled') updateData.cancelled_at = new Date().toISOString();

          await supabase
            .from('jobs')
            .update(updateData)
            .in('id', selectedJobIds);
          break;

        case 'cancel':
          await supabase
            .from('jobs')
            .update({
              status: 'cancelled',
              cancelled_at: new Date().toISOString(),
              cancellation_reason: 'Bulk cancellation',
              updated_at: new Date().toISOString()
            })
            .in('id', selectedJobIds);
          break;

        case 'delete':
          // Delete related records first
          await supabase.from('job_assignments').delete().in('job_id', selectedJobIds);
          await supabase.from('route_stops').delete().in('job_id', selectedJobIds);
          await supabase.from('jobs').delete().in('id', selectedJobIds);
          break;

        case 'notify':
          if (!messageText.trim()) throw new Error('Please enter a message');

          // Get all users related to jobs
          const { data: jobs } = await supabase
            .from('jobs')
            .select('assigned_driver_id, shipper_id, created_by')
            .in('id', selectedJobIds);

          const userIds = new Set<string>();
          jobs?.forEach(job => {
            if (job.assigned_driver_id) userIds.add(job.assigned_driver_id);
            if (job.shipper_id) userIds.add(job.shipper_id);
            if (job.created_by) userIds.add(job.created_by);
          });

          if (userIds.size === 0) throw new Error('No users found');

          const notifications = Array.from(userIds).map(userId => ({
            user_id: userId,
            type: 'system' as const,
            title: 'Job Update',
            message: messageText.trim(),
            metadata: { job_count: selectedJobIds.length }
          }));

          await supabase.from('notifications').insert(notifications);
          break;

        default:
          throw new Error('Invalid action');
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['jobs-export'] });
      
      const messages: Record<string, string> = {
        'assign': `Assigned ${selectedJobIds.length} job(s)`,
        'reassign': `Reassigned ${selectedJobIds.length} job(s)`,
        'update_status': `Updated ${selectedJobIds.length} job(s)`,
        'cancel': `Cancelled ${selectedJobIds.length} job(s)`,
        'delete': `Deleted ${selectedJobIds.length} job(s)`,
        'notify': `Sent notifications for ${selectedJobIds.length} job(s)`
      };
      
      toast.success(messages[action] || 'Action completed');
      handleClose();
      onComplete();
    },
    onError: (error: Error) => {
      toast.error(error.message || 'Action failed');
    },
  });

  const handleClose = () => {
    setAction('');
    setDriverId('');
    setStatusValue('');
    setMessageText('');
    onOpenChange(false);
  };

  const handleSubmit = () => {
    if (!action) {
      toast.error('Please select an action');
      return;
    }
    bulkMutation.mutate();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Bulk Actions</DialogTitle>
          <DialogDescription>
            Apply actions to {selectedJobIds.length} selected job(s)
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-3 pb-4">
          <div className="space-y-2">
            <Label>Select Action</Label>
            <Select value={action} onValueChange={setAction}>
              <SelectTrigger>
                <SelectValue placeholder="Choose action" />
              </SelectTrigger>
              <SelectContent className="z-[200] bg-popover text-popover-foreground">
                <SelectItem value="assign">Assign to Driver</SelectItem>
                <SelectItem value="reassign">Reassign to Driver</SelectItem>
                <SelectItem value="update_status">Update Status</SelectItem>
                <SelectItem value="cancel">Cancel Jobs</SelectItem>
                <SelectItem value="delete">Delete Jobs</SelectItem>
                <SelectItem value="notify">Send Notification</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {(action === 'assign' || action === 'reassign') && (
            <div className="space-y-2">
              <Label>Select Driver</Label>
              <Select value={driverId} onValueChange={setDriverId}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose driver" />
                </SelectTrigger>
                <SelectContent className="z-[200] bg-popover text-popover-foreground">
                  {drivers?.map((driver) => (
                    <SelectItem key={driver.id} value={driver.id}>
                      {driver.full_name || driver.email}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          {action === 'update_status' && (
            <div className="space-y-2">
              <Label>New Status</Label>
              <Select value={statusValue} onValueChange={setStatusValue}>
                <SelectTrigger>
                  <SelectValue placeholder="Choose status" />
                </SelectTrigger>
                <SelectContent className="z-[200] bg-popover text-popover-foreground max-h-[250px] overflow-y-auto">
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="posted">Posted</SelectItem>
                  <SelectItem value="planned">Planned</SelectItem>
                  <SelectItem value="claimed">Claimed</SelectItem>
                  <SelectItem value="assigned">Assigned</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="picked_up">Picked Up</SelectItem>
                  <SelectItem value="delivered">Delivered</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="delayed">Delayed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          {action === 'delete' && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Warning: This will permanently delete all selected jobs and cannot be undone.
              </AlertDescription>
            </Alert>
          )}

          {action === 'notify' && (
            <div className="space-y-2">
              <Label>Message</Label>
              <Textarea
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Enter notification message..."
                rows={4}
                maxLength={500}
              />
              <p className="text-xs text-muted-foreground">
                {messageText.length}/500 characters
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose}>
            Cancel
          </Button>
          <Button 
            onClick={handleSubmit}
            disabled={bulkMutation.isPending}
          >
            {bulkMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Apply
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
