import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { FileText, Package, Truck, Briefcase, Store } from 'lucide-react';

interface JobTypeSelectionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectJobType: (type: 'admin' | 'general' | 'shipper' | 'broker' | 'vendor') => void;
}

export function JobTypeSelectionModal({ open, onOpenChange, onSelectJobType }: JobTypeSelectionModalProps) {
  const handleSelect = (type: 'admin' | 'general' | 'shipper' | 'broker' | 'vendor') => {
    onOpenChange(false);
    onSelectJobType(type);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Select Job Form Type</DialogTitle>
          <DialogDescription>
            Choose which type of job form you want to use to create a new job.
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {/* Admin Job Form */}
          <Card 
            className="hover:shadow-lg transition-shadow cursor-pointer hover:border-primary" 
            onClick={() => handleSelect('admin')}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-lg">
                  <FileText className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg">Admin Job Form</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Full administrative controls with dispatch, assignment, and detailed configuration options.
              </CardDescription>
            </CardContent>
          </Card>

          {/* General Job Form */}
          <Card 
            className="hover:shadow-lg transition-shadow cursor-pointer hover:border-primary" 
            onClick={() => handleSelect('general')}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-blue-500/10 rounded-lg">
                  <Package className="h-6 w-6 text-blue-500" />
                </div>
                <CardTitle className="text-lg">General Job Form</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Standard job creation with essential fields including pickup/delivery locations and times.
              </CardDescription>
            </CardContent>
          </Card>

          {/* Shipper Job Form */}
          <Card 
            className="hover:shadow-lg transition-shadow cursor-pointer hover:border-primary" 
            onClick={() => handleSelect('shipper')}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-green-500/10 rounded-lg">
                  <Truck className="h-6 w-6 text-green-500" />
                </div>
                <CardTitle className="text-lg">Shipper Job Form</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Shipper-specific form optimized for shipping and delivery operations with location tracking.
              </CardDescription>
            </CardContent>
          </Card>

          {/* Broker Load Form */}
          <Card 
            className="hover:shadow-lg transition-shadow cursor-pointer hover:border-primary" 
            onClick={() => handleSelect('broker')}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-500/10 rounded-lg">
                  <Briefcase className="h-6 w-6 text-orange-500" />
                </div>
                <CardTitle className="text-lg">Broker Load Form</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Broker load posting for creating delivery gigs and managing carrier assignments.
              </CardDescription>
            </CardContent>
          </Card>

          {/* Vendor Delivery Gig Form */}
          <Card 
            className="hover:shadow-lg transition-shadow cursor-pointer hover:border-primary" 
            onClick={() => handleSelect('vendor')}
          >
            <CardHeader>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-purple-500/10 rounded-lg">
                  <Store className="h-6 w-6 text-purple-500" />
                </div>
                <CardTitle className="text-lg">Vendor Delivery Gig Form</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <CardDescription>
                Vendor-specific delivery gig creation with pickup/delivery locations and pay details.
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
