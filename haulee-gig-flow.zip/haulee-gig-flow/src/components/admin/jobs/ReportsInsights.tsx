import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Download, FileText, Calendar, TrendingUp, DollarSign, MapPin } from 'lucide-react';
import { 
  BarChart, Bar, LineChart, Line, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';

interface ReportsInsightsProps {
  filters: any;
}

export const ReportsInsights = ({ filters }: ReportsInsightsProps) => {
  // Mock data for charts
  const jobVolumeData = [
    { month: 'Jan', jobs: 245 },
    { month: 'Feb', jobs: 298 },
    { month: 'Mar', jobs: 312 },
    { month: 'Apr', jobs: 287 },
    { month: 'May', jobs: 356 },
    { month: 'Jun', jobs: 389 },
  ];

  const regionalData = [
    { region: 'Northeast', jobs: 450 },
    { region: 'Southeast', jobs: 380 },
    { region: 'Midwest', jobs: 290 },
    { region: 'Southwest', jobs: 340 },
    { region: 'West', jobs: 520 },
  ];

  const revenueData = [
    { role: 'Driver', revenue: 45000 },
    { role: 'Shipper', revenue: 62000 },
    { role: 'Vendor', revenue: 38000 },
    { role: 'Broker', revenue: 51000 },
    { role: 'Carrier', revenue: 58000 },
  ];

  const completionRateData = [
    { name: 'Completed', value: 85, color: '#10b981' },
    { name: 'Cancelled', value: 8, color: '#ef4444' },
    { name: 'Delayed', value: 7, color: '#f59e0b' },
  ];

  return (
    <div className="space-y-6">
      {/* Report Controls */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Custom Report Builder</CardTitle>
              <CardDescription>Generate and export customized reports</CardDescription>
            </div>
            <div className="flex gap-2">
              <Select defaultValue="pdf">
                <SelectTrigger className="w-[120px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="excel">Excel</SelectItem>
                  <SelectItem value="csv">CSV</SelectItem>
                </SelectContent>
              </Select>
              <Button>
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-3">
            <Select defaultValue="all">
              <SelectTrigger className="w-[160px]">
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
                <SelectItem value="quarter">This Quarter</SelectItem>
                <SelectItem value="year">This Year</SelectItem>
              </SelectContent>
            </Select>

            <Select defaultValue="all">
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Report Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Reports</SelectItem>
                <SelectItem value="performance">Performance</SelectItem>
                <SelectItem value="financial">Financial</SelectItem>
                <SelectItem value="operational">Operational</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Schedule Email
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Performance Reports */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Job Volume Trend</CardTitle>
            <CardDescription>Monthly job creation over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={jobVolumeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="jobs" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Jobs by Region</CardTitle>
            <CardDescription>Geographic distribution of deliveries</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={regionalData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="region" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="jobs" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Financial Reports */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Revenue by Role</CardTitle>
            <CardDescription>Total earnings across platform roles</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="role" />
                <YAxis />
                <Tooltip formatter={(value) => `$${value.toLocaleString()}`} />
                <Bar dataKey="revenue" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Job Completion Rate</CardTitle>
            <CardDescription>Breakdown of job outcomes</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={completionRateData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.name}: ${entry.value}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {completionRateData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Role-based KPI Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Delivery Duration</p>
                <p className="text-2xl font-bold mt-1">42 min</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">↓ 8% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Late Delivery %</p>
                <p className="text-2xl font-bold mt-1">7.2%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">↑ 2% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Platform Revenue</p>
                <p className="text-2xl font-bold mt-1">$254k</p>
              </div>
              <DollarSign className="h-8 w-8 text-emerald-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">↑ 15% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Efficiency Index</p>
                <p className="text-2xl font-bold mt-1">92.5</p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">↑ 5% from last month</p>
          </CardContent>
        </Card>
      </div>

      {/* Operational Metrics */}
      <Card>
        <CardHeader>
          <CardTitle>Top Performing Vendors & Carriers</CardTitle>
          <CardDescription>Based on job completion rate and customer ratings</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: 'Premium Logistics', role: 'Carrier', jobs: 245, rating: 4.9, revenue: '$45,200' },
              { name: 'FastTrack Delivery', role: 'Vendor', jobs: 198, rating: 4.8, revenue: '$38,900' },
              { name: 'Swift Transport', role: 'Carrier', jobs: 187, rating: 4.7, revenue: '$42,100' },
              { name: 'QuickShip Co.', role: 'Vendor', jobs: 156, rating: 4.8, revenue: '$35,600' },
            ].map((vendor, index) => (
              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <MapPin className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-semibold">{vendor.name}</p>
                    <p className="text-sm text-muted-foreground">{vendor.role}</p>
                  </div>
                </div>
                <div className="flex items-center gap-8 text-sm">
                  <div>
                    <p className="text-muted-foreground">Jobs</p>
                    <p className="font-semibold">{vendor.jobs}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Rating</p>
                    <p className="font-semibold">{vendor.rating} ⭐</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Revenue</p>
                    <p className="font-semibold">{vendor.revenue}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
