import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon } from 'lucide-react';
import { format } from 'date-fns';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import React, { useEffect } from 'react';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { VEHICLE_CATEGORIES } from '@/lib/vehicleConfig';
import { cn } from '@/lib/utils';

const jobSchema = z.object({
  title: z.string().min(1, 'Title is required'),
  description: z.string().optional(),
  priority: z.enum(['pickup_now','scheduled','route'], { required_error: 'Priority is required' }),
  status: z.string(),
  equipment_type: z.string().optional(),
  pay_amount: z.string().min(1, 'Pay amount is required'),
  distance_miles: z.string().optional(),
  estimated_duration: z.string().optional(),
  cargo_weight: z.string().optional().or(z.literal('')),
  cargo_length: z.string().optional().or(z.literal('')),
  cargo_width: z.string().optional().or(z.literal('')),
  cargo_height: z.string().optional().or(z.literal('')),
  cargo_pieces: z.string().optional().or(z.literal('')),
  signature_required: z.boolean().optional(),
  is_hazmat: z.boolean().optional(),
  hazmat_details: z.string().optional(),
  temperature_requirements: z.string().optional(),
  trailer_type: z.string().optional(),
  insurance_requirements: z.string().optional(),
  special_instructions: z.string().optional(),
  payment_terms: z.string().optional(),
  broker_notes: z.string().optional(),
  pickup_address: z.string().min(1, 'Pickup address is required'),
  pickup_city: z.string().min(1, 'City is required'),
  pickup_state: z.string().min(1, 'State is required'),
  pickup_zipCode: z.string().min(1, 'Zip code is required'),
  pickup_contact_name: z.string().optional(),
  pickup_contact_phone: z.string().optional(),
  pickup_date: z.date().optional(),
  pickup_time: z.string().optional(),
  pickup_instructions: z.string().optional(),
  delivery_address: z.string().min(1, 'Delivery address is required'),
  delivery_city: z.string().min(1, 'City is required'),
  delivery_state: z.string().min(1, 'State is required'),
  delivery_zipCode: z.string().min(1, 'Zip code is required'),
  delivery_contact_name: z.string().optional(),
  delivery_contact_phone: z.string().optional(),
  delivery_date: z.date().optional(),
  delivery_time: z.string().optional(),
  delivery_instructions: z.string().optional(),
});

type JobFormData = z.infer<typeof jobSchema>;

interface JobEditDialogProps {
  job: any;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const JobEditDialog = ({ job, open, onOpenChange }: JobEditDialogProps) => {
  const queryClient = useQueryClient();
  const [pickupAddr, setPickupAddr] = React.useState('');
  const [deliveryAddr, setDeliveryAddr] = React.useState('');
  const [pickupDate, setPickupDate] = React.useState<Date>();
  const [deliveryDate, setDeliveryDate] = React.useState<Date>();
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset, setValue, watch, control } = useForm<JobFormData>({
    resolver: zodResolver(jobSchema),
    mode: 'onChange',
    defaultValues: {
      is_hazmat: false,
      signature_required: false,
    },
  });

  // Watch status for conditional validation
  const currentStatus = watch('status');

  // Log form errors for debugging
  useEffect(() => {
    if (Object.keys(errors).length > 0) {
      console.log('🔴 Form validation errors:', errors);
    }
  }, [errors]);

  // Auto-calculation disabled - users can manually enter distance and duration

  useEffect(() => {
    if (job && open) {
      setValue('title', job.title || '');
      setValue('description', job.description || '');
      setValue('priority', job.priority || '');
      setValue('equipment_type', job.equipment_type || '');
      setPickupAddr(job.pickup_location?.address || '');
      setDeliveryAddr(job.delivery_location?.address || '');
      setValue('status', job.status || 'pending');
      setValue('pay_amount', job.pay_amount?.toString() || '');
      setValue('distance_miles', job.distance_miles?.toString() || '');
      setValue('estimated_duration', job.estimated_duration?.toString() || '');
      setValue('pickup_address', (job.pickup_location as any)?.address || '');
      setValue('pickup_city', (job.pickup_location as any)?.city || '');
      setValue('pickup_state', (job.pickup_location as any)?.state || '');
      setValue('pickup_zipCode', (job.pickup_location as any)?.zipCode || '');
      setValue('pickup_contact_name', job.pickup_contact_name || '');
      setValue('pickup_contact_phone', job.pickup_contact_phone || '');
      setValue('pickup_instructions', (job.pickup_location as any)?.instructions || '');
      setValue('delivery_address', (job.delivery_location as any)?.address || '');
      setValue('delivery_city', (job.delivery_location as any)?.city || '');
      setValue('delivery_state', (job.delivery_location as any)?.state || '');
      setValue('delivery_zipCode', (job.delivery_location as any)?.zipCode || '');
      setValue('delivery_contact_name', job.delivery_contact_name || '');
      setValue('delivery_contact_phone', job.delivery_contact_phone || '');
      setValue('delivery_instructions', (job.delivery_location as any)?.instructions || '');
      
      // Set date/time fields
      if (job.pickup_time) {
        const pickupDateTime = new Date(job.pickup_time);
        setPickupDate(pickupDateTime);
        setValue('pickup_date', pickupDateTime);
        setValue('pickup_time', format(pickupDateTime, 'HH:mm'));
      }
      if (job.delivery_time) {
        const deliveryDateTime = new Date(job.delivery_time);
        setDeliveryDate(deliveryDateTime);
        setValue('delivery_date', deliveryDateTime);
        setValue('delivery_time', format(deliveryDateTime, 'HH:mm'));
      }
      
      // Set cargo fields
      setValue('cargo_weight', job.cargo_weight?.toString() || '');
      setValue('cargo_length', (job.cargo_dimensions as any)?.length?.toString() || '');
      setValue('cargo_width', (job.cargo_dimensions as any)?.width?.toString() || '');
      setValue('cargo_height', (job.cargo_dimensions as any)?.height?.toString() || '');
      setValue('cargo_pieces', (job.cargo_dimensions as any)?.pieces?.toString() || '');
      setValue('signature_required', job.signature_required || false);
      setValue('is_hazmat', job.is_hazmat || false);
      setValue('hazmat_details', job.hazmat_details || '');
      setValue('temperature_requirements', job.temperature_requirements || '');
      setValue('trailer_type', job.trailer_type || '');
      setValue('insurance_requirements', job.insurance_requirements || '');
      setValue('special_instructions', job.special_instructions || '');
      setValue('payment_terms', job.payment_terms || '');
      setValue('broker_notes', job.broker_notes || '');
    }
  }, [job, open, setValue]);

  const onSubmit = async (data: JobFormData) => {
    console.log('🔵 [EDIT JOB] Form submitted with data:', data);
    console.log('🔵 [EDIT JOB] Job ID:', job.id);
    
    try {
      // Validate title
      if (!data.title || data.title.trim() === '') {
        console.error('❌ [EDIT JOB] Title validation failed');
        toast.error('Job title is required');
        return;
      }

      // Check if user is admin/super_admin for flexible status changes
      const { data: { user } } = await supabase.auth.getUser();
      const isAdminResult = await supabase.rpc('has_role', { 
        _user_id: user?.id, 
        _role: 'admin' 
      });
      const isSuperAdminResult = await supabase.rpc('has_role', { 
        _user_id: user?.id, 
        _role: 'super_admin' 
      });
      const isAdmin = isAdminResult.data || isSuperAdminResult.data;

      // Only apply validations to non-admins
      if (!isAdmin) {
        // Validate: Cannot set status to "assigned" if no driver is assigned
        if (data.status === 'assigned' && !job.assigned_driver_id) {
          console.error('❌ [EDIT JOB] Cannot assign without driver');
          toast.error('Cannot set status to assigned', {
            description: 'Please assign a driver first before setting status to assigned.'
          });
          return;
        }

        // Validate: Statuses requiring pickup time
        const statusesRequiringPickupTime = ['pending', 'planned', 'claimed', 'posted'];
        if (statusesRequiringPickupTime.includes(data.status)) {
          const hasPickupTime = (data.pickup_date && data.pickup_time) || job.pickup_time;
          if (!hasPickupTime) {
            console.error('❌ [EDIT JOB] Pickup date/time required for status:', data.status);
            toast.error('Pickup Date & Time Required', {
              description: `Status "${data.status}" requires both pickup date and time to be set.`
            });
            return;
          }
        }
      } else {
        console.log('✅ [EDIT JOB] Admin user - bypassing status validation');
      }

      // If status is being set to pending, delete all job assignments first
      if (data.status === 'pending') {
        console.log('🔵 [EDIT JOB] Deleting job assignments...');
        const { error: deleteError } = await supabase
          .from('job_assignments')
          .delete()
          .eq('job_id', job.id);
        
        if (deleteError) {
          console.error('❌ [EDIT JOB] Failed to delete assignments:', deleteError);
          throw deleteError;
        }
        console.log('✅ [EDIT JOB] Job assignments deleted');
      }

      // Combine date and time for pickup - preserve existing if not changed
      let pickupDateTime = null;
      if (data.pickup_date && data.pickup_time) {
        const [hours, minutes] = data.pickup_time.split(':');
        pickupDateTime = new Date(data.pickup_date);
        pickupDateTime.setHours(parseInt(hours), parseInt(minutes));
      } else if (job.pickup_time) {
        // Preserve existing pickup_time if not changed
        pickupDateTime = new Date(job.pickup_time);
      }

      // Combine date and time for delivery - preserve existing if not changed
      let deliveryDateTime = null;
      if (data.delivery_date && data.delivery_time) {
        const [hours, minutes] = data.delivery_time.split(':');
        deliveryDateTime = new Date(data.delivery_date);
        deliveryDateTime.setHours(parseInt(hours), parseInt(minutes));
      } else if (job.delivery_time) {
        // Preserve existing delivery_time if not changed
        deliveryDateTime = new Date(job.delivery_time);
      }

      const updateData: any = {
        title: data.title,
        description: data.description,
        priority: data.priority,
        status: data.status,
        equipment_type: data.equipment_type || null,
        pay_amount: parseFloat(data.pay_amount),
        distance_miles: data.distance_miles ? parseFloat(data.distance_miles) : null,
        estimated_duration: data.estimated_duration ? parseFloat(data.estimated_duration) : null,
        cargo_weight: data.cargo_weight ? parseFloat(data.cargo_weight) : null,
        cargo_dimensions: {
          length: data.cargo_length ? parseFloat(data.cargo_length) : null,
          width: data.cargo_width ? parseFloat(data.cargo_width) : null,
          height: data.cargo_height ? parseFloat(data.cargo_height) : null,
          pieces: data.cargo_pieces ? parseInt(data.cargo_pieces) : null,
        },
        signature_required: data.signature_required || false,
        is_hazmat: data.is_hazmat || false,
        hazmat_details: data.hazmat_details || null,
        temperature_requirements: data.temperature_requirements || null,
        trailer_type: data.trailer_type || null,
        insurance_requirements: data.insurance_requirements || null,
        special_instructions: data.special_instructions || null,
        payment_terms: data.payment_terms || null,
        broker_notes: data.broker_notes || null,
        pickup_contact_name: data.pickup_contact_name || null,
        pickup_contact_phone: data.pickup_contact_phone || null,
        delivery_contact_name: data.delivery_contact_name || null,
        delivery_contact_phone: data.delivery_contact_phone || null,
        pickup_location: {
          address: data.pickup_address,
          city: data.pickup_city,
          state: data.pickup_state,
          zipCode: data.pickup_zipCode,
          instructions: data.pickup_instructions || null,
        },
        delivery_location: {
          address: data.delivery_address,
          city: data.delivery_city,
          state: data.delivery_state,
          zipCode: data.delivery_zipCode,
          instructions: data.delivery_instructions || null,
        },
        pickup_time: pickupDateTime?.toISOString() || null,
        delivery_time: deliveryDateTime?.toISOString() || null,
        updated_at: new Date().toISOString(),
      };

      // Clear assigned driver when setting to pending
      if (data.status === 'pending') {
        updateData.assigned_driver_id = null;
      }

      console.log('🔵 [EDIT JOB] Updating job with data:', updateData);
      
      const { data: result, error } = await supabase
        .from('jobs')
        .update(updateData)
        .eq('id', job.id)
        .select();

      console.log('🔵 [EDIT JOB] Update result:', { result, error });

      if (error) {
        console.error('❌ [EDIT JOB] Update failed:', error);
        
        // Check for permission errors
        if (error.code === 'PGRST301' || error.message?.includes('permission') || error.message?.includes('policy')) {
          toast.error('Permission Denied', {
            description: 'You do not have permission to edit this job. Only admins or the job creator can edit jobs.'
          });
          return;
        }
        
        throw error;
      }

      if (!result || result.length === 0) {
        console.warn('⚠️ [EDIT JOB] Update returned no results - possible RLS policy blocking update');
        toast.error('Permission Denied', {
          description: 'You do not have permission to edit this job. Only admins or the job creator can edit jobs.'
        });
        return;
      }

      console.log('✅ [EDIT JOB] Job updated successfully');

      // Invalidate all job-related queries to update all tabs and pages immediately
      queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['job-stats'] });
      queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
      queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['jobs-export'] });
      queryClient.invalidateQueries({ queryKey: ['available-drivers'] });
      queryClient.invalidateQueries({ queryKey: ['available-jobs'] }); // Driver available jobs page
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] }); // Driver active jobs
      queryClient.invalidateQueries({ queryKey: ['scheduled-jobs'] }); // Driver scheduled jobs
      queryClient.invalidateQueries({ queryKey: ['planned-jobs'] }); // Driver planned jobs
      
      toast.success('Job Updated Successfully', {
        description: 'Changes are now visible across all job tabs and management pages.'
      });
      onOpenChange(false);
      reset();
    } catch (error: any) {
      console.error('❌ [EDIT JOB] Error updating job:', error);
      const msg =
        (error && typeof error === 'object' && 'message' in error && (error as any).message) ||
        (error instanceof Error && error.message) ||
        'An unexpected error occurred';
      const details =
        (error && typeof error === 'object' && 'details' in error && (error as any).details) ||
        (error && typeof error === 'object' && 'hint' in error && (error as any).hint) ||
        '';
      toast.error('Failed to update job', {
        description: [msg, details].filter(Boolean).join(' • ')
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Job</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Job Title *</Label>
              <Input id="title" {...register('title')} />
              {errors.title && <p className="text-sm text-destructive mt-1">{errors.title.message}</p>}
            </div>

            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" {...register('description')} rows={3} />
            </div>

            <div>
              <Label htmlFor="special_instructions">Special Instructions</Label>
              <Textarea id="special_instructions" {...register('special_instructions')} rows={2} placeholder="Any special handling or requirements..." />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="priority">Priority *</Label>
                <Select onValueChange={(value) => setValue('priority', value as any)} defaultValue={job?.priority || ''}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pickup_now">Pick Up Now</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="route">Route</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="status">Status *</Label>
                <Select onValueChange={(value) => setValue('status', value)} defaultValue={job?.status}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pending">Pending - Awaiting assignment</SelectItem>
                    <SelectItem value="planned">Planned - Scheduled for future</SelectItem>
                    <SelectItem value="claimed">Claimed</SelectItem>
                    <SelectItem value="posted">Posted - Visible to drivers</SelectItem>
                    <SelectItem value="assigned">Assigned - Driver claimed</SelectItem>
                    <SelectItem value="in_progress">In Progress - En route</SelectItem>
                    <SelectItem value="picked_up">Picked Up - Items collected</SelectItem>
                    <SelectItem value="delayed">Delayed - Behind schedule</SelectItem>
                    <SelectItem value="delivered">Delivered - Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground mt-1">
                  Admin can change status without restrictions
                </p>
              </div>
            </div>

            <div>
              <Label htmlFor="equipment_type">Vehicle Type Required</Label>
              <Select onValueChange={(value) => setValue('equipment_type', value)} defaultValue={job?.equipment_type || ''}>
                <SelectTrigger>
                  <SelectValue placeholder="Select vehicle type" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {VEHICLE_CATEGORIES.map((category) => (
                    <React.Fragment key={category.id}>
                      <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                        {category.icon} {category.name}
                      </div>
                      {category.vehicle_types.map((vehicle) => (
                        <SelectItem 
                          key={vehicle.name} 
                          value={vehicle.name}
                          className="pl-6"
                        >
                          {vehicle.name} ({vehicle.capacity})
                        </SelectItem>
                      ))}
                    </React.Fragment>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-4 gap-4">
              <div>
                <Label htmlFor="pay_amount">Pay Amount ($) *</Label>
                <Input id="pay_amount" type="number" step="0.01" {...register('pay_amount')} />
                {errors.pay_amount && <p className="text-sm text-destructive mt-1">{errors.pay_amount.message}</p>}
              </div>

              <div>
                <Label htmlFor="distance_miles">Distance (miles)</Label>
                <Input 
                  id="distance_miles" 
                  type="number" 
                  step="0.1" 
                  {...register('distance_miles')} 
                  placeholder="Enter distance"
                />
              </div>

              <div>
                <Label htmlFor="estimated_duration">Duration (minutes)</Label>
                <Input 
                  id="estimated_duration" 
                  type="number" 
                  {...register('estimated_duration')} 
                  placeholder="Enter duration"
                />
              </div>

            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="cargo_weight">Weight (lbs)</Label>
                <Input id="cargo_weight" type="number" {...register('cargo_weight')} placeholder="500" />
              </div>

              <div>
                <Label htmlFor="cargo_pieces">Number of Pieces</Label>
                <Input id="cargo_pieces" type="number" {...register('cargo_pieces')} placeholder="1" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="cargo_length">Length (ft)</Label>
                <Input id="cargo_length" type="number" {...register('cargo_length')} placeholder="8" />
              </div>

              <div>
                <Label htmlFor="cargo_width">Width (ft)</Label>
                <Input id="cargo_width" type="number" {...register('cargo_width')} placeholder="4" />
              </div>

              <div>
                <Label htmlFor="cargo_height">Height (ft)</Label>
                <Input id="cargo_height" type="number" {...register('cargo_height')} placeholder="6" />
              </div>
            </div>

            <div className="space-y-4 border-t pt-4 mt-4">
              <h4 className="text-sm font-semibold">Additional Requirements</h4>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="trailer_type">Trailer Type</Label>
                  <Input id="trailer_type" {...register('trailer_type')} placeholder="Flatbed, Refrigerated, etc." />
                </div>

                <div>
                  <Label htmlFor="temperature_requirements">Temperature Requirements</Label>
                  <Input id="temperature_requirements" {...register('temperature_requirements')} placeholder="e.g., -10°F to 35°F" />
                </div>
              </div>

              <div>
                <Label htmlFor="insurance_requirements">Insurance Requirements</Label>
                <Textarea id="insurance_requirements" {...register('insurance_requirements')} rows={2} placeholder="Minimum coverage amounts, special insurance..." />
              </div>

              <div className="flex items-center space-x-2">
                <Controller
                  name="is_hazmat"
                  control={control}
                  render={({ field }) => (
                    <Checkbox 
                      id="is_hazmat" 
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  )}
                />
                <Label htmlFor="is_hazmat" className="text-sm font-normal cursor-pointer">
                  Hazardous Materials (HAZMAT)
                </Label>
              </div>

              <div>
                <Label htmlFor="hazmat_details">HAZMAT Details</Label>
                <Textarea id="hazmat_details" {...register('hazmat_details')} rows={2} placeholder="UN numbers, class, packaging group..." />
              </div>

              <div className="flex items-center space-x-2">
                <Controller
                  name="signature_required"
                  control={control}
                  render={({ field }) => (
                    <Checkbox 
                      id="signature_required" 
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  )}
                />
                <Label htmlFor="signature_required" className="text-sm font-normal cursor-pointer">
                  Signature required upon delivery
                </Label>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="payment_terms">Payment Terms</Label>
                  <Input id="payment_terms" {...register('payment_terms')} placeholder="Net 30, COD, etc." />
                </div>
              </div>

              <div>
                <Label htmlFor="broker_notes">Broker Notes (Internal)</Label>
                <Textarea id="broker_notes" {...register('broker_notes')} rows={2} placeholder="Internal notes for brokers/admins..." />
              </div>
            </div>
          </div>

          {/* Pickup Location */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Pickup Location</h3>
            <div>
              <AddressAutocomplete
                label="Address"
                value={pickupAddr}
                onAddressSelect={(address) => {
                  setPickupAddr(address.formatted_address || '');
                  setValue('pickup_address', address.formatted_address || '');
                  setValue('pickup_city', address.city || '');
                  setValue('pickup_state', address.state || '');
                  setValue('pickup_zipCode', address.zip || '');
                }}
                placeholder="Start typing pickup address..."
                required
                error={errors.pickup_address?.message}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="pickup_city">City *</Label>
                <Input id="pickup_city" {...register('pickup_city')} />
                {errors.pickup_city && <p className="text-sm text-destructive mt-1">{errors.pickup_city.message}</p>}
              </div>
              <div>
                <Label htmlFor="pickup_state">State *</Label>
                <Input id="pickup_state" {...register('pickup_state')} />
                {errors.pickup_state && <p className="text-sm text-destructive mt-1">{errors.pickup_state.message}</p>}
              </div>
              <div>
                <Label htmlFor="pickup_zipCode">Zip Code *</Label>
                <Input id="pickup_zipCode" {...register('pickup_zipCode')} />
                {errors.pickup_zipCode && <p className="text-sm text-destructive mt-1">{errors.pickup_zipCode.message}</p>}
              </div>
            </div>
            
            {/* Pickup Date & Time */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col space-y-2">
                <Label htmlFor="pickup_date">
                  Pickup Date {['pending', 'planned', 'claimed', 'posted'].includes(currentStatus) && <span className="text-destructive">*</span>}
                </Label>
                <Input
                  id="pickup_date"
                  type="date"
                  value={pickupDate ? format(pickupDate, 'yyyy-MM-dd') : ''}
                  onChange={(e) => {
                    const date = e.target.value
                      ? (() => {
                          const [y, m, d] = e.target.value.split('-').map(Number);
                          const dt = new Date();
                          dt.setFullYear(y, m - 1, d);
                          dt.setHours(12, 0, 0, 0); // avoid timezone shifts
                          return dt;
                        })()
                      : undefined;
                    setPickupDate(date);
                    setValue('pickup_date', date);
                  }}
                  className="w-full"
                />
              </div>
              
              <div>
                <Label htmlFor="pickup_time">
                  Pickup Time {['pending', 'planned', 'claimed', 'posted'].includes(currentStatus) && <span className="text-destructive">*</span>}
                </Label>
                <Input 
                  id="pickup_time" 
                  type="time" 
                  {...register('pickup_time')} 
                />
              </div>
            </div>
            
            {/* Pickup Contact */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="pickup_contact_name">Contact Name</Label>
                <Input id="pickup_contact_name" {...register('pickup_contact_name')} placeholder="John Doe" />
              </div>
              <div>
                <Label htmlFor="pickup_contact_phone">Contact Phone</Label>
                <Input id="pickup_contact_phone" {...register('pickup_contact_phone')} placeholder="(555) 123-4567" />
              </div>
            </div>

            {/* Pickup Instructions */}
            <div>
              <Label htmlFor="pickup_instructions">Pickup Instructions</Label>
              <Textarea 
                id="pickup_instructions" 
                {...register('pickup_instructions')} 
                placeholder="Loading dock info, access codes, special handling..."
                rows={2}
              />
            </div>
          </div>

          {/* Delivery Location */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Delivery Location</h3>
            <div>
              <AddressAutocomplete
                label="Address"
                value={deliveryAddr}
                onAddressSelect={(address) => {
                  setDeliveryAddr(address.formatted_address || '');
                  setValue('delivery_address', address.formatted_address || '');
                  setValue('delivery_city', address.city || '');
                  setValue('delivery_state', address.state || '');
                  setValue('delivery_zipCode', address.zip || '');
                }}
                placeholder="Start typing delivery address..."
                required
                error={errors.delivery_address?.message}
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label htmlFor="delivery_city">City *</Label>
                <Input id="delivery_city" {...register('delivery_city')} />
                {errors.delivery_city && <p className="text-sm text-destructive mt-1">{errors.delivery_city.message}</p>}
              </div>
              <div>
                <Label htmlFor="delivery_state">State *</Label>
                <Input id="delivery_state" {...register('delivery_state')} />
                {errors.delivery_state && <p className="text-sm text-destructive mt-1">{errors.delivery_state.message}</p>}
              </div>
              <div>
                <Label htmlFor="delivery_zipCode">Zip Code *</Label>
                <Input id="delivery_zipCode" {...register('delivery_zipCode')} />
                {errors.delivery_zipCode && <p className="text-sm text-destructive mt-1">{errors.delivery_zipCode.message}</p>}
              </div>
            </div>
            
            {/* Delivery Date & Time */}
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col space-y-2">
                <Label htmlFor="delivery_date">Delivery Date (Optional)</Label>
                <Input
                  id="delivery_date"
                  type="date"
                  value={deliveryDate ? format(deliveryDate, 'yyyy-MM-dd') : ''}
                  onChange={(e) => {
                    const date = e.target.value
                      ? (() => {
                          const [y, m, d] = e.target.value.split('-').map(Number);
                          const dt = new Date();
                          dt.setFullYear(y, m - 1, d);
                          dt.setHours(12, 0, 0, 0); // avoid timezone shifts
                          return dt;
                        })()
                      : undefined;
                    setDeliveryDate(date);
                    setValue('delivery_date', date);
                  }}
                  className="w-full"
                />
              </div>
              
              <div>
                <Label htmlFor="delivery_time">Delivery Time (Optional)</Label>
                <Input 
                  id="delivery_time" 
                  type="time" 
                  {...register('delivery_time')} 
                 />
              </div>
            </div>
            
            {/* Delivery Contact */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="delivery_contact_name">Contact Name</Label>
                <Input id="delivery_contact_name" {...register('delivery_contact_name')} placeholder="Jane Smith" />
              </div>
              <div>
                <Label htmlFor="delivery_contact_phone">Contact Phone</Label>
                <Input id="delivery_contact_phone" {...register('delivery_contact_phone')} placeholder="(555) 987-6543" />
              </div>
            </div>

            {/* Delivery Instructions */}
            <div>
              <Label htmlFor="delivery_instructions">Delivery Instructions</Label>
              <Textarea 
                id="delivery_instructions" 
                {...register('delivery_instructions')} 
                placeholder="Delivery location details, contact info, special requirements..."
                rows={2}
              />
            </div>
          </div>

          <div className="flex justify-end gap-3">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isSubmitting}
              onClick={(e) => {
                console.log('🔵 [EDIT JOB] Update button clicked');
                console.log('🔵 [EDIT JOB] Form errors:', errors);
                console.log('🔵 [EDIT JOB] Is submitting:', isSubmitting);
                console.log('🔵 [EDIT JOB] Form values:', watch());
                
                // Check if there are validation errors
                if (Object.keys(errors).length > 0) {
                  e.preventDefault();
                  toast.error('Form Validation Failed', {
                    description: 'Please check all required fields: ' + Object.keys(errors).join(', ')
                  });
                }
              }}
            >
              {isSubmitting ? 'Updating...' : 'Update Job'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};
