import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { MapPin, Clock, AlertCircle, CheckCircle, Play, MessageSquare, Navigation, Phone, MapPinned } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { ScrollArea } from '@/components/ui/scroll-area';
import { LiveViewMap, LiveViewMapRef } from '@/components/maps/LiveViewMap';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { JobMapView } from '@/components/driver/JobMapView';

interface LiveTrackingProps {
  filters: any;
}

export const LiveTracking = ({ filters }: LiveTrackingProps) => {
  const [selectedJob, setSelectedJob] = useState<any | null>(null);
  const [showActivityFeed, setShowActivityFeed] = useState(true);
  const [showIssueDialog, setShowIssueDialog] = useState(false);
  const [issueDescription, setIssueDescription] = useState('');
  const [showRouteDialog, setShowRouteDialog] = useState(false);
  const mapRef = React.useRef<LiveViewMapRef>(null);

  // Fetch active deliveries with driver info
  const { data: allActiveJobs, refetch } = useQuery({
    queryKey: ['active-deliveries'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs')
        .select(`
          *,
          job_assignments (
            id,
            driver_id,
            status,
            assigned_at,
            started_at
          )
        `)
        .in('status', ['in_progress', 'picked_up', 'assigned'])
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      // Fetch driver profiles separately
      const jobsWithDrivers = await Promise.all(
        (data || []).map(async (job: any) => {
          if (job.job_assignments && job.job_assignments.length > 0) {
            const driverId = job.job_assignments[0].driver_id;
            if (driverId) {
              const { data: profile } = await supabase
                .from('profiles')
                .select('id, full_name, phone, email')
                .eq('id', driverId)
                .single();
              
              if (profile) {
                job.job_assignments[0].driver = profile;
              }
            }
          }
          return job;
        })
      );
      
      return jobsWithDrivers;
    }
  });

  // Real-time subscription for job updates
  useEffect(() => {
    const channel = supabase
      .channel('live-tracking-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'jobs',
          filter: 'status=in.(in_progress,picked_up,assigned)'
        },
        () => {
          refetch();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'job_assignments'
        },
        () => {
          refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [refetch]);

  // Filter active jobs based on search
  const activeJobs = React.useMemo(() => {
    if (!allActiveJobs) return [];
    
    const searchLower = filters.searchQuery?.toLowerCase().trim() || '';
    if (!searchLower) return allActiveJobs;

    return allActiveJobs.filter(job => {
      if (job.id.toLowerCase().includes(searchLower)) return true;
      if (job.title?.toLowerCase().includes(searchLower)) return true;
      
      const pickupLoc = job.pickup_location as any;
      if (pickupLoc?.address?.toLowerCase().includes(searchLower)) return true;
      if (pickupLoc?.city?.toLowerCase().includes(searchLower)) return true;
      
      const deliveryLoc = job.delivery_location as any;
      if (deliveryLoc?.address?.toLowerCase().includes(searchLower)) return true;
      if (deliveryLoc?.city?.toLowerCase().includes(searchLower)) return true;

      // Search driver name
      const assignment = job.job_assignments?.[0];
      const driver = assignment?.driver;
      if (driver?.full_name?.toLowerCase().includes(searchLower)) return true;
      
      return false;
    });
  }, [allActiveJobs, filters.searchQuery]);

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      'on-time': 'text-green-500',
      'delayed': 'text-red-500',
      'approaching': 'text-orange-500',
    };
    return colors[status] || 'text-gray-500';
  };

  // Generate activity feed from recent job updates
  const activityFeed = React.useMemo(() => {
    if (!activeJobs) return [];
    
    return activeJobs.slice(0, 10).map((job: any, idx: number) => {
      const assignment = job.job_assignments?.[0];
      const driver = assignment?.driver;
      const status = job.status;
      
      let type = 'started';
      let icon = Play;
      if (status === 'picked_up') {
        type = 'picked_up';
        icon = CheckCircle;
      } else if (status === 'in_progress') {
        type = 'in_progress';
        icon = Navigation;
      }
      
      return {
        id: job.id,
        type,
        job: `#${job.id.slice(0, 8)}`,
        driver: driver?.full_name || 'Unassigned',
        time: formatTimeAgo(assignment?.assigned_at || job.created_at),
        icon
      };
    });
  }, [activeJobs]);

  function formatTimeAgo(dateString: string) {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes} min ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  }

  const handleMessageDriver = () => {
    if (!selectedJob) {
      toast.error('Please select a job first');
      return;
    }
    
    const assignment = selectedJob.job_assignments?.[0];
    if (!assignment?.driver) {
      toast.error('No driver assigned to this job');
      return;
    }
    
    toast.info('Messaging feature coming soon!');
  };

  const handleReportIssue = () => {
    if (!selectedJob) {
      toast.error('Please select a job first');
      return;
    }
    setShowIssueDialog(true);
  };

  const handleSubmitIssue = async () => {
    if (!issueDescription.trim()) {
      toast.error('Please describe the issue');
      return;
    }

    try {
      const { error } = await supabase
        .from('notifications')
        .insert({
          user_id: selectedJob.job_assignments?.[0]?.driver_id,
          type: 'system',
          title: 'Issue Reported',
          message: `An issue has been reported for job #${selectedJob.id.slice(0, 8)}: ${issueDescription}`,
          metadata: { job_id: selectedJob.id, issue: issueDescription }
        });

      if (error) throw error;
      
      toast.success('Issue reported successfully');
      setShowIssueDialog(false);
      setIssueDescription('');
    } catch (error) {
      console.error('Error reporting issue:', error);
      toast.error('Failed to report issue');
    }
  };

  const handleCallDriver = () => {
    if (!selectedJob) {
      toast.error('Please select a job first');
      return;
    }
    
    const assignment = selectedJob.job_assignments?.[0];
    const phone = assignment?.driver?.phone;
    
    if (!phone) {
      toast.error('Driver phone number not available');
      return;
    }
    
    window.open(`tel:${phone}`, '_self');
  };

  const getJobStatusBadge = (job: any) => {
    const status = job.status;
    if (status === 'picked_up') return <Badge className="bg-blue-500">Picked Up</Badge>;
    if (status === 'in_progress') return <Badge className="bg-green-500">In Progress</Badge>;
    if (status === 'assigned') return <Badge variant="outline">Assigned</Badge>;
    return <Badge variant="secondary">{status}</Badge>;
  };

  return (
    <div className="grid gap-6 lg:grid-cols-4">
      {/* Main Map Area */}
      <div className="lg:col-span-3 space-y-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Live Tracking Map</CardTitle>
                <CardDescription>Real-time delivery monitoring</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => mapRef.current?.centerMap()}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  Center Map
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowActivityFeed(!showActivityFeed)}
                >
                  Activity Feed
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[500px]">
              <LiveViewMap 
                ref={mapRef}
                activeJobs={activeJobs} 
                selectedJobId={selectedJob?.id}
              />
            </div>
          </CardContent>
        </Card>

        {/* Statistics Cards */}
        <div className="grid gap-4 sm:grid-cols-3">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Active Deliveries</p>
                  <p className="text-2xl font-bold mt-1">{activeJobs?.length || 0}</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg">
                  <Navigation className="h-6 w-6 text-blue-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Average ETA</p>
                  <p className="text-2xl font-bold mt-1">28 min</p>
                </div>
                <div className="bg-green-50 dark:bg-green-950 p-3 rounded-lg">
                  <Clock className="h-6 w-6 text-green-500" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">Late Jobs</p>
                  <p className="text-2xl font-bold mt-1">3</p>
                </div>
                <div className="bg-red-50 dark:bg-red-950 p-3 rounded-lg">
                  <AlertCircle className="h-6 w-6 text-red-500" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Side Panel */}
      <div className="lg:col-span-1 space-y-4">
        {/* Activity Feed */}
        {showActivityFeed && (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Real-Time Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[400px] pr-4">
                <div className="space-y-3">
                  {activityFeed.map((activity) => {
                    const Icon = activity.icon;
                    return (
                      <div key={activity.id} className="flex items-start gap-3 pb-3 border-b last:border-0">
                        <div className={`mt-1 ${getStatusColor(activity.type)}`}>
                          <Icon className="h-4 w-4" />
                        </div>
                        <div className="flex-1">
                          <p className="text-sm font-medium">
                            Job {activity.job} {activity.type}
                          </p>
                          <p className="text-xs text-muted-foreground">{activity.driver}</p>
                          <p className="text-xs text-muted-foreground mt-1">{activity.time}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        )}

        {/* My Jobs List */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">
              My Jobs ({activeJobs?.length || 0})
            </CardTitle>
            <CardDescription className="text-xs">
              Click to track on map
              {filters.searchQuery && ` - Filtered by: "${filters.searchQuery}"`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[300px] pr-4">
              <div className="space-y-2">
                 {!activeJobs || activeJobs.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground text-sm">
                    {filters.searchQuery ? `No my jobs matching "${filters.searchQuery}"` : 'No my jobs'}
                  </div>
                ) : (
                  activeJobs.map((job: any) => {
                    const assignment = job.job_assignments?.[0];
                    const driver = assignment?.driver;
                    const pickupLoc = job.pickup_location as any;
                    
                    return (
                      <div
                        key={job.id}
                        onClick={() => setSelectedJob(job)}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                          selectedJob?.id === job.id ? 'border-primary bg-primary/5' : 'hover:border-primary/50'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-mono text-xs font-semibold">#{job.id.slice(0, 8)}</span>
                          {getJobStatusBadge(job)}
                        </div>
                        <p className="text-sm font-medium truncate mb-1">{job.title || 'Untitled Job'}</p>
                        <p className="text-xs text-muted-foreground truncate">
                          {driver ? `Driver: ${driver.full_name}` : 'Unassigned'}
                        </p>
                        <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                          <MapPin className="h-3 w-3" />
                          <span className="truncate">{pickupLoc?.address || 'N/A'}</span>
                        </div>
                        {job.distance_miles && (
                          <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                            <Navigation className="h-3 w-3" />
                            <span>{job.distance_miles.toFixed(1)} miles</span>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={handleMessageDriver}
              disabled={!selectedJob}
            >
              <MessageSquare className="h-4 w-4 mr-2" />
              Message Driver
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={handleCallDriver}
              disabled={!selectedJob}
            >
              <Phone className="h-4 w-4 mr-2" />
              Call Driver
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={handleReportIssue}
              disabled={!selectedJob}
            >
              <AlertCircle className="h-4 w-4 mr-2" />
              Report Issue
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="w-full"
              onClick={() => setShowRouteDialog(true)}
              disabled={!selectedJob}
            >
              <MapPinned className="h-4 w-4 mr-2" />
              View Route
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Report Issue Dialog */}
      <Dialog open={showIssueDialog} onOpenChange={setShowIssueDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Report Issue</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {selectedJob && (
              <div className="text-sm text-muted-foreground">
                Job: #{selectedJob.id?.slice(0, 8)} - {selectedJob.title}
              </div>
            )}
            <Textarea
              placeholder="Describe the issue..."
              value={issueDescription}
              onChange={(e) => setIssueDescription(e.target.value)}
              rows={4}
            />
            <div className="flex gap-2">
              <Button onClick={handleSubmitIssue} className="flex-1">
                Submit Issue
              </Button>
              <Button 
                variant="outline" 
                onClick={() => {
                  setShowIssueDialog(false);
                  setIssueDescription('');
                }}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Route Dialog */}
      <Dialog open={showRouteDialog} onOpenChange={setShowRouteDialog}>
        <DialogContent className="max-w-4xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>
              {selectedJob ? `Route: ${selectedJob.title || `Job #${selectedJob.id?.slice(0, 8)}`}` : 'Job Route'}
            </DialogTitle>
          </DialogHeader>
          <div className="flex-1 h-full">
            {selectedJob && (
              <JobMapView
                pickupLocation={selectedJob.pickup_location}
                deliveryLocation={selectedJob.delivery_location}
                jobTitle={selectedJob.title}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
