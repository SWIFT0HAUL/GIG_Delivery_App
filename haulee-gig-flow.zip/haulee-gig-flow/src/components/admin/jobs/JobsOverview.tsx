import React, { useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Briefcase, CheckCircle, Clock, AlertTriangle, DollarSign, 
  TrendingUp, MapPin, Users, ArrowRight, Truck, Package, 
  MessageSquare, Route, BarChart3, Calendar
} from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar } from 'recharts';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';
import DriverCompletedJobs from '@/components/driver/DriverCompletedJobs';

interface JobsOverviewProps {
  filters: {
    searchQuery: string;
    roleFilter: string;
    dateRange: string;
  };
}

export const JobsOverview = ({ filters }: JobsOverviewProps) => {
  const queryClient = useQueryClient();

  // Setup realtime subscription for jobs table
  useEffect(() => {
    console.log('🔄 Setting up realtime subscriptions for job stats');

    const jobsChannel = supabase
      .channel('jobs-realtime-overview')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'jobs' },
        (payload) => {
          console.log('📊 Job change detected, refreshing stats:', payload);
          // Invalidate queries to trigger refetch
          queryClient.invalidateQueries({ queryKey: ['job-stats-comprehensive'] });
        }
      )
      .subscribe();

    // Also listen to job_assignments for assignment changes
    const assignmentsChannel = supabase
      .channel('job-assignments-realtime-overview')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'job_assignments' },
        (payload) => {
          console.log('📊 Assignment change detected, refreshing stats:', payload);
          queryClient.invalidateQueries({ queryKey: ['job-stats-comprehensive'] });
        }
      )
      .subscribe();

    return () => {
      console.log('🔄 Cleaning up realtime subscriptions for job stats');
      supabase.removeChannel(jobsChannel);
      supabase.removeChannel(assignmentsChannel);
    };
  }, [queryClient]);

  // Fetch comprehensive job statistics
  const { data: stats, isLoading } = useQuery({
    queryKey: ['job-stats-comprehensive', filters],
    queryFn: async () => {
      // Fetch all jobs with related data
      const { data: allJobs, error: jobsError } = await supabase
        .from('jobs')
        .select(`
          *,
          job_assignments(id, driver_id, status)
        `);
      
      if (jobsError) throw jobsError;

      // Fetch disputes
      const { data: disputes, error: disputesError } = await supabase
        .from('disputes')
        .select('id, status, created_at');
      
      if (disputesError) throw disputesError;

      // Fetch routes
      const { data: routes, error: routesError } = await supabase
        .from('routes')
        .select('id, status, driver_id');
      
      if (routesError) throw routesError;

      // Fetch active drivers
      const { data: drivers, error: driversError } = await supabase
        .from('driver_status')
        .select('driver_id, is_online');
      
      if (driversError) throw driversError;

      // Apply search filter
      const searchLower = filters.searchQuery.toLowerCase().trim();
      const jobs = searchLower 
        ? allJobs.filter(job => {
            if (job.id.toLowerCase().includes(searchLower)) return true;
            if (job.title?.toLowerCase().includes(searchLower)) return true;
            
            const pickupLoc = job.pickup_location as any;
            if (pickupLoc?.address?.toLowerCase().includes(searchLower)) return true;
            if (pickupLoc?.city?.toLowerCase().includes(searchLower)) return true;
            
            const deliveryLoc = job.delivery_location as any;
            if (deliveryLoc?.address?.toLowerCase().includes(searchLower)) return true;
            if (deliveryLoc?.city?.toLowerCase().includes(searchLower)) return true;
            
            return false;
          })
        : allJobs;

      // Calculate date range for weekly trend
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = subDays(new Date(), 6 - i);
        return {
          date: startOfDay(date),
          dayName: format(date, 'EEE')
        };
      });

      // Calculate weekly trend from actual data
      const weeklyTrend = last7Days.map(({ date, dayName }) => {
        const dayStart = startOfDay(date);
        const dayEnd = endOfDay(date);
        const jobsCount = jobs.filter(j => {
          const createdAt = new Date(j.created_at);
          return createdAt >= dayStart && createdAt <= dayEnd;
        }).length;
        return { day: dayName, jobs: jobsCount };
      });

      // Calculate comprehensive statistics with actual platform statuses
      const posted = jobs.filter(j => j.status === 'posted').length;
      const claimed = jobs.filter(j => j.status === 'claimed').length;
      const assigned = jobs.filter(j => j.status === 'assigned').length;
      const planned = jobs.filter(j => j.status === 'planned').length;
      const inProgress = jobs.filter(j => j.status === 'in_progress').length;
      const pickedUp = jobs.filter(j => ['picked_up', 'PickedUp'].includes(j.status)).length;
      const inTransit = jobs.filter(j => j.status === 'in_transit').length;
      const delivered = jobs.filter(j => j.status === 'delivered').length;
      const cancelled = jobs.filter(j => j.status === 'cancelled').length;
      const delayed = jobs.filter(j => j.status === 'delayed').length;
      const onHold = jobs.filter(j => j.status === 'on_hold').length;
      
      const completedToday = jobs.filter(j => {
        const today = new Date().toDateString();
        return j.status === 'delivered' && new Date(j.completed_at || j.updated_at).toDateString() === today;
      }).length;
      
      // Active jobs are those in progress, picked up, or in transit
      const activeJobs = inProgress + pickedUp + inTransit;
      
      const totalEarnings = jobs
        .filter(j => j.status === 'delivered')
        .reduce((sum, j) => sum + (Number(j.pay_amount) || 0), 0);
      
      const pendingEarnings = jobs
        .filter(j => ['in_progress', 'assigned', 'picked_up', 'PickedUp', 'posted', 'claimed', 'planned', 'in_transit'].includes(j.status))
        .reduce((sum, j) => sum + (Number(j.pay_amount) || 0), 0);

      // Priority distribution
      const priorityBreakdown = [
        { name: 'Pickup Now', value: jobs.filter(j => j.priority === 'pickup_now').length, color: '#ef4444' },
        { name: 'Scheduled', value: jobs.filter(j => j.priority === 'scheduled').length, color: '#3b82f6' },
        { name: 'Route', value: jobs.filter(j => j.priority === 'route').length, color: '#8b5cf6' },
      ];

      // Driver statistics
      const onlineDrivers = drivers?.filter(d => d.is_online).length || 0;
      const totalDrivers = drivers?.length || 0;
      const activeDrivers = new Set(jobs.filter(j => j.assigned_driver_id).map(j => j.assigned_driver_id)).size;

      // Dispute statistics
      const openDisputes = disputes?.filter(d => d.status === 'open').length || 0;
      const resolvedDisputes = disputes?.filter(d => d.status === 'resolved').length || 0;
      
      // Route statistics
      const activeRoutes = routes?.filter(r => r.status === 'active').length || 0;

      return {
        // Main KPIs
        activeJobs,
        completedToday,
        delayed,
        totalEarnings,
        pendingEarnings,
        totalJobs: jobs.length,
        
        // Status breakdown
        posted,
        claimed,
        assigned,
        planned,
        inProgress,
        pickedUp,
        inTransit,
        delivered,
        cancelled,
        onHold,
        
        // Driver stats
        onlineDrivers,
        totalDrivers,
        activeDrivers,
        
        // Other stats
        openDisputes,
        resolvedDisputes,
        activeRoutes,
        
        // Charts data - Active jobs status (current workflow)
        statusDistribution: [
          { name: 'Claimed', value: claimed, color: '#ec4899', status: 'claimed' },
          { name: 'Assigned', value: assigned, color: '#6366f1', status: 'assigned' },
          { name: 'Planned', value: planned, color: '#8b5cf6', status: 'planned' },
          { name: 'In Progress', value: inProgress, color: '#10b981', status: 'in_progress' },
          { name: 'Picked Up', value: pickedUp, color: '#14b8a6', status: 'picked_up' },
          { name: 'In Transit', value: inTransit, color: '#06b6d4', status: 'in_transit' },
          { name: 'Delayed', value: delayed, color: '#f97316', status: 'delayed' },
          { name: 'On Hold', value: onHold, color: '#f59e0b', status: 'on_hold' },
        ].filter(s => s.value > 0),
        allStatusDistribution: [
          { name: 'Posted', value: posted, color: '#94a3b8' },
          { name: 'Claimed', value: claimed, color: '#ec4899' },
          { name: 'Assigned', value: assigned, color: '#6366f1' },
          { name: 'Planned', value: planned, color: '#8b5cf6' },
          { name: 'In Progress', value: inProgress, color: '#10b981' },
          { name: 'Picked Up', value: pickedUp, color: '#14b8a6' },
          { name: 'In Transit', value: inTransit, color: '#06b6d4' },
          { name: 'Delivered', value: delivered, color: '#3b82f6' },
          { name: 'Cancelled', value: cancelled, color: '#ef4444' },
          { name: 'Delayed', value: delayed, color: '#f97316' },
          { name: 'On Hold', value: onHold, color: '#f59e0b' },
        ].filter(s => s.value > 0),
        priorityBreakdown,
        weeklyTrend,
      };
    },
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
          {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-32" />)}
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-80" />
          <Skeleton className="h-80" />
        </div>
      </div>
    );
  }

  const kpiCards = [
    { title: 'Active Jobs', value: stats?.activeJobs || 0, icon: Briefcase, color: 'text-blue-500', bgColor: 'bg-blue-50 dark:bg-blue-950', subtitle: `${stats?.pickedUp || 0} picked up` },
    { title: 'Completed Today', value: stats?.completedToday || 0, icon: CheckCircle, color: 'text-green-500', bgColor: 'bg-green-50 dark:bg-green-950', subtitle: `${stats?.delivered || 0} total delivered` },
    { title: 'Posted Jobs', value: stats?.posted || 0, icon: Clock, color: 'text-orange-500', bgColor: 'bg-orange-50 dark:bg-orange-950', subtitle: `${stats?.claimed || 0} claimed` },
    { title: 'Delayed', value: stats?.delayed || 0, icon: AlertTriangle, color: 'text-red-500', bgColor: 'bg-red-50 dark:bg-red-950', subtitle: 'Needs attention' },
    { title: 'Revenue (Completed)', value: `$${(stats?.totalEarnings || 0).toLocaleString()}`, icon: DollarSign, color: 'text-emerald-500', bgColor: 'bg-emerald-50 dark:bg-emerald-950', subtitle: `$${(stats?.pendingEarnings || 0).toLocaleString()} pending` },
  ];

  const secondaryKpis = [
    { title: 'Active Drivers', value: `${stats?.activeDrivers || 0}/${stats?.onlineDrivers || 0}`, icon: Users, color: 'text-indigo-500', bgColor: 'bg-indigo-50 dark:bg-indigo-950', subtitle: `${stats?.totalDrivers || 0} total drivers` },
    { title: 'Active Routes', value: stats?.activeRoutes || 0, icon: Route, color: 'text-purple-500', bgColor: 'bg-purple-50 dark:bg-purple-950', subtitle: 'In progress' },
    { title: 'Open Disputes', value: stats?.openDisputes || 0, icon: MessageSquare, color: 'text-yellow-500', bgColor: 'bg-yellow-50 dark:bg-yellow-950', subtitle: `${stats?.resolvedDisputes || 0} resolved` },
    { title: 'Assigned Jobs', value: stats?.assigned || 0, icon: Truck, color: 'text-cyan-500', bgColor: 'bg-cyan-50 dark:bg-cyan-950', subtitle: 'Awaiting pickup' },
  ];

  return (
    <div className="space-y-6">
      {filters.searchQuery && (
        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="text-sm">
            Showing results for: <span className="font-semibold">"{filters.searchQuery}"</span>
            {stats && ` - ${stats.totalJobs} job(s) found`}
          </p>
        </div>
      )}

      {/* Primary KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-5">
        {kpiCards.map((card, index) => {
          const Icon = card.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <div className={`${card.bgColor} p-3 rounded-lg`}>
                    <Icon className={`h-6 w-6 ${card.color}`} />
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                  <p className="text-2xl font-bold mt-1">{card.value}</p>
                  {card.subtitle && (
                    <p className="text-xs text-muted-foreground mt-1">{card.subtitle}</p>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Secondary KPI Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {secondaryKpis.map((card, index) => {
          const Icon = card.icon;
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className={`${card.bgColor} p-2.5 rounded-lg`}>
                    <Icon className={`h-5 w-5 ${card.color}`} />
                  </div>
                  <div className="flex-1">
                    <p className="text-xs font-medium text-muted-foreground">{card.title}</p>
                    <p className="text-xl font-bold">{card.value}</p>
                    {card.subtitle && (
                      <p className="text-xs text-muted-foreground">{card.subtitle}</p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid gap-4 md:grid-cols-3">
        {/* Active Jobs Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Active Jobs Status</CardTitle>
            <CardDescription>Jobs in active workflow stages</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={stats?.statusDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => entry.value > 0 ? `${entry.name}: ${entry.value}` : ''}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {stats?.statusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Complete Status Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>All Status Breakdown</CardTitle>
            <CardDescription>Complete overview of all job statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats?.allStatusDistribution}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8884d8">
                  {stats?.allStatusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Weekly Job Trend */}
        <Card>
          <CardHeader>
            <CardTitle>7-Day Job Trend</CardTitle>
            <CardDescription>Jobs created per day (last 7 days)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={stats?.weeklyTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="jobs" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  dot={{ fill: '#3b82f6', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Priority Distribution */}
      {stats?.priorityBreakdown && stats.priorityBreakdown.some(p => p.value > 0) && (
        <Card>
          <CardHeader>
            <CardTitle>Job Priority Distribution</CardTitle>
            <CardDescription>Breakdown by priority type</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-4">
              {stats.priorityBreakdown.map((priority, index) => (
                <div key={index} className="text-center p-4 rounded-lg border">
                  <div className="text-3xl font-bold" style={{ color: priority.color }}>
                    {priority.value}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">{priority.name}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Tools */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">View Problem Jobs</h3>
                <p className="text-sm text-muted-foreground mt-1">Review delayed or at-risk deliveries</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">Dispatch Center</h3>
                <p className="text-sm text-muted-foreground mt-1">Assign jobs to available drivers</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow cursor-pointer">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold">Create New Job</h3>
                <p className="text-sm text-muted-foreground mt-1">Post a new delivery job</p>
              </div>
              <ArrowRight className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Status Legend & Summary */}
      <Card>
        <CardHeader>
          <CardTitle>System Overview</CardTitle>
          <CardDescription>Real-time platform statistics and health metrics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-gray-500" />
                <span className="text-sm font-medium">Posted</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.posted || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-pink-500" />
                <span className="text-sm font-medium">Claimed</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.claimed || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-indigo-500" />
                <span className="text-sm font-medium">Assigned</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.assigned || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-purple-500" />
                <span className="text-sm font-medium">Planned</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.planned || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-green-500" />
                <span className="text-sm font-medium">In Progress</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.inProgress || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-teal-500" />
                <span className="text-sm font-medium">Picked Up</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.pickedUp || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-cyan-500" />
                <span className="text-sm font-medium">In Transit</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.inTransit || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-blue-500" />
                <span className="text-sm font-medium">Delivered</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.delivered || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-orange-500" />
                <span className="text-sm font-medium">Delayed</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.delayed || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-yellow-500" />
                <span className="text-sm font-medium">On Hold</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.onHold || 0}</p>
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-red-500" />
                <span className="text-sm font-medium">Cancelled</span>
              </div>
              <p className="text-2xl font-bold pl-5">{stats?.cancelled || 0}</p>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Last updated:</span>
              <Badge variant="outline" className="gap-1">
                <Clock className="h-3 w-3" />
                Live (refreshes every 30s)
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Completed Jobs Table */}
      <DriverCompletedJobs />
    </div>
  );
};
