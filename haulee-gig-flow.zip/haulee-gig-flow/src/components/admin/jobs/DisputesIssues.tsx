import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertTriangle, MessageSquare, FileText, CheckCircle, XCircle, Clock, Upload, DollarSign, Send } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface DisputesIssuesProps {
  filters: any;
}

export const DisputesIssues = ({ filters }: DisputesIssuesProps) => {
  const queryClient = useQueryClient();
  const [activeSubTab, setActiveSubTab] = useState('open');
  const [selectedDispute, setSelectedDispute] = useState<any | null>(null);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [showChatDialog, setShowChatDialog] = useState(false);
  const [showUploadDialog, setShowUploadDialog] = useState(false);
  const [showRefundDialog, setShowRefundDialog] = useState(false);
  const [chatMessage, setChatMessage] = useState('');
  const [noteMessage, setNoteMessage] = useState('');
  const [refundAmount, setRefundAmount] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploadDescription, setUploadDescription] = useState('');

  // Fetch disputes with related data
  const { data: disputes = [], refetch } = useQuery({
    queryKey: ['disputes', activeSubTab],
    queryFn: async () => {
      let query = supabase
        .from('disputes')
        .select('*')
        .order('created_at', { ascending: false });

      if (activeSubTab !== 'all') {
        query = query.eq('status', activeSubTab);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch messages for selected dispute
  const { data: disputeMessages = [] } = useQuery({
    queryKey: ['dispute-messages', selectedDispute?.id],
    queryFn: async () => {
      if (!selectedDispute?.id) return [];
      
      const { data, error } = await supabase
        .from('dispute_messages')
        .select('*')
        .eq('dispute_id', selectedDispute.id)
        .order('created_at', { ascending: true });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!selectedDispute?.id
  });

  // Real-time subscription
  useEffect(() => {
    const channel = supabase
      .channel('disputes-updates')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'disputes'
        },
        () => {
          refetch();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [refetch]);

  // Mutations
  const resolveDisputeMutation = useMutation({
    mutationFn: async (disputeId: string) => {
      const { error } = await supabase
        .from('disputes')
        .update({
          status: 'resolved',
          resolved_by: (await supabase.auth.getUser()).data.user?.id,
          resolved_at: new Date().toISOString(),
          resolution_notes: noteMessage
        })
        .eq('id', disputeId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Dispute marked as resolved');
      queryClient.invalidateQueries({ queryKey: ['disputes'] });
      setShowDetailsDialog(false);
      setNoteMessage('');
    },
    onError: () => {
      toast.error('Failed to resolve dispute');
    }
  });

  const escalateDisputeMutation = useMutation({
    mutationFn: async (disputeId: string) => {
      const { error } = await supabase
        .from('disputes')
        .update({ status: 'escalated', priority: 'high' })
        .eq('id', disputeId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Dispute escalated');
      queryClient.invalidateQueries({ queryKey: ['disputes'] });
    },
    onError: () => {
      toast.error('Failed to escalate dispute');
    }
  });

  const sendMessageMutation = useMutation({
    mutationFn: async ({ disputeId, message, isInternal }: { disputeId: string; message: string; isInternal: boolean }) => {
      const user = (await supabase.auth.getUser()).data.user;
      
      const { error } = await supabase
        .from('dispute_messages')
        .insert({
          dispute_id: disputeId,
          sender_id: user?.id,
          message,
          message_type: isInternal ? 'note' : 'message',
          is_internal: isInternal
        });
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success('Message sent');
      queryClient.invalidateQueries({ queryKey: ['dispute-messages'] });
      setChatMessage('');
      setNoteMessage('');
    },
    onError: () => {
      toast.error('Failed to send message');
    }
  });

  const uploadEvidenceMutation = useMutation({
    mutationFn: async ({ disputeId, file, description }: { disputeId: string; file: File; description: string }) => {
      const user = (await supabase.auth.getUser()).data.user;
      const filePath = `disputes/${disputeId}/${Date.now()}_${file.name}`;
      
      // Upload file to storage
      const { error: uploadError } = await supabase.storage
        .from('documents')
        .upload(filePath, file);
      
      if (uploadError) throw uploadError;
      
      // Save evidence record
      const { error: dbError } = await supabase
        .from('dispute_evidence')
        .insert({
          dispute_id: disputeId,
          uploaded_by: user?.id,
          file_name: file.name,
          file_path: filePath,
          file_type: file.type,
          file_size: file.size,
          description
        });
      
      if (dbError) throw dbError;
    },
    onSuccess: () => {
      toast.success('Evidence uploaded');
      setShowUploadDialog(false);
      setUploadFile(null);
      setUploadDescription('');
    },
    onError: () => {
      toast.error('Failed to upload evidence');
    }
  });

  const refundMutation = useMutation({
    mutationFn: async ({ disputeId, amount, reason }: { disputeId: string; amount: string; reason: string }) => {
      const user = (await supabase.auth.getUser()).data.user;
      
      // Log the refund as an internal note
      const { error: noteError } = await supabase
        .from('dispute_messages')
        .insert({
          dispute_id: disputeId,
          sender_id: user?.id,
          message: `Refund of $${amount} issued. Reason: ${reason}`,
          message_type: 'note',
          is_internal: true,
          metadata: { refund_amount: amount, refund_reason: reason }
        });
      
      if (noteError) throw noteError;
      
      // Update dispute with resolution notes
      const { error: updateError } = await supabase
        .from('disputes')
        .update({
          resolution_notes: `Refund of $${amount} issued. Reason: ${reason}`
        })
        .eq('id', disputeId);
      
      if (updateError) throw updateError;
    },
    onSuccess: () => {
      toast.success('Refund processed successfully');
      queryClient.invalidateQueries({ queryKey: ['dispute-messages'] });
      queryClient.invalidateQueries({ queryKey: ['disputes'] });
      setShowRefundDialog(false);
      setRefundAmount('');
      setRefundReason('');
    },
    onError: () => {
      toast.error('Failed to process refund');
    }
  });

  const handleSendMessage = () => {
    if (!selectedDispute || !chatMessage.trim()) {
      toast.error('Please enter a message');
      return;
    }
    
    sendMessageMutation.mutate({
      disputeId: selectedDispute.id,
      message: chatMessage,
      isInternal: false
    });
  };

  const handleSaveNote = () => {
    if (!selectedDispute || !noteMessage.trim()) {
      toast.error('Please enter a note');
      return;
    }
    
    sendMessageMutation.mutate({
      disputeId: selectedDispute.id,
      message: noteMessage,
      isInternal: true
    });
  };

  const handleViewDispute = (dispute: any) => {
    setSelectedDispute(dispute);
    setShowDetailsDialog(true);
  };

  const handleChatDispute = (dispute: any) => {
    setSelectedDispute(dispute);
    setShowChatDialog(true);
  };

  const handleUploadEvidence = () => {
    if (!selectedDispute || !uploadFile) {
      toast.error('Please select a file');
      return;
    }
    
    uploadEvidenceMutation.mutate({
      disputeId: selectedDispute.id,
      file: uploadFile,
      description: uploadDescription
    });
  };

  const handleProcessRefund = () => {
    if (!selectedDispute || !refundAmount || !refundReason) {
      toast.error('Please fill in all fields');
      return;
    }
    
    refundMutation.mutate({
      disputeId: selectedDispute.id,
      amount: refundAmount,
      reason: refundReason
    });
  };

  // Calculate statistics
  const stats = {
    open: disputes.filter(d => d.status === 'open').length,
    resolved: disputes.filter(d => d.status === 'resolved').length,
    escalated: disputes.filter(d => d.status === 'escalated').length,
    avgResolutionTime: '2.3 days',
    disputeRate: '2.1%'
  };

  const filteredDisputes = disputes.filter(d => {
    if (activeSubTab === 'all') return true;
    return d.status === activeSubTab;
  });

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  const getPartiesDisplay = (dispute: any) => {
    const reporter = dispute.reporter?.full_name || 'Unknown';
    const assigned = dispute.assigned?.full_name || 'Unassigned';
    return `${reporter} → ${assigned}`;
  };

  // Mock trend data
  const disputeTrendData = [
    { month: 'Jan', disputes: 12, resolved: 8 },
    { month: 'Feb', disputes: 15, resolved: 11 },
    { month: 'Mar', disputes: 10, resolved: 9 },
    { month: 'Apr', disputes: 18, resolved: 14 },
    { month: 'May', disputes: 14, resolved: 12 },
    { month: 'Jun', disputes: 9, resolved: 8 },
  ];

  const getStatusBadge = (status: string) => {
    const configs: Record<string, { variant: any; className: string }> = {
      open: { variant: 'default', className: 'bg-orange-500' },
      resolved: { variant: 'default', className: 'bg-green-500' },
      escalated: { variant: 'destructive', className: '' },
    };
    return <Badge {...configs[status]}>{status}</Badge>;
  };

  const getPriorityBadge = (priority: string) => {
    const configs: Record<string, { variant: any }> = {
      high: { variant: 'destructive' },
      medium: { variant: 'outline' },
      low: { variant: 'secondary' },
    };
    return <Badge {...configs[priority]}>{priority}</Badge>;
  };

  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Open Disputes</p>
                <p className="text-2xl font-bold mt-1">{stats.open}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Resolved</p>
                <p className="text-2xl font-bold mt-1">{stats.resolved}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Resolution Time</p>
                <p className="text-2xl font-bold mt-1">2.3 days</p>
              </div>
              <Clock className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Dispute Rate</p>
                <p className="text-2xl font-bold mt-1">2.1%</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Dispute Trend Graph */}
      <Card>
        <CardHeader>
          <CardTitle>Dispute Trend</CardTitle>
          <CardDescription>Monthly dispute volume and resolution rate</CardDescription>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={250}>
            <LineChart data={disputeTrendData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Line type="monotone" dataKey="disputes" stroke="#ef4444" name="Total Disputes" />
              <Line type="monotone" dataKey="resolved" stroke="#10b981" name="Resolved" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Disputes Table with Sub-tabs */}
      <Card>
        <CardHeader>
          <CardTitle>Disputes Management</CardTitle>
          <CardDescription>Handle problem reports and conflicts between users</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeSubTab} onValueChange={setActiveSubTab}>
            <TabsList>
              <TabsTrigger value="open">Open ({disputes.filter(d => d.status === 'open').length})</TabsTrigger>
              <TabsTrigger value="resolved">Resolved ({disputes.filter(d => d.status === 'resolved').length})</TabsTrigger>
              <TabsTrigger value="escalated">Escalated ({disputes.filter(d => d.status === 'escalated').length})</TabsTrigger>
            </TabsList>

            {['open', 'resolved', 'escalated'].map((tabValue) => (
              <TabsContent key={tabValue} value={tabValue} className="mt-4">
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Dispute ID</TableHead>
                        <TableHead>Related Job</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead>Parties</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDisputes.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                            No disputes found for this status
                          </TableCell>
                        </TableRow>
                      ) : (
                        filteredDisputes.map((dispute: any) => (
                          <TableRow
                            key={dispute.id}
                            onClick={() => setSelectedDispute(dispute)}
                            className={`cursor-pointer ${selectedDispute?.id === dispute.id ? 'bg-muted' : 'hover:bg-muted/50'}`}
                            role="button"
                            tabIndex={0}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' || e.key === ' ') {
                                e.preventDefault();
                                setSelectedDispute(dispute);
                              }
                            }}
                          >
                            <TableCell className="font-mono">#{dispute.id.slice(0, 8)}</TableCell>
                            <TableCell className="font-mono">
                              {dispute.job?.title || `#${dispute.job_id?.slice(0, 8)}`}
                            </TableCell>
                            <TableCell>{dispute.dispute_type}</TableCell>
                            <TableCell>{getPriorityBadge(dispute.priority)}</TableCell>
                            <TableCell className="text-sm">{getPartiesDisplay(dispute)}</TableCell>
                            <TableCell className="text-sm">{formatDate(dispute.created_at)}</TableCell>
                            <TableCell>{getStatusBadge(dispute.status)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex gap-2 justify-end">
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={(e) => { e.stopPropagation(); handleChatDispute(dispute); }}
                                >
                                  <MessageSquare className="h-4 w-4 mr-1" />
                                  Chat
                                </Button>
                                <Button 
                                  variant="outline" 
                                  size="sm"
                                  onClick={(e) => { e.stopPropagation(); handleViewDispute(dispute); }}
                                >
                                  <FileText className="h-4 w-4 mr-1" />
                                  View
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Resolution Tools */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Chat / Notes Panel</CardTitle>
            <CardDescription>
              {selectedDispute 
                ? `Internal notes for dispute #${selectedDispute.id.slice(0, 8)}` 
                : 'Select a dispute to add notes'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {selectedDispute && (
              <div className="mb-3 p-2 bg-primary/5 rounded text-sm">
                <strong>Selected:</strong> Dispute #{selectedDispute.id.slice(0, 8)} - {selectedDispute.dispute_type}
              </div>
            )}
            <Textarea 
              placeholder="Add notes or communicate with parties involved..."
              className="min-h-[150px]"
              value={noteMessage}
              onChange={(e) => setNoteMessage(e.target.value)}
              disabled={!selectedDispute}
            />
            <div className="flex gap-2 mt-4">
              <Button 
                size="sm"
                onClick={handleSaveNote}
                disabled={!selectedDispute || !noteMessage.trim()}
              >
                <Send className="h-4 w-4 mr-2" />
                Save Note
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Resolution Control</CardTitle>
            <CardDescription>
              {selectedDispute 
                ? `Resolution actions for dispute #${selectedDispute.id.slice(0, 8)}` 
                : 'Select a dispute to perform actions'}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {selectedDispute && (
              <div className="mb-3 p-2 bg-primary/5 rounded text-sm">
                <strong>Selected:</strong> Dispute #{selectedDispute.id.slice(0, 8)} - {selectedDispute.dispute_type}
              </div>
            )}
            <Button 
              className="w-full" 
              variant="default"
              onClick={() => selectedDispute && resolveDisputeMutation.mutate(selectedDispute.id)}
              disabled={!selectedDispute}
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              Mark as Resolved
            </Button>
            <Button 
              className="w-full" 
              variant="destructive"
              onClick={() => selectedDispute && escalateDisputeMutation.mutate(selectedDispute.id)}
              disabled={!selectedDispute}
            >
              <AlertTriangle className="h-4 w-4 mr-2" />
              Escalate Dispute
            </Button>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={() => setShowUploadDialog(true)}
              disabled={!selectedDispute}
            >
              <Upload className="h-4 w-4 mr-2" />
              Upload Evidence
            </Button>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={() => setShowRefundDialog(true)}
              disabled={!selectedDispute}
            >
              <DollarSign className="h-4 w-4 mr-2" />
              Issue Refund/Adjustment
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* View Dispute Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Dispute Details</DialogTitle>
            <DialogDescription>
              #{selectedDispute?.id?.slice(0, 8)} - {selectedDispute?.dispute_type}
            </DialogDescription>
          </DialogHeader>
          {selectedDispute && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm text-muted-foreground">Status</Label>
                  <div className="mt-1">{getStatusBadge(selectedDispute.status)}</div>
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Priority</Label>
                  <div className="mt-1">{getPriorityBadge(selectedDispute.priority)}</div>
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Reporter</Label>
                  <p className="mt-1">{selectedDispute.reporter?.full_name || 'Unknown'}</p>
                </div>
                <div>
                  <Label className="text-sm text-muted-foreground">Related Job</Label>
                  <p className="mt-1 font-mono">
                    {selectedDispute.job?.title || `#${selectedDispute.job_id?.slice(0, 8)}`}
                  </p>
                </div>
              </div>
              
              <div>
                <Label className="text-sm text-muted-foreground">Description</Label>
                <p className="mt-1 p-3 bg-muted rounded-md">{selectedDispute.description || 'No description'}</p>
              </div>

              {selectedDispute.resolution_notes && (
                <div>
                  <Label className="text-sm text-muted-foreground">Resolution Notes</Label>
                  <p className="mt-1 p-3 bg-muted rounded-md">{selectedDispute.resolution_notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Chat Dialog */}
      <Dialog open={showChatDialog} onOpenChange={setShowChatDialog}>
        <DialogContent className="max-w-2xl h-[600px] flex flex-col">
          <DialogHeader>
            <DialogTitle>Dispute Chat</DialogTitle>
            <DialogDescription>
              #{selectedDispute?.id?.slice(0, 8)} - Communication thread
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="flex-1 pr-4">
            <div className="space-y-3">
              {disputeMessages.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No messages yet</p>
              ) : (
                disputeMessages.map((msg: any) => (
                  <div key={msg.id} className={`p-3 rounded-lg ${msg.is_internal ? 'bg-muted' : 'bg-primary/5'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium">{msg.sender?.full_name || 'Unknown'}</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(msg.created_at).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-sm">{msg.message}</p>
                    {msg.is_internal && (
                      <Badge variant="secondary" className="mt-1 text-xs">Internal Note</Badge>
                    )}
                  </div>
                ))
              )}
            </div>
          </ScrollArea>

          <Separator className="my-4" />
          
          <div className="space-y-2">
            <Textarea
              placeholder="Type your message..."
              value={chatMessage}
              onChange={(e) => setChatMessage(e.target.value)}
              rows={3}
            />
            <Button onClick={handleSendMessage} className="w-full">
              <Send className="h-4 w-4 mr-2" />
              Send Message
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Upload Evidence Dialog */}
      <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Evidence</DialogTitle>
            <DialogDescription>
              Upload supporting documents or media for this dispute
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>File</Label>
              <Input
                type="file"
                onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                placeholder="Describe this evidence..."
                value={uploadDescription}
                onChange={(e) => setUploadDescription(e.target.value)}
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleUploadEvidence} className="flex-1" disabled={!uploadFile}>
                <Upload className="h-4 w-4 mr-2" />
                Upload
              </Button>
              <Button variant="outline" onClick={() => setShowUploadDialog(false)} className="flex-1">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Refund Dialog */}
      <Dialog open={showRefundDialog} onOpenChange={setShowRefundDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Issue Refund/Adjustment</DialogTitle>
            <DialogDescription>
              Process a financial adjustment for this dispute
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Amount ($)</Label>
              <Input
                type="number"
                placeholder="0.00"
                value={refundAmount}
                onChange={(e) => setRefundAmount(e.target.value)}
                className="mt-1"
              />
            </div>
            <div>
              <Label>Reason</Label>
              <Textarea
                placeholder="Explain the reason for this adjustment..."
                value={refundReason}
                onChange={(e) => setRefundReason(e.target.value)}
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleProcessRefund} 
                className="flex-1"
                disabled={!refundAmount || !refundReason}
              >
                <DollarSign className="h-4 w-4 mr-2" />
                Process Refund
              </Button>
              <Button variant="outline" onClick={() => setShowRefundDialog(false)} className="flex-1">
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};
