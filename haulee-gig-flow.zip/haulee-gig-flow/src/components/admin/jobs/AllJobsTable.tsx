import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Eye, Edit, XCircle, MapPin, MoreHorizontal, Download, Send, Users, Search } from 'lucide-react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { AdminJobDetailsDialog } from '@/components/admin/AdminJobDetailsDialog';
import { JobEditDialog } from './JobEditDialog';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { JobStatusIndicator, PriorityIndicator } from '@/components/job/JobStatusIndicator';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface AllJobsTableProps {
  filters: {
    searchQuery: string;
    roleFilter: string;
    dateRange: string;
    statusFilter?: string;
  };
  selectedJobIds?: string[];
  onSelectionChange?: (ids: string[]) => void;
  onBulkActionsClick?: () => void;
}

type JobWithAssignments = {
  id: string;
  status: string;
  title: string;
  pickup_location: any;
  delivery_location: any;
  pay_amount: number | null;
  created_at: string;
  updated_at: string;
  created_by?: string | null;
  creator?: {
    id: string;
    full_name: string | null;
    email: string | null;
    role_key: string | null;
    company_name?: string | null;
  } | null;
  assigned_driver_id?: string | null;
  assigned_driver?: {
    id: string;
    full_name: string | null;
    email: string | null;
    role_key: string | null;
  } | null;
  job_assignments?: Array<{
    id: string;
    driver_id: string;
    status: string;
    assigned_at: string;
    driver?: {
      id: string;
      full_name: string | null;
      email: string | null;
      role_key: string | null;
    };
  }>;
  [key: string]: any;
};

export const AllJobsTable = ({ filters, selectedJobIds = [], onSelectionChange, onBulkActionsClick }: AllJobsTableProps) => {
  const statusFilter = filters.statusFilter || 'all';
  const [paymentFilter, setPaymentFilter] = useState('all');
  const [selectedJobForDetails, setSelectedJobForDetails] = useState<any>(null);
  const [selectedJobForEdit, setSelectedJobForEdit] = useState<any>(null);
  const [jobToCancel, setJobToCancel] = useState<any>(null);
  const [jobStatuses, setJobStatuses] = useState<Record<string, string>>({});
  const [assigningJob, setAssigningJob] = useState<any>(null);
  const [selectedDriver, setSelectedDriver] = useState<string>("");
  const [driverSearchQuery, setDriverSearchQuery] = useState<string>("");
  const queryClient = useQueryClient();

  // Extract city and state from address
  const getLocationShort = (location: any) => {
    if (!location?.address) return 'N/A';
    const parts = location.address.split(',').map((p: string) => p.trim());
    if (parts.length >= 2) {
      // Get last two parts (typically city, state)
      return `${parts[parts.length - 2]}, ${parts[parts.length - 1]}`;
    }
    return location.address;
  };

  const { data: jobs, isLoading } = useQuery<JobWithAssignments[]>({
    queryKey: ['all-jobs', filters, statusFilter, paymentFilter],
    queryFn: async () => {
      let query = supabase
        .from('jobs')
        .select(`
          *,
          job_assignments(
            id,
            driver_id,
            status,
            assigned_at
          )
        `)
        .order('created_at', { ascending: false });

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data: jobsData, error } = await query;
      if (error) throw error;

      // Apply role filter if specified
      let filteredJobsData = jobsData || [];
      if (filters.roleFilter && filters.roleFilter !== 'all') {
        // Fetch creator profiles to filter by role
        const creatorIds = [...new Set(filteredJobsData.map(job => job.created_by).filter(Boolean))];
        if (creatorIds.length > 0) {
          const { data: creatorsData } = await supabase
            .from('profiles')
            .select('id, role_key')
            .in('id', creatorIds);

          const roleCreatorIds = new Set(
            creatorsData?.filter(p => p.role_key === filters.roleFilter).map(p => p.id) || []
          );

          filteredJobsData = filteredJobsData.filter(job => 
            job.created_by && roleCreatorIds.has(job.created_by)
          );
        } else {
          filteredJobsData = [];
        }
      }

      // Fetch driver and creator details
      if (filteredJobsData.length > 0) {
        const driverIds = new Set<string>();
        const creatorIds = new Set<string>();
        
        // Collect driver IDs from assigned_driver_id field
        filteredJobsData.forEach(job => {
          if (job.assigned_driver_id) {
            driverIds.add(job.assigned_driver_id);
          }
          // Collect creator IDs
          if (job.created_by) {
            creatorIds.add(job.created_by);
          }
        });
        
        // Collect driver IDs from job_assignments
        filteredJobsData
          .flatMap(job => job.job_assignments || [])
          .forEach(assignment => {
            if (assignment.driver_id) {
              driverIds.add(assignment.driver_id);
            }
          });

        // Fetch all profiles (drivers and creators)
        const allUserIds = Array.from(new Set([...driverIds, ...creatorIds]));
        if (allUserIds.length > 0) {
          const { data: profilesData } = await supabase
            .from('profiles')
            .select('id, full_name, email, role_key')
            .in('id', allUserIds);

          // Fetch company names for business roles
          const businessRoleIds = profilesData?.filter(p => 
            ['carrier', 'broker', 'shipper', 'vendor'].includes(p.role_key || '')
          ).map(p => p.id) || [];

          let companyNamesMap = new Map<string, string>();
          
          if (businessRoleIds.length > 0) {
            console.log('🏢 Fetching company names for business role IDs:', businessRoleIds);
            
            // Fetch carrier company names
            const { data: carrierCompanies, error: carrierError } = await supabase
              .from('carrier_company_status')
              .select('user_id, company_name')
              .in('user_id', businessRoleIds);
            
            if (carrierError) {
              console.error('Error fetching carrier companies:', carrierError);
            } else {
              console.log('✅ Carrier companies fetched:', carrierCompanies);
            }
            
            carrierCompanies?.forEach(c => {
              if (c.company_name) companyNamesMap.set(c.user_id, c.company_name);
            });

            // Fetch broker company names
            const { data: brokerCompanies, error: brokerError } = await supabase
              .from('broker_profiles')
              .select('user_id, brokerage_name')
              .in('user_id', businessRoleIds);
            
            if (brokerError) {
              console.error('Error fetching broker companies:', brokerError);
            } else {
              console.log('✅ Broker companies fetched:', brokerCompanies);
            }
            
            brokerCompanies?.forEach(b => {
              if (b.brokerage_name) companyNamesMap.set(b.user_id, b.brokerage_name);
            });

            console.log('🏢 Company names map:', Array.from(companyNamesMap.entries()));
          }

          // Merge profile data with company names - FIX: Correct Map construction
          const profilesMap = new Map(profilesData?.map(p => [p.id, {
            ...p,
            company_name: companyNamesMap.get(p.id) || null
          }]));
          
          console.log('👤 Profiles with company names:', Array.from(profilesMap.entries()));

          return filteredJobsData.map(job => ({
            ...job,
            creator: job.created_by ? profilesMap.get(job.created_by) : null,
            assigned_driver: job.assigned_driver_id ? profilesMap.get(job.assigned_driver_id) : null,
            job_assignments: job.job_assignments?.map(assignment => ({
              ...assignment,
              driver: profilesMap.get(assignment.driver_id)
            }))
          })) as JobWithAssignments[];
        }
      }

      return (filteredJobsData || []) as JobWithAssignments[];
    },
    refetchInterval: 10000 // Auto-refresh every 10 seconds
  });

  const { data: availableDrivers } = useQuery({
    queryKey: ['available-drivers'],
    queryFn: async () => {
      const { data: profilesData, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, email, role_key, phone')
        .in('role_key', ['driver', 'carrier'])
        .eq('is_approved', true)
        .eq('is_active', true);
      
      if (profilesError) throw profilesError;

      // Fetch account numbers for these users
      const userIds = profilesData?.map(p => p.id) || [];
      const { data: accountData } = await supabase
        .from('user_account_number')
        .select('user_id, account_number')
        .in('user_id', userIds);

      // Merge account numbers with profiles
      const profilesWithAccounts = profilesData?.map(profile => ({
        ...profile,
        account_number: accountData?.find(acc => acc.user_id === profile.id)?.account_number || null
      }));
      
      return profilesWithAccounts || [];
    }
  });

  // Filter drivers based on search query
  const filteredDrivers = useMemo(() => {
    if (!availableDrivers) return [];
    if (!driverSearchQuery.trim()) return availableDrivers;

    const searchLower = driverSearchQuery.toLowerCase().trim();
    return availableDrivers.filter(driver => {
      // Search by name
      if (driver.full_name?.toLowerCase().includes(searchLower)) return true;
      // Search by email
      if (driver.email?.toLowerCase().includes(searchLower)) return true;
      // Search by phone
      if (driver.phone?.toLowerCase().includes(searchLower)) return true;
      // Search by account number
      if (driver.account_number?.toLowerCase().includes(searchLower)) return true;
      
      return false;
    });
  }, [availableDrivers, driverSearchQuery]);

  // Setup realtime subscriptions for job updates
  React.useEffect(() => {
    console.log('🔄 Setting up realtime job subscriptions');

    // Subscribe to jobs table changes
    const jobsChannel = supabase
      .channel('jobs-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'jobs' },
        (payload) => {
          console.log('Job updated in realtime:', payload);
          // Invalidate all job-related queries to trigger refetch
          queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['job-stats'] });
          queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
          queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['available-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['scheduled-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['planned-jobs'] });
        }
      )
      .subscribe();

    // Subscribe to job_assignments table changes
    const assignmentsChannel = supabase
      .channel('job-assignments-realtime')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'job_assignments' },
        (payload) => {
          console.log('Job assignment updated in realtime:', payload);
          // Invalidate all job-related queries to trigger refetch
          queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['job-stats'] });
          queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
          queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['available-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['scheduled-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['planned-jobs'] });
          queryClient.invalidateQueries({ queryKey: ['available-drivers'] });
        }
      )
      .subscribe();

    // Cleanup on unmount
    return () => {
      console.log('🔄 Cleaning up realtime job subscriptions');
      supabase.removeChannel(jobsChannel);
      supabase.removeChannel(assignmentsChannel);
    };
  }, [queryClient]);


  // Filter jobs based on search query
  const filteredJobs = React.useMemo(() => {
    if (!jobs) return [];
    
    const searchLower = filters.searchQuery.toLowerCase().trim();
    if (!searchLower) return jobs;

    return jobs.filter(job => {
      // Search by Job ID
      if (job.id.toLowerCase().includes(searchLower)) return true;

      // Search by Title
      if (job.title?.toLowerCase().includes(searchLower)) return true;

      // Search by Pickup Location
      const pickupLoc = job.pickup_location as any;
      if (pickupLoc?.address?.toLowerCase().includes(searchLower)) return true;
      if (pickupLoc?.city?.toLowerCase().includes(searchLower)) return true;
      if (pickupLoc?.state?.toLowerCase().includes(searchLower)) return true;

      // Search by Delivery Location
      const deliveryLoc = job.delivery_location as any;
      if (deliveryLoc?.address?.toLowerCase().includes(searchLower)) return true;
      if (deliveryLoc?.city?.toLowerCase().includes(searchLower)) return true;
      if (deliveryLoc?.state?.toLowerCase().includes(searchLower)) return true;

      return false;
    });
  }, [jobs, filters.searchQuery]);

  const handleSelectAll = () => {
    if (!onSelectionChange) return;
    if (selectedJobIds.length === filteredJobs?.length && filteredJobs?.length > 0) {
      onSelectionChange([]);
    } else {
      onSelectionChange(filteredJobs?.map(j => j.id) || []);
    }
  };

  const handleSelectJob = (jobId: string) => {
    if (!onSelectionChange) return;
    if (selectedJobIds.includes(jobId)) {
      onSelectionChange(selectedJobIds.filter(id => id !== jobId));
    } else {
      onSelectionChange([...selectedJobIds, jobId]);
    }
  };


  const handleCancelJob = async () => {
    if (!jobToCancel) return;

    try {
      const { error } = await supabase
        .from('jobs')
        .update({ status: 'cancelled', updated_at: new Date().toISOString() })
        .eq('id', jobToCancel.id);

      if (error) throw error;

      toast.success('Job cancelled successfully');
      queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['job-stats'] });
      queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
      queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
      setJobToCancel(null);
    } catch (error) {
      console.error('Error cancelling job:', error);
      toast.error('Failed to cancel job');
    }
  };

  const openDetails = (job: any) => {
    setSelectedJobForDetails(job);
  };

  const handleTrackJob = (job: any) => {
    // Navigate to tracking page or open tracking dialog
    toast.info('Tracking feature - opening map view');
    // You can implement navigation to a tracking page here
    // e.g., window.location.href = `/admin-dashboard/jobs/track/${job.id}`;
  };

  const handleStatusChange = async (jobId: string, newStatus: string) => {
    // Find the job to check if it has an assigned driver
    const job = jobs?.find(j => j.id === jobId);
    
    // Validate: Cannot set status to "assigned" if no driver is assigned
    if (newStatus === 'assigned' && (!job?.assigned_driver_id && (!job?.job_assignments || job.job_assignments.length === 0))) {
      toast.error('Cannot set status to assigned', {
        description: 'Please assign a driver first before setting status to assigned.'
      });
      return;
    }

    setJobStatuses(prev => ({ ...prev, [jobId]: newStatus }));
    
    try {
      const now = new Date().toISOString();
      const updateData: any = { 
        status: newStatus,
        updated_at: now
      };

      // If changing to pending, remove driver assignment
      if (newStatus === 'pending') {
        updateData.assigned_driver_id = null;
        
        const { error: deleteError } = await supabase
          .from('job_assignments')
          .delete()
          .eq('job_id', jobId);
        
        if (deleteError) throw deleteError;
      }

      // Update corresponding timestamp fields based on status
      if (newStatus === 'assigned') {
        updateData.accepted_at = now;
      } else if (newStatus === 'in_progress') {
        updateData.started_at = now;
        // If accepted_at is not set, set it too
        const { data: job } = await supabase
          .from('jobs')
          .select('accepted_at')
          .eq('id', jobId)
          .single();
        if (!job?.accepted_at) {
          updateData.accepted_at = now;
        }
      } else if (newStatus === 'delivered') {
        updateData.completed_at = now;
        updateData.actual_delivery_time = now;
        // Ensure all previous timestamps are set
        const { data: job } = await supabase
          .from('jobs')
          .select('accepted_at, started_at')
          .eq('id', jobId)
          .single();
        if (!job?.accepted_at) {
          updateData.accepted_at = now;
        }
        if (!job?.started_at) {
          updateData.started_at = now;
        }
      } else if (newStatus === 'cancelled') {
        updateData.cancelled_at = now;
        // Also remove driver assignment on cancellation
        const { error: deleteError } = await supabase
          .from('job_assignments')
          .delete()
          .eq('job_id', jobId);
        
        if (deleteError) console.error('Error removing assignment:', deleteError);
      }

      const { error } = await supabase
        .from('jobs')
        .update(updateData)
        .eq('id', jobId);

      if (error) throw error;

      toast.success('Job status and timeline updated');
      queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['job-stats'] });
      queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
      queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['driver-completed-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['active-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['available-jobs'] }); // Driver available jobs page
      queryClient.invalidateQueries({ queryKey: ['scheduled-jobs'] }); // Driver scheduled jobs
      queryClient.invalidateQueries({ queryKey: ['planned-jobs'] }); // Driver planned jobs
    } catch (error) {
      console.error('Error updating job status:', error);
      toast.error('Failed to update job status');
      // Revert on error
      setJobStatuses(prev => {
        const { [jobId]: _, ...rest } = prev;
        return rest;
      });
    }
  };

  const handleAssignDriver = async () => {
    if (!assigningJob || !selectedDriver) {
      toast.error('Please select a driver/carrier to assign');
      return;
    }

    if (assigningJob.status === 'on_hold') {
      toast.error('Cannot assign driver: This job is currently on hold');
      return;
    }

    try {
      // Check if driver is already assigned to this job
      const { data: existingAssignment } = await supabase
        .from('job_assignments')
        .select('id')
        .eq('job_id', assigningJob.id)
        .eq('status', 'assigned')
        .maybeSingle();

      if (existingAssignment) {
        toast.error('This job already has an assigned driver. Please unassign first.');
        return;
      }

      // Insert assignment with timestamp
      const { error: assignError } = await supabase
        .from('job_assignments')
        .insert({
          job_id: assigningJob.id,
          driver_id: selectedDriver,
          status: 'assigned',
          assigned_at: new Date().toISOString()
        });

      if (assignError) throw assignError;

      // Update job's assigned_driver_id AND automatically set status to "assigned"
      const { error: updateError } = await supabase
        .from('jobs')
        .update({ 
          assigned_driver_id: selectedDriver,
          status: 'assigned', 
          updated_at: new Date().toISOString() 
        })
        .eq('id', assigningJob.id);

      if (updateError) throw updateError;

      toast.success('Driver/Carrier assigned successfully');
      
      // Refresh all job-related queries
      await queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      await queryClient.invalidateQueries({ queryKey: ['job-stats'] });
      await queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
      await queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
      
      // Close dialog and reset state
      setAssigningJob(null);
      setSelectedDriver("");
      setDriverSearchQuery("");
    } catch (error: any) {
      console.error('Error assigning driver:', error);
      toast.error(error.message || 'Failed to assign driver/carrier');
    }
  };

  const handleUnassignDriver = async (job: JobWithAssignments) => {
    try {
      // Delete the job assignment
      const { error: deleteError } = await supabase
        .from('job_assignments')
        .delete()
        .eq('job_id', job.id)
        .eq('status', 'assigned');

      if (deleteError) throw deleteError;

      // Update job status back to pending and clear assigned driver
      const { error: updateError } = await supabase
        .from('jobs')
        .update({ 
          status: 'pending', 
          assigned_driver_id: null,
          updated_at: new Date().toISOString() 
        })
        .eq('id', job.id);

      if (updateError) throw updateError;

      toast.success('Driver/Carrier unassigned successfully');
      
      // Refresh all job-related queries
      await queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      await queryClient.invalidateQueries({ queryKey: ['job-stats'] });
      await queryClient.invalidateQueries({ queryKey: ['active-deliveries'] });
      await queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
    } catch (error: any) {
      console.error('Error unassigning driver:', error);
      const errorMessage = error.message || 'Failed to unassign driver/carrier';
      
      // Check if error is about missing pickup time
      if (errorMessage.includes('pickup_time') || errorMessage.includes('pickup date')) {
        toast.error('Cannot unassign: Job requires pickup date and time to be set first');
      } else {
        toast.error(errorMessage);
      }
    }
  };

  if (isLoading) {
    return <Skeleton className="h-96" />;
  }

  return (
    <div className="space-y-4">
      {/* Bulk Actions Button */}
      {selectedJobIds.length > 0 && onBulkActionsClick && (
        <div className="flex justify-end">
          <Button 
            variant="default" 
            onClick={onBulkActionsClick}
            className="gap-2"
          >
            <Users className="h-4 w-4" />
            Bulk Actions ({selectedJobIds.length})
          </Button>
        </div>
      )}

      {/* Jobs Table */}
      <Card>
        <CardHeader>
          <CardTitle>
            All Jobs ({filteredJobs?.length || 0}
            {filters.searchQuery && jobs && filteredJobs.length !== jobs.length && 
              ` of ${jobs.length}`
            })
          </CardTitle>
          <CardDescription>
            Comprehensive list of all job records in the system
            {filters.searchQuery && ` - Filtered by: "${filters.searchQuery}"`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
               <TableHeader>
                <TableRow>
                  {onSelectionChange && (
                    <TableHead className="w-12">
                      <Checkbox 
                        checked={selectedJobIds.length === filteredJobs?.length && filteredJobs?.length > 0}
                        onCheckedChange={handleSelectAll}
                      />
                    </TableHead>
                  )}
                  <TableHead>Job ID</TableHead>
                  <TableHead className="w-[130px]">Priority</TableHead>
                  <TableHead>Pickup & Dropoff</TableHead>
                  <TableHead className="w-[173px]">Duration</TableHead>
                  <TableHead>Distance</TableHead>
                  <TableHead className="w-[270px]">Created By</TableHead>
                  <TableHead className="w-[220px]">Assigned To</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Fee</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredJobs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={onSelectionChange ? 11 : 10} className="text-center py-8 text-muted-foreground">
                      {filters.searchQuery ? `No jobs found matching "${filters.searchQuery}"` : 'No jobs available'}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredJobs.map((job) => (
                  <TableRow key={job.id}>
                    {onSelectionChange && (
                      <TableCell>
                        <Checkbox 
                          checked={selectedJobIds.includes(job.id)}
                          onCheckedChange={() => handleSelectJob(job.id)}
                        />
                      </TableCell>
                    )}
                    <TableCell className="font-mono text-sm">
                      #{job.id.slice(0, 8)}
                    </TableCell>
                    <TableCell>
                      {job.priority && <PriorityIndicator priority={job.priority} size="sm" />}
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="h-3 w-3 text-green-500" />
                          <span className="truncate max-w-[200px]">
                            {getLocationShort(job.pickup_location)}
                          </span>
                        </div>
                        <div className="flex items-center gap-1 text-sm">
                          <MapPin className="h-3 w-3 text-red-500" />
                          <span className="truncate max-w-[200px]">
                            {getLocationShort(job.delivery_location)}
                          </span>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {formatDuration(getJobDuration(job.estimated_duration, job.distance_miles))}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground">
                        {job.distance_miles ? `${job.distance_miles}mi` : 'N/A'}
                      </span>
                    </TableCell>
                    <TableCell>
                      {job.creator ? (
                        <div className="flex flex-col gap-1">
                          <span className="text-sm font-medium">
                            {(() => {
                              // Show company name for business roles
                              if (['carrier', 'broker', 'shipper', 'vendor'].includes(job.creator.role_key || '')) {
                                return job.creator.company_name || job.creator.full_name || job.creator.email || 'Unknown';
                              }
                              // Show person name for other roles
                              return job.creator.full_name || job.creator.email || 'Unknown';
                            })()}
                          </span>
                          <Badge variant="outline" className="w-fit text-xs capitalize">
                            {job.creator.role_key}
                          </Badge>
                        </div>
                      ) : (
                        <span className="text-sm text-muted-foreground">System</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {(() => {
                        // Check assigned_driver_id first (direct assignment in jobs table)
                        if (job.assigned_driver_id && job.assigned_driver) {
                          return (
                            <div className="flex flex-col gap-1">
                              <span className="text-sm font-medium">
                                {job.assigned_driver.full_name || job.assigned_driver.email || 'Unknown'}
                              </span>
                              <Badge variant="outline" className="w-fit text-xs">
                                {job.assigned_driver.role_key}
                              </Badge>
                            </div>
                          );
                        }
                        
                        // Then check job_assignments
                        if (job.job_assignments && job.job_assignments.length > 0 && job.job_assignments[0].driver) {
                          return (
                            <div className="flex flex-col gap-1">
                              <span className="text-sm font-medium">
                                {job.job_assignments[0].driver.full_name || job.job_assignments[0].driver.email || 'Unknown'}
                              </span>
                              <Badge variant="outline" className="w-fit text-xs">
                                {job.job_assignments[0].driver.role_key}
                              </Badge>
                            </div>
                          );
                        }
                        
                        // No assignment found
                        return <Badge variant="secondary" className="text-xs">Unassigned</Badge>;
                      })()}
                    </TableCell>
                    <TableCell><JobStatusIndicator status={jobStatuses[job.id] ?? job.status} size="sm" /></TableCell>
                    <TableCell className="font-semibold">
                      ${job.pay_amount?.toLocaleString() || '0'}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Select 
                          value={jobStatuses[job.id] ?? job.status}
                          onValueChange={(value) => handleStatusChange(job.id, value)}
                        >
                           <SelectTrigger className="w-[140px] h-8">
                             <SelectValue placeholder={(jobStatuses[job.id] ?? job.status) || 'Status'} />
                           </SelectTrigger>
                           <SelectContent className="bg-background z-50">
                              <SelectItem value="pending">Pending</SelectItem>
                              <SelectItem value="posted">Posted</SelectItem>
                              <SelectItem value="planned">Planned</SelectItem>
                              <SelectItem value="claimed">Claimed</SelectItem>
                              <SelectItem value="assigned">Assigned</SelectItem>
                              <SelectItem value="in_progress">In Progress</SelectItem>
                              <SelectItem value="in_transit">In Transit</SelectItem>
                              <SelectItem value="picked_up">Picked Up</SelectItem>
                              <SelectItem value="on_hold">On Hold</SelectItem>
                              <SelectItem value="delayed">Delayed</SelectItem>
                              <SelectItem value="delivered">Delivered</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                              <SelectItem value="cancelled">Cancelled</SelectItem>
                              <SelectItem value="archived">Archived</SelectItem>
                            </SelectContent>
                        </Select>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => openDetails(job)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => setSelectedJobForEdit(job)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Job
                            </DropdownMenuItem>
                            {(job.assigned_driver_id || (job.job_assignments && job.job_assignments.length > 0)) ? (
                              <DropdownMenuItem onClick={() => handleUnassignDriver(job)}>
                                <Users className="h-4 w-4 mr-2" />
                                Unassign Driver/Carrier
                              </DropdownMenuItem>
                            ) : (
                              <DropdownMenuItem onClick={() => {
                                setAssigningJob(job);
                                setSelectedDriver("");
                              }}>
                                <Users className="h-4 w-4 mr-2" />
                                Assign Driver/Carrier
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => handleTrackJob(job)}>
                              <MapPin className="h-4 w-4 mr-2" />
                              Track
                            </DropdownMenuItem>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem 
                              className="text-destructive"
                              onClick={() => setJobToCancel(job)}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Cancel Job
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialogs */}
      {selectedJobForDetails && (
        <AdminJobDetailsDialog
          job={selectedJobForDetails}
          open={!!selectedJobForDetails}
          onOpenChange={(open) => {
            if (!open) setSelectedJobForDetails(null);
          }}
        />
      )}

      <JobEditDialog
        job={selectedJobForEdit}
        open={!!selectedJobForEdit}
        onOpenChange={(open) => !open && setSelectedJobForEdit(null)}
      />

      <AlertDialog open={!!jobToCancel} onOpenChange={(open) => !open && setJobToCancel(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Job</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to cancel this job? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>No, keep job</AlertDialogCancel>
            <AlertDialogAction onClick={handleCancelJob} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Yes, cancel job
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!assigningJob} onOpenChange={(open) => {
        if (!open) {
          setAssigningJob(null);
          setDriverSearchQuery("");
          setSelectedDriver("");
        }
      }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Assign Driver or Carrier</DialogTitle>
            <DialogDescription>
              Search and select a driver or carrier to assign to this job.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Search Driver/Carrier</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name, email, phone, or user code..."
                  value={driverSearchQuery}
                  onChange={(e) => setDriverSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Available Drivers/Carriers 
                {filteredDrivers.length > 0 && ` (${filteredDrivers.length})`}
              </label>
              <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                <SelectTrigger>
                  <SelectValue placeholder="Select driver or carrier" />
                </SelectTrigger>
                <SelectContent className="bg-background z-50">
                  {filteredDrivers.length === 0 ? (
                    <div className="p-4 text-sm text-muted-foreground text-center">
                      {driverSearchQuery ? 'No drivers/carriers found matching your search' : 'No available drivers/carriers'}
                    </div>
                  ) : (
                    filteredDrivers.map((driver) => (
                      <SelectItem key={driver.id} value={driver.id}>
                        <div className="flex flex-col">
                          <span className="font-medium">
                            {driver.full_name || driver.email}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {driver.role_key} • {driver.email}
                            {driver.phone && ` • ${driver.phone}`}
                            {driver.account_number && ` • Code: ${driver.account_number}`}
                          </span>
                        </div>
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setAssigningJob(null);
              setDriverSearchQuery("");
              setSelectedDriver("");
            }}>
              Cancel
            </Button>
            <Button onClick={handleAssignDriver} disabled={!selectedDriver}>
              Assign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
