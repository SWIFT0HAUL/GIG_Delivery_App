import React, { useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { calculateJobCost } from '@/lib/jobCostCalculator';
import { AddressAutocomplete } from '@/components/ui/address-autocomplete';
import { getDirections } from '@/lib/directions';
import { VEHICLE_CATEGORIES } from '@/lib/vehicleConfig';

const jobSchema = z.object({
  title: z.string().trim().min(3, 'Title must be at least 3 characters').max(100, 'Title must be less than 100 characters'),
  description: z.string().trim().max(1000, 'Description must be less than 1000 characters').optional(),
  priority: z.enum(['pickup_now','scheduled','route'], { required_error: 'Priority is required' }),
  vehicle_type: z.string().min(1, 'Vehicle type is required'),
  pickup_time: z.string().min(1, 'Pickup date and time is required'),
  pickup_address: z.string().trim().min(5, 'Pickup address is required'),
  pickup_city: z.string().trim().min(2, 'Pickup city is required'),
  pickup_state: z.string().trim().min(2, 'Pickup state is required'),
  pickup_zip: z.string().trim().min(5, 'Pickup zip code is required').max(10),
  pickup_contact_phone: z.string().trim().min(10, 'Pickup contact phone is required'),
  pickup_instructions: z.string().trim().max(500).optional(),
  delivery_address: z.string().trim().min(5, 'Delivery address is required'),
  delivery_city: z.string().trim().min(2, 'Delivery city is required'),
  delivery_state: z.string().trim().min(2, 'Delivery state is required'),
  delivery_zip: z.string().trim().min(5, 'Delivery zip code is required').max(10),
  recipient_phone: z.string().trim().min(10, 'Recipient phone is required'),
  delivery_instructions: z.string().trim().max(500).optional(),
  pay_amount: z.string().refine((val) => !isNaN(Number(val)) && Number(val) > 0, 'Pay amount must be a positive number'),
  distance_miles: z.string().optional(),
  estimated_duration: z.string().optional(),
  cargo_weight: z.string().optional(),
  cargo_length: z.string().optional(),
  cargo_width: z.string().optional(),
  cargo_height: z.string().optional(),
  cargo_pieces: z.string().optional(),
  cargo_description: z.string().trim().max(500).optional(),
  signature_required: z.boolean().optional(),
});

type JobFormData = z.infer<typeof jobSchema>;

interface JobCreateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onJobCreated?: () => void;
}

export const JobCreateDialog = ({ open, onOpenChange, onJobCreated }: JobCreateDialogProps) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [pickupAddr, setPickupAddr] = React.useState('');
  const [deliveryAddr, setDeliveryAddr] = React.useState('');
  const [calculatedDuration, setCalculatedDuration] = React.useState<number | null>(null);

  const { register, handleSubmit, formState: { errors }, reset, setValue, watch } = useForm<JobFormData>({
    resolver: zodResolver(jobSchema),
  });

  // Reset form when dialog closes
  useEffect(() => {
    if (!open) {
      reset();
    }
  }, [open, reset]);

  // Auto-calculation disabled - users can manually enter distance and duration
  // useEffect(() => {
  //   const subscription = watch((value) => {
  //     const calculateDistanceAndDuration = async () => {
  //       const pickupAddr = value.pickup_address;
  //       const deliveryAddr = value.delivery_address;
  //       
  //       if (pickupAddr && deliveryAddr) {
  //         try {
  //           const result = await getDirections({
  //             origin: pickupAddr,
  //             destination: deliveryAddr,
  //             mode: 'driving'
  //           });
  //
  //           if (result.routes && result.routes.length > 0) {
  //             const route = result.routes[0];
  //             let totalDistanceMeters = 0;
  //             let totalDurationSeconds = 0;
  //             
  //             route.legs.forEach(leg => {
  //               totalDistanceMeters += leg.distance.value;
  //               totalDurationSeconds += leg.duration.value;
  //             });
  //             
  //             // Convert meters to miles
  //             const miles = (totalDistanceMeters / 1609.34).toFixed(1);
  //             setValue("distance_miles", miles);
  //             
  //             // Convert seconds to minutes
  //             const minutes = Math.round(totalDurationSeconds / 60);
  //             setCalculatedDuration(minutes);
  //           }
  //         } catch (error) {
  //           console.error('Error calculating distance and duration:', error);
  //         }
  //       }
  //     };
  //
  //     calculateDistanceAndDuration();
  //   });
  //
  //   return () => subscription.unsubscribe();
  // }, [watch, setValue]);

  const createJobMutation = useMutation({
    mutationFn: async (data: JobFormData) => {
      if (!user?.id) throw new Error('User not authenticated');

      const pickupDate = data.pickup_time ? new Date(data.pickup_time) : new Date();
      const currentDate = new Date();

      // Reset time parts for date comparison
      const pickupDateOnly = new Date(pickupDate.getFullYear(), pickupDate.getMonth(), pickupDate.getDate());
      const currentDateOnly = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate());
      
      if (isNaN(pickupDate.getTime())) {
        throw new Error('Invalid pickup date. Please review the pickup date and time.');
      }
      
      // Determine job category based on pickup date
      let jobCategory: string;
      if (pickupDateOnly.getTime() === currentDateOnly.getTime()) {
        jobCategory = 'pickup_now';
      } else if (pickupDateOnly > currentDateOnly) {
        jobCategory = 'scheduled';
      } else {
        throw new Error('Pickup date cannot be in the past. Please review the pickup date.');
      }

      // Calculate job cost based on distance, weight, and market analysis
      const calculatedCost = calculateJobCost({
        distanceMiles: data.distance_miles ? Number(data.distance_miles) : 0,
        weight: data.cargo_weight ? Number(data.cargo_weight) : 0,
        vehicleType: data.vehicle_type,
        createdDate: new Date(),
      });

      // Determine status based on pay amount vs calculated cost
      const payAmount = Number(data.pay_amount);
      const jobStatus = payAmount > calculatedCost ? 'posted' : 'pending';

      const { data: job, error } = await supabase
        .from('jobs')
        .insert({
          title: data.title,
          description: data.description || null,
          priority: data.priority,
          pickup_time: pickupDate.toISOString(),
          pickup_location: {
            address: data.pickup_address,
            city: data.pickup_city,
            state: data.pickup_state,
            zip: data.pickup_zip,
            contact_phone: data.pickup_contact_phone,
            instructions: data.pickup_instructions || null,
          },
          delivery_location: {
            address: data.delivery_address,
            city: data.delivery_city,
            state: data.delivery_state,
            zip: data.delivery_zip,
            contact_phone: data.recipient_phone,
            instructions: data.delivery_instructions || null,
          },
          pay_amount: payAmount,
          distance_miles: data.distance_miles ? Number(data.distance_miles) : null,
          estimated_duration: data.estimated_duration ? Number(data.estimated_duration) : null,
          cargo_details: {
            weight: data.cargo_weight || null,
            description: data.cargo_description || null,
            vehicle_type: data.vehicle_type,
          },
          status: jobStatus,
          created_by: user.id,
        })
        .select()
        .single();

      if (error) throw error;
      return job;
    },
    onSuccess: (job) => {
      // Invalidate all job-related queries to update all tabs and pages immediately
      queryClient.invalidateQueries({ queryKey: ['all-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['job-stats'] });
      queryClient.invalidateQueries({ queryKey: ['unassigned-jobs'] });
      queryClient.invalidateQueries({ queryKey: ['jobs-export'] });
      queryClient.invalidateQueries({ queryKey: ['available-drivers'] });
      
      const isPickupNow = job.priority === 'pickup_now';
      const isScheduled = job.priority === 'scheduled';
      
      toast({
        title: 'Job Created Successfully',
        description: `${
          isPickupNow ? '🚀 Pickup Now job created! ' : 
          isScheduled ? '📅 Scheduled job created! ' : 'Job created! '
        }${
          job.status === 'posted' ? 'Now visible to drivers.' : 'Pending approval.'
        }`,
      });
      
      reset();
      onOpenChange(false);
      if (onJobCreated) onJobCreated();
    },
    onError: (error: Error) => {
      console.error('Error creating job:', error);
      const errorMessage = error.message || 'Please check all required fields and try again.';
      
      // Check if error is about missing pickup time
      if (errorMessage.includes('pickup_time') || errorMessage.includes('pickup date')) {
        toast({
          title: 'Pickup Date & Time Required',
          description: 'Please set the pickup date and time before creating this job.',
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'Failed to Create Job',
          description: errorMessage,
          variant: 'destructive',
        });
      }
    },
  });

  const onSubmit = (data: JobFormData) => {
    createJobMutation.mutate(data);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create New Job</DialogTitle>
          <DialogDescription>
            Fill in the job details to create a new delivery assignment.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          {/* Basic Info */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Basic Information</h3>
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="title">Job Title *</Label>
                <Input id="title" {...register('title')} placeholder="e.g., Furniture Delivery" />
                {errors.title && <p className="text-xs text-destructive">{errors.title.message}</p>}
              </div>

              <div className="space-y-2">
                <Label htmlFor="priority">Priority *</Label>
                <Select onValueChange={(value) => register('priority').onChange({ target: { value } })}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent className="bg-background z-50">
                    <SelectItem value="pickup_now">Pick Up Now</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="route">Route</SelectItem>
                  </SelectContent>
                </Select>
                {errors.priority && <p className="text-xs text-destructive">{errors.priority.message}</p>}
                <p className="text-xs text-muted-foreground">
                  Note: System validates against pickup date
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicle_type">Vehicle Type Required *</Label>
              <Select onValueChange={(value) => register('vehicle_type').onChange({ target: { value } })}>
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Select vehicle type" />
                </SelectTrigger>
                <SelectContent className="bg-background z-50 max-h-[300px]">
                  {VEHICLE_CATEGORIES.map((category) => (
                    <React.Fragment key={category.id}>
                      <div className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                        {category.icon} {category.name}
                      </div>
                      {category.vehicle_types.map((vehicle) => (
                        <SelectItem 
                          key={vehicle.name} 
                          value={vehicle.name}
                          className="pl-6"
                        >
                          {vehicle.name} ({vehicle.capacity})
                        </SelectItem>
                      ))}
                    </React.Fragment>
                  ))}
                </SelectContent>
              </Select>
              {errors.vehicle_type && <p className="text-xs text-destructive">{errors.vehicle_type.message}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea id="description" {...register('description')} placeholder="Additional job details..." rows={3} />
              {errors.description && <p className="text-xs text-destructive">{errors.description.message}</p>}
            </div>
          </div>

          {/* Pickup Schedule */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Pickup Schedule</h3>
            <div className="space-y-2">
              <Label htmlFor="pickup_time">Pickup Date & Time *</Label>
              <Input 
                id="pickup_time" 
                type="datetime-local" 
                {...register('pickup_time')} 
                className="w-full"
              />
              {errors.pickup_time && <p className="text-xs text-destructive">{errors.pickup_time.message}</p>}
              <p className="text-xs text-muted-foreground">
                📍 Today's date = Pickup Now | Future date = Scheduled Job
              </p>
            </div>
          </div>

          {/* Pickup Location */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Pickup Location</h3>
            <div className="space-y-2">
              <AddressAutocomplete
                label="Address"
                value={pickupAddr}
                onAddressSelect={(address) => {
                  setPickupAddr(address.formatted_address || '');
                  setValue('pickup_address', address.formatted_address || '');
                  setValue('pickup_city', address.city || '');
                  setValue('pickup_state', address.state || '');
                  setValue('pickup_zip', address.zip || '');
                }}
                placeholder="Start typing pickup address..."
                required
                error={errors.pickup_address?.message}
              />
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="pickup_city">City *</Label>
                <Input id="pickup_city" {...register('pickup_city')} placeholder="City" />
                {errors.pickup_city && <p className="text-xs text-destructive">{errors.pickup_city.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="pickup_state">State *</Label>
                <Input id="pickup_state" {...register('pickup_state')} placeholder="State" />
                {errors.pickup_state && <p className="text-xs text-destructive">{errors.pickup_state.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="pickup_zip">ZIP Code *</Label>
                <Input id="pickup_zip" {...register('pickup_zip')} placeholder="12345" />
                {errors.pickup_zip && <p className="text-xs text-destructive">{errors.pickup_zip.message}</p>}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="pickup_contact_phone">Pickup Contact Phone *</Label>
              <Input id="pickup_contact_phone" {...register('pickup_contact_phone')} placeholder="(555) 123-4567" />
              {errors.pickup_contact_phone && <p className="text-xs text-destructive">{errors.pickup_contact_phone.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="pickup_instructions">Pickup Instructions</Label>
              <Textarea id="pickup_instructions" {...register('pickup_instructions')} placeholder="Any special pickup instructions..." rows={2} />
              {errors.pickup_instructions && <p className="text-xs text-destructive">{errors.pickup_instructions.message}</p>}
            </div>
          </div>

          {/* Delivery Location */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Delivery Location</h3>
            <div className="space-y-2">
              <AddressAutocomplete
                label="Address"
                value={deliveryAddr}
                onAddressSelect={(address) => {
                  setDeliveryAddr(address.formatted_address || '');
                  setValue('delivery_address', address.formatted_address || '');
                  setValue('delivery_city', address.city || '');
                  setValue('delivery_state', address.state || '');
                  setValue('delivery_zip', address.zip || '');
                }}
                placeholder="Start typing delivery address..."
                required
                error={errors.delivery_address?.message}
              />
            </div>
            <div className="grid gap-4 md:grid-cols-3">
              <div className="space-y-2">
                <Label htmlFor="delivery_city">City *</Label>
                <Input id="delivery_city" {...register('delivery_city')} placeholder="City" />
                {errors.delivery_city && <p className="text-xs text-destructive">{errors.delivery_city.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="delivery_state">State *</Label>
                <Input id="delivery_state" {...register('delivery_state')} placeholder="State" />
                {errors.delivery_state && <p className="text-xs text-destructive">{errors.delivery_state.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="delivery_zip">ZIP Code *</Label>
                <Input id="delivery_zip" {...register('delivery_zip')} placeholder="12345" />
                {errors.delivery_zip && <p className="text-xs text-destructive">{errors.delivery_zip.message}</p>}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="recipient_phone">Recipient Phone *</Label>
              <Input id="recipient_phone" {...register('recipient_phone')} placeholder="(555) 987-6543" />
              {errors.recipient_phone && <p className="text-xs text-destructive">{errors.recipient_phone.message}</p>}
            </div>
            <div className="space-y-2">
              <Label htmlFor="delivery_instructions">Delivery Instructions</Label>
              <Textarea id="delivery_instructions" {...register('delivery_instructions')} placeholder="Any special delivery instructions..." rows={2} />
              {errors.delivery_instructions && <p className="text-xs text-destructive">{errors.delivery_instructions.message}</p>}
            </div>
          </div>

          {/* Job Details */}
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">Job Details</h3>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="space-y-2">
                <Label htmlFor="pay_amount">Pay Amount ($) *</Label>
                <Input id="pay_amount" {...register('pay_amount')} type="number" step="0.01" placeholder="150.00" />
                {errors.pay_amount && <p className="text-xs text-destructive">{errors.pay_amount.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="distance_miles">Distance (miles)</Label>
                <Input 
                  id="distance_miles" 
                  {...register('distance_miles')} 
                  type="number" 
                  step="0.1" 
                  placeholder="Enter distance"
                />
                {errors.distance_miles && <p className="text-xs text-destructive">{errors.distance_miles.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="estimated_duration">Duration (minutes)</Label>
                <Input 
                  id="estimated_duration" 
                  {...register('estimated_duration')}
                  type="number" 
                  placeholder="Enter duration"
                />
                {errors.estimated_duration && <p className="text-xs text-destructive">{errors.estimated_duration.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="cargo_weight">Weight (lbs)</Label>
                <Input id="cargo_weight" {...register('cargo_weight')} type="number" placeholder="500" />
                {errors.cargo_weight && <p className="text-xs text-destructive">{errors.cargo_weight.message}</p>}
              </div>
            </div>
            <div className="grid gap-4 md:grid-cols-4">
              <div className="space-y-2">
                <Label htmlFor="cargo_length">Length (ft)</Label>
                <Input id="cargo_length" {...register('cargo_length')} type="number" placeholder="8" />
                {errors.cargo_length && <p className="text-xs text-destructive">{errors.cargo_length.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="cargo_width">Width (ft)</Label>
                <Input id="cargo_width" {...register('cargo_width')} type="number" placeholder="4" />
                {errors.cargo_width && <p className="text-xs text-destructive">{errors.cargo_width.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="cargo_height">Height (ft)</Label>
                <Input id="cargo_height" {...register('cargo_height')} type="number" placeholder="6" />
                {errors.cargo_height && <p className="text-xs text-destructive">{errors.cargo_height.message}</p>}
              </div>
              <div className="space-y-2">
                <Label htmlFor="cargo_pieces">Number of Pieces</Label>
                <Input id="cargo_pieces" {...register('cargo_pieces')} type="number" placeholder="1" />
                {errors.cargo_pieces && <p className="text-xs text-destructive">{errors.cargo_pieces.message}</p>}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="cargo_description">Cargo Description</Label>
              <Textarea id="cargo_description" {...register('cargo_description')} placeholder="Describe the cargo..." rows={2} />
              {errors.cargo_description && <p className="text-xs text-destructive">{errors.cargo_description.message}</p>}
            </div>

            <div className="flex items-center space-x-2 pt-2">
              <Checkbox 
                id="signature_required" 
                {...register('signature_required')}
              />
              <Label htmlFor="signature_required" className="text-sm font-normal cursor-pointer">
                Signature required upon delivery
              </Label>
            </div>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={createJobMutation.isPending}>
              {createJobMutation.isPending && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Create Job
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
