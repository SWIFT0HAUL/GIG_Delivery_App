import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Clock, LogOut, FileText, AlertCircle, CheckCircle, XCircle, Timer, Calendar, Filter, Download, TrendingUp, ClockIcon, Activity, AlertTriangle, FileSpreadsheet, FilePlus, FileDown } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import { format, differenceInSeconds, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subDays } from 'date-fns';
import { TimesheetAnalytics } from './TimesheetAnalytics';
import { WeeklySummaryCard } from './WeeklySummaryCard';
import { ClockInOutCard } from './timesheet/ClockInOutCard';
import { TimesheetTable } from './timesheet/TimesheetTable';
import { SummaryCard } from './timesheet/SummaryCard';
import { ManualEntryForm } from './timesheet/ManualEntryForm';
import { AdminActivityChart } from './timesheet/AdminActivityChart';
import { ModernSummaryStats } from './timesheet/ModernSummaryStats';
import { TimesheetEntry, Task, ActivityLog } from './timesheet/types';
import * as XLSX from 'xlsx';

export function TimesheetManagement() {
  const { user } = useAuth();
  const [timesheets, setTimesheets] = useState<TimesheetEntry[]>([]);
  const [currentSession, setCurrentSession] = useState<TimesheetEntry | null>(null);
  const [loading, setLoading] = useState(true);
  const [manualEntryOpen, setManualEntryOpen] = useState(false);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  const [selectedEntry, setSelectedEntry] = useState<TimesheetEntry | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [inactivityWarning, setInactivityWarning] = useState(false);
  const [viewAllTimesheets, setViewAllTimesheets] = useState(false);
  const [allAdmins, setAllAdmins] = useState<{ id: string; full_name: string; email: string; sub_role: string | null; role_key: string }[]>([]);
  const [selectedAdminFilter, setSelectedAdminFilter] = useState<string>('all');
  const [selectedTimesheet, setSelectedTimesheet] = useState<TimesheetEntry | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [activityLogsOpen, setActivityLogsOpen] = useState(false);
  const [availableTasks, setAvailableTasks] = useState<Task[]>([]);
  const [selectedTaskId, setSelectedTaskId] = useState<string>('');
  
  // Filters
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('week');
  const [activeTab, setActiveTab] = useState('tracking');

  // Manual entry form state
  const [manualClockIn, setManualClockIn] = useState('');
  const [manualClockOut, setManualClockOut] = useState('');
  const [manualReason, setManualReason] = useState('');
  const [manualNotes, setManualNotes] = useState('');
  
  // Approval form state
  const [rejectionReason, setRejectionReason] = useState('');
  
  // Summary stats
  const [stats, setStats] = useState({
    totalHours: 0,
    thisWeek: 0,
    pending: 0,
    approved: 0,
    overtime: 0
  });

  useEffect(() => {
    console.log('[Timesheet] Auth user changed:', user?.id);
    if (user?.id) {
      checkUserRole();
    } else {
      console.log('[Timesheet] No user ID found');
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    console.log('[Timesheet] Data fetch effect triggered - user:', user?.id, 'isAdmin:', isAdmin, 'isSuperAdmin:', isSuperAdmin);
    
    if (user?.id && (isAdmin || isSuperAdmin)) {
      console.log('[Timesheet] Fetching timesheet data...');
      fetchTimesheets();
      checkActiveSession();
      fetchAvailableTasks();
      if (isSuperAdmin) {
        fetchAllAdmins();
      }
      
      // Check for inactive sessions periodically
      const inactivityCheck = setInterval(() => {
        checkInactivity();
      }, 60000); // Check every minute
      
      return () => clearInterval(inactivityCheck);
    } else {
      console.log('[Timesheet] Not fetching data - conditions not met');
    }
  }, [user, dateFilter, statusFilter, viewAllTimesheets, selectedAdminFilter, isAdmin, isSuperAdmin]);

  const checkUserRole = async () => {
    try {
      console.log('[Timesheet] Checking user role for user:', user?.id);
      
      const { data, error } = await supabase
        .from('profiles')
        .select('role_key, is_approved, is_active')
        .eq('id', user?.id)
        .single();
      
      console.log('[Timesheet] Profile data:', data);
      console.log('[Timesheet] Profile error:', error);
      
      if (error) {
        console.error('[Timesheet] Error fetching profile:', error);
        setLoading(false);
        throw error;
      }
      
      const roleKey = data?.role_key;
      const isApproved = data?.is_approved;
      const isActive = data?.is_active;
      
      console.log('[Timesheet] Role:', roleKey, 'Approved:', isApproved, 'Active:', isActive);
      
      const hasAdminRole = roleKey === 'admin';
      const hasSuperAdminRole = roleKey === 'super_admin';
      
      setIsSuperAdmin(hasSuperAdminRole);
      setIsAdmin(hasAdminRole);
      
      // Set loading to false after checking role
      if (!hasAdminRole && !hasSuperAdminRole) {
        console.warn('[Timesheet] User does not have admin privileges');
        setLoading(false);
        toast.error('Access denied: Admin privileges required');
      } else if (!isApproved || !isActive) {
        console.warn('[Timesheet] User not approved or not active');
        setLoading(false);
        toast.error('Your account is not yet activated. Please contact an administrator.');
      }
    } catch (error) {
      console.error('[Timesheet] Error checking user role:', error);
      setLoading(false);
      toast.error('Failed to verify permissions');
    }
  };

  const fetchAllAdmins = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, full_name, email, sub_role, role_key')
        .in('role_key', ['admin', 'super_admin'])
        .order('role_key', { ascending: false })
        .order('sub_role')
        .order('full_name');
      
      if (error) throw error;
      setAllAdmins(data || []);
    } catch (error) {
      console.error('Error fetching admins:', error);
    }
  };

  const fetchAvailableTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('custom_tasks')
        .select('id, name, description')
        .order('name');

      if (error) throw error;
      setAvailableTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const fetchActivityLogs = async (timesheetId: string) => {
    try {
      const { data, error } = await supabase
        .from('timesheet_activity_logs')
        .select('*')
        .eq('timesheet_id', timesheetId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setActivityLogs(data || []);
    } catch (error: any) {
      toast.error('Failed to fetch activity logs: ' + error.message);
    }
  };

  const handleViewActivityLogs = (timesheet: TimesheetEntry) => {
    setSelectedTimesheet(timesheet);
    fetchActivityLogs(timesheet.id);
    setActivityLogsOpen(true);
  };

  const checkInactivity = async () => {
    if (!currentSession || currentSession.clock_out) return;
    
    const lastActivity = new Date(currentSession.last_activity || currentSession.clock_in);
    const minutesInactive = differenceInSeconds(new Date(), lastActivity) / 60;
    
    if (minutesInactive > 45 && minutesInactive < 60) {
      setInactivityWarning(true);
      toast.warning('You will be automatically clocked out after 60 minutes of inactivity');
    } else if (minutesInactive >= 60) {
      // Trigger auto-timeout
      await supabase.rpc('auto_timeout_timesheets');
      setInactivityWarning(false);
      checkActiveSession();
      fetchTimesheets();
    }
  };

  // Update elapsed time every second for active session
  useEffect(() => {
    if (currentSession && !currentSession.clock_out) {
      const interval = setInterval(() => {
        const seconds = differenceInSeconds(new Date(), new Date(currentSession.clock_in));
        setElapsedTime(seconds);
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [currentSession]);

  const fetchTimesheets = async () => {
    try {
      let query = supabase
        .from('timesheets')
        .select('*');

      // Super Admin can view all timesheets or filter by admin
      if (isSuperAdmin) {
        if (viewAllTimesheets) {
          // View all timesheets
          if (selectedAdminFilter !== 'all') {
            query = query.eq('admin_id', selectedAdminFilter);
          }
        } else {
          // View only own timesheets
          query = query.eq('admin_id', user?.id);
        }
      } else if (isAdmin) {
        // Admin can only view their own timesheets
        query = query.eq('admin_id', user?.id);
      } else {
        // No access
        setLoading(false);
        return;
      }

      // Apply date filter
      const now = new Date();
      switch (dateFilter) {
        case 'today':
          query = query.gte('clock_in', new Date().setHours(0, 0, 0, 0));
          break;
        case 'week':
          query = query.gte('clock_in', startOfWeek(now).toISOString());
          break;
        case 'month':
          query = query.gte('clock_in', startOfMonth(now).toISOString());
          break;
        case '7days':
          query = query.gte('clock_in', subDays(now, 7).toISOString());
          break;
        case '30days':
          query = query.gte('clock_in', subDays(now, 30).toISOString());
          break;
      }

      // Apply status filter
      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      query = query.order('clock_in', { ascending: false }).limit(100);

      const { data, error } = await query;
      if (error) throw error;

      setTimesheets(data || []);
      calculateStats(data || []);
    } catch (error: any) {
      toast.error('Failed to fetch timesheets: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const calculateStats = (data: TimesheetEntry[]) => {
    const now = new Date();
    const weekStart = startOfWeek(now);
    
    const totalHours = data.reduce((sum, t) => sum + (t.total_duration || 0), 0);
    const thisWeekHours = data
      .filter(t => new Date(t.clock_in) >= weekStart)
      .reduce((sum, t) => sum + (t.total_duration || 0), 0);
    const overtimeHours = data
      .filter(t => new Date(t.clock_in) >= weekStart)
      .reduce((sum, t) => sum + Math.max(0, (t.total_duration || 0) - 8), 0);
    const pendingCount = data.filter(t => t.status === 'pending' || t.status === 'pending_approval').length;
    const approvedCount = data.filter(t => t.status === 'approved').length;

    setStats({
      totalHours: parseFloat(totalHours.toFixed(2)),
      thisWeek: parseFloat(thisWeekHours.toFixed(2)),
      pending: pendingCount,
      approved: approvedCount,
      overtime: parseFloat(overtimeHours.toFixed(2))
    });
  };

  const checkActiveSession = async () => {
    try {
      const { data, error } = await supabase
        .from('timesheets')
        .select('*')
        .eq('admin_id', user?.id)
        .is('clock_out', null)
        .order('clock_in', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      setCurrentSession(data as unknown as TimesheetEntry | null);
    } catch (error: any) {
      console.error('Error checking active session:', error);
    }
  };

  const handleClockIn = async (taskId?: string) => {
    try {
      // Check for active session first
      const { data: activeSession } = await supabase
        .from('timesheets')
        .select('id')
        .eq('admin_id', user?.id)
        .is('clock_out', null)
        .maybeSingle();
      
      if (activeSession) {
        toast.error('You already have an active session. Please clock out first.');
        return;
      }

      const { data, error } = await supabase
        .from('timesheets' as any)
        .insert({
          admin_id: user?.id,
          clock_in: new Date().toISOString(),
          last_activity: new Date().toISOString(),
          status: 'active',
          manual_entry: false,
          activity_count: 0
        } as any)
        .select()
        .single();

      if (error) throw error;

      const timesheetEntry = data as any;
      
      // If task selected, create activity log
      if (taskId && timesheetEntry?.id) {
        await supabase
          .from('timesheet_activity_logs' as any)
          .insert({
            timesheet_id: timesheetEntry.id,
            activity_type: 'TASK_START',
            activity_description: 'Started working on task',
            task_id: taskId,
          } as any);
      }

      setCurrentSession(timesheetEntry as unknown as TimesheetEntry);
      setInactivityWarning(false);
      toast.success(taskId ? 'Clocked in with task tracking' : 'Clocked in successfully');
      fetchTimesheets();
    } catch (error: any) {
      toast.error('Failed to clock in: ' + error.message);
    }
  };

  const handleClockOut = async () => {
    if (!currentSession) return;

    try {
      const { error } = await supabase
        .from('timesheets' as any)
        .update({
          clock_out: new Date().toISOString(),
          status: 'completed'
        } as any)
        .eq('id', currentSession.id);

      if (error) throw error;

      setCurrentSession(null);
      setInactivityWarning(false);
      toast.success('Clocked out successfully');
      fetchTimesheets();
    } catch (error: any) {
      toast.error('Failed to clock out: ' + error.message);
    }
  };

  const updateActivity = async () => {
    if (!currentSession || currentSession.clock_out) return;
    
    try {
      await supabase
        .from('timesheets' as any)
        .update({
          last_activity: new Date().toISOString(),
          activity_count: (currentSession.activity_count || 0) + 1
        } as any)
        .eq('id', currentSession.id);
    } catch (error) {
      console.error('Failed to update activity:', error);
    }
  };

  // Call updateActivity on user interactions
  useEffect(() => {
    const handleUserActivity = () => updateActivity();
    
    if (currentSession && !currentSession.clock_out) {
      window.addEventListener('click', handleUserActivity);
      window.addEventListener('keypress', handleUserActivity);
      
      return () => {
        window.removeEventListener('click', handleUserActivity);
        window.removeEventListener('keypress', handleUserActivity);
      };
    }
  }, [currentSession]);

  const handleManualEntry = async (data: { clockIn: string; clockOut: string; reason: string; notes: string }) => {
    try {
      const { error } = await supabase
        .from('timesheets' as any)
        .insert({
          admin_id: user?.id,
          clock_in: new Date(data.clockIn).toISOString(),
          clock_out: new Date(data.clockOut).toISOString(),
          status: 'pending_approval',
          manual_entry: true,
          manual_entry_reason: data.reason,
          notes: data.notes
        } as any);

      if (error) {
        // Handle specific validation errors with user-friendly messages
        if (error.message.includes('overlaps')) {
          toast.error('This timesheet entry overlaps with an existing session', {
            description: 'Please check your existing entries and try different times.'
          });
        } else if (error.message.includes('future')) {
          toast.error('Cannot create entries with future timestamps', {
            description: 'All timestamps must be in the past.'
          });
        } else {
          throw error;
        }
        return;
      }

      toast.success('Manual entry submitted for Super Admin approval', {
        description: 'You will be notified once reviewed.'
      });
      setManualEntryOpen(false);
      fetchTimesheets();
    } catch (error: any) {
      toast.error('Failed to create manual entry: ' + error.message);
    }
  };

  const formatDuration = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleApprove = async (entryId: string) => {
    try {
      const { error } = await supabase
        .from('timesheets' as any)
        .update({
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
          status: 'approved'
        } as any)
        .eq('id', entryId);

      if (error) throw error;

      toast.success('Timesheet entry approved');
      setApprovalDialogOpen(false);
      fetchTimesheets();
    } catch (error: any) {
      toast.error('Failed to approve entry: ' + error.message);
    }
  };

  const handleReject = async (entryId: string) => {
    if (!rejectionReason.trim()) {
      toast.error('Please provide a rejection reason');
      return;
    }

    try {
      const { error } = await supabase
        .from('timesheets' as any)
        .update({
          approved_by: user?.id,
          approved_at: new Date().toISOString(),
          status: 'rejected',
          rejection_reason: rejectionReason
        } as any)
        .eq('id', entryId);

      if (error) throw error;

      toast.success('Timesheet entry rejected');
      setApprovalDialogOpen(false);
      setRejectionReason('');
      fetchTimesheets();
    } catch (error: any) {
      toast.error('Failed to reject entry: ' + error.message);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-500"><CheckCircle className="h-3 w-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Rejected</Badge>;
      case 'completed':
        return <Badge className="bg-blue-500"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'pending_approval':
        return <Badge variant="outline" className="border-orange-500 text-orange-500"><Clock className="h-3 w-3 mr-1" />Pending Approval</Badge>;
      case 'auto_timeout':
        return <Badge variant="secondary"><AlertTriangle className="h-3 w-3 mr-1" />Auto Timeout</Badge>;
      case 'active':
        return <Badge className="bg-purple-500"><Activity className="h-3 w-3 mr-1" />Active</Badge>;
      case 'adjusted':
        return <Badge variant="outline"><FileText className="h-3 w-3 mr-1" />Adjusted</Badge>;
      case 'archived':
        return <Badge variant="secondary">Archived</Badge>;
      default:
        return <Badge variant="secondary"><AlertCircle className="h-3 w-3 mr-1" />Pending</Badge>;
    }
  };

  // Access control check
  if (!isAdmin && !isSuperAdmin) {
    return (
      <div className="flex flex-col items-center justify-center h-64 space-y-4">
        <AlertCircle className="h-12 w-12 text-destructive" />
        <div className="text-center space-y-2">
          <h3 className="text-lg font-semibold">Access Denied</h3>
          <p className="text-muted-foreground">
            You need Admin or Super Admin privileges to access Timesheet Management.
          </p>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <p className="text-muted-foreground">Loading timesheets...</p>
      </div>
    );
  }

  const exportToCSV = () => {
    const headers = ['Clock In', 'Clock Out', 'Duration (hrs)', 'Type', 'Status', 'Activities', 'Notes'];
    const rows = timesheets.map(entry => [
      format(new Date(entry.clock_in), 'yyyy-MM-dd HH:mm'),
      entry.clock_out ? format(new Date(entry.clock_out), 'yyyy-MM-dd HH:mm') : 'Active',
      entry.total_duration?.toFixed(2) || '0',
      entry.manual_entry ? 'Manual' : 'Auto',
      entry.status,
      entry.activity_count || 0,
      entry.manual_entry_reason || entry.adjustment_reason || entry.notes || ''
    ]);

    const csvContent = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `timesheet-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    a.click();
    toast.success('Timesheet exported to CSV');
  };

  const exportToExcel = () => {
    const data = timesheets.map(entry => ({
      'Clock In': format(new Date(entry.clock_in), 'yyyy-MM-dd HH:mm'),
      'Clock Out': entry.clock_out ? format(new Date(entry.clock_out), 'yyyy-MM-dd HH:mm') : 'Active',
      'Duration (hrs)': entry.total_duration?.toFixed(2) || '0',
      'Type': entry.manual_entry ? 'Manual' : 'Auto',
      'Status': entry.status,
      'Activities': entry.activity_count || 0,
      'Notes': entry.manual_entry_reason || entry.adjustment_reason || entry.notes || ''
    }));

    const worksheet = XLSX.utils.json_to_sheet(data);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Timesheets');
    
    // Add summary sheet
    const summaryData = [
      { Metric: 'Total Hours', Value: stats.totalHours },
      { Metric: 'This Week', Value: stats.thisWeek },
      { Metric: 'Overtime', Value: stats.overtime },
      { Metric: 'Pending Entries', Value: stats.pending },
      { Metric: 'Approved Entries', Value: stats.approved },
    ];
    const summarySheet = XLSX.utils.json_to_sheet(summaryData);
    XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary');
    
    XLSX.writeFile(workbook, `timesheet-${format(new Date(), 'yyyy-MM-dd')}.xlsx`);
    toast.success('Timesheet exported to Excel');
  };

  const exportToPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      toast.error('Please allow popups to export PDF');
      return;
    }

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Timesheet Report - ${format(new Date(), 'yyyy-MM-dd')}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            h1 { color: #333; border-bottom: 2px solid #666; padding-bottom: 10px; }
            .summary { display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin: 20px 0; }
            .summary-card { border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
            .summary-card h3 { margin: 0 0 5px 0; color: #666; font-size: 12px; }
            .summary-card p { margin: 0; font-size: 24px; font-weight: bold; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }
            th { background-color: #f4f4f4; font-weight: bold; }
            tr:nth-child(even) { background-color: #f9f9f9; }
            .footer { margin-top: 30px; text-align: center; color: #666; font-size: 12px; }
            @media print {
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <button class="no-print" onclick="window.print()" style="padding: 10px 20px; margin-bottom: 20px; cursor: pointer;">
            Print / Save as PDF
          </button>
          <h1>Timesheet Report</h1>
          <p><strong>Generated:</strong> ${format(new Date(), 'MMMM dd, yyyy HH:mm')}</p>
          <p><strong>Period:</strong> ${dateFilter === 'today' ? 'Today' : dateFilter === 'week' ? 'This Week' : dateFilter === 'month' ? 'This Month' : dateFilter}</p>
          
          <div class="summary">
            <div class="summary-card">
              <h3>Total Hours</h3>
              <p>${stats.totalHours}h</p>
            </div>
            <div class="summary-card">
              <h3>This Week</h3>
              <p>${stats.thisWeek}h</p>
            </div>
            <div class="summary-card">
              <h3>Overtime</h3>
              <p>${stats.overtime}h</p>
            </div>
            <div class="summary-card">
              <h3>Pending</h3>
              <p>${stats.pending}</p>
            </div>
            <div class="summary-card">
              <h3>Approved</h3>
              <p>${stats.approved}</p>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Clock In</th>
                <th>Clock Out</th>
                <th>Duration</th>
                <th>Type</th>
                <th>Status</th>
                <th>Activities</th>
                <th>Notes</th>
              </tr>
            </thead>
            <tbody>
              ${timesheets.map(entry => `
                <tr>
                  <td>${format(new Date(entry.clock_in), 'MMM dd, HH:mm')}</td>
                  <td>${entry.clock_out ? format(new Date(entry.clock_out), 'MMM dd, HH:mm') : 'Active'}</td>
                  <td>${entry.total_duration?.toFixed(2) || '0'}h</td>
                  <td>${entry.manual_entry ? 'Manual' : 'Auto'}</td>
                  <td>${entry.status}</td>
                  <td>${entry.activity_count || 0}</td>
                  <td>${entry.manual_entry_reason || entry.adjustment_reason || entry.notes || '-'}</td>
                </tr>
              `).join('')}
            </tbody>
          </table>

          <div class="footer">
            <p>This is an automated report generated from the Timesheet Management system.</p>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
    toast.success('PDF preview opened - use Print dialog to save');
  };

  // Show loading state
  if (loading && !isAdmin && !isSuperAdmin) {
    console.log('[Timesheet] Showing loading state - loading:', loading, 'isAdmin:', isAdmin, 'isSuperAdmin:', isSuperAdmin);
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-4">
          <Clock className="h-12 w-12 animate-spin mx-auto text-muted-foreground" />
          <p className="text-muted-foreground">Loading timesheet...</p>
        </div>
      </div>
    );
  }

  // Show no access state if user doesn't have admin role
  if (!isAdmin && !isSuperAdmin && !loading) {
    console.log('[Timesheet] Showing no access state');
    return (
      <Card className="p-8">
        <div className="text-center space-y-4">
          <AlertTriangle className="h-16 w-16 mx-auto text-destructive" />
          <div>
            <h3 className="text-xl font-semibold mb-2">Access Denied</h3>
            <p className="text-muted-foreground">
              You need Admin or Super Admin privileges to access the Timesheet Management system.
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              If you believe this is an error, please contact your system administrator.
            </p>
          </div>
        </div>
      </Card>
    );
  }

  console.log('[Timesheet] Rendering timesheet UI');
  
  return (
    <div className="space-y-6">
      {/* Modern Page Header with gradient */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-2 border-primary/20 p-8">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-3xl"></div>
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="p-4 rounded-2xl bg-gradient-to-br from-primary to-primary/80 text-primary-foreground shadow-xl transform hover:scale-110 transition-all duration-300">
                <ClockIcon className="h-8 w-8" />
              </div>
              <div>
                <div className="flex items-center gap-3">
                  <h1 className="text-4xl font-bold bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text text-transparent">
                    Timesheet Management
                  </h1>
                  <Badge 
                    variant={isSuperAdmin ? "default" : "secondary"}
                    className={isSuperAdmin ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg" : ""}
                  >
                    {isSuperAdmin ? "Super Admin" : "Admin"}
                  </Badge>
                </div>
                <p className="text-lg text-muted-foreground mt-1">
                  Track and manage work hours with precision
                </p>
              </div>
            </div>
            
            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3">
              <Button 
                onClick={() => setManualEntryOpen(true)}
                size="lg"
                variant="outline"
                className="border-2 hover:border-primary hover:bg-primary/5 transition-all duration-300 hover:scale-105 shadow-sm"
              >
                <FilePlus className="h-5 w-5 mr-2" />
                Manual Entry
              </Button>
              
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button 
                    variant="outline" 
                    size="lg"
                    className="border-2 hover:border-primary hover:bg-primary/5 transition-all duration-300 hover:scale-105 shadow-sm"
                  >
                    <FileDown className="h-5 w-5 mr-2" />
                    Export
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="z-50 bg-background border-2">
                  <DropdownMenuItem onClick={exportToCSV} className="cursor-pointer">
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Export as CSV
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={exportToExcel} className="cursor-pointer">
                    <FileSpreadsheet className="h-4 w-4 mr-2" />
                    Export as Excel
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              {isSuperAdmin && (
                <Button
                  onClick={() => setViewAllTimesheets(!viewAllTimesheets)}
                  variant={viewAllTimesheets ? 'default' : 'outline'}
                  size="lg"
                  className="border-2 transition-all duration-300 hover:scale-105 shadow-sm"
                >
                  <Activity className="h-5 w-5 mr-2" />
                  {viewAllTimesheets ? 'My Timesheets' : 'All Timesheets'}
                </Button>
              )}
            </div>
          </div>
          
          {/* Super Admin Filters */}
          {isSuperAdmin && viewAllTimesheets && (
            <div className="mt-6 p-4 rounded-xl bg-background/50 backdrop-blur-sm border border-border/50 animate-fade-in">
              <Label className="text-sm font-semibold mb-2 block">Filter by Admin</Label>
              <Select value={selectedAdminFilter} onValueChange={setSelectedAdminFilter}>
                <SelectTrigger className="w-full md:w-[300px] h-11 bg-background">
                  <SelectValue placeholder="Filter by admin" />
                </SelectTrigger>
                <SelectContent className="bg-background border-2 shadow-lg z-50 max-h-[400px]">
                  <SelectItem value="all" className="font-semibold">All Admins</SelectItem>
                  {allAdmins.map((admin) => (
                    <SelectItem 
                      key={admin.id} 
                      value={admin.id}
                      className="pl-4"
                    >
                      <div className="flex flex-col gap-1">
                        <span className="font-medium">
                          {admin.full_name || admin.email}
                        </span>
                        {admin.sub_role && (
                          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded-full inline-block w-fit">
                            {admin.role_key === 'super_admin' ? 'Super Admin' : 'Admin'} • {admin.sub_role}
                          </span>
                        )}
                        {!admin.sub_role && (
                          <span className="text-xs text-muted-foreground">
                            {admin.role_key === 'super_admin' ? 'Super Admin' : 'Admin'}
                          </span>
                        )}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
        </div>
      </div>

      {/* Inactivity Warning */}
      {inactivityWarning && (
        <Alert className="animate-fade-in bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 border-2 border-amber-500/50 shadow-lg">
          <AlertTriangle className="h-5 w-5 text-amber-600" />
          <AlertDescription className="text-amber-900 dark:text-amber-100 font-medium">
            You will be automatically clocked out after 60 minutes of inactivity. Please click anywhere to stay active.
          </AlertDescription>
        </Alert>
      )}

      {/* Modern Summary Stats */}
      <ModernSummaryStats stats={stats} />

      {/* Weekly Summary */}
      <WeeklySummaryCard />

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 h-14 bg-muted/30 p-1.5 rounded-xl border-2 border-border/50">
          <TabsTrigger 
            value="tracking" 
            className="data-[state=active]:bg-background data-[state=active]:shadow-md data-[state=active]:text-primary rounded-lg font-semibold text-base transition-all duration-300 data-[state=active]:scale-105"
          >
            <Timer className="h-4 w-4 mr-2" />
            Time Tracking
          </TabsTrigger>
          <TabsTrigger 
            value="history"
            className="data-[state=active]:bg-background data-[state=active]:shadow-md data-[state=active]:text-primary rounded-lg font-semibold text-base transition-all duration-300 data-[state=active]:scale-105"
          >
            <FileText className="h-4 w-4 mr-2" />
            History & Reports
          </TabsTrigger>
          <TabsTrigger 
            value="analytics"
            className="data-[state=active]:bg-background data-[state=active]:shadow-md data-[state=active]:text-primary rounded-lg font-semibold text-base transition-all duration-300 data-[state=active]:scale-105"
          >
            <TrendingUp className="h-4 w-4 mr-2" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tracking" className="space-y-6 animate-fade-in">
          {/* Info Alert for Super Admin viewing others */}
          {isSuperAdmin && viewAllTimesheets && (
            <Alert className="bg-blue-50 dark:bg-blue-950/20 border-2 border-blue-200 dark:border-blue-900">
              <AlertCircle className="h-5 w-5 text-blue-600" />
              <AlertDescription className="text-blue-900 dark:text-blue-100 font-medium">
                You are viewing {selectedAdminFilter === 'all' ? 'all admins' : 'a specific admin'}. 
                Clock In/Out is disabled in this view. Switch to "My Timesheets" to manage your own timesheet.
              </AlertDescription>
            </Alert>
          )}

          {/* Clock In/Out Card - Only for own timesheets */}
          {(!isSuperAdmin || !viewAllTimesheets) && (
            <ClockInOutCard
              currentSession={currentSession}
              elapsedTime={elapsedTime}
              availableTasks={availableTasks}
              onClockIn={(taskId) => handleClockIn(taskId)}
              onClockOut={handleClockOut}
              onManualEntry={() => setManualEntryOpen(true)}
              formatDuration={formatDuration}
            />
          )}

        </TabsContent>

        <TabsContent value="history" className="space-y-6 animate-fade-in">
          {/* Modern Filters Card */}
          <Card className="border-2 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-muted/30 to-transparent">
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center gap-2 text-xl">
                  <Filter className="h-5 w-5 text-primary" />
                  Filters & Export
                </span>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="border-2 hover:border-primary hover:scale-105 transition-all duration-300"
                    >
                      <FileDown className="h-4 w-4 mr-2" />
                      Export Report
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-background border-2">
                    <DropdownMenuItem onClick={exportToCSV} className="cursor-pointer">
                      <FileText className="h-4 w-4 mr-2" />
                      Export as CSV
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={exportToExcel} className="cursor-pointer">
                      <FileSpreadsheet className="h-4 w-4 mr-2" />
                      Export as Excel
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={exportToPDF} className="cursor-pointer">
                      <FileDown className="h-4 w-4 mr-2" />
                      Export as PDF
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <Label htmlFor="date-filter" className="text-sm font-semibold flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-primary" />
                    Date Range
                  </Label>
                  <Select value={dateFilter} onValueChange={setDateFilter}>
                    <SelectTrigger id="date-filter" className="h-11 bg-background border-2 hover:border-primary transition-colors">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background">
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">This Week</SelectItem>
                      <SelectItem value="month">This Month</SelectItem>
                      <SelectItem value="7days">Last 7 Days</SelectItem>
                      <SelectItem value="30days">Last 30 Days</SelectItem>
                      <SelectItem value="all">All Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-3">
                  <Label htmlFor="status-filter" className="text-sm font-semibold flex items-center gap-2">
                    <Activity className="h-4 w-4 text-primary" />
                    Status Filter
                  </Label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger id="status-filter" className="h-11 bg-background border-2 hover:border-primary transition-colors">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background">
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="pending_approval">Pending Approval</SelectItem>
                      <SelectItem value="approved">Approved</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Timesheet History */}
          <Card className="border-2 shadow-lg">
            <CardHeader className="bg-gradient-to-r from-muted/30 to-transparent">
              <CardTitle className="text-xl">Timesheet History</CardTitle>
              <CardDescription className="text-base">
                Showing {timesheets.length} entries • Total: {stats.totalHours.toFixed(1)}h
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <TimesheetTable
                timesheets={timesheets}
                isSuperAdmin={isSuperAdmin}
                viewAllTimesheets={viewAllTimesheets}
                onViewDetails={(entry) => {
                  setSelectedTimesheet(entry);
                  fetchActivityLogs(entry.id);
                  setActivityLogsOpen(true);
                }}
                onApprove={handleApprove}
                onReject={(entryId) => {
                  const entry = timesheets.find(t => t.id === entryId);
                  if (entry) {
                    setSelectedEntry(entry);
                    setApprovalDialogOpen(true);
                  }
                }}
              />
            </CardContent>
          </Card>

          {/* Activity Chart */}
          <AdminActivityChart timesheets={timesheets} />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <TimesheetAnalytics timesheets={timesheets} />
        </TabsContent>
      </Tabs>

      {/* Manual Entry Dialog */}
      <ManualEntryForm
        open={manualEntryOpen}
        onOpenChange={setManualEntryOpen}
        onSubmit={handleManualEntry}
      />

      {/* Approval Dialog */}
      <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Timesheet Entry</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this timesheet entry
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rejection-reason">Rejection Reason *</Label>
              <Textarea
                id="rejection-reason"
                placeholder="e.g., Overlapping times, Invalid timestamps, etc."
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={4}
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setApprovalDialogOpen(false);
              setRejectionReason('');
              setSelectedEntry(null);
            }}>
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={() => selectedEntry && handleReject(selectedEntry.id)}
            >
              Reject Entry
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Activity Logs Dialog */}
      <Dialog open={activityLogsOpen} onOpenChange={setActivityLogsOpen}>
        <DialogContent className="max-w-3xl max-h-[600px]">
          <DialogHeader>
            <DialogTitle>Timesheet Details & Activity Logs</DialogTitle>
            <DialogDescription>
              {selectedTimesheet && (
                <div className="mt-2 space-y-1">
                  <div><strong>Date:</strong> {format(new Date(selectedTimesheet.date), 'MMMM dd, yyyy (EEEE)')}</div>
                  <div><strong>Clock In:</strong> {format(new Date(selectedTimesheet.clock_in), 'HH:mm:ss')}</div>
                  <div><strong>Clock Out:</strong> {selectedTimesheet.clock_out ? format(new Date(selectedTimesheet.clock_out), 'HH:mm:ss') : 'Active'}</div>
                  <div><strong>Duration:</strong> {selectedTimesheet.total_duration?.toFixed(2) || '0'}h</div>
                  <div><strong>Status:</strong> {selectedTimesheet.status}</div>
                </div>
              )}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2 flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Activity Logs ({activityLogs.length})
              </h4>
              {activityLogs.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">
                  No activity logs recorded for this session
                </p>
              ) : (
                <div className="space-y-2 max-h-[300px] overflow-y-auto">
                  {activityLogs.map((log) => (
                    <div key={log.id} className="border rounded-lg p-3 space-y-1">
                      <div className="flex items-start justify-between">
                        <Badge variant="outline">{log.activity_type}</Badge>
                        <span className="text-xs text-muted-foreground">
                          {format(new Date(log.created_at), 'MMM dd, HH:mm:ss')}
                        </span>
                      </div>
                      {log.activity_description && (
                        <p className="text-sm">{log.activity_description}</p>
                      )}
                      {log.metadata && Object.keys(log.metadata).length > 0 && (
                        <details className="text-xs">
                          <summary className="cursor-pointer text-muted-foreground">Metadata</summary>
                          <pre className="mt-1 p-2 bg-muted rounded text-xs overflow-x-auto">
                            {JSON.stringify(log.metadata, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {selectedTimesheet?.notes && (
              <div>
                <h4 className="font-semibold mb-2">Notes</h4>
                <p className="text-sm bg-muted p-3 rounded">{selectedTimesheet.notes}</p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button onClick={() => setActivityLogsOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
