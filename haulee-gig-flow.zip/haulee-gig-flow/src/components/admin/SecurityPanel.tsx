import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, FileText, Eye, AlertTriangle } from 'lucide-react';
import { FinancialAuditLogs } from './FinancialAuditLogs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

export function SecurityPanel() {
  return (
    <div className="space-y-6">
      {/* Security Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-green-200 bg-green-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Shield className="h-4 w-4 text-green-600" />
              Financial Data Protection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700">Active</div>
            <p className="text-xs text-muted-foreground mt-1">
              All financial data is masked and access-logged
            </p>
          </CardContent>
        </Card>

        <Card className="border-blue-200 bg-blue-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <FileText className="h-4 w-4 text-blue-600" />
              Audit Logging
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700">Enabled</div>
            <p className="text-xs text-muted-foreground mt-1">
              All access attempts are tracked
            </p>
          </CardContent>
        </Card>

        <Card className="border-purple-200 bg-purple-50/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Eye className="h-4 w-4 text-purple-600" />
              Data Masking
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700">Active</div>
            <p className="text-xs text-muted-foreground mt-1">
              Sensitive data automatically masked
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Security Alerts */}
      <Alert className="border-yellow-200 bg-yellow-50">
        <AlertTriangle className="h-4 w-4 text-yellow-600" />
        <AlertTitle className="text-yellow-800">Security Recommendation</AlertTitle>
        <AlertDescription className="text-yellow-700">
          Enable leaked password protection in your Supabase Auth settings for enhanced security.
          This will prevent users from using commonly compromised passwords.
        </AlertDescription>
      </Alert>

      {/* Security Features Tabs */}
      <Tabs defaultValue="audit-logs" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="audit-logs">Audit Logs</TabsTrigger>
          <TabsTrigger value="data-protection">Data Protection</TabsTrigger>
          <TabsTrigger value="access-controls">Access Controls</TabsTrigger>
        </TabsList>

        <TabsContent value="audit-logs" className="space-y-4">
          <FinancialAuditLogs />
        </TabsContent>

        <TabsContent value="data-protection" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Financial Data Protection Status</CardTitle>
              <CardDescription>
                Overview of security measures protecting sensitive financial information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Implemented Protections</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Credit card number masking (show last 4 digits)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Bank account number masking (show last 4 digits)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Routing number partial masking</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">CVV code completely hidden</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Admin-only unmasked data access</span>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <h4 className="font-semibold text-sm">Security Features</h4>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Comprehensive access logging</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">IP address tracking</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Row-level security policies</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Secure database functions</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">Admin confirmation dialogs</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="access-controls" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Access Control Matrix</CardTitle>
              <CardDescription>
                Role-based permissions for financial data access
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-4 text-sm font-medium border-b pb-2">
                  <div>Role</div>
                  <div>View Own Data</div>
                  <div>View All Data</div>
                  <div>Unmasked Access</div>
                </div>
                
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div className="font-medium">Vendor</div>
                  <div className="text-green-600">✓ Allowed</div>
                  <div className="text-red-600">✗ Denied</div>
                  <div className="text-green-600">✓ Own Data Only</div>
                </div>
                
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div className="font-medium">Driver</div>
                  <div className="text-red-600">✗ N/A</div>
                  <div className="text-red-600">✗ Denied</div>
                  <div className="text-red-600">✗ Denied</div>
                </div>
                
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div className="font-medium">Admin</div>
                  <div className="text-green-600">✓ Allowed</div>
                  <div className="text-green-600">✓ Allowed</div>
                  <div className="text-green-600">✓ All Data</div>
                </div>
                
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div className="font-medium">Super Admin</div>
                  <div className="text-green-600">✓ Allowed</div>
                  <div className="text-green-600">✓ Allowed</div>
                  <div className="text-green-600">✓ All Data</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}