import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Loader2, Users } from 'lucide-react';

export const SetupDemoButton: React.FC = () => {
  const [loading, setLoading] = useState(false);

  const handleSetupDemo = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('setup-demo-accounts', {
        method: 'POST',
      });

      if (error) throw error;

      toast({
        title: "Demo Accounts Created",
        description: "All demo accounts have been set up successfully with sample data.",
      });

      console.log('Demo setup results:', data);
    } catch (error) {
      console.error('Demo setup error:', error);
      toast({
        title: "Setup Failed",
        description: "Failed to create demo accounts. Check console for details.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button onClick={handleSetupDemo} disabled={loading} variant="outline" className="gap-2">
      {loading ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          Setting up...
        </>
      ) : (
        <>
          <Users className="h-4 w-4" />
          Setup Demo Accounts
        </>
      )}
    </Button>
  );
};
