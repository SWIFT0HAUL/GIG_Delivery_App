import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { CheckCircle2, XCircle, Clock, MapPin, Package, User } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';

interface AuthRequest {
  id: string;
  driver_id: string;
  job_id: string;
  status: 'pending' | 'approved' | 'rejected';
  driver_current_jobs: any[];
  driver_location: { lat: number; lng: number } | null;
  request_reason: string | null;
  admin_notes: string | null;
  reviewed_by: string | null;
  reviewed_at: string | null;
  created_at: string;
}

export const JobClaimAuthorizationManager: React.FC = () => {
  const queryClient = useQueryClient();
  const [selectedRequest, setSelectedRequest] = useState<AuthRequest | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [adminNotes, setAdminNotes] = useState('');
  const [actionType, setActionType] = useState<'approve' | 'reject'>('approve');

  // Fetch pending authorization requests
  const { data: requests = [], isLoading } = useQuery({
    queryKey: ['job-claim-auth-requests'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('job_claim_authorization_requests')
        .select(`
          *,
          driver:driver_id(full_name, email, phone),
          job:job_id(title, pickup_location, delivery_location, pay_amount, status)
        `)
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as any[];
    },
    refetchInterval: 10000
  });

  // Approve mutation
  const approveMutation = useMutation({
    mutationFn: async ({ requestId, notes }: { requestId: string; notes: string }) => {
      const { data, error } = await supabase.rpc('approve_job_claim_request', {
        p_request_id: requestId,
        p_admin_notes: notes || null
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Authorization request approved');
      queryClient.invalidateQueries({ queryKey: ['job-claim-auth-requests'] });
      setDialogOpen(false);
      setAdminNotes('');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to approve request');
    }
  });

  // Reject mutation
  const rejectMutation = useMutation({
    mutationFn: async ({ requestId, notes }: { requestId: string; notes: string }) => {
      const { data, error } = await supabase.rpc('reject_job_claim_request', {
        p_request_id: requestId,
        p_admin_notes: notes || null
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast.success('Authorization request rejected');
      queryClient.invalidateQueries({ queryKey: ['job-claim-auth-requests'] });
      setDialogOpen(false);
      setAdminNotes('');
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to reject request');
    }
  });

  const handleAction = (request: AuthRequest, action: 'approve' | 'reject') => {
    setSelectedRequest(request);
    setActionType(action);
    setDialogOpen(true);
  };

  const handleConfirmAction = () => {
    if (!selectedRequest) return;

    if (actionType === 'approve') {
      approveMutation.mutate({ requestId: selectedRequest.id, notes: adminNotes });
    } else {
      rejectMutation.mutate({ requestId: selectedRequest.id, notes: adminNotes });
    }
  };

  if (isLoading) {
    return (
      <Card className="p-4">
        <div className="text-sm text-muted-foreground">Loading authorization requests...</div>
      </Card>
    );
  }

  if (requests.length === 0) {
    return (
      <Card className="p-4">
        <div className="text-sm text-muted-foreground text-center">
          No pending authorization requests
        </div>
      </Card>
    );
  }

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Job Claim Authorization Requests</h3>
          <Badge variant="secondary">
            {requests.length} pending
          </Badge>
        </div>

        {requests.map((request) => (
          <Card key={request.id} className="p-4">
            <div className="space-y-3">
              {/* Header */}
              <div className="flex items-start justify-between">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-muted-foreground" />
                    <span className="font-medium">{request.driver?.full_name}</span>
                    <Badge variant="outline" className="gap-1">
                      <Clock className="h-3 w-3" />
                      {format(new Date(request.created_at), 'MMM d, HH:mm')}
                    </Badge>
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {request.driver?.email}
                  </div>
                </div>
              </div>

              {/* Job Details */}
              <div className="bg-secondary/50 rounded-md p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <Package className="h-4 w-4 text-primary" />
                  <span className="font-medium text-sm">{request.job?.title}</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-muted-foreground">Pickup:</span>
                    <div className="font-medium">
                      {request.job?.pickup_location?.address || 'N/A'}
                    </div>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Delivery:</span>
                    <div className="font-medium">
                      {request.job?.delivery_location?.address || 'N/A'}
                    </div>
                  </div>
                </div>
                {request.job?.pay_amount && (
                  <div className="text-sm font-semibold text-primary">
                    ${parseFloat(request.job.pay_amount).toFixed(2)}
                  </div>
                )}
              </div>

              {/* Current My Jobs */}
              {request.driver_current_jobs && request.driver_current_jobs.length > 0 && (
                <div className="border-t pt-3">
                  <div className="text-xs font-medium text-muted-foreground mb-2">
                    Driver's My Jobs ({request.driver_current_jobs.length})
                  </div>
                  <div className="space-y-1">
                    {request.driver_current_jobs.map((job: any, idx: number) => (
                      <div key={idx} className="text-xs bg-amber-50 dark:bg-amber-950/20 p-2 rounded">
                        <div className="font-medium">{job.title}</div>
                        <div className="text-muted-foreground">Status: {job.status}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2 pt-2">
                <Button
                  size="sm"
                  variant="default"
                  className="flex-1"
                  onClick={() => handleAction(request, 'approve')}
                  disabled={approveMutation.isPending || rejectMutation.isPending}
                >
                  <CheckCircle2 className="h-4 w-4 mr-1" />
                  Approve
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  className="flex-1"
                  onClick={() => handleAction(request, 'reject')}
                  disabled={approveMutation.isPending || rejectMutation.isPending}
                >
                  <XCircle className="h-4 w-4 mr-1" />
                  Reject
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {actionType === 'approve' ? 'Approve' : 'Reject'} Authorization Request
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              {actionType === 'approve'
                ? 'Approving will automatically assign this job to the driver.'
                : 'The driver will be notified of the rejection.'}
            </p>
            <div className="space-y-2">
              <label className="text-sm font-medium">
                Notes {actionType === 'reject' && '(Required)'}
              </label>
              <Textarea
                placeholder={
                  actionType === 'approve'
                    ? 'Optional notes for approval...'
                    : 'Please provide a reason for rejection...'
                }
                value={adminNotes}
                onChange={(e) => setAdminNotes(e.target.value)}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              variant={actionType === 'approve' ? 'default' : 'destructive'}
              onClick={handleConfirmAction}
              disabled={
                (actionType === 'reject' && !adminNotes.trim()) ||
                approveMutation.isPending ||
                rejectMutation.isPending
              }
            >
              {actionType === 'approve' ? 'Approve' : 'Reject'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};
