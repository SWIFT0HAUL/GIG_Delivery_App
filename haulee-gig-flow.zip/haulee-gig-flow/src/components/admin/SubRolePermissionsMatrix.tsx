import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Grid3x3, Search, Save } from 'lucide-react';
import { ALL_SUB_ROLES } from '@/lib/subRoleConfig';

interface Permission {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
}

interface SubRolePermission {
  sub_role: string;
  permission_id: string;
}

export const SubRolePermissionsMatrix = () => {
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [subRolePermissions, setSubRolePermissions] = useState<Map<string, Set<string>>>(new Map());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [hasChanges, setHasChanges] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch all permissions
      const { data: perms, error: permsError } = await supabase
        .from('permissions')
        .select('*')
        .order('category', { ascending: true });

      if (permsError) throw permsError;
      setPermissions(perms || []);

      // Note: This is a conceptual implementation
      // You would need to create a sub_role_permissions table in your database
      // For now, we'll initialize with empty permissions
      const permMap = new Map<string, Set<string>>();
      ALL_SUB_ROLES.forEach(subRole => {
        permMap.set(subRole.value, new Set<string>());
      });
      setSubRolePermissions(permMap);

    } catch (error: any) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load permissions matrix');
    } finally {
      setLoading(false);
    }
  };

  const togglePermission = (subRoleValue: string, permissionId: string) => {
    setSubRolePermissions(prev => {
      const newMap = new Map(prev);
      const perms = new Set<string>(newMap.get(subRoleValue) || new Set<string>());
      
      if (perms.has(permissionId)) {
        perms.delete(permissionId);
      } else {
        perms.add(permissionId);
      }
      
      newMap.set(subRoleValue, perms);
      setHasChanges(true);
      return newMap;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Note: You'll need to implement this in your database
      // This would typically involve:
      // 1. Creating a sub_role_permissions table
      // 2. Clearing existing permissions for all sub-roles
      // 3. Inserting new permissions
      
      toast.success('Sub-role permissions saved successfully');
      setHasChanges(false);
    } catch (error: any) {
      console.error('Error saving permissions:', error);
      toast.error('Failed to save permissions');
    } finally {
      setSaving(false);
    }
  };

  const filteredPermissions = permissions.filter(perm =>
    perm.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    perm.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const groupedPermissions = filteredPermissions.reduce((acc, perm) => {
    const category = perm.category || 'Uncategorized';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(perm);
    return acc;
  }, {} as Record<string, Permission[]>);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Grid3x3 className="h-5 w-5" />
              Sub-Role Permissions Matrix
            </CardTitle>
            <CardDescription>
              Assign permissions to each sub-role. These permissions complement the primary role permissions.
            </CardDescription>
          </div>
          {hasChanges && (
            <Button onClick={handleSave} disabled={saving}>
              {saving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save Changes
                </>
              )}
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search permissions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <ScrollArea className="h-[600px] rounded-md border">
          <div className="p-4">
            {Object.entries(groupedPermissions).map(([category, perms]) => (
              <div key={category} className="mb-6">
                <h3 className="text-sm font-semibold mb-3 uppercase text-muted-foreground sticky top-0 bg-background py-2">
                  {category}
                </h3>
                <div className="space-y-2">
                  {perms.map((permission) => (
                    <div key={permission.id} className="border rounded-lg p-4 bg-card">
                      <div className="flex items-start gap-3 mb-3">
                        <div className="flex-1">
                          <div className="font-semibold text-sm">{permission.name}</div>
                          {permission.description && (
                            <div className="text-xs text-muted-foreground mt-1">{permission.description}</div>
                          )}
                        </div>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        {ALL_SUB_ROLES.map((subRole) => {
                          const hasPermission = subRolePermissions.get(subRole.value)?.has(permission.id) || false;
                          return (
                            <div 
                              key={subRole.value}
                              className="flex items-center justify-between space-x-3 p-2 rounded-md border bg-background hover:bg-accent/50 transition-colors"
                            >
                              <Label 
                                htmlFor={`${permission.id}-${subRole.value}`}
                                className="text-sm font-normal cursor-pointer flex-1"
                              >
                                {subRole.label}
                              </Label>
                              <Switch
                                id={`${permission.id}-${subRole.value}`}
                                checked={hasPermission}
                                onCheckedChange={() => togglePermission(subRole.value, permission.id)}
                              />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="text-sm text-muted-foreground">
            <strong>Note:</strong> Sub-role permissions are additive. Users with a sub-role will have both their 
            primary role permissions and their sub-role specific permissions.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default SubRolePermissionsMatrix;
