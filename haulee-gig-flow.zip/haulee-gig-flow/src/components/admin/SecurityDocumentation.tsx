import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Shield, AlertTriangle, CheckCircle, Users, CreditCard, Eye } from 'lucide-react';

export function SecurityDocumentation() {
  return (
    <div className="space-y-6">
      <Card className="border-green-200 bg-green-50/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Shield className="h-5 w-5" />
            Security Vulnerabilities Fixed
          </CardTitle>
          <CardDescription className="text-green-700">
            Critical security issues have been resolved to protect user data
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="font-medium text-green-800">Customer Data Protection</span>
              </div>
              <p className="text-sm text-green-700 pl-6">
                Removed public access to user profiles. Customer emails and names are no longer accessible to unauthorized users or hackers.
              </p>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <span className="font-medium text-green-800">Financial Data Security</span>
              </div>
              <p className="text-sm text-green-700 pl-6">
                Implemented masking and access logging for credit card numbers, bank accounts, and routing numbers in vendor applications.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-red-200 bg-red-50/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-800">
              <AlertTriangle className="h-5 w-5" />
              What Was Vulnerable
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-2">
                <Users className="h-4 w-4 text-red-600 mt-0.5" />
                <div>
                  <span className="font-medium text-red-800 text-sm">Public Profile Access</span>
                  <p className="text-xs text-red-700 mt-1">
                    Anyone could view ALL user profiles including names, emails, and roles - even without logging in.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <CreditCard className="h-4 w-4 text-red-600 mt-0.5" />
                <div>
                  <span className="font-medium text-red-800 text-sm">Exposed Financial Data</span>
                  <p className="text-xs text-red-700 mt-1">
                    Credit card numbers, bank accounts, and routing numbers were visible in vendor applications without proper masking.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-green-200 bg-green-50/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-green-800">
              <Shield className="h-5 w-5" />
              Security Measures Added
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-2">
                <Eye className="h-4 w-4 text-green-600 mt-0.5" />
                <div>
                  <span className="font-medium text-green-800 text-sm">Access Control Policies</span>
                  <p className="text-xs text-green-700 mt-1">
                    Users can only view their own profiles. Admins have controlled access to manage users.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-2">
                <Shield className="h-4 w-4 text-green-600 mt-0.5" />
                <div>
                  <span className="font-medium text-green-800 text-sm">Data Masking & Logging</span>
                  <p className="text-xs text-green-700 mt-1">
                    Financial data is automatically masked. All admin access to sensitive data is logged for audit.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-green-200">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                  Compliance Ready
                </Badge>
                <span className="text-xs text-green-700">
                  Now meets privacy and data protection standards
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Implementation Details</CardTitle>
          <CardDescription>
            Technical security measures implemented
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Database Policies</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Removed public profile access</li>
                <li>• Added user-specific access control</li>
                <li>• Admin-only system statistics</li>
                <li>• Secure database functions</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Data Protection</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Financial data masking</li>
                <li>• CVV codes always hidden</li>
                <li>• Account numbers show last 4 digits</li>
                <li>• Access audit logging</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Application Updates</h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                <li>• Removed public profile routes</li>
                <li>• Updated admin components</li>
                <li>• Secure statistics functions</li>
                <li>• Enhanced error handling</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}