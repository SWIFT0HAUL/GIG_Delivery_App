import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { Bell, Edit, Search, Send, AlertCircle, CheckCircle2, Info, AlertTriangle } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface NotificationEventTemplate {
  id: string;
  event_type: string;
  event_category: string;
  default_title: string;
  default_message: string;
  default_link: string | null;
  is_active: boolean;
  priority: string;
  requires_admin_approval: boolean;
}

export function NotificationEventsManagement() {
  const [events, setEvents] = useState<NotificationEventTemplate[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<NotificationEventTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [editingEvent, setEditingEvent] = useState<NotificationEventTemplate | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    fetchEvents();
  }, []);

  useEffect(() => {
    filterEvents();
  }, [searchQuery, selectedCategory, events]);

  const fetchEvents = async () => {
    try {
      const { data, error } = await supabase
        .from('notification_event_templates')
        .select('*')
        .order('event_category', { ascending: true })
        .order('event_type', { ascending: true });

      if (error) throw error;
      setEvents(data || []);
    } catch (error) {
      console.error('Error fetching events:', error);
      toast({
        title: 'Error',
        description: 'Failed to load notification events',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const filterEvents = () => {
    let filtered = events;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(e => e.event_category === selectedCategory);
    }

    if (searchQuery) {
      filtered = filtered.filter(e =>
        e.event_type.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.default_title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        e.default_message.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredEvents(filtered);
  };

  const categories = Array.from(new Set(events.map(e => e.event_category)));

  const groupedEvents = filteredEvents.reduce((acc, event) => {
    if (!acc[event.event_category]) {
      acc[event.event_category] = [];
    }
    acc[event.event_category].push(event);
    return acc;
  }, {} as Record<string, NotificationEventTemplate[]>);

  const toggleEventStatus = async (eventId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('notification_event_templates')
        .update({ is_active: !currentStatus })
        .eq('id', eventId);

      if (error) throw error;

      setEvents(events.map(e => e.id === eventId ? { ...e, is_active: !currentStatus } : e));
      toast({
        title: 'Success',
        description: `Event ${!currentStatus ? 'enabled' : 'disabled'}`,
      });
    } catch (error) {
      console.error('Error toggling event:', error);
      toast({
        title: 'Error',
        description: 'Failed to update event status',
        variant: 'destructive',
      });
    }
  };

  const handleEditEvent = (event: NotificationEventTemplate) => {
    setEditingEvent(event);
    setIsEditDialogOpen(true);
  };

  const saveEventChanges = async () => {
    if (!editingEvent) return;

    try {
      const { error } = await supabase
        .from('notification_event_templates')
        .update({
          default_title: editingEvent.default_title,
          default_message: editingEvent.default_message,
          default_link: editingEvent.default_link,
          priority: editingEvent.priority,
          requires_admin_approval: editingEvent.requires_admin_approval,
        })
        .eq('id', editingEvent.id);

      if (error) throw error;

      setEvents(events.map(e => e.id === editingEvent.id ? editingEvent : e));
      setIsEditDialogOpen(false);
      toast({
        title: 'Success',
        description: 'Event template updated successfully',
      });
    } catch (error) {
      console.error('Error updating event:', error);
      toast({
        title: 'Error',
        description: 'Failed to update event template',
        variant: 'destructive',
      });
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'urgent': return <AlertCircle className="h-4 w-4 text-destructive" />;
      case 'high': return <AlertTriangle className="h-4 w-4 text-orange-500" />;
      case 'normal': return <Info className="h-4 w-4 text-primary" />;
      case 'low': return <CheckCircle2 className="h-4 w-4 text-muted-foreground" />;
      default: return <Info className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'destructive';
      case 'high': return 'default';
      case 'normal': return 'secondary';
      case 'low': return 'outline';
      default: return 'secondary';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Bell className="h-12 w-12 animate-pulse mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">Loading notification events...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Notification Events Management</h1>
        <p className="text-muted-foreground mt-2">
          Manage all {events.length} notification event types and their templates
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Search Events</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by type, title, or message..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories ({events.length})</SelectItem>
                  {categories.map(cat => (
                    <SelectItem key={cat} value={cat}>
                      {cat} ({events.filter(e => e.event_category === cat).length})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap">
            <Badge variant="secondary">
              Total: {events.length} events
            </Badge>
            <Badge variant="secondary">
              Active: {events.filter(e => e.is_active).length}
            </Badge>
            <Badge variant="outline">
              Inactive: {events.filter(e => !e.is_active).length}
            </Badge>
            <Badge variant="outline">
              Filtered: {filteredEvents.length}
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* Events List */}
      <Accordion type="multiple" className="space-y-4">
        {Object.entries(groupedEvents).map(([category, categoryEvents]) => (
          <AccordionItem key={category} value={category} className="border rounded-lg">
            <AccordionTrigger className="px-4 hover:no-underline">
              <div className="flex items-center justify-between w-full pr-4">
                <div className="flex items-center gap-3">
                  <Bell className="h-5 w-5 text-primary" />
                  <span className="font-semibold">{category}</span>
                  <Badge variant="secondary">{categoryEvents.length} events</Badge>
                </div>
                <Badge variant="outline">
                  {categoryEvents.filter(e => e.is_active).length} active
                </Badge>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 pb-4">
              <div className="space-y-3 mt-3">
                {categoryEvents.map((event) => (
                  <Card key={event.id} className={!event.is_active ? 'opacity-50' : ''}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2 flex-wrap">
                            <code className="text-xs bg-muted px-2 py-1 rounded">
                              {event.event_type}
                            </code>
                            <Badge variant={getPriorityColor(event.priority)}>
                              <span className="flex items-center gap-1">
                                {getPriorityIcon(event.priority)}
                                {event.priority}
                              </span>
                            </Badge>
                            {event.requires_admin_approval && (
                              <Badge variant="outline">Requires Approval</Badge>
                            )}
                          </div>
                          
                          <div>
                            <p className="font-medium">{event.default_title}</p>
                            <p className="text-sm text-muted-foreground">{event.default_message}</p>
                            {event.default_link && (
                              <p className="text-xs text-muted-foreground mt-1">
                                Link: {event.default_link}
                              </p>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditEvent(event)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Switch
                            checked={event.is_active}
                            onCheckedChange={() => toggleEventStatus(event.id, event.is_active)}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      {/* Edit Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Event Template</DialogTitle>
            <DialogDescription>
              Customize the default notification template for this event
            </DialogDescription>
          </DialogHeader>

          {editingEvent && (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Event Type</Label>
                <code className="block text-xs bg-muted px-3 py-2 rounded">
                  {editingEvent.event_type}
                </code>
              </div>

              <div className="space-y-2">
                <Label>Default Title</Label>
                <Input
                  value={editingEvent.default_title}
                  onChange={(e) => setEditingEvent({ ...editingEvent, default_title: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Default Message</Label>
                <Textarea
                  value={editingEvent.default_message}
                  onChange={(e) => setEditingEvent({ ...editingEvent, default_message: e.target.value })}
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Default Link</Label>
                <Input
                  value={editingEvent.default_link || ''}
                  onChange={(e) => setEditingEvent({ ...editingEvent, default_link: e.target.value })}
                  placeholder="/path/to/page"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Priority</Label>
                  <Select
                    value={editingEvent.priority}
                    onValueChange={(value: any) => setEditingEvent({ ...editingEvent, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="normal">Normal</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center space-x-2 pt-8">
                  <Switch
                    checked={editingEvent.requires_admin_approval}
                    onCheckedChange={(checked) => 
                      setEditingEvent({ ...editingEvent, requires_admin_approval: checked })
                    }
                  />
                  <Label>Requires Admin Approval</Label>
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={saveEventChanges}>
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
