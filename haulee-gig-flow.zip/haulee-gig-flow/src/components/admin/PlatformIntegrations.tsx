import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  CreditCard, 
  MapPin, 
  Mail, 
  MessageSquare, 
  Webhook, 
  Database, 
  Key, 
  Eye, 
  EyeOff, 
  Plus, 
  Edit, 
  Trash2, 
  RefreshCw, 
  CheckCircle, 
  XCircle, 
  AlertTriangle 
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

const iconMap: Record<string, any> = {
  CreditCard,
  MapPin,
  Mail,
  MessageSquare,
  Database,
  Webhook
};

interface Integration {
  id: string;
  name: string;
  integration_type: string;
  status: string;
  description: string | null;
  icon: string | null;
  last_sync: string | null;
  config: any;
}

interface ApiKey {
  id: string;
  name: string;
  key_identifier: string;
  encrypted_value: string;
  integration_id: string | null;
  status: string;
  last_used: string | null;
}

interface WebhookType {
  id: string;
  name: string;
  url: string;
  events: string[];
  status: string;
  secret: string | null;
  integration_id: string | null;
  last_triggered: string | null;
}

export function PlatformIntegrations() {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [showApiKey, setShowApiKey] = useState<{ [key: string]: boolean }>({});
  
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [webhooks, setWebhooks] = useState<WebhookType[]>([]);
  
  // Dialog states
  const [isIntegrationDialogOpen, setIsIntegrationDialogOpen] = useState(false);
  const [isApiKeyDialogOpen, setIsApiKeyDialogOpen] = useState(false);
  const [isWebhookDialogOpen, setIsWebhookDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);
  
  // Form states
  const [integrationForm, setIntegrationForm] = useState({ name: '', integration_type: '', description: '', icon: '' });
  const [integrationConfigText, setIntegrationConfigText] = useState<string>('{}');
  const [apiKeyForm, setApiKeyForm] = useState({ name: '', key_identifier: '', encrypted_value: '', integration_id: '' });
  const [webhookForm, setWebhookForm] = useState({ name: '', url: '', events: '', status: 'active', secret: '' });

  // Load data from Supabase
  useEffect(() => {
    loadIntegrations();
    loadApiKeys();
    loadWebhooks();
  }, []);

  const loadIntegrations = async () => {
    try {
      const { data, error } = await supabase
        .from('integrations')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setIntegrations(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const loadApiKeys = async () => {
    try {
      const { data, error } = await supabase
        .from('api_keys')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setApiKeys(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const loadWebhooks = async () => {
    try {
      const { data, error } = await supabase
        .from('webhooks')
        .select('*')
        .order('name');
      
      if (error) throw error;
      setWebhooks(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const toggleApiKeyVisibility = (keyId: string) => {
    setShowApiKey(prev => ({ ...prev, [keyId]: !prev[keyId] }));
  };

  const handleSyncIntegration = async (integrationId: string) => {
    console.log('🔄 Sync button clicked for:', integrationId);
    setLoading(true);
    try {
      const { error } = await supabase
        .from('integrations')
        .update({ last_sync: new Date().toISOString() })
        .eq('id', integrationId);
      
      if (error) throw error;
      
      await loadIntegrations();
      
      toast({
        title: "Sync Completed",
        description: "Integration synced successfully"
      });
    } catch (error: any) {
      console.error('Sync error:', error);
      toast({
        title: "Sync Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConnectIntegration = async (integrationId: string) => {
    console.log('🔌 Connect button clicked for:', integrationId);
    setLoading(true);
    try {
      const { error } = await supabase
        .from('integrations')
        .update({ status: 'connected', last_sync: new Date().toISOString() })
        .eq('id', integrationId);
      
      if (error) throw error;
      
      await loadIntegrations();
      
      toast({
        title: "Integration Connected",
        description: "Integration connected successfully"
      });
    } catch (error: any) {
      console.error('Connect error:', error);
      toast({
        title: "Connection Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteApiKey = async (keyId: string) => {
    if (!confirm('Are you sure you want to delete this API key?')) return;
    
    try {
      const { error } = await supabase
        .from('api_keys')
        .delete()
        .eq('id', keyId);
      
      if (error) throw error;
      
      await loadApiKeys();
      
      toast({
        title: "API Key Deleted",
        description: "API key deleted successfully"
      });
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const handleDeleteWebhook = async (webhookId: string) => {
    if (!confirm('Are you sure you want to delete this webhook?')) return;
    
    try {
      const { error } = await supabase
        .from('webhooks')
        .delete()
        .eq('id', webhookId);
      
      if (error) throw error;
      
      await loadWebhooks();
      
      toast({
        title: "Webhook Deleted",
        description: "Webhook deleted successfully"
      });
    } catch (error: any) {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive"
      });
    }
  };

  const openConfigureDialog = (integration: Integration) => {
    setEditingItem(integration);
    setIntegrationForm({
      name: integration.name,
      integration_type: integration.integration_type,
      description: integration.description || '',
      icon: integration.icon || ''
    });
    setIntegrationConfigText(JSON.stringify(integration.config || {}, null, 2));
    setIsIntegrationDialogOpen(true);
  };

  const openAddApiKeyDialog = () => {
    console.log('🔑 Add API Key button clicked');
    console.log('Dialog state before:', isApiKeyDialogOpen);
    console.log('Form state:', apiKeyForm);
    setEditingItem(null);
    setApiKeyForm({ name: '', key_identifier: '', encrypted_value: '', integration_id: '' });
    setIsApiKeyDialogOpen(true);
    console.log('Dialog state set to true');
  };

  const openEditApiKeyDialog = (apiKey: ApiKey) => {
    setEditingItem(apiKey);
    setApiKeyForm({
      name: apiKey.name,
      key_identifier: apiKey.key_identifier,
      encrypted_value: apiKey.encrypted_value,
      integration_id: apiKey.integration_id || ''
    });
    setIsApiKeyDialogOpen(true);
  };

  const openAddWebhookDialog = () => {
    console.log('🪝 Add Webhook button clicked');
    setEditingItem(null);
    setWebhookForm({ name: '', url: '', events: '', status: 'active', secret: '' });
    setIsWebhookDialogOpen(true);
  };

  const handleSaveApiKey = async () => {
    console.log('💾 Save API Key clicked');
    setLoading(true);
    try {
      if (!apiKeyForm.name || !apiKeyForm.key_identifier || !apiKeyForm.encrypted_value) {
        throw new Error('Name, Key Identifier, and Value are required');
      }

      if (editingItem) {
        // Update existing API key
        const { error } = await supabase
          .from('api_keys')
          .update({
            name: apiKeyForm.name,
            key_identifier: apiKeyForm.key_identifier,
            encrypted_value: apiKeyForm.encrypted_value,
            integration_id: apiKeyForm.integration_id || null
          })
          .eq('id', editingItem.id);

        if (error) throw error;
        toast({ title: 'API Key Updated', description: 'API key updated successfully' });
      } else {
        // Insert new API key
        const { error } = await supabase
          .from('api_keys')
          .insert({
            name: apiKeyForm.name,
            key_identifier: apiKeyForm.key_identifier,
            encrypted_value: apiKeyForm.encrypted_value,
            integration_id: apiKeyForm.integration_id || null,
            status: 'active'
          });

        if (error) throw error;
        toast({ title: 'API Key Added', description: 'API key created successfully' });
      }

      await loadApiKeys();
      setIsApiKeyDialogOpen(false);
    } catch (error: any) {
      console.error('Save API key error:', error);
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveWebhook = async () => {
    console.log('💾 Save Webhook clicked');
    setLoading(true);
    try {
      if (!webhookForm.name || !webhookForm.url || !webhookForm.events) {
        throw new Error('Name, URL, and Events are required');
      }

      const eventsArray = webhookForm.events.split(',').map(e => e.trim()).filter(Boolean);

      const { error } = await supabase
        .from('webhooks')
        .insert({
          name: webhookForm.name,
          url: webhookForm.url,
          events: eventsArray,
          status: webhookForm.status,
          secret: webhookForm.secret || null
        });

      if (error) throw error;

      await loadWebhooks();
      setIsWebhookDialogOpen(false);
      toast({ title: 'Webhook Added', description: 'Webhook created successfully' });
    } catch (error: any) {
      console.error('Save webhook error:', error);
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleSaveIntegrationConfig = async () => {
    console.log('💾 Save config clicked for:', editingItem?.id);
    setLoading(true);
    try {
      let parsedConfig: any = {};
      if (integrationConfigText && integrationConfigText.trim().length > 0) {
        parsedConfig = JSON.parse(integrationConfigText);
      }

      const updatePayload: any = {
        description: integrationForm.description || null,
        icon: integrationForm.icon || null,
        config: parsedConfig,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('integrations')
        .update(updatePayload)
        .eq('id', editingItem.id);

      if (error) throw error;

      await loadIntegrations();
      setIsIntegrationDialogOpen(false);

      toast({ title: 'Saved', description: 'Integration updated.' });
    } catch (e: any) {
      console.error('Save config error:', e);
      toast({ title: 'Invalid JSON', description: e.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
      case 'active':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Connected</Badge>;
      case 'disconnected':
      case 'inactive':
        return <Badge variant="secondary"><XCircle className="w-3 h-3 mr-1" />Disconnected</Badge>;
      case 'error':
        return <Badge variant="destructive"><AlertTriangle className="w-3 h-3 mr-1" />Error</Badge>;
      default:
        return <Badge variant="outline">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Platform Integrations</h2>
        <p className="text-muted-foreground">
          Manage third-party integrations, API keys, and webhooks
        </p>
      </div>

      <Tabs defaultValue="integrations" className="w-full">
        <TabsList>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
          <TabsTrigger value="api-keys">API Keys</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
        </TabsList>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {integrations.map((integration) => {
              const IconComponent = integration.icon ? iconMap[integration.icon] || Database : Database;
              return (
                <Card key={integration.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <IconComponent className="h-5 w-5" />
                        <span>{integration.name}</span>
                      </div>
                      {getStatusBadge(integration.status)}
                    </CardTitle>
                    <CardDescription>{integration.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="text-sm text-muted-foreground">
                      <div>Type: {integration.integration_type}</div>
                      <div>Last Sync: {integration.last_sync ? new Date(integration.last_sync).toLocaleDateString() : 'Never'}</div>
                    </div>
                    
                    <div className="flex space-x-2">
                      {integration.status === 'connected' ? (
                        <>
                          <Button size="sm" onClick={() => handleSyncIntegration(integration.id)} disabled={loading}>
                            <RefreshCw className="w-3 h-3 mr-1" />
                            Sync
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => openConfigureDialog(integration)}>
                            <Edit className="w-3 h-3 mr-1" />
                            Configure
                          </Button>
                        </>
                      ) : (
                        <Button size="sm" onClick={() => handleConnectIntegration(integration.id)} disabled={loading}>
                          <Plus className="w-3 h-3 mr-1" />
                          Connect
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* API Keys Tab */}
        <TabsContent value="api-keys" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Key className="h-5 w-5" />
                  <span>API Keys Management</span>
                </div>
                <Button onClick={openAddApiKeyDialog}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add API Key
                </Button>
              </CardTitle>
              <CardDescription>Manage your platform's API keys and credentials</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Key</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Used</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {apiKeys.map((apiKey) => (
                    <TableRow key={apiKey.id}>
                      <TableCell className="font-medium">{apiKey.name}</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <code className="bg-muted px-2 py-1 rounded text-xs">
                            {showApiKey[apiKey.key_identifier] ? apiKey.encrypted_value : '••••••••••••••••'}
                          </code>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => toggleApiKeyVisibility(apiKey.key_identifier)}
                          >
                            {showApiKey[apiKey.key_identifier] ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                          </Button>
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(apiKey.status)}</TableCell>
                      <TableCell>{apiKey.last_used ? new Date(apiKey.last_used).toLocaleDateString() : 'Never'}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" onClick={() => openEditApiKeyDialog(apiKey)}>
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDeleteApiKey(apiKey.id)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Webhooks Tab */}
        <TabsContent value="webhooks" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Webhook className="h-5 w-5" />
                  <span>Webhook Management</span>
                </div>
                <Button onClick={openAddWebhookDialog}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Webhook
                </Button>
              </CardTitle>
              <CardDescription>Configure webhooks for real-time event notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>URL</TableHead>
                    <TableHead>Events</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {webhooks.map((webhook) => (
                    <TableRow key={webhook.id}>
                      <TableCell className="font-medium">{webhook.name}</TableCell>
                      <TableCell>
                        <code className="bg-muted px-2 py-1 rounded text-xs">
                          {webhook.url}
                        </code>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {webhook.events.map((event) => (
                            <Badge key={event} variant="outline" className="text-xs">
                              {event}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                      <TableCell>{getStatusBadge(webhook.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline" onClick={() => toast({ title: "Edit", description: "Edit functionality coming soon" })}>
                            <Edit className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="destructive" onClick={() => handleDeleteWebhook(webhook.id)}>
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Configure Integration Dialog */}
      <Dialog open={isIntegrationDialogOpen} onOpenChange={setIsIntegrationDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Configure {integrationForm.name || 'Integration'}</DialogTitle>
            <DialogDescription>Update settings for this integration.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="integration-description">Description</Label>
              <Input
                id="integration-description"
                placeholder="Optional description"
                value={integrationForm.description}
                onChange={(e) => setIntegrationForm((prev) => ({ ...prev, description: e.target.value }))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="integration-icon">Icon (lucide name)</Label>
              <Input
                id="integration-icon"
                placeholder="e.g., Database, Mail, CreditCard"
                value={integrationForm.icon}
                onChange={(e) => setIntegrationForm((prev) => ({ ...prev, icon: e.target.value }))}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="integration-config">Config JSON</Label>
              <Textarea
                id="integration-config"
                className="font-mono text-xs min-h-[200px]"
                placeholder='{"api_key": "..."}'
                value={integrationConfigText}
                onChange={(e) => setIntegrationConfigText(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsIntegrationDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveIntegrationConfig} disabled={loading}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add API Key Dialog */}
      <Dialog open={isApiKeyDialogOpen} onOpenChange={setIsApiKeyDialogOpen}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">{editingItem ? 'Edit API Key' : 'Add API Key'}</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              {editingItem ? 'Update the API key details.' : 'Create a new API key for integration access.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="apikey-name" className="text-foreground">Name *</Label>
              <Input
                id="apikey-name"
                className="bg-background text-foreground"
                placeholder="e.g., Production API Key"
                value={apiKeyForm.name}
                onChange={(e) => {
                  console.log('Name input changed:', e.target.value);
                  setApiKeyForm((prev) => ({ ...prev, name: e.target.value }));
                }}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apikey-identifier" className="text-foreground">Key Identifier *</Label>
              <Input
                id="apikey-identifier"
                className="bg-background text-foreground"
                placeholder="e.g., pk_live_..."
                value={apiKeyForm.key_identifier}
                onChange={(e) => setApiKeyForm((prev) => ({ ...prev, key_identifier: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apikey-value" className="text-foreground">Secret Value *</Label>
              <Input
                id="apikey-value"
                type="password"
                className="bg-background text-foreground"
                placeholder="Enter secret key"
                value={apiKeyForm.encrypted_value}
                onChange={(e) => setApiKeyForm((prev) => ({ ...prev, encrypted_value: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="apikey-integration" className="text-foreground">Integration (Optional)</Label>
              <Select
                value={apiKeyForm.integration_id || "__none"}
                onValueChange={(value) => setApiKeyForm((prev) => ({ ...prev, integration_id: value === "__none" ? "" : value }))}
              >
                <SelectTrigger id="apikey-integration" className="bg-background text-foreground">
                  <SelectValue placeholder="Select integration" />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground">
                  <SelectItem value="__none">None</SelectItem>
                  {integrations.map((int) => (
                    <SelectItem key={int.id} value={int.id}>
                      {int.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsApiKeyDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveApiKey} disabled={loading}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Webhook Dialog */}
      <Dialog open={isWebhookDialogOpen} onOpenChange={setIsWebhookDialogOpen}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Add Webhook</DialogTitle>
            <DialogDescription className="text-muted-foreground">Configure a new webhook endpoint for event notifications.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="webhook-name" className="text-foreground">Name *</Label>
              <Input
                id="webhook-name"
                className="bg-background text-foreground"
                placeholder="e.g., Order Notifications"
                value={webhookForm.name}
                onChange={(e) => setWebhookForm((prev) => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="webhook-url" className="text-foreground">Webhook URL *</Label>
              <Input
                id="webhook-url"
                type="url"
                className="bg-background text-foreground"
                placeholder="https://example.com/webhook"
                value={webhookForm.url}
                onChange={(e) => setWebhookForm((prev) => ({ ...prev, url: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="webhook-events" className="text-foreground">Events (comma-separated) *</Label>
              <Input
                id="webhook-events"
                className="bg-background text-foreground"
                placeholder="order.created, order.updated, order.completed"
                value={webhookForm.events}
                onChange={(e) => setWebhookForm((prev) => ({ ...prev, events: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="webhook-secret" className="text-foreground">Secret (Optional)</Label>
              <Input
                id="webhook-secret"
                type="password"
                className="bg-background text-foreground"
                placeholder="Webhook signing secret"
                value={webhookForm.secret}
                onChange={(e) => setWebhookForm((prev) => ({ ...prev, secret: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="webhook-status" className="text-foreground">Status</Label>
              <Select
                value={webhookForm.status}
                onValueChange={(value) => setWebhookForm((prev) => ({ ...prev, status: value }))}
              >
                <SelectTrigger id="webhook-status" className="bg-background text-foreground">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-popover text-popover-foreground">
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsWebhookDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveWebhook} disabled={loading}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
