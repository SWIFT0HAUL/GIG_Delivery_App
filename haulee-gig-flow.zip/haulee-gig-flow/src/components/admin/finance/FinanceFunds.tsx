import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Wallet, CreditCard, ArrowUpRight, ArrowDownLeft, RefreshCw, Plus, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

const accountBalances = [
  {
    id: "ACC-PRIMARY",
    name: "Primary Operating Account",
    bank: "Chase Business",
    balance: 245750.00,
    currency: "USD",
    type: "Checking",
    lastUpdated: new Date("2024-03-15T14:30:00"),
    accountNumber: "**** 4567"
  },
  {
    id: "ACC-ESCROW",
    name: "Driver Payout Escrow", 
    bank: "Wells Fargo Business",
    balance: 89250.00,
    currency: "USD",
    type: "Savings",
    lastUpdated: new Date("2024-03-15T14:25:00"),
    accountNumber: "**** 8901"
  },
  {
    id: "ACC-RESERVE",
    name: "Reserve Fund",
    bank: "Bank of America Business",
    balance: 150000.00,
    currency: "USD", 
    type: "Money Market",
    lastUpdated: new Date("2024-03-15T14:20:00"),
    accountNumber: "**** 2345"
  }
];

const transactions = [
  {
    id: "TXN-TOP-001",
    type: "Top-up",
    amount: 50000.00,
    account: "Primary Operating Account",
    source: "Bank Transfer - Chase ****1234",
    status: "Completed",
    date: new Date("2024-03-15T10:30:00"),
    reference: "TOP-001234"
  },
  {
    id: "TXN-WTH-001", 
    type: "Withdrawal",
    amount: -25000.00,
    account: "Primary Operating Account",
    destination: "Payroll Account - Chase ****5678",
    status: "Completed",
    date: new Date("2024-03-14T16:45:00"),
    reference: "WTH-001234"
  },
  {
    id: "TXN-REF-001",
    type: "Refund",
    amount: -1250.00,
    account: "Primary Operating Account",
    destination: "Customer Refund - ABC Corp",
    status: "Processing",
    date: new Date("2024-03-14T14:20:00"),
    reference: "REF-001234"
  },
  {
    id: "TXN-ADJ-001",
    type: "Adjustment",
    amount: 750.00,
    account: "Driver Payout Escrow",
    reason: "Failed payout reversal",
    status: "Completed",
    date: new Date("2024-03-13T11:15:00"),
    reference: "ADJ-001234"
  }
];

const settlementLogs = [
  {
    id: "SET-LOG-001",
    type: "Driver Batch Settlement",
    totalAmount: 25400.00,
    recipientCount: 15,
    status: "Settled",
    initiatedDate: new Date("2024-03-15T09:00:00"),
    settledDate: new Date("2024-03-15T11:30:00"),
    batchId: "BATCH-20240315-001"
  },
  {
    id: "SET-LOG-002",
    type: "Vendor Settlement",
    totalAmount: 45200.00,
    recipientCount: 3,
    status: "Settling",
    initiatedDate: new Date("2024-03-15T14:00:00"),
    batchId: "BATCH-20240315-002"
  }
];

export const FinanceFunds = () => {
  const [topupDialogOpen, setTopupDialogOpen] = useState(false);
  const [withdrawalDialogOpen, setWithdrawalDialogOpen] = useState(false);
  const [refundDialogOpen, setRefundDialogOpen] = useState(false);
  
  const [topupForm, setTopupForm] = useState({
    account: '',
    amount: '',
    source: '',
    description: ''
  });

  const [withdrawalForm, setWithdrawalForm] = useState({
    account: '',
    amount: '',
    destination: '',
    description: ''
  });

  const [refundForm, setRefundForm] = useState({
    account: '',
    amount: '',
    recipient: '',
    reason: '',
    reference: ''
  });

  const totalBalance = accountBalances.reduce((sum, account) => sum + account.balance, 0);

  const handleTopup = () => {
    console.log('Processing top-up:', topupForm);
    setTopupDialogOpen(false);
    setTopupForm({ account: '', amount: '', source: '', description: '' });
  };

  const handleWithdrawal = () => {
    console.log('Processing withdrawal:', withdrawalForm);
    setWithdrawalDialogOpen(false);
    setWithdrawalForm({ account: '', amount: '', destination: '', description: '' });
  };

  const handleRefund = () => {
    console.log('Processing refund:', refundForm);
    setRefundDialogOpen(false);
    setRefundForm({ account: '', amount: '', recipient: '', reason: '', reference: '' });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Funds & Settlements</h2>
          <p className="text-muted-foreground">Manage account balances, transfers, and settlement processing</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={topupDialogOpen} onOpenChange={setTopupDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <ArrowDownLeft className="h-4 w-4 mr-2" />
                Top-up
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Account Top-up</DialogTitle>
                <DialogDescription>Add funds to an account</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="topup-account">Target Account</Label>
                  <Select value={topupForm.account} onValueChange={(value) => setTopupForm({...topupForm, account: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select account" />
                    </SelectTrigger>
                    <SelectContent>
                      {accountBalances.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} ({account.accountNumber})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="topup-amount">Amount</Label>
                  <Input
                    id="topup-amount"
                    type="number"
                    step="0.01"
                    value={topupForm.amount}
                    onChange={(e) => setTopupForm({...topupForm, amount: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="topup-source">Source</Label>
                  <Input
                    id="topup-source"
                    value={topupForm.source}
                    onChange={(e) => setTopupForm({...topupForm, source: e.target.value})}
                    placeholder="Funding source description"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="topup-description">Description</Label>
                  <Textarea
                    id="topup-description"
                    value={topupForm.description}
                    onChange={(e) => setTopupForm({...topupForm, description: e.target.value})}
                    placeholder="Optional description"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setTopupDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleTopup}>
                    Process Top-up
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={withdrawalDialogOpen} onOpenChange={setWithdrawalDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <ArrowUpRight className="h-4 w-4 mr-2" />
                Withdraw
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Account Withdrawal</DialogTitle>
                <DialogDescription>Withdraw funds from an account</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="withdrawal-account">Source Account</Label>
                  <Select value={withdrawalForm.account} onValueChange={(value) => setWithdrawalForm({...withdrawalForm, account: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select account" />
                    </SelectTrigger>
                    <SelectContent>
                      {accountBalances.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} - ${account.balance.toLocaleString()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="withdrawal-amount">Amount</Label>
                  <Input
                    id="withdrawal-amount"
                    type="number"
                    step="0.01"
                    value={withdrawalForm.amount}
                    onChange={(e) => setWithdrawalForm({...withdrawalForm, amount: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="withdrawal-destination">Destination</Label>
                  <Input
                    id="withdrawal-destination"
                    value={withdrawalForm.destination}
                    onChange={(e) => setWithdrawalForm({...withdrawalForm, destination: e.target.value})}
                    placeholder="Destination account or recipient"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="withdrawal-description">Description</Label>
                  <Textarea
                    id="withdrawal-description"
                    value={withdrawalForm.description}
                    onChange={(e) => setWithdrawalForm({...withdrawalForm, description: e.target.value})}
                    placeholder="Optional description"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setWithdrawalDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleWithdrawal}>
                    Process Withdrawal
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>

          <Dialog open={refundDialogOpen} onOpenChange={setRefundDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <RefreshCw className="h-4 w-4 mr-2" />
                Refund
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Process Refund</DialogTitle>
                <DialogDescription>Issue a refund to a customer or partner</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="refund-account">Source Account</Label>
                  <Select value={refundForm.account} onValueChange={(value) => setRefundForm({...refundForm, account: value})}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select account" />
                    </SelectTrigger>
                    <SelectContent>
                      {accountBalances.map((account) => (
                        <SelectItem key={account.id} value={account.id}>
                          {account.name} - ${account.balance.toLocaleString()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="refund-amount">Refund Amount</Label>
                  <Input
                    id="refund-amount"
                    type="number"
                    step="0.01"
                    value={refundForm.amount}
                    onChange={(e) => setRefundForm({...refundForm, amount: e.target.value})}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="refund-recipient">Recipient</Label>
                  <Input
                    id="refund-recipient"
                    value={refundForm.recipient}
                    onChange={(e) => setRefundForm({...refundForm, recipient: e.target.value})}
                    placeholder="Customer or partner name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="refund-reference">Reference</Label>
                  <Input
                    id="refund-reference"
                    value={refundForm.reference}
                    onChange={(e) => setRefundForm({...refundForm, reference: e.target.value})}
                    placeholder="Original transaction ID or invoice number"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="refund-reason">Reason</Label>
                  <Textarea
                    id="refund-reason"
                    value={refundForm.reason}
                    onChange={(e) => setRefundForm({...refundForm, reason: e.target.value})}
                    placeholder="Reason for refund"
                  />
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setRefundDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleRefund}>
                    Process Refund
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Account Balance Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="md:col-span-1">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
            <Wallet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalBalance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Across all accounts</p>
          </CardContent>
        </Card>
        
        {accountBalances.slice(0, 3).map((account) => (
          <Card key={account.id}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{account.name}</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${account.balance.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">
                {account.bank} • {account.accountNumber}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs defaultValue="balances" className="space-y-4">
        <TabsList>
          <TabsTrigger value="balances">Account Balances</TabsTrigger>
          <TabsTrigger value="transactions">Transactions</TabsTrigger>
          <TabsTrigger value="settlements">Settlement Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="balances">
          <Card>
            <CardHeader>
              <CardTitle>Account Details</CardTitle>
              <CardDescription>Detailed view of all connected accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account Name</TableHead>
                      <TableHead>Bank</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Balance</TableHead>
                      <TableHead>Last Updated</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {accountBalances.map((account) => (
                      <TableRow key={account.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{account.name}</div>
                            <div className="text-sm text-muted-foreground font-mono">{account.accountNumber}</div>
                          </div>
                        </TableCell>
                        <TableCell>{account.bank}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{account.type}</Badge>
                        </TableCell>
                        <TableCell className="font-semibold">${account.balance.toLocaleString()}</TableCell>
                        <TableCell>{format(account.lastUpdated, 'MMM dd, HH:mm')}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <RefreshCw className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transactions">
          <Card>
            <CardHeader>
              <CardTitle>Fund Transactions</CardTitle>
              <CardDescription>Top-ups, withdrawals, refunds, and adjustments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Account</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Details</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Reference</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <Badge variant={
                            transaction.type === 'Top-up' ? 'default' :
                            transaction.type === 'Withdrawal' ? 'secondary' :
                            transaction.type === 'Refund' ? 'outline' : 'destructive'
                          }>
                            {transaction.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-[150px] truncate">{transaction.account}</TableCell>
                        <TableCell className={`font-semibold ${
                          transaction.amount > 0 ? 'text-green-600' : 'text-red-600'
                        }`}>
                          ${Math.abs(transaction.amount).toLocaleString()}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">
                          {transaction.source || transaction.destination || transaction.reason}
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            transaction.status === 'Completed' ? 'default' :
                            transaction.status === 'Processing' ? 'secondary' : 'destructive'
                          }>
                            {transaction.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{format(transaction.date, 'MMM dd, HH:mm')}</TableCell>
                        <TableCell className="font-mono text-sm">{transaction.reference}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settlements">
          <Card>
            <CardHeader>
              <CardTitle>Settlement Processing Logs</CardTitle>
              <CardDescription>Track batch settlement processing status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {settlementLogs.map((log) => (
                  <Card key={log.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="font-semibold">{log.type}</h4>
                          <p className="text-sm text-muted-foreground">
                            {log.recipientCount} recipients • ${log.totalAmount.toLocaleString()}
                          </p>
                          <p className="text-sm text-muted-foreground font-mono">{log.batchId}</p>
                        </div>
                        <Badge variant={
                          log.status === 'Settled' ? 'default' :
                          log.status === 'Settling' ? 'secondary' : 'outline'
                        }>
                          {log.status}
                        </Badge>
                      </div>
                      
                      <div className="flex justify-between items-center text-sm text-muted-foreground">
                        <span>Initiated: {format(log.initiatedDate, 'MMM dd, yyyy HH:mm')}</span>
                        {log.settledDate && (
                          <span>Settled: {format(log.settledDate, 'MMM dd, yyyy HH:mm')}</span>
                        )}
                        {log.status === 'Settling' && (
                          <div className="flex items-center gap-2">
                            <AlertTriangle className="h-4 w-4 text-amber-500" />
                            <span>Processing...</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};