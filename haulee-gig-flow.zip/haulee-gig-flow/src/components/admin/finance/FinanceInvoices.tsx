import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Search, Eye, Edit, Send, Copy, Calendar, DollarSign } from 'lucide-react';
import { format } from 'date-fns';

const invoices = [
  {
    id: "INV-2024-001",
    client: "ABC Logistics Corp",
    amount: 15750.00,
    status: "Paid",
    dueDate: new Date("2024-03-01"),
    paidDate: new Date("2024-02-28"),
    description: "Monthly logistics services",
    items: [
      { description: "Delivery Services", quantity: 45, rate: 250.00 },
      { description: "Fuel Surcharge", quantity: 1, rate: 2500.00 }
    ]
  },
  {
    id: "INV-2024-002",
    client: "XYZ Transport Ltd",
    amount: 8900.00,
    status: "Pending",
    dueDate: new Date("2024-03-20"),
    description: "Freight management services",
    items: [
      { description: "Route Planning", quantity: 20, rate: 175.00 },
      { description: "Load Coordination", quantity: 25, rate: 200.00 }
    ]
  },
  {
    id: "INV-2024-003",
    client: "QuickMove Solutions",
    amount: 22450.00,
    status: "Overdue",
    dueDate: new Date("2024-02-15"),
    description: "Express delivery services",
    items: [
      { description: "Express Deliveries", quantity: 89, rate: 180.00 },
      { description: "Priority Handling", quantity: 1, rate: 6230.00 }
    ]
  }
];

const templates = [
  {
    id: "TPL-001",
    name: "Standard Service Invoice",
    description: "Default template for service invoices",
    fields: ["Service Description", "Hours/Quantity", "Rate", "Total"]
  },
  {
    id: "TPL-002", 
    name: "Freight Invoice",
    description: "Template for freight and logistics services",
    fields: ["Load Details", "Distance", "Rate per Mile", "Fuel Surcharge"]
  },
  {
    id: "TPL-003",
    name: "Monthly Recurring",
    description: "Template for monthly recurring services",
    fields: ["Service Period", "Base Fee", "Additional Services", "Total"]
  }
];

const recurringBilling = [
  {
    id: "REC-001",
    client: "ABC Logistics Corp",
    template: "Monthly Recurring",
    amount: 15750.00,
    frequency: "Monthly",
    nextBill: new Date("2024-04-01"),
    status: "Active"
  },
  {
    id: "REC-002",
    client: "FastTrack Shipping",
    template: "Standard Service Invoice", 
    amount: 8500.00,
    frequency: "Bi-weekly",
    nextBill: new Date("2024-03-25"),
    status: "Active"
  }
];

export const FinanceInvoices = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState<any>(null);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [newInvoice, setNewInvoice] = useState({
    client: '',
    amount: '',
    description: '',
    dueDate: '',
    items: [{ description: '', quantity: 1, rate: 0 }]
  });

  const filteredInvoices = invoices.filter(invoice =>
    invoice.client.toLowerCase().includes(searchTerm.toLowerCase()) ||
    invoice.id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const addInvoiceItem = () => {
    setNewInvoice({
      ...newInvoice,
      items: [...newInvoice.items, { description: '', quantity: 1, rate: 0 }]
    });
  };

  const updateInvoiceItem = (index: number, field: string, value: any) => {
    const updatedItems = newInvoice.items.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    );
    setNewInvoice({ ...newInvoice, items: updatedItems });
  };

  const calculateTotal = () => {
    return newInvoice.items.reduce((total, item) => total + (item.quantity * item.rate), 0);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Invoice & Billing Management</h2>
          <p className="text-muted-foreground">Create, manage, and track invoices and recurring billing</p>
        </div>
        <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Invoice
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Invoice</DialogTitle>
              <DialogDescription>Create a new invoice for your client</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="client">Client</Label>
                  <Input
                    id="client"
                    value={newInvoice.client}
                    onChange={(e) => setNewInvoice({ ...newInvoice, client: e.target.value })}
                    placeholder="Client name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dueDate">Due Date</Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={newInvoice.dueDate}
                    onChange={(e) => setNewInvoice({ ...newInvoice, dueDate: e.target.value })}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={newInvoice.description}
                  onChange={(e) => setNewInvoice({ ...newInvoice, description: e.target.value })}
                  placeholder="Invoice description"
                />
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <Label>Invoice Items</Label>
                  <Button type="button" variant="outline" size="sm" onClick={addInvoiceItem}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>
                </div>
                
                {newInvoice.items.map((item, index) => (
                  <div key={index} className="grid grid-cols-6 gap-2 items-end">
                    <div className="col-span-3">
                      <Label>Description</Label>
                      <Input
                        value={item.description}
                        onChange={(e) => updateInvoiceItem(index, 'description', e.target.value)}
                        placeholder="Item description"
                      />
                    </div>
                    <div>
                      <Label>Quantity</Label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateInvoiceItem(index, 'quantity', parseInt(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <Label>Rate ($)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        value={item.rate}
                        onChange={(e) => updateInvoiceItem(index, 'rate', parseFloat(e.target.value) || 0)}
                      />
                    </div>
                    <div>
                      <Label>Total</Label>
                      <div className="font-semibold p-2 bg-muted rounded">
                        ${(item.quantity * item.rate).toFixed(2)}
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="text-right">
                  <div className="text-lg font-bold">
                    Total: ${calculateTotal().toFixed(2)}
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={() => setCreateDialogOpen(false)}>
                  Create Invoice
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs defaultValue="invoices" className="space-y-4">
        <TabsList>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="recurring">Recurring Billing</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="invoices">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Invoice List</CardTitle>
                  <CardDescription>Manage and track all invoices</CardDescription>
                </div>
                <div className="flex gap-2">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search invoices..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 w-64"
                    />
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Invoice ID</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Due Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredInvoices.map((invoice) => (
                      <TableRow key={invoice.id}>
                        <TableCell className="font-mono">{invoice.id}</TableCell>
                        <TableCell className="font-medium">{invoice.client}</TableCell>
                        <TableCell className="font-semibold">${invoice.amount.toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge variant={
                            invoice.status === 'Paid' ? 'default' :
                            invoice.status === 'Pending' ? 'secondary' : 'destructive'
                          }>
                            {invoice.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {format(invoice.dueDate, 'MMM dd, yyyy')}
                          {invoice.status === 'Overdue' && (
                            <div className="text-xs text-destructive mt-1">
                              {Math.ceil((new Date().getTime() - invoice.dueDate.getTime()) / (1000 * 3600 * 24))} days overdue
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Send className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recurring">
          <Card>
            <CardHeader>
              <CardTitle>Recurring Billing</CardTitle>
              <CardDescription>Automated recurring invoice generation</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>ID</TableHead>
                      <TableHead>Client</TableHead>
                      <TableHead>Template</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Frequency</TableHead>
                      <TableHead>Next Bill</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recurringBilling.map((billing) => (
                      <TableRow key={billing.id}>
                        <TableCell className="font-mono">{billing.id}</TableCell>
                        <TableCell className="font-medium">{billing.client}</TableCell>
                        <TableCell>{billing.template}</TableCell>
                        <TableCell className="font-semibold">${billing.amount.toLocaleString()}</TableCell>
                        <TableCell>{billing.frequency}</TableCell>
                        <TableCell>{format(billing.nextBill, 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <Badge variant={billing.status === 'Active' ? 'default' : 'secondary'}>
                            {billing.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Calendar className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {template.name}
                    <Button variant="outline" size="sm">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Label>Template Fields:</Label>
                    <div className="space-y-1">
                      {template.fields.map((field, index) => (
                        <div key={index} className="text-sm bg-muted p-2 rounded">
                          {field}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm" className="flex-1">
                      Use Template
                    </Button>
                    <Button variant="outline" size="sm">
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
            
            <Card className="border-dashed border-2 hover:border-primary transition-colors">
              <CardContent className="flex flex-col items-center justify-center h-full min-h-[200px]">
                <Plus className="h-8 w-8 text-muted-foreground mb-2" />
                <Button variant="ghost">Create New Template</Button>
                <p className="text-sm text-muted-foreground mt-2 text-center">
                  Create custom invoice templates for different services
                </p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};