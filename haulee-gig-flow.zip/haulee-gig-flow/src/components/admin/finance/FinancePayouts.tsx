import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Users, Truck, CreditCard, Clock, DollarSign, Download, Send, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';

const driverPayouts = [
  {
    id: "PAY-D-001",
    driver: "John Smith",
    driverId: "DRV-1234",
    amount: 2450.00,
    completedJobs: 12,
    status: "Pending",
    requestDate: new Date("2024-03-15"),
    method: "Bank Transfer",
    accountEnding: "4567"
  },
  {
    id: "PAY-D-002", 
    driver: "Sarah Johnson",
    driverId: "DRV-1235",
    amount: 1850.00,
    completedJobs: 9,
    status: "Processed",
    requestDate: new Date("2024-03-14"),
    processedDate: new Date("2024-03-15"),
    method: "Bank Transfer",
    accountEnding: "7890"
  },
  {
    id: "PAY-D-003",
    driver: "Mike Rodriguez",
    driverId: "DRV-1236", 
    amount: 3200.00,
    completedJobs: 15,
    status: "Failed",
    requestDate: new Date("2024-03-13"),
    method: "Bank Transfer",
    accountEnding: "2345",
    failureReason: "Invalid account details"
  }
];

const vendorSettlements = [
  {
    id: "SET-V-001",
    vendor: "ABC Logistics Corp",
    vendorId: "VEN-5001",
    amount: 15750.00,
    invoiceCount: 5,
    status: "Approved",
    requestDate: new Date("2024-03-10"),
    settlementDate: new Date("2024-03-17"),
    method: "ACH Transfer",
    accountEnding: "9876"
  },
  {
    id: "SET-V-002",
    vendor: "XYZ Transport Ltd", 
    vendorId: "VEN-5002",
    amount: 22300.00,
    invoiceCount: 8,
    status: "Under Review",
    requestDate: new Date("2024-03-12"),
    method: "Wire Transfer",
    accountEnding: "5432"
  }
];

const carrierSettlements = [
  {
    id: "SET-C-001",
    carrier: "FastMove Transport",
    carrierId: "CAR-8001",
    amount: 45200.00,
    loadCount: 23,
    status: "Scheduled",
    requestDate: new Date("2024-03-08"),
    scheduledDate: new Date("2024-03-20"),
    method: "ACH Transfer",
    accountEnding: "1111"
  }
];

const batchPayouts = [
  {
    id: "BATCH-001",
    name: "Weekly Driver Payouts - Week 11",
    totalAmount: 45200.00,
    recipientCount: 28,
    status: "Processing",
    createdDate: new Date("2024-03-15"),
    progress: 65
  },
  {
    id: "BATCH-002", 
    name: "Monthly Vendor Settlements - March",
    totalAmount: 125000.00,
    recipientCount: 12,
    status: "Completed",
    createdDate: new Date("2024-03-01"),
    completedDate: new Date("2024-03-02"),
    progress: 100
  }
];

export const FinancePayouts = () => {
  const [selectedPayouts, setSelectedPayouts] = useState<string[]>([]);
  const [batchDialogOpen, setBatchDialogOpen] = useState(false);

  const handleSelectPayout = (payoutId: string) => {
    setSelectedPayouts(prev => 
      prev.includes(payoutId) 
        ? prev.filter(id => id !== payoutId)
        : [...prev, payoutId]
    );
  };

  const handleSelectAll = (payouts: any[]) => {
    const pendingIds = payouts.filter(p => p.status === 'Pending').map(p => p.id);
    setSelectedPayouts(prev => 
      pendingIds.every(id => prev.includes(id))
        ? prev.filter(id => !pendingIds.includes(id))
        : [...new Set([...prev, ...pendingIds])]
    );
  };

  const processBatchPayout = () => {
    console.log('Processing batch payout for:', selectedPayouts);
    setBatchDialogOpen(false);
    setSelectedPayouts([]);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Payout Management</h2>
          <p className="text-muted-foreground">Manage driver payouts, vendor settlements, and batch processing</p>
        </div>
        <div className="flex gap-2">
          {selectedPayouts.length > 0 && (
            <Dialog open={batchDialogOpen} onOpenChange={setBatchDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <Send className="h-4 w-4 mr-2" />
                  Process Selected ({selectedPayouts.length})
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Process Batch Payout</DialogTitle>
                  <DialogDescription>
                    You are about to process {selectedPayouts.length} payout(s). This action cannot be undone.
                  </DialogDescription>
                </DialogHeader>
                <Alert>
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>
                    Please ensure all payout details are correct before processing. Failed payments may result in delays and additional fees.
                  </AlertDescription>
                </Alert>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setBatchDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={processBatchPayout}>
                    Process Payouts
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
          
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Driver Payouts</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$8,950</div>
            <p className="text-xs text-muted-foreground">15 drivers waiting</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Vendor Settlements</CardTitle>
            <Truck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$38,050</div>
            <p className="text-xs text-muted-foreground">3 vendors pending</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Processed Today</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$125,000</div>
            <p className="text-xs text-muted-foreground">45 transactions</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Processing Time</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2.5h</div>
            <p className="text-xs text-muted-foreground">Average processing</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="drivers" className="space-y-4">
        <TabsList>
          <TabsTrigger value="drivers">Driver Payouts</TabsTrigger>
          <TabsTrigger value="vendors">Vendor Settlements</TabsTrigger>
          <TabsTrigger value="carriers">Carrier Settlements</TabsTrigger>
          <TabsTrigger value="batch">Batch Processing</TabsTrigger>
          <TabsTrigger value="history">Payout History</TabsTrigger>
        </TabsList>

        <TabsContent value="drivers">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Driver Payouts</CardTitle>
                  <CardDescription>Individual driver payment requests</CardDescription>
                </div>
                <Button 
                  variant="outline" 
                  onClick={() => handleSelectAll(driverPayouts)}
                >
                  {driverPayouts.filter(p => p.status === 'Pending').every(p => selectedPayouts.includes(p.id)) 
                    ? 'Deselect All' : 'Select All Pending'}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-12">
                        <Checkbox 
                          checked={driverPayouts.filter(p => p.status === 'Pending').every(p => selectedPayouts.includes(p.id))}
                          onCheckedChange={() => handleSelectAll(driverPayouts)}
                        />
                      </TableHead>
                      <TableHead>Driver</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Jobs</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Request Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {driverPayouts.map((payout) => (
                      <TableRow key={payout.id}>
                        <TableCell>
                          <Checkbox 
                            checked={selectedPayouts.includes(payout.id)}
                            onCheckedChange={() => handleSelectPayout(payout.id)}
                            disabled={payout.status !== 'Pending'}
                          />
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{payout.driver}</div>
                            <div className="text-sm text-muted-foreground font-mono">{payout.driverId}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-semibold">${payout.amount.toLocaleString()}</TableCell>
                        <TableCell>{payout.completedJobs} completed</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {payout.method}
                            <div className="text-muted-foreground">****{payout.accountEnding}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            payout.status === 'Processed' ? 'default' :
                            payout.status === 'Pending' ? 'secondary' : 'destructive'
                          }>
                            {payout.status}
                          </Badge>
                          {payout.status === 'Failed' && (
                            <div className="text-xs text-destructive mt-1">{payout.failureReason}</div>
                          )}
                        </TableCell>
                        <TableCell>{format(payout.requestDate, 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              View
                            </Button>
                            {payout.status === 'Pending' && (
                              <Button size="sm">
                                Process
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="vendors">
          <Card>
            <CardHeader>
              <CardTitle>Vendor Settlements</CardTitle>
              <CardDescription>Vendor payment settlements and approvals</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Vendor</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Invoices</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Request Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {vendorSettlements.map((settlement) => (
                      <TableRow key={settlement.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{settlement.vendor}</div>
                            <div className="text-sm text-muted-foreground font-mono">{settlement.vendorId}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-semibold">${settlement.amount.toLocaleString()}</TableCell>
                        <TableCell>{settlement.invoiceCount} invoices</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {settlement.method}
                            <div className="text-muted-foreground">****{settlement.accountEnding}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={
                            settlement.status === 'Approved' ? 'default' :
                            settlement.status === 'Under Review' ? 'secondary' : 'destructive'
                          }>
                            {settlement.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{format(settlement.requestDate, 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              Review
                            </Button>
                            {settlement.status === 'Approved' && (
                              <Button size="sm">
                                Process
                              </Button>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="carriers">
          <Card>
            <CardHeader>
              <CardTitle>Carrier Settlements</CardTitle>
              <CardDescription>Large carrier payment settlements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Carrier</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Loads</TableHead>
                      <TableHead>Method</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Scheduled Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {carrierSettlements.map((settlement) => (
                      <TableRow key={settlement.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{settlement.carrier}</div>
                            <div className="text-sm text-muted-foreground font-mono">{settlement.carrierId}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-semibold">${settlement.amount.toLocaleString()}</TableCell>
                        <TableCell>{settlement.loadCount} loads</TableCell>
                        <TableCell>
                          <div className="text-sm">
                            {settlement.method}
                            <div className="text-muted-foreground">****{settlement.accountEnding}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{settlement.status}</Badge>
                        </TableCell>
                        <TableCell>{format(settlement.scheduledDate, 'MMM dd, yyyy')}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              Review
                            </Button>
                            <Button size="sm">
                              Process Now
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="batch">
          <Card>
            <CardHeader>
              <CardTitle>Batch Processing</CardTitle>
              <CardDescription>Automated batch payout processing status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {batchPayouts.map((batch) => (
                  <Card key={batch.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h4 className="font-semibold">{batch.name}</h4>
                          <p className="text-sm text-muted-foreground">
                            {batch.recipientCount} recipients • ${batch.totalAmount.toLocaleString()}
                          </p>
                        </div>
                        <Badge variant={
                          batch.status === 'Completed' ? 'default' :
                          batch.status === 'Processing' ? 'secondary' : 'outline'
                        }>
                          {batch.status}
                        </Badge>
                      </div>
                      
                      {batch.status === 'Processing' && (
                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress</span>
                            <span>{batch.progress}%</span>
                          </div>
                          <Progress value={batch.progress} className="h-2" />
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center text-sm text-muted-foreground">
                        <span>Created: {format(batch.createdDate, 'MMM dd, yyyy HH:mm')}</span>
                        {batch.completedDate && (
                          <span>Completed: {format(batch.completedDate, 'MMM dd, yyyy HH:mm')}</span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Payout History</CardTitle>
              <CardDescription>Complete history of all processed payouts</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">Payout History</h3>
                <p className="text-muted-foreground">
                  Historical payout records will be displayed here
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};