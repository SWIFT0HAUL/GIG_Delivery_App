import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Settings, 
  CreditCard, 
  DollarSign, 
  Globe, 
  Shield, 
  Link,
  Plus,
  Edit,
  Trash2,
  Check,
  X
} from 'lucide-react';

export const FinanceSettings = () => {
  const [newGatewayName, setNewGatewayName] = useState('');
  const [platformFeeRate, setPlatformFeeRate] = useState('5.5');
  const [minPayoutAmount, setMinPayoutAmount] = useState('25.00');

  // Mock data for payment gateways
  const paymentGateways = [
    { id: 1, name: 'Stripe', status: 'Active', type: 'Credit Card', fees: '2.9% + $0.30' },
    { id: 2, name: 'PayPal', status: 'Active', type: 'Digital Wallet', fees: '3.5% + $0.15' },
    { id: 3, name: 'Square', status: 'Inactive', type: 'Credit Card', fees: '2.6% + $0.10' },
  ];

  // Mock data for payout rules
  const payoutRules = [
    { role: 'Driver', frequency: 'Daily', minAmount: '$25.00', processingFee: '$1.00' },
    { role: 'Vendor/Merchant', frequency: 'Weekly', minAmount: '$50.00', processingFee: '$2.50' },
    { role: 'Carrier', frequency: 'Weekly', minAmount: '$100.00', processingFee: '$5.00' },
    { role: 'Broker', frequency: 'Monthly', minAmount: '$200.00', processingFee: '$10.00' },
  ];

  // Mock data for integrations
  const integrations = [
    { name: 'QuickBooks', status: 'Connected', type: 'Accounting', lastSync: '2024-01-15 14:30' },
    { name: 'Xero', status: 'Available', type: 'Accounting', lastSync: null },
    { name: 'Plaid', status: 'Connected', type: 'Banking', lastSync: '2024-01-15 16:45' },
    { name: 'TaxJar', status: 'Available', type: 'Tax', lastSync: null },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Finance Settings</h2>
        <p className="text-muted-foreground">Configure payment gateways, payout rules, and financial permissions</p>
      </div>

      <Tabs defaultValue="gateways" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="gateways">Payment Gateways</TabsTrigger>
          <TabsTrigger value="payouts">Payout Rules</TabsTrigger>
          <TabsTrigger value="currency">Currency & Tax</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
          <TabsTrigger value="integrations">Integrations</TabsTrigger>
        </TabsList>

        <TabsContent value="gateways" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <CreditCard className="h-5 w-5" />
                    Payment Gateways
                  </CardTitle>
                  <CardDescription>Configure payment processing providers</CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="h-4 w-4 mr-2" />
                      Add Gateway
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Add Payment Gateway</DialogTitle>
                      <DialogDescription>Configure a new payment processing provider</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="gateway-provider">Provider</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select provider..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="stripe">Stripe</SelectItem>
                            <SelectItem value="paypal">PayPal</SelectItem>
                            <SelectItem value="square">Square</SelectItem>
                            <SelectItem value="authorize">Authorize.Net</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="api-key">API Key</Label>
                        <Input id="api-key" type="password" placeholder="Enter API key..." />
                      </div>
                      <div>
                        <Label htmlFor="webhook-url">Webhook URL</Label>
                        <Input id="webhook-url" placeholder="https://your-domain.com/webhooks" />
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline">Cancel</Button>
                        <Button>Add Gateway</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Gateway</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Processing Fees</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paymentGateways.map((gateway) => (
                    <TableRow key={gateway.id}>
                      <TableCell className="font-medium">{gateway.name}</TableCell>
                      <TableCell>
                        <Badge variant={gateway.status === 'Active' ? 'default' : 'secondary'}>
                          {gateway.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{gateway.type}</TableCell>
                      <TableCell>{gateway.fees}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payouts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Payout Rules
              </CardTitle>
              <CardDescription>Configure automatic payout schedules and minimums</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-medium">Global Settings</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="auto-payouts">Enable Auto Payouts</Label>
                      <Switch id="auto-payouts" defaultChecked />
                    </div>
                    <div>
                      <Label htmlFor="platform-fee">Platform Fee Rate (%)</Label>
                      <Input
                        id="platform-fee"
                        type="number"
                        step="0.1"
                        value={platformFeeRate}
                        onChange={(e) => setPlatformFeeRate(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="min-payout">Minimum Payout Amount</Label>
                      <Input
                        id="min-payout"
                        type="number"
                        step="0.01"
                        value={minPayoutAmount}
                        onChange={(e) => setMinPayoutAmount(e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium">Processing Days</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Label>Monday</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Tuesday</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Wednesday</Label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Thursday</Label>
                      <Switch />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label>Friday</Label>
                      <Switch />
                    </div>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-4">Role-Specific Rules</h4>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role</TableHead>
                      <TableHead>Frequency</TableHead>
                      <TableHead>Minimum Amount</TableHead>
                      <TableHead>Processing Fee</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payoutRules.map((rule, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{rule.role}</TableCell>
                        <TableCell>{rule.frequency}</TableCell>
                        <TableCell>{rule.minAmount}</TableCell>
                        <TableCell>{rule.processingFee}</TableCell>
                        <TableCell>
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="currency" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5" />
                  Currency Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="base-currency">Base Currency</Label>
                  <Select defaultValue="usd">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="usd">USD ($)</SelectItem>
                      <SelectItem value="eur">EUR (€)</SelectItem>
                      <SelectItem value="gbp">GBP (£)</SelectItem>
                      <SelectItem value="cad">CAD (C$)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="exchange-provider">Exchange Rate Provider</Label>
                  <Select defaultValue="openexchange">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="openexchange">Open Exchange Rates</SelectItem>
                      <SelectItem value="fixer">Fixer.io</SelectItem>
                      <SelectItem value="currencylayer">CurrencyLayer</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-update">Auto-update Rates</Label>
                  <Switch id="auto-update" defaultChecked />
                </div>

                <div>
                  <Label htmlFor="update-frequency">Update Frequency</Label>
                  <Select defaultValue="hourly">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Tax Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="enable-tax">Enable Tax Calculation</Label>
                  <Switch id="enable-tax" defaultChecked />
                </div>

                <div>
                  <Label htmlFor="tax-provider">Tax Provider</Label>
                  <Select defaultValue="taxjar">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="taxjar">TaxJar</SelectItem>
                      <SelectItem value="avalara">Avalara</SelectItem>
                      <SelectItem value="taxify">Taxify</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="default-tax-rate">Default Tax Rate (%)</Label>
                  <Input id="default-tax-rate" type="number" step="0.01" defaultValue="8.25" />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="tax-inclusive">Tax Inclusive Pricing</Label>
                  <Switch id="tax-inclusive" />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-remit">Auto Tax Remittance</Label>
                  <Switch id="auto-remit" />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-5 w-5" />
                Financial Permissions
              </CardTitle>
              <CardDescription>Control access to financial features and data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <h4 className="font-medium">Admin Permissions</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="view-financials">View Financial Data</Label>
                    <Switch id="view-financials" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="process-payouts">Process Payouts</Label>
                    <Switch id="process-payouts" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="manage-disputes">Manage Disputes</Label>
                    <Switch id="manage-disputes" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="generate-reports">Generate Reports</Label>
                    <Switch id="generate-reports" defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="manual-adjustments">Manual Adjustments</Label>
                    <Switch id="manual-adjustments" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label htmlFor="financial-settings">Modify Settings</Label>
                    <Switch id="financial-settings" />
                  </div>
                </div>
              </div>

              <Separator />

              <div className="space-y-4">
                <h4 className="font-medium">User Role Permissions</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Drivers</p>
                      <p className="text-sm text-muted-foreground">View earnings, request payouts</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Vendors</p>
                      <p className="text-sm text-muted-foreground">View sales, manage invoices, request settlements</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium">Carriers</p>
                      <p className="text-sm text-muted-foreground">View earnings, manage fleet payouts</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link className="h-5 w-5" />
                Financial Integrations
              </CardTitle>
              <CardDescription>Connect with external financial services and tools</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {integrations.map((integration, index) => (
                  <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                        <Link className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="font-medium">{integration.name}</p>
                        <p className="text-sm text-muted-foreground">{integration.type}</p>
                        {integration.lastSync && (
                          <p className="text-xs text-muted-foreground">Last sync: {integration.lastSync}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={integration.status === 'Connected' ? 'default' : 'secondary'}>
                        {integration.status === 'Connected' ? (
                          <>
                            <Check className="h-3 w-3 mr-1" />
                            Connected
                          </>
                        ) : (
                          'Available'
                        )}
                      </Badge>
                      <Button variant="outline" size="sm">
                        {integration.status === 'Connected' ? 'Configure' : 'Connect'}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};