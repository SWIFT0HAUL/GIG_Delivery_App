import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  AlertTriangle, 
  CreditCard, 
  RefreshCw, 
  FileText, 
  Eye, 
  MessageSquare,
  Clock,
  CheckCircle,
  XCircle,
  DollarSign
} from 'lucide-react';

export const FinanceDisputes = () => {
  const [selectedDispute, setSelectedDispute] = useState(null);
  const [adjustmentAmount, setAdjustmentAmount] = useState('');
  const [adjustmentReason, setAdjustmentReason] = useState('');

  // Mock data for disputes
  const refundRequests = [
    { 
      id: 'REF-001', 
      user: 'John Driver', 
      amount: '$150.00', 
      reason: 'Service not completed', 
      status: 'Pending', 
      date: '2024-01-15',
      type: 'Job Cancellation'
    },
    { 
      id: 'REF-002', 
      user: 'ABC Logistics', 
      amount: '$320.50', 
      reason: 'Overcharged fees', 
      status: 'Approved', 
      date: '2024-01-14',
      type: 'Fee Dispute'
    },
    { 
      id: 'REF-003', 
      user: 'Mike Carrier', 
      amount: '$89.75', 
      reason: 'Duplicate charge', 
      status: 'Under Review', 
      date: '2024-01-13',
      type: 'Billing Error'
    },
  ];

  const chargebacks = [
    { 
      id: 'CB-001', 
      user: 'XYZ Shipping', 
      amount: '$245.00', 
      reason: 'Unauthorized transaction', 
      status: 'Disputed', 
      date: '2024-01-12',
      processor: 'Stripe'
    },
    { 
      id: 'CB-002', 
      user: 'Fast Delivery Co', 
      amount: '$180.25', 
      reason: 'Service not received', 
      status: 'Won', 
      date: '2024-01-10',
      processor: 'PayPal'
    },
  ];

  const adjustments = [
    { 
      id: 'ADJ-001', 
      user: 'Sarah Vendor', 
      amount: '+$50.00', 
      reason: 'Compensation for delayed payment', 
      status: 'Completed', 
      date: '2024-01-14',
      adjustedBy: 'Admin User'
    },
    { 
      id: 'ADJ-002', 
      user: 'Tom Driver', 
      amount: '-$25.00', 
      reason: 'Correction for processing error', 
      status: 'Completed', 
      date: '2024-01-13',
      adjustedBy: 'Finance Team'
    },
  ];

  const resolutionLogs = [
    { 
      id: 'LOG-001', 
      case: 'REF-001', 
      action: 'Case opened', 
      user: 'System', 
      timestamp: '2024-01-15 09:30:00',
      notes: 'Automatic case creation from refund request'
    },
    { 
      id: 'LOG-002', 
      case: 'CB-001', 
      action: 'Evidence submitted', 
      user: 'Finance Team', 
      timestamp: '2024-01-14 14:20:00',
      notes: 'Transaction logs and communication history uploaded'
    },
    { 
      id: 'LOG-003', 
      case: 'REF-002', 
      action: 'Case resolved', 
      user: 'Admin User', 
      timestamp: '2024-01-14 16:45:00',
      notes: 'Refund approved and processed'
    },
  ];

  const getStatusBadgeVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'pending': return 'default';
      case 'approved': case 'won': case 'completed': return 'default';
      case 'under review': case 'disputed': return 'secondary';
      case 'rejected': case 'lost': return 'destructive';
      default: return 'default';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Disputes & Adjustments</h2>
        <p className="text-muted-foreground">Manage refund requests, chargebacks, and dispute resolution</p>
      </div>

      <Tabs defaultValue="refunds" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="refunds">Refund Requests</TabsTrigger>
          <TabsTrigger value="chargebacks">Chargebacks</TabsTrigger>
          <TabsTrigger value="adjustments">Manual Adjustments</TabsTrigger>
          <TabsTrigger value="logs">Resolution Logs</TabsTrigger>
        </TabsList>

        <TabsContent value="refunds" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <RefreshCw className="h-5 w-5" />
                Refund Requests
              </CardTitle>
              <CardDescription>Process and manage refund requests from users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex gap-2">
                    <Select defaultValue="all">
                      <SelectTrigger className="w-40">
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Status</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="approved">Approved</SelectItem>
                        <SelectItem value="rejected">Rejected</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="Search requests..." className="w-64" />
                  </div>
                </div>

                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Request ID</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {refundRequests.map((request) => (
                      <TableRow key={request.id}>
                        <TableCell className="font-mono">{request.id}</TableCell>
                        <TableCell className="font-medium">{request.user}</TableCell>
                        <TableCell>{request.amount}</TableCell>
                        <TableCell>{request.type}</TableCell>
                        <TableCell className="max-w-xs truncate">{request.reason}</TableCell>
                        <TableCell>
                          <Badge variant={getStatusBadgeVariant(request.status)}>
                            {request.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{request.date}</TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            {request.status === 'Pending' && (
                              <>
                                <Button variant="outline" size="sm" className="text-green-600">
                                  <CheckCircle className="h-4 w-4" />
                                </Button>
                                <Button variant="outline" size="sm" className="text-red-600">
                                  <XCircle className="h-4 w-4" />
                                </Button>
                              </>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="chargebacks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                Chargebacks
              </CardTitle>
              <CardDescription>Monitor and respond to payment chargebacks</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Case ID</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Processor</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {chargebacks.map((chargeback) => (
                    <TableRow key={chargeback.id}>
                      <TableCell className="font-mono">{chargeback.id}</TableCell>
                      <TableCell className="font-medium">{chargeback.user}</TableCell>
                      <TableCell>{chargeback.amount}</TableCell>
                      <TableCell>{chargeback.reason}</TableCell>
                      <TableCell>{chargeback.processor}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(chargeback.status)}>
                          {chargeback.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{chargeback.date}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button variant="outline" size="sm">
                            <MessageSquare className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="adjustments" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5" />
                    Manual Adjustments
                  </CardTitle>
                  <CardDescription>Create manual balance adjustments for users</CardDescription>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button>New Adjustment</Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create Manual Adjustment</DialogTitle>
                      <DialogDescription>Manually adjust a user's account balance</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="user-select">Select User</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Choose user..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="user1">John Driver</SelectItem>
                            <SelectItem value="user2">ABC Logistics</SelectItem>
                            <SelectItem value="user3">Sarah Vendor</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="adjustment-type">Adjustment Type</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="credit">Credit (+)</SelectItem>
                            <SelectItem value="debit">Debit (-)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="amount">Amount</Label>
                        <Input
                          id="amount"
                          type="number"
                          placeholder="0.00"
                          value={adjustmentAmount}
                          onChange={(e) => setAdjustmentAmount(e.target.value)}
                        />
                      </div>
                      <div>
                        <Label htmlFor="reason">Reason</Label>
                        <Textarea
                          id="reason"
                          placeholder="Explain the reason for this adjustment..."
                          value={adjustmentReason}
                          onChange={(e) => setAdjustmentReason(e.target.value)}
                        />
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline">Cancel</Button>
                        <Button>Create Adjustment</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Adjusted By</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {adjustments.map((adjustment) => (
                    <TableRow key={adjustment.id}>
                      <TableCell className="font-mono">{adjustment.id}</TableCell>
                      <TableCell className="font-medium">{adjustment.user}</TableCell>
                      <TableCell className={adjustment.amount.startsWith('+') ? 'text-green-600' : 'text-red-600'}>
                        {adjustment.amount}
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{adjustment.reason}</TableCell>
                      <TableCell>{adjustment.adjustedBy}</TableCell>
                      <TableCell>
                        <Badge variant={getStatusBadgeVariant(adjustment.status)}>
                          {adjustment.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{adjustment.date}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Resolution Logs
              </CardTitle>
              <CardDescription>Track all dispute resolution activities and decisions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex gap-2">
                  <Input placeholder="Search logs..." className="max-w-sm" />
                  <Select defaultValue="all">
                    <SelectTrigger className="w-40">
                      <SelectValue placeholder="Filter by case" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Cases</SelectItem>
                      <SelectItem value="refunds">Refunds</SelectItem>
                      <SelectItem value="chargebacks">Chargebacks</SelectItem>
                      <SelectItem value="adjustments">Adjustments</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-3">
                  {resolutionLogs.map((log) => (
                    <div key={log.id} className="flex items-start gap-3 p-4 border rounded-lg">
                      <div className="mt-1">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium">{log.action}</span>
                          <Badge variant="outline" className="text-xs">{log.case}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-1">{log.notes}</p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>by {log.user}</span>
                          <span>•</span>
                          <span>{log.timestamp}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};