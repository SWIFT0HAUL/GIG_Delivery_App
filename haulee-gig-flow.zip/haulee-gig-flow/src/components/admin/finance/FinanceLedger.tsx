import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { 
  BookOpen, 
  Plus, 
  Search, 
  Download, 
  Filter,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Building2,
  Calendar,
  FileText,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

// Mock data for chart of accounts
const chartOfAccounts = [
  { id: '1000', name: 'Cash', type: 'Asset', balance: 50000, status: 'Active' },
  { id: '1100', name: 'Accounts Receivable', type: 'Asset', balance: 25000, status: 'Active' },
  { id: '1200', name: 'Inventory', type: 'Asset', balance: 15000, status: 'Active' },
  { id: '2000', name: 'Accounts Payable', type: 'Liability', balance: -12000, status: 'Active' },
  { id: '3000', name: 'Owner Equity', type: 'Equity', balance: -78000, status: 'Active' },
  { id: '4000', name: 'Revenue', type: 'Revenue', balance: -45000, status: 'Active' },
  { id: '5000', name: 'Operating Expenses', type: 'Expense', balance: 10000, status: 'Active' }
];

// Mock data for journal entries
const journalEntries = [
  {
    id: 'JE001',
    date: new Date('2024-01-15'),
    reference: 'INV-001',
    description: 'Driver payment for delivery services',
    entries: [
      { account: 'Operating Expenses', debit: 500, credit: 0 },
      { account: 'Cash', debit: 0, credit: 500 }
    ],
    status: 'Posted',
    createdBy: 'Admin'
  },
  {
    id: 'JE002', 
    date: new Date('2024-01-16'),
    reference: 'INV-002',
    description: 'Customer payment received',
    entries: [
      { account: 'Cash', debit: 1200, credit: 0 },
      { account: 'Accounts Receivable', debit: 0, credit: 1200 }
    ],
    status: 'Posted',
    createdBy: 'Admin'
  }
];

// Mock data for bank reconciliation
const bankReconciliation = [
  {
    id: 'BR001',
    date: new Date('2024-01-31'),
    bankStatement: 48500,
    bookBalance: 50000,
    difference: -1500,
    status: 'Pending',
    reconciler: 'Finance Team'
  }
];

// Mock data for audit trail
const auditTrail = [
  {
    id: 'AT001',
    timestamp: new Date('2024-01-15T10:30:00'),
    user: 'admin@platform.com',
    action: 'Created Journal Entry',
    reference: 'JE001',
    oldValue: null,
    newValue: 'Driver payment entry',
    ipAddress: '192.168.1.1'
  },
  {
    id: 'AT002',
    timestamp: new Date('2024-01-16T14:20:00'),
    user: 'finance@platform.com',
    action: 'Posted Journal Entry',
    reference: 'JE001',
    oldValue: 'Draft',
    newValue: 'Posted',
    ipAddress: '192.168.1.5'
  }
];

export const FinanceLedger = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [accountTypeFilter, setAccountTypeFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [isNewAccountOpen, setIsNewAccountOpen] = useState(false);
  const [isNewJournalEntryOpen, setIsNewJournalEntryOpen] = useState(false);

  const filteredAccounts = chartOfAccounts.filter(account => {
    const matchesSearch = account.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         account.id.includes(searchTerm);
    const matchesType = accountTypeFilter === 'all' || account.type === accountTypeFilter;
    const matchesStatus = statusFilter === 'all' || account.status === statusFilter;
    return matchesSearch && matchesType && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground">Ledger & Reconciliation</h2>
        <p className="text-muted-foreground">Comprehensive accounting and reconciliation management</p>
      </div>

      <Tabs defaultValue="general-ledger" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="general-ledger">General Ledger</TabsTrigger>
          <TabsTrigger value="chart-accounts">Chart of Accounts</TabsTrigger>
          <TabsTrigger value="journal-entries">Journal Entries</TabsTrigger>
          <TabsTrigger value="bank-reconciliation">Bank Reconciliation</TabsTrigger>
          <TabsTrigger value="audit-trail">Audit Trail</TabsTrigger>
        </TabsList>

        {/* General Ledger Tab */}
        <TabsContent value="general-ledger">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="h-5 w-5" />
                General Ledger
              </CardTitle>
              <CardDescription>Complete record of all financial transactions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Summary Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <DollarSign className="h-4 w-4 text-green-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Total Assets</p>
                          <p className="text-2xl font-bold">$90,000</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <TrendingDown className="h-4 w-4 text-red-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Total Liabilities</p>
                          <p className="text-2xl font-bold">$12,000</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <Building2 className="h-4 w-4 text-blue-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Total Equity</p>
                          <p className="text-2xl font-bold">$78,000</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Net Income</p>
                          <p className="text-2xl font-bold">$35,000</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Trial Balance Table */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Trial Balance</h3>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Account</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="text-right">Debit</TableHead>
                        <TableHead className="text-right">Credit</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {chartOfAccounts.map((account) => (
                        <TableRow key={account.id}>
                          <TableCell className="font-medium">{account.name}</TableCell>
                          <TableCell>
                            <Badge variant="outline">{account.type}</Badge>
                          </TableCell>
                          <TableCell className="text-right">
                            {account.balance > 0 ? `$${account.balance.toLocaleString()}` : '-'}
                          </TableCell>
                          <TableCell className="text-right">
                            {account.balance < 0 ? `$${Math.abs(account.balance).toLocaleString()}` : '-'}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Chart of Accounts Tab */}
        <TabsContent value="chart-accounts">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <BookOpen className="h-5 w-5" />
                    Chart of Accounts
                  </CardTitle>
                  <CardDescription>Manage your account structure and classifications</CardDescription>
                </div>
                <Dialog open={isNewAccountOpen} onOpenChange={setIsNewAccountOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      New Account
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create New Account</DialogTitle>
                      <DialogDescription>Add a new account to your chart of accounts</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="account-number">Account Number</Label>
                        <Input id="account-number" placeholder="1000" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="account-name">Account Name</Label>
                        <Input id="account-name" placeholder="Cash" />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="account-type">Account Type</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="asset">Asset</SelectItem>
                            <SelectItem value="liability">Liability</SelectItem>
                            <SelectItem value="equity">Equity</SelectItem>
                            <SelectItem value="revenue">Revenue</SelectItem>
                            <SelectItem value="expense">Expense</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea id="description" placeholder="Account description..." />
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsNewAccountOpen(false)}>Cancel</Button>
                        <Button onClick={() => setIsNewAccountOpen(false)}>Create Account</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search accounts..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                  <Select value={accountTypeFilter} onValueChange={setAccountTypeFilter}>
                    <SelectTrigger className="w-full sm:w-48">
                      <Filter className="mr-2 h-4 w-4" />
                      <SelectValue placeholder="Account Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="Asset">Asset</SelectItem>
                      <SelectItem value="Liability">Liability</SelectItem>
                      <SelectItem value="Equity">Equity</SelectItem>
                      <SelectItem value="Revenue">Revenue</SelectItem>
                      <SelectItem value="Expense">Expense</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-48">
                      <SelectValue placeholder="Status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="Active">Active</SelectItem>
                      <SelectItem value="Inactive">Inactive</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline">
                    <Download className="mr-2 h-4 w-4" />
                    Export
                  </Button>
                </div>

                {/* Accounts Table */}
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account #</TableHead>
                      <TableHead>Account Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="text-right">Balance</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAccounts.map((account) => (
                      <TableRow key={account.id}>
                        <TableCell className="font-medium">{account.id}</TableCell>
                        <TableCell>{account.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{account.type}</Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <span className={account.balance >= 0 ? 'text-green-600' : 'text-red-600'}>
                            ${Math.abs(account.balance).toLocaleString()}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge variant={account.status === 'Active' ? 'default' : 'secondary'}>
                            {account.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">Edit</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Journal Entries Tab */}
        <TabsContent value="journal-entries">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <FileText className="h-5 w-5" />
                    Journal Entries
                  </CardTitle>
                  <CardDescription>Record and manage all journal entries</CardDescription>
                </div>
                <Dialog open={isNewJournalEntryOpen} onOpenChange={setIsNewJournalEntryOpen}>
                  <DialogTrigger asChild>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      New Entry
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl">
                    <DialogHeader>
                      <DialogTitle>Create Journal Entry</DialogTitle>
                      <DialogDescription>Record a new journal entry with debits and credits</DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="entry-date">Date</Label>
                          <Input id="entry-date" type="date" />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="reference">Reference</Label>
                          <Input id="reference" placeholder="INV-001" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="entry-description">Description</Label>
                        <Textarea id="entry-description" placeholder="Entry description..." />
                      </div>
                      <div className="space-y-2">
                        <Label>Journal Entry Lines</Label>
                        <div className="border rounded-lg p-4 space-y-2">
                          <div className="grid grid-cols-4 gap-2 text-sm font-medium">
                            <span>Account</span>
                            <span>Description</span>
                            <span>Debit</span>
                            <span>Credit</span>
                          </div>
                          <div className="grid grid-cols-4 gap-2">
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select account" />
                              </SelectTrigger>
                              <SelectContent>
                                {chartOfAccounts.map(account => (
                                  <SelectItem key={account.id} value={account.id}>
                                    {account.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input placeholder="Description" />
                            <Input placeholder="0.00" type="number" />
                            <Input placeholder="0.00" type="number" />
                          </div>
                          <div className="grid grid-cols-4 gap-2">
                            <Select>
                              <SelectTrigger>
                                <SelectValue placeholder="Select account" />
                              </SelectTrigger>
                              <SelectContent>
                                {chartOfAccounts.map(account => (
                                  <SelectItem key={account.id} value={account.id}>
                                    {account.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <Input placeholder="Description" />
                            <Input placeholder="0.00" type="number" />
                            <Input placeholder="0.00" type="number" />
                          </div>
                        </div>
                        <Button variant="outline" size="sm">
                          <Plus className="mr-2 h-4 w-4" />
                          Add Line
                        </Button>
                      </div>
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline" onClick={() => setIsNewJournalEntryOpen(false)}>Cancel</Button>
                        <Button onClick={() => { toast.success('Journal entry saved as draft!'); setIsNewJournalEntryOpen(false); }}>Save as Draft</Button>
                        <Button onClick={() => { toast.success('Journal entry posted successfully!'); setIsNewJournalEntryOpen(false); }}>Post Entry</Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Entry #</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead className="text-right">Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Created By</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {journalEntries.map((entry) => (
                      <TableRow key={entry.id}>
                        <TableCell className="font-medium">{entry.id}</TableCell>
                        <TableCell>{format(entry.date, 'MMM d, yyyy')}</TableCell>
                        <TableCell>{entry.reference}</TableCell>
                        <TableCell>{entry.description}</TableCell>
                        <TableCell className="text-right">
                          ${entry.entries.reduce((sum, line) => sum + line.debit, 0).toLocaleString()}
                        </TableCell>
                        <TableCell>
                          <Badge variant={entry.status === 'Posted' ? 'default' : 'secondary'}>
                            {entry.status}
                          </Badge>
                        </TableCell>
                        <TableCell>{entry.createdBy}</TableCell>
                        <TableCell className="text-right">
                          <Button variant="ghost" size="sm">View</Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Bank Reconciliation Tab */}
        <TabsContent value="bank-reconciliation">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Bank Reconciliation
              </CardTitle>
              <CardDescription>Reconcile bank statements with book records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Reconciliation Status */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <CheckCircle2 className="h-4 w-4 text-green-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Book Balance</p>
                          <p className="text-2xl font-bold">$50,000</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <Building2 className="h-4 w-4 text-blue-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Bank Balance</p>
                          <p className="text-2xl font-bold">$48,500</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="h-4 w-4 text-orange-600" />
                        <div className="space-y-1">
                          <p className="text-sm font-medium">Difference</p>
                          <p className="text-2xl font-bold text-orange-600">$1,500</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Reconciliation History */}
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Reconciliation History</h3>
                    <Button>
                      <Plus className="mr-2 h-4 w-4" />
                      Start Reconciliation
                    </Button>
                  </div>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Period</TableHead>
                        <TableHead>Bank Statement</TableHead>
                        <TableHead>Book Balance</TableHead>
                        <TableHead>Difference</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Reconciler</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {bankReconciliation.map((recon) => (
                        <TableRow key={recon.id}>
                          <TableCell>{format(recon.date, 'MMM yyyy')}</TableCell>
                          <TableCell>${recon.bankStatement.toLocaleString()}</TableCell>
                          <TableCell>${recon.bookBalance.toLocaleString()}</TableCell>
                          <TableCell className={recon.difference === 0 ? 'text-green-600' : 'text-orange-600'}>
                            ${Math.abs(recon.difference).toLocaleString()}
                          </TableCell>
                          <TableCell>
                            <Badge variant={recon.status === 'Completed' ? 'default' : 'secondary'}>
                              {recon.status}
                            </Badge>
                          </TableCell>
                          <TableCell>{recon.reconciler}</TableCell>
                          <TableCell className="text-right">
                            <Button variant="ghost" size="sm">Review</Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audit Trail Tab */}
        <TabsContent value="audit-trail">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Audit Trail
              </CardTitle>
              <CardDescription>Complete log of all accounting system activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Filters */}
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                    <Input
                      placeholder="Search audit logs..."
                      className="pl-10"
                    />
                  </div>
                  <Select>
                    <SelectTrigger className="w-full sm:w-48">
                      <SelectValue placeholder="Action Type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Actions</SelectItem>
                      <SelectItem value="create">Create</SelectItem>
                      <SelectItem value="update">Update</SelectItem>
                      <SelectItem value="delete">Delete</SelectItem>
                      <SelectItem value="post">Post</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button variant="outline">
                    <Download className="mr-2 h-4 w-4" />
                    Export Logs
                  </Button>
                </div>

                {/* Audit Trail Table */}
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Reference</TableHead>
                      <TableHead>Old Value</TableHead>
                      <TableHead>New Value</TableHead>
                      <TableHead>IP Address</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditTrail.map((log) => (
                      <TableRow key={log.id}>
                        <TableCell>
                          <div className="space-y-1">
                            <p className="text-sm">{format(log.timestamp, 'MMM d, yyyy')}</p>
                            <p className="text-xs text-muted-foreground">{format(log.timestamp, 'h:mm a')}</p>
                          </div>
                        </TableCell>
                        <TableCell>{log.user}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{log.action}</Badge>
                        </TableCell>
                        <TableCell>{log.reference}</TableCell>
                        <TableCell>{log.oldValue || '-'}</TableCell>
                        <TableCell>{log.newValue}</TableCell>
                        <TableCell>{log.ipAddress}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};