import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Bar, BarChart, Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend, PieChart, Pie, Cell } from 'recharts';
import { DollarSign, TrendingUp, TrendingDown, AlertTriangle, Bell, Download, RefreshCw } from 'lucide-react';

const kpiData = [
  {
    title: "Net Balance",
    value: "$845,250",
    change: "+12.5%",
    trend: "up",
    icon: DollarSign,
    description: "Total available balance"
  },
  {
    title: "Monthly Inflow",
    value: "$125,400",
    change: "+8.2%",
    trend: "up",
    icon: TrendingUp,
    description: "This month's revenue"
  },
  {
    title: "Monthly Outflow",
    value: "$89,650",
    change: "-3.1%",
    trend: "down",
    icon: TrendingDown,
    description: "This month's expenses"
  },
  {
    title: "Pending Settlements",
    value: "$32,180",
    change: "+5.4%",
    trend: "up",
    icon: AlertTriangle,
    description: "Awaiting processing"
  }
];

const cashFlowData = [
  { month: 'Jan', inflow: 85000, outflow: 62000, net: 23000 },
  { month: 'Feb', inflow: 92000, outflow: 68000, net: 24000 },
  { month: 'Mar', inflow: 88000, outflow: 71000, net: 17000 },
  { month: 'Apr', inflow: 125400, outflow: 89650, net: 35750 },
  { month: 'May', inflow: 108000, outflow: 78000, net: 30000 },
  { month: 'Jun', inflow: 115000, outflow: 82000, net: 33000 }
];

const categoryData = [
  { name: 'Driver Payments', value: 45, color: 'hsl(var(--primary))' },
  { name: 'Vendor Settlements', value: 25, color: 'hsl(var(--accent))' },
  { name: 'Platform Fees', value: 15, color: 'hsl(var(--secondary))' },
  { name: 'Operational', value: 15, color: 'hsl(var(--muted))' }
];

const alerts = [
  {
    type: "warning",
    title: "Large Withdrawal Pending",
    description: "Vendor #1247 requested $15,000 withdrawal - requires approval",
    time: "2 hours ago"
  },
  {
    type: "info",
    title: "Monthly Report Available",
    description: "March financial report is ready for download",
    time: "1 day ago"
  },
  {
    type: "error",
    title: "Failed Payment",
    description: "Driver payout failed - insufficient funds in secondary account",
    time: "3 hours ago"
  }
];

export const FinanceOverview = () => {
  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Actions */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-foreground">Financial Overview</h2>
          <p className="text-muted-foreground">Real-time dashboard of your financial metrics</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleRefresh} disabled={refreshing}>
            <RefreshCw className={`h-4 w-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {kpiData.map((kpi, index) => {
          const Icon = kpi.icon;
          const isPositive = kpi.trend === 'up';
          
          return (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  {kpi.title}
                </CardTitle>
                <Icon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-foreground">{kpi.value}</div>
                <div className="flex items-center space-x-2 mt-2">
                  <Badge variant={isPositive ? "default" : "secondary"} className="text-xs">
                    {kpi.change}
                  </Badge>
                  <p className="text-xs text-muted-foreground">{kpi.description}</p>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Cash Flow Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Cash Flow Trends</CardTitle>
            <CardDescription>Monthly inflow, outflow, and net balance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={cashFlowData}>
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip formatter={(value, name) => [`$${value.toLocaleString()}`, name]} />
                  <Legend />
                  <Bar dataKey="inflow" fill="hsl(var(--primary))" name="Inflow" />
                  <Bar dataKey="outflow" fill="hsl(var(--accent))" name="Outflow" />
                  <Bar dataKey="net" fill="hsl(var(--secondary))" name="Net" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Expense Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Expense Categories</CardTitle>
            <CardDescription>Current month breakdown</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={120}
                    dataKey="value"
                    label={({ name, value }) => `${name}: ${value}%`}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts & Notifications */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Alerts & Notifications
            </CardTitle>
            <CardDescription>Recent financial alerts requiring attention</CardDescription>
          </div>
          <Button variant="outline" size="sm">View All</Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {alerts.map((alert, index) => (
            <Alert key={index} className={`border-l-4 ${
              alert.type === 'error' ? 'border-l-destructive' :
              alert.type === 'warning' ? 'border-l-accent' :
              'border-l-primary'
            }`}>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-medium">{alert.title}</div>
                    <div className="text-sm text-muted-foreground mt-1">{alert.description}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">{alert.time}</div>
                </div>
              </AlertDescription>
            </Alert>
          ))}
        </CardContent>
      </Card>
    </div>
  );
};