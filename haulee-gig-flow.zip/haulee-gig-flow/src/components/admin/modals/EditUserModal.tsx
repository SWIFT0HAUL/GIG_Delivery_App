import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2 } from 'lucide-react';
import { getSubRolesForRole, ALL_SUB_ROLES } from '@/lib/subRoleConfig';

interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  phone?: string;
  role_key: string;
  sub_role?: string | null;
  is_approved: boolean;
  is_active: boolean;
}

interface EditUserModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: UserProfile;
  onSuccess?: () => void;
}

export const EditUserModal: React.FC<EditUserModalProps> = ({
  open,
  onOpenChange,
  user,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [hasChecklist, setHasChecklist] = useState(false);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    role_key: '',
    sub_role: null as string | null,
    is_active: true,
    is_approved: false
  });
  const [availableSubRoles, setAvailableSubRoles] = useState<Array<{ value: string; label: string }>>([]);

  useEffect(() => {
    const fetchChecklistStatus = async () => {
      if (open && user) {
        setFormData({
          full_name: user.full_name || '',
          email: user.email || '',
          phone: user.phone || '',
          role_key: user.role_key || '',
          sub_role: user.sub_role || null,
          is_active: user.is_active,
          is_approved: user.is_approved
        });
        
        // Set available sub-roles based on current role
        if (user.role_key) {
          setAvailableSubRoles(getSubRolesForRole(user.role_key));
        }

        // Check if user has an approval checklist
        try {
          const { data, error } = await supabase
            .from('user_approval_checklists')
            .select('id')
            .eq('user_id', user.id)
            .single();

          if (error && error.code !== 'PGRST116') {
            console.error('Error checking checklist:', error);
          }
          
          setHasChecklist(!!data);
        } catch (error) {
          console.error('Error fetching checklist:', error);
          setHasChecklist(false);
        }
      }
    };

    fetchChecklistStatus();
  }, [open, user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.full_name.trim()) {
      toast.error('Full name is required');
      return;
    }
    
    if (!formData.email.trim()) {
      toast.error('Email is required');
      return;
    }
    
    if (!formData.role_key) {
      toast.error('Role is required');
      return;
    }

    // Validation: cannot activate if not approved
    if (formData.is_active && !formData.is_approved) {
      toast.error('Cannot activate user: User must be approved first');
      return;
    }

    // Validation: cannot approve without checklist
    if (formData.is_approved && !hasChecklist) {
      toast.error('Cannot approve user: User must have an approval checklist on file');
      return;
    }

    setLoading(true);

    try {
      // Update profile in profiles table
      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          full_name: formData.full_name.trim(),
          email: formData.email.trim(),
          phone: formData.phone?.trim() || null,
          role_key: formData.role_key as any,
          sub_role: formData.sub_role as any,
          is_active: formData.is_active,
          is_approved: formData.is_approved,
          updated_at: new Date().toISOString()
        })
        .eq('id', user.id);

      if (profileError) {
        console.error('Profile update error:', profileError);
        throw new Error(profileError.message || 'Failed to update user profile');
      }

      // Log the activity
      try {
        await supabase.rpc('log_user_activity', {
          p_user_id: user.id,
          p_activity_type: 'profile_update',
          p_activity_description: 'Profile updated by admin',
          p_metadata: { 
            updated_fields: Object.keys(formData),
            changes: {
              role_changed: user.role_key !== formData.role_key,
              sub_role_changed: user.sub_role !== formData.sub_role,
              approved_changed: user.is_approved !== formData.is_approved,
              active_changed: user.is_active !== formData.is_active
            }
          }
        });
      } catch (logError) {
        console.error('Failed to log activity:', logError);
        // Don't throw - activity logging failure shouldn't block the update
      }

      // Send notification to user if status changed
      if (user.is_approved !== formData.is_approved || user.is_active !== formData.is_active) {
        try {
          let notificationMessage = '';
          if (formData.is_approved && !user.is_approved) {
            notificationMessage = 'Your account has been approved by an administrator.';
          } else if (formData.is_active && !user.is_active) {
            notificationMessage = 'Your account has been activated.';
          } else if (!formData.is_active && user.is_active) {
            notificationMessage = 'Your account has been deactivated.';
          }

          if (notificationMessage) {
            await supabase.from('notifications').insert({
              user_id: user.id,
              type: 'system',
              title: 'Account Status Updated',
              message: notificationMessage
            });
          }
        } catch (notifError) {
          console.error('Failed to send notification:', notifError);
        }
      }

      toast.success('User profile updated successfully');
      onOpenChange(false);
      
      // Call success callback to refresh parent data
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      const errorMessage = error?.message || 'Failed to update user profile';
      toast.error(errorMessage);
      console.error('Error updating user:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Edit User</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="full_name">Full Name</Label>
            <Input
              id="full_name"
              value={formData.full_name}
              onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
              placeholder="Enter full name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="Enter email"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="Enter phone number"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role</Label>
            <Select
              value={formData.role_key}
              onValueChange={(value) => {
                setFormData({ ...formData, role_key: value, sub_role: null });
                setAvailableSubRoles(getSubRolesForRole(value));
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="vendor_merchant">Vendor/Merchant</SelectItem>
                <SelectItem value="shipper">Shipper</SelectItem>
                <SelectItem value="broker">Broker</SelectItem>
                <SelectItem value="driver">Driver</SelectItem>
                <SelectItem value="carrier">Carrier</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {availableSubRoles.length > 0 && (
            <div className="space-y-2">
              <Label htmlFor="sub_role">Sub-Role (Optional)</Label>
              <Select
                value={formData.sub_role || 'none'}
                onValueChange={(value) => setFormData({ ...formData, sub_role: value === 'none' ? null : value })}
              >
                <SelectTrigger className="bg-background">
                  <SelectValue placeholder="Select sub-role" />
                </SelectTrigger>
                <SelectContent className="bg-background z-[100] max-h-[300px]">
                  <SelectItem value="none">None</SelectItem>
                  {availableSubRoles.map((subRole) => (
                    <SelectItem key={subRole.value} value={subRole.value}>
                      {subRole.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex items-center justify-between py-2">
            <div className="space-y-1">
              <Label htmlFor="is_active">Active Status</Label>
              {!formData.is_approved && (
                <p className="text-xs text-muted-foreground">User must be approved before activation</p>
              )}
            </div>
            <Switch
              id="is_active"
              checked={formData.is_active}
              disabled={!formData.is_approved}
              onCheckedChange={(checked) => {
                if (!formData.is_approved && checked) {
                  toast.error('Cannot activate user: User must be approved before activation');
                  return;
                }
                setFormData({ ...formData, is_active: checked });
              }}
            />
          </div>

          <div className="flex items-center justify-between py-2">
            <div className="space-y-1">
              <Label htmlFor="is_approved">Approved Status</Label>
              {!hasChecklist && (
                <p className="text-xs text-muted-foreground">User must have an approval checklist on file</p>
              )}
            </div>
            <Switch
              id="is_approved"
              checked={formData.is_approved}
              disabled={!hasChecklist}
              onCheckedChange={(checked) => {
                if (!hasChecklist && checked) {
                  toast.error('Cannot approve user: User must have an approval checklist on file');
                  return;
                }
                setFormData({ ...formData, is_approved: checked });
              }}
            />
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Changes
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
