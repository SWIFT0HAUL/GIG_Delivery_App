import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Check, X, FileText, Activity, User, Download, Shield } from 'lucide-react';
import { format } from 'date-fns';
import { KYCDataProcessor } from '../KYCDataProcessor';
import { TaskSubmissionsViewer } from '../TaskSubmissionsViewer';
import { UserComplianceViewer } from '../UserComplianceViewer';

interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  phone?: string;
  role_key: string;
  is_approved: boolean;
  is_active: boolean;
  created_at: string;
  account_number?: string;
}

interface UserDocument {
  id: string;
  document_name: string;
  document_type: string;
  file_path: string;
  uploaded_at: string;
  status: string;
  review_notes?: string;
  source?: 'onboarding' | 'uploaded';
  step_title?: string;
}

interface ActivityLog {
  id: string;
  activity_type: string;
  activity_description: string;
  created_at: string;
  metadata: any;
}

interface ViewUserDetailsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: UserProfile;
  onRefresh?: () => void;
}

export const ViewUserDetailsModal: React.FC<ViewUserDetailsModalProps> = ({
  open,
  onOpenChange,
  user,
  onRefresh
}) => {
  const [documents, setDocuments] = useState<UserDocument[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [reviewNotes, setReviewNotes] = useState<Record<string, string>>({});

  useEffect(() => {
    if (open && user) {
      fetchDocuments();
      fetchActivityLogs();
    }
  }, [open, user]);

  const fetchDocuments = async () => {
    try {
      // Fetch regular uploaded documents
      const { data: uploadedDocs, error: uploadedError } = await supabase
        .from('user_documents')
        .select('*')
        .eq('user_id', user.id)
        .order('uploaded_at', { ascending: false });

      if (uploadedError) throw uploadedError;

      // Fetch onboarding documents
      const { data: onboardingData, error: onboardingError } = await supabase
        .from('onboarding_data')
        .select('step_number, step_title, step_data, created_at')
        .eq('user_id', user.id)
        .order('step_number', { ascending: true });

      if (onboardingError) throw onboardingError;

      // Build storage path from target user's role and account number
      let storagePrefix: string | null = null;
      let accountNumber = user.account_number;
      if (!accountNumber) {
        const { data: accRow } = await supabase
          .from('user_account_number')
          .select('account_number')
          .eq('user_id', user.id)
          .maybeSingle();
        accountNumber = accRow?.account_number || undefined;
      }
      if (accountNumber && user.role_key) {
        storagePrefix = `${user.role_key}/${accountNumber}`;
      }

      const onboardingDocs: UserDocument[] = [];

      // Extract documents from onboarding data
      onboardingData?.forEach((step) => {
        const stepData = step.step_data as any;
        
        // Check for uploaded_files in step_data
        if (stepData?.uploaded_files && Array.isArray(stepData.uploaded_files)) {
          stepData.uploaded_files.forEach((file: any, index: number) => {
            onboardingDocs.push({
              id: `onboarding-${step.step_number}-${index}`,
              document_name: file.name || file.fileName || 'Onboarding Document',
              document_type: file.type || 'document',
              file_path: file.path || file.url || '',
              uploaded_at: step.created_at,
              status: 'pending',
              source: 'onboarding' as const,
              step_title: step.step_title
            });
          });
        }

        // Check for individual file fields in step_data
        Object.keys(stepData || {}).forEach((key) => {
          if ((key.includes('file') || key.includes('document') || key.includes('license') || 
               key.includes('insurance') || key.includes('registration')) && 
              typeof stepData[key] === 'object' && 
              stepData[key]?.path) {
            onboardingDocs.push({
              id: `onboarding-${step.step_number}-${key}`,
              document_name: stepData[key].name || key.replace(/_/g, ' ').toUpperCase(),
              document_type: stepData[key].type || 'document',
              file_path: stepData[key].path || stepData[key].url || '',
              uploaded_at: step.created_at,
              status: 'pending',
              source: 'onboarding' as const,
              step_title: step.step_title
            });
          }
        });
      });

      // Also fetch from storage bucket for this user's folder (handle both prefix styles)
      if (storagePrefix) {
        const bucketName = storagePrefix.split('/')[0];
        const accountPart = storagePrefix.split('/')[1];
        const prefixes = [accountPart, `${bucketName}/${accountPart}`];

        for (const pref of prefixes) {
          try {
            const { data: storageFiles, error: storageError } = await supabase
              .storage
              .from(bucketName)
              .list(`${pref}/`, { limit: 200, sortBy: { column: 'name', order: 'asc' } });

            if (!storageError && storageFiles && storageFiles.length > 0) {
              storageFiles.forEach((file, index) => {
                onboardingDocs.push({
                  id: `storage-${pref}-${index}`,
                  document_name: file.name,
                  document_type: 'document',
                  file_path: `${bucketName}/${pref}/${file.name}`,
                  uploaded_at: (file as any).created_at || new Date().toISOString(),
                  status: 'pending',
                  source: 'onboarding' as const,
                  step_title: 'Storage Files'
                });
              });
            }
          } catch (storageError) {
            console.error('Error fetching storage files for prefix', pref, storageError);
          }
        }
      }

      // Combine all document sources
      const allDocuments = [
        ...(uploadedDocs || []).map(doc => ({ ...doc, source: 'uploaded' as const })),
        ...onboardingDocs
      ].sort((a, b) => new Date(b.uploaded_at).getTime() - new Date(a.uploaded_at).getTime());

      setDocuments(allDocuments);
    } catch (error: any) {
      toast.error('Failed to load documents');
      console.error('Error fetching documents:', error);
    }
  };

  const fetchActivityLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('user_activity_logs')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      
      // If no activity logs exist, create some default ones based on user data
      if (!data || data.length === 0) {
        const defaultLogs: ActivityLog[] = [
          {
            id: 'default-1',
            activity_type: 'account_created',
            activity_description: 'Account created',
            created_at: user.created_at,
            metadata: {}
          }
        ];

        if (user.is_approved) {
          defaultLogs.push({
            id: 'default-2',
            activity_type: 'account_approved',
            activity_description: 'Account approved by administrator',
            created_at: user.created_at,
            metadata: {}
          });
        }

        setActivityLogs(defaultLogs);
      } else {
        setActivityLogs(data);
      }
    } catch (error: any) {
      toast.error('Failed to load activity logs');
      console.error('Error fetching activity logs:', error);
    }
  };

  const isValidUUID = (id: string) => {
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(id);
  };

  const handleReviewDocument = async (documentId: string, status: 'approved' | 'rejected' | 'pending') => {
    setLoading(true);
    try {
      let targetId = documentId;

      // If this is not a valid UUID (e.g., onboarding/storage-derived doc),
      // create a canonical record in user_documents first, then review it.
      if (!isValidUUID(documentId)) {
        const sourceDoc = documents.find((d) => d.id === documentId);
        if (!sourceDoc) throw new Error('Source document not found');

        const insertPayload = {
          user_id: user.id,
          document_name: sourceDoc.document_name || 'Document',
          document_type: sourceDoc.document_type || 'document',
          file_path: sourceDoc.file_path || '',
          status: 'pending' as const,
          metadata: {
            source: sourceDoc.source || 'onboarding',
            step_title: sourceDoc.step_title || null
          }
        };

        const { data: inserted, error: insertError } = await supabase
          .from('user_documents')
          .insert([insertPayload])
          .select('id')
          .single();

        if (insertError) throw insertError;
        targetId = inserted!.id as string;
      }

      const { error } = await supabase.rpc('review_user_document', {
        p_document_id: targetId,
        p_status: status,
        p_review_notes: reviewNotes[documentId] || reviewNotes[targetId] || null
      });

      if (error) throw error;
      toast.success(`Document ${status === 'pending' ? 'reset to pending' : status} successfully`);
      fetchDocuments();
      if (onRefresh) onRefresh();
    } catch (error: any) {
      toast.error(`Failed to update document status`);
      console.error('Error reviewing document:', error);
    } finally {
      setLoading(false);
    }
  };

  const getBucketAndPath = (fullPath: string) => {
    const [bucket, ...rest] = fullPath.split('/');
    return { bucket, path: rest.join('/') };
  };

  const isProbablyFile = (name: string) => name.includes('.') && !name.endsWith('.');

  const handleDownload = async (fullPath: string) => {
    try {
      const { bucket, path } = getBucketAndPath(fullPath);
      const { data, error } = await supabase.storage.from(bucket).createSignedUrl(path, 60);
      if (error || !data?.signedUrl) throw error || new Error('No signed URL');
      window.open(data.signedUrl, '_blank');
    } catch (e) {
      toast.error('Failed to download file');
      console.error('Download error:', e);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-500';
      case 'rejected': return 'bg-red-500';
      case 'pending': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            User Details: {user.full_name || user.email}
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
            <TabsTrigger value="compliance">Compliance</TabsTrigger>
            <TabsTrigger value="activity">Activity Logs</TabsTrigger>
            <TabsTrigger value="kyc-processor">KYC Processor</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Email</p>
                    <p className="text-sm">{user.email}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Full Name</p>
                    <p className="text-sm">{user.full_name || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Phone</p>
                    <p className="text-sm">{user.phone || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Account Number</p>
                    <p className="text-sm font-mono">{user.account_number || 'N/A'}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Role</p>
                    <Badge variant="outline">{user.role_key}</Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                    <Badge className={user.is_active ? 'bg-green-500' : 'bg-red-500'}>
                      {user.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Approval</p>
                    <Badge className={user.is_approved ? 'bg-green-500' : 'bg-yellow-500'}>
                      {user.is_approved ? 'Approved' : 'Pending'}
                    </Badge>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Joined</p>
                    <p className="text-sm">{format(new Date(user.created_at), 'PPP')}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents">
            <ScrollArea className="h-[500px] pr-4">
              {documents.length === 0 ? (
                <Card>
                  <CardContent className="py-12 text-center">
                    <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground/40" />
                    <p className="text-lg font-medium text-muted-foreground">No documents uploaded</p>
                    <p className="text-sm text-muted-foreground mt-2">Documents will appear here once uploaded</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {documents.map((doc) => (
                    <Card key={doc.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          {/* Document Icon */}
                          <div className="flex-shrink-0">
                            <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center">
                              <FileText className="h-6 w-6 text-primary" />
                            </div>
                          </div>

                          {/* Document Info */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start justify-between gap-2">
                              <div className="flex-1 min-w-0">
                                <h4 className="text-sm font-semibold truncate" title={doc.document_name}>
                                  {doc.document_name}
                                </h4>
                                <p className="text-xs text-muted-foreground mt-1">
                                  Uploaded {format(new Date(doc.uploaded_at), 'PPp')}
                                </p>
                                {doc.step_title && (
                                  <p className="text-xs text-muted-foreground">
                                    From: {doc.step_title}
                                  </p>
                                )}
                              </div>

                              {/* Status Badges */}
                              <div className="flex flex-col gap-1.5 items-end">
                                <Badge 
                                  className={
                                    doc.status === 'approved' ? 'bg-green-500 hover:bg-green-600' : 
                                    doc.status === 'rejected' ? 'bg-red-500 hover:bg-red-600' : 
                                    'bg-yellow-500 hover:bg-yellow-600'
                                  }
                                >
                                  {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                                </Badge>
                                {doc.source === 'onboarding' && (
                                  <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                    Onboarding
                                  </Badge>
                                )}
                              </div>
                            </div>

                            {/* Review Notes */}
                            {doc.review_notes && (
                              <div className="mt-3 p-3 bg-muted rounded-md">
                                <p className="text-xs font-medium text-muted-foreground mb-1">Review Notes:</p>
                                <p className="text-xs">{doc.review_notes}</p>
                              </div>
                            )}

                            {/* Action Buttons */}
                            <div className="flex items-center gap-2 mt-3">
                              {doc.file_path && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleDownload(doc.file_path)}
                                  className="h-8"
                                >
                                  <Download className="h-3.5 w-3.5 mr-1.5" />
                                  Download
                                </Button>
                              )}
                              
                              {doc.status === 'pending' && (
                                <>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleReviewDocument(doc.id, 'approved')}
                                    disabled={loading}
                                    className="h-8 text-green-600 hover:text-green-700 hover:bg-green-50 border-green-200"
                                  >
                                    <Check className="h-3.5 w-3.5 mr-1.5" />
                                    Approve
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => handleReviewDocument(doc.id, 'rejected')}
                                    disabled={loading}
                                    className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200"
                                  >
                                    <X className="h-3.5 w-3.5 mr-1.5" />
                                    Reject
                                  </Button>
                                </>
                              )}
                              
                              {(doc.status === 'approved' || doc.status === 'rejected') && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => handleReviewDocument(doc.id, 'pending')}
                                  disabled={loading}
                                  className="h-8"
                                >
                                  Undo Review
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </ScrollArea>
          </TabsContent>

          <TabsContent value="compliance">
            <ScrollArea className="h-[500px] pr-4">
              <UserComplianceViewer userId={user.id} userRole={user.role_key} />
            </ScrollArea>
          </TabsContent>

          <TabsContent value="activity">
            <ScrollArea className="h-[500px] pr-4">
              <div className="space-y-3">
                {activityLogs.length === 0 ? (
                  <Card>
                    <CardContent className="py-8 text-center text-muted-foreground">
                      <Activity className="h-12 w-12 mx-auto mb-2 opacity-50" />
                      <p>No activity logs available</p>
                    </CardContent>
                  </Card>
                ) : (
                  activityLogs.map((log) => (
                    <Card key={log.id}>
                      <CardContent className="py-3">
                        <div className="flex items-start gap-3">
                          <Activity className="h-4 w-4 mt-1 text-primary" />
                          <div className="flex-1 space-y-1">
                            <div className="flex items-center justify-between gap-2">
                              <Badge variant="outline" className="capitalize">
                                {log.activity_type.replace(/_/g, ' ')}
                              </Badge>
                              <span className="text-xs text-muted-foreground whitespace-nowrap">
                                {format(new Date(log.created_at), 'MMM d, yyyy HH:mm')}
                              </span>
                            </div>
                            <p className="text-sm font-medium">
                              {log.activity_description || `${log.activity_type.replace(/_/g, ' ')} action performed`}
                            </p>
                            {log.metadata && Object.keys(log.metadata).length > 0 && (
                              <details className="text-xs text-muted-foreground">
                                <summary className="cursor-pointer hover:text-foreground">View details</summary>
                                <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-auto">
                                  {JSON.stringify(log.metadata, null, 2)}
                                </pre>
                              </details>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="kyc-processor">
            <ScrollArea className="h-[500px] pr-4">
              <TaskSubmissionsViewer
                userId={user.id}
                userEmail={user.email}
                onUpdate={() => {
                  fetchDocuments();
                  fetchActivityLogs();
                  if (onRefresh) onRefresh();
                }}
              />
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
