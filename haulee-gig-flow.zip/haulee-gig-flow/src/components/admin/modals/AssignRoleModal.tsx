import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Shield } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { getSubRolesForRole } from '@/lib/subRoleConfig';

interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role_key: string;
  sub_role?: string | null;
}

interface Permission {
  id: string;
  name: string;
  description: string;
  category: string;
}

interface AssignRoleModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  user: UserProfile;
  onSuccess?: () => void;
}

export const AssignRoleModal: React.FC<AssignRoleModalProps> = ({
  open,
  onOpenChange,
  user,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedSubRole, setSelectedSubRole] = useState<string | null>(null);
  const [availableSubRoles, setAvailableSubRoles] = useState<Array<{ value: string; label: string }>>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);

  useEffect(() => {
    if (open && user) {
      setSelectedRole(user.role_key);
      setSelectedSubRole(user.sub_role || null);
      setAvailableSubRoles(getSubRolesForRole(user.role_key));
      fetchPermissions();
    }
  }, [open, user]);

  const fetchPermissions = async () => {
    try {
      const { data, error } = await supabase
        .from('permissions')
        .select('*')
        .order('category', { ascending: true });

      if (error) throw error;
      setPermissions(data || []);
    } catch (error: any) {
      console.error('Error fetching permissions:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Update user role and sub-role
      const { error: roleError } = await supabase
        .from('profiles')
        .update({ 
          role_key: selectedRole as any,
          sub_role: selectedSubRole as any
        })
        .eq('id', user.id);

      if (roleError) throw roleError;

      // Log the activity
      await supabase.rpc('log_user_activity', {
        p_user_id: user.id,
        p_activity_type: 'role_change',
        p_activity_description: `Role changed to ${selectedRole} by admin`,
        p_metadata: { new_role: selectedRole, previous_role: user.role_key }
      });

      toast.success('Role assigned successfully');
      onOpenChange(false);
      if (onSuccess) onSuccess();
    } catch (error: any) {
      toast.error('Failed to assign role');
      console.error('Error assigning role:', error);
    } finally {
      setLoading(false);
    }
  };

  const togglePermission = (permissionId: string) => {
    setSelectedPermissions(prev =>
      prev.includes(permissionId)
        ? prev.filter(id => id !== permissionId)
        : [...prev, permissionId]
    );
  };

  const groupedPermissions = permissions.reduce((acc, permission) => {
    if (!acc[permission.category]) {
      acc[permission.category] = [];
    }
    acc[permission.category].push(permission);
    return acc;
  }, {} as Record<string, Permission[]>);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Assign Role & Permissions: {user.full_name || user.email}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="role">Primary Role</Label>
            <Select 
              value={selectedRole} 
              onValueChange={(value) => {
                setSelectedRole(value);
                setSelectedSubRole(null);
                setAvailableSubRoles(getSubRolesForRole(value));
              }}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="super_admin">Super Admin</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="vendor_merchant">Vendor/Merchant</SelectItem>
                <SelectItem value="shipper">Shipper</SelectItem>
                <SelectItem value="broker">Broker</SelectItem>
                <SelectItem value="driver">Driver</SelectItem>
                <SelectItem value="carrier">Carrier</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {availableSubRoles.length > 0 && (
            <div className="space-y-2">
              <Label htmlFor="sub_role">Sub-Role / Specialization (Optional)</Label>
              <Select
                value={selectedSubRole || 'none'}
                onValueChange={(value) => setSelectedSubRole(value === 'none' ? null : value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select sub-role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  {availableSubRoles.map((subRole) => (
                    <SelectItem key={subRole.value} value={subRole.value}>
                      {subRole.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="space-y-2">
            <Label>Additional Permissions</Label>
            <ScrollArea className="h-[300px] rounded-md border p-4">
              {Object.entries(groupedPermissions).map(([category, perms]) => (
                <div key={category} className="mb-4">
                  <h4 className="font-semibold mb-2 text-sm uppercase text-muted-foreground">
                    {category}
                  </h4>
                  <div className="space-y-2">
                    {perms.map((permission) => (
                      <div key={permission.id} className="flex items-start space-x-2">
                        <Checkbox
                          id={permission.id}
                          checked={selectedPermissions.includes(permission.id)}
                          onCheckedChange={() => togglePermission(permission.id)}
                        />
                        <div className="flex-1">
                          <label
                            htmlFor={permission.id}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                          >
                            {permission.name}
                          </label>
                          {permission.description && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {permission.description}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </ScrollArea>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Assign Role
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
