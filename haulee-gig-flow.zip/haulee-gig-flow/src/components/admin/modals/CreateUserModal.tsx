import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, UserPlus, RefreshCw, Eye, EyeOff } from 'lucide-react';
import { ALL_SUB_ROLES } from '@/lib/subRoleConfig';

interface CreateUserModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}

export const CreateUserModal: React.FC<CreateUserModalProps> = ({
  open,
  onOpenChange,
  onSuccess
}) => {
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [hasNoMiddleName, setHasNoMiddleName] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    first_name: '',
    middle_name: '',
    last_name: '',
    phone: '',
    role_key: '',
    sub_role: null as string | null,
  });

  const generatePassword = () => {
    // Generate 12-character password with at least one special character
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const lowercase = 'abcdefghijkmnopqrstuvwxyz';
    const numbers = '0123456789';
    const special = '!@#$%^&*';
    const allChars = uppercase + lowercase + numbers + special;
    
    // Ensure at least one character from each category
    let password = '';
    password += uppercase.charAt(Math.floor(Math.random() * uppercase.length));
    password += lowercase.charAt(Math.floor(Math.random() * lowercase.length));
    password += numbers.charAt(Math.floor(Math.random() * numbers.length));
    password += special.charAt(Math.floor(Math.random() * special.length));
    
    // Fill the rest randomly to reach 12 characters
    for (let i = password.length; i < 12; i++) {
      password += allChars.charAt(Math.floor(Math.random() * allChars.length));
    }
    
    // Shuffle the password
    password = password.split('').sort(() => Math.random() - 0.5).join('');
    
    setFormData(prev => ({ ...prev, password }));
    setShowPassword(true); // Show password after generation
    toast.success('Password generated successfully');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.email.trim()) {
      toast.error('Email is required');
      return;
    }

    // Strict email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email.trim())) {
      toast.error('Please enter a valid email address (e.g., user@example.com)');
      return;
    }
    
    if (!formData.password || formData.password.length < 12) {
      toast.error('Password must be at least 12 characters');
      return;
    }
    
    // Check for at least one special character
    const specialCharRegex = /[!@#$%^&*]/;
    if (!specialCharRegex.test(formData.password)) {
      toast.error('Password must include at least one special character (!@#$%^&*)');
      return;
    }
    
    if (!formData.first_name.trim()) {
      toast.error('First name is required');
      return;
    }
    
    if (!formData.last_name.trim()) {
      toast.error('Last name is required');
      return;
    }
    
    if (!hasNoMiddleName && !formData.middle_name.trim()) {
      toast.error('Middle name is required or check "No middle name"');
      return;
    }
    
    if (!formData.role_key) {
      toast.error('Role is required');
      return;
    }

    setLoading(true);

    try {
      // Get current session for auth
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      // Combine names
      const fullName = hasNoMiddleName 
        ? `${formData.first_name.trim()} ${formData.last_name.trim()}`
        : `${formData.first_name.trim()} ${formData.middle_name.trim()} ${formData.last_name.trim()}`;

      // Call edge function to create user
      const response = await fetch(
        'https://cqoydkxlonzobykwjcin.supabase.co/functions/v1/create-user-invitation',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({
            email: formData.email.trim(),
            password: formData.password,
            full_name: fullName,
            phone: formData.phone?.trim() || null,
            role: formData.role_key,
            sub_role: formData.sub_role,
            sendInvitation: true, // Always send email for all user roles
          }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to create user');
      }

      toast.success('User created successfully');
      
      // Reset form
      setFormData({
        email: '',
        password: '',
        first_name: '',
        middle_name: '',
        last_name: '',
        phone: '',
        role_key: '',
        sub_role: null,
      });
      setHasNoMiddleName(false);
      
      onOpenChange(false);
      
      // Call success callback to refresh parent data
      if (onSuccess) {
        onSuccess();
      }
    } catch (error: any) {
      const errorMessage = error?.message || 'Failed to create user';
      toast.error(errorMessage);
      console.error('Error creating user:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <UserPlus className="h-5 w-5" />
            Create New User
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              placeholder="user@example.com"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password *</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  placeholder="Min. 12 characters + special char"
                  minLength={12}
                  required
                  className="pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-0 top-0 h-full px-3 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                  title={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <Eye className="h-4 w-4 text-muted-foreground" />
                  )}
                </Button>
              </div>
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={generatePassword}
                title="Generate Password"
              >
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Minimum 12 characters with at least one special character (!@#$%^&*) required.
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="first_name">First Name *</Label>
            <Input
              id="first_name"
              value={formData.first_name}
              onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
              placeholder="John"
              required
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="middle_name">Middle Name {!hasNoMiddleName && '*'}</Label>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="no_middle_name"
                  checked={hasNoMiddleName}
                  onCheckedChange={(checked) => {
                    setHasNoMiddleName(checked as boolean);
                    if (checked) {
                      setFormData({ ...formData, middle_name: '' });
                    }
                  }}
                />
                <Label 
                  htmlFor="no_middle_name" 
                  className="text-xs font-normal cursor-pointer"
                >
                  No middle name
                </Label>
              </div>
            </div>
            <Input
              id="middle_name"
              value={formData.middle_name}
              onChange={(e) => setFormData({ ...formData, middle_name: e.target.value })}
              placeholder="Michael"
              required={!hasNoMiddleName}
              disabled={hasNoMiddleName}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="last_name">Last Name *</Label>
            <Input
              id="last_name"
              value={formData.last_name}
              onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
              placeholder="Doe"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Phone</Label>
            <Input
              id="phone"
              type="tel"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              placeholder="+1 (555) 000-0000"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="role">Role *</Label>
            <Select
              value={formData.role_key}
              onValueChange={(value) => {
                setFormData({ ...formData, role_key: value, sub_role: null });
              }}
              required
            >
              <SelectTrigger>
                <SelectValue placeholder="Select role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="super_admin">Super Admin</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="vendor_merchant">Vendor/Merchant</SelectItem>
                <SelectItem value="shipper">Shipper</SelectItem>
                <SelectItem value="broker">Broker</SelectItem>
                <SelectItem value="driver">Driver</SelectItem>
                <SelectItem value="carrier">Carrier</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sub_role">Sub-Role (Optional)</Label>
            <Select
              value={formData.sub_role || 'none'}
              onValueChange={(value) => setFormData({ ...formData, sub_role: value === 'none' ? null : value })}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select sub-role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                {ALL_SUB_ROLES.map((subRole) => (
                  <SelectItem key={subRole.value} value={subRole.value}>
                    {subRole.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Optional: Assign a sub-role for additional access control
            </p>
          </div>

          <DialogFooter className="gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Create User
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};