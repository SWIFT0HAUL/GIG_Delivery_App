import { Button } from '@/components/ui/button';
import { usePlatformSettings } from '@/contexts/PlatformSettingsContext';
import { AdvancedSettings } from "./settings/AdvancedSettings";
import { AlertCircle, RefreshCw, Undo, RotateCcw, Save } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { useState } from 'react';

export const PlatformSettingsPage = () => {
  const { 
    loading, 
    reloadSettings, 
    activityLog, 
    undoLastChange, 
    resetToDefaults, 
    canUndo,
    hasUnsavedChanges,
    saveAllChanges,
    discardChanges 
  } = usePlatformSettings();
  const [showResetDialog, setShowResetDialog] = useState(false);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="platform-settings-panel container mx-auto p-6 space-y-6 pb-20 md:pb-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold">Platform Settings</h1>
            {hasUnsavedChanges && (
              <Badge variant="secondary" className="text-xs">
                Unsaved Changes
              </Badge>
            )}
          </div>
          <p className="text-muted-foreground">
            Unified platform settings management - all settings in one place
          </p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={saveAllChanges}
            variant="default"
            size="sm"
            disabled={!hasUnsavedChanges}
          >
            <Save className="h-4 w-4 mr-2" />
            Save Changes
          </Button>
          
          <Button 
            onClick={undoLastChange} 
            variant="outline" 
            size="sm"
            disabled={!canUndo}
          >
            <Undo className="h-4 w-4 mr-2" />
            Undo
          </Button>
          
          <AlertDialog open={showResetDialog} onOpenChange={setShowResetDialog}>
            <AlertDialogTrigger asChild>
              <Button variant="outline" size="sm">
                <RotateCcw className="h-4 w-4 mr-2" />
                Reset to Defaults
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Reset All Settings?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will reset all platform settings to their default values. This action cannot be undone.
                  Are you sure you want to continue?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={async () => {
                    await resetToDefaults();
                    setShowResetDialog(false);
                  }}
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                >
                  Reset All Settings
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <Button onClick={reloadSettings} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      <Alert>
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          All platform settings are now in one unified view. Use search and filters to find specific settings.
        </AlertDescription>
      </Alert>

      <AdvancedSettings />
    </div>
  );
};
