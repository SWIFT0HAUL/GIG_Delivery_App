import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, Key, Database, Server, Eye, AlertTriangle } from 'lucide-react';

export function FinancialEncryptionGuide() {
  return (
    <div className="space-y-6">
      <Alert className="border-blue-200 bg-blue-50">
        <Shield className="h-4 w-4 text-blue-600" />
        <AlertDescription className="text-blue-700">
          <strong>Financial Data Encryption System:</strong> This system implements field-level encryption for all sensitive 
          financial data using AES-256-GCM encryption. All credit card numbers, CVV codes, bank account numbers, and routing 
          numbers are now encrypted at rest and can only be decrypted by authorized administrators.
        </AlertDescription>
      </Alert>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Lock className="h-5 w-5 text-blue-600" />
              How Encryption Works
            </CardTitle>
            <CardDescription>
              Technical overview of the encryption implementation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Key className="h-4 w-4 text-green-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-sm">AES-256-GCM Encryption</h4>
                  <p className="text-xs text-muted-foreground">
                    Military-grade encryption with authenticated encryption and additional data (AEAD)
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Database className="h-4 w-4 text-blue-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-sm">Random IV Generation</h4>
                  <p className="text-xs text-muted-foreground">
                    Each encryption uses a unique initialization vector for maximum security
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Server className="h-4 w-4 text-purple-600 mt-1" />
                <div>
                  <h4 className="font-semibold text-sm">Edge Function Processing</h4>
                  <p className="text-xs text-muted-foreground">
                    Encryption/decryption happens in secure edge functions, never client-side
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-orange-600" />
              Access Control & Masking
            </CardTitle>
            <CardDescription>
              How data access and display masking works
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold text-sm mb-2">Admin Access</h4>
                <div className="text-xs space-y-1">
                  <p>• Can decrypt and view full financial data</p>
                  <p>• All access is logged for audit compliance</p>
                  <p>• Requires explicit confirmation dialogs</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-sm mb-2">Vendor Access</h4>
                <div className="text-xs space-y-1">
                  <p>• Can view only their own data</p>
                  <p>• Financial data shown with masking</p>
                  <p>• CVV codes always hidden (***)</p>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-sm mb-2">Data Masking</h4>
                <div className="text-xs space-y-1">
                  <p>• Card numbers: ****-****-****-1234</p>
                  <p>• Account numbers: ****5678</p>
                  <p>• Routing numbers: ******89</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Compliance & Security Standards</CardTitle>
          <CardDescription>
            Industry standards and compliance certifications
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h4 className="font-semibold text-sm">Compliance Standards</h4>
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-green-100 text-green-800 border-green-300">
                    PCI DSS Level 1
                  </Badge>
                  <span className="text-xs text-muted-foreground">Credit card data protection</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-300">
                    FIPS 140-2 Level 1
                  </Badge>
                  <span className="text-xs text-muted-foreground">Cryptographic module standards</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-300">
                    SOC 2 Type II Ready
                  </Badge>
                  <span className="text-xs text-muted-foreground">Security controls framework</span>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              <h4 className="font-semibold text-sm">Security Features</h4>
              <div className="space-y-2 text-xs">
                <p>• 256-bit encryption keys stored in Supabase Vault</p>
                <p>• Comprehensive audit logging for all access</p>
                <p>• Role-based access control (RBAC)</p>
                <p>• Secure edge function processing</p>
                <p>• No client-side financial data exposure</p>
                <p>• Automated data migration capabilities</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="border-orange-200 bg-orange-50/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <AlertTriangle className="h-5 w-5" />
            Important Security Notes
          </CardTitle>
        </CardHeader>
        <CardContent className="text-orange-700">
          <div className="space-y-3 text-sm">
            <div>
              <strong>Encryption Key Management:</strong> The encryption key is stored securely in Supabase secrets. 
              Loss of this key will make encrypted data unrecoverable.
            </div>
            <div>
              <strong>Data Migration:</strong> Use the migration tool to encrypt existing plain-text financial data. 
              This process is irreversible and should be performed during maintenance windows.
            </div>
            <div>
              <strong>Compliance:</strong> While this system implements strong encryption, additional compliance 
              measures may be required depending on your jurisdiction and business requirements.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}