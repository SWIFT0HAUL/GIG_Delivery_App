import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Eye, 
  FileText, 
  Search,
  Download,
  Filter,
  Trash2
} from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { UserApprovalChecklist } from './UserApprovalChecklist';
import { UserPreActivationChecklist } from './UserPreActivationChecklist';

interface ChecklistSummary {
  user_id: string;
  user_name: string;
  user_email: string;
  user_role: string;
  approval_status: string | null;
  approval_date: string | null;
  approval_admin: string | null;
  preactivation_status: string | null;
  preactivation_date: string | null;
  preactivation_admin: string | null;
}

export const ChecklistSummaryReport = () => {
  const [summaries, setSummaries] = useState<ChecklistSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [checklistDialogOpen, setChecklistDialogOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [checklistType, setChecklistType] = useState<'approval' | 'preactivation' | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<{ userId: string; type: 'approval' | 'preactivation' } | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchChecklistSummaries();
  }, []);

  const fetchChecklistSummaries = async () => {
    try {
      setLoading(true);

      // Fetch all users with their profile information
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, email, role_name')
        .order('full_name');

      if (profilesError) throw profilesError;

      // Fetch approval checklists
      const { data: approvalChecklists, error: approvalError } = await supabase
        .from('user_approval_checklists')
        .select('user_id, status, checklist_date, admin_name');

      if (approvalError) throw approvalError;

      // Fetch activating checklists
      const { data: preactivationChecklists, error: preactivationError } = await supabase
        .from('user_preactivation_checklists')
        .select('user_id, status, checklist_date, admin_name');

      if (preactivationError) throw preactivationError;

      // Combine data
      const combined = profiles?.map(profile => {
        const approval = approvalChecklists?.find(c => c.user_id === profile.id);
        const preactivation = preactivationChecklists?.find(c => c.user_id === profile.id);

        return {
          user_id: profile.id,
          user_name: profile.full_name || 'N/A',
          user_email: profile.email || 'N/A',
          user_role: profile.role_name || 'N/A',
          approval_status: approval?.status || null,
          approval_date: approval?.checklist_date || null,
          approval_admin: approval?.admin_name || null,
          preactivation_status: preactivation?.status || null,
          preactivation_date: preactivation?.checklist_date || null,
          preactivation_admin: preactivation?.admin_name || null,
        };
      }) || [];

      setSummaries(combined);
    } catch (error: any) {
      console.error('Error fetching checklist summaries:', error);
      toast({
        title: 'Error',
        description: 'Failed to load checklist summaries',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string | null) => {
    if (!status) {
      return <Badge variant="outline" className="gap-1"><Clock className="h-3 w-3" />Not Started</Badge>;
    }
    
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="gap-1 bg-green-600"><CheckCircle2 className="h-3 w-3" />Completed</Badge>;
      case 'in_progress':
        return <Badge variant="secondary" className="gap-1"><Clock className="h-3 w-3" />In Progress</Badge>;
      case 'rejected':
        return <Badge variant="destructive" className="gap-1"><XCircle className="h-3 w-3" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const handleViewChecklist = (userId: string, type: 'approval' | 'preactivation') => {
    setSelectedUserId(userId);
    setChecklistType(type);
    setChecklistDialogOpen(true);
  };

  const handleChecklistClose = () => {
    setChecklistDialogOpen(false);
    setSelectedUserId(null);
    setChecklistType(null);
    // Refresh the data after closing
    fetchChecklistSummaries();
  };

  const handleDeleteClick = (userId: string, type: 'approval' | 'preactivation') => {
    setDeleteTarget({ userId, type });
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deleteTarget) return;

    try {
      const tableName = deleteTarget.type === 'approval' 
        ? 'user_approval_checklists' 
        : 'user_preactivation_checklists';

      const { error } = await supabase
        .from(tableName)
        .delete()
        .eq('user_id', deleteTarget.userId);

      if (error) throw error;

      toast({
        title: 'Checklist Deleted',
        description: `${deleteTarget.type === 'approval' ? 'Approval' : 'Activating'} checklist has been deleted successfully.`,
      });

      fetchChecklistSummaries();
    } catch (error: any) {
      console.error('Error deleting checklist:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete checklist',
        variant: 'destructive',
      });
    } finally {
      setDeleteDialogOpen(false);
      setDeleteTarget(null);
    }
  };

  const exportToCSV = () => {
    const headers = [
      'User Name',
      'Email',
      'Role',
      'Approval Checklist',
      'Approval Date',
      'Approval Admin',
      'Activating Checklist',
      'Activating Date',
      'Activating Admin'
    ];

    const rows = filteredSummaries.map(s => [
      s.user_name,
      s.user_email,
      s.user_role,
      s.approval_status || 'Not Started',
      s.approval_date || 'N/A',
      s.approval_admin || 'N/A',
      s.preactivation_status || 'Not Started',
      s.preactivation_date || 'N/A',
      s.preactivation_admin || 'N/A'
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `checklist-summary-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const filteredSummaries = summaries.filter(summary => {
    const matchesSearch = 
      summary.user_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      summary.user_email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesRole = roleFilter === 'all' || summary.user_role === roleFilter;

    const matchesStatus = statusFilter === 'all' || 
      summary.approval_status === statusFilter ||
      summary.preactivation_status === statusFilter;

    return matchesSearch && matchesRole && matchesStatus;
  });

  const uniqueRoles = Array.from(new Set(summaries.map(s => s.user_role)));

  const stats = {
    total: summaries.length,
    approvalCompleted: summaries.filter(s => s.approval_status === 'completed').length,
    preactivationCompleted: summaries.filter(s => s.preactivation_status === 'completed').length,
    inProgress: summaries.filter(s => 
      s.approval_status === 'in_progress' || s.preactivation_status === 'in_progress'
    ).length,
  };

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Checklist Summary Report</CardTitle>
          <CardDescription>Loading checklist summaries...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center p-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Checklist Summary Report
            </CardTitle>
            <CardDescription>
              Overview of all user approval and activating checklists
            </CardDescription>
          </div>
          <Button onClick={exportToCSV} variant="outline" className="gap-2">
            <Download className="h-4 w-4" />
            Export CSV
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {/* Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold">{stats.total}</div>
              <p className="text-xs text-muted-foreground">Total Users</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-green-600">{stats.approvalCompleted}</div>
              <p className="text-xs text-muted-foreground">Approval Completed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-blue-600">{stats.preactivationCompleted}</div>
              <p className="text-xs text-muted-foreground">Activating Completed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-2xl font-bold text-yellow-600">{stats.inProgress}</div>
              <p className="text-xs text-muted-foreground">In Progress</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by role" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Roles</SelectItem>
              {uniqueRoles.map(role => (
                <SelectItem key={role} value={role}>{role}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Summary Table */}
        <Tabs defaultValue="combined" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="combined">Combined View</TabsTrigger>
            <TabsTrigger value="approval">Approval Only</TabsTrigger>
            <TabsTrigger value="preactivation">Activating Only</TabsTrigger>
          </TabsList>

          <TabsContent value="combined">
            <div className="border rounded-lg overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Approval Checklist</TableHead>
                    <TableHead>Approval Admin</TableHead>
                    <TableHead>Activating Checklist</TableHead>
                    <TableHead>Activating Admin</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSummaries.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground">
                        No users found
                      </TableCell>
                    </TableRow>
                  ) : (
                    filteredSummaries.map((summary) => (
                      <TableRow key={summary.user_id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{summary.user_name}</div>
                            <div className="text-xs text-muted-foreground">{summary.user_email}</div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary">{summary.user_role}</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {getStatusBadge(summary.approval_status)}
                            {summary.approval_date && (
                              <div className="text-xs text-muted-foreground">
                                {new Date(summary.approval_date).toLocaleDateString()}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{summary.approval_admin || '-'}</div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {getStatusBadge(summary.preactivation_status)}
                            {summary.preactivation_date && (
                              <div className="text-xs text-muted-foreground">
                                {new Date(summary.preactivation_date).toLocaleDateString()}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{summary.preactivation_admin || '-'}</div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant={summary.approval_status ? "ghost" : "outline"}
                              size="sm"
                              onClick={() => handleViewChecklist(summary.user_id, 'approval')}
                              title={summary.approval_status ? "View/Edit Approval Checklist" : "Create Approval Checklist"}
                            >
                              {summary.approval_status ? <Eye className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteClick(summary.user_id, 'approval')}
                              disabled={!summary.approval_status}
                              title="Delete Approval Checklist"
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                            <Button
                              variant={summary.preactivation_status ? "ghost" : "outline"}
                              size="sm"
                              onClick={() => handleViewChecklist(summary.user_id, 'preactivation')}
                              title={summary.preactivation_status ? "View/Edit Activating Checklist" : "Create Activating Checklist"}
                            >
                              {summary.preactivation_status ? <Eye className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteClick(summary.user_id, 'preactivation')}
                              disabled={!summary.preactivation_status}
                              title="Delete Activating Checklist"
                            >
                              <Trash2 className="h-4 w-4 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="approval">
            <div className="border rounded-lg overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Admin</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSummaries.map((summary) => (
                    <TableRow key={summary.user_id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{summary.user_name}</div>
                          <div className="text-xs text-muted-foreground">{summary.user_email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{summary.user_role}</Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(summary.approval_status)}</TableCell>
                      <TableCell>
                        {summary.approval_date 
                          ? new Date(summary.approval_date).toLocaleDateString()
                          : '-'
                        }
                      </TableCell>
                      <TableCell>{summary.approval_admin || '-'}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant={summary.approval_status ? "ghost" : "outline"}
                            size="sm"
                            onClick={() => handleViewChecklist(summary.user_id, 'approval')}
                            title={summary.approval_status ? "View/Edit Approval Checklist" : "Create Approval Checklist"}
                          >
                            {summary.approval_status ? <Eye className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteClick(summary.user_id, 'approval')}
                            disabled={!summary.approval_status}
                            title="Delete Approval Checklist"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="preactivation">
            <div className="border rounded-lg overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Admin</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSummaries.map((summary) => (
                    <TableRow key={summary.user_id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{summary.user_name}</div>
                          <div className="text-xs text-muted-foreground">{summary.user_email}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary">{summary.user_role}</Badge>
                      </TableCell>
                      <TableCell>{getStatusBadge(summary.preactivation_status)}</TableCell>
                      <TableCell>
                        {summary.preactivation_date 
                          ? new Date(summary.preactivation_date).toLocaleDateString()
                          : '-'
                        }
                      </TableCell>
                      <TableCell>{summary.preactivation_admin || '-'}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant={summary.preactivation_status ? "ghost" : "outline"}
                            size="sm"
                            onClick={() => handleViewChecklist(summary.user_id, 'preactivation')}
                            title={summary.preactivation_status ? "View/Edit Activating Checklist" : "Create Activating Checklist"}
                          >
                            {summary.preactivation_status ? <Eye className="h-4 w-4" /> : <FileText className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteClick(summary.user_id, 'preactivation')}
                            disabled={!summary.preactivation_status}
                            title="Delete Activating Checklist"
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>

    <Dialog open={checklistDialogOpen} onOpenChange={setChecklistDialogOpen}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {checklistType === 'approval' 
              ? (summaries.find(s => s.user_id === selectedUserId)?.approval_status 
                  ? 'User Approval Checklist' 
                  : 'Create User Approval Checklist')
              : (summaries.find(s => s.user_id === selectedUserId)?.preactivation_status 
                  ? 'User Pre-Activation Checklist' 
                  : 'Create User Pre-Activation Checklist')
            }
          </DialogTitle>
        </DialogHeader>
        <div className="mt-4">
          {checklistType === 'approval' && selectedUserId && (
            <UserApprovalChecklist 
              preselectedUserId={selectedUserId}
              onSaveComplete={handleChecklistClose}
            />
          )}
          {checklistType === 'preactivation' && selectedUserId && (
            <UserPreActivationChecklist 
              preselectedUserId={selectedUserId}
              onSaveComplete={handleChecklistClose}
            />
          )}
        </div>
      </DialogContent>
    </Dialog>

    <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete Checklist</AlertDialogTitle>
          <AlertDialogDescription>
            Are you sure you want to delete this {deleteTarget?.type === 'approval' ? 'approval' : 'activating'} checklist? 
            This action cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel onClick={() => setDeleteTarget(null)}>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={handleDeleteConfirm} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
    </>
  );
};
