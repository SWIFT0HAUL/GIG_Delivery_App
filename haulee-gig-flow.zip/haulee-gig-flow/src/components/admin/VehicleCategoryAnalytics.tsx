import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { BarChart3, TrendingUp, Truck } from 'lucide-react';

interface VehicleCategoryStats {
  category_id: number;
  category_name: string;
  category_icon: string;
  category_description: string;
  total_jobs: number;
  pending_jobs: number;
  posted_jobs: number;
  in_progress_jobs: number;
  completed_jobs: number;
  total_pay_amount: number;
  avg_pay_amount: number;
  total_distance_miles: number;
  avg_distance_miles: number;
}

export const VehicleCategoryAnalytics = () => {
  const { data: categoryStats, isLoading } = useQuery({
    queryKey: ['vehicle-category-analytics'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs_by_vehicle_category')
        .select('*');
      
      if (error) throw error;
      return data as VehicleCategoryStats[];
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Jobs by Vehicle Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const totalJobs = categoryStats?.reduce((sum, cat) => sum + cat.total_jobs, 0) || 0;
  const totalRevenue = categoryStats?.reduce((sum, cat) => sum + cat.total_pay_amount, 0) || 0;

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Jobs</p>
                <p className="text-2xl font-bold">{totalJobs}</p>
              </div>
              <Truck className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Revenue</p>
                <p className="text-2xl font-bold">${totalRevenue.toLocaleString()}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Categories</p>
                <p className="text-2xl font-bold">
                  {categoryStats?.filter(c => c.total_jobs > 0).length || 0}
                </p>
              </div>
              <BarChart3 className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Jobs by Vehicle Category
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Category</TableHead>
                <TableHead className="text-center">Total Jobs</TableHead>
                <TableHead className="text-center">Pending</TableHead>
                <TableHead className="text-center">Posted</TableHead>
                <TableHead className="text-center">In Progress</TableHead>
                <TableHead className="text-center">Completed</TableHead>
                <TableHead className="text-right">Total Pay</TableHead>
                <TableHead className="text-right">Avg Pay</TableHead>
                <TableHead className="text-right">Avg Distance</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {categoryStats?.map((stat) => (
                <TableRow key={stat.category_id}>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <span className="text-xl">{stat.category_icon}</span>
                      <div>
                        <div className="font-medium">{stat.category_name}</div>
                        <div className="text-xs text-muted-foreground">
                          {stat.category_description}
                        </div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="secondary">{stat.total_jobs}</Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.pending_jobs > 0 ? (
                      <Badge variant="outline">{stat.pending_jobs}</Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.posted_jobs > 0 ? (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        {stat.posted_jobs}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.in_progress_jobs > 0 ? (
                      <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                        {stat.in_progress_jobs}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.completed_jobs > 0 ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {stat.completed_jobs}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    ${stat.total_pay_amount.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right">
                    ${Math.round(stat.avg_pay_amount).toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right">
                    {stat.avg_distance_miles > 0 
                      ? `${Math.round(stat.avg_distance_miles)} mi`
                      : '-'
                    }
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
