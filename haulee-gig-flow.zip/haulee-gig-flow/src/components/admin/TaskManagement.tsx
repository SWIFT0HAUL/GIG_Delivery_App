import React, { useState, useEffect } from 'react';
import { format } from 'date-fns';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Plus, Edit2, Trash2, Settings, Target, CheckCircle, XCircle, Users, ArrowRight, Calendar as CalendarIcon, Eye } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { cn } from '@/lib/utils';

interface CustomTask {
  id: string;
  name: string;
  description: string;
  category: string;
  required: boolean;
  created_by: string;
  created_at: string;
  updated_at: string;
  custom_link?: string;
  due_date?: string;
  redirect_path?: any[];
}

interface TaskAssignment {
  id: string;
  task_id: string;
  user_id: string;
  status: string;
  created_at: string;
  completed_at?: string;
  updated_at?: string;
  task?: CustomTask;
}

interface PredefinedTask {
  key: string;
  name: string;
  description: string;
  category: string;
  custom_link?: string;
}

const PREDEFINED_TASKS: PredefinedTask[] = [
  { key: 'task_background_check', name: 'Background Check', description: 'Complete background verification', category: 'verification' },
  { key: 'task_training', name: 'Training', description: 'Complete required training modules', category: 'training' },
  { key: 'task_contract_signing', name: 'Contract Signing', description: 'Sign legal agreements', category: 'documentation' },
  { key: 'task_terms_policy', name: 'Terms & Policy', description: 'Accept terms and policies', category: 'compliance' },
  { key: 'task_tutorial_videos', name: 'Tutorial Videos', description: 'Watch onboarding videos', category: 'training' },
];

export function TaskManagement({ applications, onTaskUpdate }: { applications: any[], onTaskUpdate: () => void }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [customTasks, setCustomTasks] = useState<CustomTask[]>([]);
  const [taskAssignments, setTaskAssignments] = useState<TaskAssignment[]>([]);
  const [predefinedTasks, setPredefinedTasks] = useState<PredefinedTask[]>(PREDEFINED_TASKS);
  const [loading, setLoading] = useState(true);
  const [editingTask, setEditingTask] = useState<CustomTask | null>(null);
  const [editingPredefined, setEditingPredefined] = useState<PredefinedTask | null>(null);
  const [creatingTask, setCreatingTask] = useState(false);
  const [dueDateOpen, setDueDateOpen] = useState(false);
  const [viewFormDialogOpen, setViewFormDialogOpen] = useState(false);
  const [viewingTask, setViewingTask] = useState<CustomTask | null>(null);
  const [taskData, setTaskData] = useState({
    name: '',
    description: '',
    category: 'general',
    required: false,
    custom_link: '',
    due_date: undefined as Date | undefined,
    redirect_path: [] as any[]
  });

  const [currentStep, setCurrentStep] = useState({
    step_number: 1,
    step_name: '',
    step_description: '',
    path: '',
    is_optional: false
  });

  const handleAddStep = () => {
    if (!currentStep.step_name.trim() || !currentStep.path.trim()) {
      toast({
        title: "Error",
        description: "Step name and path are required",
        variant: "destructive"
      });
      return;
    }
    const next = ([...(taskData.redirect_path || [])] as any[]).concat(currentStep);
    setTaskData(prev => ({ ...prev, redirect_path: next }));
    setCurrentStep({
      step_number: next.length + 1,
      step_name: '',
      step_description: '',
      path: '',
      is_optional: false
    });
  };

  const handleRemoveStep = (stepNumber: number) => {
    const updated = ((taskData.redirect_path || []) as any[])
      .filter((s: any) => s.step_number !== stepNumber)
      .map((s: any, idx: number) => ({ ...s, step_number: idx + 1 }));
    setTaskData(prev => ({ ...prev, redirect_path: updated }));
    setCurrentStep(prev => ({ ...prev, step_number: updated.length + 1 }));
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch custom tasks
      const { data: tasks, error: tasksError } = await supabase
        .from('custom_tasks')
        .select('*')
        .order('created_at', { ascending: false });

      if (tasksError) throw tasksError;
      setCustomTasks((tasks as any) || []);

      // Fetch task assignments
      const { data: assignments, error: assignmentsError } = await supabase
        .from('task_assignments')
        .select(`
          *,
          task:custom_tasks(*)
        `)
        .order('created_at', { ascending: false });

      if (assignmentsError) throw assignmentsError;
      setTaskAssignments((assignments as any) || []);
    } catch (error) {
      console.error('Error fetching task data:', error);
      toast({
        title: "Error",
        description: "Failed to fetch task data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateTask = async () => {
    if (!taskData.name.trim()) {
      toast({
        title: "Error",
        description: "Task name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('custom_tasks')
        .insert({
          name: taskData.name,
          description: taskData.description,
          category: taskData.category,
          required: taskData.required,
          custom_link: taskData.custom_link,
          due_date: taskData.due_date ? taskData.due_date.toISOString() : null,
          redirect_path: taskData.redirect_path,
          created_by: user?.id
        });

      if (error) throw error;

      resetForm();
      setCreatingTask(false);
      fetchData();
      onTaskUpdate();
      
      toast({
        title: "Success",
        description: "Task created successfully"
      });
    } catch (error) {
      console.error('Error creating task:', error);
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive"
      });
    }
  };

  const handleUpdateTask = async () => {
    if (!editingTask || !taskData.name.trim()) {
      toast({
        title: "Error",
        description: "Task name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('custom_tasks')
        .update({
          name: taskData.name,
          description: taskData.description,
          category: taskData.category,
          required: taskData.required,
          custom_link: taskData.custom_link,
          due_date: taskData.due_date ? taskData.due_date.toISOString() : null,
          redirect_path: taskData.redirect_path
        })
        .eq('id', editingTask.id);

      if (error) throw error;

      resetForm();
      setEditingTask(null);
      fetchData();
      onTaskUpdate();
      
      toast({
        title: "Success",
        description: "Task updated successfully"
      });
    } catch (error) {
      console.error('Error updating task:', error);
      toast({
        title: "Error",
        description: "Failed to update task",
        variant: "destructive"
      });
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    try {
      // First delete any assignments
      await supabase
        .from('task_assignments')
        .delete()
        .eq('task_id', taskId);

      // Then delete the task
      const { error } = await supabase
        .from('custom_tasks')
        .delete()
        .eq('id', taskId);

      if (error) throw error;

      fetchData();
      onTaskUpdate();
      
      toast({
        title: "Success",
        description: "Task deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting task:', error);
      toast({
        title: "Error",
        description: "Failed to delete task",
        variant: "destructive"
      });
    }
  };

  const handleAssignTask = async (taskId: string, userId: string, applicationType: string) => {
    try {
      const { error } = await supabase
        .from('task_assignments')
        .insert({
          task_id: taskId,
          user_id: userId,
          application_type: applicationType,
          assigned_by: user?.id,
          status: 'pending'
        });

      if (error) throw error;

      fetchData();
      onTaskUpdate();
      
      toast({
        title: "Success",
        description: "Task assigned successfully"
      });
    } catch (error) {
      console.error('Error assigning task:', error);
      toast({
        title: "Error",
        description: "Failed to assign task",
        variant: "destructive"
      });
    }
  };

  const handleUpdateAssignmentStatus = async (assignmentId: string, status: string) => {
    try {
      const { error } = await supabase
        .from('task_assignments')
        .update({ 
          status, 
          completed_at: status === 'completed' ? new Date().toISOString() : null 
        })
        .eq('id', assignmentId);

      if (error) throw error;

      fetchData();
      onTaskUpdate();
      
      toast({
        title: "Success",
        description: `Task ${status} successfully`
      });
    } catch (error) {
      console.error('Error updating assignment:', error);
      toast({
        title: "Error",
        description: "Failed to update task status",
        variant: "destructive"
      });
    }
  };

  const startEdit = (task: CustomTask) => {
    setEditingTask(task);
    setTaskData({
      name: task.name,
      description: task.description || '',
      category: task.category,
      required: task.required,
      custom_link: task.custom_link || '',
      due_date: task.due_date ? new Date(task.due_date) : undefined,
      redirect_path: (task.redirect_path as any) || []
    });
  };

  const resetForm = () => {
    setTaskData({
      name: '',
      description: '',
      category: 'general',
      required: false,
      custom_link: '',
      due_date: undefined,
      redirect_path: []
    });
    setEditingTask(null);
    setEditingPredefined(null);
    setCreatingTask(false);
  };

  const startEditPredefined = (task: PredefinedTask) => {
    setEditingPredefined(task);
    setTaskData({
      name: task.name,
      description: task.description || '',
      category: task.category,
      required: true, // predefined tasks are typically required
      custom_link: task.custom_link || '',
      due_date: undefined,
      redirect_path: []
    });
  };

  const handleUpdatePredefined = async () => {
    if (!editingPredefined || !taskData.name.trim()) {
      toast({
        title: "Error",
        description: "Task name is required",
        variant: "destructive"
      });
      return;
    }

    try {
      // Update the predefined task in state
      const updatedTasks = predefinedTasks.map(task => 
        task.key === editingPredefined.key 
          ? { ...task, ...taskData }
          : task
      );
      setPredefinedTasks(updatedTasks);

      resetForm();
      
      toast({
        title: "Success",
        description: "Predefined task updated successfully"
      });
    } catch (error) {
      console.error('Error updating predefined task:', error);
      toast({
        title: "Error",
        description: "Failed to update predefined task",
        variant: "destructive"
      });
    }
  };

  const handleDeletePredefined = (taskKey: string) => {
    try {
      const updatedTasks = predefinedTasks.filter(task => task.key !== taskKey);
      setPredefinedTasks(updatedTasks);
      
      toast({
        title: "Success",
        description: "Predefined task deleted successfully"
      });
    } catch (error) {
      console.error('Error deleting predefined task:', error);
      toast({
        title: "Error",
        description: "Failed to delete predefined task",
        variant: "destructive"
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return <Badge variant="default" className="bg-green-100 text-green-800"><CheckCircle className="h-3 w-3 mr-1" />Completed</Badge>;
      case 'pending':
        return <Badge variant="secondary">Pending</Badge>;
      case 'failed':
        return <Badge variant="destructive"><XCircle className="h-3 w-3 mr-1" />Failed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center p-8">Loading task management...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Task Management</h2>
          <p className="text-muted-foreground">Create, edit, and manage onboarding tasks</p>
        </div>
        <Button onClick={() => setCreatingTask(true)} className="flex items-center space-x-2">
          <Plus className="h-4 w-4" />
          <span>Create Task</span>
        </Button>
      </div>

      <Tabs defaultValue="custom" className="w-full">
        <TabsList>
          <TabsTrigger value="custom">Custom Tasks</TabsTrigger>
          <TabsTrigger value="predefined">Predefined Tasks</TabsTrigger>
          <TabsTrigger value="assignments">Task Assignments</TabsTrigger>
        </TabsList>

        <TabsContent value="custom" className="space-y-4">
          <div className="grid gap-4">
            {customTasks.length === 0 ? (
              <Card>
                <CardContent className="p-6 text-center">
                  <Target className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No custom tasks created yet</p>
                </CardContent>
              </Card>
            ) : (
              customTasks.map((task) => (
                <Card key={task.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold">{task.name}</h3>
                          <Badge variant="outline">{task.category}</Badge>
                          {task.required && <Badge variant="secondary">Required</Badge>}
                        </div>
                        {task.description && (
                          <p className="text-sm text-muted-foreground mb-2">{task.description}</p>
                        )}
                        {task.custom_link && (
                          <p className="text-sm text-blue-600 mb-2">
                            Link: <a href={task.custom_link} target="_blank" rel="noopener noreferrer" className="underline">{task.custom_link}</a>
                          </p>
                        )}
                        {task.redirect_path && Array.isArray(task.redirect_path) && task.redirect_path.length > 0 && (
                          <div className="mb-2">
                            <p className="text-xs font-semibold text-muted-foreground mb-1">Completion Path ({task.redirect_path.length} steps):</p>
                            <div className="flex flex-wrap gap-1">
                              {task.redirect_path.map((step: any, index: number) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {index + 1}. {step.step_name}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Created {new Date(task.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setViewingTask(task);
                            setViewFormDialogOpen(true);
                          }}
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View Form
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => startEdit(task)}
                        >
                          <Edit2 className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4 text-red-500" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Task</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete "{task.name}"? This will also remove all assignments for this task.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDeleteTask(task.id)}
                                className="bg-red-600 hover:bg-red-700"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="predefined" className="space-y-4">
          <div className="grid gap-4">
            {predefinedTasks.map((task) => (
              <Card key={task.key} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-2">
                        <h3 className="font-semibold">{task.name}</h3>
                        <Badge variant="outline">{task.category}</Badge>
                        <Badge variant="secondary">System</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{task.description}</p>
                      {task.custom_link && (
                        <p className="text-sm text-blue-600 mb-2">
                          Link: <a href={task.custom_link} target="_blank" rel="noopener noreferrer" className="underline">{task.custom_link}</a>
                        </p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        System-defined task • Customizable
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const fullTask = customTasks.find(t => t.name === task.name);
                          if (fullTask) {
                            setViewingTask(fullTask);
                            setViewFormDialogOpen(true);
                          } else {
                            toast({
                              title: "Info",
                              description: "This predefined task template has no additional form data",
                              variant: "default"
                            });
                          }
                        }}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => startEditPredefined(task)}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Predefined Task</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure you want to delete "{task.name}"? This will remove it from the system.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              onClick={() => handleDeletePredefined(task.key)}
                              className="bg-red-600 hover:bg-red-700"
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="assignments" className="space-y-4">
          <div className="grid gap-4">
            {taskAssignments.length === 0 ? (
              <Card>
                <CardContent className="p-6 text-center">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No task assignments yet</p>
                </CardContent>
              </Card>
            ) : (
              taskAssignments.map((assignment) => (
                <Card key={assignment.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold">{assignment.task?.name || 'Unknown Task'}</h3>
                          {getStatusBadge(assignment.status)}
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          Assigned to: {applications.find(app => app.user_id === assignment.user_id)?.full_name || 'Unknown User'}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Assigned {new Date(assignment.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        {assignment.status === 'pending' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleUpdateAssignmentStatus(assignment.id, 'completed')}
                          >
                            Mark Complete
                          </Button>
                        )}
                        {assignment.status === 'completed' && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleUpdateAssignmentStatus(assignment.id, 'pending')}
                          >
                            Mark Pending
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Create/Edit Task Dialog */}
      <Dialog open={creatingTask || !!editingTask || !!editingPredefined} onOpenChange={() => resetForm()}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Target className="h-5 w-5" />
              <span>
                {editingTask ? 'Edit Custom Task' : 
                 editingPredefined ? 'Edit Predefined Task' : 
                 'Create New Task'}
              </span>
            </DialogTitle>
            <DialogDescription>
              {editingTask ? 'Update custom task details' : 
               editingPredefined ? 'Customize predefined task' :
               'Create a new custom task for onboarding'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div>
              <Label htmlFor="taskName">Task Name*</Label>
              <Input
                id="taskName"
                placeholder="e.g., Document Verification"
                value={taskData.name}
                onChange={(e) => setTaskData(prev => ({ ...prev, name: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="taskDescription">Description</Label>
              <Textarea
                id="taskDescription"
                placeholder="Detailed description of the task..."
                value={taskData.description}
                onChange={(e) => setTaskData(prev => ({ ...prev, description: e.target.value }))}
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="taskLink">Custom Link</Label>
              <Input
                id="taskLink"
                placeholder="https://example.com/task-instructions"
                value={taskData.custom_link}
                onChange={(e) => setTaskData(prev => ({ ...prev, custom_link: e.target.value }))}
              />
            </div>

            <div>
              <Label htmlFor="dueDate">Due Date</Label>
              <Popover modal={false} open={dueDateOpen} onOpenChange={setDueDateOpen}>
                <PopoverTrigger asChild>
                  <Button
                    id="dueDate"
                    variant="outline"
                    type="button"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !taskData.due_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {taskData.due_date ? format(taskData.due_date, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start" sideOffset={4}>
                  <Calendar
                    mode="single"
                    selected={taskData.due_date}
                    onSelect={(date) => {
                      setTaskData(prev => ({ ...prev, due_date: date }));
                      setDueDateOpen(false);
                    }}
                    initialFocus
                    className="pointer-events-auto"
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <Label htmlFor="taskCategory">Category</Label>
              <Select value={taskData.category} onValueChange={(value) => setTaskData(prev => ({ ...prev, category: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">General</SelectItem>
                  <SelectItem value="documentation">Documentation</SelectItem>
                  <SelectItem value="verification">Verification</SelectItem>
                  <SelectItem value="training">Training</SelectItem>
                  <SelectItem value="compliance">Compliance</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="required"
                checked={taskData.required}
                onCheckedChange={(checked) => setTaskData(prev => ({ ...prev, required: checked }))}
              />
              <Label htmlFor="required">Required task</Label>
            </div>

            {/* Redirect Path Builder */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Task Completion Path</CardTitle>
                <CardDescription>
                  Define the step-by-step path users should follow to complete this task
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {Array.isArray(taskData.redirect_path) && taskData.redirect_path.length > 0 && (
                  <div className="space-y-2">
                    <Label>Configured Steps:</Label>
                    {(taskData.redirect_path as any[]).map((step: any) => (
                      <Card key={step.step_number} className="p-1 bg-muted/50">
                        <div className="flex items-start justify-between gap-1">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center space-x-1.5 mb-0.5">
                              <span className="font-semibold text-[10px]">Step {step.step_number}:</span>
                              <span className="text-[10px] truncate">{step.step_name}</span>
                              {step.is_optional && (
                                <span className="text-[9px] text-muted-foreground">(Optional)</span>
                              )}
                            </div>
                            <p className="text-[9px] text-muted-foreground mb-0.5 line-clamp-1">{step.step_description}</p>
                            <div className="flex items-center space-x-0.5 text-[9px] text-primary">
                              <ArrowRight className="h-2.5 w-2.5" />
                              <span className="truncate">{step.path}</span>
                            </div>
                          </div>
                          <Button variant="ghost" size="sm" className="h-5 w-5 p-0" onClick={() => handleRemoveStep(step.step_number)}>
                            <Trash2 className="h-3 w-3 text-red-500" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}

                <div className="space-y-3 pt-2 border-t">
                  <Label>Add Step {currentStep.step_number}:</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label htmlFor="stepName" className="text-xs">Step Name*</Label>
                      <Input id="stepName" placeholder="e.g., Complete Profile"
                        value={currentStep.step_name}
                        onChange={(e) => setCurrentStep(prev => ({ ...prev, step_name: e.target.value }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="stepPath" className="text-xs">Path/URL*</Label>
                      <Input id="stepPath" placeholder="e.g., /onboarding?step=1"
                        value={currentStep.path}
                        onChange={(e) => setCurrentStep(prev => ({ ...prev, path: e.target.value }))}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="stepDescription" className="text-xs">Description</Label>
                    <Textarea id="stepDescription" rows={2}
                      placeholder="Brief description of what user needs to do..."
                      value={currentStep.step_description}
                      onChange={(e) => setCurrentStep(prev => ({ ...prev, step_description: e.target.value }))}
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Switch id="stepOptional" checked={currentStep.is_optional}
                        onCheckedChange={(checked) => setCurrentStep(prev => ({ ...prev, is_optional: checked }))}
                      />
                      <Label htmlFor="stepOptional" className="text-xs">Optional Step</Label>
                    </div>
                    <Button type="button" variant="outline" size="sm" onClick={handleAddStep}>
                      <Plus className="h-3 w-3 mr-1" />
                      Add Step
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <Button variant="outline" onClick={resetForm}>
              Cancel
            </Button>
            <Button onClick={
              editingTask ? handleUpdateTask : 
              editingPredefined ? handleUpdatePredefined :
              handleCreateTask
            }>
              {editingTask ? 'Update Task' : 
               editingPredefined ? 'Update Task' :
               'Create Task'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Task Form Dialog */}
      <Dialog open={viewFormDialogOpen} onOpenChange={setViewFormDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-2">
              <Eye className="h-5 w-5" />
              <span>View Task Form: {viewingTask?.name}</span>
            </DialogTitle>
            <DialogDescription>
              Complete task details and configuration
            </DialogDescription>
          </DialogHeader>

          {viewingTask && (
            <div className="space-y-6">
              {/* Basic Information */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Basic Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <Label className="text-muted-foreground">Task Name</Label>
                    <p className="font-medium">{viewingTask.name}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Description</Label>
                    <p className="text-sm">{viewingTask.description || 'No description provided'}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-muted-foreground">Category</Label>
                      <Badge variant="outline" className="mt-1">{viewingTask.category}</Badge>
                    </div>
                    <div>
                      <Label className="text-muted-foreground">Required</Label>
                      <p className="text-sm">{viewingTask.required ? 'Yes' : 'No'}</p>
                    </div>
                  </div>
                  {viewingTask.due_date && (
                    <div>
                      <Label className="text-muted-foreground">Due Date</Label>
                      <p className="text-sm">{format(new Date(viewingTask.due_date), 'MMM dd, yyyy')}</p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Custom Link */}
              {viewingTask.custom_link && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ArrowRight className="h-4 w-4" />
                      Resource Link
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <a 
                      href={viewingTask.custom_link} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline break-all"
                    >
                      {viewingTask.custom_link}
                    </a>
                  </CardContent>
                </Card>
              )}

              {/* Completion Steps */}
              {viewingTask.redirect_path && Array.isArray(viewingTask.redirect_path) && viewingTask.redirect_path.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center gap-2">
                      <ArrowRight className="h-4 w-4" />
                      Task Completion Path ({viewingTask.redirect_path.length} Steps)
                    </CardTitle>
                    <CardDescription>
                      User will follow these steps to complete the task
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {viewingTask.redirect_path.map((step: any, index: number) => (
                        <Card key={index} className="bg-muted/50">
                          <CardContent className="p-4">
                            <div className="flex items-start gap-3">
                              <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-semibold">
                                {step.step_number || index + 1}
                              </div>
                              <div className="flex-1 space-y-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-semibold">{step.step_name}</h4>
                                  {step.is_optional && (
                                    <Badge variant="outline" className="text-xs">Optional</Badge>
                                  )}
                                </div>
                                {step.step_description && (
                                  <p className="text-sm text-muted-foreground">{step.step_description}</p>
                                )}
                                <div className="flex items-center gap-1 text-xs text-primary">
                                  <ArrowRight className="h-3 w-3" />
                                  <code className="bg-muted px-2 py-1 rounded">{step.path}</code>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Metadata */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Metadata</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Created:</span>
                    <span>{format(new Date(viewingTask.created_at), 'MMM dd, yyyy HH:mm')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last Updated:</span>
                    <span>{format(new Date(viewingTask.updated_at), 'MMM dd, yyyy HH:mm')}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setViewFormDialogOpen(false)}>
              Close
            </Button>
            <Button onClick={() => {
              if (viewingTask) {
                setViewFormDialogOpen(false);
                startEdit(viewingTask);
              }
            }}>
              <Edit2 className="h-4 w-4 mr-2" />
              Edit Task
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}