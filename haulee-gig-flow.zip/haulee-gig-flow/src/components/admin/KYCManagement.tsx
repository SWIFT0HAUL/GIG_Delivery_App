import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { CheckCircle, XCircle, Clock, Eye, FileText, AlertTriangle, Shield, Download, Search, Filter } from 'lucide-react';
import { format } from 'date-fns';

interface KYCSubmission {
  id: string;
  user_id: string;
  government_id_path: string;
  proof_of_address_path: string;
  selfie_path: string | null;
  status: string;
  submitted_at: string;
  reviewed_at: string | null;
  reviewed_by: string | null;
  rejection_reason: string | null;
  admin_notes: string | null;
  profiles: {
    full_name: string;
    email: string;
  };
}

export function KYCManagement() {
  const { toast } = useToast();
  const [submissions, setSubmissions] = useState<KYCSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSubmission, setSelectedSubmission] = useState<KYCSubmission | null>(null);
  const [reviewAction, setReviewAction] = useState<'approve' | 'reject' | 'more_info' | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    fetchSubmissions();
  }, [statusFilter]);

  // Subscribe to realtime changes so new submissions appear without manual refresh
  useEffect(() => {
    const channel = supabase
      .channel('kyc-submissions-realtime')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'kyc_submissions' }, () => {
        fetchSubmissions();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchSubmissions = async () => {
    try {
      setLoading(true);
      console.log('Fetching KYC submissions with status filter:', statusFilter);
      
      // First, fetch KYC submissions
      let query = supabase
        .from('kyc_submissions' as any)
        .select('*')
        .order('submitted_at', { ascending: false });

      if (statusFilter !== 'all') {
        query = query.eq('status', statusFilter);
      }

      const { data: kycData, error: kycError } = await query;

      if (kycError) {
        console.error('KYC submissions query error:', kycError);
        throw kycError;
      }

      console.log('Fetched KYC submissions:', kycData?.length || 0);

      // Then fetch user profiles separately
      if (kycData && kycData.length > 0) {
        const userIds = kycData.map((sub: any) => sub.user_id);
        const { data: profilesData, error: profilesError } = await supabase
          .from('profiles')
          .select('id, full_name, email')
          .in('id', userIds);

        if (profilesError) {
          console.error('Profiles query error:', profilesError);
          // Continue even if profiles fail
        }

        console.log('Fetched profiles:', profilesData?.length || 0);

        // Merge the data
        const mergedData = kycData.map((submission: any) => {
          const profile = profilesData?.find((p: any) => p.id === submission.user_id);
          return {
            ...submission,
            profiles: profile || { full_name: 'Unknown', email: 'Unknown' }
          };
        });

        setSubmissions(mergedData);
      } else {
        setSubmissions([]);
      }
    } catch (error: any) {
      console.error('Error fetching KYC submissions:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to load KYC submissions",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleReview = async () => {
    if (!selectedSubmission || !reviewAction) return;

    try {
      const updates: any = {
        status: reviewAction === 'approve' ? 'approved' : reviewAction === 'reject' ? 'rejected' : 'more_info_needed',
        reviewed_at: new Date().toISOString(),
        admin_notes: adminNotes
      };

      if (reviewAction === 'reject') {
        updates.rejection_reason = rejectionReason;
      }

      const { error: updateError } = await supabase
        .from('kyc_submissions' as any)
        .update(updates)
        .eq('id', selectedSubmission.id);

      if (updateError) throw updateError;

      // Update profile KYC status
      if (reviewAction === 'approve') {
        await supabase
          .from('profiles' as any)
          .update({ kyc_status: 'approved', kyc_verified: true } as any)
          .eq('id', selectedSubmission.user_id);
      }

      toast({
        title: "Review Submitted",
        description: `KYC submission has been ${reviewAction === 'approve' ? 'approved' : reviewAction === 'reject' ? 'rejected' : 'marked for more information'}`
      });

      setSelectedSubmission(null);
      setReviewAction(null);
      setRejectionReason('');
      setAdminNotes('');
      fetchSubmissions();
    } catch (error) {
      console.error('Error reviewing KYC:', error);
      toast({
        title: "Error",
        description: "Failed to submit review",
        variant: "destructive"
      });
    }
  };

  const downloadDocument = async (path: string) => {
    try {
      const { data, error } = await supabase.storage
        .from(path.split('/')[0])
        .download(path.split('/').slice(1).join('/'));

      if (error) throw error;

      const url = URL.createObjectURL(data);
      const a = document.createElement('a');
      a.href = url;
      a.download = path.split('/').pop() || 'document';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error downloading document:', error);
      toast({
        title: "Error",
        description: "Failed to download document",
        variant: "destructive"
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><CheckCircle className="w-3 h-3 mr-1" />Approved</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'more_info_needed':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200"><AlertTriangle className="w-3 h-3 mr-1" />More Info Needed</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const filteredSubmissions = submissions.filter(sub => {
    if (!searchQuery) return true;
    const searchLower = searchQuery.toLowerCase();
    return (
      sub.profiles?.full_name?.toLowerCase().includes(searchLower) ||
      sub.profiles?.email?.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Shield className="h-6 w-6" />
                KYC Verification Management
              </CardTitle>
              <CardDescription>
                Review and manage user identity verification submissions
              </CardDescription>
            </div>
            <Button onClick={fetchSubmissions} variant="outline" size="sm">
              <Filter className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search by name or email..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Status Filter</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="approved">Approved</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                  <SelectItem value="more_info_needed">More Info Needed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Pending Review</CardDescription>
            <CardTitle className="text-3xl text-yellow-600">
              {submissions.filter(s => s.status === 'pending').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Approved</CardDescription>
            <CardTitle className="text-3xl text-green-600">
              {submissions.filter(s => s.status === 'approved').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Rejected</CardDescription>
            <CardTitle className="text-3xl text-red-600">
              {submissions.filter(s => s.status === 'rejected').length}
            </CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>More Info Needed</CardDescription>
            <CardTitle className="text-3xl text-blue-600">
              {submissions.filter(s => s.status === 'more_info_needed').length}
            </CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Submissions List */}
      <Card>
        <CardHeader>
          <CardTitle>KYC Submissions</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center py-8 text-muted-foreground">Loading submissions...</div>
          ) : filteredSubmissions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">No KYC submissions found</div>
          ) : (
            <div className="space-y-4">
              {filteredSubmissions.map((submission) => (
                <Card key={submission.id} className="hover:border-primary/50 transition-colors">
                  <CardContent className="pt-6">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-3">
                          <h3 className="font-semibold">{submission.profiles?.full_name || 'Unknown User'}</h3>
                          {getStatusBadge(submission.status)}
                        </div>
                        <p className="text-sm text-muted-foreground">{submission.profiles?.email}</p>
                        <p className="text-xs text-muted-foreground">
                          Submitted: {format(new Date(submission.submitted_at), 'PPP')}
                        </p>
                        {submission.reviewed_at && (
                          <p className="text-xs text-muted-foreground">
                            Reviewed: {format(new Date(submission.reviewed_at), 'PPP')}
                          </p>
                        )}
                      </div>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => setSelectedSubmission(submission)}
                          >
                            <Eye className="w-4 h-4 mr-2" />
                            Review
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>Review KYC Submission</DialogTitle>
                            <DialogDescription>
                              Review documents and approve or reject this submission
                            </DialogDescription>
                          </DialogHeader>

                          {selectedSubmission && (
                            <div className="space-y-6">
                              {/* User Info */}
                              <div className="space-y-2">
                                <h4 className="font-semibold">User Information</h4>
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <p className="text-muted-foreground">Name</p>
                                    <p className="font-medium">{selectedSubmission.profiles?.full_name}</p>
                                  </div>
                                  <div>
                                    <p className="text-muted-foreground">Email</p>
                                    <p className="font-medium">{selectedSubmission.profiles?.email}</p>
                                  </div>
                                </div>
                              </div>

                              {/* Documents */}
                              <div className="space-y-3">
                                <h4 className="font-semibold">Submitted Documents</h4>
                                <div className="grid grid-cols-1 gap-3">
                                  <div className="flex items-center justify-between p-3 border rounded-lg">
                                    <div className="flex items-center gap-2">
                                      <FileText className="h-4 w-4" />
                                      <span className="text-sm">Government ID</span>
                                    </div>
                                    <Button 
                                      size="sm" 
                                      variant="ghost"
                                      onClick={() => downloadDocument(selectedSubmission.government_id_path)}
                                    >
                                      <Download className="h-4 w-4" />
                                    </Button>
                                  </div>
                                  <div className="flex items-center justify-between p-3 border rounded-lg">
                                    <div className="flex items-center gap-2">
                                      <FileText className="h-4 w-4" />
                                      <span className="text-sm">Proof of Address</span>
                                    </div>
                                    <Button 
                                      size="sm" 
                                      variant="ghost"
                                      onClick={() => downloadDocument(selectedSubmission.proof_of_address_path)}
                                    >
                                      <Download className="h-4 w-4" />
                                    </Button>
                                  </div>
                                  {selectedSubmission.selfie_path && (
                                    <div className="flex items-center justify-between p-3 border rounded-lg">
                                      <div className="flex items-center gap-2">
                                        <FileText className="h-4 w-4" />
                                        <span className="text-sm">Selfie</span>
                                      </div>
                                      <Button 
                                        size="sm" 
                                        variant="ghost"
                                        onClick={() => downloadDocument(selectedSubmission.selfie_path!)}
                                      >
                                        <Download className="h-4 w-4" />
                                      </Button>
                                    </div>
                                  )}
                                </div>
                              </div>

                              {/* Previous Review Info */}
                              {selectedSubmission.admin_notes && (
                                <Alert>
                                  <AlertDescription>
                                    <strong>Previous Notes:</strong> {selectedSubmission.admin_notes}
                                  </AlertDescription>
                                </Alert>
                              )}

                              {/* Review Actions */}
                              {selectedSubmission.status === 'pending' || selectedSubmission.status === 'more_info_needed' ? (
                                <div className="space-y-4">
                                  <div className="space-y-2">
                                    <Label>Review Action</Label>
                                    <Select value={reviewAction || ''} onValueChange={(val) => setReviewAction(val as any)}>
                                      <SelectTrigger>
                                        <SelectValue placeholder="Select action" />
                                      </SelectTrigger>
                                      <SelectContent>
                                        <SelectItem value="approve">Approve</SelectItem>
                                        <SelectItem value="reject">Reject</SelectItem>
                                        <SelectItem value="more_info">Request More Information</SelectItem>
                                      </SelectContent>
                                    </Select>
                                  </div>

                                  {reviewAction === 'reject' && (
                                    <div className="space-y-2">
                                      <Label>Rejection Reason *</Label>
                                      <Textarea
                                        placeholder="Provide a clear reason for rejection..."
                                        value={rejectionReason}
                                        onChange={(e) => setRejectionReason(e.target.value)}
                                        rows={3}
                                      />
                                    </div>
                                  )}

                                  <div className="space-y-2">
                                    <Label>Admin Notes (Optional)</Label>
                                    <Textarea
                                      placeholder="Add any internal notes..."
                                      value={adminNotes}
                                      onChange={(e) => setAdminNotes(e.target.value)}
                                      rows={3}
                                    />
                                  </div>

                                  <div className="flex justify-end gap-2">
                                    <Button variant="outline" onClick={() => setSelectedSubmission(null)}>
                                      Cancel
                                    </Button>
                                    <Button 
                                      onClick={handleReview}
                                      disabled={!reviewAction || (reviewAction === 'reject' && !rejectionReason)}
                                    >
                                      Submit Review
                                    </Button>
                                  </div>
                                </div>
                              ) : (
                                <Alert>
                                  <AlertDescription>
                                    This submission has already been reviewed and is {selectedSubmission.status}.
                                  </AlertDescription>
                                </Alert>
                              )}
                            </div>
                          )}
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
