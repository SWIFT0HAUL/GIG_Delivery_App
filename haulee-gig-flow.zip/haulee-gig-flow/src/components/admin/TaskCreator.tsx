import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Target, Trash2, ArrowRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface RedirectStep {
  step_number: number;
  step_name: string;
  step_description: string;
  path: string;
  is_optional: boolean;
}

interface TaskCreatorProps {
  onTaskCreated: () => void;
  applications: any[];
}

export function TaskCreator({ onTaskCreated, applications }: TaskCreatorProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [taskData, setTaskData] = useState({
    name: '',
    description: '',
    category: 'general',
    required: false
  });
  const [assignToApplication, setAssignToApplication] = useState('');
  const [applicationType, setApplicationType] = useState('');
  const [redirectSteps, setRedirectSteps] = useState<RedirectStep[]>([]);
  const [currentStep, setCurrentStep] = useState<RedirectStep>({
    step_number: 1,
    step_name: '',
    step_description: '',
    path: '',
    is_optional: false
  });

  const handleCreateTask = async () => {
    if (!taskData.name.trim()) {
      toast({
        title: "Error",
        description: "Task name is required",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Create the custom task with redirect path
      const { data: taskResult, error: taskError } = await supabase
        .from('custom_tasks')
        .insert([{
          name: taskData.name,
          description: taskData.description,
          category: taskData.category,
          required: taskData.required,
          redirect_path: redirectSteps as any,
          created_by: user?.id
        }])
        .select()
        .single();

      if (taskError) throw taskError;

      // If assigned to a specific application, create assignment
      if (assignToApplication && applicationType && taskResult) {
        const { error: assignmentError } = await supabase
          .from('task_assignments')
          .insert({
            task_id: taskResult.id,
            user_id: assignToApplication,
            application_type: applicationType,
            assigned_by: user?.id,
            status: 'pending'
          });

        if (assignmentError) throw assignmentError;
      }

      // Reset form
      setTaskData({ name: '', description: '', category: 'general', required: false });
      setAssignToApplication('');
      setApplicationType('');
      setRedirectSteps([]);
      setCurrentStep({
        step_number: 1,
        step_name: '',
        step_description: '',
        path: '',
        is_optional: false
      });
      setOpen(false);
      
      onTaskCreated();
      
      toast({
        title: "Success",
        description: "Task created successfully",
        variant: "default"
      });
    } catch (error) {
      console.error('Error creating task:', error);
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddStep = () => {
    if (!currentStep.step_name.trim() || !currentStep.path.trim()) {
      toast({
        title: "Error",
        description: "Step name and path are required",
        variant: "destructive"
      });
      return;
    }

    setRedirectSteps([...redirectSteps, currentStep]);
    setCurrentStep({
      step_number: redirectSteps.length + 2,
      step_name: '',
      step_description: '',
      path: '',
      is_optional: false
    });
  };

  const handleRemoveStep = (stepNumber: number) => {
    const updatedSteps = redirectSteps
      .filter(step => step.step_number !== stepNumber)
      .map((step, index) => ({ ...step, step_number: index + 1 }));
    setRedirectSteps(updatedSteps);
    setCurrentStep(prev => ({ ...prev, step_number: updatedSteps.length + 1 }));
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex items-center space-x-2">
          <Plus className="h-4 w-4" />
          <span>Create Custom Task</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Target className="h-5 w-5" />
            <span>Create Custom Task</span>
          </DialogTitle>
          <DialogDescription>
            Create a new task with step-by-step redirect path template
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label htmlFor="taskName">Task Name*</Label>
            <Input
              id="taskName"
              placeholder="e.g., Document Verification"
              value={taskData.name}
              onChange={(e) => setTaskData(prev => ({ ...prev, name: e.target.value }))}
            />
          </div>

          <div>
            <Label htmlFor="taskDescription">Description</Label>
            <Textarea
              id="taskDescription"
              placeholder="Detailed description of the task..."
              value={taskData.description}
              onChange={(e) => setTaskData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="taskCategory">Category</Label>
            <Select value={taskData.category} onValueChange={(value) => setTaskData(prev => ({ ...prev, category: value }))}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="documentation">Documentation</SelectItem>
                <SelectItem value="verification">Verification</SelectItem>
                <SelectItem value="training">Training</SelectItem>
                <SelectItem value="compliance">Compliance</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="required"
              checked={taskData.required}
              onCheckedChange={(checked) => setTaskData(prev => ({ ...prev, required: checked }))}
            />
            <Label htmlFor="required">Required task</Label>
          </div>

          <div>
            <Label>Assign to Application (Optional)</Label>
            <div className="space-y-2">
              <Select value={applicationType} onValueChange={setApplicationType}>
                <SelectTrigger>
                  <SelectValue placeholder="Select application type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="driver">Driver</SelectItem>
                  <SelectItem value="vendor_merchant">Vendor/Merchant</SelectItem>
                  <SelectItem value="shipper">Shipper</SelectItem>
                  <SelectItem value="broker">Broker</SelectItem>
                  <SelectItem value="carrier">Carrier</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>

              {applicationType && (
                <Select value={assignToApplication} onValueChange={setAssignToApplication}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select specific application" />
                  </SelectTrigger>
                  <SelectContent>
                    {applications
                      .filter(app => app.type === applicationType)
                      .map(app => (
                        <SelectItem key={app.id} value={app.user_id}>
                          {app.full_name} ({app.email})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </div>

          {/* Redirect Path Builder */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Task Completion Path</CardTitle>
              <CardDescription>
                Define step-by-step redirect path users will follow to complete this task
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Display existing steps */}
              {redirectSteps.length > 0 && (
                <div className="space-y-2">
                  <Label>Configured Steps:</Label>
                  {redirectSteps.map((step) => (
                    <Card key={step.step_number} className="p-1 bg-muted/50">
                      <div className="flex items-start justify-between gap-1">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-1.5 mb-0.5">
                            <span className="font-semibold text-[10px]">Step {step.step_number}:</span>
                            <span className="text-[10px] truncate">{step.step_name}</span>
                            {step.is_optional && (
                              <span className="text-[9px] text-muted-foreground">(Optional)</span>
                            )}
                          </div>
                          <p className="text-[9px] text-muted-foreground mb-0.5 line-clamp-1">{step.step_description}</p>
                          <div className="flex items-center space-x-0.5 text-[9px] text-primary">
                            <ArrowRight className="h-2.5 w-2.5" />
                            <span className="truncate">{step.path}</span>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-5 w-5 p-0"
                          onClick={() => handleRemoveStep(step.step_number)}
                        >
                          <Trash2 className="h-3 w-3 text-red-500" />
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              )}

              {/* Add new step form */}
              <div className="space-y-3 pt-2 border-t">
                <Label>Add Step {currentStep.step_number}:</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="stepName" className="text-xs">Step Name*</Label>
                    <Input
                      id="stepName"
                      placeholder="e.g., Complete Profile"
                      value={currentStep.step_name}
                      onChange={(e) => setCurrentStep(prev => ({ ...prev, step_name: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="stepPath" className="text-xs">Path/URL*</Label>
                    <Input
                      id="stepPath"
                      placeholder="e.g., /onboarding?step=1"
                      value={currentStep.path}
                      onChange={(e) => setCurrentStep(prev => ({ ...prev, path: e.target.value }))}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="stepDescription" className="text-xs">Description</Label>
                  <Textarea
                    id="stepDescription"
                    placeholder="Brief description of what user needs to do..."
                    value={currentStep.step_description}
                    onChange={(e) => setCurrentStep(prev => ({ ...prev, step_description: e.target.value }))}
                    rows={2}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Switch
                      id="stepOptional"
                      checked={currentStep.is_optional}
                      onCheckedChange={(checked) => setCurrentStep(prev => ({ ...prev, is_optional: checked }))}
                    />
                    <Label htmlFor="stepOptional" className="text-xs">Optional Step</Label>
                  </div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleAddStep}
                  >
                    <Plus className="h-3 w-3 mr-1" />
                    Add Step
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-end space-x-2 pt-4">
          <Button variant="outline" onClick={() => setOpen(false)} disabled={loading}>
            Cancel
          </Button>
          <Button onClick={handleCreateTask} disabled={loading}>
            {loading ? 'Creating...' : 'Create Task'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}