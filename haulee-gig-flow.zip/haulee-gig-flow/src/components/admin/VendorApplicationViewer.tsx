import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';

export function VendorApplicationViewer() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Vendor Application Viewer</CardTitle>
      </CardHeader>
      <CardContent>
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            Vendor application viewer is currently being updated to match the new database schema.
            Please check back later or contact support for vendor information.
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
