import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

interface TimesheetEntry {
  id: string;
  clock_in: string;
  clock_out: string | null;
  total_duration: number | null;
  status: string;
  manual_entry: boolean;
  manual_entry_reason: string | null;
  notes: string | null;
  approved_by: string | null;
  approved_at: string | null;
  last_activity: string | null;
  rejection_reason: string | null;
  adjustment_reason: string | null;
  is_archived: boolean;
  activity_count: number;
  admin_id: string;
}

interface TimesheetAnalyticsProps {
  timesheets: TimesheetEntry[];
}

export function TimesheetAnalytics({ timesheets }: TimesheetAnalyticsProps) {
  // Prepare data for charts
  const dailyHours = timesheets
    .filter(t => t.total_duration)
    .reduce((acc: any, entry) => {
      const date = new Date(entry.clock_in).toLocaleDateString();
      if (!acc[date]) {
        acc[date] = { date, hours: 0, overtime: 0 };
      }
      acc[date].hours += parseFloat(entry.total_duration?.toString() || '0');
      acc[date].overtime += Math.max(0, parseFloat(entry.total_duration?.toString() || '0') - 8);
      return acc;
    }, {});

  const dailyData = Object.values(dailyHours).slice(-14); // Last 14 days

  const statusData = timesheets.reduce((acc: any, entry) => {
    const status = entry.status || 'unknown';
    acc[status] = (acc[status] || 0) + 1;
    return acc;
  }, {});

  const statusChartData = Object.entries(statusData).map(([name, value]) => ({ name, value }));

  const COLORS: Record<string, string> = {
    approved: '#10b981',
    completed: '#3b82f6',
    pending: '#f59e0b',
    pending_approval: '#f59e0b',
    rejected: '#ef4444',
    auto_timeout: '#6b7280',
    active: '#8b5cf6',
  };

  return (
    <div className="space-y-6">
      {/* Daily Hours Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Work Hours (Last 14 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={dailyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="hours" stroke="#3b82f6" strokeWidth={2} name="Total Hours" />
              <Line type="monotone" dataKey="overtime" stroke="#ef4444" strokeWidth={2} name="Overtime" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hours Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Hours Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={dailyData.slice(-7)}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="hours" fill="#3b82f6" name="Hours" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Status Breakdown */}
        <Card>
          <CardHeader>
            <CardTitle>Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={statusChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[entry.name as keyof typeof COLORS] || '#6b7280'} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
