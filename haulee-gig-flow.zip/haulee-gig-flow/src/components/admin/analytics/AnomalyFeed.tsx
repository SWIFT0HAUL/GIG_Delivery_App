import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { DateRange } from 'react-day-picker';
import { AlertTriangle, CheckCircle, Clock, XCircle } from 'lucide-react';
import { format } from 'date-fns';

interface AnomalyFeedProps {
  dateRange: DateRange;
}

interface Anomaly {
  id: string;
  type: string;
  severity: string;
  description: string;
  adminName: string;
  detectedAt: string;
  resolved: boolean;
  thresholdValue?: number;
  actualValue?: number;
}

export function AnomalyFeed({ dateRange }: AnomalyFeedProps) {
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'resolved' | 'unresolved'>('all');

  useEffect(() => {
    fetchAnomalies();
  }, [dateRange, filter]);

  const fetchAnomalies = async () => {
    try {
      setLoading(true);
      
      let query = supabase
        .from('timesheet_anomalies' as any)
        .select(`
          *,
          profiles:admin_id (full_name)
        `)
        .gte('detected_at', dateRange.from?.toISOString())
        .lte('detected_at', dateRange.to?.toISOString())
        .order('detected_at', { ascending: false });

      if (filter === 'resolved') {
        query = query.eq('resolved', true);
      } else if (filter === 'unresolved') {
        query = query.eq('resolved', false);
      }

      const { data, error } = await query;

      if (error) throw error;

      const mappedAnomalies: Anomaly[] = (data || []).map((item: any) => ({
        id: item.id,
        type: item.anomaly_type,
        severity: item.severity,
        description: item.description,
        adminName: item.profiles?.full_name || 'Unknown Admin',
        detectedAt: item.detected_at,
        resolved: item.resolved,
        thresholdValue: item.threshold_value,
        actualValue: item.actual_value
      }));

      setAnomalies(mappedAnomalies);
    } catch (error) {
      console.error('Error fetching anomalies:', error);
      // Mock data for demo
      setAnomalies([
        {
          id: '1',
          type: 'EXCESSIVE_DURATION',
          severity: 'high',
          description: 'Session duration significantly exceeds average',
          adminName: 'John Admin',
          detectedAt: new Date().toISOString(),
          resolved: false,
          thresholdValue: 12,
          actualValue: 18.5
        },
        {
          id: '2',
          type: 'HIGH_IDLE_RATIO',
          severity: 'medium',
          description: 'High proportion of idle time detected',
          adminName: 'Sarah Manager',
          detectedAt: new Date(Date.now() - 86400000).toISOString(),
          resolved: false,
          thresholdValue: 40,
          actualValue: 65
        },
        {
          id: '3',
          type: 'SHORT_DURATION',
          severity: 'low',
          description: 'Session duration is unusually short',
          adminName: 'Mike Supervisor',
          detectedAt: new Date(Date.now() - 172800000).toISOString(),
          resolved: true,
          thresholdValue: 0.1,
          actualValue: 0.05
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high': return <AlertTriangle className="h-5 w-5 text-red-600" />;
      case 'medium': return <AlertTriangle className="h-5 w-5 text-orange-600" />;
      case 'low': return <Clock className="h-5 w-5 text-yellow-600" />;
      default: return <AlertTriangle className="h-5 w-5" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'medium': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      case 'low': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleResolve = async (id: string) => {
    try {
      const { error } = await supabase
        .from('timesheet_anomalies' as any)
        .update({ resolved: true, resolved_at: new Date().toISOString() } as any)
        .eq('id', id);

      if (error) throw error;
      
      fetchAnomalies();
    } catch (error) {
      console.error('Error resolving anomaly:', error);
    }
  };

  const filteredAnomalies = anomalies.filter(a => {
    if (filter === 'resolved') return a.resolved;
    if (filter === 'unresolved') return !a.resolved;
    return true;
  });

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Anomaly Detection Feed
            </CardTitle>
            <CardDescription>
              Flagged sessions and unusual patterns
            </CardDescription>
          </div>

          <div className="flex gap-2">
            <Button
              variant={filter === 'all' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('all')}
            >
              All
            </Button>
            <Button
              variant={filter === 'unresolved' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('unresolved')}
            >
              Unresolved
            </Button>
            <Button
              variant={filter === 'resolved' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setFilter('resolved')}
            >
              Resolved
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading anomalies...</p>
          </div>
        ) : filteredAnomalies.length === 0 ? (
          <div className="h-[200px] flex flex-col items-center justify-center text-center">
            <CheckCircle className="h-12 w-12 text-green-600 mb-2" />
            <p className="font-medium">No anomalies detected</p>
            <p className="text-sm text-muted-foreground">All timesheet data looks normal</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[500px] overflow-y-auto">
            {filteredAnomalies.map((anomaly) => (
              <div 
                key={anomaly.id}
                className={`p-4 rounded-lg border ${anomaly.resolved ? 'opacity-60' : ''}`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {anomaly.resolved ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      getSeverityIcon(anomaly.severity)
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <Badge className={getSeverityColor(anomaly.severity)}>
                        {anomaly.severity.toUpperCase()}
                      </Badge>
                      <Badge variant="outline">{anomaly.type.replace(/_/g, ' ')}</Badge>
                      {anomaly.resolved && (
                        <Badge variant="outline" className="bg-green-50 text-green-700">
                          Resolved
                        </Badge>
                      )}
                    </div>

                    <p className="font-medium mb-1">{anomaly.adminName}</p>
                    <p className="text-sm text-muted-foreground mb-2">
                      {anomaly.description}
                    </p>

                    {anomaly.thresholdValue !== undefined && anomaly.actualValue !== undefined && (
                      <div className="text-xs text-muted-foreground">
                        Threshold: {anomaly.thresholdValue}h | Actual: {anomaly.actualValue}h
                      </div>
                    )}

                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-muted-foreground">
                        {format(new Date(anomaly.detectedAt), 'MMM dd, yyyy HH:mm')}
                      </span>

                      {!anomaly.resolved && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleResolve(anomaly.id)}
                        >
                          Mark Resolved
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
