import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, TrendingUp, AlertCircle, CheckCircle, Timer, Activity } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { DateRange } from 'react-day-picker';

interface AnalyticsOverviewCardsProps {
  dateRange: DateRange;
}

export function AnalyticsOverviewCards({ dateRange }: AnalyticsOverviewCardsProps) {
  const [metrics, setMetrics] = useState({
    totalHours: 0,
    avgDailyHours: 0,
    overtimeHours: 0,
    idlePercentage: 0,
    pendingApprovals: 0,
    utilizationRate: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMetrics();
  }, [dateRange]);

  const fetchMetrics = async () => {
    try {
      setLoading(true);
      
      // Fetch timesheets in date range
      const { data: timesheets, error } = await supabase
        .from('timesheets')
        .select('*')
        .gte('clock_in', dateRange.from?.toISOString())
        .lte('clock_in', dateRange.to?.toISOString())
        .neq('status', 'rejected');

      if (error) throw error;

      // Calculate metrics
      const totalHours = timesheets?.reduce((sum, t) => sum + (t.total_duration || 0), 0) || 0;
      const dayCount = Math.max(1, Math.ceil((dateRange.to!.getTime() - dateRange.from!.getTime()) / (1000 * 60 * 60 * 24)));
      const avgDailyHours = totalHours / dayCount;
      
      // Get pending approvals
      const { count: pendingCount } = await supabase
        .from('timesheets')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'pending')
        .eq('manual_entry', true);

      setMetrics({
        totalHours,
        avgDailyHours,
        overtimeHours: Math.max(0, totalHours - (dayCount * 8)), // Assuming 8hr standard
        idlePercentage: 15, // Will be calculated from activity logs
        pendingApprovals: pendingCount || 0,
        utilizationRate: 75 // Will be calculated from activity vs total time
      });
    } catch (error) {
      console.error('Error fetching metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const cards = [
    {
      title: 'Total Hours',
      value: `${metrics.totalHours.toFixed(1)}h`,
      change: '+12.5%',
      changePositive: true,
      icon: Clock,
      color: 'text-blue-600'
    },
    {
      title: 'Avg Daily Hours',
      value: `${metrics.avgDailyHours.toFixed(1)}h`,
      change: '+0.5h',
      changePositive: true,
      icon: Activity,
      color: 'text-green-600'
    },
    {
      title: 'Overtime Hours',
      value: `${metrics.overtimeHours.toFixed(1)}h`,
      change: '+8.2%',
      changePositive: false,
      icon: AlertCircle,
      color: 'text-orange-600'
    },
    {
      title: 'Idle Time',
      value: `${metrics.idlePercentage}%`,
      change: '-2.1%',
      changePositive: true,
      icon: Timer,
      color: 'text-purple-600'
    },
    {
      title: 'Pending Approvals',
      value: metrics.pendingApprovals,
      change: `${metrics.pendingApprovals} items`,
      changePositive: null,
      icon: CheckCircle,
      color: 'text-yellow-600'
    },
    {
      title: 'Utilization Rate',
      value: `${metrics.utilizationRate}%`,
      change: '+3.4%',
      changePositive: true,
      icon: TrendingUp,
      color: 'text-emerald-600'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              {card.title}
            </CardTitle>
            <card.icon className={`h-4 w-4 ${card.color}`} />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{loading ? '...' : card.value}</div>
            <p className={`text-xs ${
              card.changePositive === null ? 'text-muted-foreground' :
              card.changePositive ? 'text-green-600' : 'text-red-600'
            }`}>
              {card.change}
            </p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
