import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { DateRange } from 'react-day-picker';
import { Package } from 'lucide-react';

interface ActivityBreakdownChartProps {
  dateRange: DateRange;
  showDetailed?: boolean;
}

export function ActivityBreakdownChart({ dateRange, showDetailed }: ActivityBreakdownChartProps) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchActivityData();
  }, [dateRange]);

  const fetchActivityData = async () => {
    try {
      setLoading(true);
      
      // Fetch activity logs
      const { data: activities, error } = await supabase
        .from('user_activity_logs')
        .select('activity_type')
        .gte('created_at', dateRange.from?.toISOString())
        .lte('created_at', dateRange.to?.toISOString());

      if (error) throw error;

      // Group by activity type
      const activityCounts = activities?.reduce((acc, activity) => {
        const type = activity.activity_type || 'Other';
        acc[type] = (acc[type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>) || {};

      // Map to common categories
      const categoryMap: Record<string, string> = {
        'TASK_COMPLETED': 'Tasks',
        'APPROVAL_PROCESSED': 'Approvals',
        'DOCUMENT_REVIEWED': 'Documents',
        'USER_UPDATED': 'User Management',
        'LOGIN': 'Authentication',
      };

      const categorized = Object.entries(activityCounts).reduce((acc, [type, count]) => {
        const category = categoryMap[type] || 'Other';
        acc[category] = (acc[category] || 0) + count;
        return acc;
      }, {} as Record<string, number>);

      const chartData = Object.entries(categorized).map(([name, value]) => ({
        name,
        value,
        percentage: 0 // Will be calculated after
      }));

      // Calculate percentages
      const total = chartData.reduce((sum, item) => sum + item.value, 0);
      chartData.forEach(item => {
        item.percentage = total > 0 ? (item.value / total * 100) : 0;
      });

      setData(chartData.sort((a, b) => b.value - a.value));
    } catch (error) {
      console.error('Error fetching activity data:', error);
      // Mock data for demo
      setData([
        { name: 'Tasks', value: 145, percentage: 35 },
        { name: 'Approvals', value: 98, percentage: 24 },
        { name: 'Documents', value: 76, percentage: 18 },
        { name: 'User Management', value: 62, percentage: 15 },
        { name: 'Other', value: 33, percentage: 8 }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const COLORS = [
    'hsl(var(--chart-1))',
    'hsl(var(--chart-2))',
    'hsl(var(--chart-3))',
    'hsl(var(--chart-4))',
    'hsl(var(--chart-5))'
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Package className="h-5 w-5" />
          Activity Breakdown
        </CardTitle>
        <CardDescription>
          Time distribution by activity category
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading activity data...</p>
          </div>
        ) : (
          <>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ percentage }) => `${percentage.toFixed(1)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {data.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '6px'
                  }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>

            {showDetailed && (
              <div className="mt-4 space-y-2">
                {data.map((item, idx) => (
                  <div key={item.name} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                      />
                      <span className="text-sm">{item.name}</span>
                    </div>
                    <div className="text-sm font-medium">
                      {item.value} ({item.percentage.toFixed(1)}%)
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  );
}
