import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { DateRange } from 'react-day-picker';
import { Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { format, differenceInHours } from 'date-fns';

interface ApprovalLatencyTableProps {
  dateRange: DateRange;
}

interface ApprovalEntry {
  id: string;
  adminName: string;
  submittedAt: string;
  approvedAt?: string;
  latencyHours?: number;
  status: string;
  hours: number;
  reason?: string;
}

export function ApprovalLatencyTable({ dateRange }: ApprovalLatencyTableProps) {
  const [entries, setEntries] = useState<ApprovalEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [avgLatency, setAvgLatency] = useState(0);

  useEffect(() => {
    fetchApprovalData();
  }, [dateRange]);

  const fetchApprovalData = async () => {
    try {
      setLoading(true);
      
      // Mock data for now - will be replaced with real data
      const mockEntries: ApprovalEntry[] = [
        {
          id: '1',
          adminName: 'John Admin',
          submittedAt: new Date(Date.now() - 7200000).toISOString(),
          approvedAt: new Date(Date.now() - 3600000).toISOString(),
          latencyHours: 1,
          status: 'approved',
          hours: 8.5,
          reason: 'Forgot to clock out'
        },
        {
          id: '2',
          adminName: 'Sarah Manager',
          submittedAt: new Date(Date.now() - 14400000).toISOString(),
          status: 'pending',
          hours: 7.2,
          reason: 'System error during clock-in'
        },
        {
          id: '3',
          adminName: 'Mike Supervisor',
          submittedAt: new Date(Date.now() - 86400000).toISOString(),
          approvedAt: new Date(Date.now() - 43200000).toISOString(),
          latencyHours: 12,
          status: 'approved',
          hours: 9.0,
          reason: 'Power outage'
        },
        {
          id: '4',
          adminName: 'Emma Coordinator',
          submittedAt: new Date(Date.now() - 3600000).toISOString(),
          status: 'pending',
          hours: 6.5,
          reason: 'Missed clock-out'
        }
      ];

      setEntries(mockEntries);

      // Calculate average latency
      const approvedEntries = mockEntries.filter(e => e.status === 'approved' && e.latencyHours);
      const avg = approvedEntries.reduce((sum, e) => sum + (e.latencyHours || 0), 0) / approvedEntries.length;
      setAvgLatency(avg);
    } catch (error) {
      console.error('Error fetching approval data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-100 text-green-800">Approved</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      case 'rejected':
        return <Badge className="bg-red-100 text-red-800">Rejected</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  const getLatencyColor = (hours?: number) => {
    if (!hours) return '';
    if (hours < 2) return 'text-green-600';
    if (hours < 6) return 'text-yellow-600';
    return 'text-red-600';
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Manual Entry Approvals
            </CardTitle>
            <CardDescription>
              Approval status and processing time for manual timesheet entries
            </CardDescription>
          </div>

          <div className="text-right">
            <p className="text-sm text-muted-foreground">Avg Approval Time</p>
            <p className={`text-2xl font-bold ${getLatencyColor(avgLatency)}`}>
              {avgLatency.toFixed(1)}h
            </p>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading approval data...</p>
          </div>
        ) : entries.length === 0 ? (
          <div className="h-[200px] flex flex-col items-center justify-center text-center">
            <CheckCircle className="h-12 w-12 text-green-600 mb-2" />
            <p className="font-medium">No pending approvals</p>
            <p className="text-sm text-muted-foreground">All manual entries have been processed</p>
          </div>
        ) : (
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Admin</TableHead>
                  <TableHead>Hours</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead>Latency</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entries.map((entry) => (
                  <TableRow key={entry.id}>
                    <TableCell className="font-medium">{entry.adminName}</TableCell>
                    <TableCell>{entry.hours}h</TableCell>
                    <TableCell className="max-w-[200px] truncate">
                      {entry.reason || '-'}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {format(new Date(entry.submittedAt), 'MMM dd, HH:mm')}
                    </TableCell>
                    <TableCell>
                      {entry.latencyHours !== undefined ? (
                        <span className={`font-medium ${getLatencyColor(entry.latencyHours)}`}>
                          {entry.latencyHours}h
                        </span>
                      ) : (
                        <span className="text-muted-foreground">Pending</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(entry.status)}
                    </TableCell>
                    <TableCell>
                      {entry.status === 'pending' && (
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            Approve
                          </Button>
                          <Button size="sm" variant="outline">
                            Reject
                          </Button>
                        </div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
