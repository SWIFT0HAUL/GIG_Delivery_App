import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { DateRange } from 'react-day-picker';
import { format, eachDayOfInterval } from 'date-fns';
import { TrendingUp } from 'lucide-react';

interface TimeSeriesChartProps {
  dateRange: DateRange;
  granularity: string;
  fullWidth?: boolean;
}

export function TimeSeriesChart({ dateRange, granularity, fullWidth }: TimeSeriesChartProps) {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTimeSeriesData();
  }, [dateRange, granularity]);

  const fetchTimeSeriesData = async () => {
    try {
      setLoading(true);
      
      const { data: timesheets, error } = await supabase
        .from('timesheets')
        .select('*')
        .gte('clock_in', dateRange.from?.toISOString())
        .lte('clock_in', dateRange.to?.toISOString())
        .neq('status', 'rejected');

      if (error) throw error;

      // Group by date
      const days = eachDayOfInterval({
        start: dateRange.from!,
        end: dateRange.to!
      });

      const chartData = days.map(day => {
        const dayStr = format(day, 'yyyy-MM-dd');
        const dayTimesheets = timesheets?.filter(t => 
          format(new Date(t.clock_in), 'yyyy-MM-dd') === dayStr
        ) || [];

        const totalHours = dayTimesheets.reduce((sum, t) => sum + (t.total_duration || 0), 0);
        
        return {
          date: format(day, 'MMM dd'),
          hours: parseFloat(totalHours.toFixed(2)),
          sessions: dayTimesheets.length,
          avgSession: dayTimesheets.length > 0 ? parseFloat((totalHours / dayTimesheets.length).toFixed(2)) : 0
        };
      });

      setData(chartData);
    } catch (error) {
      console.error('Error fetching time series data:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className={fullWidth ? 'col-span-full' : ''}>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUp className="h-5 w-5" />
          Hours Trend Over Time
        </CardTitle>
        <CardDescription>
          Total hours logged per {granularity === 'daily' ? 'day' : granularity === 'weekly' ? 'week' : 'month'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading chart data...</p>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis 
                dataKey="date" 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <YAxis 
                className="text-xs"
                tick={{ fill: 'hsl(var(--muted-foreground))' }}
              />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px'
                }}
              />
              <Legend />
              <Area 
                type="monotone" 
                dataKey="hours" 
                stroke="hsl(var(--primary))" 
                fill="hsl(var(--primary))"
                fillOpacity={0.3}
                name="Total Hours"
              />
              <Line 
                type="monotone" 
                dataKey="avgSession" 
                stroke="hsl(var(--destructive))" 
                name="Avg Session"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
}
