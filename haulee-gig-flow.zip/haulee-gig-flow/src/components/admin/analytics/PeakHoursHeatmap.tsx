import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock } from 'lucide-react';
import { DateRange } from 'react-day-picker';

interface PeakHoursHeatmapProps {
  dateRange: DateRange;
}

export function PeakHoursHeatmap({ dateRange }: PeakHoursHeatmapProps) {
  // Mock data for heatmap - will be replaced with real data
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  // Generate mock intensity data (0-100)
  const getIntensity = (day: number, hour: number) => {
    if (day >= 5) return 10; // Weekend
    if (hour < 7 || hour > 18) return 20; // Outside business hours
    if (hour >= 9 && hour <= 17) return 60 + Math.random() * 40; // Business hours
    return 30 + Math.random() * 30;
  };

  const getColor = (intensity: number) => {
    if (intensity < 20) return 'bg-gray-100 dark:bg-gray-800';
    if (intensity < 40) return 'bg-blue-200 dark:bg-blue-900';
    if (intensity < 60) return 'bg-blue-400 dark:bg-blue-700';
    if (intensity < 80) return 'bg-blue-600 dark:bg-blue-500';
    return 'bg-blue-800 dark:bg-blue-300';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5" />
          Peak Working Hours
        </CardTitle>
        <CardDescription>
          Activity intensity by day of week and hour
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {/* Day labels */}
          <div className="flex gap-1">
            <div className="w-12" /> {/* Spacer for hour labels */}
            {days.map(day => (
              <div key={day} className="flex-1 text-center text-xs font-medium">
                {day}
              </div>
            ))}
          </div>

          {/* Heatmap grid - showing only key hours for space */}
          {[6, 9, 12, 15, 18].map(hour => (
            <div key={hour} className="flex gap-1">
              <div className="w-12 text-xs text-muted-foreground flex items-center">
                {hour}:00
              </div>
              {days.map((day, dayIdx) => {
                const intensity = getIntensity(dayIdx, hour);
                return (
                  <div
                    key={`${day}-${hour}`}
                    className={`flex-1 h-8 rounded ${getColor(intensity)} hover:ring-2 hover:ring-primary cursor-pointer transition-all`}
                    title={`${day} ${hour}:00 - ${intensity.toFixed(0)}% active`}
                  />
                );
              })}
            </div>
          ))}

          {/* Legend */}
          <div className="flex items-center justify-end gap-2 pt-4 text-xs">
            <span className="text-muted-foreground">Less</span>
            <div className="flex gap-1">
              {[0, 25, 50, 75, 100].map(intensity => (
                <div
                  key={intensity}
                  className={`w-4 h-4 rounded ${getColor(intensity)}`}
                />
              ))}
            </div>
            <span className="text-muted-foreground">More</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
