import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { supabase } from '@/integrations/supabase/client';
import { DateRange } from 'react-day-picker';
import { Trophy, TrendingUp } from 'lucide-react';

interface AdminLeaderboardProps {
  dateRange: DateRange;
}

interface LeaderboardEntry {
  id: string;
  name: string;
  hours: number;
  sessions: number;
  utilization: number;
  rank: number;
}

export function AdminLeaderboard({ dateRange }: AdminLeaderboardProps) {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchLeaderboard();
  }, [dateRange]);

  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      
      // Mock data for now - will be replaced with real aggregated data
      setLeaderboard([
        { id: '1', name: 'John Admin', hours: 156.5, sessions: 42, utilization: 87, rank: 1 },
        { id: '2', name: 'Sarah Manager', hours: 142.3, sessions: 38, utilization: 82, rank: 2 },
        { id: '3', name: 'Mike Supervisor', hours: 138.7, sessions: 40, utilization: 78, rank: 3 },
        { id: '4', name: 'Emma Coordinator', hours: 125.2, sessions: 35, utilization: 75, rank: 4 },
        { id: '5', name: 'David Lead', hours: 118.9, sessions: 33, utilization: 71, rank: 5 }
      ]);
    } catch (error) {
      console.error('Error fetching leaderboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'bg-yellow-500';
      case 2: return 'bg-gray-400';
      case 3: return 'bg-amber-600';
      default: return 'bg-muted';
    }
  };

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trophy className="h-5 w-5" />
          Top Performing Admins
        </CardTitle>
        <CardDescription>
          Ranked by total hours and utilization
        </CardDescription>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <p className="text-muted-foreground">Loading leaderboard...</p>
          </div>
        ) : (
          <div className="space-y-3">
            {leaderboard.map((entry) => (
              <div 
                key={entry.id}
                className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1">
                  <div className={`w-8 h-8 rounded-full ${getRankColor(entry.rank)} flex items-center justify-center text-white font-bold text-sm`}>
                    {entry.rank}
                  </div>
                  
                  <Avatar className="h-10 w-10">
                    <AvatarFallback>{getInitials(entry.name)}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1 min-w-0">
                    <p className="font-medium truncate">{entry.name}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <span>{entry.sessions} sessions</span>
                      <span>•</span>
                      <span>{entry.utilization}% utilization</span>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-lg font-bold">{entry.hours.toFixed(1)}h</p>
                  <Badge variant="outline" className="text-xs">
                    <TrendingUp className="h-3 w-3 mr-1" />
                    +5.2%
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
