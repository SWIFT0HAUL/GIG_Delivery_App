import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { Loader2, Save, AlertCircle, Shield, Search, ChevronRight } from 'lucide-react';
import { SUB_ROLE_CONFIG, ALL_SUB_ROLES } from '@/lib/subRoleConfig';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MenuPermissionMapping } from './MenuPermissionMapping';

interface Role {
  role_key: string;
  description: string | null;
}

interface Permission {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
}

interface SubRolePermissions {
  [subRoleValue: string]: Set<string>; // permission ids
}

export const RoleSubRoleRelationships = () => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [relationships, setRelationships] = useState<Map<string, Set<string>>>(new Map());
  const [subRolePermissions, setSubRolePermissions] = useState<SubRolePermissions>({});
  const [selectedSubRole, setSelectedSubRole] = useState<string | null>(null);
  const [selectedRole, setSelectedRole] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [permissionSearch, setPermissionSearch] = useState('');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch all roles
      const { data: rolesData, error: rolesError } = await supabase
        .from('roles')
        .select('role_key, description')
        .eq('is_active', true)
        .order('role_key', { ascending: true });

      if (rolesError) throw rolesError;
      setRoles(rolesData || []);

      // Fetch all permissions
      const { data: permsData, error: permsError } = await supabase
        .from('permissions')
        .select('*')
        .order('category', { ascending: true });

      if (permsError) throw permsError;
      setPermissions(permsData || []);

      // Initialize relationships from SUB_ROLE_CONFIG
      const relMap = new Map<string, Set<string>>();
      Object.entries(SUB_ROLE_CONFIG).forEach(([role, subRoles]) => {
        relMap.set(role, new Set(subRoles.map(sr => sr.value)));
      });
      setRelationships(relMap);

      // Initialize sub-role permissions (empty for now)
      const subRolePerms: SubRolePermissions = {};
      ALL_SUB_ROLES.forEach(subRole => {
        subRolePerms[subRole.value] = new Set<string>();
      });
      setSubRolePermissions(subRolePerms);

    } catch (error: any) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load role relationships');
    } finally {
      setLoading(false);
    }
  };

  const toggleSubRole = (roleKey: string, subRoleValue: string) => {
    setRelationships(prev => {
      const newMap = new Map(prev);
      const subRoles = new Set<string>(newMap.get(roleKey) || new Set<string>());
      
      if (subRoles.has(subRoleValue)) {
        subRoles.delete(subRoleValue);
        // Clear selection if we're removing the selected sub-role
        if (selectedSubRole === subRoleValue) {
          setSelectedSubRole(null);
          setSelectedRole(null);
        }
      } else {
        subRoles.add(subRoleValue);
        // Auto-select when adding a new sub-role
        setSelectedSubRole(subRoleValue);
        setSelectedRole(roleKey);
      }
      
      newMap.set(roleKey, subRoles);
      setHasChanges(true);
      return newMap;
    });
  };

  const togglePermission = (subRoleValue: string, permissionId: string) => {
    setSubRolePermissions(prev => {
      const newPerms = { ...prev };
      const perms = new Set<string>(newPerms[subRoleValue] || new Set<string>());
      
      if (perms.has(permissionId)) {
        perms.delete(permissionId);
      } else {
        perms.add(permissionId);
      }
      
      newPerms[subRoleValue] = perms;
      setHasChanges(true);
      return newPerms;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Note: This would require updating the subRoleConfig.ts file
      // or storing relationships and permissions in database tables
      
      toast.success('Role-SubRole relationships and permissions saved successfully');
      toast.info('Note: You may need to update the subRoleConfig.ts file manually');
      setHasChanges(false);
    } catch (error: any) {
      console.error('Error saving relationships:', error);
      toast.error('Failed to save relationships');
    } finally {
      setSaving(false);
    }
  };

  const getSubRoleLabel = (value: string): string => {
    const found = ALL_SUB_ROLES.find(sr => sr.value === value);
    return found ? found.label : value;
  };

  const getRoleBadgeVariant = (roleKey: string) => {
    if (roleKey === 'super_admin') return 'destructive';
    if (roleKey === 'admin') return 'default';
    return 'secondary';
  };

  const getPermissionCount = (subRoleValue: string): number => {
    return subRolePermissions[subRoleValue]?.size || 0;
  };

  const filteredPermissions = permissions.filter(perm =>
    perm.name.toLowerCase().includes(permissionSearch.toLowerCase()) ||
    perm.description?.toLowerCase().includes(permissionSearch.toLowerCase())
  );

  const groupedPermissions = filteredPermissions.reduce((acc, perm) => {
    const category = perm.category || 'Uncategorized';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(perm);
    return acc;
  }, {} as Record<string, Permission[]>);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Clean Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Role Management</h1>
          <p className="text-muted-foreground mt-1">Configure role relationships and permissions</p>
        </div>
        {hasChanges && (
          <Button onClick={handleSave} disabled={saving}>
            {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            {saving ? 'Saving...' : 'Save Changes'}
          </Button>
        )}
      </div>

      {/* Main Content with Tabs */}
      <Tabs defaultValue="assign" className="w-full">
        <TabsList className="grid w-full max-w-2xl grid-cols-3">
          <TabsTrigger value="assign">Assign Sub-Roles</TabsTrigger>
          <TabsTrigger value="permissions">Configure Permissions</TabsTrigger>
          <TabsTrigger value="menu-permissions">Menu Permissions</TabsTrigger>
        </TabsList>

        {/* Tab 1: Assign Sub-Roles to Roles */}
        <TabsContent value="assign" className="mt-6">
          <div className="grid gap-6">
            {roles.filter(role => role.role_key !== 'super_admin').map((role) => {
              const assignedSubRoles = relationships.get(role.role_key) || new Set();
              
              return (
                <Card key={role.role_key} className="overflow-hidden">
                  <CardHeader className="bg-muted/30 border-b">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Badge variant={getRoleBadgeVariant(role.role_key)} className="text-sm font-semibold">
                          {role.role_key}
                        </Badge>
                        <Separator orientation="vertical" className="h-6" />
                        <div>
                          <CardTitle className="text-base">{role.description || role.role_key}</CardTitle>
                          <CardDescription className="text-xs mt-1">
                            {assignedSubRoles.size} sub-role{assignedSubRoles.size !== 1 ? 's' : ''} assigned
                          </CardDescription>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-6">
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {ALL_SUB_ROLES
                        .filter(subRole => {
                          const restrictedRoles = ['shipper', 'broker', 'carrier', 'driver', 'vendor_merchant'];
                          if (restrictedRoles.includes(role.role_key)) {
                            return subRole.value === role.role_key;
                          }
                          return true;
                        })
                        .map((subRole) => {
                        const isAssigned = assignedSubRoles.has(subRole.value);
                        const permCount = getPermissionCount(subRole.value);
                        
                        return (
                          <Button
                            key={subRole.value}
                            variant={isAssigned ? "default" : "outline"}
                            className="h-auto py-4 flex flex-col items-start gap-2 relative"
                            onClick={() => toggleSubRole(role.role_key, subRole.value)}
                          >
                            <div className="flex items-center gap-2 w-full">
                              <div className={`h-2 w-2 rounded-full ${isAssigned ? 'bg-primary-foreground' : 'bg-muted-foreground/30'}`} />
                              <span className="text-sm font-medium text-left flex-1">{subRole.label}</span>
                            </div>
                            {isAssigned && permCount > 0 && (
                              <Badge variant="secondary" className="text-xs self-start">
                                {permCount} permission{permCount !== 1 ? 's' : ''}
                              </Badge>
                            )}
                          </Button>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        {/* Tab 2: Configure Permissions */}
        <TabsContent value="permissions" className="mt-6">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Sub-Role Selection */}
            <Card className="lg:col-span-1">
              <CardHeader>
                <CardTitle className="text-base">Select Sub-Role</CardTitle>
                <CardDescription>Choose a sub-role to configure</CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[600px] pr-3">
                  <div className="space-y-2">
                    {ALL_SUB_ROLES.map((subRole) => {
                      const isSelected = selectedSubRole === subRole.value;
                      const permCount = getPermissionCount(subRole.value);
                      
                      return (
                        <Button
                          key={subRole.value}
                          variant={isSelected ? "default" : "ghost"}
                          className="w-full justify-between h-auto py-3"
                          onClick={() => setSelectedSubRole(subRole.value)}
                        >
                          <span className="font-medium">{subRole.label}</span>
                          {permCount > 0 && (
                            <Badge variant={isSelected ? "secondary" : "outline"} className="ml-2">
                              {permCount}
                            </Badge>
                          )}
                        </Button>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Permissions Configuration */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-base flex items-center gap-2">
                      <Shield className="h-4 w-4" />
                      Permissions
                    </CardTitle>
                    <CardDescription>
                      {selectedSubRole ? `Configure permissions for ${getSubRoleLabel(selectedSubRole)}` : 'Select a sub-role to begin'}
                    </CardDescription>
                  </div>
                  {selectedSubRole && (
                    <Badge variant="outline">
                      {getPermissionCount(selectedSubRole)} selected
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {selectedSubRole ? (
                  <div className="space-y-4">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        placeholder="Search permissions..."
                        value={permissionSearch}
                        onChange={(e) => setPermissionSearch(e.target.value)}
                        className="pl-9"
                      />
                    </div>

                    <Separator />

                    <ScrollArea className="h-[500px]">
                      <div className="space-y-6 pr-3">
                        {Object.entries(groupedPermissions).map(([category, perms]) => (
                          <div key={category}>
                            <h3 className="font-semibold text-sm mb-3 flex items-center gap-2">
                              <ChevronRight className="h-4 w-4" />
                              {category}
                            </h3>
                            <div className="space-y-2 ml-6">
                              {perms.map((permission) => {
                                const hasPermission = subRolePermissions[selectedSubRole]?.has(permission.id) || false;
                                return (
                                  <div
                                    key={permission.id}
                                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                                      hasPermission 
                                        ? 'bg-primary/5 border-primary/20' 
                                        : 'hover:bg-muted/50 border-transparent'
                                    }`}
                                    onClick={() => togglePermission(selectedSubRole, permission.id)}
                                  >
                                    <div className="flex items-start gap-3">
                                      <div className={`mt-1 h-5 w-5 rounded border-2 flex items-center justify-center ${
                                        hasPermission 
                                          ? 'bg-primary border-primary' 
                                          : 'border-muted-foreground/30'
                                      }`}>
                                        {hasPermission && (
                                          <svg className="h-3 w-3 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                          </svg>
                                        )}
                                      </div>
                                      <div className="flex-1">
                                        <p className="font-medium text-sm">{permission.name}</p>
                                        {permission.description && (
                                          <p className="text-xs text-muted-foreground mt-1">
                                            {permission.description}
                                          </p>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center h-[500px] text-center">
                    <Shield className="h-16 w-16 mb-4 text-muted-foreground/30" />
                    <h3 className="font-semibold text-lg mb-2">No Sub-Role Selected</h3>
                    <p className="text-sm text-muted-foreground max-w-sm">
                      Select a sub-role from the list to configure its permissions
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Tab 3: Menu-Permission Mapping */}
        <TabsContent value="menu-permissions" className="mt-6">
          <MenuPermissionMapping />
        </TabsContent>
      </Tabs>

      {/* Info Alert */}
      {hasChanges && (
        <Alert>
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            You have unsaved changes. Click <strong>Save Changes</strong> to persist your configuration.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default RoleSubRoleRelationships;
