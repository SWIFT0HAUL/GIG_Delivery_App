import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { User, Building2, Shield, Bell, CreditCard, FileText, Smartphone, Sun, Moon, Monitor, MapPin } from 'lucide-react';
import { toast } from 'sonner';
import { useDarkModeSettings } from '@/hooks/useDarkModeSettings';

export function BrokerSettings() {
  const [activeMainTab, setActiveMainTab] = useState('profile');
  const [activeProfileTab, setActiveProfileTab] = useState('personal');
  const [activeBusinessTab, setActiveBusinessTab] = useState('info');
  const [paymentMethodType, setPaymentMethodType] = useState('bank');
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [smsAuthEnabled, setSmsAuthEnabled] = useState(true);
  const [emailAuthEnabled, setEmailAuthEnabled] = useState(true);
  const [themePreference, setThemePreference] = useState('system');
  const { appDarkMode, mapsDarkMode, setAppDarkMode, setMapsDarkMode } = useDarkModeSettings();

  return (
    <div className="space-y-4 sm:space-y-6 animate-fade-in w-full max-w-full overflow-x-hidden">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Broker Settings</h1>
        <p className="text-sm sm:text-base text-muted-foreground mt-2">
          Configure default settings and preferences for broker accounts
        </p>
      </div>

      <Tabs value={activeMainTab} onValueChange={setActiveMainTab} className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-9 sm:h-10">
          <TabsTrigger value="profile" className="text-xs sm:text-sm">Profile</TabsTrigger>
          <TabsTrigger value="business" className="text-xs sm:text-sm">Business Info</TabsTrigger>
          <TabsTrigger value="security" className="text-xs sm:text-sm">MFA / Security</TabsTrigger>
        </TabsList>

        {/* Profile Tab - same structure as Shipper but with broker-specific content */}
        <TabsContent value="profile" className="space-y-4">
          <Tabs value={activeProfileTab} onValueChange={setActiveProfileTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-auto sm:h-10 p-1">
              <TabsTrigger value="personal" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Personal Information
              </TabsTrigger>
              <TabsTrigger value="payment" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Payment Method
              </TabsTrigger>
              <TabsTrigger value="notifications" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Notifications & Preferences
              </TabsTrigger>
            </TabsList>

            {/* Personal Information */}
            <TabsContent value="personal" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <User className="h-4 w-4 sm:h-5 sm:w-5" />
                    Personal Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure default fields for broker contact information
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require broker license</Label>
                      <p className="text-xs text-muted-foreground">Valid freight broker license required</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require phone verification</Label>
                      <p className="text-xs text-muted-foreground">Verify contact phone number</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Allow company logo upload</Label>
                      <p className="text-xs text-muted-foreground">Let brokers upload their company logo</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="defaultLanguage" className="text-xs sm:text-sm">Default language</Label>
                    <Select defaultValue="English">
                      <SelectTrigger id="defaultLanguage" className="max-w-xs h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="French">French</SelectItem>
                        <SelectItem value="Spanish">Spanish</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Default language for new broker accounts</p>
                  </div>

                  <Button onClick={() => toast.success('Personal settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payment Method - matching structure */}
            <TabsContent value="payment" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <CreditCard className="h-4 w-4 sm:h-5 sm:w-5" />
                    Payment Methods
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure payment and commission settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="space-y-2">
                    <Label htmlFor="allowedMethods" className="text-xs sm:text-sm">Allowed payment methods</Label>
                    <Select value={paymentMethodType} onValueChange={setPaymentMethodType}>
                      <SelectTrigger id="allowedMethods" className="max-w-xs h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="bank">Bank Account</SelectItem>
                        <SelectItem value="check">Check</SelectItem>
                        <SelectItem value="both">Both Methods</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Payment methods brokers can use</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="commissionRate" className="text-xs sm:text-sm">Default commission rate (%)</Label>
                    <Input 
                      id="commissionRate"
                      type="number" 
                      defaultValue="15" 
                      step="0.1"
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Standard commission percentage</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="paymentTerms" className="text-xs sm:text-sm">Payment terms (days)</Label>
                    <Input 
                      id="paymentTerms"
                      type="number" 
                      defaultValue="30" 
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Default payment terms for carriers</p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require surety bond</Label>
                      <p className="text-xs text-muted-foreground">Verify BMC-84 surety bond</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Button onClick={() => toast.success('Payment settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications & Preferences - matching structure */}
            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5" />
                    Notifications & Preferences
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure default notification settings and appearance
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">New load alerts</Label>
                        <p className="text-xs text-muted-foreground">Notify about new load postings</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Carrier bids</Label>
                        <p className="text-xs text-muted-foreground">Receive notifications for carrier bids</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Delivery confirmations</Label>
                        <p className="text-xs text-muted-foreground">Get notified about completed deliveries</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <Separator />

                  <div className="pt-2">
                    <Label className="text-xs sm:text-sm font-medium">Default notification channels</Label>
                    <p className="text-xs text-muted-foreground mb-3">How brokers receive notifications</p>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked id="email-default" />
                        <Label htmlFor="email-default" className="text-xs sm:text-sm cursor-pointer">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked id="sms-default" />
                        <Label htmlFor="sms-default" className="text-xs sm:text-sm cursor-pointer">SMS</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked id="push-default" />
                        <Label htmlFor="push-default" className="text-xs sm:text-sm cursor-pointer">Push Notifications</Label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="pt-2">
                    <Label className="text-xs sm:text-sm font-medium">Appearance</Label>
                    <p className="text-xs text-muted-foreground mb-3">Choose your preferred theme</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={() => setThemePreference('light')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'light' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Sun className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Light mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('dark')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'dark' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Moon className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Dark mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('system')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'system' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Monitor className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">System default</span>
                      </button>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div>
                    <Label className="text-xs sm:text-sm font-medium">Advanced Dark Mode Settings</Label>
                    <p className="text-xs text-muted-foreground mb-4">Separately control dark mode for app and maps</p>
                    
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-primary/10">
                            <Monitor className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">App Dark Mode</p>
                            <p className="text-xs text-muted-foreground">Enable dark theme for the interface</p>
                          </div>
                        </div>
                        <Switch
                          checked={appDarkMode}
                          onCheckedChange={setAppDarkMode}
                        />
                      </div>

                      <div className="flex items-center justify-between p-4 rounded-lg border bg-card">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-primary/10">
                            <MapPin className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">Maps Dark Mode</p>
                            <p className="text-xs text-muted-foreground">Enable dark theme for maps</p>
                          </div>
                        </div>
                        <Switch
                          checked={mapsDarkMode}
                          onCheckedChange={setMapsDarkMode}
                        />
                      </div>
                    </div>
                  </div>

                  <Button onClick={() => toast.success('Notification preferences saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Business Info Tab */}
        <TabsContent value="business" className="space-y-4">
          <Tabs value={activeBusinessTab} onValueChange={setActiveBusinessTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="info">Company Info</TabsTrigger>
              <TabsTrigger value="licensing">Licensing</TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Building2 className="h-4 w-4 sm:h-5 sm:w-5" />
                    Company Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure company information requirements
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require MC number</Label>
                      <p className="text-xs text-muted-foreground">Valid MC (Motor Carrier) number</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require DOT number</Label>
                      <p className="text-xs text-muted-foreground">Department of Transportation number</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require tax ID</Label>
                      <p className="text-xs text-muted-foreground">Federal tax identification number</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Button onClick={() => toast.success('Company info settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="licensing" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
                    Licensing Requirements
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure broker licensing and insurance requirements
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Verify broker authority</Label>
                      <p className="text-xs text-muted-foreground">Confirm active broker authority with FMCSA</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="bondAmount" className="text-xs sm:text-sm">Minimum bond amount ($)</Label>
                    <Input 
                      id="bondAmount"
                      type="number" 
                      defaultValue="75000" 
                      step="1000"
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Required BMC-84 surety bond amount</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="renewalWarning" className="text-xs sm:text-sm">License renewal warning (days)</Label>
                    <Input 
                      id="renewalWarning"
                      type="number" 
                      defaultValue="60" 
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Days before expiry to warn brokers</p>
                  </div>

                  <Button onClick={() => toast.success('Licensing settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Security Tab - same for all roles */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Shield className="h-4 w-4 sm:h-5 sm:w-5" />
                Multi-Factor Authentication (MFA)
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Add an extra layer of security to your account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-3 sm:p-6">
              <div className="flex items-center justify-between p-3 sm:p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Smartphone className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">Authenticator App (Recommended)</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Use Google Authenticator or similar</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={mfaEnabled ? "default" : "secondary"} className="text-[10px] sm:text-xs">
                    {mfaEnabled ? "Required" : "Optional"}
                  </Badge>
                  <Switch 
                    checked={mfaEnabled} 
                    onCheckedChange={setMfaEnabled}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 sm:p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">SMS Authentication</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Verification codes via text message</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={smsAuthEnabled ? "default" : "secondary"} className="text-[10px] sm:text-xs">
                    {smsAuthEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Switch 
                    checked={smsAuthEnabled} 
                    onCheckedChange={setSmsAuthEnabled}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 sm:p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">Email Authentication</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Verification codes via email</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={emailAuthEnabled ? "default" : "secondary"} className="text-[10px] sm:text-xs">
                    {emailAuthEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Switch 
                    checked={emailAuthEnabled} 
                    onCheckedChange={setEmailAuthEnabled}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="sessionTimeout" className="text-xs sm:text-sm">Session timeout (minutes)</Label>
                <Input 
                  id="sessionTimeout"
                  type="number" 
                  defaultValue="60" 
                  className="max-w-xs h-9 sm:h-10 text-sm" 
                />
                <p className="text-xs text-muted-foreground">Auto-logout after inactivity</p>
              </div>

              <Button onClick={() => toast.success('Security settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
