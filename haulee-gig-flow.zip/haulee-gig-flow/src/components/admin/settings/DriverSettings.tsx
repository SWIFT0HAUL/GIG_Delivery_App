import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { User, Car, Shield, Bell, CreditCard, FileText, Smartphone, Sun, Moon, Monitor } from 'lucide-react';
import { toast } from 'sonner';

export function DriverSettings() {
  const [activeMainTab, setActiveMainTab] = useState('profile');
  const [activeProfileTab, setActiveProfileTab] = useState('personal');
  const [activeVehicleTab, setActiveVehicleTab] = useState('info');
  const [paymentMethodType, setPaymentMethodType] = useState('bank');
  const [mfaEnabled, setMfaEnabled] = useState(false);
  const [smsAuthEnabled, setSmsAuthEnabled] = useState(true);
  const [emailAuthEnabled, setEmailAuthEnabled] = useState(true);
  const [themePreference, setThemePreference] = useState('system');

  return (
    <div className="space-y-4 sm:space-y-6 animate-fade-in w-full max-w-full overflow-x-hidden">
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">Driver Settings</h1>
        <p className="text-sm sm:text-base text-muted-foreground mt-2">
          Configure default settings and preferences for driver accounts
        </p>
      </div>

      <Tabs value={activeMainTab} onValueChange={setActiveMainTab} className="space-y-4 sm:space-y-6">
        <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-9 sm:h-10">
          <TabsTrigger value="profile" className="text-xs sm:text-sm">Profile</TabsTrigger>
          <TabsTrigger value="vehicle" className="text-xs sm:text-sm">Vehicle</TabsTrigger>
          <TabsTrigger value="security" className="text-xs sm:text-sm">MFA / Security</TabsTrigger>
        </TabsList>

        {/* Profile Tab */}
        <TabsContent value="profile" className="space-y-4">
          <Tabs value={activeProfileTab} onValueChange={setActiveProfileTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-3 gap-0.5 sm:gap-1 h-auto sm:h-10 p-1">
              <TabsTrigger value="personal" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Personal Information
              </TabsTrigger>
              <TabsTrigger value="payment" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Payment Method
              </TabsTrigger>
              <TabsTrigger value="notifications" className="text-[10px] sm:text-sm px-1 sm:px-3 py-2 whitespace-normal leading-tight">
                Notifications & Preferences
              </TabsTrigger>
            </TabsList>

            {/* Personal Information */}
            <TabsContent value="personal" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <User className="h-4 w-4 sm:h-5 sm:w-5" />
                    Personal Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure default fields and requirements for driver profiles
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require emergency contact</Label>
                      <p className="text-xs text-muted-foreground">Mandatory emergency contact information</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require phone verification</Label>
                      <p className="text-xs text-muted-foreground">Drivers must verify their phone number</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Allow profile photo updates</Label>
                      <p className="text-xs text-muted-foreground">Let drivers update their profile photo</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="defaultLanguage" className="text-xs sm:text-sm">Default language</Label>
                    <Select defaultValue="English">
                      <SelectTrigger id="defaultLanguage" className="max-w-xs h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="English">English</SelectItem>
                        <SelectItem value="French">French</SelectItem>
                        <SelectItem value="Spanish">Spanish</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Default language for new driver accounts</p>
                  </div>

                  <Button onClick={() => toast.success('Personal settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Payment Method */}
            <TabsContent value="payment" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <CreditCard className="h-4 w-4 sm:h-5 sm:w-5" />
                    Payment Methods
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure allowed payment methods and payout settings
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="space-y-2">
                    <Label htmlFor="allowedMethods" className="text-xs sm:text-sm">Allowed payment methods</Label>
                    <Select value={paymentMethodType} onValueChange={setPaymentMethodType}>
                      <SelectTrigger id="allowedMethods" className="max-w-xs h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select method" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="bank">Bank Account Only</SelectItem>
                        <SelectItem value="debit">Debit Card Only</SelectItem>
                        <SelectItem value="both">Both Methods</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Payment methods drivers can use</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="minPayout" className="text-xs sm:text-sm">Minimum payout threshold ($)</Label>
                    <Input 
                      id="minPayout"
                      type="number" 
                      defaultValue="50" 
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Minimum earnings before payout</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="payoutSchedule" className="text-xs sm:text-sm">Default payout schedule</Label>
                    <Select defaultValue="weekly">
                      <SelectTrigger id="payoutSchedule" className="max-w-xs h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select schedule" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="biweekly">Bi-weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">How often drivers receive payouts</p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Enable instant payouts</Label>
                      <p className="text-xs text-muted-foreground">Allow drivers to request instant payouts (may incur fees)</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Button onClick={() => toast.success('Payment settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications & Preferences */}
            <TabsContent value="notifications" className="space-y-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5" />
                    Notifications & Preferences
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure default notification settings and appearance preferences
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">New job alerts (default ON)</Label>
                        <p className="text-xs text-muted-foreground">Notify drivers about new available jobs</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Earnings updates (default ON)</Label>
                        <p className="text-xs text-muted-foreground">Send earnings and payout notifications</p>
                      </div>
                      <Switch defaultChecked />
                    </div>

                    <Separator />

                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label className="text-xs sm:text-sm font-medium">Job reminders (default ON)</Label>
                        <p className="text-xs text-muted-foreground">Remind about upcoming scheduled jobs</p>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <Separator />

                  <div className="pt-2">
                    <Label className="text-xs sm:text-sm font-medium">Default notification channels</Label>
                    <p className="text-xs text-muted-foreground mb-3">How drivers receive notifications by default</p>
                    <div className="space-y-2">
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked id="email-default" />
                        <Label htmlFor="email-default" className="text-xs sm:text-sm cursor-pointer">Email</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked id="sms-default" />
                        <Label htmlFor="sms-default" className="text-xs sm:text-sm cursor-pointer">SMS</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch defaultChecked id="push-default" />
                        <Label htmlFor="push-default" className="text-xs sm:text-sm cursor-pointer">Push Notifications</Label>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  <div className="pt-2">
                    <Label className="text-xs sm:text-sm font-medium">Appearance</Label>
                    <p className="text-xs text-muted-foreground mb-3">Choose your preferred theme</p>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        onClick={() => setThemePreference('light')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'light' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Sun className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Light mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('dark')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'dark' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Moon className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">Dark mode</span>
                      </button>

                      <button
                        onClick={() => setThemePreference('system')}
                        className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                          themePreference === 'system' 
                            ? 'border-primary bg-primary/5' 
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <Monitor className="h-5 w-5" />
                        <span className="text-xs sm:text-sm font-medium">System default</span>
                      </button>
                    </div>
                  </div>

                  {themePreference === 'dark' && (
                    <>
                      <Separator />

                      <div className="pt-2">
                        <Label className="text-xs sm:text-sm font-medium">Advanced Dark Mode Settings</Label>
                        <p className="text-xs text-muted-foreground mb-3">Separate dark mode controls for app and maps</p>
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label className="text-xs sm:text-sm font-medium">App Dark Mode</Label>
                              <p className="text-xs text-muted-foreground">Enable dark mode for the application interface</p>
                            </div>
                            <Switch />
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="space-y-0.5">
                              <Label className="text-xs sm:text-sm font-medium">Maps Dark Mode</Label>
                              <p className="text-xs text-muted-foreground">Enable dark mode for map views</p>
                            </div>
                            <Switch />
                          </div>
                        </div>
                      </div>
                    </>
                  )}

                  <Button onClick={() => toast.success('Notification preferences saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Vehicle Tab */}
        <TabsContent value="vehicle" className="space-y-4">
          <Tabs value={activeVehicleTab} onValueChange={setActiveVehicleTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="info">Vehicle Info</TabsTrigger>
              <TabsTrigger value="insurance">Insurance</TabsTrigger>
            </TabsList>

            <TabsContent value="info" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <Car className="h-4 w-4 sm:h-5 sm:w-5" />
                    Vehicle Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure vehicle information requirements for drivers
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require vehicle registration</Label>
                      <p className="text-xs text-muted-foreground">Drivers must provide valid vehicle registration</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require vehicle photos</Label>
                      <p className="text-xs text-muted-foreground">Mandatory vehicle photo uploads</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="minVehicleYear" className="text-xs sm:text-sm">Minimum vehicle year</Label>
                    <Input 
                      id="minVehicleYear"
                      type="number" 
                      defaultValue="2010" 
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Oldest vehicle year allowed for drivers</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="vehicleTypes" className="text-xs sm:text-sm">Allowed vehicle types</Label>
                    <Select defaultValue="all">
                      <SelectTrigger id="vehicleTypes" className="max-w-xs h-9 sm:h-10 text-sm bg-background">
                        <SelectValue placeholder="Select types" />
                      </SelectTrigger>
                      <SelectContent className="bg-popover z-50">
                        <SelectItem value="all">All Types</SelectItem>
                        <SelectItem value="car">Cars Only</SelectItem>
                        <SelectItem value="suv">SUVs Only</SelectItem>
                        <SelectItem value="truck">Trucks Only</SelectItem>
                        <SelectItem value="van">Vans Only</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">Types of vehicles allowed</p>
                  </div>

                  <Button onClick={() => toast.success('Vehicle settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="insurance" className="space-y-4 mt-4">
              <Card>
                <CardHeader className="p-3 sm:p-6">
                  <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                    <FileText className="h-4 w-4 sm:h-5 sm:w-5" />
                    Insurance Information
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Configure insurance requirements for driver vehicles
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4 p-3 sm:p-6">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Require insurance verification</Label>
                      <p className="text-xs text-muted-foreground">Drivers must provide valid insurance</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="minCoverage" className="text-xs sm:text-sm">Minimum coverage amount ($)</Label>
                    <Input 
                      id="minCoverage"
                      type="number" 
                      defaultValue="1000000" 
                      step="100000"
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Minimum required insurance coverage</p>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label htmlFor="expiryWarning" className="text-xs sm:text-sm">Expiry warning period (days)</Label>
                    <Input 
                      id="expiryWarning"
                      type="number" 
                      defaultValue="30" 
                      className="max-w-xs h-9 sm:h-10 text-sm" 
                    />
                    <p className="text-xs text-muted-foreground">Days before expiry to warn drivers</p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label className="text-xs sm:text-sm font-medium">Auto-suspend on expiry</Label>
                      <p className="text-xs text-muted-foreground">Automatically suspend drivers with expired insurance</p>
                    </div>
                    <Switch defaultChecked />
                  </div>

                  <Button onClick={() => toast.success('Insurance settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                    Save Changes
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader className="p-3 sm:p-6">
              <CardTitle className="flex items-center gap-2 text-base sm:text-lg">
                <Shield className="h-4 w-4 sm:h-5 sm:w-5" />
                Multi-Factor Authentication (MFA)
              </CardTitle>
              <CardDescription className="text-xs sm:text-sm">
                Add an extra layer of security to your account
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4 p-3 sm:p-6">
              <div className="flex items-center justify-between p-3 sm:p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Smartphone className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">Authenticator App (Recommended)</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Use Google Authenticator or similar</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={mfaEnabled ? "default" : "secondary"} className="text-[10px] sm:text-xs">
                    {mfaEnabled ? "Required" : "Optional"}
                  </Badge>
                  <Switch 
                    checked={mfaEnabled} 
                    onCheckedChange={setMfaEnabled}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 sm:p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5 text-blue-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">SMS Authentication</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Verification codes via text message</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={smsAuthEnabled ? "default" : "secondary"} className="text-[10px] sm:text-xs">
                    {smsAuthEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Switch 
                    checked={smsAuthEnabled} 
                    onCheckedChange={setSmsAuthEnabled}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between p-3 sm:p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-green-500/10 rounded-lg">
                    <Bell className="h-4 w-4 sm:h-5 sm:w-5 text-green-500" />
                  </div>
                  <div>
                    <p className="font-medium text-xs sm:text-sm">Email Authentication</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground">Verification codes via email</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={emailAuthEnabled ? "default" : "secondary"} className="text-[10px] sm:text-xs">
                    {emailAuthEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                  <Switch 
                    checked={emailAuthEnabled} 
                    onCheckedChange={setEmailAuthEnabled}
                  />
                </div>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="sessionTimeout" className="text-xs sm:text-sm">Session timeout (minutes)</Label>
                <Input 
                  id="sessionTimeout"
                  type="number" 
                  defaultValue="60" 
                  className="max-w-xs h-9 sm:h-10 text-sm" 
                />
                <p className="text-xs text-muted-foreground">Auto-logout after inactivity</p>
              </div>

              <Button onClick={() => toast.success('Security settings saved!')} className="w-full sm:w-auto text-xs sm:text-sm h-9 sm:h-10">
                Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
