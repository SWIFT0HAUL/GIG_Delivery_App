import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { useUserRole } from '@/hooks/useUserRole';
import { 
  Settings, Search, Eye, Save, RotateCcw, Undo2, 
  ChevronDown, ChevronRight, Filter, Download, Upload, RefreshCw, Database, Clock
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Setting {
  id: string;
  category: string;
  subcategory: string | null;
  setting_key: string;
  setting_value: any;
  value_type: string;
  description: string | null;
  is_global: boolean;
  status: string;
  role_access: string[];
  updated_at: string;
}

interface CategoryGroup {
  [subcategory: string]: Setting[];
}

interface SettingsData {
  [category: string]: CategoryGroup;
}

export const AdvancedSettings = () => {
  const { isSuperAdmin } = useUserRole();
  const [settings, setSettings] = useState<Setting[]>([]);
  const [filteredSettings, setFilteredSettings] = useState<Setting[]>([]);
  const [groupedSettings, setGroupedSettings] = useState<SettingsData>({});
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [loading, setLoading] = useState(true);
  const [pendingChanges, setPendingChanges] = useState<Record<string, any>>({});
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});
  const [auditLogs, setAuditLogs] = useState<any[]>([]);
  const [isClearing, setIsClearing] = useState(false);
  const [isRunningMaintenance, setIsRunningMaintenance] = useState(false);
  const [isRecalculating, setIsRecalculating] = useState(false);

  const hasSuperAdminAccess = isSuperAdmin();

  // Load settings from database
  const loadSettings = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('platform_settings')
        .select('*')
        .eq('status', 'active')
        .order('category', { ascending: true })
        .order('subcategory', { ascending: true })
        .order('setting_key', { ascending: true });

      if (error) throw error;

      setSettings(data || []);
      setFilteredSettings(data || []);
      groupSettingsByCategory(data || []);
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to load settings',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Load audit logs
  const loadAuditLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('settings_audit_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      setAuditLogs(data || []);
    } catch (error) {
      console.error('Error loading audit logs:', error);
    }
  };

  useEffect(() => {
    loadSettings();
    loadAuditLogs();

    // Real-time subscription for settings changes
    const channel = supabase
      .channel('advanced-settings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'platform_settings',
        },
        (payload) => {
          console.log('Settings changed in real-time:', payload);
          loadSettings();
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'settings_audit_log',
        },
        () => {
          loadAuditLogs();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // Group settings by category and subcategory
  const groupSettingsByCategory = (settingsData: Setting[]) => {
    const grouped: SettingsData = {};
    
    settingsData.forEach((setting) => {
      if (!grouped[setting.category]) {
        grouped[setting.category] = {};
      }
      
      const subcat = setting.subcategory || 'General';
      if (!grouped[setting.category][subcat]) {
        grouped[setting.category][subcat] = [];
      }
      
      grouped[setting.category][subcat].push(setting);
    });

    setGroupedSettings(grouped);
  };

  // Filter settings based on search and category
  useEffect(() => {
    let filtered = settings;

    if (searchTerm) {
      filtered = filtered.filter(
        (s) =>
          s.setting_key.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
          s.category.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCategory !== 'all') {
      filtered = filtered.filter((s) => s.category === selectedCategory);
    }

    setFilteredSettings(filtered);
    groupSettingsByCategory(filtered);
  }, [searchTerm, selectedCategory, settings]);

  // Update setting value (always stage changes, never auto-save)
  const updateSetting = (settingKey: string, newValue: any) => {
    setPendingChanges((prev) => ({ ...prev, [settingKey]: newValue }));
  };

  // Save all pending changes
  const saveAllChanges = async () => {
    if (Object.keys(pendingChanges).length === 0) {
      toast({
        title: 'No Changes',
        description: 'There are no changes to save',
      });
      return;
    }

    try {
      const promises = Object.entries(pendingChanges).map(async ([key, value]) => {
        const { error } = await supabase.rpc('update_platform_setting', {
          p_setting_key: key,
          p_setting_value: value,
        });
        if (error) throw error;
      });
      
      await Promise.all(promises);
      setPendingChanges({});
      
      toast({
        title: 'Changes Saved',
        description: `Successfully saved ${Object.keys(pendingChanges).length} settings`,
      });

      await loadSettings();
      await loadAuditLogs();
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to save some settings',
        variant: 'destructive',
      });
    }
  };

  // Discard pending changes
  const discardChanges = () => {
    setPendingChanges({});
    toast({
      title: 'Changes Discarded',
      description: 'All pending changes have been discarded',
    });
  };

  // Reset to defaults
  const resetToDefaults = async () => {
    try {
      const { error } = await supabase.rpc('reset_settings_to_defaults', {
        p_backup: true,
      });

      if (error) throw error;

      toast({
        title: 'Settings Reset',
        description: 'All settings have been reset to defaults. A backup was created.',
      });

      await loadSettings();
      await loadAuditLogs();
    } catch (error) {
      console.error('Error resetting settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to reset settings',
        variant: 'destructive',
      });
    }
  };

  // Undo last change
  const undoLastChange = async () => {
    try {
      const { error } = await supabase.rpc('undo_last_setting_change');

      if (error) throw error;

      toast({
        title: 'Change Undone',
        description: 'Last change has been reverted',
      });

      await loadSettings();
      await loadAuditLogs();
    } catch (error) {
      console.error('Error undoing change:', error);
      toast({
        title: 'Error',
        description: 'Failed to undo change',
        variant: 'destructive',
      });
    }
  };

  // Render setting input based on type
  const renderSettingInput = (setting: Setting) => {
    const currentValue = pendingChanges[setting.setting_key] !== undefined
      ? pendingChanges[setting.setting_key]
      : setting.setting_value;

    const onChange = (value: any) => {
      updateSetting(setting.setting_key, value);
    };
    
    const hasChanged = pendingChanges[setting.setting_key] !== undefined;

    switch (setting.value_type) {
      case 'boolean':
        return (
          <div className="flex items-center gap-2">
            <Switch
              checked={currentValue === true || currentValue === 'true'}
              onCheckedChange={onChange}
            />
            {hasChanged && <Badge variant="secondary" className="text-xs">Modified</Badge>}
          </div>
        );

      case 'number':
        return (
          <div className="flex items-center gap-2">
            <Input
              type="number"
              value={currentValue}
              onChange={(e) => onChange(Number(e.target.value))}
              className={cn("max-w-xs", hasChanged && "border-primary")}
            />
            {hasChanged && <Badge variant="secondary" className="text-xs">Modified</Badge>}
          </div>
        );

      case 'color':
        return (
          <div className="flex items-center gap-2">
            <Input
              type="color"
              value={currentValue}
              onChange={(e) => onChange(e.target.value)}
              className="w-20 h-10"
            />
            <Input
              type="text"
              value={currentValue}
              onChange={(e) => onChange(e.target.value)}
              className={cn("max-w-xs", hasChanged && "border-primary")}
            />
            {hasChanged && <Badge variant="secondary" className="text-xs">Modified</Badge>}
          </div>
        );

      case 'array':
        return (
          <div className="flex items-center gap-2">
            <Input
              value={Array.isArray(currentValue) ? currentValue.join(', ') : currentValue}
              onChange={(e) => onChange(e.target.value.split(',').map((v: string) => v.trim()))}
              placeholder="Comma-separated values"
              className={cn("max-w-md", hasChanged && "border-primary")}
            />
            {hasChanged && <Badge variant="secondary" className="text-xs">Modified</Badge>}
          </div>
        );

      case 'json':
        return (
          <div className="space-y-2">
            <textarea
              value={typeof currentValue === 'string' ? currentValue : JSON.stringify(currentValue, null, 2)}
              onChange={(e) => {
                try {
                  onChange(JSON.parse(e.target.value));
                } catch {
                  onChange(e.target.value);
                }
              }}
              className={cn("w-full min-h-[100px] p-2 border rounded-md font-mono text-sm", hasChanged && "border-primary")}
            />
            {hasChanged && <Badge variant="secondary" className="text-xs">Modified</Badge>}
          </div>
        );

      default:
        return (
          <div className="flex items-center gap-2">
            <Input
              type="text"
              value={currentValue}
              onChange={(e) => onChange(e.target.value)}
              className={cn("max-w-md", hasChanged && "border-primary")}
            />
            {hasChanged && <Badge variant="secondary" className="text-xs">Modified</Badge>}
          </div>
        );
    }
  };

  const clearCache = async () => {
    try {
      setIsClearing(true);
      await new Promise(resolve => setTimeout(resolve, 1000));
      window.location.reload();
      toast({
        title: "Cache Cleared",
        description: "Application cache has been cleared and page will reload",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear cache",
        variant: "destructive",
      });
    } finally {
      setIsClearing(false);
    }
  };

  const runMaintenance = async () => {
    try {
      setIsRunningMaintenance(true);
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast({
        title: "Maintenance Complete",
        description: "Database maintenance tasks completed successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to run maintenance tasks",
        variant: "destructive",
      });
    } finally {
      setIsRunningMaintenance(false);
    }
  };

  const recalculateJobDurations = async () => {
    try {
      setIsRecalculating(true);
      toast({
        title: "Recalculation Started",
        description: "Recalculating durations for all jobs. This may take a few minutes...",
      });

      const { data, error } = await supabase.functions.invoke('recalculate-job-durations');

      if (error) throw error;

      toast({
        title: "Recalculation Complete",
        description: `Updated ${data.updated} jobs. Failed: ${data.failed}, Skipped: ${data.skipped}`,
      });
    } catch (error) {
      console.error('Error recalculating durations:', error);
      toast({
        title: "Error",
        description: "Failed to recalculate job durations. Check console for details.",
        variant: "destructive",
      });
    } finally {
      setIsRecalculating(false);
    }
  };

  const categories = Array.from(new Set(settings.map((s) => s.category)));

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Advanced Settings
                {Object.keys(pendingChanges).length > 0 && (
                  <Badge variant="default" className="ml-2">
                    {Object.keys(pendingChanges).length} Unsaved
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Make changes to settings and click Save to apply them permanently
              </CardDescription>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button 
                size="sm" 
                onClick={saveAllChanges}
                disabled={Object.keys(pendingChanges).length === 0}
                className={cn(
                  Object.keys(pendingChanges).length > 0 && "animate-pulse"
                )}
              >
                <Save className="h-4 w-4 mr-2" />
                Save Changes
                {Object.keys(pendingChanges).length > 0 && ` (${Object.keys(pendingChanges).length})`}
              </Button>

              <Button 
                variant="outline" 
                size="sm" 
                onClick={discardChanges}
                disabled={Object.keys(pendingChanges).length === 0}
              >
                <Undo2 className="h-4 w-4 mr-2" />
                Discard Changes
              </Button>

              <Button 
                variant="outline" 
                size="sm" 
                onClick={undoLastChange}
              >
                <Undo2 className="h-4 w-4 mr-2" />
                Undo Last Saved Change
              </Button>

              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset All
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Reset All Settings?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will reset all settings to their default values. A backup will be created automatically.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={resetToDefaults}>
                      Reset All Settings
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Search and Filter */}
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search settings by key, description, or category..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[200px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {Object.keys(pendingChanges).length > 0 && (
            <div className="p-4 rounded-md border-2 bg-primary/10 border-primary transition-all">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-semibold">
                    {Object.keys(pendingChanges).length} Pending Changes
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    Changes will not be saved until you click "Save Changes" button.
                  </p>
                </div>
                <div className="flex gap-2">
                  <Button 
                    variant="outline"
                    size="sm" 
                    onClick={discardChanges}
                  >
                    Discard
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={saveAllChanges}
                  >
                    <Save className="h-4 w-4 mr-2" />
                    Save All
                  </Button>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Settings Content */}
      <Tabs defaultValue="settings" className="space-y-4">
        <TabsList>
          <TabsTrigger value="settings">All Settings</TabsTrigger>
          <TabsTrigger value="audit">Audit Log</TabsTrigger>
        </TabsList>

        <TabsContent value="settings" className="space-y-4">
          <ScrollArea className="h-[calc(100vh-400px)]">
            {Object.entries(groupedSettings).map(([category, subcategories]) => (
              <Card key={category} className="mb-4">
                <CardHeader>
                  <CardTitle className="text-lg">{category}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {Object.entries(subcategories).map(([subcategory, categorySettings]) => (
                    <Collapsible
                      key={`${category}-${subcategory}`}
                      open={expandedCategories[`${category}-${subcategory}`] !== false}
                      onOpenChange={(open) =>
                        setExpandedCategories((prev) => ({
                          ...prev,
                          [`${category}-${subcategory}`]: open,
                        }))
                      }
                    >
                      <CollapsibleTrigger className="flex items-center justify-between w-full p-3 hover:bg-muted/50 rounded-md">
                        <div className="flex items-center gap-2">
                          {expandedCategories[`${category}-${subcategory}`] !== false ? (
                            <ChevronDown className="h-4 w-4" />
                          ) : (
                            <ChevronRight className="h-4 w-4" />
                          )}
                          <span className="font-medium">{subcategory}</span>
                          <Badge variant="secondary">{categorySettings.length}</Badge>
                        </div>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-4 mt-4 ml-6">
                        {categorySettings.map((setting) => (
                          <div
                            key={setting.id}
                            className={cn(
                              'p-4 border rounded-lg space-y-2',
                              pendingChanges[setting.setting_key] !== undefined &&
                                'border-primary bg-primary/5'
                            )}
                          >
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <Label className="font-mono text-sm">{setting.setting_key}</Label>
                                  <Badge variant="outline">{setting.value_type}</Badge>
                                  {!setting.is_global && (
                                    <Badge variant="secondary">User Override</Badge>
                                  )}
                                </div>
                                {setting.description && (
                                  <p className="text-sm text-muted-foreground mt-1">
                                    {setting.description}
                                  </p>
                                )}
                              </div>
                            </div>
                            <div className="mt-2">{renderSettingInput(setting)}</div>
                            <div className="text-xs text-muted-foreground">
                              Last updated: {new Date(setting.updated_at).toLocaleString()}
                            </div>
                          </div>
                        ))}
                      </CollapsibleContent>
                    </Collapsible>
                  ))}
                </CardContent>
              </Card>
            ))}
          </ScrollArea>
        </TabsContent>

        <TabsContent value="audit">
          <Card>
            <CardHeader>
              <CardTitle>Settings Audit Log</CardTitle>
              <CardDescription>Complete history of all settings changes</CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-[500px]">
                <div className="space-y-2">
                  {auditLogs.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No audit logs available</p>
                  ) : (
                    auditLogs.map((log) => (
                      <div key={log.id} className="p-3 border rounded-lg text-sm space-y-1">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge>{log.action}</Badge>
                            <span className="font-mono">{log.setting_key}</span>
                          </div>
                          <span className="text-muted-foreground text-xs">
                            {new Date(log.created_at).toLocaleString()}
                          </span>
                        </div>
                        {log.change_reason && (
                          <p className="text-muted-foreground">{log.change_reason}</p>
                        )}
                        {log.old_value && log.new_value && (
                          <div className="mt-2 text-xs">
                            <span className="text-muted-foreground">
                              {JSON.stringify(log.old_value)} → {JSON.stringify(log.new_value)}
                            </span>
                          </div>
                        )}
                      </div>
                    ))
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* System Maintenance Section - Super Admin Only */}
      {hasSuperAdminAccess && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Database className="h-5 w-5" />
              <span>System Maintenance</span>
            </CardTitle>
            <CardDescription>
              Perform system maintenance and optimization tasks (Super Admin Only)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={clearCache} 
                variant="outline"
                disabled={isClearing}
              >
                {isClearing ? (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                    Clearing...
                  </>
                ) : (
                  <>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Clear Cache
                  </>
                )}
              </Button>
              <Button 
                onClick={runMaintenance} 
                variant="outline"
                disabled={isRunningMaintenance}
              >
                {isRunningMaintenance ? (
                  <>
                    <Database className="h-4 w-4 mr-2 animate-spin" />
                    Running...
                  </>
                ) : (
                  <>
                    <Database className="h-4 w-4 mr-2" />
                    Run Maintenance
                  </>
                )}
              </Button>
              <Button 
                onClick={recalculateJobDurations} 
                variant="outline"
                disabled={isRecalculating}
              >
                {isRecalculating ? (
                  <>
                    <Clock className="h-4 w-4 mr-2 animate-spin" />
                    Recalculating...
                  </>
                ) : (
                  <>
                    <Clock className="h-4 w-4 mr-2" />
                    Recalculate Job Durations
                  </>
                )}
              </Button>
            </div>
            <div className="space-y-2 text-sm text-muted-foreground">
              <p><strong>Clear Cache:</strong> Clears application cache and reloads the page</p>
              <p><strong>Run Maintenance:</strong> Performs database optimization and cleanup tasks</p>
              <p><strong>Recalculate Job Durations:</strong> Updates estimated_duration for all jobs using current route data from Google Maps. This fixes inaccurate or missing duration values.</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
