import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, FileText } from "lucide-react";
import { toast } from "sonner";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface W9Record {
  id: string;
  user_id: string;
  form_data: any;
  pdf_url: string | null;
  status: 'pending' | 'approved' | 'rejected';
  submitted_at: string;
  approved_at: string | null;
  approved_by: string | null;
}

export function W9Management() {
  const [w9Records, setW9Records] = useState<W9Record[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadW9Records();
  }, []);

  const loadW9Records = async () => {
    try {
      const { data, error } = await supabase
        .from("w9_forms")
        .select("*")
        .order("submitted_at", { ascending: false });

      if (error) throw error;
      setW9Records(data || []);
    } catch (error: any) {
      console.error("Error loading W-9 records:", error);
      toast.error("Failed to load W-9 records");
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return <div>Loading W-9 records...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-3">
          <FileText className="h-6 w-6" />
          <CardTitle>W-9 Form Submissions</CardTitle>
        </div>
      </CardHeader>
      <CardContent>
        {w9Records.length === 0 ? (
          <p className="text-muted-foreground">No W-9 forms submitted yet.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Business Name</TableHead>
                <TableHead>Tax ID</TableHead>
                <TableHead>Classification</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {w9Records.map((record) => {
                const formData = record.form_data || {};
                return (
                  <TableRow key={record.id}>
                    <TableCell className="font-medium">{formData.business_name || "N/A"}</TableCell>
                    <TableCell>{formData.tax_id ? `***-**-${formData.tax_id.slice(-4)}` : "—"}</TableCell>
                    <TableCell>{formData.tax_classification || "—"}</TableCell>
                    <TableCell>{new Date(record.submitted_at).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <span className={record.status === 'approved' ? 'text-green-600' : record.status === 'rejected' ? 'text-red-600' : 'text-muted-foreground'}>
                        {record.status === 'approved' ? '✓ Approved' : record.status === 'rejected' ? '✗ Rejected' : 'Pending'}
                      </span>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
}
