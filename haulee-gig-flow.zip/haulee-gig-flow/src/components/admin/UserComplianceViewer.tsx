import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Shield, FileText, AlertCircle, CheckCircle2, Clock, Download, Eye, Building2, Truck, Users } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

interface DriverComplianceRecord {
  id: string;
  driver_name: string;
  cdl_status: string;
  cdl_expiry_date: string | null;
  cdl_document_path: string | null;
  medical_status: string;
  medical_expiry_date: string | null;
  medical_document_path: string | null;
  hazmat_status: string;
  hazmat_expiry_date: string | null;
  hazmat_document_path: string | null;
  compliance_score: number;
  created_at: string;
  updated_at: string;
}

interface ComplianceDocument {
  id: string;
  document_type: string;
  document_name: string;
  document_category: string;
  file_path: string | null;
  status: string;
  issue_date: string | null;
  expiry_date: string | null;
  policy_number: string | null;
  issuing_authority: string | null;
  coverage_amount: number | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface UserComplianceViewerProps {
  userId: string;
  userRole: string;
}

export const UserComplianceViewer: React.FC<UserComplianceViewerProps> = ({ userId, userRole }) => {
  const [loading, setLoading] = useState(true);
  const [driverCompliance, setDriverCompliance] = useState<DriverComplianceRecord[]>([]);
  const [complianceDocuments, setComplianceDocuments] = useState<ComplianceDocument[]>([]);

  useEffect(() => {
    fetchAllCompliance();
  }, [userId]);

  const fetchAllCompliance = async () => {
    try {
      // Fetch driver compliance (for drivers and carriers)
      const { data: driverData, error: driverError } = await supabase
        .from('driver_compliance')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (driverError) throw driverError;
      setDriverCompliance(driverData || []);

      // Fetch general compliance documents (for all roles)
      const { data: docsData, error: docsError } = await supabase
        .from('compliance_documents')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false });

      if (docsError) throw docsError;
      setComplianceDocuments(docsData || []);
    } catch (error) {
      console.error('Error fetching compliance:', error);
      toast.error('Failed to load compliance records');
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (filePath: string, bucket: string = 'driver-compliance') => {
    try {
      const { data, error } = await supabase.storage
        .from(bucket)
        .createSignedUrl(filePath, 60);

      if (error) throw error;
      if (data?.signedUrl) {
        window.open(data.signedUrl, '_blank');
      }
    } catch (error) {
      console.error('Error downloading document:', error);
      toast.error('Failed to download document');
    }
  };

  const getStatusBadge = (status: string) => {
    const statusColors = {
      valid: 'bg-green-500',
      expiring: 'bg-yellow-500',
      expired: 'bg-red-500',
      'n/a': 'bg-gray-400',
    };

    const statusIcons = {
      valid: <CheckCircle2 className="h-3 w-3 mr-1" />,
      expiring: <Clock className="h-3 w-3 mr-1" />,
      expired: <AlertCircle className="h-3 w-3 mr-1" />,
      'n/a': null,
    };

    return (
      <Badge className={statusColors[status as keyof typeof statusColors] || 'bg-gray-500'}>
        {statusIcons[status as keyof typeof statusIcons]}
        {status}
      </Badge>
    );
  };

  const calculateOverallStats = () => {
    let validCount = 0;
    let expiringCount = 0;
    let expiredCount = 0;
    let totalScore = 0;
    let scoreCount = 0;

    // Count driver compliance
    driverCompliance.forEach(record => {
      [record.cdl_status, record.medical_status, record.hazmat_status].forEach(status => {
        if (status === 'valid') validCount++;
        if (status === 'expiring') expiringCount++;
        if (status === 'expired') expiredCount++;
      });
      totalScore += record.compliance_score || 0;
      scoreCount++;
    });

    // Count general compliance documents
    complianceDocuments.forEach(doc => {
      if (doc.status === 'valid') validCount++;
      if (doc.status === 'expiring') expiringCount++;
      if (doc.status === 'expired') expiredCount++;
      
      // Calculate score based on status
      if (doc.status === 'valid') totalScore += 100;
      else if (doc.status === 'expiring') totalScore += 70;
      else if (doc.status === 'expired') totalScore += 0;
      scoreCount++;
    });

    const avgScore = scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0;

    return {
      valid: validCount,
      expiring: expiringCount,
      expired: expiredCount,
      avgScore,
    };
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-muted-foreground">Loading compliance records...</div>
      </div>
    );
  }

  if (driverCompliance.length === 0 && complianceDocuments.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Shield className="h-16 w-16 mx-auto mb-4 text-muted-foreground/40" />
          <p className="text-lg font-medium text-muted-foreground">No compliance records</p>
          <p className="text-sm text-muted-foreground mt-2">This user has no compliance records</p>
        </CardContent>
      </Card>
    );
  }

  const stats = calculateOverallStats();

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Valid Documents</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{stats.valid}</div>
            <p className="text-xs text-muted-foreground">All up to date</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Expiring Soon</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-500">{stats.expiring}</div>
            <p className="text-xs text-muted-foreground">Within 60 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Expired</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{stats.expired}</div>
            <p className="text-xs text-muted-foreground">Needs renewal</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg Compliance Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.avgScore}%</div>
            <Progress value={stats.avgScore} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Compliance Records */}
      <Tabs defaultValue="company" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="company">
            <Building2 className="h-4 w-4 mr-2" />
            Company Documents
          </TabsTrigger>
          <TabsTrigger value="drivers">
            <Truck className="h-4 w-4 mr-2" />
            Driver Certifications
          </TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="space-y-4 mt-4">
          {complianceDocuments.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <FileText className="h-16 w-16 mx-auto mb-4 text-muted-foreground/40" />
                <p className="text-lg font-medium text-muted-foreground">No company documents</p>
                <p className="text-sm text-muted-foreground mt-2">No compliance documents uploaded</p>
              </CardContent>
            </Card>
          ) : (
            complianceDocuments.map((doc) => (
              <Card key={doc.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Shield className="h-4 w-4 text-primary" />
                        <h4 className="font-semibold">{doc.document_name}</h4>
                      </div>
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Badge variant="outline" className="capitalize">
                          {doc.document_category}
                        </Badge>
                        <span>•</span>
                        <span className="capitalize">{doc.document_type.replace(/_/g, ' ')}</span>
                      </div>
                    </div>
                    {getStatusBadge(doc.status)}
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-sm mb-3">
                    {doc.expiry_date && (
                      <div>
                        <p className="text-muted-foreground">Expires</p>
                        <p className="font-medium">{format(new Date(doc.expiry_date), 'PP')}</p>
                      </div>
                    )}
                    {doc.issue_date && (
                      <div>
                        <p className="text-muted-foreground">Issued</p>
                        <p className="font-medium">{format(new Date(doc.issue_date), 'PP')}</p>
                      </div>
                    )}
                    {doc.policy_number && (
                      <div>
                        <p className="text-muted-foreground">Policy Number</p>
                        <p className="font-medium font-mono">{doc.policy_number}</p>
                      </div>
                    )}
                    {doc.issuing_authority && (
                      <div>
                        <p className="text-muted-foreground">Issuing Authority</p>
                        <p className="font-medium">{doc.issuing_authority}</p>
                      </div>
                    )}
                    {doc.coverage_amount && (
                      <div>
                        <p className="text-muted-foreground">Coverage Amount</p>
                        <p className="font-medium">${doc.coverage_amount.toLocaleString()}</p>
                      </div>
                    )}
                  </div>

                  {doc.notes && (
                    <div className="mb-3 p-2 bg-muted rounded text-sm">
                      <p className="text-muted-foreground">Notes:</p>
                      <p>{doc.notes}</p>
                    </div>
                  )}

                  {doc.file_path && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDownload(doc.file_path!, 'compliance-documents')}
                    >
                      <Download className="h-3 w-3 mr-1" />
                      Download Document
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        <TabsContent value="drivers" className="space-y-4 mt-4">
          {driverCompliance.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Users className="h-16 w-16 mx-auto mb-4 text-muted-foreground/40" />
                <p className="text-lg font-medium text-muted-foreground">No driver records</p>
                <p className="text-sm text-muted-foreground mt-2">No driver compliance records found</p>
              </CardContent>
            </Card>
          ) : (
            driverCompliance.map((record) => (
              <Card key={record.id}>
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-lg">{record.driver_name}</h4>
                      <p className="text-sm text-muted-foreground">
                        Last updated: {format(new Date(record.updated_at), 'PPp')}
                      </p>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <Badge variant="outline" className="text-lg">
                        Score: {record.compliance_score}%
                      </Badge>
                      <Progress value={record.compliance_score} className="w-24" />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {/* CDL */}
                    <div className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">CDL License</span>
                        {getStatusBadge(record.cdl_status)}
                      </div>
                      {record.cdl_expiry_date && (
                        <p className="text-xs text-muted-foreground">
                          Expires: {format(new Date(record.cdl_expiry_date), 'PP')}
                        </p>
                      )}
                      {record.cdl_document_path && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => handleDownload(record.cdl_document_path!)}
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      )}
                    </div>

                    {/* Medical */}
                    <div className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">Medical Card</span>
                        {getStatusBadge(record.medical_status)}
                      </div>
                      {record.medical_expiry_date && (
                        <p className="text-xs text-muted-foreground">
                          Expires: {format(new Date(record.medical_expiry_date), 'PP')}
                        </p>
                      )}
                      {record.medical_document_path && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => handleDownload(record.medical_document_path!)}
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      )}
                    </div>

                    {/* HAZMAT */}
                    <div className="border rounded-lg p-3 space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">HAZMAT</span>
                        {getStatusBadge(record.hazmat_status)}
                      </div>
                      {record.hazmat_expiry_date && (
                        <p className="text-xs text-muted-foreground">
                          Expires: {format(new Date(record.hazmat_expiry_date), 'PP')}
                        </p>
                      )}
                      {record.hazmat_document_path && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full"
                          onClick={() => handleDownload(record.hazmat_document_path!)}
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
