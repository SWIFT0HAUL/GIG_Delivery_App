import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle } from 'lucide-react';

interface LegacyAdminStubProps {
  componentName: string;
}

export const LegacyAdminStub: React.FC<LegacyAdminStubProps> = ({ componentName }) => {
  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-warning" />
            <CardTitle>Legacy Component</CardTitle>
          </div>
          <CardDescription>
            {componentName} is being migrated to the new RBAC system
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            This component references the old database schema and is temporarily disabled.
            Please use the new unified dashboard at <code className="bg-muted px-2 py-1 rounded">/dashboard</code>
          </p>
        </CardContent>
      </Card>
    </div>
  );
};