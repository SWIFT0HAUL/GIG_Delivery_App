import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { CheckSquare, Save, FileText, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

interface ChecklistItem {
  id: string;
  label: string;
  checkboxField: string;
  approvalField: string;
  notesField: string;
}

interface ChecklistSection {
  title: string;
  description?: string;
  items: ChecklistItem[];
}

interface UserPreActivationChecklistProps {
  preselectedUserId?: string;
  onSaveComplete?: () => void;
}

export const UserPreActivationChecklist: React.FC<UserPreActivationChecklistProps> = ({ 
  preselectedUserId,
  onSaveComplete 
}) => {
  const { user } = useAuth();
  const [selectedUserId, setSelectedUserId] = useState<string>(preselectedUserId || '');
  const [users, setUsers] = useState<any[]>([]);
  const [checklist, setChecklist] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [adminName, setAdminName] = useState('');
  const [checklistDate, setChecklistDate] = useState(new Date().toISOString().split('T')[0]);
  const [autoSaving, setAutoSaving] = useState(false);
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const sections: ChecklistSection[] = [
    {
      title: '1. Managerial Approval',
      description: 'Obtain necessary managerial approvals before activation',
      items: [
        { id: 'managerial_approval_checked', label: 'Managerial approval obtained', checkboxField: 'managerial_approval_checked', approvalField: 'managerial_approval_status', notesField: 'managerial_notes' },
      ],
    },
    {
      title: '2. Security Configuration',
      description: 'Configure security settings for the user account',
      items: [
        { id: 'strong_password_verified', label: 'Strong password requirement met', checkboxField: 'strong_password_verified', approvalField: 'password_approval', notesField: 'password_notes' },
        { id: 'mfa_configured', label: 'Multi-factor authentication configured', checkboxField: 'mfa_configured', approvalField: 'mfa_approval', notesField: 'mfa_notes' },
        { id: 'no_system_flags', label: 'No security flags or warnings', checkboxField: 'no_system_flags', approvalField: 'flags_approval', notesField: 'flags_notes' },
        { id: 'security_scan_complete', label: 'Security scan completed successfully', checkboxField: 'security_scan_complete', approvalField: 'security_approval', notesField: 'security_notes' },
      ],
    },
    {
      title: '3. User Communication',
      description: 'Ensure proper communication with the user',
      items: [
        { id: 'welcome_email_sent', label: 'Welcome email sent', checkboxField: 'welcome_email_sent', approvalField: 'welcome_email_approval', notesField: 'welcome_email_notes' },
        { id: 'first_login_instructions', label: 'First login instructions provided', checkboxField: 'first_login_instructions', approvalField: 'instructions_approval', notesField: 'instructions_notes' },
        { id: 'support_contact_provided', label: 'Support contact information provided', checkboxField: 'support_contact_provided', approvalField: 'support_approval', notesField: 'support_notes' },
      ],
    },
    {
      title: '4. Account Activation',
      description: 'Activate the user account in the system',
      items: [
        { id: 'all_checks_confirmed', label: 'All pre-activation checks confirmed complete', checkboxField: 'all_checks_confirmed', approvalField: 'checks_approval', notesField: 'checks_notes' },
        { id: 'account_activated', label: 'User account activated in system', checkboxField: 'account_activated', approvalField: 'activation_approval', notesField: 'activation_notes' },
        { id: 'activation_logged', label: 'Activation action logged', checkboxField: 'activation_logged', approvalField: 'log_approval', notesField: 'log_notes' },
        { id: 'permissions_assigned', label: 'Correct permissions assigned', checkboxField: 'permissions_assigned', approvalField: 'permissions_approval', notesField: 'permissions_notes' },
      ],
    },
    {
      title: '5. Post-Activation Verification',
      description: 'Verify activation was successful',
      items: [
        { id: 'login_tested', label: 'Login tested and successful', checkboxField: 'login_tested', approvalField: 'login_approval', notesField: 'login_notes' },
        { id: 'permissions_verified', label: 'User has correct permissions', checkboxField: 'permissions_verified', approvalField: 'permissions_verify_approval', notesField: 'permissions_verify_notes' },
        { id: 'activity_monitored', label: 'Initial activity monitored', checkboxField: 'activity_monitored', approvalField: 'activity_approval', notesField: 'activity_notes' },
        { id: 'user_feedback_collected', label: 'User feedback collected (if applicable)', checkboxField: 'user_feedback_collected', approvalField: 'feedback_approval', notesField: 'feedback_notes' },
      ],
    },
    {
      title: '6. Final Documentation & Audit',
      description: 'Complete final documentation and audit trail',
      items: [
        { id: 'checklist_complete', label: 'Activation checklist complete', checkboxField: 'checklist_complete', approvalField: 'complete_approval', notesField: 'complete_notes' },
        { id: 'audit_trail_created', label: 'Audit trail created and stored', checkboxField: 'audit_trail_created', approvalField: 'audit_approval', notesField: 'audit_notes' },
        { id: 'admin_sign_off', label: 'Admin sign-off recorded', checkboxField: 'admin_sign_off', approvalField: 'sign_off_approval', notesField: 'sign_off_notes' },
      ],
    },
  ];

  useEffect(() => {
    fetchUsers();
    fetchAdminName();
  }, []);

  useEffect(() => {
    if (selectedUserId) {
      loadChecklist();
    } else {
      setChecklist(null);
    }
  }, [selectedUserId]);

  const fetchUsers = async () => {
    try {
      // Get all users
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, email, role_key, created_at')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Get all users who already have pre-activation checklists
      const { data: existingChecklists, error: checklistsError } = await supabase
        .from('user_preactivation_checklists')
        .select('user_id');

      if (checklistsError) throw checklistsError;

      // Filter out users who already have checklists
      const usersWithChecklistIds = new Set(existingChecklists?.map(c => c.user_id) || []);
      const usersWithoutChecklists = profiles?.filter(user => !usersWithChecklistIds.has(user.id)) || [];

      setUsers(usersWithoutChecklists);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to load users');
    }
  };

  const fetchAdminName = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user?.id)
        .single();

      if (error) throw error;
      setAdminName(data?.full_name || 'Admin');
    } catch (error) {
      console.error('Error fetching admin name:', error);
    }
  };

  const loadChecklist = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('user_preactivation_checklists')
        .select('*')
        .eq('user_id', selectedUserId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setChecklist(data);
        setChecklistDate(data.checklist_date);
        if (data.admin_name) setAdminName(data.admin_name);
      } else {
        const newChecklist = {
          user_id: selectedUserId,
          admin_id: user?.id,
          admin_name: adminName,
          checklist_date: checklistDate,
        };
        setChecklist(newChecklist);
      }
    } catch (error) {
      console.error('Error loading checklist:', error);
      toast.error('Failed to load checklist');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckboxChange = (field: string, checked: boolean) => {
    setChecklist((prev: any) => ({ ...prev, [field]: checked }));
    triggerAutoSave();
  };

  const handleFieldChange = (field: string, value: string) => {
    setChecklist((prev: any) => ({ ...prev, [field]: value }));
    triggerAutoSave();
  };

  const triggerAutoSave = useCallback(() => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(() => {
      autoSaveChecklist();
    }, 1500);
  }, []);

  const autoSaveChecklist = async () => {
    if (!selectedUserId || !checklist) return;

    try {
      setAutoSaving(true);
      
      const allCheckboxFields = sections.flatMap(section => 
        section.items.map(item => item.checkboxField)
      );
      const allChecked = allCheckboxFields.every(field => checklist[field] === true);
      
      const allApprovalFields = sections.flatMap(section => 
        section.items.map(item => item.approvalField)
      );
      const allApprovalsSet = allApprovalFields.every(field => 
        checklist[field] && checklist[field].trim() !== ''
      );
      
      const finalStatus = (allChecked && allApprovalsSet) ? 'completed' : 'in_progress';
      
      const allowedFields = new Set<string>([
        ...sections.flatMap(section => section.items.map(item => item.checkboxField)),
        ...sections.flatMap(section => section.items.map(item => item.approvalField)),
        ...sections.flatMap(section => section.items.map(item => item.notesField)),
        'id'
      ]);

      const sanitized: Record<string, any> = {};
      for (const key of allowedFields) {
        if (key in checklist) sanitized[key] = (checklist as any)[key];
      }

      const checklistData = {
        ...sanitized,
        user_id: selectedUserId,
        admin_id: user?.id,
        admin_name: adminName,
        checklist_date: checklistDate,
        status: finalStatus,
        updated_at: new Date().toISOString(),
      };

      if (checklist?.id) {
        const { error } = await supabase
          .from('user_preactivation_checklists')
          .update(checklistData)
          .eq('id', checklist.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('user_preactivation_checklists')
          .insert(checklistData)
          .select()
          .single();

        if (error) throw error;
        setChecklist(data);
      }

      // If completed, show success and close
      if (finalStatus === 'completed') {
        toast.success('Checklist completed successfully!');
        setTimeout(() => {
          onSaveComplete?.();
        }, 500);
      }
    } catch (error: any) {
      console.error('Auto-save error:', error);
    } finally {
      setAutoSaving(false);
    }
  };

  const saveChecklist = async () => {
    if (!selectedUserId) {
      toast.error('Please select a user');
      return;
    }

    try {
      setLoading(true);
      toast.loading('Saving checklist...');
      
      // Check if all required checkboxes are checked
      const allCheckboxFields = sections.flatMap(section => 
        section.items.map(item => item.checkboxField)
      );
      const allChecked = allCheckboxFields.every(field => checklist[field] === true);
      
      // Check if all approval fields have a value (Yes, No, or N/A)
      const allApprovalFields = sections.flatMap(section => 
        section.items.map(item => item.approvalField)
      );
      const allApprovalsSet = allApprovalFields.every(field => 
        checklist[field] && checklist[field].trim() !== ''
      );
      
      // Automatically set status to completed if all checkboxes are checked AND all approvals are set
      const finalStatus = (allChecked && allApprovalsSet) ? 'completed' : 'in_progress';
      
      // Build a sanitized payload that only includes known DB columns
      const allowedFields = new Set<string>([
        ...sections.flatMap(section => section.items.map(item => item.checkboxField)),
        ...sections.flatMap(section => section.items.map(item => item.approvalField)),
        ...sections.flatMap(section => section.items.map(item => item.notesField)),
        'id'
      ]);

      const sanitized: Record<string, any> = {};
      for (const key of allowedFields) {
        if (key in checklist) sanitized[key] = (checklist as any)[key];
      }

      const checklistData = {
        ...sanitized,
        user_id: selectedUserId,
        admin_id: user?.id,
        admin_name: adminName,
        checklist_date: checklistDate,
        status: finalStatus,
        updated_at: new Date().toISOString(),
      };

      if (checklist?.id) {
        const { error } = await supabase
          .from('user_preactivation_checklists')
          .update(checklistData)
          .eq('id', checklist.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('user_preactivation_checklists')
          .insert(checklistData)
          .select()
          .single();

        if (error) throw error;
        setChecklist(data);
      }

      toast.dismiss();
      toast.success('Checklist saved successfully');
      
      // Close dialog/screen immediately after save
      onSaveComplete?.();
      
      // Reload checklist data in background
      await loadChecklist();
    } catch (error: any) {
      toast.dismiss();
      console.error('Error saving checklist:', error);
      
      // Check if it's a column not found error
      if (error?.message?.includes('Could not find')) {
        const match = error.message.match(/'([^']+)'/);
        if (match) {
          toast.error(`Database column missing: ${match[1]}. Please contact administrator.`);
        } else {
          toast.error('Some checklist fields are not configured in the database');
        }
      } else {
        toast.error('Failed to save checklist');
      }
    } finally {
      setLoading(false);
    }
  };

  const selectedUser = users.find((u) => u.id === selectedUserId);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckSquare className="h-6 w-6 text-primary" />
            User Activating Verification Checklist
          </CardTitle>
          <CardDescription>
            Streamlined checklist for approved users. Focuses on security setup, communication, and activation. 
            (Requires Pre-Approval checklist completion first)
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Header Section - Only show when not preselected */}
          {!preselectedUserId && (
            <div className="p-4 bg-muted/50 rounded-lg space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="user-select">Select User *</Label>
                  <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                    <SelectTrigger id="user-select">
                      <SelectValue placeholder="Choose a user..." />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((u) => (
                        <SelectItem key={u.id} value={u.id}>
                          {u.full_name || u.email} ({u.role_key})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-name">Admin Name</Label>
                  <Input
                    id="admin-name"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    placeholder="Enter admin name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="checklist-date">Date</Label>
                  <Input
                    id="checklist-date"
                    type="date"
                    value={checklistDate}
                    onChange={(e) => setChecklistDate(e.target.value)}
                  />
                </div>
              </div>

              {selectedUser && (
                <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-md">
                  <FileText className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <p className="font-medium">{selectedUser.full_name || 'No name'}</p>
                    <p className="text-sm text-muted-foreground">{selectedUser.email}</p>
                  </div>
                  <Badge variant="outline">{selectedUser.role_key}</Badge>
                </div>
              )}
            </div>
          )}

          {/* Purpose & Scope */}
          {selectedUserId && (
            <div className="space-y-4">
              <div className="border-l-4 border-primary pl-4 py-2 bg-muted/30 rounded-r">
                <h3 className="font-semibold text-lg mb-1">Purpose</h3>
                <p className="text-sm text-muted-foreground">
                  This streamlined activation checklist focuses on security configuration, user communication, 
                  and account activation steps. It assumes the Pre-Approval Verification Checklist has been completed, 
                  eliminating duplicate identity and documentation verifications.
                </p>
              </div>
              <div className="border-l-4 border-primary pl-4 py-2 bg-muted/30 rounded-r">
                <h3 className="font-semibold text-lg mb-1">Scope</h3>
                <p className="text-sm text-muted-foreground">
                  This checklist applies to approved users ready for system activation. It covers security setup, 
                  managerial approval, user communication, actual activation, and post-activation verification. 
                  Basic identity verification must be completed in the Pre-Approval checklist first.
                </p>
              </div>
            </div>
          )}

          {checklist && (
            <>
              {/* Checklist Sections */}
              <div className="space-y-8">
                {sections.map((section) => (
                  <div key={section.title} className="space-y-4">
                    <div>
                      <h3 className="text-lg font-semibold border-b pb-2">{section.title}</h3>
                      {section.description && (
                        <p className="text-sm text-muted-foreground mt-1">{section.description}</p>
                      )}
                    </div>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[40px]">Done</TableHead>
                          <TableHead>Verification Step</TableHead>
                          <TableHead className="w-[120px]">Status</TableHead>
                          <TableHead>Admin Notes</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {section.items.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>
                              <Checkbox
                                checked={checklist[item.checkboxField] || false}
                                onCheckedChange={(checked) =>
                                  handleCheckboxChange(item.checkboxField, checked as boolean)
                                }
                              />
                            </TableCell>
                            <TableCell className="font-medium">{item.label}</TableCell>
                            <TableCell>
                              <Select
                                value={checklist[item.approvalField] || ''}
                                onValueChange={(value) => handleFieldChange(item.approvalField, value)}
                              >
                                <SelectTrigger className="h-9">
                                  <SelectValue placeholder="—" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Yes">
                                    <span className="flex items-center gap-1">
                                      <CheckCircle2 className="h-3 w-3 text-green-600" /> Yes
                                    </span>
                                  </SelectItem>
                                  <SelectItem value="No">
                                    <span className="flex items-center gap-1">
                                      <AlertCircle className="h-3 w-3 text-red-600" /> No
                                    </span>
                                  </SelectItem>
                                  <SelectItem value="N/A">
                                    <span className="flex items-center justify-center w-full">N/A</span>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Textarea
                                value={checklist[item.notesField] || ''}
                                onChange={(e) => handleFieldChange(item.notesField, e.target.value)}
                                placeholder="Add notes..."
                                className="min-h-[60px]"
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ))}
              </div>

              {/* Save Button */}
              <div className="flex justify-end items-center gap-4 pt-6 border-t">
                {autoSaving && (
                  <Badge variant="secondary" className="text-xs">
                    Auto-saving...
                  </Badge>
                )}
                <Button onClick={saveChecklist} disabled={loading} size="lg">
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Saving...' : 'Save Checklist'}
                </Button>
              </div>
            </>
          )}

          {!selectedUserId && (
            <div className="text-center py-12 text-muted-foreground">
              <CheckSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Select a user to begin the activating verification checklist</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
