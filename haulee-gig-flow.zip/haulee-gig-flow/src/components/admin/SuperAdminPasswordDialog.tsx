import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Lock, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SuperAdminPasswordDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onVerified: () => void;
  action: string;
  description?: string;
}

export const SuperAdminPasswordDialog = ({
  open,
  onOpenChange,
  onVerified,
  action,
  description
}: SuperAdminPasswordDialogProps) => {
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleVerify = async () => {
    if (!password.trim()) {
      toast.error('Please enter your super admin password');
      return;
    }

    try {
      setLoading(true);

      // Call edge function to verify super admin password
      const { data, error } = await supabase.functions.invoke('verify-super-admin-action', {
        body: { password, action }
      });

      if (error) throw error;

      if (data?.verified) {
        toast.success('Super admin credentials verified');
        onVerified();
        onOpenChange(false);
        setPassword('');
      } else {
        toast.error('Invalid super admin password');
      }
    } catch (error: any) {
      console.error('Password verification error:', error);
      toast.error('Failed to verify credentials');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    setPassword('');
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-2 text-destructive mb-2">
            <AlertTriangle className="h-5 w-5" />
            <DialogTitle>Super Admin Authorization Required</DialogTitle>
          </div>
          <DialogDescription>
            {description || `This action requires super admin authorization: ${action}`}
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="password">Super Admin Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type="password"
                placeholder="Enter super admin password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !loading) {
                    handleVerify();
                  }
                }}
                className="pl-10"
                autoFocus
              />
            </div>
          </div>

          <div className="bg-muted p-3 rounded-md text-sm">
            <p className="font-medium mb-1">Security Notice:</p>
            <p className="text-muted-foreground">
              This action modifies or deletes protected data that is locked after user approval. 
              Only super administrators can perform this operation.
            </p>
          </div>
        </div>

        <DialogFooter>
          <Button
            variant="outline"
            onClick={handleCancel}
            disabled={loading}
          >
            Cancel
          </Button>
          <Button
            onClick={handleVerify}
            disabled={loading}
            className="bg-destructive hover:bg-destructive/90"
          >
            {loading ? 'Verifying...' : 'Verify & Proceed'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
