import React from 'react';
import { usePermissions } from '@/hooks/usePermissions';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ShieldX } from 'lucide-react';

interface PermissionGuardProps {
  permission: string | string[];
  children: React.ReactNode;
  fallback?: React.ReactNode;
  requireAll?: boolean; // If true, user needs ALL permissions. If false (default), user needs ANY permission
}

export const PermissionGuard: React.FC<PermissionGuardProps> = ({
  permission,
  children,
  fallback,
  requireAll = false
}) => {
  const { hasPermission, hasAnyPermission, loading, isSuperAdmin } = usePermissions();

  if (loading) {
    return <div className="animate-pulse bg-muted h-20 rounded-md" />;
  }

  // Super Admin always has access
  if (isSuperAdmin) {
    return <>{children}</>;
  }

  const permissions = Array.isArray(permission) ? permission : [permission];
  
  const hasAccess = requireAll 
    ? permissions.every(p => hasPermission(p))
    : hasAnyPermission(permissions);

  if (!hasAccess) {
    return fallback || (
      <Alert variant="destructive">
        <ShieldX className="h-4 w-4" />
        <AlertDescription>
          You don't have permission to access this feature.
        </AlertDescription>
      </Alert>
    );
  }

  return <>{children}</>;
};