import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Info } from 'lucide-react';
import { toast } from 'sonner';

interface SOPLinkProps {
  moduleName: string;
  className?: string;
}

interface LinkedDocument {
  id: string;
  document_name: string;
  version_number: string;
  file_path: string;
  description: string | null;
}

export const SOPLink: React.FC<SOPLinkProps> = ({ moduleName, className }) => {
  const [open, setOpen] = useState(false);
  const [document, setDocument] = useState<LinkedDocument | null>(null);
  const [loading, setLoading] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string>('');

  const fetchLinkedDocument = async () => {
    if (!open) return;
    
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('admin_documents')
        .select('id, document_name, version_number, file_path, description')
        .eq('linked_module', moduleName)
        .eq('category', 'sop')
        .eq('is_approved', true)
        .eq('is_archived', false)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setDocument(data);
        
        // Get signed URL
        const { data: urlData, error: urlError } = await supabase.storage
          .from('admin_docs')
          .createSignedUrl(data.file_path, 3600);

        if (urlError) throw urlError;
        setPdfUrl(urlData.signedUrl);

        // Log access
        await supabase.rpc('log_document_activity', {
          p_document_id: data.id,
          p_action: 'VIEW_LINKED',
          p_document_name: data.document_name,
          p_metadata: { module: moduleName },
        });
      }
    } catch (error) {
      console.error('Error loading SOP:', error);
      toast.error('Failed to load SOP document');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLinkedDocument();
  }, [open]);

  return (
    <>
      <Button
        variant="ghost"
        size="sm"
        className={className}
        onClick={() => setOpen(true)}
      >
        <Info className="h-4 w-4" />
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-5xl h-[80vh]">
          <DialogHeader>
            <DialogTitle>
              {document ? `${document.document_name} (v${document.version_number})` : 'Loading...'}
            </DialogTitle>
          </DialogHeader>
          {loading ? (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground">Loading SOP...</p>
            </div>
          ) : document && pdfUrl ? (
            <div className="flex-1 overflow-hidden">
              <iframe
                src={pdfUrl}
                className="w-full h-full rounded-md border"
                title="SOP Document"
              />
            </div>
          ) : (
            <div className="flex items-center justify-center h-full">
              <p className="text-muted-foreground">
                No SOP document linked to this module. Visit the Documentation Center to add one.
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
