import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Database, RefreshCw, CheckCircle, AlertCircle, Info } from 'lucide-react';

interface ProcessResult {
  success: boolean;
  updated_fields?: string[];
  error?: string;
  extracted_data?: any;
}

interface KYCDataProcessorProps {
  userId?: string;
  userEmail?: string;
  onComplete?: () => void;
}

export function KYCDataProcessor({ userId, userEmail, onComplete }: KYCDataProcessorProps) {
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);
  const [result, setResult] = useState<ProcessResult | null>(null);

  const handleProcess = async () => {
    if (!userId) {
      toast({
        title: "Error",
        description: "No user selected",
        variant: "destructive"
      });
      return;
    }

    try {
      setProcessing(true);
      setResult(null);

      console.log('Processing KYC data for user:', userId);

      const { data, error } = await supabase.rpc('process_kyc_from_onboarding', {
        p_user_id: userId
      });

      if (error) {
        console.error('Error processing KYC data:', error);
        throw error;
      }

      console.log('Processing result:', data);
      setResult(data as unknown as ProcessResult);

      if (data && (data as any).success) {
        toast({
          title: "Success",
          description: `KYC data processed successfully for ${userEmail || 'user'}`
        });

        if (onComplete) {
          onComplete();
        }
      } else {
        toast({
          title: "Processing Failed",
          description: (data as any)?.error || "Failed to process KYC data",
          variant: "destructive"
        });
      }
    } catch (error: any) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to process KYC data",
        variant: "destructive"
      });
      setResult({
        success: false,
        error: error.message || "Unknown error"
      });
    } finally {
      setProcessing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          KYC Data Processor
        </CardTitle>
        <CardDescription>
          Extract KYC data from onboarding forms and populate database tables
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <Info className="h-4 w-4" />
          <AlertDescription>
            This tool extracts personal information, address, and document paths from onboarding data 
            and populates the <code className="bg-muted px-1 py-0.5 rounded">profiles</code> and <code className="bg-muted px-1 py-0.5 rounded">kyc_submissions</code> tables.
          </AlertDescription>
        </Alert>

        {userId && (
          <div className="space-y-2">
            <p className="text-sm font-medium">Selected User:</p>
            <div className="flex items-center gap-2">
              <Badge variant="outline">{userEmail || userId}</Badge>
            </div>
          </div>
        )}

        <Button 
          onClick={handleProcess} 
          disabled={processing || !userId}
          className="w-full"
        >
          {processing ? (
            <>
              <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
              Processing...
            </>
          ) : (
            <>
              <Database className="h-4 w-4 mr-2" />
              Process KYC Data
            </>
          )}
        </Button>

        {result && (
          <Alert className={result.success ? "border-green-500 bg-green-50" : "border-red-500 bg-red-50"}>
            {result.success ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription>
              {result.success ? (
                <div className="space-y-2">
                  <p className="font-medium text-green-800">Processing completed successfully!</p>
                  {result.updated_fields && result.updated_fields.length > 0 && (
                    <div>
                      <p className="text-sm text-green-700 mb-1">Updated fields:</p>
                      <div className="flex flex-wrap gap-1">
                        {result.updated_fields.map((field) => (
                          <Badge key={field} variant="outline" className="bg-green-100 text-green-800 border-green-300">
                            {field}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <p className="text-red-800 font-medium">{result.error || "Processing failed"}</p>
              )}
            </AlertDescription>
          </Alert>
        )}

        <Alert variant="default" className="bg-blue-50 border-blue-200">
          <Info className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>What this does:</strong>
            <ul className="list-disc list-inside mt-2 space-y-1 text-sm">
              <li>Extracts name, phone, and address from onboarding data</li>
              <li>Updates the user's profile with this information</li>
              <li>Creates/updates KYC submission with document paths</li>
              <li>Sets KYC status to "pending" for admin review</li>
            </ul>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
}
