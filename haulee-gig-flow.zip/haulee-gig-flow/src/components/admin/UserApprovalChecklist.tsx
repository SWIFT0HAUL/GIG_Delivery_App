import React, { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useUserRole } from '@/hooks/useUserRole';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { ClipboardCheck, Save, FileText, CheckCircle2, AlertCircle, Lock, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { SuperAdminPasswordDialog } from './SuperAdminPasswordDialog';

interface ChecklistItem {
  id: string;
  label: string;
  checkboxField: string;
  approvalField: string;
  notesField: string;
}

interface ChecklistSection {
  title: string;
  items: ChecklistItem[];
}

interface UserApprovalChecklistProps {
  preselectedUserId?: string;
  onSaveComplete?: () => void;
}

export const UserApprovalChecklist: React.FC<UserApprovalChecklistProps> = ({ 
  preselectedUserId,
  onSaveComplete 
}) => {
  const { user } = useAuth();
  const { isSuperAdmin } = useUserRole();
  const [selectedUserId, setSelectedUserId] = useState<string>(preselectedUserId || '');
  const [users, setUsers] = useState<any[]>([]);
  const [checklist, setChecklist] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [adminName, setAdminName] = useState('');
  const [checklistDate, setChecklistDate] = useState(new Date().toISOString().split('T')[0]);
  const [showPasswordDialog, setShowPasswordDialog] = useState(false);
  const [deleteAction, setDeleteAction] = useState<'delete' | null>(null);
  const [autoSaving, setAutoSaving] = useState(false);
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const sections: ChecklistSection[] = [
    {
      title: '1. Identity Verification',
      items: [
        { id: 'id_reviewed', label: 'Review ID/passport/business registration', checkboxField: 'id_reviewed', approvalField: 'id_approval', notesField: 'id_notes' },
        { id: 'name_verified', label: 'Verify name/DOB/registration', checkboxField: 'name_verified', approvalField: 'name_approval', notesField: 'name_notes' },
        { id: 'email_phone_verified', label: 'Confirm email/phone verification', checkboxField: 'email_phone_verified', approvalField: 'email_phone_approval', notesField: 'email_phone_notes' },
        { id: 'unique_account_verified', label: 'Ensure unique system account ID', checkboxField: 'unique_account_verified', approvalField: 'unique_account_approval', notesField: 'unique_account_notes' },
      ],
    },
    {
      title: '2. Profile Completeness Review',
      items: [
        { id: 'profile_fields_complete', label: 'Check all mandatory profile fields', checkboxField: 'profile_fields_complete', approvalField: 'profile_fields_approval', notesField: 'profile_fields_notes' },
        { id: 'profile_picture_valid', label: 'Profile picture/logo standards', checkboxField: 'profile_picture_valid', approvalField: 'profile_picture_approval', notesField: 'profile_picture_notes' },
        { id: 'documents_readable', label: 'Uploaded documents readability and validity', checkboxField: 'documents_readable', approvalField: 'documents_approval', notesField: 'documents_notes' },
      ],
    },
    {
      title: '3. Compliance & Role Validation',
      items: [
        { id: 'role_validated', label: 'Validate user role vs documentation', checkboxField: 'role_validated', approvalField: 'role_approval', notesField: 'role_notes' },
        { id: 'background_check_complete', label: 'Confirm background checks', checkboxField: 'background_check_complete', approvalField: 'background_check_approval', notesField: 'background_check_notes' },
        { id: 'legal_agreements_signed', label: 'Legal agreements signed', checkboxField: 'legal_agreements_signed', approvalField: 'legal_agreements_approval', notesField: 'legal_agreements_notes' },
        { id: 'payment_data_correct', label: 'Tax/payment data correct', checkboxField: 'payment_data_correct', approvalField: 'payment_data_approval', notesField: 'payment_data_notes' },
      ],
    },
    {
      title: '4. System Integrity Check',
      items: [
        { id: 'no_duplicates', label: 'Detect duplicate/conflicting accounts', checkboxField: 'no_duplicates', approvalField: 'no_duplicates_approval', notesField: 'no_duplicates_notes' },
        { id: 'unique_identifiers_verified', label: 'Verify unique identifiers', checkboxField: 'unique_identifiers_verified', approvalField: 'unique_identifiers_approval', notesField: 'unique_identifiers_notes' },
        { id: 'no_suspicious_activity', label: 'Review logs for suspicious behavior', checkboxField: 'no_suspicious_activity', approvalField: 'no_suspicious_activity_approval', notesField: 'no_suspicious_activity_notes' },
      ],
    },
    {
      title: '5. Admin Review & Final Approval',
      items: [
        { id: 'all_steps_complete', label: 'Ensure all steps complete', checkboxField: 'all_steps_complete', approvalField: 'all_steps_approval', notesField: 'all_steps_notes' },
        { id: 'approval_note_recorded', label: 'Record approval note', checkboxField: 'approval_note_recorded', approvalField: 'approval_note_approval', notesField: 'approval_note' },
        { id: 'user_approved_in_system', label: 'Approve user in system', checkboxField: 'user_approved_in_system', approvalField: 'user_approved_approval', notesField: 'user_approved_notes' },
        { id: 'status_changed', label: 'Confirm status changed to Approved', checkboxField: 'status_changed', approvalField: 'status_changed_approval', notesField: 'status_changed_notes' },
        { id: 'notification_sent', label: 'Notification sent', checkboxField: 'notification_sent', approvalField: 'notification_approval', notesField: 'notification_notes' },
        { id: 'activation_unlocked', label: 'Activation unlocked', checkboxField: 'activation_unlocked', approvalField: 'activation_approval', notesField: 'activation_notes' },
      ],
    },
    {
      title: '6. Audit & Notes',
      items: [
        { id: 'audit_complete', label: 'Log all actions', checkboxField: 'audit_complete', approvalField: 'audit_approval', notesField: 'audit_notes' },
        { id: 'documents_stored_securely', label: 'Store documents securely', checkboxField: 'documents_stored_securely', approvalField: 'documents_stored_approval', notesField: 'documents_stored_notes' },
        { id: 'incomplete_marked', label: 'Mark incomplete applications', checkboxField: 'incomplete_marked', approvalField: 'incomplete_approval', notesField: 'incomplete_notes' },
        { id: 'super_admin_reviewed', label: 'Super Admin audit', checkboxField: 'super_admin_reviewed', approvalField: 'super_admin_approval', notesField: 'super_admin_notes' },
      ],
    },
  ];

  useEffect(() => {
    fetchUsers();
    fetchAdminName();
  }, []);

  useEffect(() => {
    if (selectedUserId) {
      loadChecklist();
    } else {
      setChecklist(null);
    }
  }, [selectedUserId]);

  const fetchUsers = async () => {
    try {
      // Get all users
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, full_name, email, role_key, created_at')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Get all users who already have checklists
      const { data: existingChecklists, error: checklistsError } = await supabase
        .from('user_approval_checklists')
        .select('user_id');

      if (checklistsError) throw checklistsError;

      // Filter out users who already have checklists
      const usersWithChecklistIds = new Set(existingChecklists?.map(c => c.user_id) || []);
      const usersWithoutChecklists = profiles?.filter(user => !usersWithChecklistIds.has(user.id)) || [];

      setUsers(usersWithoutChecklists);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast.error('Failed to load users');
    }
  };

  const fetchAdminName = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user?.id)
        .single();

      if (error) throw error;
      setAdminName(data?.full_name || 'Admin');
    } catch (error) {
      console.error('Error fetching admin name:', error);
    }
  };

  const loadChecklist = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('user_approval_checklists')
        .select('*')
        .eq('user_id', selectedUserId)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setChecklist(data);
        setChecklistDate(data.checklist_date);
        if (data.admin_name) setAdminName(data.admin_name);
      } else {
        // Create new checklist
        const newChecklist = {
          user_id: selectedUserId,
          admin_id: user?.id,
          admin_name: adminName,
          checklist_date: checklistDate,
        };
        setChecklist(newChecklist);
      }
    } catch (error) {
      console.error('Error loading checklist:', error);
      toast.error('Failed to load checklist');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckboxChange = (field: string, checked: boolean) => {
    if (checklist?.locked && !isSuperAdmin()) {
      toast.error('This checklist is locked. Only super admins can modify locked checklists.');
      return;
    }
    setChecklist((prev: any) => ({ ...prev, [field]: checked }));
    triggerAutoSave();
  };

  const handleFieldChange = (field: string, value: string) => {
    if (checklist?.locked && !isSuperAdmin()) {
      toast.error('This checklist is locked. Only super admins can modify locked checklists.');
      return;
    }
    setChecklist((prev: any) => ({ ...prev, [field]: value }));
    triggerAutoSave();
  };

  const triggerAutoSave = useCallback(() => {
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(() => {
      autoSaveChecklist();
    }, 1500);
  }, []);

  const autoSaveChecklist = async () => {
    if (!selectedUserId || !checklist || checklist?.locked && !isSuperAdmin()) return;

    try {
      setAutoSaving(true);
      
      const allCheckboxFields = sections.flatMap(section => 
        section.items.map(item => item.checkboxField)
      );
      const allChecked = allCheckboxFields.every(field => checklist[field] === true);
      
      const allApprovalFields = sections.flatMap(section => 
        section.items.map(item => item.approvalField)
      );
      const allApprovalsSet = allApprovalFields.every(field => 
        checklist[field] && checklist[field].trim() !== ''
      );
      
      const finalStatus = (allChecked && allApprovalsSet) ? 'completed' : 'in_progress';
      
      const allowedFields = new Set<string>([
        ...sections.flatMap(section => section.items.map(item => item.checkboxField)),
        ...sections.flatMap(section => section.items.map(item => item.approvalField)),
        ...sections.flatMap(section => section.items.map(item => item.notesField)),
        'id'
      ]);

      const sanitized: Record<string, any> = {};
      for (const key of allowedFields) {
        if (key in checklist) sanitized[key] = (checklist as any)[key];
      }

      const checklistData = {
        ...sanitized,
        user_id: selectedUserId,
        admin_id: user?.id,
        admin_name: adminName,
        checklist_date: checklistDate,
        status: finalStatus,
        updated_at: new Date().toISOString(),
      };

      if (checklist?.id) {
        const { error } = await supabase
          .from('user_approval_checklists')
          .update(checklistData)
          .eq('id', checklist.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('user_approval_checklists')
          .insert(checklistData)
          .select()
          .single();

        if (error) throw error;
        setChecklist(data);
      }

      // If completed, show success and close
      if (finalStatus === 'completed') {
        toast.success('Checklist completed successfully!');
        setTimeout(() => {
          onSaveComplete?.();
        }, 500);
      }
    } catch (error: any) {
      console.error('Auto-save error:', error);
    } finally {
      setAutoSaving(false);
    }
  };

  const handleDeleteChecklist = () => {
    if (checklist?.locked && !isSuperAdmin()) {
      toast.error('Cannot delete locked checklist. Super admin authorization required.');
      return;
    }
    
    if (checklist?.locked) {
      // Require super admin password
      setDeleteAction('delete');
      setShowPasswordDialog(true);
    } else {
      // Direct delete for unlocked checklists
      performDelete();
    }
  };

  const performDelete = async () => {
    if (!checklist?.id) return;

    try {
      setLoading(true);
      const { error } = await supabase
        .from('user_approval_checklists')
        .delete()
        .eq('id', checklist.id);

      if (error) throw error;

      toast.success('Checklist deleted successfully');
      setChecklist(null);
      onSaveComplete?.();
    } catch (error: any) {
      console.error('Error deleting checklist:', error);
      toast.error('Failed to delete checklist: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordVerified = () => {
    if (deleteAction === 'delete') {
      performDelete();
    }
    setDeleteAction(null);
  };

  const saveChecklist = async () => {
    if (!selectedUserId) {
      toast.error('Please select a user');
      return;
    }

    // Check if locked and user is not super admin
    if (checklist?.locked && !isSuperAdmin()) {
      toast.error('This checklist is locked. Only super admins can modify locked checklists.');
      return;
    }

    try {
      setLoading(true);
      toast.loading('Saving checklist...');
      
      // Check if all required checkboxes are checked
      const allCheckboxFields = sections.flatMap(section => 
        section.items.map(item => item.checkboxField)
      );
      const allChecked = allCheckboxFields.every(field => checklist[field] === true);
      
      // Check if all approval fields have a value (Yes, No, or N/A)
      const allApprovalFields = sections.flatMap(section => 
        section.items.map(item => item.approvalField)
      );
      const allApprovalsSet = allApprovalFields.every(field => 
        checklist[field] && checklist[field].trim() !== ''
      );
      
      // Automatically set status to completed if all checkboxes are checked AND all approvals are set
      const finalStatus = (allChecked && allApprovalsSet) ? 'completed' : 'in_progress';
      
      // Build a sanitized payload that only includes known DB columns
      const allowedFields = new Set<string>([
        ...sections.flatMap(section => section.items.map(item => item.checkboxField)),
        ...sections.flatMap(section => section.items.map(item => item.approvalField)),
        ...sections.flatMap(section => section.items.map(item => item.notesField)),
        // Include id if present so updates work without removing it
        'id'
      ]);

      const sanitized: Record<string, any> = {};
      for (const key of allowedFields) {
        if (key in checklist) sanitized[key] = (checklist as any)[key];
      }

      const checklistData = {
        ...sanitized,
        user_id: selectedUserId,
        admin_id: user?.id,
        admin_name: adminName,
        checklist_date: checklistDate,
        status: finalStatus,
        updated_at: new Date().toISOString(),
      };

      if (checklist?.id) {
        // Update existing
        const { error } = await supabase
          .from('user_approval_checklists')
          .update(checklistData)
          .eq('id', checklist.id);

        if (error) throw error;
      } else {
        // Create new
        const { data, error } = await supabase
          .from('user_approval_checklists')
          .insert(checklistData)
          .select()
          .single();

        if (error) throw error;
        setChecklist(data);
      }

      toast.dismiss();
      toast.success('Checklist saved successfully');
      
      // Close dialog/screen immediately after save
      onSaveComplete?.();
      
      // Reload checklist data in background
      await loadChecklist();
    } catch (error: any) {
      toast.dismiss();
      console.error('Error saving checklist:', error);
      
      // Check if it's a column not found error
      if (error?.message?.includes('Could not find')) {
        const match = error.message.match(/'([^']+)'/);
        if (match) {
          toast.error(`Database column missing: ${match[1]}. Please contact administrator.`);
        } else {
          toast.error('Some checklist fields are not configured in the database');
        }
      } else {
        toast.error('Failed to save checklist');
      }
    } finally {
      setLoading(false);
    }
  };

  const selectedUser = users.find((u) => u.id === selectedUserId);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <ClipboardCheck className="h-6 w-6 text-primary" />
                User Pre-Approval Verification Checklist
                {checklist?.locked && (
                  <Badge variant="secondary" className="ml-2 bg-yellow-100 text-yellow-800 border-yellow-300">
                    <Lock className="h-3 w-3 mr-1" />
                    Locked
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                Complete this checklist for each user requiring approval
                {checklist?.locked && (
                  <span className="block mt-1 text-yellow-600">
                    This checklist is locked. Only super admins can modify or delete it.
                  </span>
                )}
              </CardDescription>
            </div>
            {checklist?.id && (
              <Button
                variant="destructive"
                size="sm"
                onClick={handleDeleteChecklist}
                disabled={loading}
              >
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Header Section - Only show when not preselected */}
          {!preselectedUserId && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-muted/50 rounded-lg">
                <div className="space-y-2">
                  <Label htmlFor="user-select">Select User *</Label>
                  <Select value={selectedUserId} onValueChange={setSelectedUserId}>
                    <SelectTrigger id="user-select">
                      <SelectValue placeholder="Choose a user..." />
                    </SelectTrigger>
                    <SelectContent>
                      {users.map((u) => (
                        <SelectItem key={u.id} value={u.id}>
                          {u.full_name || u.email} ({u.role_key})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="admin-name">Admin Name</Label>
                  <Input
                    id="admin-name"
                    value={adminName}
                    onChange={(e) => setAdminName(e.target.value)}
                    placeholder="Enter admin name"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="checklist-date">Date</Label>
                  <Input
                    id="checklist-date"
                    type="date"
                    value={checklistDate}
                    onChange={(e) => setChecklistDate(e.target.value)}
                  />
                </div>
              </div>

              {selectedUser && (
                <div className="flex items-center gap-2 p-3 bg-primary/10 rounded-md">
                  <FileText className="h-5 w-5 text-primary" />
                  <div className="flex-1">
                    <p className="font-medium">{selectedUser.full_name || 'No name'}</p>
                    <p className="text-sm text-muted-foreground">{selectedUser.email}</p>
                  </div>
                  <Badge variant="outline">{selectedUser.role_key}</Badge>
                </div>
              )}
            </>
          )}

          {/* Purpose & Scope */}
          {selectedUserId && (
            <div className="space-y-4">
              <div className="border-l-4 border-primary pl-4 py-2 bg-muted/30 rounded-r">
                <h3 className="font-semibold text-lg mb-1">Purpose</h3>
                <p className="text-sm text-muted-foreground">
                  This checklist ensures that all necessary verifications, security checks, and compliance requirements 
                  are completed before a user account is approved, maintaining platform integrity and security standards.
                </p>
              </div>
              <div className="border-l-4 border-primary pl-4 py-2 bg-muted/30 rounded-r">
                <h3 className="font-semibold text-lg mb-1">Scope</h3>
                <p className="text-sm text-muted-foreground">
                  This checklist applies to all new user registrations requiring admin approval before account activation. 
                  It must be completed by an authorized administrator before granting system access.
                </p>
              </div>
            </div>
          )}

          {checklist && (
            <>
              {/* Checklist Sections */}
              <div className="space-y-8">
                {sections.map((section) => (
                  <div key={section.title} className="space-y-4">
                    <h3 className="text-lg font-semibold border-b pb-2">{section.title}</h3>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-[40px]">Done</TableHead>
                          <TableHead>Step</TableHead>
                          <TableHead className="w-[120px]">Approval</TableHead>
                          <TableHead>Admin Notes</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {section.items.map((item) => (
                          <TableRow key={item.id}>
                          <TableCell>
                              <Checkbox
                                checked={checklist[item.checkboxField] || false}
                                onCheckedChange={(checked) =>
                                  handleCheckboxChange(item.checkboxField, checked as boolean)
                                }
                                disabled={checklist?.locked && !isSuperAdmin()}
                              />
                            </TableCell>
                            <TableCell className="font-medium">{item.label}</TableCell>
                            <TableCell>
                              <Select
                                value={checklist[item.approvalField] || ''}
                                onValueChange={(value) => handleFieldChange(item.approvalField, value)}
                                disabled={checklist?.locked && !isSuperAdmin()}
                              >
                                <SelectTrigger className="h-9">
                                  <SelectValue placeholder="—" />
                                </SelectTrigger>
                                <SelectContent>
                                  <SelectItem value="Yes">
                                    <span className="flex items-center gap-1">
                                      <CheckCircle2 className="h-3 w-3 text-green-600" /> Yes
                                    </span>
                                  </SelectItem>
                                  <SelectItem value="No">
                                    <span className="flex items-center gap-1">
                                      <AlertCircle className="h-3 w-3 text-red-600" /> No
                                    </span>
                                  </SelectItem>
                                  <SelectItem value="N/A">
                                    <span className="flex items-center justify-center w-full">N/A</span>
                                  </SelectItem>
                                </SelectContent>
                              </Select>
                            </TableCell>
                            <TableCell>
                              <Textarea
                                value={checklist[item.notesField] || ''}
                                onChange={(e) => handleFieldChange(item.notesField, e.target.value)}
                                placeholder="Add notes..."
                                className="min-h-[60px]"
                                disabled={checklist?.locked && !isSuperAdmin()}
                              />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ))}
              </div>

              {/* Save Button */}
              <div className="flex justify-end items-center gap-4 pt-6 border-t">
                {autoSaving && (
                  <Badge variant="secondary" className="text-xs">
                    Auto-saving...
                  </Badge>
                )}
                <Button 
                  onClick={saveChecklist} 
                  disabled={loading || (checklist?.locked && !isSuperAdmin())} 
                  size="lg"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {loading ? 'Saving...' : 'Save Checklist'}
                </Button>
              </div>
            </>
          )}

          {!selectedUserId && (
            <div className="text-center py-12 text-muted-foreground">
              <ClipboardCheck className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Select a user to begin the pre-approval verification checklist</p>
            </div>
          )}
        </CardContent>
      </Card>

      <SuperAdminPasswordDialog
        open={showPasswordDialog}
        onOpenChange={setShowPasswordDialog}
        onVerified={handlePasswordVerified}
        action={deleteAction === 'delete' ? 'Delete Locked Approval Checklist' : ''}
        description="This checklist is locked because the user has been approved. Deleting it requires super admin authorization."
      />
    </div>
  );
};
