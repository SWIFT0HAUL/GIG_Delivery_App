import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { Plus, Trash2, Check, ListPlus, UserPlus, Users } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Task {
  id: string;
  name: string;
  description: string;
  category: string;
  priority: string;
  required: boolean;
}

interface TemplateTask extends Task {
  display_order: number;
  template_id: string;
}

interface User {
  id: string;
  email: string;
  full_name: string | null;
  role_key: string;
}

export function DefaultTaskTemplates() {
  const [selectedRole, setSelectedRole] = useState<string>('driver');
  const [availableTasks, setAvailableTasks] = useState<Task[]>([]);
  const [templateTasks, setTemplateTasks] = useState<TemplateTask[]>([]);
  const [loading, setLoading] = useState(false);
  const [applyDialogOpen, setApplyDialogOpen] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [userSearchQuery, setUserSearchQuery] = useState('');

  const roles = [
    { value: 'independent_driver', label: 'Independent Driver' },
    { value: 'carrier_driver', label: 'Carrier Driver' },
    { value: 'carrier', label: 'Carrier' },
    { value: 'shipper', label: 'Shipper' },
    { value: 'broker', label: 'Broker' },
    { value: 'vendor', label: 'Vendor' },
    { value: 'vendor_merchant', label: 'Vendor Merchant' },
    { value: 'admin', label: 'Admin' },
  ];

  useEffect(() => {
    fetchAvailableTasks();
  }, []);

  useEffect(() => {
    if (selectedRole) {
      fetchTemplateTasks();
      fetchUsers();
    }
  }, [selectedRole]);

  const fetchAvailableTasks = async () => {
    try {
      const { data, error } = await supabase
        .from('custom_tasks')
        .select('id, name, description, category, priority, required')
        .order('name');

      if (error) throw error;
      setAvailableTasks(data || []);
    } catch (error) {
      console.error('Error fetching tasks:', error);
      toast({
        title: "Error",
        description: "Failed to fetch available tasks",
        variant: "destructive",
      });
    }
  };

  const fetchTemplateTasks = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('default_task_templates')
        .select(`
          id,
          display_order,
          custom_tasks (
            id,
            name,
            description,
            category,
            priority,
            required
          )
        `)
        .eq('role_key', selectedRole)
        .order('display_order');

      if (error) throw error;

      const formatted: TemplateTask[] = (data || []).map((item: any) => ({
        id: item.custom_tasks.id,
        name: item.custom_tasks.name,
        description: item.custom_tasks.description,
        category: item.custom_tasks.category,
        priority: item.custom_tasks.priority,
        required: item.custom_tasks.required,
        display_order: item.display_order,
        template_id: item.id,
      }));

      setTemplateTasks(formatted);
    } catch (error) {
      console.error('Error fetching template tasks:', error);
      toast({
        title: "Error",
        description: "Failed to fetch template tasks",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleAddTask = async (taskId: string) => {
    try {
      const maxOrder = templateTasks.length > 0 
        ? Math.max(...templateTasks.map(t => t.display_order))
        : 0;

      const { error } = await supabase
        .from('default_task_templates')
        .insert({
          role_key: selectedRole,
          task_id: taskId,
          display_order: maxOrder + 1,
        });

      if (error) throw error;

      toast({
        title: "Task Added",
        description: "Task added to default template",
      });

      await fetchTemplateTasks();
    } catch (error: any) {
      console.error('Error adding task:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to add task to template",
        variant: "destructive",
      });
    }
  };

  const handleRemoveTask = async (templateId: string) => {
    try {
      const { error } = await supabase
        .from('default_task_templates')
        .delete()
        .eq('id', templateId);

      if (error) throw error;

      toast({
        title: "Task Removed",
        description: "Task removed from default template",
      });

      await fetchTemplateTasks();
    } catch (error) {
      console.error('Error removing task:', error);
      toast({
        title: "Error",
        description: "Failed to remove task from template",
        variant: "destructive",
      });
    }
  };

  const fetchUsers = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, email, full_name, role_key')
        .eq('role_key', selectedRole as any)
        .order('full_name');

      if (error) throw error;
      setUsers(data || []);
    } catch (error) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "Failed to fetch users",
        variant: "destructive",
      });
    }
  };

  const handleApplyTemplate = async () => {
    try {
      setLoading(true);

      if (selectedUserIds.length === 0) {
        toast({
          title: "No Users Selected",
          description: "Please select at least one user to assign tasks to",
          variant: "destructive",
        });
        return;
      }

      // Build task and user sets
      const taskIds = templateTasks.map((t) => t.id);

      if (taskIds.length === 0) {
        toast({
          title: "No Tasks in Template",
          description: "Add tasks to the template before assigning",
          variant: "destructive",
        });
        return;
      }

      // Fetch existing assignments in ONE query to avoid N x M requests
      const { data: existing, error: existingError } = await supabase
        .from('task_assignments')
        .select('user_id, task_id')
        .in('user_id', selectedUserIds)
        .in('task_id', taskIds);

      if (existingError) throw existingError;

      const existingSet = new Set((existing || []).map((e: any) => `${e.user_id}_${e.task_id}`));

      // Prepare rows to insert (skip existing)
      const rowsToInsert: any[] = [];
      for (const userId of selectedUserIds) {
        for (const taskId of taskIds) {
          const key = `${userId}_${taskId}`;
          if (!existingSet.has(key)) {
            rowsToInsert.push({
              user_id: userId,
              task_id: taskId,
              status: 'pending',
              approval_status: 'pending_approval',
            });
          }
        }
      }

      if (rowsToInsert.length > 0) {
        const { error: insertError } = await supabase
          .from('task_assignments')
          .insert(rowsToInsert);
        if (insertError) throw insertError;
      }

      toast({
        title: "Tasks Assigned",
        description: `Successfully assigned ${rowsToInsert.length} task(s) to ${selectedUserIds.length} user(s)`,
      });

      setApplyDialogOpen(false);
      setSelectedUserIds([]);
      setUserSearchQuery('');
    } catch (error) {
      console.error('Error applying template:', error);
      toast({
        title: "Error",
        description: "Failed to assign tasks",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredUsers = users.filter(user => {
    const searchLower = userSearchQuery.toLowerCase();
    return (
      user.email?.toLowerCase().includes(searchLower) ||
      user.full_name?.toLowerCase().includes(searchLower)
    );
  });

  const filteredIds = filteredUsers.map(u => u.id);
  const allFilteredSelected = filteredIds.length > 0 && filteredIds.every(id => selectedUserIds.includes(id));

  const toggleUserSelection = (userId: string) => {
    setSelectedUserIds(prev =>
      prev.includes(userId)
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const toggleAllUsers = () => {
    setSelectedUserIds(prev => {
      if (allFilteredSelected) {
        // Deselect only filtered users
        return prev.filter(id => !filteredIds.includes(id));
      }
      // Add missing filtered users to selection
      const set = new Set(prev);
      for (const id of filteredIds) set.add(id);
      return Array.from(set);
    });
  };

  const tasksNotInTemplate = availableTasks.filter(
    task => !templateTasks.find(tt => tt.id === task.id)
  );

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Default Task Templates</h2>
          <p className="text-muted-foreground">
            Manage default task lists per role that can be applied to all users
          </p>
        </div>
        <Dialog open={applyDialogOpen} onOpenChange={setApplyDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" disabled={templateTasks.length === 0}>
              <UserPlus className="w-4 h-4" />
              Assign to Users
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] p-0 flex flex-col gap-0">
            <DialogHeader className="px-6 pt-6 pb-4 space-y-2 border-b">
              <DialogTitle className="text-xl font-semibold">Assign Tasks to Users</DialogTitle>
              <DialogDescription className="text-sm">
                Select users to assign {templateTasks.length} task(s) from the {roles.find(r => r.value === selectedRole)?.label} template.
              </DialogDescription>
            </DialogHeader>

            <div className="flex-1 flex flex-col min-h-0 px-6 py-5 space-y-4">
              {/* Stats Bar */}
              <div className="flex items-center justify-between p-3 bg-muted/30 rounded-lg border">
                <div className="flex items-center gap-6">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                      <ListPlus className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Tasks</p>
                      <p className="text-sm font-semibold">{templateTasks.length}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-md bg-primary/10 flex items-center justify-center">
                      <Users className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Selected</p>
                      <p className="text-sm font-semibold text-primary">{selectedUserIds.length}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Search and Select All */}
              <div className="flex items-center gap-3">
                <Input
                  placeholder="Search by name or email..."
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  className="flex-1"
                />
                <Button
                  variant="outline"
                  onClick={toggleAllUsers}
                  disabled={filteredUsers.length === 0}
                  className="shrink-0"
                >
                  {allFilteredSelected ? 'Deselect All' : 'Select All'}
                </Button>
              </div>

              {/* User List */}
              <ScrollArea className="flex-1 -mx-6 px-6 min-h-[300px]">
                {filteredUsers.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-16">
                    <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                      <Users className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <p className="text-sm font-medium text-foreground mb-1">
                      {userSearchQuery ? 'No users found' : 'No users available'}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {userSearchQuery ? 'Try adjusting your search' : `No ${roles.find(r => r.value === selectedRole)?.label.toLowerCase()}s in the system`}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1.5 pb-2">
                    {filteredUsers.map((user) => {
                      const isSelected = selectedUserIds.includes(user.id);
                      return (
                        <div
                          key={user.id}
                          onClick={() => toggleUserSelection(user.id)}
                          className={`
                            group flex items-center gap-3.5 p-3 rounded-lg cursor-pointer transition-all
                            hover:bg-accent/50 active:scale-[0.98]
                            ${isSelected ? 'bg-primary/5 ring-1 ring-primary/20' : 'hover:ring-1 hover:ring-border'}
                          `}
                        >
                          <Checkbox
                            checked={isSelected}
                            onClick={(e) => e.stopPropagation()}
                            onCheckedChange={() => toggleUserSelection(user.id)}
                            className="shrink-0 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
                          />
                          <div className="flex items-center gap-3 flex-1 min-w-0">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center shrink-0">
                              <span className="text-sm font-semibold text-primary">
                                {(user.full_name || user.email || '?')[0].toUpperCase()}
                              </span>
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium truncate leading-tight">
                                {user.full_name || 'Unnamed User'}
                              </p>
                              <p className="text-xs text-muted-foreground truncate mt-0.5">
                                {user.email}
                              </p>
                            </div>
                          </div>
                          {isSelected && (
                            <div className="shrink-0 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                              <Check className="w-3.5 h-3.5 text-primary-foreground" />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </ScrollArea>
            </div>

            {/* Footer */}
            <div className="px-6 py-4 border-t bg-muted/20 flex items-center justify-between gap-4">
              <div className="flex-1 min-w-0">
                {selectedUserIds.length > 0 ? (
                  <p className="text-sm text-muted-foreground truncate">
                    Assigning <span className="font-medium text-foreground">{templateTasks.length}</span> task(s) to <span className="font-medium text-foreground">{selectedUserIds.length}</span> user(s)
                  </p>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    No users selected
                  </p>
                )}
              </div>
              <div className="flex gap-2 shrink-0">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setApplyDialogOpen(false);
                    setSelectedUserIds([]);
                    setUserSearchQuery('');
                  }}
                  disabled={loading}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={handleApplyTemplate} 
                  disabled={loading || selectedUserIds.length === 0}
                  className="min-w-[130px]"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                      Assigning...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Assign Tasks
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Select Role</CardTitle>
          <CardDescription>Choose a role to manage its default task template</CardDescription>
        </CardHeader>
        <CardContent>
          <Select value={selectedRole} onValueChange={setSelectedRole}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a role" />
            </SelectTrigger>
            <SelectContent>
              {roles.map((role) => (
                <SelectItem key={role.value} value={role.value}>
                  {role.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Template Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Check className="w-5 h-5 text-green-600" />
              Template Tasks ({templateTasks.length})
            </CardTitle>
            <CardDescription>
              Tasks that will be assigned when template is applied
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-muted-foreground text-sm">Loading...</p>
            ) : templateTasks.length === 0 ? (
              <p className="text-muted-foreground text-sm">No tasks in template. Add tasks from the right.</p>
            ) : (
              <div className="space-y-2">
                {templateTasks.map((task) => (
                  <div
                    key={task.template_id}
                    className="flex items-start justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-sm truncate">{task.name}</p>
                        {task.required && (
                          <Badge variant="destructive" className="text-xs">Required</Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {task.description}
                      </p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline" className="text-xs">{task.category}</Badge>
                        <Badge variant="secondary" className="text-xs">{task.priority}</Badge>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveTask(task.template_id)}
                      className="ml-2 shrink-0"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Available Tasks */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ListPlus className="w-5 h-5" />
              Available Tasks ({tasksNotInTemplate.length})
            </CardTitle>
            <CardDescription>
              Click to add tasks to the template
            </CardDescription>
          </CardHeader>
          <CardContent>
            {tasksNotInTemplate.length === 0 ? (
              <p className="text-muted-foreground text-sm">All tasks are already in the template.</p>
            ) : (
              <div className="space-y-2">
                {tasksNotInTemplate.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-start justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <p className="font-medium text-sm truncate">{task.name}</p>
                        {task.required && (
                          <Badge variant="destructive" className="text-xs">Required</Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {task.description}
                      </p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="outline" className="text-xs">{task.category}</Badge>
                        <Badge variant="secondary" className="text-xs">{task.priority}</Badge>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleAddTask(task.id)}
                      className="ml-2 shrink-0"
                    >
                      <Plus className="w-4 h-4 text-primary" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
