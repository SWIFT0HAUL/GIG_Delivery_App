import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Info, Code, Shield, Users, FileText, DollarSign } from 'lucide-react';

export const RBACImplementationGuide: React.FC = () => {
  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            RBAC Implementation Guide
          </CardTitle>
          <CardDescription>
            Comprehensive Role-Based Access Control is now active across the platform
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>System Status</AlertTitle>
            <AlertDescription>
              RBAC is fully configured with granular permissions for all resources: Jobs, Users, Documents, and Financials.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="hooks">Hooks</TabsTrigger>
          <TabsTrigger value="components">Components</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
          <TabsTrigger value="permissions">Permissions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>RBAC System Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Database Layer</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li><code>granular_permissions</code> table - Stores all permission definitions</li>
                  <li><code>role_granular_permissions</code> table - Maps permissions to roles</li>
                  <li><code>get_user_permissions()</code> function - Fetches user permissions</li>
                  <li><code>user_has_permission()</code> function - Checks specific permission</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Frontend Layer</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li><code>useGranularPermissions</code> hook - Main permission hook</li>
                  <li><code>PermissionGuard</code> component - Conditional rendering</li>
                  <li><code>ResourceGuard</code> component - Resource-based protection</li>
                  <li><code>ProtectedButton</code> component - Permission-aware buttons</li>
                </ul>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Permission Resources</h3>
                <div className="grid grid-cols-2 gap-4 mt-2">
                  <div className="flex items-start gap-2">
                    <Users className="h-4 w-4 mt-1" />
                    <div>
                      <p className="font-medium text-sm">Users</p>
                      <p className="text-xs text-muted-foreground">Profile and account management</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Code className="h-4 w-4 mt-1" />
                    <div>
                      <p className="font-medium text-sm">Jobs</p>
                      <p className="text-xs text-muted-foreground">Job posting and management</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <FileText className="h-4 w-4 mt-1" />
                    <div>
                      <p className="font-medium text-sm">Documents</p>
                      <p className="text-xs text-muted-foreground">Document upload and review</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <DollarSign className="h-4 w-4 mt-1" />
                    <div>
                      <p className="font-medium text-sm">Financial</p>
                      <p className="text-xs text-muted-foreground">Payments and payouts</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="hooks" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Using Permission Hooks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">useGranularPermissions Hook</h3>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`import { useGranularPermissions } from '@/hooks/useGranularPermissions';

function MyComponent() {
  const { 
    hasPermission, 
    canCreate,
    canUpdate,
    loading 
  } = useGranularPermissions();

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      {hasPermission('job.create') && (
        <button>Create Job</button>
      )}
      
      {canUpdate('user') && (
        <button>Edit Profile</button>
      )}
    </div>
  );
}`}
                </pre>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Available Methods</h3>
                <ul className="space-y-2 text-sm">
                  <li><code>hasPermission(key)</code> - Check single permission</li>
                  <li><code>hasAnyPermission([keys])</code> - Check if user has any of the permissions</li>
                  <li><code>hasAllPermissions([keys])</code> - Check if user has all permissions</li>
                  <li><code>canCreate(resource)</code> - Check create permission for resource</li>
                  <li><code>canRead(resource)</code> - Check read permission</li>
                  <li><code>canUpdate(resource)</code> - Check update permission</li>
                  <li><code>canDelete(resource)</code> - Check delete permission</li>
                  <li><code>canApprove(resource)</code> - Check approve permission</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="components" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>RBAC Components</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold mb-2">PermissionGuard</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Conditionally renders content based on permissions
                </p>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`import { PermissionGuard } from '@/components/rbac';

<PermissionGuard permission="job.create">
  <CreateJobButton />
</PermissionGuard>

// Multiple permissions (any)
<PermissionGuard permissions={['job.edit.own', 'job.edit.all']}>
  <EditJobButton />
</PermissionGuard>

// Multiple permissions (all required)
<PermissionGuard 
  permissions={['user.approve', 'user.activate']}
  requireAll
>
  <ApproveUserButton />
</PermissionGuard>`}
                </pre>
              </div>

              <div>
                <h3 className="font-semibold mb-2">ResourceGuard</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Guards based on resource and action type
                </p>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`import { ResourceGuard } from '@/components/rbac';

<ResourceGuard resource="job" action="create">
  <CreateJobForm />
</ResourceGuard>

<ResourceGuard resource="financial" action="export">
  <ExportButton />
</ResourceGuard>`}
                </pre>
              </div>

              <div>
                <h3 className="font-semibold mb-2">ProtectedButton</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Button that disables when user lacks permission
                </p>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`import { ProtectedButton } from '@/components/rbac';

<ProtectedButton 
  permission="user.delete"
  onClick={handleDelete}
  variant="destructive"
>
  Delete User
</ProtectedButton>

// Hide button entirely if no permission
<ProtectedButton 
  permission="financial.export"
  hideWhenNoPermission
>
  Export Report
</ProtectedButton>`}
                </pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="examples" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Real-World Examples</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-semibold mb-2">Job Management Page</h3>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`import { PermissionGuard, ProtectedButton } from '@/components/rbac';
import { PERMISSIONS } from '@/lib/rbacConfig';

function JobsPage() {
  return (
    <div>
      <PermissionGuard permission={PERMISSIONS.JOB.CREATE}>
        <button>Post New Job</button>
      </PermissionGuard>

      {jobs.map(job => (
        <div key={job.id}>
          <h3>{job.title}</h3>
          
          <PermissionGuard permissions={[
            PERMISSIONS.JOB.EDIT_OWN,
            PERMISSIONS.JOB.EDIT_ALL
          ]}>
            <button>Edit</button>
          </PermissionGuard>

          <ProtectedButton
            permission={PERMISSIONS.JOB.DELETE_ALL}
            onClick={() => handleDelete(job.id)}
            variant="destructive"
          >
            Delete
          </ProtectedButton>
        </div>
      ))}
    </div>
  );
}`}
                </pre>
              </div>

              <div>
                <h3 className="font-semibold mb-2">User Management</h3>
                <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
{`import { useGranularPermissions } from '@/hooks/useGranularPermissions';

function UserManagement() {
  const { hasPermission, canUpdate } = useGranularPermissions();

  const canApproveUsers = hasPermission('user.approve');
  const canEditUsers = canUpdate('user');

  return (
    <div>
      {canApproveUsers && <ApprovalQueue />}
      {canEditUsers && <UserEditor />}
    </div>
  );
}`}
                </pre>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="permissions" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Permission Reference</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">Job Permissions</h3>
                  <ul className="text-sm space-y-1">
                    <li><code>job.create</code> - Create job postings</li>
                    <li><code>job.view.own</code> - View own jobs</li>
                    <li><code>job.view.all</code> - View all jobs</li>
                    <li><code>job.edit.own</code> - Edit own jobs</li>
                    <li><code>job.edit.all</code> - Edit any job</li>
                    <li><code>job.delete.own</code> - Delete own jobs</li>
                    <li><code>job.delete.all</code> - Delete any job</li>
                    <li><code>job.assign</code> - Assign jobs to workers</li>
                    <li><code>job.approve</code> - Approve job postings</li>
                    <li><code>job.claim</code> - Claim available jobs</li>
                    <li><code>job.complete</code> - Mark jobs complete</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">User Permissions</h3>
                  <ul className="text-sm space-y-1">
                    <li><code>user.view.all</code> - View all users</li>
                    <li><code>user.edit.all</code> - Edit any user</li>
                    <li><code>user.approve</code> - Approve registrations</li>
                    <li><code>user.activate</code> - Activate/deactivate accounts</li>
                    <li><code>user.assign_role</code> - Assign roles</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Document Permissions</h3>
                  <ul className="text-sm space-y-1">
                    <li><code>document.view.all</code> - View all documents</li>
                    <li><code>document.review</code> - Review documents</li>
                    <li><code>document.delete.all</code> - Delete any document</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-semibold mb-2">Financial Permissions</h3>
                  <ul className="text-sm space-y-1">
                    <li><code>financial.view.all</code> - View all financial data</li>
                    <li><code>financial.process_payment</code> - Process payments</li>
                    <li><code>financial.approve_payout</code> - Approve payouts</li>
                    <li><code>financial.export</code> - Export financial reports</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
