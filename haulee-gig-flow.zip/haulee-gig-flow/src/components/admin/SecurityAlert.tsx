import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Shield, CheckCircle, Lock } from 'lucide-react';

export function SecurityAlert() {
  return (
    <Alert className="border-green-200 bg-green-50">
      <Shield className="h-4 w-4 text-green-600" />
      <AlertTitle className="text-green-800">Security Enhanced!</AlertTitle>
      <AlertDescription className="text-green-700">
        <div className="space-y-2">
          <p>Critical security improvements have been implemented:</p>
          <ul className="list-disc pl-4 space-y-1">
            <li className="flex items-center gap-2">
              <CheckCircle className="h-3 w-3 text-green-600" />
              Removed public access to user profiles (emails, names)
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-3 w-3 text-green-600" />
              Added financial data masking and access logging
            </li>
            <li className="flex items-center gap-2">
              <Lock className="h-3 w-3 text-green-600" />
              Implemented admin-only access controls for sensitive data
            </li>
          </ul>
          <p className="text-sm font-medium">Your user data is now properly protected from unauthorized access.</p>
        </div>
      </AlertDescription>
    </Alert>
  );
}