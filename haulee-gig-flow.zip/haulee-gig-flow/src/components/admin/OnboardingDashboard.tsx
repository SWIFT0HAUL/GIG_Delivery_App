import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Button } from '@/components/ui/button';
import { ChevronDown, ChevronRight, CheckCircle2, Circle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { toast } from '@/hooks/use-toast';

interface OnboardingStepData {
  step_data?: any;
  completed_at?: string | null;
  created_at?: string;
  uploaded_files?: any;
}

interface OnboardingStep {
  step_number: number;
  step_data: any;
  completed_at: string | null;
  created_at: string;
}

interface UserOnboarding {
  id: string;
  email: string;
  full_name: string | null;
  role_name: string | null;
  onboarding_complete: boolean;
  steps: OnboardingStep[];
}

export const OnboardingDashboard = () => {
  const [users, setUsers] = useState<UserOnboarding[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedUsers, setExpandedUsers] = useState<Set<string>>(new Set());

  // Fetch all users with their onboarding steps
  useEffect(() => {
    fetchUsersOnboarding();
  }, []);

  const fetchUsersOnboarding = async () => {
    try {
      setLoading(true);

      // Fetch all profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, email, full_name, role_name, onboarding_complete')
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // Fetch all onboarding data (now one row per user)
      const { data: onboardingData, error: onboardingError } = await supabase
        .from('onboarding_data')
        .select('user_id, steps, last_step_number, completed_steps');

      if (onboardingError) throw onboardingError;

      // Combine profiles with their steps
      const usersWithSteps: UserOnboarding[] = (profiles || []).map(profile => {
        const userOnboarding = onboardingData?.find(od => od.user_id === profile.id);
        
        let userSteps: OnboardingStep[] = [];
        
        if (userOnboarding && userOnboarding.steps) {
          // Parse JSONB steps into array
          const stepsObj = userOnboarding.steps as Record<string, OnboardingStepData>;
          const completedSteps = userOnboarding.completed_steps || [];
          
          userSteps = Object.entries(stepsObj)
            .map(([stepNum, stepData]) => {
              const stepNumber = parseInt(stepNum);
              return {
                step_number: stepNumber,
                step_data: stepData.step_data || {},
                completed_at: completedSteps.includes(stepNumber) ? (stepData.completed_at || '') : null,
                created_at: stepData.created_at || ''
              };
            })
            .sort((a, b) => a.step_number - b.step_number);
        }

        return {
          ...profile,
          steps: userSteps
        };
      });

      setUsers(usersWithSteps);
    } catch (error) {
      console.error('Error fetching onboarding data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load onboarding dashboard',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleUser = (userId: string) => {
    setExpandedUsers(prev => {
      const newSet = new Set(prev);
      if (newSet.has(userId)) {
        newSet.delete(userId);
      } else {
        newSet.add(userId);
      }
      return newSet;
    });
  };

  const getStepLabel = (stepNumber: number) => {
    const stepLabels: { [key: number]: string } = {
      1: 'Welcome',
      2: 'Personal Information',
      3: 'Business Information',
      4: 'Documents',
      5: 'Payment Information',
      6: 'Tasks',
      7: 'Review & Confirm'
    };
    return stepLabels[stepNumber] || `Step ${stepNumber}`;
  };

  const formatDate = (dateString: string | null) => {
    if (!dateString) return 'Not completed';
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>User Onboarding Dashboard</CardTitle>
        <CardDescription>
          View all users and their onboarding progress
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {users.map(user => {
            const isExpanded = expandedUsers.has(user.id);
            const completedSteps = user.steps.filter(s => s.completed_at).length;
            const totalSteps = user.steps.length;

            return (
              <Collapsible
                key={user.id}
                open={isExpanded}
                onOpenChange={() => toggleUser(user.id)}
              >
                <div className="border rounded-lg overflow-hidden">
                  <CollapsibleTrigger asChild>
                    <Button
                      variant="ghost"
                      className="w-full justify-between p-4 h-auto hover:bg-accent"
                    >
                      <div className="flex items-center gap-4 flex-1 text-left">
                        <div className="flex-shrink-0">
                          {isExpanded ? (
                            <ChevronDown className="h-5 w-5 text-muted-foreground" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-muted-foreground" />
                          )}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-medium truncate">
                              {user.full_name || user.email}
                            </p>
                            {user.onboarding_complete && (
                              <Badge variant="default" className="flex-shrink-0">
                                Complete
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground truncate">
                            {user.email}
                          </p>
                        </div>

                        <div className="flex items-center gap-4 flex-shrink-0">
                          <Badge variant="outline">
                            {user.role_name || 'No role'}
                          </Badge>
                          <div className="text-sm text-muted-foreground">
                            {completedSteps}/{totalSteps} steps
                          </div>
                        </div>
                      </div>
                    </Button>
                  </CollapsibleTrigger>

                  <CollapsibleContent>
                    <div className="border-t bg-muted/50 p-4">
                      {user.steps.length === 0 ? (
                        <p className="text-sm text-muted-foreground text-center py-4">
                          No onboarding steps started
                        </p>
                      ) : (
                        <div className="space-y-3">
                          {user.steps.map(step => (
                            <div
                              key={`${user.id}-${step.step_number}`}
                              className="flex items-start gap-3 p-3 bg-background rounded-md border"
                            >
                              <div className="flex-shrink-0 mt-0.5">
                                {step.completed_at ? (
                                  <CheckCircle2 className="h-5 w-5 text-success" />
                                ) : (
                                  <Circle className="h-5 w-5 text-muted-foreground" />
                                )}
                              </div>
                              
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between mb-1">
                                  <p className="font-medium text-sm">
                                    Step {step.step_number}: {getStepLabel(step.step_number)}
                                  </p>
                                  <Badge
                                    variant={step.completed_at ? "default" : "outline"}
                                    className="flex-shrink-0 ml-2"
                                  >
                                    {step.completed_at ? 'Completed' : 'In Progress'}
                                  </Badge>
                                </div>
                                
                                <p className="text-xs text-muted-foreground">
                                  {step.completed_at 
                                    ? `Completed: ${formatDate(step.completed_at)}`
                                    : `Started: ${formatDate(step.created_at)}`
                                  }
                                </p>

                                {step.step_data && Object.keys(step.step_data).length > 0 && (
                                  <details className="mt-2">
                                    <summary className="text-xs text-muted-foreground cursor-pointer hover:text-foreground">
                                      View step data
                                    </summary>
                                    <pre className="mt-2 text-xs bg-muted p-2 rounded overflow-x-auto">
                                      {JSON.stringify(step.step_data, null, 2)}
                                    </pre>
                                  </details>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </CollapsibleContent>
                </div>
              </Collapsible>
            );
          })}

          {users.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              No users found
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
