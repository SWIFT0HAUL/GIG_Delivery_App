import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { FileText, Upload, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { SimpleFileUpload } from './SimpleFileUpload';

interface IDDocumentUploadFormProps {
  onComplete: () => void;
}

export function IDDocumentUploadForm({ onComplete }: IDDocumentUploadFormProps) {
  const { user } = useAuth();
  const [frontImage, setFrontImage] = useState<string | null>(null);
  const [backImage, setBackImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    if (!user || !frontImage) {
      toast({
        title: "Missing Information",
        description: "Please upload at least the front of your ID",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      // Create or update KYC submission
      const { error } = await supabase
        .from('kyc_submissions')
        .upsert({
          user_id: user.id,
          government_id_path: frontImage,
          proof_of_address_path: backImage || frontImage,
          status: 'pending',
          submitted_at: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "ID documents submitted for verification"
      });
      
      onComplete();
    } catch (error: any) {
      toast({
        title: "Submission Failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Alert>
        <FileText className="h-4 w-4" />
        <AlertDescription>
          <strong>Accepted Documents:</strong> Driver's License, Passport, State ID, or National ID
          <br />
          <strong>Requirements:</strong> Clear, high-resolution images with all four corners visible
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>ID Document Front</CardTitle>
          <CardDescription>
            Upload a clear photo of the front of your government-issued ID
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <SimpleFileUpload
            label="ID Front"
            value={frontImage || undefined}
            onChange={setFrontImage}
            required
          />
          
          {frontImage && (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle className="w-4 h-4" />
              Front image uploaded successfully
            </div>
          )}

          <div className="text-sm text-muted-foreground space-y-1">
            <p className="font-medium">Photo Guidelines:</p>
            <ul className="list-disc list-inside space-y-1">
              <li>High resolution (min 1200x900px)</li>
              <li>All text clearly visible</li>
              <li>No glare or shadows</li>
              <li>All four corners visible</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>ID Document Back (if applicable)</CardTitle>
          <CardDescription>
            Upload the back of your ID if it contains additional information
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <SimpleFileUpload
            label="ID Back (Optional)"
            value={backImage || undefined}
            onChange={setBackImage}
          />
          
          {backImage && (
            <div className="flex items-center gap-2 text-sm text-green-600">
              <CheckCircle className="w-4 h-4" />
              Back image uploaded successfully
            </div>
          )}
        </CardContent>
      </Card>

      <Alert className="border-amber-200 bg-amber-50 dark:bg-amber-950/20">
        <AlertCircle className="h-4 w-4 text-amber-600" />
        <AlertDescription className="text-amber-800 dark:text-amber-200">
          <strong>Privacy & Security:</strong> Your documents are encrypted and used only for verification. We comply with GDPR and data protection regulations.
        </AlertDescription>
      </Alert>

      <div className="flex justify-end gap-3">
        <Button
          onClick={handleSubmit}
          disabled={!frontImage || loading}
          className="gap-2"
        >
          {loading ? (
            <>
              <Upload className="w-4 h-4 animate-pulse" />
              Submitting...
            </>
          ) : (
            <>
              <CheckCircle className="w-4 h-4" />
              Submit for Verification
            </>
          )}
        </Button>
      </div>
    </div>
  );
}
