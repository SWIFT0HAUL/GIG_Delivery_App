import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { FileText, CheckCircle, ExternalLink } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface TermsAcceptanceFormProps {
  onComplete: () => void;
}

export function TermsAcceptanceForm({ onComplete }: TermsAcceptanceFormProps) {
  const { user } = useAuth();
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [acceptedAUP, setAcceptedAUP] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleOpenPolicies = async () => {
    try {
      const { data, error } = await supabase.functions.invoke('get-public-policy-url');
      
      if (error) throw error;
      
      if (data?.url) {
        const newWindow = window.open(data.url, '_blank');
        if (!newWindow) {
          toast({
            title: "Popup Blocked",
            description: "Please allow popups to view the document",
            variant: "destructive"
          });
        }
      } else {
        throw new Error('No URL received');
      }
    } catch (error: any) {
      console.error('Error fetching policy URL:', error);
      toast({
        title: "Error",
        description: "Failed to load the policies document",
        variant: "destructive"
      });
    }
  };

  const handleSubmit = async () => {
    if (!acceptedTerms || !acceptedPrivacy || !acceptedAUP) {
      toast({
        title: "Action Required",
        description: "Please accept all terms and policies to continue",
        variant: "destructive"
      });
      return;
    }

    if (!user) return;

    setLoading(true);
    try {
      // Store acceptance in onboarding_data table
      const { error } = await supabase
        .from('onboarding_data')
        .insert({
          user_id: user.id,
          step_number: 99,
          step_title: 'Terms Acceptance',
          step_data: {
            terms_accepted_at: new Date().toISOString(),
            privacy_accepted_at: new Date().toISOString(),
            aup_accepted_at: new Date().toISOString()
          }
        });

      if (error) {
        console.error('Error saving acceptance:', error);
        throw error;
      }

      toast({
        title: "Success",
        description: "Terms and conditions accepted successfully"
      });
      
      onComplete();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save acceptance",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Alert>
        <FileText className="h-4 w-4" />
        <AlertDescription>
          Please review all documents carefully. You must read and accept all terms to use the platform.
        </AlertDescription>
      </Alert>

      {/* Terms of Service */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Terms of Service</span>
            <Button variant="ghost" size="sm" onClick={handleOpenPolicies} className="gap-2">
              <ExternalLink className="w-4 h-4" />
              Open Full Document
            </Button>
          </CardTitle>
          <CardDescription>Platform usage terms and user responsibilities</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ScrollArea className="h-[200px] border rounded-lg p-4">
            <div className="text-sm space-y-3 text-muted-foreground">
              <h4 className="font-semibold text-foreground">1. Acceptance of Terms</h4>
              <p>By accessing and using this platform, you accept and agree to be bound by the terms and provision of this agreement.</p>
              
              <h4 className="font-semibold text-foreground">2. Use License</h4>
              <p>Permission is granted to temporarily access the materials on the platform for personal, non-commercial transitory viewing only.</p>
              
              <h4 className="font-semibold text-foreground">3. User Responsibilities</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Maintain account security</li>
                <li>Provide accurate information</li>
                <li>Comply with all applicable laws</li>
                <li>Respect intellectual property rights</li>
              </ul>

              <h4 className="font-semibold text-foreground">4. Prohibited Activities</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Fraudulent activities</li>
                <li>Harassment or abuse</li>
                <li>Unauthorized access attempts</li>
                <li>Spam or unsolicited communications</li>
              </ul>

              <h4 className="font-semibold text-foreground">5. Liability Limitations</h4>
              <p>The platform and its suppliers will not be liable for any damages arising from the use or inability to use the materials on the platform.</p>
              
            </div>
          </ScrollArea>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="terms"
              checked={acceptedTerms}
              onCheckedChange={(checked) => setAcceptedTerms(checked as boolean)}
            />
            <Label htmlFor="terms" className="text-sm cursor-pointer">
              I have read and accept the Terms of Service
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Privacy Policy */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Privacy Policy</span>
            <Button variant="ghost" size="sm" onClick={handleOpenPolicies} className="gap-2">
              <ExternalLink className="w-4 h-4" />
              Open Full Document
            </Button>
          </CardTitle>
          <CardDescription>How we collect, use, and protect your data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <ScrollArea className="h-[200px] border rounded-lg p-4">
            <div className="text-sm space-y-3 text-muted-foreground">
              <h4 className="font-semibold text-foreground">Data Collection</h4>
              <p>We collect information you provide directly, usage data, and technical information about your device.</p>
              
              <h4 className="font-semibold text-foreground">Data Usage</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Provide and improve services</li>
                <li>Process transactions</li>
                <li>Send notifications and updates</li>
                <li>Prevent fraud and ensure security</li>
              </ul>

              <h4 className="font-semibold text-foreground">Data Protection</h4>
              <p>We implement industry-standard security measures including encryption, secure servers, and access controls.</p>

              <h4 className="font-semibold text-foreground">Your Rights</h4>
              <ul className="list-disc list-inside space-y-1">
                <li>Access your personal data</li>
                <li>Request data correction or deletion</li>
                <li>Opt-out of marketing communications</li>
                <li>Data portability</li>
              </ul>

              <h4 className="font-semibold text-foreground">GDPR Compliance</h4>
              <p>We comply with EU data protection regulations and provide appropriate safeguards for international data transfers.</p>
              
              
            </div>
          </ScrollArea>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="privacy"
              checked={acceptedPrivacy}
              onCheckedChange={(checked) => setAcceptedPrivacy(checked as boolean)}
            />
            <Label htmlFor="privacy" className="text-sm cursor-pointer">
              I have read and accept the Privacy Policy
            </Label>
          </div>
        </CardContent>
      </Card>

      {/* Acceptable Use Policy */}
      <Card>
        <CardHeader>
          <CardTitle>Acceptable Use Policy</CardTitle>
          <CardDescription>Standards for platform conduct and content</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm space-y-2 text-muted-foreground">
            <p>You agree to use the platform in compliance with all applicable laws and regulations.</p>
            <p>Prohibited: Illegal activities, harassment, spam, malware, unauthorized access, or content that violates rights.</p>
          </div>

          <div className="flex items-start space-x-3">
            <Checkbox
              id="aup"
              checked={acceptedAUP}
              onCheckedChange={(checked) => setAcceptedAUP(checked as boolean)}
            />
            <Label htmlFor="aup" className="text-sm cursor-pointer">
              I agree to abide by the Acceptable Use Policy
            </Label>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end gap-3">
        <Button
          onClick={handleSubmit}
          disabled={!acceptedTerms || !acceptedPrivacy || !acceptedAUP || loading}
          className="gap-2"
        >
          <CheckCircle className="w-4 h-4" />
          {loading ? 'Accepting...' : 'Accept All & Continue'}
        </Button>
      </div>
    </div>
  );
}
