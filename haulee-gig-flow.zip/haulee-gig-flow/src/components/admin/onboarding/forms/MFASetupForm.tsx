import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Shield, Smartphone, MessageSquare, CheckCircle, Copy, Download } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { toast as sonnerToast } from 'sonner';
import QRCode from 'react-qr-code';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useTwilioSMS } from '@/hooks/useTwilioSMS';
import { 
  generateVerificationCode, 
  formatPhoneNumber, 
  isValidPhoneNumber,
  storeVerificationCode,
  verifyStoredCode 
} from '@/lib/smsUtils';

interface MFASetupFormProps {
  onComplete: () => void;
}

export function MFASetupForm({ onComplete }: MFASetupFormProps) {
  const { user } = useAuth();
  const { sendMFACode, sending: sendingSMS } = useTwilioSMS();
  
  const [method, setMethod] = useState<'app' | 'sms'>('app');
  const [countryCode, setCountryCode] = useState('+1');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [step, setStep] = useState<'choose' | 'setup' | 'verify'>('choose');
  const [loading, setLoading] = useState(false);
  const [smsSent, setSmsSent] = useState(false);
  
  // Generate a random TOTP secret for authenticator apps
  const [qrSecret] = useState(() => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    return Array.from({ length: 32 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  });
  
  // Generate backup codes
  const [backupCodes] = useState(() => {
    return Array.from({ length: 10 }, () => {
      const part1 = Math.random().toString(36).substring(2, 6).toUpperCase();
      const part2 = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
      const part3 = Math.random().toString(36).substring(2, 6).toUpperCase();
      return `${part1}-${part2}-${part3}`;
    });
  });

  const handleMethodSelect = (selectedMethod: 'app' | 'sms') => {
    setMethod(selectedMethod);
    setStep('setup');
  };

  const handleSendSMSCode = async () => {
    if (!phoneNumber) {
      sonnerToast.error('Please enter a phone number');
      return;
    }

    const fullPhoneNumber = `${countryCode}${phoneNumber}`;
    if (!isValidPhoneNumber(fullPhoneNumber)) {
      sonnerToast.error('Please enter a valid phone number');
      return;
    }

    const formattedPhone = formatPhoneNumber(fullPhoneNumber);
    const code = generateVerificationCode(6);
    
    // Store code for verification
    storeVerificationCode(formattedPhone, code, 10);
    
    // Send via Twilio
    const result = await sendMFACode(formattedPhone, code);
    
    if (result.success) {
      setSmsSent(true);
      sonnerToast.success('Verification code sent to your phone!');
    }
  };

  const handleVerify = async () => {
    if (!verificationCode || verificationCode.length !== 6) {
      sonnerToast.error('Please enter a 6-digit verification code');
      return;
    }

    if (!user) {
      sonnerToast.error('User not authenticated');
      return;
    }

    setLoading(true);
    try {
      let isValid = false;

      if (method === 'sms') {
        // Verify SMS code
        const fullPhoneNumber = `${countryCode}${phoneNumber}`;
        const formattedPhone = formatPhoneNumber(fullPhoneNumber);
        isValid = verifyStoredCode(formattedPhone, verificationCode);
        
        if (!isValid) {
          sonnerToast.error('Invalid or expired verification code');
          setLoading(false);
          return;
        }
      } else {
        // For authenticator app, we'd verify TOTP code here
        // For now, accept any 6-digit code as valid for demo
        isValid = verificationCode.length === 6;
      }

      if (isValid) {
        // Save MFA configuration to database
        const fullPhoneNumber = method === 'sms' ? `${countryCode}${phoneNumber}` : null;
        const { error } = await supabase
          .from('profiles')
          .update({
            mfa_enabled: true,
            mfa_method: method,
            mfa_phone: fullPhoneNumber ? formatPhoneNumber(fullPhoneNumber) : null,
            mfa_totp_secret: method === 'app' ? qrSecret : null,
            mfa_backup_codes: backupCodes,
            updated_at: new Date().toISOString()
          })
          .eq('id', user.id);

        if (error) {
          console.error('Error saving MFA config:', error);
          sonnerToast.error('Failed to save MFA configuration');
          setLoading(false);
          return;
        }

        sonnerToast.success('MFA enabled successfully!');
        setStep('verify');
      }
    } catch (error: any) {
      console.error('Error in handleVerify:', error);
      sonnerToast.error(error.message || 'Verification failed');
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    sonnerToast.success('Copied to clipboard');
  };

  const downloadBackupCodes = () => {
    const content = `MFA Backup Codes\nGenerated: ${new Date().toLocaleDateString()}\n\n${backupCodes.join('\n')}\n\nIMPORTANT: Keep these codes safe and secure!\nEach code can be used once to access your account if you lose your authentication device.\n\nDO NOT share these codes with anyone.`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `mfa-backup-codes-${new Date().getTime()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    sonnerToast.success('Backup codes downloaded');
  };

  if (step === 'choose') {
    return (
      <div className="space-y-6">
        <Alert>
          <Shield className="h-4 w-4" />
          <AlertDescription>
            Multi-Factor Authentication adds an extra layer of security by requiring a second verification method in addition to your password.
          </AlertDescription>
        </Alert>

        <div className="grid md:grid-cols-2 gap-4">
          <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => handleMethodSelect('app')}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                Authenticator App
              </CardTitle>
              <CardDescription>Recommended - More secure</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Use an authenticator app like Google Authenticator, Microsoft Authenticator, or Authy.
              </p>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Works offline
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  More secure
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  No phone number required
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="cursor-pointer hover:border-primary transition-colors" onClick={() => handleMethodSelect('sms')}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                SMS Verification
              </CardTitle>
              <CardDescription>Codes sent via text message</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Receive verification codes via SMS to your mobile phone.
              </p>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Easy to use
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  No app required
                </li>
                <li className="text-muted-foreground">
                  Requires mobile signal
                </li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (step === 'setup' && method === 'app') {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Setup Authenticator App</CardTitle>
            <CardDescription>Scan the QR code with your authenticator app</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex justify-center p-6 bg-white rounded-lg">
              <QRCode 
                value={`otpauth://totp/Haulee:${user?.email || 'user'}?secret=${qrSecret}&issuer=Haulee`} 
                size={200} 
              />
            </div>

            <div className="space-y-2">
              <Label>Or enter this code manually:</Label>
              <div className="flex gap-2">
                <Input value={qrSecret} readOnly className="font-mono" />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => copyToClipboard(qrSecret)}
                >
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <Alert>
              <Smartphone className="h-4 w-4" />
              <AlertDescription>
                <strong>Popular Authenticator Apps:</strong>
                <ul className="mt-2 space-y-1">
                  <li>• Google Authenticator</li>
                  <li>• Microsoft Authenticator</li>
                  <li>• Authy</li>
                  <li>• 1Password</li>
                </ul>
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <Label htmlFor="code">Enter 6-Digit Code from App</Label>
              <Input
                id="code"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="000000"
                maxLength={6}
                className="text-center text-2xl tracking-widest font-mono"
              />
            </div>

            <Button
              onClick={handleVerify}
              disabled={verificationCode.length !== 6 || loading}
              className="w-full"
            >
              {loading ? 'Verifying...' : 'Verify & Enable MFA'}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (step === 'setup' && method === 'sms') {
    return (
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Setup SMS Verification</CardTitle>
            <CardDescription>Enter your phone number to receive verification codes</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <MessageSquare className="h-4 w-4" />
              <AlertDescription>
                We'll send a verification code to your phone via SMS to confirm your number.
              </AlertDescription>
            </Alert>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <div className="flex gap-2">
                <Select value={countryCode} onValueChange={setCountryCode} disabled={sendingSMS || smsSent}>
                  <SelectTrigger className="w-32 bg-background">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background border-border z-50 max-h-[300px]">
                    <SelectItem value="+1">🇺🇸 US +1</SelectItem>
                    <SelectItem value="+44">🇬🇧 UK +44</SelectItem>
                    <SelectItem value="+91">🇮🇳 India +91</SelectItem>
                    <SelectItem value="+86">🇨🇳 China +86</SelectItem>
                    <SelectItem value="+81">🇯🇵 Japan +81</SelectItem>
                    <SelectItem value="+49">🇩🇪 Germany +49</SelectItem>
                    <SelectItem value="+33">🇫🇷 France +33</SelectItem>
                    <SelectItem value="+39">🇮🇹 Italy +39</SelectItem>
                    <SelectItem value="+34">🇪🇸 Spain +34</SelectItem>
                    <SelectItem value="+52">🇲🇽 Mexico +52</SelectItem>
                    <SelectItem value="+55">🇧🇷 Brazil +55</SelectItem>
                    <SelectItem value="+61">🇦🇺 Australia +61</SelectItem>
                    <SelectItem value="+7">🇷🇺 Russia +7</SelectItem>
                    <SelectItem value="+82">🇰🇷 S. Korea +82</SelectItem>
                    <SelectItem value="+62">🇮🇩 Indonesia +62</SelectItem>
                    <SelectItem value="+63">🇵🇭 Philippines +63</SelectItem>
                    <SelectItem value="+84">🇻🇳 Vietnam +84</SelectItem>
                    <SelectItem value="+66">🇹🇭 Thailand +66</SelectItem>
                    <SelectItem value="+27">🇿🇦 S. Africa +27</SelectItem>
                    <SelectItem value="+20">🇪🇬 Egypt +20</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  id="phone"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => {
                    setPhoneNumber(e.target.value.replace(/[^0-9]/g, ''));
                    setSmsSent(false);
                  }}
                  placeholder="5551234567"
                  disabled={sendingSMS || smsSent}
                  className="flex-1"
                />
              </div>
              <p className="text-sm text-muted-foreground">
                Enter your phone number without country code
              </p>
            </div>

            {!smsSent ? (
              <Button
                onClick={handleSendSMSCode}
                disabled={!phoneNumber || sendingSMS}
                className="w-full"
              >
                {sendingSMS ? 'Sending...' : 'Send Verification Code'}
              </Button>
            ) : (
              <>
                <Alert className="border-green-200 bg-green-50 dark:bg-green-950/20">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <AlertDescription className="text-green-800 dark:text-green-200">
                    Verification code sent to {formatPhoneNumber(`${countryCode}${phoneNumber}`)}
                  </AlertDescription>
                </Alert>

                <div className="space-y-2">
                  <Label htmlFor="code">Enter 6-Digit Code</Label>
                  <Input
                    id="code"
                    value={verificationCode}
                    onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
                    placeholder="000000"
                    maxLength={6}
                    className="text-center text-2xl tracking-widest font-mono"
                  />
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={handleVerify}
                    disabled={verificationCode.length !== 6 || loading}
                    className="flex-1"
                  >
                    {loading ? 'Verifying...' : 'Verify & Enable MFA'}
                  </Button>
                  <Button
                    onClick={handleSendSMSCode}
                    variant="outline"
                    disabled={sendingSMS}
                  >
                    {sendingSMS ? 'Sending...' : 'Resend'}
                  </Button>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Backup codes screen
  return (
    <div className="space-y-6">
      <Alert className="border-green-200 bg-green-50 dark:bg-green-950/20">
        <CheckCircle className="h-4 w-4 text-green-600" />
        <AlertDescription className="text-green-800 dark:text-green-200">
          MFA has been successfully enabled on your account!
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Backup Codes</span>
            <Button
              variant="outline"
              size="sm"
              onClick={downloadBackupCodes}
              className="gap-2"
            >
              <Download className="w-4 h-4" />
              Download
            </Button>
          </CardTitle>
          <CardDescription>
            Save these backup codes in a secure location. Each can be used once to access your account.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert className="mb-4">
            <Shield className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> Store these codes securely. If you lose access to your authentication device, these codes are your only way to regain access.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 p-4 bg-muted rounded-lg font-mono text-sm">
            {backupCodes.map((code, index) => (
              <div key={index} className="flex items-center justify-between p-2 bg-background rounded">
                <span>{code}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => copyToClipboard(code)}
                >
                  <Copy className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button onClick={onComplete} className="gap-2">
          <CheckCircle className="w-4 h-4" />
          Complete Setup
        </Button>
      </div>
    </div>
  );
}
