import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Mail, CheckCircle, RefreshCw, AlertCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

interface EmailVerificationFormProps {
  onComplete: () => void;
}

export function EmailVerificationForm({ onComplete }: EmailVerificationFormProps) {
  const { user } = useAuth();
  const [email, setEmail] = useState(user?.email || '');
  const [isVerified, setIsVerified] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);

  useEffect(() => {
    checkVerificationStatus();
  }, []);

  useEffect(() => {
    if (resendCooldown > 0) {
      const timer = setTimeout(() => setResendCooldown(resendCooldown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendCooldown]);

  const checkVerificationStatus = async () => {
    if (!user) return;
    
    const { data } = await supabase.auth.getUser();
    const verified = data?.user?.email_confirmed_at != null;
    setIsVerified(verified);
    
    if (verified) {
      toast({
        title: "Email Verified",
        description: "Your email address has been verified successfully."
      });
    }
  };

  const handleResendVerification = async () => {
    if (!email) return;
    
    setLoading(true);
    try {
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: email
      });

      if (error) throw error;

      setResendCooldown(60);
      toast({
        title: "Verification Email Sent",
        description: "Please check your inbox for the verification link."
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to resend verification email",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleComplete = () => {
    if (isVerified) {
      onComplete();
    } else {
      toast({
        title: "Verification Required",
        description: "Please verify your email before completing this task.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="w-5 h-5" />
            Email Verification
          </CardTitle>
          <CardDescription>
            Verify your email address to secure your account and receive important notifications
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email Address</Label>
            <Input
              id="email"
              type="email"
              value={email}
              disabled
              className="bg-muted"
            />
          </div>

          {isVerified ? (
            <Alert className="border-green-200 bg-green-50 dark:bg-green-950/20">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800 dark:text-green-200">
                Your email address has been verified successfully!
              </AlertDescription>
            </Alert>
          ) : (
            <>
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  A verification email has been sent to <strong>{email}</strong>. 
                  Please check your inbox and click the verification link.
                </AlertDescription>
              </Alert>

              <div className="space-y-3">
                <h4 className="text-sm font-medium">Didn't receive the email?</h4>
                <ul className="text-sm text-muted-foreground space-y-1 list-disc list-inside">
                  <li>Check your spam/junk folder</li>
                  <li>Verify the email address is correct</li>
                  <li>Click the button below to resend</li>
                </ul>

                <Button
                  variant="outline"
                  onClick={handleResendVerification}
                  disabled={loading || resendCooldown > 0}
                  className="w-full gap-2"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  {resendCooldown > 0 
                    ? `Resend in ${resendCooldown}s` 
                    : 'Resend Verification Email'
                  }
                </Button>

                <Button
                  variant="ghost"
                  onClick={checkVerificationStatus}
                  className="w-full"
                >
                  I've Verified - Check Status
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button
          onClick={handleComplete}
          disabled={!isVerified}
          className="gap-2"
        >
          <CheckCircle className="w-4 h-4" />
          Complete Task
        </Button>
      </div>
    </div>
  );
}
