import React from 'react';
import { LegacyAdminStub } from './LegacyAdminStub';

export const ApprovalsManagement = () => <LegacyAdminStub componentName="Approvals Management" />;

export default ApprovalsManagement;