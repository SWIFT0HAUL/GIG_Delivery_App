import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Users as UsersIcon, 
  Shield, 
  Trash2, 
  UserCog, 
  Loader2, 
  Search,
  CheckCircle,
  XCircle,
  Filter,
  MoreVertical,
  Eye,
  Edit,
  Mail,
  UserPlus
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ViewUserDetailsModal } from './modals/ViewUserDetailsModal';
import { EditUserModal } from './modals/EditUserModal';
import { AssignRoleModal } from './modals/AssignRoleModal';
import { SendMessageModal } from './modals/SendMessageModal';
import { CreateUserModal } from './modals/CreateUserModal';

interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  phone?: string | null;
  account_number: string | null;
  role_key: string | null;
  sub_role?: string | null;
  is_approved: boolean;
  is_active: boolean;
  is_system_account: boolean;
  onboarding_complete: boolean;
  email_confirmed: boolean;
  created_at: string;
  has_approval_checklist?: boolean;
  has_activation_checklist?: boolean;
}

export const UserManagement = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [deleteUserId, setDeleteUserId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  
  // Modal states
  const [viewDetailsUser, setViewDetailsUser] = useState<UserProfile | null>(null);
  const [editUser, setEditUser] = useState<UserProfile | null>(null);
  const [assignRoleUser, setAssignRoleUser] = useState<UserProfile | null>(null);
  const [sendMessageUser, setSendMessageUser] = useState<UserProfile | null>(null);
  const [showCreateUserModal, setShowCreateUserModal] = useState(false);

  const fetchUsers = async () => {
    setLoading(true);
    try {
      // 1) Fetch profiles
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select(`
          id,
          email,
          full_name,
          phone,
          role_key,
          sub_role,
          is_approved,
          is_active,
          is_system_account,
          onboarding_complete,
          email_confirmed,
          created_at
        `)
        .order('created_at', { ascending: false });

      if (profilesError) throw profilesError;

      // 2) Fetch user codes (account numbers) and map by user_id
      const { data: accounts, error: accountsError } = await supabase
        .from('user_account_number')
        .select('user_id, account_number');

      if (accountsError) throw accountsError;

      const accountMap = new Map<string, string>(
        (accounts || []).map((a: any) => [a.user_id, a.account_number])
      );

      // 3) Fetch completed approval checklists
      const { data: approvalChecklists } = await supabase
        .from('user_approval_checklists')
        .select('user_id, status')
        .eq('status', 'completed');

      const approvalChecklistSet = new Set(
        (approvalChecklists || []).map((c: any) => c.user_id)
      );

      // 4) Fetch completed activation checklists
      const { data: activationChecklists } = await supabase
        .from('user_preactivation_checklists')
        .select('user_id, status')
        .eq('status', 'completed');

      const activationChecklistSet = new Set(
        (activationChecklists || []).map((c: any) => c.user_id)
      );

      const combined = (profiles || []).map((u: any) => ({
        ...u,
        account_number: accountMap.get(u.id) || null,
        has_approval_checklist: approvalChecklistSet.has(u.id),
        has_activation_checklist: activationChecklistSet.has(u.id),
      }));

      setUsers(combined as UserProfile[]);
    } catch (error: any) {
      console.error('Error fetching users:', error);
      toast({
        title: "Error",
        description: "Failed to load users",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleDeleteUser = async () => {
    if (!deleteUserId) return;

    try {
      const user = users.find(u => u.id === deleteUserId);
      if (user?.is_system_account) {
        toast({
          title: "Protected Account",
          description: "System accounts cannot be deleted",
          variant: "destructive",
        });
        setDeleteUserId(null);
        return;
      }

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(
        'https://cqoydkxlonzobykwjcin.supabase.co/functions/v1/admin-delete-user',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ userId: deleteUserId }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to delete user');
      }

      toast({
        title: "User Deleted",
        description: "User account has been removed",
      });

      fetchUsers();
    } catch (error: any) {
      console.error('Delete error:', error);
      toast({
        title: "Delete Failed",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
    } finally {
      setDeleteUserId(null);
    }
  };

  const toggleUserStatus = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: "Status Updated",
        description: `User ${!currentStatus ? 'activated' : 'suspended'}`,
      });

      fetchUsers();
    } catch (error: any) {
      console.error('Status update error:', error);
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const toggleUserApproval = async (userId: string, currentStatus: boolean) => {
    // Check if trying to approve and completed checklist doesn't exist
    const user = users.find(u => u.id === userId);
    if (!currentStatus && !user?.has_approval_checklist) {
      toast({
        title: "Cannot Approve User",
        description: "User must have a completed User Pre-Approval Verification Checklist (status: 'completed') on file before approval.",
        variant: "destructive",
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_approved: !currentStatus })
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: "Approval Updated",
        description: `User ${!currentStatus ? 'approved' : 'unapproved'}`,
      });

      fetchUsers();
    } catch (error: any) {
      console.error('Approval update error:', error);
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const toggleUserActivation = async (userId: string, currentStatus: boolean) => {
    // Check if trying to activate
    const user = users.find(u => u.id === userId);
    if (!currentStatus) {
      // Must have completed activation checklist
      if (!user?.has_activation_checklist) {
        toast({
          title: "Cannot Activate User",
          description: "User must have a completed User Pre-Activating Verification Checklist (status: 'completed') on file before activation.",
          variant: "destructive",
        });
        return;
      }
      // Must be approved
      if (!user?.is_approved) {
        toast({
          title: "Cannot Activate User",
          description: "User must be approved before activation. Please approve the user first.",
          variant: "destructive",
        });
        return;
      }
    }

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus })
        .eq('id', userId);

      if (error) throw error;

      toast({
        title: "Status Updated",
        description: `User ${!currentStatus ? 'activated' : 'deactivated'}`,
      });

      fetchUsers();
    } catch (error: any) {
      console.error('Status update error:', error);
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.email?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.full_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.account_number?.includes(searchQuery);
    
    const matchesRole = roleFilter === 'all' || user.role_key === roleFilter;
    const matchesStatus = 
      statusFilter === 'all' ||
      (statusFilter === 'active' && user.is_active) ||
      (statusFilter === 'suspended' && !user.is_active) ||
      (statusFilter === 'approved' && user.is_approved) ||
      (statusFilter === 'pending' && !user.is_approved);

    return matchesSearch && matchesRole && matchesStatus;
  });

  const activeUsers = users.filter(u => u.is_active).length;
  const pendingApprovals = users.filter(u => !u.is_approved).length;
  const totalUsers = users.length;

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total Users</CardDescription>
            <CardTitle className="text-3xl">{totalUsers}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Active Users</CardDescription>
            <CardTitle className="text-3xl text-green-600">{activeUsers}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Pending Approvals</CardDescription>
            <CardTitle className="text-3xl text-orange-600">{pendingApprovals}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by email, name, or user code..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="super_admin">Super Admin</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="vendor_merchant">Vendor/Merchant</SelectItem>
                <SelectItem value="shipper">Shipper</SelectItem>
                <SelectItem value="broker">Broker</SelectItem>
                <SelectItem value="driver">Driver</SelectItem>
                <SelectItem value="carrier">Carrier</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="pending">Pending Approval</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center space-x-2">
                <UserCog className="h-5 w-5" />
                <span>User Directory</span>
              </CardTitle>
              <CardDescription>
                {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''} found. System accounts are protected from deletion.
              </CardDescription>
            </div>
            <Button onClick={() => setShowCreateUserModal(true)} className="gap-2">
              <UserPlus className="h-4 w-4" />
              Create User
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Email</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>User Code</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Sub-Role</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Approval</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                      No users found matching your criteria
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.email}</TableCell>
                      <TableCell>{user.full_name || '-'}</TableCell>
                      <TableCell>{user.account_number || '-'}</TableCell>
                      <TableCell>
                        <Badge variant={user.role_key === 'super_admin' ? 'destructive' : 'default'}>
                          {user.role_key || 'none'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.sub_role ? (
                          <Badge variant="outline" className="text-xs">
                            {user.sub_role}
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.is_active ? 'default' : 'secondary'}>
                          {user.is_active ? 'Active' : 'Suspended'}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant={user.is_approved ? 'default' : 'outline'}>
                          {user.is_approved ? (
                            <><CheckCircle className="h-3 w-3 mr-1" />Approved</>
                          ) : (
                            <><XCircle className="h-3 w-3 mr-1" />Pending</>
                          )}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {user.is_system_account && (
                          <Badge variant="outline" className="border-red-500 text-red-500">
                            <Shield className="h-3 w-3 mr-1" />
                            System
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-48">
                            <DropdownMenuLabel>Actions</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem onClick={() => setViewDetailsUser(user)}>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            {!user.is_system_account && (
                              <>
                                <DropdownMenuItem onClick={() => setEditUser(user)}>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Edit User
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => toggleUserActivation(user.id, user.is_active)}>
                                  {user.is_active ? 'Deactivate' : 'Activate'}
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => toggleUserApproval(user.id, user.is_approved)}>
                                  {user.is_approved ? 'Unapprove' : 'Approve'}
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => setAssignRoleUser(user)}>
                                  <Shield className="h-4 w-4 mr-2" />
                                  Assign Role
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => setSendMessageUser(user)}>
                                  <Mail className="h-4 w-4 mr-2" />
                                  Send Message
                                </DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem 
                                  className="text-destructive"
                                  onClick={() => setDeleteUserId(user.id)}
                                >
                                  Delete User
                                </DropdownMenuItem>
                              </>
                            )}
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Modals */}
      <CreateUserModal
        open={showCreateUserModal}
        onOpenChange={setShowCreateUserModal}
        onSuccess={fetchUsers}
      />

      {viewDetailsUser && (
        <ViewUserDetailsModal
          open={!!viewDetailsUser}
          onOpenChange={(open) => !open && setViewDetailsUser(null)}
          user={viewDetailsUser}
          onRefresh={fetchUsers}
        />
      )}

      {editUser && (
        <EditUserModal
          open={!!editUser}
          onOpenChange={(open) => !open && setEditUser(null)}
          user={editUser}
          onSuccess={fetchUsers}
        />
      )}

      {assignRoleUser && (
        <AssignRoleModal
          open={!!assignRoleUser}
          onOpenChange={(open) => !open && setAssignRoleUser(null)}
          user={assignRoleUser}
          onSuccess={fetchUsers}
        />
      )}

      {sendMessageUser && (
        <SendMessageModal
          open={!!sendMessageUser}
          onOpenChange={(open) => !open && setSendMessageUser(null)}
          user={sendMessageUser}
        />
      )}

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteUserId} onOpenChange={() => setDeleteUserId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete User Account</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the user account
              and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-destructive">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default UserManagement;