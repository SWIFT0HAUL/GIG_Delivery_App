import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { JobStatusIndicator } from '@/components/job/JobStatusIndicator';
import { JobMapView } from '@/components/driver/JobMapView';
import { getJobDuration, formatDuration } from '@/lib/durationUtils';
import {
  MapPin,
  DollarSign,
  Clock,
  User,
  Package,
  Truck,
  FileText,
  AlertTriangle,
  ThermometerSnowflake,
  Shield,
  TrendingUp,
  Star,
  MessageSquare,
  Phone,
  AlertCircle,
  Camera,
  CheckCircle,
  PenTool,
} from 'lucide-react';
import { format } from 'date-fns';
import { calculateJobCost } from '@/lib/jobCostCalculator';

interface AdminJobDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  job: {
    id: string;
    title: string;
    description?: string;
    pickup_location: any;
    delivery_location: any;
    dropoff_locations?: any[];
    pay_amount?: number;
    estimated_duration?: number;
    distance_miles?: number;
    pickup_time?: string;
    delivery_time?: string;
    status?: string;
    priority?: string;
    assigned_driver_id?: string | null;
    special_instructions?: string;
    cargo_details?: any;
    cargo_weight?: number;
    cargo_dimensions?: any;
    signature_required?: boolean;
    require_signature?: boolean;
    pickup_contact_name?: string;
    pickup_contact_phone?: string;
    delivery_contact_name?: string;
    delivery_contact_phone?: string;
    equipment_type?: string;
    trailer_type?: string;
    is_hazmat?: boolean;
    hazmat_details?: string;
    temperature_requirements?: string;
    required_certifications?: string[];
    insurance_requirements?: string;
    payment_terms?: string;
    broker_notes?: string;
    broker_commission?: number;
    carrier_rate?: number;
    invoice_id?: string;
    rating?: number;
    feedback?: string;
    cancellation_reason?: string;
    delay_reason?: string;
    proof_of_delivery_url?: string;
    created_at?: string;
    updated_at?: string;
    accepted_at?: string;
    started_at?: string;
    completed_at?: string;
    actual_delivery_time?: string;
    cancelled_at?: string;
    created_by?: string;
    shipper_id?: string;
    carrier_id?: string;
    broker_id?: string;
    vendor_id?: string;
    metadata?: {
      actual_pickup_time?: string;
      pickup_photo_url?: string;
      signature_url?: string;
      recipient_name?: string;
      delivery_notes?: string;
      dropoff_location_type?: string;
      specific_delivery_area?: string;
      actual_dropoff_location?: any;
    };
  };
}

const getFullAddress = (location: any) => {
  if (!location) return 'No address provided';
  if (typeof location === 'string') return location;
  if (location.address) return location.address;
  if (location.formatted_address) return location.formatted_address;
  
  const parts = [];
  if (location.street_number) parts.push(location.street_number);
  if (location.city) parts.push(location.city);
  if (location.state) parts.push(location.state);
  if (location.zip || location.postal_code) parts.push(location.zip || location.postal_code);
  
  return parts.length > 0 ? parts.join(', ') : 'Address not available';
};

const getPriorityColor = (priority?: string) => {
  switch (priority?.toLowerCase()) {
    case 'critical':
      return 'destructive';
    case 'high':
      return 'default';
    case 'medium':
      return 'secondary';
    case 'low':
      return 'outline';
    default:
      return 'secondary';
  }
};

export const AdminJobDetailsDialog: React.FC<AdminJobDetailsDialogProps> = ({
  open,
  onOpenChange,
  job,
}) => {
  if (!job) {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Job Not Found</DialogTitle>
            <DialogDescription>
              Unable to load job details. Please try again.
            </DialogDescription>
          </DialogHeader>
        </DialogContent>
      </Dialog>
    );
  }

  const pickupTime = job.pickup_time ? new Date(job.pickup_time) : null;
  const deliveryTime = job.delivery_time ? new Date(job.delivery_time) : null;
  const [activeTab, setActiveTab] = useState('overview');

  const calculatedCost = calculateJobCost({
    distanceMiles: job.distance_miles || 0,
    weight: (job.cargo_details as any)?.weight || job.cargo_weight || 0,
    vehicleType: (job.cargo_details as any)?.vehicleType || 'Car/SUV',
    createdDate: new Date(job.created_at || new Date()),
  });

  const displayDuration = getJobDuration(job.estimated_duration, job.distance_miles);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">{job.title}</DialogTitle>
          <DialogDescription className="text-sm text-muted-foreground">
            Job ID: #{job.id.slice(0, 8)}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Status and Priority */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="text-lg font-semibold">{job.title}</h3>
              <p className="text-sm text-muted-foreground">Job ID: #{job.id.slice(0, 8)}</p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <JobStatusIndicator status={job.status} />
              {job.priority && (
                <Badge variant={getPriorityColor(job.priority)}>
                  {job.priority.toUpperCase()} Priority
                </Badge>
              )}
              {job.is_hazmat && (
                <Badge variant="destructive" className="flex items-center gap-1">
                  <AlertTriangle className="h-3 w-3" />
                  HAZMAT
                </Badge>
              )}
            </div>
          </div>

          <Separator />

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="locations">Locations</TabsTrigger>
              <TabsTrigger value="cargo">Cargo & Equipment</TabsTrigger>
              <TabsTrigger value="financial">Financial</TabsTrigger>
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4">
              {job.description && (
                <div className="p-4 border rounded-lg">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    Description
                  </h4>
                  <p className="text-sm text-muted-foreground">{job.description}</p>
                </div>
              )}

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex gap-3 p-3 border rounded-lg">
                  <DollarSign className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-xs text-muted-foreground">Pay Amount</p>
                    <p className="text-lg font-semibold">${job.pay_amount?.toLocaleString() || '0'}</p>
                  </div>
                </div>
                <div className="flex gap-3 p-3 border rounded-lg">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Distance</p>
                    <p className="text-lg font-semibold">{job.distance_miles || 'N/A'} mi</p>
                  </div>
                </div>
                <div className="flex gap-3 p-3 border rounded-lg">
                  <Clock className="h-5 w-5 text-muted-foreground" />
                  <div>
                    <p className="text-xs text-muted-foreground">Duration</p>
                    <p className="text-lg font-semibold">{formatDuration(displayDuration)}</p>
                  </div>
                </div>
                <div className="flex gap-3 p-3 border rounded-lg bg-accent/5">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-xs text-muted-foreground">Calculated Cost</p>
                    <p className="text-lg font-semibold">${calculatedCost.toLocaleString()}</p>
                  </div>
                </div>
              </div>

              {job.special_instructions && (
                <div className="p-4 border rounded-lg bg-amber-50 dark:bg-amber-950">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-amber-600" />
                    Special Instructions
                  </h4>
                  <p className="text-sm text-muted-foreground">{job.special_instructions}</p>
                </div>
              )}

              {job.broker_notes && (
                <div className="p-4 border rounded-lg">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <MessageSquare className="h-4 w-4" />
                    Broker Notes
                  </h4>
                  <p className="text-sm text-muted-foreground">{job.broker_notes}</p>
                </div>
              )}

              {(job.rating || job.feedback) && (
                <div className="p-4 border rounded-lg">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <Star className="h-4 w-4" />
                    Rating & Feedback
                  </h4>
                  {job.rating && (
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm text-muted-foreground">Rating:</span>
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`h-4 w-4 ${i < job.rating! ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} />
                        ))}
                      </div>
                    </div>
                  )}
                  {job.feedback && (
                    <p className="text-sm text-muted-foreground">{job.feedback}</p>
                  )}
                </div>
              )}

              {(job.cancellation_reason || job.delay_reason) && (
                <div className="p-4 border rounded-lg bg-red-50 dark:bg-red-950">
                  <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
                    <AlertTriangle className="h-4 w-4 text-red-600" />
                    Issues
                  </h4>
                  {job.cancellation_reason && (
                    <p className="text-sm text-muted-foreground mb-1">
                      <span className="font-medium">Cancellation:</span> {job.cancellation_reason}
                    </p>
                  )}
                  {job.delay_reason && (
                    <p className="text-sm text-muted-foreground">
                      <span className="font-medium">Delay:</span> {job.delay_reason}
                    </p>
                  )}
                </div>
              )}
            </TabsContent>

            {/* Locations Tab */}
            <TabsContent value="locations" className="space-y-4">
              <div className="space-y-4">
                {/* Map View */}
                <JobMapView
                  pickupLocation={
                    job.pickup_location?.lat && job.pickup_location?.lng
                      ? {
                          lat: job.pickup_location.lat,
                          lng: job.pickup_location.lng,
                          address: getFullAddress(job.pickup_location),
                        }
                      : null
                  }
                  deliveryLocation={
                    job.delivery_location?.lat && job.delivery_location?.lng
                      ? {
                          lat: job.delivery_location.lat,
                          lng: job.delivery_location.lng,
                          address: getFullAddress(job.delivery_location),
                        }
                      : null
                  }
                  jobTitle={job.title}
                />

                {/* Pickup Location */}
                <div className="p-4 border rounded-lg bg-green-50 dark:bg-green-950">
                  <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-green-600" />
                    Pickup Location
                  </h4>
                  <p className="text-sm text-muted-foreground">{getFullAddress(job.pickup_location)}</p>
                  {pickupTime && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Scheduled Pickup: {format(pickupTime, 'PPpp')}
                    </p>
                  )}
                  {(job.pickup_contact_name || job.pickup_contact_phone) && (
                    <div className="mt-2 space-y-1">
                      {job.pickup_contact_name && (
                        <p className="text-sm flex items-center gap-2">
                          <User className="h-4 w-4" />
                          {job.pickup_contact_name}
                        </p>
                      )}
                      {job.pickup_contact_phone && (
                        <p className="text-sm flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          {job.pickup_contact_phone}
                        </p>
                      )}
                    </div>
                  )}
                </div>

                {/* Delivery Location */}
                <div className="p-4 border rounded-lg bg-red-50 dark:bg-red-950">
                  <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <MapPin className="h-5 w-5 text-red-600" />
                    Delivery Location
                  </h4>
                  <p className="text-sm text-muted-foreground">{getFullAddress(job.delivery_location)}</p>
                  {deliveryTime && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Scheduled Delivery: {format(deliveryTime, 'PPpp')}
                    </p>
                  )}
                  {(job.delivery_contact_name || job.delivery_contact_phone) && (
                    <div className="mt-2 space-y-1">
                      {job.delivery_contact_name && (
                        <p className="text-sm flex items-center gap-2">
                          <User className="h-4 w-4" />
                          {job.delivery_contact_name}
                        </p>
                      )}
                      {job.delivery_contact_phone && (
                        <p className="text-sm flex items-center gap-2">
                          <Phone className="h-4 w-4" />
                          {job.delivery_contact_phone}
                        </p>
                      )}
                    </div>
                  )}
                  {(job.signature_required || job.require_signature) && (
                    <p className="text-sm text-muted-foreground mt-2 flex items-center gap-2">
                      <FileText className="h-4 w-4" />
                      Signature required upon delivery
                    </p>
                  )}
                </div>

                {/* Dropoff Locations */}
                {job.dropoff_locations && job.dropoff_locations.length > 0 && (
                  <div className="p-4 border rounded-lg bg-yellow-50 dark:bg-yellow-950">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <MapPin className="h-5 w-5 text-yellow-600" />
                      Dropoff Locations
                    </h4>
                    <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                      {job.dropoff_locations.map((loc, idx) => (
                        <li key={idx}>{getFullAddress(loc)}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Cargo Tab */}
            <TabsContent value="cargo" className="space-y-4">
              <div className="space-y-4">
                {/* Cargo Details */}
                {job.cargo_details && (
                  <div className="p-4 border rounded-lg">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <Package className="h-5 w-5 text-muted-foreground" />
                      Cargo Details
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {job.cargo_details.description || 'No description provided.'}
                    </p>
                    {job.cargo_details.weight && (
                      <p className="text-sm text-muted-foreground mt-1">
                        Weight: {job.cargo_details.weight} lbs
                      </p>
                    )}
                    {job.cargo_details.vehicle_type && (
                      <p className="text-sm text-muted-foreground mt-1">
                        Vehicle Type Required: {job.cargo_details.vehicle_type}
                      </p>
                    )}
                    {job.cargo_dimensions && (
                      <p className="text-sm text-muted-foreground mt-1">
                        Dimensions: {job.cargo_dimensions.length} x {job.cargo_dimensions.width} x {job.cargo_dimensions.height} (LxWxH)
                      </p>
                    )}
                  </div>
                )}

                {/* Equipment Requirements */}
                {(job.equipment_type || job.trailer_type || job.is_hazmat) && (
                  <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <Truck className="h-5 w-5 text-blue-600" />
                      Equipment Requirements
                    </h4>
                    {job.equipment_type && (
                      <p className="text-sm text-muted-foreground">
                        Vehicle Type: {job.equipment_type}
                      </p>
                    )}
                    {job.trailer_type && (
                      <p className="text-sm text-muted-foreground">
                        Trailer Type: {job.trailer_type}
                      </p>
                    )}
                    {job.is_hazmat && (
                      <p className="text-sm text-red-600 font-semibold">
                        HAZMAT Material
                      </p>
                    )}
                  </div>
                )}

                {/* Temperature Requirements */}
                {job.temperature_requirements && (
                  <div className="p-4 border rounded-lg bg-cyan-50 dark:bg-cyan-950">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <ThermometerSnowflake className="h-5 w-5 text-cyan-600" />
                      Temperature Control
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      {job.temperature_requirements}
                    </p>
                  </div>
                )}

                {/* Required Certifications */}
                {job.required_certifications && job.required_certifications.length > 0 && (
                  <div className="p-4 border rounded-lg bg-amber-50 dark:bg-amber-950">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <Shield className="h-5 w-5 text-amber-600" />
                      Required Certifications
                    </h4>
                    <ul className="list-disc list-inside text-sm text-muted-foreground">
                      {job.required_certifications.map((cert, idx) => (
                        <li key={idx}>{cert}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Special Instructions */}
                {job.special_instructions && (
                  <div className="p-4 border rounded-lg bg-orange-50 dark:bg-orange-950">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <AlertCircle className="h-5 w-5 text-orange-600" />
                      Special Instructions
                    </h4>
                    <p className="text-sm text-muted-foreground">{job.special_instructions}</p>
                  </div>
                )}

                {/* HAZMAT Details */}
                {job.hazmat_details && (
                  <div className="p-4 border rounded-lg bg-red-50 dark:bg-red-950">
                    <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-red-600" />
                      HAZMAT Details
                    </h4>
                    <p className="text-sm text-muted-foreground">{job.hazmat_details}</p>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Financial Tab */}
            <TabsContent value="financial" className="space-y-4">
              <div className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="text-lg font-semibold mb-2 flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" />
                    Financial Details
                  </h4>
                  <p className="text-sm text-muted-foreground">
                    Pay Amount: ${job.pay_amount?.toLocaleString() || '0'}
                  </p>
                  {job.broker_commission !== undefined && job.broker_commission !== null && (
                    <p className="text-sm text-muted-foreground">
                      Broker Commission: ${job.broker_commission?.toLocaleString() || '0'}
                    </p>
                  )}
                  {job.carrier_rate !== undefined && job.carrier_rate !== null && (
                    <p className="text-sm text-muted-foreground">
                      Carrier Rate: ${job.carrier_rate?.toLocaleString() || '0'}
                    </p>
                  )}
                  {job.invoice_id && (
                    <p className="text-sm text-muted-foreground">
                      Invoice ID: {job.invoice_id}
                    </p>
                  )}
                  {job.payment_terms && (
                    <p className="text-sm text-muted-foreground">
                      Payment Terms: {job.payment_terms}
                    </p>
                  )}
                </div>
              </div>
            </TabsContent>

            {/* Timeline Tab */}
            <TabsContent value="timeline" className="space-y-0">
              <div className="relative">
                {/* Vertical connecting line */}
                <div className="absolute left-6 top-4 bottom-4 w-px bg-border" />
                
                <div className="space-y-0">
                  {/* Job Creation */}
                  {job.created_at && (
                    <div className="relative pl-14 pr-4 py-4 border-b">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-blue-100 dark:bg-blue-900 border-4 border-background z-10">
                        <FileText className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Job Created</h5>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(job.created_at), 'PPpp')}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Job Accepted */}
                  {job.accepted_at && (
                    <div className="relative pl-14 pr-4 py-4 border-b">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-green-100 dark:bg-green-900 border-4 border-background z-10">
                        <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Job Accepted</h5>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(job.accepted_at), 'PPpp')}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Job Started / Pickup */}
                  {(job.started_at || (job as any).metadata?.actual_pickup_time) && (
                    <div className="relative pl-14 pr-4 py-4 border-b">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-purple-100 dark:bg-purple-900 border-4 border-background z-10">
                        <Truck className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Picked Up</h5>
                        <p className="text-xs text-muted-foreground mt-1">
                          <span className="font-medium">Actual Pickup:</span> {format(new Date((job as any).metadata?.actual_pickup_time || job.started_at), 'PPpp')}
                        </p>
                        
                        {/* Pickup Photo */}
                        {(job as any).metadata?.pickup_photo_url && (
                          <div className="mt-3">
                            <div className="flex items-center gap-2 mb-2">
                              <Camera className="h-4 w-4 text-muted-foreground" />
                              <span className="text-xs font-medium">Pickup Photo</span>
                            </div>
                            <img 
                              src={(job as any).metadata.pickup_photo_url} 
                              alt="Pickup proof photo" 
                              loading="lazy"
                              className="w-full max-w-sm rounded-lg border"
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Drop-off Locations */}
                  {job.dropoff_locations && job.dropoff_locations.length > 0 && (
                    <div className="relative pl-14 pr-4 py-4 border-b">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-yellow-100 dark:bg-yellow-900 border-4 border-background z-10">
                        <MapPin className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Drop-off Stops</h5>
                        <div className="mt-2 space-y-2">
                          {job.dropoff_locations.map((loc, idx) => (
                            <div key={idx} className="p-2 bg-muted/50 rounded border">
                              <p className="text-xs font-medium">Stop {idx + 1}</p>
                              <p className="text-xs text-muted-foreground mt-1">
                                {getFullAddress(loc)}
                              </p>
                              {(loc as any).completed_at && (
                                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                                  ✓ Completed: {format(new Date((loc as any).completed_at), 'PPp')}
                                </p>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Job Completed / Delivery */}
                  {(job.completed_at || job.actual_delivery_time) && (
                    <div className="relative pl-14 pr-4 py-4 border-b">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-emerald-100 dark:bg-emerald-900 border-4 border-background z-10">
                        <CheckCircle className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Delivery Completed</h5>
                        <p className="text-xs text-muted-foreground mt-1">
                          <span className="font-medium">Completed At:</span> {job.actual_delivery_time 
                            ? format(new Date(job.actual_delivery_time), 'PPpp')
                            : job.completed_at 
                              ? format(new Date(job.completed_at), 'PPpp')
                              : 'Time not recorded'}
                        </p>

                        {/* Drop-off Location Type */}
                        {(job as any).metadata?.dropoff_location_type && (
                          <div className="mt-2 flex items-start gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                            <div className="text-xs text-muted-foreground">
                              <p className="font-medium">Drop-off Location Type</p>
                              <p>{(job as any).metadata.dropoff_location_type}</p>
                            </div>
                          </div>
                        )}

                        {/* Specific Delivery Area */}
                        {(job as any).metadata?.specific_delivery_area && (
                          <div className="mt-2 flex items-start gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                            <div className="text-xs text-muted-foreground">
                              <p className="font-medium">Specific Delivery Area</p>
                              <p>{(job as any).metadata.specific_delivery_area}</p>
                            </div>
                          </div>
                        )}

                        {/* Actual Drop-off Location (if different) */}
                        {(job as any).metadata?.actual_dropoff_location && (
                          <div className="mt-2 flex items-start gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground mt-0.5" />
                            <div className="text-xs text-muted-foreground">
                              <p className="font-medium">Actual Drop-off Location</p>
                              <p>{getFullAddress((job as any).metadata.actual_dropoff_location)}</p>
                            </div>
                          </div>
                        )}

                        {/* Delivery Photo */}
                        {job.proof_of_delivery_url && (
                          <div className="mt-3">
                            <div className="flex items-center gap-2 mb-2">
                              <Camera className="h-4 w-4 text-muted-foreground" />
                              <span className="text-xs font-medium">Proof of Delivery</span>
                            </div>
                            <img 
                              src={job.proof_of_delivery_url} 
                              alt="Proof of delivery photo" 
                              loading="lazy"
                              className="w-full max-w-sm rounded-lg border"
                            />
                          </div>
                        )}

                        {/* Signature */}
                        {(job as any).metadata?.signature_url && (
                          <div className="mt-3">
                            <div className="flex items-center gap-2 mb-2">
                              <PenTool className="h-4 w-4 text-muted-foreground" />
                              <span className="text-xs font-medium">Recipient Signature</span>
                            </div>
                            <img 
                              src={(job as any).metadata.signature_url} 
                              alt="Recipient signature image" 
                              loading="lazy"
                              className="w-full max-w-xs rounded-lg border bg-white dark:bg-gray-900"
                            />
                          </div>
                        )}

                        {/* Additional Completion Details */}
                        {((job as any).metadata?.delivery_notes || (job as any).metadata?.recipient_name) && (
                          <div className="mt-2 space-y-1 text-xs text-muted-foreground">
                            {(job as any).metadata?.recipient_name && (
                              <p><span className="font-medium">Received by:</span> {(job as any).metadata.recipient_name}</p>
                            )}
                            {(job as any).metadata?.delivery_notes && (
                              <p><span className="font-medium">Delivery Notes:</span> {(job as any).metadata.delivery_notes}</p>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Job Cancelled */}
                  {job.cancelled_at && (
                    <div className="relative pl-14 pr-4 py-4 border-b">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-red-100 dark:bg-red-900 border-4 border-background z-10">
                        <AlertTriangle className="h-4 w-4 text-red-600 dark:text-red-400" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Job Cancelled</h5>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(job.cancelled_at), 'PPpp')}
                        </p>
                        {job.cancellation_reason && (
                          <p className="text-xs text-muted-foreground mt-2">
                            <span className="font-medium">Reason:</span> {job.cancellation_reason}
                          </p>
                        )}
                      </div>
                    </div>
                  )}

                  {/* Last Updated */}
                  {job.updated_at && (
                    <div className="relative pl-14 pr-4 py-4">
                      <div className="absolute left-4 top-4 p-2 rounded-full bg-muted border-4 border-background z-10">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <div>
                        <h5 className="font-semibold text-sm">Last Updated</h5>
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(job.updated_at), 'PPpp')}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
};
