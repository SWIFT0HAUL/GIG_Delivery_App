import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Users, Briefcase, DollarSign, AlertTriangle, 
  TrendingUp, CheckCircle, Clock, UserCheck,
  Package, Car, FileText, Shield, Activity
} from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const COLORS = ['hsl(var(--primary))', 'hsl(var(--chart-2))', 'hsl(var(--chart-3))', 'hsl(var(--chart-4))', 'hsl(var(--chart-5))'];

export const AdminDashboardOverview: React.FC = () => {
  // Fetch comprehensive platform data
  const { data: stats, isLoading } = useQuery({
    queryKey: ['admin-dashboard-overview'],
    queryFn: async () => {
      // Users stats
      const { data: profiles, error: profilesError } = await supabase
        .from('profiles')
        .select('id, created_at');
      
      if (profilesError) throw profilesError;

      // Get user metadata for roles
      const { data: authUsers } = await supabase.auth.admin.listUsers();
      const usersWithRoles = authUsers?.users || [];

      // Jobs stats
      const { data: jobs, error: jobsError } = await supabase
        .from('jobs')
        .select('status, pay_amount, created_at, completed_at, priority');
      
      if (jobsError) throw jobsError;

      // Driver status
      const { data: driverStatus, error: driverError } = await supabase
        .from('driver_status')
        .select('is_online, driver_id');
      
      if (driverError) throw driverError;

      // Disputes
      const { data: disputes, error: disputesError } = await supabase
        .from('disputes')
        .select('status, priority, created_at');
      
      if (disputesError) throw disputesError;

      // KYC submissions
      const { data: kycSubmissions, error: kycError } = await supabase
        .from('kyc_submissions')
        .select('status, submitted_at');
      
      if (kycError) throw kycError;

      // Invoices
      const { data: invoices, error: invoicesError } = await supabase
        .from('invoices')
        .select('status, amount, created_at');
      
      if (invoicesError) throw invoicesError;

      // Routes
      const { data: routes, error: routesError } = await supabase
        .from('routes')
        .select('status, id');
      
      if (routesError) throw routesError;

      // Process user stats
      const totalUsers = usersWithRoles.length || 0;
      const onboardedUsers = usersWithRoles.filter(u => u.user_metadata?.onboarding_complete).length || 0;
      const pendingUsers = totalUsers - onboardedUsers;
      const usersByRole = usersWithRoles.reduce((acc: any, u) => {
        const role = u.user_metadata?.role || 'unassigned';
        acc[role] = (acc[role] || 0) + 1;
        return acc;
      }, {});

      // Process job stats
      const totalJobs = jobs?.length || 0;
      const activeJobs = jobs?.filter(j => ['assigned', 'in_progress', 'in_transit', 'picked_up', 'on_hold'].includes(j.status)).length || 0;
      const completedJobs = jobs?.filter(j => j.status === 'completed').length || 0;
      const delayedJobs = jobs?.filter(j => j.status === 'delayed').length || 0;
      const pendingJobs = jobs?.filter(j => ['pending', 'posted', 'planned', 'claimed'].includes(j.status)).length || 0;
      
      const totalRevenue = jobs
        ?.filter(j => j.status === 'completed')
        .reduce((sum, j) => sum + (Number(j.pay_amount) || 0), 0) || 0;

      const jobsByStatus = jobs?.reduce((acc: any, j) => {
        acc[j.status] = (acc[j.status] || 0) + 1;
        return acc;
      }, {});

      // Process driver stats
      const totalDrivers = driverStatus?.length || 0;
      const onlineDrivers = driverStatus?.filter(d => d.is_online).length || 0;

      // Process dispute stats
      const totalDisputes = disputes?.length || 0;
      const openDisputes = disputes?.filter(d => d.status === 'open').length || 0;
      const resolvedDisputes = disputes?.filter(d => d.status === 'resolved').length || 0;

      // Process KYC stats
      const pendingKyc = kycSubmissions?.filter(k => k.status === 'pending').length || 0;
      const approvedKyc = kycSubmissions?.filter(k => k.status === 'approved').length || 0;

      // Process invoice stats
      const pendingInvoices = invoices?.filter(i => i.status === 'pending').length || 0;
      const paidInvoices = invoices?.filter(i => i.status === 'paid').length || 0;
      const totalInvoiceAmount = invoices?.reduce((sum, i) => sum + (Number(i.amount) || 0), 0) || 0;

      // Process route stats
      const activeRoutes = routes?.filter(r => r.status === 'active').length || 0;

      // Weekly job trends
      const now = new Date();
      const weeklyTrends = Array.from({ length: 7 }, (_, i) => {
        const date = new Date(now);
        date.setDate(date.getDate() - (6 - i));
        const dayStart = new Date(date.setHours(0, 0, 0, 0));
        const dayEnd = new Date(date.setHours(23, 59, 59, 999));
        
        const dayJobs = jobs?.filter(j => {
          const created = new Date(j.created_at);
          return created >= dayStart && created <= dayEnd;
        }).length || 0;

        return {
          day: dayStart.toLocaleDateString('en-US', { weekday: 'short' }),
          jobs: dayJobs
        };
      });

      return {
        users: {
          total: totalUsers,
          onboarded: onboardedUsers,
          pending: pendingUsers,
          byRole: usersByRole
        },
        jobs: {
          total: totalJobs,
          active: activeJobs,
          completed: completedJobs,
          delayed: delayedJobs,
          pending: pendingJobs,
          byStatus: jobsByStatus,
          totalRevenue
        },
        drivers: {
          total: totalDrivers,
          online: onlineDrivers,
          offline: totalDrivers - onlineDrivers
        },
        disputes: {
          total: totalDisputes,
          open: openDisputes,
          resolved: resolvedDisputes
        },
        kyc: {
          pending: pendingKyc,
          approved: approvedKyc
        },
        invoices: {
          pending: pendingInvoices,
          paid: paidInvoices,
          totalAmount: totalInvoiceAmount
        },
        routes: {
          active: activeRoutes
        },
        weeklyTrends
      };
    },
    refetchInterval: 30000 // Refresh every 30 seconds
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const statusDistribution = stats?.jobs.byStatus ? Object.entries(stats.jobs.byStatus).map(([status, count]) => ({
    name: status.replace('_', ' ').toUpperCase(),
    value: count as number
  })) : [];

  const roleDistribution = stats?.users.byRole ? Object.entries(stats.users.byRole).map(([role, count]) => ({
    name: role.replace('_', ' ').toUpperCase(),
    value: count as number
  })) : [];

  return (
    <div className="space-y-6">
      {/* Platform Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Users</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.users.total || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.users.pending || 0} pending onboarding
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">My Jobs</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.jobs.active || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.jobs.delayed || 0} delayed
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${stats?.jobs.totalRevenue.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-muted-foreground">
              From {stats?.jobs.completed || 0} completed jobs
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Online Drivers</CardTitle>
            <UserCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.drivers.online || 0}</div>
            <p className="text-xs text-muted-foreground">
              of {stats?.drivers.total || 0} total drivers
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Open Disputes</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.disputes.open || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.disputes.resolved || 0} resolved
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending KYC</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.kyc.pending || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.kyc.approved || 0} approved
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Invoices</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.invoices.pending || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.invoices.paid || 0} paid
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Routes</CardTitle>
            <Activity className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.routes.active || 0}</div>
            <p className="text-xs text-muted-foreground">Currently running</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Jobs</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.jobs.completed || 0}</div>
            <p className="text-xs text-muted-foreground">
              {stats?.jobs.total || 0} total jobs
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Job Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Weekly Job Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={stats?.weeklyTrends || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="jobs" fill="hsl(var(--primary))" name="Jobs Created" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Job Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Job Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* User Role Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>User Role Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={roleDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {roleDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Platform Health Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Platform Health</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Job Completion Rate</span>
              <span className="text-sm text-muted-foreground">
                {stats?.jobs.total ? ((stats.jobs.completed / stats.jobs.total) * 100).toFixed(1) : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Driver Availability</span>
              <span className="text-sm text-muted-foreground">
                {stats?.drivers.total ? ((stats.drivers.online / stats.drivers.total) * 100).toFixed(1) : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Dispute Resolution Rate</span>
              <span className="text-sm text-muted-foreground">
                {stats?.disputes.total ? ((stats.disputes.resolved / stats.disputes.total) * 100).toFixed(1) : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">KYC Approval Rate</span>
              <span className="text-sm text-muted-foreground">
                {(stats?.kyc.approved || 0) + (stats?.kyc.pending || 0) > 0 
                  ? ((stats.kyc.approved / ((stats.kyc.approved || 0) + (stats.kyc.pending || 0))) * 100).toFixed(1) 
                  : 0}%
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm font-medium">Invoice Payment Rate</span>
              <span className="text-sm text-muted-foreground">
                {(stats?.invoices.paid || 0) + (stats?.invoices.pending || 0) > 0 
                  ? ((stats.invoices.paid / ((stats.invoices.paid || 0) + (stats.invoices.pending || 0))) * 100).toFixed(1) 
                  : 0}%
              </span>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
