import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { 
  Settings as SettingsIcon,
  Users, 
  Bell, 
  Shield, 
  CreditCard, 
  Globe, 
  Database,
  Mail,
  Lock,
  Key,
  Palette,
  BarChart3,
  FileText,
  DollarSign,
  Webhook,
  Server,
  Monitor,
  Download,
  Upload,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Plus,
  Edit,
  Trash2,
  Save,
  Copy,
  Eye,
  EyeOff,
  Search,
  Filter,
  Calendar,
  MapPin,
  Truck,
  Building,
  Phone,
  Clock,
  Target,
  Zap,
  Link,
  Code,
  Image,
  Type,
  Layout,
  Sliders,
  User
} from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export function PlatformSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [initialLoad, setInitialLoad] = useState(true);
  
  const [settings, setSettings] = useState({
    platformName: 'Haulee',
    platformFee: 5,
    currency: 'USD',
    timezone: 'UTC',
    autoApproval: false,
    maintenanceMode: false,
    registrationOpen: true,
    emailVerificationRequired: true,
    phoneVerificationRequired: false,
    backgroundCheckRequired: true,
    insuranceRequired: true,
    licenseRequired: true,
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    systemAlerts: true,
    darkMode: false,
    autoRefresh: true,
    defaultMapView: 'street',
    theme: 'blue',
    logoUrl: '',
    primaryColor: '#3b82f6',
    secondaryColor: '#64748b',
    // Advanced Personalization Settings
    accentColor: '#f59e0b',
    backgroundColor: '#ffffff',
    surfaceColor: '#f8fafc',
    textPrimary: '#0f172a',
    textSecondary: '#64748b',
    textMuted: '#94a3b8',
    borderColor: '#e2e8f0',
    shadowColor: '#000000',
    fontFamily: 'Inter',
    headingFont: 'Inter',
    fontSize: '14',
    headingSize: '24',
    lineHeight: '1.5',
    letterSpacing: '0',
    fontWeight: '400',
    borderRadius: '8',
    buttonStyle: 'modern',
    buttonSize: 'medium',
    buttonHover: 'scale',
    hoverEffect: 'scale',
    transitionSpeed: '200',
    animationStyle: 'smooth',
    headerHeight: '64',
    headerStyle: 'solid',
    headerPosition: 'sticky',
    sidebarWidth: '280',
    sidebarStyle: 'elevated',
    cardStyle: 'elevated',
    inputStyle: 'outlined',
    iconStyle: 'outlined',
    contentPadding: 'normal',
    maxContentWidth: 'full',
    shadowIntensity: 'medium',
    gradientPrimary: 'linear-gradient(135deg, #3b82f6, #1d4ed8)',
    gradientSecondary: 'linear-gradient(135deg, #64748b, #475569)',
    customCSS: '',
    // Branding Settings
    faviconUrl: '',
    brandTagline: '',
    metaTitle: '',
    metaDescription: '',
    socialImage: '',
    // Delivery Radius Enforcement
    enableRadiusEnforcement: true,
    enablePickupRadius: true,
    enableDropoffRadius: true,
    showRadiusMap: true,
    logRadiusAttempts: true
  });

  const [systemStats, setSystemStats] = useState({
    totalUsers: 1247,
    activeJobs: 342,
    systemHealth: 98,
    uptime: '99.9%',
    storageUsed: 65,
    databaseSize: '2.3 GB',
    lastBackup: '2024-01-15 02:00 AM'
  });

  const [apiKeys, setApiKeys] = useState([
    { id: 1, name: 'Stripe API Key', value: 'sk_test_***************', status: 'active', lastUsed: '2024-01-15' },
    { id: 2, name: 'Google Maps API', value: import.meta.env.VITE_GOOGLE_MAPS_API_KEY || 'Not configured', status: 'active', lastUsed: '2024-01-15' },
    { id: 3, name: 'SendGrid API', value: 'SG.***************', status: 'inactive', lastUsed: '2024-01-10' },
  ]);

  const [editingApiKey, setEditingApiKey] = useState<number | null>(null);
  const [editApiKeyValue, setEditApiKeyValue] = useState('');

  const [permissions, setPermissions] = useState([
    { id: 1, role: 'Admin', users: 5, permissions: ['all_access'] },
    { id: 2, role: 'Driver', users: 834, permissions: ['view_jobs', 'claim_jobs'] },
    { id: 3, role: 'Vendor/Merchant', users: 89, permissions: ['manage_inventory', 'view_sales'] },
    { id: 4, role: 'Broker', users: 156, permissions: ['broker_deals', 'view_commission'] },
    { id: 5, role: 'Carrier', users: 67, permissions: ['manage_fleet', 'view_contracts'] }
  ]);
  
  const [integrations, setIntegrations] = useState([
    { name: 'Stripe', status: 'connected', type: 'payment', lastSync: '2024-01-15' },
    { name: 'Google Maps', status: 'connected', type: 'mapping', lastSync: '2024-01-15' },
    { name: 'SendGrid', status: 'disconnected', type: 'email', lastSync: '2024-01-10' },
    { name: 'Twilio', status: 'connected', type: 'sms', lastSync: '2024-01-14' },
  ]);

  // Handle setting changes with automatic save
  const handleSettingChange = async (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    
    // Apply UI effects immediately
    if (key === 'darkMode') {
      const root = document.documentElement;
      if (value) {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
    }
    
    toast({
      title: "Success",
      description: `${key} updated successfully`,
    });
  };

  const handleSaveAllSettings = async () => {
    setLoading(true);
    try {
      toast({
        title: "Success",
        description: "All settings saved successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to save some settings",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSystemOperation = async (operation: string) => {
    setLoading(true);
    try {
      toast({
        title: "Success",
        description: `${operation.replace('_', ' ')} completed successfully`
      });
    } catch (error) {
      toast({
        title: "Error",
        description: `Failed to ${operation.replace('_', ' ')}`,
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBackupDatabase = async () => {
    setLoading(true);
    try {
      toast({
        title: "Backup Completed",
        description: "Database backup completed successfully"
      });
      
      setSystemStats(prev => ({
        ...prev,
        lastBackup: new Date().toLocaleString()
      }));
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to backup database",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleEditApiKey = (keyId: number) => {
    const key = apiKeys.find(k => k.id === keyId);
    if (key) {
      setEditingApiKey(keyId);
      setEditApiKeyValue(key.value);
    }
  };

  const handleSaveApiKey = async (keyId: number) => {
    if (keyId === 2) { // Google Maps API Key
      setLoading(true);
      try {
        // Update Supabase secret
        const { data, error } = await supabase.functions.invoke('update-google-maps-key', {
          body: { apiKey: editApiKeyValue }
        });

        if (error) throw error;

        // Update local state
        setApiKeys(prev => prev.map(key => 
          key.id === keyId 
            ? { ...key, value: editApiKeyValue, lastUsed: new Date().toLocaleDateString() }
            : key
        ));

        setEditingApiKey(null);
        setEditApiKeyValue('');

        toast({
          title: "Success",
          description: data?.message || "API key updated successfully. Edge functions will use the new key after redeployment.",
        });
      } catch (error) {
        console.error('Error updating API key:', error);
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to update API key",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    } else {
      // For other API keys, just update locally (add backend logic as needed)
      setApiKeys(prev => prev.map(key => 
        key.id === keyId 
          ? { ...key, value: editApiKeyValue, lastUsed: new Date().toLocaleDateString() }
          : key
      ));
      setEditingApiKey(null);
      setEditApiKeyValue('');
      toast({
        title: "Success",
        description: "API key updated locally"
      });
    }
  };

  const handleCancelEdit = () => {
    setEditingApiKey(null);
    setEditApiKeyValue('');
  };

  useEffect(() => {
    setInitialLoad(false);
  }, []);

  if (initialLoad) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">Platform Settings</h2>
        <p className="text-muted-foreground">
          Comprehensive platform configuration and management tools
        </p>
      </div>

      <Tabs defaultValue="platform" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="platform">Platform</TabsTrigger>
          <TabsTrigger value="users">Users</TabsTrigger>
          <TabsTrigger value="system">System</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="customization">Customization</TabsTrigger>
        </TabsList>

        {/* Platform Configuration */}
        <TabsContent value="platform" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Globe className="h-5 w-5" />
                  <span>General Settings</span>
                </CardTitle>
                <CardDescription>Basic platform configuration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="platformName">Platform Name</Label>
                  <Input 
                    id="platformName" 
                    value={settings.platformName}
                    onChange={(e) => handleSettingChange('platformName', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="platformFee">Platform Fee (%)</Label>
                  <Input 
                    id="platformFee" 
                    type="number"
                    value={settings.platformFee}
                    onChange={(e) => handleSettingChange('platformFee', parseFloat(e.target.value))}
                  />
                </div>
                <div>
                  <Label htmlFor="currency">Default Currency</Label>
                  <Select value={settings.currency} onValueChange={(value) => handleSettingChange('currency', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">USD - US Dollar</SelectItem>
                      <SelectItem value="EUR">EUR - Euro</SelectItem>
                      <SelectItem value="GBP">GBP - British Pound</SelectItem>
                      <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="timezone">Default Timezone</Label>
                  <Select value={settings.timezone} onValueChange={(value) => handleSettingChange('timezone', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC - Coordinated Universal Time</SelectItem>
                      <SelectItem value="EST">EST - Eastern Standard Time</SelectItem>
                      <SelectItem value="PST">PST - Pacific Standard Time</SelectItem>
                      <SelectItem value="GMT">GMT - Greenwich Mean Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Operational Settings</span>
                </CardTitle>
                <CardDescription>Control platform operations</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Auto-approve Users</Label>
                    <div className="text-sm text-muted-foreground">
                      Automatically approve new user registrations
                    </div>
                  </div>
                  <Switch 
                    checked={settings.autoApproval}
                    onCheckedChange={(checked) => handleSettingChange('autoApproval', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Maintenance Mode</Label>
                    <div className="text-sm text-muted-foreground">
                      Put platform in maintenance mode
                    </div>
                  </div>
                  <Switch 
                    checked={settings.maintenanceMode}
                    onCheckedChange={(checked) => handleSettingChange('maintenanceMode', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Open Registration</Label>
                    <div className="text-sm text-muted-foreground">
                      Allow new user registrations
                    </div>
                  </div>
                  <Switch 
                    checked={settings.registrationOpen}
                    onCheckedChange={(checked) => handleSettingChange('registrationOpen', checked)}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setSettings(settings)}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Reload Settings
            </Button>
            <Button onClick={handleSaveAllSettings} disabled={loading}>
              {loading ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Save All Settings
            </Button>
          </div>
        </TabsContent>

        {/* User Management */}
        <TabsContent value="users" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Users className="h-5 w-5" />
                  <span>User Verification</span>
                </CardTitle>
                <CardDescription>Configure user verification requirements</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Email Verification</Label>
                    <div className="text-sm text-muted-foreground">
                      Require email verification for new users
                    </div>
                  </div>
                  <Switch 
                    checked={settings.emailVerificationRequired}
                    onCheckedChange={(checked) => handleSettingChange('emailVerificationRequired', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Phone Verification</Label>
                    <div className="text-sm text-muted-foreground">
                      Require phone number verification
                    </div>
                  </div>
                  <Switch 
                    checked={settings.phoneVerificationRequired}
                    onCheckedChange={(checked) => handleSettingChange('phoneVerificationRequired', checked)}
                  />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label className="text-base">Background Check</Label>
                    <div className="text-sm text-muted-foreground">
                      Require background check for drivers
                    </div>
                  </div>
                  <Switch 
                    checked={settings.backgroundCheckRequired}
                    onCheckedChange={(checked) => handleSettingChange('backgroundCheckRequired', checked)}
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Shield className="h-5 w-5" />
                  <span>Role Permissions</span>
                </CardTitle>
                <CardDescription>Manage user roles and permissions</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role</TableHead>
                      <TableHead>Users</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {permissions.map((perm) => (
                      <TableRow key={perm.id}>
                        <TableCell className="font-medium">{perm.role}</TableCell>
                        <TableCell>{perm.users}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* System Management */}
        <TabsContent value="system" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Monitor className="h-5 w-5" />
                  <span>System Health</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">System Health</span>
                  <Badge variant="default" className="bg-accent/20 text-accent border-accent/30">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    {systemStats.systemHealth}%
                  </Badge>
                </div>
                <Progress value={systemStats.systemHealth} className="w-full" />
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Uptime</span>
                    <span className="font-medium">{systemStats.uptime}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Active Users</span>
                    <span className="font-medium">{systemStats.totalUsers.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>My Jobs</span>
                    <span className="font-medium">{systemStats.activeJobs}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Database className="h-5 w-5" />
                  <span>Database</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Storage Used</span>
                    <span className="font-medium">{systemStats.storageUsed}%</span>
                  </div>
                  <Progress value={systemStats.storageUsed} className="w-full" />
                  <div className="flex justify-between text-sm">
                    <span>Database Size</span>
                    <span className="font-medium">{systemStats.databaseSize}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Last Backup</span>
                    <span className="font-medium">{systemStats.lastBackup}</span>
                  </div>
                </div>
                <Button 
                  onClick={handleBackupDatabase} 
                  className="w-full" 
                  variant="outline"
                  disabled={loading}
                >
                  {loading ? (
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Download className="mr-2 h-4 w-4" />
                  )}
                  Backup Now
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <FileText className="h-5 w-5" />
                  <span>Data Management</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button 
                  onClick={() => handleSystemOperation('clear_cache')} 
                  className="w-full" 
                  variant="outline"
                  disabled={loading}
                >
                  {loading ? (
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCw className="mr-2 h-4 w-4" />
                  )}
                  Clear Cache
                </Button>
                <Button 
                  onClick={() => handleSystemOperation('restart_services')} 
                  className="w-full" 
                  variant="outline"
                  disabled={loading}
                >
                  {loading ? (
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Server className="mr-2 h-4 w-4" />
                  )}
                  Restart Services
                </Button>
                <Button 
                  onClick={() => handleSystemOperation('optimize_database')} 
                  className="w-full" 
                  variant="outline"
                  disabled={loading}
                >
                  {loading ? (
                    <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Database className="mr-2 h-4 w-4" />
                  )}
                  Optimize Database
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MapPin className="h-5 w-5" />
                <span>Delivery Radius Enforcement</span>
              </CardTitle>
              <CardDescription>Configure location-based pickup and delivery restrictions</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Enable Radius Enforcement</Label>
                  <div className="text-sm text-muted-foreground">
                    Require drivers to be within defined radius for pickup/delivery
                  </div>
                </div>
                <Switch 
                  checked={settings.enableRadiusEnforcement}
                  onCheckedChange={(checked) => handleSettingChange('enableRadiusEnforcement', checked)}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Enforce Pickup Radius</Label>
                  <div className="text-sm text-muted-foreground">
                    Restrict pickup action based on driver location
                  </div>
                </div>
                <Switch 
                  checked={settings.enablePickupRadius}
                  onCheckedChange={(checked) => handleSettingChange('enablePickupRadius', checked)}
                  disabled={!settings.enableRadiusEnforcement}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Enforce Drop-off Radius</Label>
                  <div className="text-sm text-muted-foreground">
                    Restrict delivery action based on driver location
                  </div>
                </div>
                <Switch 
                  checked={settings.enableDropoffRadius}
                  onCheckedChange={(checked) => handleSettingChange('enableDropoffRadius', checked)}
                  disabled={!settings.enableRadiusEnforcement}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Show Radius Map to Drivers</Label>
                  <div className="text-sm text-muted-foreground">
                    Display visual map with allowed radius circle
                  </div>
                </div>
                <Switch 
                  checked={settings.showRadiusMap}
                  onCheckedChange={(checked) => handleSettingChange('showRadiusMap', checked)}
                />
              </div>
              <Separator />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-base">Log All Radius Attempts</Label>
                  <div className="text-sm text-muted-foreground">
                    Record all pickup/delivery attempts for auditing
                  </div>
                </div>
                <Switch 
                  checked={settings.logRadiusAttempts}
                  onCheckedChange={(checked) => handleSettingChange('logRadiusAttempts', checked)}
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Key className="h-5 w-5" />
                <span>API Keys</span>
              </CardTitle>
              <CardDescription>Manage external service API keys</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Service</TableHead>
                    <TableHead>Key</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Last Used</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {apiKeys.map((key) => (
                    <TableRow key={key.id}>
                      <TableCell className="font-medium">{key.name}</TableCell>
                      <TableCell className="font-mono text-sm">
                        {editingApiKey === key.id ? (
                          <Input
                            value={editApiKeyValue}
                            onChange={(e) => setEditApiKeyValue(e.target.value)}
                            className="max-w-md"
                            placeholder="Enter API key"
                          />
                        ) : (
                          key.value
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge variant={key.status === 'active' ? 'default' : 'secondary'}>
                          {key.status}
                        </Badge>
                      </TableCell>
                      <TableCell>{key.lastUsed}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          {editingApiKey === key.id ? (
                            <>
                              <Button 
                                variant="default" 
                                size="sm" 
                                onClick={() => handleSaveApiKey(key.id)}
                                disabled={loading}
                              >
                                {loading ? (
                                  <RefreshCw className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Save className="h-4 w-4" />
                                )}
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm" 
                                onClick={handleCancelEdit}
                                disabled={loading}
                              >
                                <XCircle className="h-4 w-4" />
                              </Button>
                            </>
                          ) : (
                            <>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => handleEditApiKey(key.id)}
                                disabled={key.id !== 2} // Only allow editing Google Maps key
                                title={key.id === 2 ? "Click to edit and sync to Supabase secrets" : "Not editable in this interface"}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                onClick={() => {
                                  navigator.clipboard.writeText(key.value);
                                  toast({ title: "Copied", description: "API key copied to clipboard" });
                                }}
                              >
                                <Copy className="h-4 w-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>


        {/* Analytics */}
        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5" />
                <span>Platform Analytics</span>
              </CardTitle>
              <CardDescription>Analytics and reporting configuration</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">Analytics configuration coming soon...</p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Platform Customization - DEPRECATED */}
        <TabsContent value="customization" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Platform Customization Moved</CardTitle>
              <CardDescription>This section has been deprecated</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-muted-foreground">
                Platform customization has been moved to the unified <strong>Platform Settings</strong> page.
              </p>
              <p className="text-muted-foreground">
                Please navigate to <strong>Advanced Settings → Personalization</strong> for all customization options.
              </p>
              <Badge variant="outline">Feature moved to unified system</Badge>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}