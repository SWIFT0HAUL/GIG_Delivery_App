import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { supabase } from '@/integrations/supabase/client';
import { TrendingUp } from 'lucide-react';

interface VehicleTypeStats {
  vehicle_type_id: number;
  vehicle_type_name: string;
  capacity: string;
  category_id: number;
  category_name: string;
  category_icon: string;
  total_jobs: number;
  pending_jobs: number;
  posted_jobs: number;
  in_progress_jobs: number;
  completed_jobs: number;
  total_pay_amount: number;
  avg_pay_amount: number;
}

export const VehicleTypeAnalytics = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const { data: vehicleTypeStats, isLoading } = useQuery({
    queryKey: ['vehicle-type-analytics'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('jobs_by_vehicle_type')
        .select('*');
      
      if (error) throw error;
      return data as VehicleTypeStats[];
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Jobs by Vehicle Type
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const categories = Array.from(
    new Set(vehicleTypeStats?.map(s => s.category_name) || [])
  );

  const filteredStats = selectedCategory === 'all'
    ? vehicleTypeStats
    : vehicleTypeStats?.filter(s => s.category_name === selectedCategory);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Jobs by Vehicle Type
          </CardTitle>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-[280px]">
              <SelectValue placeholder="Filter by category" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Categories</SelectItem>
              {categories.map((category) => (
                <SelectItem key={category} value={category}>
                  {category}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Vehicle Type</TableHead>
              <TableHead>Capacity</TableHead>
              <TableHead>Category</TableHead>
              <TableHead className="text-center">Total Jobs</TableHead>
              <TableHead className="text-center">Pending</TableHead>
              <TableHead className="text-center">Posted</TableHead>
              <TableHead className="text-center">Completed</TableHead>
              <TableHead className="text-right">Total Pay</TableHead>
              <TableHead className="text-right">Avg Pay</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStats?.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center text-muted-foreground">
                  No jobs found for this category
                </TableCell>
              </TableRow>
            ) : (
              filteredStats?.map((stat) => (
                <TableRow key={stat.vehicle_type_id}>
                  <TableCell className="font-medium">
                    {stat.vehicle_type_name}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{stat.capacity}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <span>{stat.category_icon}</span>
                      <span className="text-sm">{stat.category_name}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="secondary">{stat.total_jobs}</Badge>
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.pending_jobs > 0 ? (
                      <Badge variant="outline">{stat.pending_jobs}</Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.posted_jobs > 0 ? (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        {stat.posted_jobs}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    {stat.completed_jobs > 0 ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                        {stat.completed_jobs}
                      </Badge>
                    ) : (
                      <span className="text-muted-foreground">0</span>
                    )}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    ${stat.total_pay_amount.toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right">
                    ${Math.round(stat.avg_pay_amount).toLocaleString()}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};
