import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { Plus, Pencil, Trash2, Search, Filter, ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { format, formatDistanceToNow } from 'date-fns';

interface Permission {
  id: string;
  name: string;
  description: string | null;
  category: string | null;
  created_at: string;
}

export const PermissionManagement = () => {
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'name' | 'category' | 'created_at'>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [deletePermissionId, setDeletePermissionId] = useState<string | null>(null);
  const [selectedPermission, setSelectedPermission] = useState<Permission | null>(null);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
  });

  // Helper function to get badge color based on category
  const getCategoryColor = (category: string | null): "default" | "secondary" | "destructive" | "outline" => {
    if (!category) return "outline";
    const lowerCategory = category.toLowerCase();
    
    // Super Admin - Most critical (Red/Destructive)
    if (lowerCategory.includes('super admin')) return "destructive";
    // Platform Admin (Full Admin) - High level (Red/Destructive)
    if (lowerCategory.includes('platform admin')) return "destructive";
    // Department Admin (Scoped) - Medium level (Secondary)
    if (lowerCategory.includes('department admin')) return "secondary";
    // Basic Administrator - Standard (Default)
    if (lowerCategory.includes('administrator')) return "default";
    // Other system categories
    if (lowerCategory.includes('system')) return "destructive";
    if (lowerCategory.includes('user') || lowerCategory.includes('profile')) return "default";
    if (lowerCategory.includes('dashboard')) return "secondary";
    return "outline";
  };

  // Helper function to format date
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return {
        relative: formatDistanceToNow(date, { addSuffix: true }),
        full: format(date, 'PPP p')
      };
    } catch {
      return { relative: 'Unknown', full: 'Unknown' };
    }
  };

  // Toggle sort
  const handleSort = (column: 'name' | 'category' | 'created_at') => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('asc');
    }
  };

  // Get sort icon
  const getSortIcon = (column: 'name' | 'category' | 'created_at') => {
    if (sortBy !== column) return <ArrowUpDown className="h-4 w-4 ml-1 opacity-50" />;
    return sortOrder === 'asc' 
      ? <ArrowUp className="h-4 w-4 ml-1" />
      : <ArrowDown className="h-4 w-4 ml-1" />;
  };

  useEffect(() => {
    fetchPermissions();
  }, []);

  const fetchPermissions = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('permissions')
        .select('*')
        .order('category', { ascending: true })
        .order('name', { ascending: true });

      if (error) throw error;
      setPermissions(data || []);
    } catch (error) {
      console.error('Error fetching permissions:', error);
      toast({
        title: "Error",
        description: "Failed to load permissions",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreate = async () => {
    try {
      const { error } = await supabase
        .from('permissions')
        .insert([formData]);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Permission created successfully",
      });

      setIsCreateOpen(false);
      setFormData({ name: '', description: '', category: '' });
      fetchPermissions();
    } catch (error) {
      console.error('Error creating permission:', error);
      toast({
        title: "Error",
        description: "Failed to create permission",
        variant: "destructive",
      });
    }
  };

  const handleEdit = async () => {
    if (!selectedPermission) return;

    try {
      const { error } = await supabase
        .from('permissions')
        .update(formData)
        .eq('id', selectedPermission.id);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Permission updated successfully",
      });

      setIsEditOpen(false);
      setSelectedPermission(null);
      setFormData({ name: '', description: '', category: '' });
      fetchPermissions();
    } catch (error) {
      console.error('Error updating permission:', error);
      toast({
        title: "Error",
        description: "Failed to update permission",
        variant: "destructive",
      });
    }
  };

  const handleDelete = async () => {
    if (!deletePermissionId) return;

    try {
      const { error } = await supabase
        .from('permissions')
        .delete()
        .eq('id', deletePermissionId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Permission deleted successfully",
      });

      setDeletePermissionId(null);
      fetchPermissions();
    } catch (error) {
      console.error('Error deleting permission:', error);
      toast({
        title: "Error",
        description: "Failed to delete permission",
        variant: "destructive",
      });
    }
  };

  const openEditDialog = (permission: Permission) => {
    setSelectedPermission(permission);
    setFormData({
      name: permission.name,
      description: permission.description || '',
      category: permission.category || '',
    });
    setIsEditOpen(true);
  };

  // Get unique categories for filter
  const uniqueCategories = useMemo(() => {
    const categories = permissions
      .map(p => p.category || 'Uncategorized')
      .filter((v, i, a) => a.indexOf(v) === i)
      .sort();
    return categories;
  }, [permissions]);

  // Filter and sort permissions
  const filteredAndSortedPermissions = useMemo(() => {
    let filtered = permissions.filter(
      (permission) =>
        permission.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        permission.category?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        permission.description?.toLowerCase().includes(searchQuery.toLowerCase())
    );

    // Apply category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(p => 
        (p.category || 'Uncategorized') === categoryFilter
      );
    }

    // Apply sorting
    filtered.sort((a, b) => {
      let compareA: any;
      let compareB: any;

      if (sortBy === 'name') {
        compareA = a.name.toLowerCase();
        compareB = b.name.toLowerCase();
      } else if (sortBy === 'category') {
        compareA = (a.category || 'Uncategorized').toLowerCase();
        compareB = (b.category || 'Uncategorized').toLowerCase();
      } else {
        compareA = new Date(a.created_at).getTime();
        compareB = new Date(b.created_at).getTime();
      }

      if (compareA < compareB) return sortOrder === 'asc' ? -1 : 1;
      if (compareA > compareB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    return filtered;
  }, [permissions, searchQuery, categoryFilter, sortBy, sortOrder]);

  // Get category stats
  const categoryStats = useMemo(() => {
    const stats: Record<string, number> = {};
    permissions.forEach(p => {
      const cat = p.category || 'Uncategorized';
      stats[cat] = (stats[cat] || 0) + 1;
    });
    return stats;
  }, [permissions]);

  return (
    <Card>
      <CardHeader>
        <CardTitle>Permission Management</CardTitle>
        <CardDescription>Manage system permissions and access controls</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search and Filter Controls */}
        <div className="flex justify-between items-center gap-4 flex-wrap">
          <div className="flex gap-3 flex-1 min-w-[300px]">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search permissions..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-[200px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {uniqueCategories.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Add Permission
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Permission</DialogTitle>
                <DialogDescription>Add a new permission to the system</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name">Permission Name</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., manage_users"
                  />
                </div>
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Input
                    id="category"
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    placeholder="e.g., User Management"
                  />
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Describe what this permission allows"
                  />
                </div>
                <Button onClick={handleCreate} className="w-full">Create Permission</Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Summary Stats */}
        <div className="flex items-center gap-4 text-sm text-muted-foreground bg-muted/30 px-4 py-3 rounded-lg">
          <div className="font-semibold text-foreground">
            Total: {permissions.length} permissions
          </div>
          <div className="flex gap-3 flex-wrap">
            {Object.entries(categoryStats).map(([cat, count]) => (
              <div key={cat} className="flex items-center gap-1">
                <span>{cat}:</span>
                <span className="font-medium text-foreground">{count}</span>
              </div>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="text-center py-8">Loading permissions...</div>
        ) : (
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead className="w-[25%]">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2 -ml-2 font-semibold"
                      onClick={() => handleSort('name')}
                    >
                      Permission Name
                      {getSortIcon('name')}
                    </Button>
                  </TableHead>
                  <TableHead className="w-[35%]">Description</TableHead>
                  <TableHead className="w-[15%]">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2 -ml-2 font-semibold"
                      onClick={() => handleSort('category')}
                    >
                      Category
                      {getSortIcon('category')}
                    </Button>
                  </TableHead>
                  <TableHead className="w-[15%]">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-8 px-2 -ml-2 font-semibold"
                      onClick={() => handleSort('created_at')}
                    >
                      Date Created
                      {getSortIcon('created_at')}
                    </Button>
                  </TableHead>
                  <TableHead className="w-[10%] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAndSortedPermissions.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      No permissions found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredAndSortedPermissions.map((permission, index) => {
                    const dateInfo = formatDate(permission.created_at);
                    return (
                      <TableRow 
                        key={permission.id}
                        className={`hover:bg-muted/30 transition-colors ${index % 2 === 0 ? 'bg-background' : 'bg-muted/10'}`}
                      >
                        <TableCell>
                          <code className="font-mono text-xs bg-muted px-2 py-1 rounded">
                            {permission.name}
                          </code>
                        </TableCell>
                        <TableCell className="text-sm">
                          {permission.description || <span className="text-muted-foreground italic">No description</span>}
                        </TableCell>
                        <TableCell>
                          <Badge variant={getCategoryColor(permission.category)}>
                            {permission.category || 'Uncategorized'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm">
                          <TooltipProvider>
                            <Tooltip>
                              <TooltipTrigger asChild>
                                <span className="cursor-help text-muted-foreground">
                                  {dateInfo.relative}
                                </span>
                              </TooltipTrigger>
                              <TooltipContent>
                                <p>{dateInfo.full}</p>
                              </TooltipContent>
                            </Tooltip>
                          </TooltipProvider>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-1 justify-end">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => openEditDialog(permission)}
                              className="h-8 w-8 p-0"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setDeletePermissionId(permission.id)}
                              className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        )}

        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Permission</DialogTitle>
              <DialogDescription>Update permission details</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name">Permission Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-category">Category</Label>
                <Input
                  id="edit-category"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                />
              </div>
              <Button onClick={handleEdit} className="w-full">Update Permission</Button>
            </div>
          </DialogContent>
        </Dialog>

        <AlertDialog open={!!deletePermissionId} onOpenChange={() => setDeletePermissionId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Permission</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this permission? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  );
};

export default PermissionManagement;
