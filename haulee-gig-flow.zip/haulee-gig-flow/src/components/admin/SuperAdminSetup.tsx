import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Shield, AlertTriangle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

/**
 * SuperAdminSetup Component
 * 
 * SECURITY CRITICAL: This component is used ONCE to initialize the super admin account.
 * After setup, this component should be removed or hidden.
 * 
 * Steps:
 * 1. Admin creates account via Supabase Auth with email: admin@swiftohaul.com
 * 2. Use this component to upgrade that account to super_admin with system protections
 * 3. Never expose credentials in code - they are hashed and stored securely
 */
export const SuperAdminSetup = () => {
  const [userId, setUserId] = useState('');
  const [mfaPin, setMfaPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [setupComplete, setSetupComplete] = useState(false);

  const hashPin = async (pin: string): Promise<string> => {
    // Use Web Crypto API to hash the PIN
    const encoder = new TextEncoder();
    const data = encoder.encode(pin);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  };

  const setupSuperAdmin = async () => {
    if (!userId.trim() || !mfaPin.trim()) {
      toast({
        title: "Missing Information",
        description: "Please provide both User ID and MFA PIN",
        variant: "destructive",
      });
      return;
    }

    if (mfaPin.length !== 6) {
      toast({
        title: "Invalid PIN",
        description: "MFA PIN must be exactly 6 digits",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      // Hash the PIN before sending
      const hashedPin = await hashPin(mfaPin);

      // Call the secure database function
      const { error } = await supabase.rpc('setup_super_admin_account', {
        p_user_id: userId,
        p_mfa_pin_hash: hashedPin
      });

      if (error) throw error;

      setSetupComplete(true);
      toast({
        title: "Super Admin Setup Complete",
        description: "The system account has been secured successfully.",
      });

      // Clear sensitive data from memory
      setUserId('');
      setMfaPin('');
    } catch (error: any) {
      console.error('Setup error:', error);
      toast({
        title: "Setup Failed",
        description: error.message || "Failed to setup super admin account",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  if (setupComplete) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Shield className="h-6 w-6 text-green-500" />
            <span>Setup Complete</span>
          </CardTitle>
          <CardDescription>
            Super Admin account has been secured. This component should now be removed.
          </CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card className="border-red-500">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Shield className="h-6 w-6 text-red-500" />
          <span>Super Admin Setup - One Time Only</span>
        </CardTitle>
        <CardDescription>
          Initialize the system super admin account with security protections.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            This is a one-time setup. After completion, remove this component from production.
            Never commit credentials to code repositories.
          </AlertDescription>
        </Alert>

        <div className="space-y-2">
          <Label htmlFor="userId">User ID (UUID)</Label>
          <Input
            id="userId"
            type="text"
            placeholder="Enter the user UUID from Supabase Auth"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            disabled={loading}
          />
          <p className="text-xs text-muted-foreground">
            Get this from Supabase Dashboard → Authentication → Users
          </p>
        </div>

        <div className="space-y-2">
          <Label htmlFor="mfaPin">MFA PIN (6 digits)</Label>
          <Input
            id="mfaPin"
            type="password"
            placeholder="Enter 6-digit PIN"
            value={mfaPin}
            onChange={(e) => setMfaPin(e.target.value)}
            maxLength={6}
            disabled={loading}
          />
          <p className="text-xs text-muted-foreground">
            This PIN will be hashed and stored securely
          </p>
        </div>

        <Button 
          onClick={setupSuperAdmin} 
          disabled={loading}
          className="w-full"
        >
          {loading ? "Setting up..." : "Initialize Super Admin"}
        </Button>

        <Alert>
          <AlertDescription className="text-xs">
            <strong>Steps:</strong>
            <ol className="list-decimal list-inside mt-2 space-y-1">
              <li>Create account via Supabase with admin@swiftohaul.com</li>
              <li>Copy the user UUID from Supabase Dashboard</li>
              <li>Enter UUID and desired MFA PIN here</li>
              <li>Click Initialize - account will be secured</li>
              <li>Remove this component after setup</li>
            </ol>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
};
