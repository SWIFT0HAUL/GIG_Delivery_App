import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { FileText, RefreshCw, Download, Eye } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';

interface AdminLog {
  id: string;
  user_id: string;
  action: string;
  entity_type: string;
  entity_id: string;
  details: any;
  created_at: string;
  ip_address?: unknown;
}

export const SuperAdminAuditLogs = () => {
  const [logs, setLogs] = useState<AdminLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<string>('all');

  const fetchLogs = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase.rpc('get_super_admin_logs', {
        limit_count: 100
      });
      
      if (error) throw error;
      setLogs(data || []);
    } catch (error) {
      console.error('Error fetching audit logs:', error);
      toast({
        title: "Error",
        description: "Failed to fetch audit logs",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const getActionBadgeVariant = (action: string) => {
    if (action.includes('delete') || action.includes('remove')) return 'destructive';
    if (action.includes('create') || action.includes('add')) return 'default';
    if (action.includes('update') || action.includes('modify')) return 'secondary';
    if (action.includes('super_admin')) return 'destructive';
    return 'outline';
  };

  const exportLogs = async () => {
    try {
      const csv = [
        'Timestamp,Admin,Action,Target Type,Target ID,Details',
        ...logs.map(log => [
          new Date(log.created_at).toISOString(),
          log.user_id || 'System',
          log.action,
          log.entity_type || '',
          log.entity_id || '',
          JSON.stringify(log.details || {})
        ].map(field => `"${field}"`).join(','))
      ].join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `admin-audit-logs-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      toast({
        title: "Success",
        description: "Audit logs exported successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export audit logs",
        variant: "destructive",
      });
    }
  };

  const filteredLogs = logs.filter(log => {
    if (filter === 'all') return true;
    if (filter === 'super_admin') return log.action.includes('super_admin');
    if (filter === 'user_management') return log.entity_type === 'user';
    if (filter === 'system') return log.entity_type === 'platform_setting';
    return true;
  });

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Loading Audit Logs...</CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <FileText className="h-5 w-5" />
          <span>Audit Logs</span>
        </CardTitle>
        <CardDescription>
          Track all administrative actions and system changes
        </CardDescription>
        <div className="flex items-center space-x-4 pt-4">
          <Select value={filter} onValueChange={setFilter}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Filter logs" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Actions</SelectItem>
              <SelectItem value="super_admin">Super Admin Actions</SelectItem>
              <SelectItem value="user_management">User Management</SelectItem>
              <SelectItem value="system">System Changes</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={fetchLogs} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={exportLogs} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Timestamp</TableHead>
              <TableHead>Admin</TableHead>
              <TableHead>Action</TableHead>
              <TableHead>Target</TableHead>
              <TableHead>Details</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredLogs.map((log) => (
              <TableRow key={log.id}>
                <TableCell className="font-mono text-sm">
                  {new Date(log.created_at).toLocaleString()}
                </TableCell>
                <TableCell>
                  <div>
                    <div className="font-medium">{log.user_id}</div>
                    <div className="text-xs text-muted-foreground">{log.user_id}</div>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant={getActionBadgeVariant(log.action)}>
                    {log.action}
                  </Badge>
                </TableCell>
                <TableCell>
                  <div>
                    <div className="font-medium">{log.entity_type || 'N/A'}</div>
                    {log.entity_id && (
                      <div className="text-xs text-muted-foreground font-mono">
                        {log.entity_id}
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  {log.details && Object.keys(log.details).length > 0 ? (
                    <details className="cursor-pointer">
                      <summary className="flex items-center space-x-1">
                        <Eye className="h-3 w-3" />
                        <span className="text-xs">View Details</span>
                      </summary>
                      <pre className="mt-2 text-xs bg-muted p-2 rounded overflow-x-auto">
                        {JSON.stringify(log.details, null, 2)}
                      </pre>
                    </details>
                  ) : (
                    <span className="text-muted-foreground text-sm">No details</span>
                  )}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        
        {filteredLogs.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            No audit logs found matching the current filter.
          </div>
        )}
      </CardContent>
    </Card>
  );
};