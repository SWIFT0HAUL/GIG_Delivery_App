import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  X, LayoutDashboard, Users, Briefcase, Palette, UserPlus, DollarSign, 
  CreditCard, Bell, BarChart3, Settings, Shield, Eye, Database, FileText, 
  Activity, BookOpen, Puzzle, Wrench, HelpCircle, Sliders 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { usePermissions } from '@/hooks/usePermissions';

const menuGroups = [
  {
    title: "CORE",
    items: [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/admin-dashboard/dashboard' },
      { id: 'userManagement', label: 'User Management', icon: Users, path: '/admin-dashboard/users' },
      { id: 'jobsManagement', label: 'Jobs Management', icon: Briefcase, path: '/admin-dashboard/jobs' },
      { id: 'jobAuthRequests', label: 'Job Auth Requests', icon: UserPlus, path: '/admin-dashboard/job-auth-requests' },
      { id: 'kycVerification', label: 'KYC Verification', icon: Shield, path: '/admin-dashboard/kyc' },
      { id: 'rbac', label: 'RBAC', icon: Shield, path: '/admin-dashboard/rbac' },
      { id: 'timesheet', label: 'Timesheet Management', icon: Activity, path: '/admin-dashboard/timesheet' },
      { id: 'superAdmin', label: 'Super Admin Panel', icon: Shield, path: '/admin-dashboard/super', superAdminOnly: true },
    ]
  },
  {
    title: "CONTENT",
    items: [
      { id: 'documentation', label: 'Documentation', icon: BookOpen, path: '/documentation' },
      { id: 'contentManagement', label: 'Content Management', icon: FileText, path: '/admin-dashboard/content' },
      { id: 'tasksManagement', label: 'Tasks Management', icon: UserPlus, path: '/admin-dashboard/tasks' },
      { id: 'checklistManagement', label: 'Checklist Management', icon: BookOpen, path: '/admin-dashboard/checklists' },
    ]
  },
  {
    title: "FINANCIALS",
    items: [
      { id: 'financeAccounting', label: 'Finance & Accounting', icon: DollarSign, path: '/admin-dashboard/finance' },
      { id: 'w9Management', label: 'W-9 Forms', icon: FileText, path: '/admin-dashboard/w9' },
    ]
  },
  {
    title: "PLATFORM",
    items: [
      { id: 'advancedSettings', label: 'Advanced Settings', icon: Settings, path: '/admin-dashboard/advanced-settings' },
      { id: 'dataManagement', label: 'Data Management', icon: Database, path: '/admin-dashboard/data' },
      { id: 'integrationHub', label: 'Integrations', icon: Puzzle, path: '/admin-dashboard/integrations' },
    ]
  },
  {
    title: "SECURITY",
    items: [
      { id: 'auditLogs', label: 'Audit Logs', icon: BookOpen, path: '/admin-dashboard/audit' },
      { id: 'systemControl', label: 'System Control', icon: Shield, path: '/admin-dashboard/system-control' },
      { id: 'navigationAudit', label: 'Navigation Audit', icon: Eye, path: '/admin-dashboard/nav-audit' },
    ]
  },
  {
    title: "MONITORING & SUPPORT",
    items: [
       { id: 'notifications', label: 'Notifications', icon: Bell, path: '/admin-dashboard/notifications' },
       { id: 'support', label: 'Support Center', icon: HelpCircle, path: '/admin-dashboard/support' },
       { id: 'systemMaintenance', label: 'Maintenance', icon: Wrench, path: '/admin-dashboard/maintenance' },
    ]
  }
];

interface NavContentProps {
  setSidebarOpen?: (open: boolean) => void;
}

const NavContent = ({ setSidebarOpen }: NavContentProps) => {
  const { isSuperAdmin } = usePermissions();
  const location = useLocation();

  return (
  <nav className="p-2 pb-6">
    {menuGroups.map((group, groupIndex) => (
      <div key={group.title} className={groupIndex < menuGroups.length - 1 ? "mb-4" : "mb-2"}>
        <h3 className="px-3 py-2 text-xs font-semibold text-muted-foreground uppercase tracking-wider">{group.title}</h3>
        {group.items.map((item: any) => {
          // Hide super admin only items if user doesn't have super admin access
          if (item.superAdminOnly && !isSuperAdmin) {
            return null;
          }

          const Icon = item.icon;
          const isActive = location.pathname === item.path;
          
          return (
            <Link key={item.id} to={item.path}>
              <Button
                variant={isActive ? "secondary" : "ghost"}
                className="w-full justify-start mb-1"
                onClick={() => {
                  if (setSidebarOpen) {
                    setSidebarOpen(false); // Close sidebar on mobile after selection
                  }
                }}
              >
                <Icon className="w-4 h-4 mr-3" />
                {item.label}
                {item.superAdminOnly && <Shield className="w-3 h-3 ml-auto text-red-500" />}
              </Button>
            </Link>
          );
        }).filter(Boolean)}
      </div>
    ))}
  </nav>
  );
};

interface AdminSidebarProps {
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export default function AdminSidebar({ sidebarOpen, setSidebarOpen }: AdminSidebarProps) {
  const { hasPermission, loading } = usePermissions();

  // Don't render sidebar if user doesn't have permission
  if (!hasPermission('view_admin_sidebar')) {
    return null;
  }

  if (loading) {
    return null;
  }

  return (
    <>
      {/* Mobile Sidebar */}
      <div className={cn("fixed inset-0 z-50 flex lg:hidden", sidebarOpen ? "pointer-events-auto" : "pointer-events-none")}>
        <div className={cn("fixed inset-y-0 left-0 w-64 bg-card shadow-lg transition-transform duration-300 ease-in-out", sidebarOpen ? "translate-x-0" : "-translate-x-full")}>
           <div className="p-4 border-b border-border flex justify-between items-center h-[65px]">
             <h2 className="text-xl font-bold text-foreground">Admin Menu</h2>
             <Button variant="ghost" size="icon" onClick={() => setSidebarOpen(false)}>
               <X className="w-5 h-5"/>
             </Button>
           </div>
           <div className="overflow-y-auto overflow-x-hidden h-[calc(100vh-65px)]">
             <NavContent setSidebarOpen={setSidebarOpen} />
           </div>
        </div>
        <div className={cn("flex-1 bg-background/80 transition-opacity duration-300", sidebarOpen ? "opacity-100" : "opacity-0")} onClick={() => setSidebarOpen(false)} />
      </div>

      {/* Desktop Sidebar */}
      <div className={cn(
        "hidden lg:block fixed left-0 top-0 h-screen bg-card shadow-lg border-r border-border z-30 transition-transform duration-300",
        sidebarOpen ? "translate-x-0 w-64" : "-translate-x-64 w-64"
      )}>
        <div className="p-4 border-b border-border h-[65px] flex items-center flex-shrink-0">
          <h2 className="text-xl font-bold text-foreground">🛠️ Admin Panel</h2>
        </div>
        <div className="overflow-y-auto overflow-x-hidden h-[calc(100vh-65px)]">
          <NavContent />
        </div>
      </div>
    </>
  );
}