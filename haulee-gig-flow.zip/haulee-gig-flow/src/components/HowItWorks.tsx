import { Card, CardContent } from "@/components/ui/card";
import { UserPlus, Search, Truck, DollarSign, ArrowRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

const HowItWorks = () => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const handlePostJob = () => {
    navigate('/auth');
  };

  const handleFindJobs = () => {
    navigate('/auth');
  };

  const steps = [
    {
      step: "01",
      icon: <UserPlus className="h-8 w-8" />,
      title: "Sign Up & Get Verified",
      description: "Create your account, upload required documents, and get verified in minutes. Choose your role as shipper or carrier."
    },
    {
      step: "02", 
      icon: <Search className="h-8 w-8" />,
      title: "Post or Find Jobs",
      description: "Shippers post delivery jobs with details and rates. Carriers browse and filter jobs by location, cargo type, and pay rate."
    },
    {
      step: "03",
      icon: <Truck className="h-8 w-8" />,
      title: "Execute & Track",
      description: "Carriers accept jobs and provide real-time updates. Shippers track progress with GPS monitoring and status notifications."
    },
    {
      step: "04",
      icon: <DollarSign className="h-8 w-8" />,
      title: "Get Paid Securely",
      description: "Automatic payment processing upon delivery confirmation. Fast payouts with multiple payment options available."
    }
  ];

  return (
    <section id="how-it-works" className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold mb-4">
            How <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Haulee</span> Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Our streamlined process makes it easy to connect shippers with carriers and get deliveries moving quickly.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="border-border hover:border-primary/50 transition-all duration-300 hover:shadow-lg h-full">
                <CardContent className="p-6 text-center space-y-4">
                  {/* Step Number */}
                  <div className="relative">
                    <div className="text-6xl font-bold text-muted/20 absolute -top-2 left-1/2 transform -translate-x-1/2">
                      {step.step}
                    </div>
                    <div className="relative bg-gradient-to-r from-primary to-accent p-3 rounded-xl text-white inline-flex items-center justify-center mx-auto z-10">
                      {step.icon}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-xl font-semibold">{step.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Arrow Connector - Hidden on mobile, shown on larger screens */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <ArrowRight className="h-6 w-6 text-primary" />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20">
            <h3 className="text-2xl font-bold mb-4">Ready to Get Started?</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Join thousands of shippers and carriers who trust Haulee for their logistics needs. 
              Sign up today and start connecting with verified professionals in your area.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={handlePostJob}
                className="bg-gradient-to-r from-primary to-accent text-primary-foreground px-8 py-3 rounded-lg font-semibold hover:shadow-xl hover:shadow-primary/30 hover:scale-105 transition-all duration-300"
              >
                Post Your First Job
              </button>
              <button 
                onClick={handleFindJobs}
                className="bg-gradient-to-r from-accent to-primary text-accent-foreground px-8 py-3 rounded-lg font-semibold hover:shadow-xl hover:shadow-accent/30 hover:scale-105 transition-all duration-300"
              >
                Find Delivery Jobs
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;