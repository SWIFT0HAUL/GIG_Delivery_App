import React, { useState } from 'react';
import { marked } from 'marked';
import { Document, Paragraph, TextRun, HeadingLevel, Packer, AlignmentType } from 'docx';
import { Button } from '@/components/ui/button';
import { Download, FileText, FileType } from 'lucide-react';
import { toast } from 'sonner';

interface DocumentExporterProps {
  markdownContent: string;
  fileName?: string;
}

export const DocumentExporter: React.FC<DocumentExporterProps> = ({
  markdownContent,
  fileName = 'document',
}) => {
  const [isExporting, setIsExporting] = useState(false);

  const convertMarkdownToHtml = async (markdown: string): Promise<string> => {
    // Configure marked options
    marked.setOptions({
      breaks: true,
      gfm: true,
    });

    const html = await marked.parse(markdown);
    
    // Wrap in a full HTML document with styling
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>${fileName}</title>
          <style>
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 900px;
              margin: 0 auto;
              padding: 20px;
            }
            h1 {
              color: #1E40AF;
              border-bottom: 3px solid #F97316;
              padding-bottom: 10px;
              margin-top: 30px;
            }
            h2 {
              color: #1E40AF;
              border-bottom: 2px solid #E5E7EB;
              padding-bottom: 8px;
              margin-top: 25px;
            }
            h3 {
              color: #374151;
              margin-top: 20px;
            }
            code {
              background-color: #F3F4F6;
              padding: 2px 6px;
              border-radius: 3px;
              font-family: 'Courier New', monospace;
              font-size: 0.9em;
            }
            pre {
              background-color: #F3F4F6;
              padding: 15px;
              border-radius: 5px;
              overflow-x: auto;
            }
            pre code {
              background-color: transparent;
              padding: 0;
            }
            table {
              border-collapse: collapse;
              width: 100%;
              margin: 20px 0;
            }
            table th,
            table td {
              border: 1px solid #E5E7EB;
              padding: 8px 12px;
              text-align: left;
            }
            table th {
              background-color: #F3F4F6;
              font-weight: 600;
            }
            blockquote {
              border-left: 4px solid #F97316;
              margin: 20px 0;
              padding-left: 20px;
              color: #6B7280;
            }
            a {
              color: #1E40AF;
              text-decoration: none;
            }
            a:hover {
              text-decoration: underline;
            }
            ul, ol {
              margin: 15px 0;
              padding-left: 30px;
            }
            li {
              margin: 8px 0;
            }
            hr {
              border: none;
              border-top: 2px solid #E5E7EB;
              margin: 30px 0;
            }
          </style>
        </head>
        <body>
          ${html}
        </body>
      </html>
    `;
  };

  const exportToPDF = async () => {
    setIsExporting(true);
    try {
      const htmlContent = await convertMarkdownToHtml(markdownContent);
      
      // Create a new window for printing
      const printWindow = window.open('', '_blank');
      if (!printWindow) {
        toast.error('Please allow popups to export to PDF');
        setIsExporting(false);
        return;
      }

      printWindow.document.write(htmlContent);
      printWindow.document.close();

      // Wait for content to load, then print
      printWindow.onload = () => {
        printWindow.print();
        toast.success('PDF export ready! Use your browser\'s print dialog to save.');
      };
    } catch (error) {
      console.error('PDF export error:', error);
      toast.error('Failed to export to PDF');
    } finally {
      setIsExporting(false);
    }
  };

  const exportToWord = async () => {
    setIsExporting(true);
    try {
      // Parse markdown into lines
      const lines = markdownContent.split('\n');
      const docParagraphs: Paragraph[] = [];

      for (const line of lines) {
        if (line.startsWith('# ')) {
          docParagraphs.push(
            new Paragraph({
              text: line.substring(2),
              heading: HeadingLevel.HEADING_1,
              spacing: { before: 240, after: 120 },
            })
          );
        } else if (line.startsWith('## ')) {
          docParagraphs.push(
            new Paragraph({
              text: line.substring(3),
              heading: HeadingLevel.HEADING_2,
              spacing: { before: 200, after: 100 },
            })
          );
        } else if (line.startsWith('### ')) {
          docParagraphs.push(
            new Paragraph({
              text: line.substring(4),
              heading: HeadingLevel.HEADING_3,
              spacing: { before: 160, after: 80 },
            })
          );
        } else if (line.startsWith('- ') || line.startsWith('* ')) {
          docParagraphs.push(
            new Paragraph({
              text: line.substring(2),
              bullet: { level: 0 },
            })
          );
        } else if (line.trim()) {
          docParagraphs.push(
            new Paragraph({
              children: [new TextRun(line)],
              spacing: { after: 100 },
            })
          );
        } else {
          docParagraphs.push(new Paragraph({ text: '' }));
        }
      }

      const doc = new Document({
        sections: [{
          properties: {},
          children: docParagraphs,
        }],
      });

      const blob = await Packer.toBlob(doc);
      
      // Create download link
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${fileName}.docx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success('Word document downloaded successfully!');
    } catch (error) {
      console.error('Word export error:', error);
      toast.error('Failed to export to Word');
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex gap-2">
      <Button
        onClick={exportToPDF}
        disabled={isExporting}
        variant="outline"
        className="gap-2"
      >
        <FileText className="h-4 w-4" />
        Export to PDF
      </Button>
      
      <Button
        onClick={exportToWord}
        disabled={isExporting}
        variant="outline"
        className="gap-2"
      >
        <FileType className="h-4 w-4" />
        Export to Word
      </Button>
    </div>
  );
};
