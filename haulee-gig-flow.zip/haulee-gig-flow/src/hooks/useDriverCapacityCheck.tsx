import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface CapacityCheckResult {
  canClaim: boolean;
  reason?: string;
  driverCapacity?: number;
  activeVolume?: number;
  hasActiveJob?: boolean;
  hasActiveRoute?: boolean;
}

export const useDriverCapacityCheck = (jobId?: string) => {
  return useQuery({
    queryKey: ['driver-capacity-check', jobId],
    queryFn: async (): Promise<CapacityCheckResult> => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get driver's vehicle capacity
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('capacity_volume_kg')
        .eq('id', user.id)
        .single();

      if (profileError) throw profileError;

      const driverCapacity = profile?.capacity_volume_kg || 10;

      // Check for active jobs (assigned, in_progress, picked_up)
      const { data: activeAssignments, error: assignmentsError } = await supabase
        .from('job_assignments')
        .select(`
          id,
          status,
          job_id,
          jobs!inner (
            id,
            job_volume_kg,
            status
          )
        `)
        .eq('driver_id', user.id)
        .in('status', ['assigned', 'in_progress', 'picked_up']);

      if (assignmentsError) throw assignmentsError;

      const activeJobs = activeAssignments || [];
      const hasActiveJob = activeJobs.length > 0;

      // Calculate total active volume
      const activeVolume = activeJobs.reduce((sum, assignment: any) => {
        return sum + (assignment.jobs?.job_volume_kg || 0);
      }, 0);

      // Check for active routes (planned status jobs)
      const { data: plannedJobs, error: plannedError } = await supabase
        .from('jobs')
        .select('id, status')
        .eq('assigned_driver_id', user.id)
        .eq('status', 'planned');

      if (plannedError) throw plannedError;

      const hasActiveRoute = (plannedJobs || []).length > 0;

      // If checking a specific job
      if (jobId) {
        const { data: job, error: jobError } = await supabase
          .from('jobs')
          .select('job_volume_kg, pickup_time, status')
          .eq('id', jobId)
          .single();

        if (jobError) throw jobError;

        const jobVolume = job?.job_volume_kg || 0;
        const isScheduled = job?.pickup_time && new Date(job.pickup_time) > new Date();

        // For scheduled jobs (route planner) - allow multiple planned jobs
        if (isScheduled) {
          // No restriction - drivers can add multiple scheduled jobs
        } else {
          // For active jobs (pickup now)
          if (hasActiveJob) {
            return {
              canClaim: false,
              reason: 'You already have an active job. Complete or deliver current job before claiming new ones.',
              driverCapacity,
              activeVolume,
              hasActiveJob: true
            };
          }
        }

        // Check individual job volume
        if (jobVolume > driverCapacity) {
          return {
            canClaim: false,
            reason: 'Job volume exceeds your vehicle\'s maximum capacity.',
            driverCapacity,
            activeVolume
          };
        }

        // Check total capacity
        if (activeVolume + jobVolume > driverCapacity) {
          return {
            canClaim: false,
            reason: 'You\'ve reached your total vehicle capacity. Complete or deliver current jobs before claiming new ones.',
            driverCapacity,
            activeVolume
          };
        }
      }

      return {
        canClaim: true,
        driverCapacity,
        activeVolume,
        hasActiveJob,
        hasActiveRoute
      };
    },
    enabled: !!jobId,
    staleTime: 5000 // Cache for 5 seconds
  });
};
