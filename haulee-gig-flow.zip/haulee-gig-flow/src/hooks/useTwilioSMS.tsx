import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SendSMSParams {
  to: string;
  message: string;
  type?: 'verification' | 'notification' | 'mfa';
}

interface SendSMSResponse {
  success: boolean;
  message?: string;
  error?: string;
  sid?: string;
  status?: string;
}

export function useTwilioSMS() {
  const [sending, setSending] = useState(false);

  const sendSMS = async ({ to, message, type = 'notification' }: SendSMSParams): Promise<SendSMSResponse> => {
    setSending(true);
    
    try {
      console.log('Sending SMS via Twilio:', { to, type, messageLength: message.length });

      const { data, error } = await supabase.functions.invoke('send-sms', {
        body: {
          to,
          message,
          type,
        },
      });

      if (error) {
        console.error('Error invoking send-sms function:', error);
        toast.error('Failed to send SMS');
        return {
          success: false,
          error: error.message || 'Failed to send SMS',
        };
      }

      if (!data.success) {
        console.error('SMS sending failed:', data.error);
        toast.error(data.error || 'Failed to send SMS');
        return data;
      }

      console.log('SMS sent successfully:', data);
      toast.success('SMS sent successfully');
      return data;

    } catch (error) {
      console.error('Unexpected error sending SMS:', error);
      toast.error('Failed to send SMS');
      return {
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    } finally {
      setSending(false);
    }
  };

  const sendVerificationCode = async (phoneNumber: string, code: string) => {
    return sendSMS({
      to: phoneNumber,
      message: `Your verification code is: ${code}. Do not share this code with anyone.`,
      type: 'verification',
    });
  };

  const sendMFACode = async (phoneNumber: string, code: string) => {
    return sendSMS({
      to: phoneNumber,
      message: `Your MFA authentication code is: ${code}. This code expires in 10 minutes.`,
      type: 'mfa',
    });
  };

  const sendNotification = async (phoneNumber: string, message: string) => {
    return sendSMS({
      to: phoneNumber,
      message,
      type: 'notification',
    });
  };

  return {
    sendSMS,
    sendVerificationCode,
    sendMFACode,
    sendNotification,
    sending,
  };
}
