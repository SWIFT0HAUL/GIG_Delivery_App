import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface BrokerProfileData {
  personalInfo: {
    firstName: string;
    lastName: string;
    brokerageName: string;
    mcNumber: string;
    dotNumber: string;
    email: string;
    phone: string;
    dbaName?: string;
    einTaxId?: string;
    yearEstablished?: number | null;
    businessType?: string;
    address?: string;
    mailingAddress?: string;
    bondAmount?: number | null;
    bondCompany?: string;
    insuranceCompany?: string;
    insuranceExpiryDate?: string;
    serviceAreas?: string[];
  };
  paymentInfo: {
    paymentMethodType: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
  };
  accountStatus: {
    status: string;
    licenseVerification: string;
    memberSince: string;
    totalJobs: number;
  };
}

export function useBrokerProfileData() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState<BrokerProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    async function fetchBrokerData() {
      try {
        setLoading(true);
        setError(null);

        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;

        // Fetch broker profile
        const { data: brokerProfile, error: brokerError } = await supabase
          .from('broker_profiles')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (brokerError && brokerError.code !== 'PGRST116') {
          console.error('Error fetching broker profile:', brokerError);
        }

        // Fetch total jobs brokered
        const { count: totalJobs } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('broker_id', user.id);

        // Format address
        const formatAddress = (addr: any) => {
          if (!addr) return '';
          if (typeof addr === 'string') return addr;
          return `${addr.street_number || ''} ${addr.route || ''}, ${addr.city || ''}, ${addr.state || ''} ${addr.zip || ''}`.trim();
        };

        // Placeholder for task submissions - implement when task_submissions table is available
        const paymentData: any = {};

        const data: BrokerProfileData = {
          personalInfo: {
            firstName: profile?.full_name?.split(' ')[0] || '',
            lastName: profile?.full_name?.split(' ').slice(1).join(' ') || '',
            brokerageName: brokerProfile?.brokerage_name || '',
            mcNumber: brokerProfile?.mc_number || '',
            dotNumber: brokerProfile?.dot_number || '',
            email: user.email || '',
            phone: brokerProfile?.primary_contact_phone || profile?.phone || '',
            dbaName: brokerProfile?.dba_name || '',
            einTaxId: brokerProfile?.ein_tax_id || '',
            yearEstablished: brokerProfile?.year_established || null,
            businessType: brokerProfile?.business_type || '',
            address: formatAddress(brokerProfile?.physical_address) || '',
            mailingAddress: formatAddress(brokerProfile?.mailing_address) || '',
            bondAmount: brokerProfile?.bond_amount || null,
            bondCompany: brokerProfile?.bond_company || '',
            insuranceCompany: brokerProfile?.insurance_company || '',
            insuranceExpiryDate: brokerProfile?.insurance_expiry_date || '',
            serviceAreas: brokerProfile?.service_areas || [],
          },
          paymentInfo: {
            paymentMethodType: paymentData?.type || 'bank',
            bankName: paymentData?.bankName || '',
            accountNumber: paymentData?.accountNumber || '',
            routingNumber: paymentData?.routingNumber || '',
          },
          accountStatus: {
            status: profile?.is_active ? 'Active' : 'Inactive',
            licenseVerification: brokerProfile?.license_verified ? 'Verified' : 'Pending',
            memberSince: profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A',
            totalJobs: totalJobs || 0,
          },
        };

        setProfileData(data);
      } catch (err: any) {
        console.error('Error fetching broker profile data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchBrokerData();
  }, [user]);

  return { profileData, loading, error };
}
