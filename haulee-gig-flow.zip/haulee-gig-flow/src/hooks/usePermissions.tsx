import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

interface Permission {
  permission_name: string;
  permission_description: string;
  category: string;
}

export const usePermissions = () => {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSuperAdminRBAC, setIsSuperAdminRBAC] = useState(false);

  const fetchUserPermissions = async () => {
    if (!user?.id) {
      setPermissions([]);
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase.rpc('get_user_permissions', {
        _user_id: user.id
      });

      if (error) throw error;
      setPermissions(data || []);
    } catch (error) {
      console.error('Error fetching user permissions:', error);
      setPermissions([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUserPermissions();
  }, [user?.id]);

  useEffect(() => {
    const check = async () => {
      if (!user?.id) { setIsSuperAdminRBAC(false); return; }
      try {
        const { data } = await supabase.rpc('has_role', { _user_id: user.id, _role: 'super_admin' });
        setIsSuperAdminRBAC(Boolean(data));
      } catch (e) {
        console.error('Error checking super admin role:', e);
        setIsSuperAdminRBAC(false);
      }
    };
    check();
  }, [user?.id]);

  const hasPermission = (permissionName: string): boolean => {
    // Super admins always have all permissions
    if (isSuperAdminRBAC) return true;
    return permissions.some(p => p.permission_name === permissionName);
  };

  const hasAnyPermission = (permissionNames: string[]): boolean => {
    // Super admins always have all permissions
    if (isSuperAdminRBAC) return true;
    return permissionNames.some(permissionName => hasPermission(permissionName));
  };
  
  const hasAllPermissions = (permissionNames: string[]): boolean => {
    // Super admins always have all permissions
    if (isSuperAdminRBAC) return true;
    return permissionNames.every(permissionName => hasPermission(permissionName));
  };

  const getPermissionsByCategory = (category: string): Permission[] => {
    return permissions.filter(p => p.category === category);
  };

  return {
    permissions,
    loading,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    getPermissionsByCategory,
    refetch: fetchUserPermissions,
    isSuperAdmin: isSuperAdminRBAC
  };
};

// Permission check utility function for server operations
export const checkUserPermission = async (userId: string, permissionName: string): Promise<boolean> => {
  try {
    const { data, error } = await supabase.rpc('user_has_permission', {
      p_user_id: userId,
      p_permission_name: permissionName
    });

    if (error) throw error;
    return data || false;
  } catch (error) {
    console.error('Error checking user permission:', error);
    return false;
  }
};