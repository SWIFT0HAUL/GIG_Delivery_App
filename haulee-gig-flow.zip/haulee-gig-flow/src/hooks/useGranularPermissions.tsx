import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface Permission {
  permission_key: string;
  permission_name: string;
  description: string | null;
  resource_type: string | null;
  action_type: string | null;
}

export const useGranularPermissions = () => {
  const { user } = useAuth();
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  useEffect(() => {
    if (!user?.id) {
      setPermissions([]);
      setIsSuperAdmin(false);
      setLoading(false);
      return;
    }

    const fetchPermissions = async () => {
      try {
        setLoading(true);
        
        // Check if user is super admin first
        const { data: superAdminCheck } = await supabase.rpc('has_role', { 
          _user_id: user.id, 
          _role: 'super_admin' 
        });
        setIsSuperAdmin(Boolean(superAdminCheck));
        
        const { data, error } = await supabase
          .rpc('get_user_permissions', { _user_id: user.id });

        if (error) throw error;
        
        // Type assertion since the RPC function returns the correct structure
        setPermissions((data as unknown as Permission[]) || []);
        setError(null);
      } catch (err) {
        console.error('Error fetching permissions:', err);
        setError(err instanceof Error ? err.message : 'Failed to fetch permissions');
        setPermissions([]);
      } finally {
        setLoading(false);
      }
    };

    fetchPermissions();
  }, [user?.id]);

  const hasPermission = (permissionKey: string): boolean => {
    // Super admins always have all permissions
    if (isSuperAdmin) return true;
    return permissions.some(p => p.permission_key === permissionKey);
  };

  const hasAnyPermission = (permissionKeys: string[]): boolean => {
    // Super admins always have all permissions
    if (isSuperAdmin) return true;
    return permissionKeys.some(key => hasPermission(key));
  };

  const hasAllPermissions = (permissionKeys: string[]): boolean => {
    // Super admins always have all permissions
    if (isSuperAdmin) return true;
    return permissionKeys.every(key => hasPermission(key));
  };

  const getPermissionsByResource = (resourceType: string): Permission[] => {
    return permissions.filter(p => p.resource_type === resourceType);
  };

  const getPermissionsByAction = (actionType: string): Permission[] => {
    return permissions.filter(p => p.action_type === actionType);
  };

  const canCreate = (resourceType: string): boolean => {
    // Super admins can do everything
    if (isSuperAdmin) return true;
    return permissions.some(
      p => p.resource_type === resourceType && p.action_type === 'create'
    );
  };

  const canRead = (resourceType: string): boolean => {
    // Super admins can do everything
    if (isSuperAdmin) return true;
    return permissions.some(
      p => p.resource_type === resourceType && p.action_type === 'read'
    );
  };

  const canUpdate = (resourceType: string): boolean => {
    // Super admins can do everything
    if (isSuperAdmin) return true;
    return permissions.some(
      p => p.resource_type === resourceType && p.action_type === 'update'
    );
  };

  const canDelete = (resourceType: string): boolean => {
    // Super admins can do everything
    if (isSuperAdmin) return true;
    return permissions.some(
      p => p.resource_type === resourceType && p.action_type === 'delete'
    );
  };

  const canApprove = (resourceType: string): boolean => {
    // Super admins can do everything
    if (isSuperAdmin) return true;
    return permissions.some(
      p => p.resource_type === resourceType && p.action_type === 'approve'
    );
  };

  const canExport = (resourceType: string): boolean => {
    // Super admins can do everything
    if (isSuperAdmin) return true;
    return permissions.some(
      p => p.resource_type === resourceType && p.action_type === 'export'
    );
  };

  return {
    permissions,
    loading,
    error,
    hasPermission,
    hasAnyPermission,
    hasAllPermissions,
    getPermissionsByResource,
    getPermissionsByAction,
    canCreate,
    canRead,
    canUpdate,
    canDelete,
    canApprove,
    canExport,
    isSuperAdmin,
  };
};
