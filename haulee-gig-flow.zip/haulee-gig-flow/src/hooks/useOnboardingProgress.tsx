import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export interface OnboardingStatus {
  role: string;
  last_step: string;
  is_complete: boolean;
  is_approved: boolean;
  has_progress_record: boolean;
  next_action: string;
}

export const useOnboardingProgress = () => {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState<OnboardingStatus | null>(null);

  // Get current onboarding status
  const getStatus = useCallback(async () => {
    if (!user?.id) return null;
    
    try {
      setLoading(true);
      const { data, error } = await supabase
        .rpc('get_comprehensive_onboarding_status', { p_user_id: user.id })
        .single();

      if (error) {
        console.error('Error fetching onboarding status:', error);
        throw error;
      }

      setStatus({
        ...data,
        is_complete: data.onboarding_complete,
        has_progress_record: true,
        last_step: String(data.last_step || 0)
      });
      return data;
    } catch (error) {
      console.error('Error in getStatus:', error);
      return null;
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  // Update progress to a specific step
  const updateProgress = useCallback(async (step: string, isComplete: boolean = false) => {
    if (!user?.id) {
      throw new Error('User not authenticated');
    }

    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .rpc('update_onboarding_progress', {
          p_user_id: user.id,
          p_step_number: parseInt(step.replace(/\D/g, '')) || 1,
          p_mark_complete: isComplete
        });

      if (error) {
        console.error('Error updating onboarding progress:', error);
        throw error;
      }

      // Refresh status after update
      await getStatus();
      
      return data;
    } catch (error) {
      console.error('Error in updateProgress:', error);
      toast({
        title: "Error",
        description: "Failed to save progress. Please try again.",
        variant: "destructive",
      });
      throw error;
    } finally {
      setLoading(false);
    }
  }, [user?.id, getStatus]);

  // Mark onboarding as complete
  const completeOnboarding = useCallback(async (finalStep: string = 'complete') => {
    return await updateProgress(finalStep, true);
  }, [updateProgress]);

  // Get step-specific URL for redirection
  const getStepUrl = useCallback((step: string, role?: string) => {
    // Map steps to URL parameters or specific routes
    const stepMap: Record<string, string> = {
      'step_1_welcome': '?step=1',
      'step_2_personal': '?step=2', 
      'step_3_business': '?step=3',
      'step_4_documents': '?step=4',
      'step_5_payment': '?step=5',
      'step_6_tasks': '?step=6',
      'step_7_review': '?step=7',
    };

    const stepParam = stepMap[step] || '';
    return `/onboarding${stepParam}`;
  }, []);

  return {
    status,
    loading,
    getStatus,
    updateProgress,
    completeOnboarding,
    getStepUrl,
  };
};