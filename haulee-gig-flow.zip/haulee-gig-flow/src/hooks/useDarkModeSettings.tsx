import { useState, useEffect } from 'react';

export type DarkModeTarget = 'app' | 'maps' | 'both';

interface DarkModeSettings {
  appDarkMode: boolean;
  mapsDarkMode: boolean;
}

const STORAGE_KEY = 'dark-mode-settings';

export function useDarkModeSettings() {
  const [settings, setSettings] = useState<DarkModeSettings>(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
    return { appDarkMode: false, mapsDarkMode: false };
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
    
    // Apply app dark mode to document
    if (settings.appDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings]);

  const setAppDarkMode = (enabled: boolean) => {
    setSettings(prev => ({ ...prev, appDarkMode: enabled }));
  };

  const setMapsDarkMode = (enabled: boolean) => {
    setSettings(prev => ({ ...prev, mapsDarkMode: enabled }));
  };

  const setDarkModeFor = (target: DarkModeTarget, enabled: boolean) => {
    switch (target) {
      case 'app':
        setAppDarkMode(enabled);
        break;
      case 'maps':
        setMapsDarkMode(enabled);
        break;
      case 'both':
        setSettings({ appDarkMode: enabled, mapsDarkMode: enabled });
        break;
    }
  };

  return {
    appDarkMode: settings.appDarkMode,
    mapsDarkMode: settings.mapsDarkMode,
    setAppDarkMode,
    setMapsDarkMode,
    setDarkModeFor,
  };
}
