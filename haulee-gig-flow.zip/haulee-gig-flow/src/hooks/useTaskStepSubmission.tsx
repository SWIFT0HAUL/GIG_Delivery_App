import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface StepSubmission {
  step_number: number;
  submission_data: Record<string, any>;
  notes?: string;
}

export function useTaskStepSubmission(taskId: string) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [submissions, setSubmissions] = useState<Record<number, any>>({});

  const fetchSubmissions = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('task_step_submissions')
        .select('*')
        .eq('user_id', user.id)
        .eq('task_id', taskId);

      if (error) throw error;

      const submissionsMap: Record<number, any> = {};
      data?.forEach((sub: any) => {
        submissionsMap[sub.step_number] = sub;
      });
      setSubmissions(submissionsMap);
    } catch (error) {
      console.error('Error fetching submissions:', error);
    }
  };

  const submitStep = async (stepData: StepSubmission, totalSteps?: number) => {
    if (!user) {
      toast.error('You must be logged in');
      return false;
    }

    setLoading(true);
    try {
      const { error } = await supabase
        .from('task_step_submissions')
        .upsert({
          user_id: user.id,
          task_id: taskId,
          step_number: stepData.step_number,
          submission_data: stepData.submission_data,
          notes: stepData.notes,
          status: 'submitted'
        }, {
          onConflict: 'user_id,task_id,step_number'
        });

      if (error) throw error;

      toast.success('Step submitted successfully');
      await fetchSubmissions();

      // Auto-complete task if all steps are done
      if (totalSteps) {
        const { data: allSubmissions } = await supabase
          .from('task_step_submissions')
          .select('step_number')
          .eq('user_id', user.id)
          .eq('task_id', taskId);

        if (allSubmissions && allSubmissions.length === totalSteps) {
          // All steps completed - auto-complete the task
          const { error: updateError } = await supabase
            .from('task_assignments')
            .update({
              status: 'completed',
              completed_at: new Date().toISOString(),
              approval_status: 'pending_approval',
              updated_at: new Date().toISOString()
            })
            .eq('task_id', taskId)
            .eq('user_id', user.id);

          if (!updateError) {
            toast.success('Task auto-completed! Awaiting admin approval.');
          }
        }
      }

      // Update role-specific profile if task is role-related
      try {
        // Check which profile table the user has
        const profileChecks = await Promise.all([
          supabase.from('carrier_company_status').select('user_id').eq('user_id', user.id).maybeSingle(),
          supabase.from('broker_profiles').select('user_id').eq('user_id', user.id).maybeSingle(),
          supabase.from('shipper_profiles').select('user_id').eq('user_id', user.id).maybeSingle(),
          supabase.from('vendor_profiles').select('user_id').eq('user_id', user.id).maybeSingle(),
          supabase.from('driver_profiles').select('user_id').eq('user_id', user.id).maybeSingle()
        ]);

        const [carrierCheck, brokerCheck, shipperCheck, vendorCheck, driverCheck] = profileChecks;

        // Get task details to determine what to update
        const { data: task } = await supabase
          .from('custom_tasks')
          .select('name, category')
          .eq('id', taskId)
          .single();

        if (task) {
          const taskNameLower = task.name.toLowerCase();
          
          // Update carrier profile
          if (carrierCheck.data) {
            const updateData: any = {};
            
            if (taskNameLower.includes('insurance')) {
              updateData.insurance_verified = true;
              if (stepData.submission_data.insurance_company) updateData.insurance_company = stepData.submission_data.insurance_company;
              if (stepData.submission_data.policy_number) updateData.insurance_policy_number = stepData.submission_data.policy_number;
              if (stepData.submission_data.coverage_amount) updateData.insurance_coverage_limit = parseFloat(stepData.submission_data.coverage_amount);
              if (stepData.submission_data.expiry_date) updateData.insurance_expiry_date = stepData.submission_data.expiry_date;
            }

            if (taskNameLower.includes('vehicle') || taskNameLower.includes('registration')) {
              if (stepData.submission_data.vehicle_types) {
                updateData.vehicle_types = Array.isArray(stepData.submission_data.vehicle_types) 
                  ? stepData.submission_data.vehicle_types 
                  : [stepData.submission_data.vehicle_types];
              }
              if (stepData.submission_data.registration_numbers) {
                updateData.vehicle_registration_numbers = Array.isArray(stepData.submission_data.registration_numbers)
                  ? stepData.submission_data.registration_numbers
                  : [stepData.submission_data.registration_numbers];
              }
            }

            if (taskNameLower.includes('dot') || taskNameLower.includes('mc')) {
              if (stepData.submission_data.dot_number) updateData.dot_number = stepData.submission_data.dot_number;
              if (stepData.submission_data.mc_number) updateData.mc_number = stepData.submission_data.mc_number;
            }

            if (Object.keys(updateData).length > 0) {
              updateData.updated_at = new Date().toISOString();
              await supabase.from('carrier_company_status').upsert({ user_id: user.id, ...updateData }, { onConflict: 'user_id' });
            }
          }
          
          // Update broker profile
          if (brokerCheck.data) {
            const updateData: any = {};
            
            if (taskNameLower.includes('license') || taskNameLower.includes('mc')) {
              updateData.license_verified = true;
              if (stepData.submission_data.mc_number) updateData.mc_number = stepData.submission_data.mc_number;
            }

            if (taskNameLower.includes('bond')) {
              if (stepData.submission_data.bond_amount) updateData.bond_amount = parseFloat(stepData.submission_data.bond_amount);
              if (stepData.submission_data.bond_company) updateData.bond_company = stepData.submission_data.bond_company;
              if (stepData.submission_data.bond_policy_number) updateData.bond_policy_number = stepData.submission_data.bond_policy_number;
              if (stepData.submission_data.bond_expiry_date) updateData.bond_expiry_date = stepData.submission_data.bond_expiry_date;
            }

            if (Object.keys(updateData).length > 0) {
              updateData.updated_at = new Date().toISOString();
              await supabase.from('broker_profiles').upsert({ user_id: user.id, ...updateData }, { onConflict: 'user_id' });
            }
          }
          
          // Update driver profile
          if (driverCheck.data) {
            const updateData: any = {};
            
            if (taskNameLower.includes('license') || taskNameLower.includes('cdl')) {
              if (stepData.submission_data.license_number) updateData.license_number = stepData.submission_data.license_number;
              if (stepData.submission_data.license_expiry) updateData.license_expiry_date = stepData.submission_data.license_expiry;
              if (stepData.submission_data.cdl_number) updateData.cdl_number = stepData.submission_data.cdl_number;
              updateData.cdl_endorsed = true;
            }

            if (taskNameLower.includes('background')) {
              updateData.background_check_status = 'completed';
              updateData.background_check_date = new Date().toISOString();
            }

            if (taskNameLower.includes('medical')) {
              if (stepData.submission_data.medical_expiry) updateData.medical_card_expiry = stepData.submission_data.medical_expiry;
            }

            if (Object.keys(updateData).length > 0) {
              updateData.updated_at = new Date().toISOString();
              await supabase.from('driver_profiles').upsert({ user_id: user.id, ...updateData }, { onConflict: 'user_id' });
            }

            // Update vehicle/insurance tables if relevant
            if (taskNameLower.includes('vehicle')) {
              const vehicleData = {
                driver_id: user.id,
                make: stepData.submission_data.vehicle_make,
                model: stepData.submission_data.vehicle_model,
                year: stepData.submission_data.vehicle_year,
                license_plate: stepData.submission_data.license_plate,
                is_primary: true
              };
              await supabase.from('driver_vehicles').upsert(vehicleData);
            }

            if (taskNameLower.includes('insurance')) {
              const insuranceData = {
                driver_id: user.id,
                company: stepData.submission_data.insurance_company,
                policy_number: stepData.submission_data.policy_number,
                expiry_date: stepData.submission_data.expiry_date,
                is_active: true
              };
              await supabase.from('driver_insurance').upsert(insuranceData);
            }
          }
          
          // Update vendor profile
          if (vendorCheck.data) {
            const updateData: any = {};
            
            if (taskNameLower.includes('tax') || taskNameLower.includes('ein')) {
              updateData.tax_id_verified = true;
              if (stepData.submission_data.ein_tax_id) updateData.ein_tax_id = stepData.submission_data.ein_tax_id;
            }

            if (taskNameLower.includes('business') || taskNameLower.includes('verification')) {
              updateData.business_verified = true;
            }

            if (Object.keys(updateData).length > 0) {
              updateData.updated_at = new Date().toISOString();
              await supabase.from('vendor_profiles').upsert({ user_id: user.id, ...updateData }, { onConflict: 'user_id' });
            }
          }
        }
      } catch (profileError) {
        console.error('Error updating profile from task:', profileError);
        // Don't fail the task submission
      }

      return true;
    } catch (error: any) {
      console.error('Error submitting step:', error);
      toast.error(error.message || 'Failed to submit step');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const isStepCompleted = (stepNumber: number) => {
    return !!submissions[stepNumber];
  };

  const getStepSubmission = (stepNumber: number) => {
    return submissions[stepNumber];
  };

  return {
    loading,
    submissions,
    submitStep,
    isStepCompleted,
    getStepSubmission,
    fetchSubmissions
  };
}
