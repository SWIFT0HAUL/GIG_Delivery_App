import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { usePermissions } from './usePermissions';
import { useGranularPermissions } from './useGranularPermissions';
import { useUserRole } from './useUserRole';

interface AccessValidationResult {
  hasAccess: boolean;
  reason?: string;
  requiredPermission?: string;
  userRole?: string;
}

export const useSystemAccessValidation = () => {
  const { user } = useAuth();
  const { hasPermission, hasAnyPermission, hasAllPermissions, isSuperAdmin: isSuperAdminPerm } = usePermissions();
  const { 
    canCreate, 
    canRead, 
    canUpdate, 
    canDelete, 
    canApprove,
    isSuperAdmin: isSuperAdminGranular 
  } = useGranularPermissions();
  const { 
    isSuperAdmin: isSuperAdminRole, 
    isAdmin, 
    isApproved, 
    hasAdminAccess,
    profile 
  } = useUserRole();
  
  const [validationCache, setValidationCache] = useState<Record<string, AccessValidationResult>>({});

  // Unified super admin check
  const isSuperAdmin = isSuperAdminPerm || isSuperAdminGranular || isSuperAdminRole();

  // Validate route access
  const validateRouteAccess = async (route: string): Promise<AccessValidationResult> => {
    if (!user) {
      return { hasAccess: false, reason: 'Not authenticated' };
    }

    // Super admins have access to everything
    if (isSuperAdmin) {
      return { hasAccess: true };
    }

    // Check if user is approved
    if (!isApproved()) {
      return { hasAccess: false, reason: 'User not approved' };
    }

    // Route-specific validation
    const adminRoutes = ['/admin-dashboard', '/admin'];
    const requiresAdmin = adminRoutes.some(r => route.startsWith(r));

    if (requiresAdmin && !hasAdminAccess()) {
      return { hasAccess: false, reason: 'Admin access required', requiredPermission: 'admin' };
    }

    return { hasAccess: true };
  };

  // Validate task access
  const validateTaskAccess = async (
    taskId: string, 
    action: 'view' | 'submit' | 'approve' | 'edit' | 'delete'
  ): Promise<AccessValidationResult> => {
    if (!user) {
      return { hasAccess: false, reason: 'Not authenticated' };
    }

    if (isSuperAdmin) {
      return { hasAccess: true };
    }

    // Check task assignment
    const { data: assignment } = await supabase
      .from('task_assignments')
      .select('user_id, approval_status')
      .eq('task_id', taskId)
      .eq('user_id', user.id)
      .single();

    switch (action) {
      case 'view':
      case 'submit':
        if (!assignment) {
          return { hasAccess: false, reason: 'Task not assigned to user' };
        }
        return { hasAccess: true };
      
      case 'approve':
        if (!canApprove('task')) {
          return { hasAccess: false, reason: 'No approval permission', requiredPermission: 'task:approve' };
        }
        return { hasAccess: true };
      
      case 'edit':
        if (!canUpdate('task')) {
          return { hasAccess: false, reason: 'No edit permission', requiredPermission: 'task:update' };
        }
        return { hasAccess: true };
      
      case 'delete':
        if (!canDelete('task')) {
          return { hasAccess: false, reason: 'No delete permission', requiredPermission: 'task:delete' };
        }
        return { hasAccess: true };
      
      default:
        return { hasAccess: false, reason: 'Invalid action' };
    }
  };

  // Validate job access
  const validateJobAccess = async (
    jobId: string,
    action: 'view' | 'edit' | 'delete' | 'assign' | 'claim'
  ): Promise<AccessValidationResult> => {
    if (!user) {
      return { hasAccess: false, reason: 'Not authenticated' };
    }

    if (isSuperAdmin) {
      return { hasAccess: true };
    }

    const { data: job } = await supabase
      .from('jobs')
      .select('created_by, assigned_driver_id, status')
      .eq('id', jobId)
      .single();

    if (!job) {
      return { hasAccess: false, reason: 'Job not found' };
    }

    switch (action) {
      case 'view':
        if (canRead('job') || job.created_by === user.id || job.assigned_driver_id === user.id) {
          return { hasAccess: true };
        }
        return { hasAccess: false, reason: 'No view permission', requiredPermission: 'job:read' };
      
      case 'edit':
        if (!canUpdate('job') && job.created_by !== user.id) {
          return { hasAccess: false, reason: 'No edit permission', requiredPermission: 'job:update' };
        }
        return { hasAccess: true };
      
      case 'delete':
        if (!canDelete('job')) {
          return { hasAccess: false, reason: 'No delete permission', requiredPermission: 'job:delete' };
        }
        return { hasAccess: true };
      
      case 'assign':
        if (!hasPermission('job:assign') && !hasAdminAccess()) {
          return { hasAccess: false, reason: 'No assign permission', requiredPermission: 'job:assign' };
        }
        return { hasAccess: true };
      
      case 'claim':
        if (job.status !== 'pending' && job.status !== 'posted') {
          return { hasAccess: false, reason: 'Job not available for claiming' };
        }
        if (profile?.role_name !== 'driver') {
          return { hasAccess: false, reason: 'Only drivers can claim jobs' };
        }
        return { hasAccess: true };
      
      default:
        return { hasAccess: false, reason: 'Invalid action' };
    }
  };

  // Validate resource access (generic)
  const validateResourceAccess = (
    resource: string,
    action: 'create' | 'read' | 'update' | 'delete' | 'approve' | 'export'
  ): AccessValidationResult => {
    if (!user) {
      return { hasAccess: false, reason: 'Not authenticated' };
    }

    if (isSuperAdmin) {
      return { hasAccess: true };
    }

    let hasAccess = false;
    let permission = '';

    switch (action) {
      case 'create':
        hasAccess = canCreate(resource);
        permission = `${resource}:create`;
        break;
      case 'read':
        hasAccess = canRead(resource);
        permission = `${resource}:read`;
        break;
      case 'update':
        hasAccess = canUpdate(resource);
        permission = `${resource}:update`;
        break;
      case 'delete':
        hasAccess = canDelete(resource);
        permission = `${resource}:delete`;
        break;
      case 'approve':
        hasAccess = canApprove(resource);
        permission = `${resource}:approve`;
        break;
      case 'export':
        hasAccess = hasPermission(`${resource}:export`);
        permission = `${resource}:export`;
        break;
    }

    if (!hasAccess) {
      return { 
        hasAccess: false, 
        reason: `No ${action} permission for ${resource}`,
        requiredPermission: permission
      };
    }

    return { hasAccess: true };
  };

  // Validate admin panel access
  const validateAdminPanelAccess = (section: string): AccessValidationResult => {
    if (!user) {
      return { hasAccess: false, reason: 'Not authenticated' };
    }

    if (isSuperAdmin) {
      return { hasAccess: true };
    }

    if (!isApproved()) {
      return { hasAccess: false, reason: 'User not approved' };
    }

    if (!hasAdminAccess()) {
      return { hasAccess: false, reason: 'Admin access required' };
    }

    // Section-specific permissions
    const sectionPermissions: Record<string, string[]> = {
      'users': ['user:read', 'user:manage'],
      'jobs': ['job:read', 'job:manage'],
      'tasks': ['task:read', 'task:manage'],
      'finance': ['finance:read', 'finance:manage'],
      'settings': ['settings:read', 'settings:manage'],
      'reports': ['report:read', 'report:generate'],
    };

    const requiredPerms = sectionPermissions[section] || [];
    if (requiredPerms.length > 0 && !hasAnyPermission(requiredPerms)) {
      return {
        hasAccess: false,
        reason: `No permission for ${section}`,
        requiredPermission: requiredPerms.join(' or ')
      };
    }

    return { hasAccess: true };
  };

  // Validate KYC requirement
  const validateKYCRequirement = async (): Promise<AccessValidationResult> => {
    if (!user || isSuperAdmin) {
      return { hasAccess: true };
    }

    const { data: kycSubmission } = await supabase
      .from('kyc_submissions')
      .select('status')
      .eq('user_id', user.id)
      .single();

    if (!kycSubmission || kycSubmission.status !== 'approved') {
      return { 
        hasAccess: false, 
        reason: 'KYC verification required',
        requiredPermission: 'kyc:approved'
      };
    }

    return { hasAccess: true };
  };

  return {
    validateRouteAccess,
    validateTaskAccess,
    validateJobAccess,
    validateResourceAccess,
    validateAdminPanelAccess,
    validateKYCRequirement,
    isSuperAdmin,
    isAdmin: isAdmin(),
    isApproved: isApproved(),
    hasAdminAccess: hasAdminAccess(),
    userRole: profile?.role_name,
  };
};
