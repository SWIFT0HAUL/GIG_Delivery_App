import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface UserProfile {
  id: string;
  role_id: string | null;
  role_name: string | null;
  sub_role: string | null;
  onboarding_complete: boolean;
  is_approved: boolean;
}

export const useUserRole = () => {
  const { user } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = async () => {
    if (!user?.id) {
      setProfile(null);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          id,
          role_id,
          role_key,
          sub_role,
          onboarding_complete,
          is_approved
        `)
        .eq('id', user.id)
        .single();

      if (error) throw error;
      
      setProfile({
        id: data.id,
        role_id: data.role_id,
        role_name: data.role_key,
        sub_role: data.sub_role,
        onboarding_complete: data.onboarding_complete || false,
        is_approved: data.is_approved || false
      });
      setError(null);
    } catch (err) {
      console.error('Error fetching user profile:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch profile');
      setProfile(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, [user?.id]);

  const isRole = (roleName: string): boolean => {
    return profile?.role_name === roleName;
  };

  const isSuperAdmin = (): boolean => {
    return profile?.role_name === 'super_admin';
  };

  const isAdmin = (): boolean => {
    return profile?.role_name === 'admin' || profile?.role_name === 'super_admin';
  };

  const isApproved = (): boolean => {
    return profile?.is_approved === true;
  };

  const hasAdminAccess = (): boolean => {
    return isAdmin() && isApproved();
  };

  const hasSuperAdminAccess = (): boolean => {
    return isSuperAdmin() && isApproved();
  };

  return {
    profile,
    loading,
    error,
    isRole,
    isSuperAdmin,
    isAdmin,
    isApproved,
    hasAdminAccess,
    hasSuperAdminAccess,
    refetch: fetchProfile
  };
};