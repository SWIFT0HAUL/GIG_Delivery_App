import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { usePlatformEvents } from '@/contexts/PlatformEventsContext';
import { useAuth } from '@/contexts/AuthContext';

export function useRealtimeSync() {
  const { emit } = usePlatformEvents();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    console.log('🔄 Setting up realtime listeners for user:', user.id);

    // Listen to profile changes
    const profileChannel = supabase
      .channel('profile-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔄 Profile changed:', payload);

          if (payload.eventType === 'UPDATE') {
            const newProfile = payload.new as any;
            const oldProfile = payload.old as any;

            // Check for role changes
            if (oldProfile?.role_key !== newProfile?.role_key) {
              emit('ROLE_CHANGED', { old: oldProfile?.role_key, new: newProfile?.role_key });
            }

            // Check for approval status
            if (oldProfile?.is_approved !== newProfile?.is_approved) {
              if (newProfile?.is_approved) {
                emit('USER_APPROVED', newProfile);
              }
            }

            // Check for active status
            if (oldProfile?.is_active !== newProfile?.is_active) {
              if (newProfile?.is_active) {
                emit('USER_ACTIVATED', newProfile);
              } else {
                emit('USER_DEACTIVATED', newProfile);
              }
            }

            emit('PROFILE_UPDATED', newProfile);
          }

          if (payload.eventType === 'DELETE') {
            emit('AUTH_USER_DELETED', payload.old);
          }
        }
      )
      .subscribe();

    // Listen to user_roles changes
    const rolesChannel = supabase
      .channel('roles-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_roles',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔄 User role changed:', payload);
          emit('ROLE_CHANGED', payload.new);
        }
      )
      .subscribe();

    // Listen to notifications
    const notificationsChannel = supabase
      .channel('notifications-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔔 New notification:', payload);
          emit('NOTIFICATION_RECEIVED', payload.new);
        }
      )
      .subscribe();

    // Listen to admin_approvals
    const approvalsChannel = supabase
      .channel('approvals-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'admin_approvals',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔄 Approval status changed:', payload);
          if (payload.eventType === 'UPDATE' && payload.new) {
            const approval = payload.new as any;
            if (approval.status === 'approved') {
              emit('USER_APPROVED', approval);
            }
          }
        }
      )
      .subscribe();

    // Listen to job_assignments (driver's jobs)
    const jobAssignmentsChannel = supabase
      .channel('job-assignments-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'job_assignments',
          filter: `driver_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔄 Job assignment changed:', payload);
          emit('JOB_ASSIGNMENT_UPDATED', payload.new);
        }
      )
      .subscribe();

    // Listen to jobs table for driver's assigned jobs
    const jobsChannel = supabase
      .channel('jobs-realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'jobs',
          filter: `assigned_driver_id=eq.${user.id}`,
        },
        (payload) => {
          console.log('🔄 Job status changed:', payload);
          emit('JOB_STATUS_UPDATED', payload.new);
        }
      )
      .subscribe();

    return () => {
      console.log('🔄 Cleaning up realtime listeners');
      supabase.removeChannel(profileChannel);
      supabase.removeChannel(rolesChannel);
      supabase.removeChannel(notificationsChannel);
      supabase.removeChannel(approvalsChannel);
      supabase.removeChannel(jobAssignmentsChannel);
      supabase.removeChannel(jobsChannel);
    };
  }, [user, emit]);
}
