import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface EncryptedFinancialData {
  user_id: string;
  vendor_name: string;
  account_type: string;
  email: string;
  first_name: string;
  last_name: string;
  business_type?: string;
  business_address?: string;
  business_phone?: string;
  representative_name?: string;
  representative_title?: string;
  business_license?: string;
  tax_id_certificate?: string;
  insurance_proof?: string;
  task_background_check?: boolean;
  task_tutorial_videos?: boolean;
  task_contract_signing?: boolean;
  task_terms_policy?: boolean;
  task_other?: string;
  current_step?: string;
  status?: string;
  payment_method?: string;
  bank_name?: string;
  account_holder_name?: string;
  cardholder_name?: string;
  card_expiry?: string;
  review_notes?: string;
  created_at: string;
  updated_at: string;
  // Encrypted/masked financial data
  account_number?: string;
  routing_number?: string;
  card_number?: string;
  card_cvv?: string;
}

export function useEncryptedFinancialData() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  const encryptVendorData = async (vendorData: any) => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.functions.invoke('secure-financial-data', {
        body: {
          action: 'encrypt_vendor_data',
          data: { vendorData },
          userId: user.id
        }
      });

      if (error) throw error;

      if (!data.success) {
        throw new Error(data.error || 'Failed to encrypt financial data');
      }

      toast.success('Financial data encrypted and secured');
      return data;
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to encrypt financial data';
      setError(errorMessage);
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const decryptVendorData = async (vendorUserId: string, maskData: boolean = true): Promise<EncryptedFinancialData | null> => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.functions.invoke('secure-financial-data', {
        body: {
          action: 'decrypt_vendor_data',
          data: { vendorUserId, maskData },
          userId: user.id
        }
      });

      if (error) throw error;

      if (!data.success) {
        throw new Error(data.error || 'Failed to decrypt financial data');
      }

      return data.data;
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to decrypt financial data';
      setError(errorMessage);
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const migrateExistingData = async () => {
    if (!user) {
      throw new Error('User not authenticated');
    }

    try {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.functions.invoke('secure-financial-data', {
        body: {
          action: 'migrate_existing_data',
          data: {},
          userId: user.id
        }
      });

      if (error) throw error;

      if (!data.success) {
        throw new Error(data.error || 'Failed to migrate financial data');
      }

      toast.success(`Successfully encrypted ${data.migrated_count} vendor records`);
      
      if (data.errors && data.errors.length > 0) {
        console.warn('Migration errors:', data.errors);
        toast.warning(`${data.errors.length} records had encryption errors - check console for details`);
      }

      return data;
    } catch (err: any) {
      const errorMessage = err.message || 'Failed to migrate financial data';
      setError(errorMessage);
      toast.error(errorMessage);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    encryptVendorData,
    decryptVendorData,
    migrateExistingData
  };
}