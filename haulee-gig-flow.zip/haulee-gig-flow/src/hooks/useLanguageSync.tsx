import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

const languageMap: Record<string, string> = {
  'English': 'en',
  'Spanish': 'es',
  'Arabic': 'ar',
  'Mandarin': 'zh',
  'French': 'fr',
};

export function useLanguageSync() {
  const { i18n } = useTranslation();
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;

    const fetchLanguagePreference = async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('notification_preferences')
        .eq('id', user.id)
        .single();

      if (!error && data?.notification_preferences) {
        const prefs = data.notification_preferences as { language?: string };
        const preferredLanguage = prefs.language;
        if (preferredLanguage) {
          const languageCode = languageMap[preferredLanguage] || 'en';
          
          if (i18n.language !== languageCode) {
            i18n.changeLanguage(languageCode);
          }
        }
      }
    };

    fetchLanguagePreference();

    // Subscribe to profile changes
    const channel = supabase
      .channel('profile-language-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`,
        },
        (payload) => {
          const prefs = payload.new?.notification_preferences as { language?: string } | null;
          const newLanguage = prefs?.language;
          if (newLanguage) {
            const languageCode = languageMap[newLanguage] || 'en';
            i18n.changeLanguage(languageCode);
          }
        }
      )
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [user, i18n]);
}
