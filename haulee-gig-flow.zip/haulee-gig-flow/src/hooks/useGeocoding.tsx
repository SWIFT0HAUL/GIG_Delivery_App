import { useState } from 'react';
import { geocodeByPlaceId, geocodeByAddress, type GeocodeResult } from '@/lib/geocoding';
import { useToast } from '@/hooks/use-toast';

export function useGeocoding() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const geocodePlaceId = async (placeId: string): Promise<GeocodeResult | null> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await geocodeByPlaceId(placeId);
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to geocode place ID';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Geocoding Error',
        description: errorMessage,
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const geocodeAddress = async (address: string): Promise<GeocodeResult | null> => {
    setIsLoading(true);
    setError(null);
    
    try {
      const result = await geocodeByAddress(address);
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to geocode address';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Geocoding Error',
        description: errorMessage,
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    geocodePlaceId,
    geocodeAddress,
    isLoading,
    error,
  };
}
