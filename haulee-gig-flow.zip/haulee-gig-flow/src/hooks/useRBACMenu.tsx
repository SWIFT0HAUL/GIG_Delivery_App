import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface Menu {
  id: string;
  name: string;
  path: string;
  icon: string | null;
  category: string | null;
  display_order: number;
  is_active: boolean;
  display_mode?: 'normal' | 'hidden' | 'disabled';
}

export interface Permission {
  id: string;
  name: string;
  description: string | null;
}

export const useRBACMenu = () => {
  const { user } = useAuth();
  const [menus, setMenus] = useState<Menu[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);

  const fetchMenusAndPermissions = async () => {
    if (!user) {
      setMenus([]);
      setPermissions([]);
      setIsSuperAdmin(false);
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      
      // Check if user is super admin first
      const { data: superAdminCheck } = await supabase.rpc('has_role', { 
        _user_id: user.id, 
        _role: 'super_admin' 
      });
      const isSuperAdminUser = Boolean(superAdminCheck);
      setIsSuperAdmin(isSuperAdminUser);
      console.log('👑 Super admin status:', isSuperAdminUser);
      
      // Get user profile with role and sub_role
      const { data: profile } = await supabase
        .from('profiles')
        .select('role_id, role_key, sub_role')
        .eq('id', user.id)
        .single();

      // Super admins get ALL menus and permissions
      if (isSuperAdminUser) {
        console.log('👑 Super admin - granting access to ALL menus and permissions');
        
        // Get all active menus
        const { data: allMenus, error: menusError } = await supabase
          .from('menus')
          .select('*')
          .eq('is_active', true)
          .order('display_order');
        
        if (menusError) throw menusError;
        
        // Get all permissions
        const { data: allPermissions, error: permsError } = await supabase
          .from('permissions')
          .select('*');
        
        if (permsError) throw permsError;
        
        setMenus((allMenus || []) as Menu[]);
        setPermissions(allPermissions || []);
        setError(null);
        setLoading(false);
        return;
      }

      // Regular users: fetch based on role
      // Resolve role id (fallback to role_key if role_id is missing)
      let roleId = profile?.role_id as string | null;
      if (!roleId && profile?.role_key) {
        const { data: roleRow } = await supabase
          .from('roles')
          .select('id')
          .eq('role_key', profile.role_key)
          .maybeSingle();
        roleId = roleRow?.id ?? null;
      }

      if (!roleId) {
        setError('No role assigned');
        setLoading(false);
        return;
      }

      // Get role permissions
      const { data: rolePermissions } = await supabase
        .from('role_permissions')
        .select(`
          permission_id,
          permissions (
            id,
            name,
            description
          )
        `)
        .eq('role_id', roleId);

      const userPermissions = rolePermissions?.map(rp => rp.permissions).filter(Boolean) || [];

      // Get menus accessible by role
      const { data: roleMenuPerms } = await supabase
        .from('role_menu_permissions')
        .select(`
          menu_id,
          menus!inner (
            id,
            name,
            path,
            icon,
            category,
            display_order,
            is_active,
            display_mode
          )
        `)
        .eq('role_id', roleId)
        .eq('menus.is_active', true);

      let userMenus = (roleMenuPerms?.map(rmp => rmp.menus).filter(Boolean) || []) as any[];

      // If user has a sub_role, intersect with sub_role_menu_permissions
      if (profile?.sub_role) {
        const { data: subRoleMenuPerms } = await supabase
          .from('sub_role_menu_permissions')
          .select(`
            menu_id,
            menus!inner (
              id,
              name,
              path,
              icon,
              category,
              display_order,
              is_active,
              display_mode
            )
          `)
          .eq('sub_role', profile.sub_role)
          .eq('menus.is_active', true);

        const subRoleMenus = (subRoleMenuPerms?.map(rmp => rmp.menus).filter(Boolean) || []) as any[];
        
        // Create intersection: only show menus that exist in BOTH role and sub-role permissions
        const subRoleMenuIds = new Set(subRoleMenus.map(menu => menu.id));
        userMenus = userMenus.filter(menu => subRoleMenuIds.has(menu.id));
      }

      // Sort by display_order
      setMenus(userMenus.sort((a, b) => (a.display_order ?? 0) - (b.display_order ?? 0)) as any);
      setPermissions(userPermissions as any);
      setError(null);
    } catch (err) {
      console.error('Error fetching menus and permissions:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch
  useEffect(() => {
    fetchMenusAndPermissions();
  }, [user?.id]);

  // Real-time subscriptions
  useEffect(() => {
    if (!user) return;

    const channels = [
      supabase.channel('roles-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'roles' }, () => {
          fetchMenusAndPermissions();
        })
        .subscribe(),
      
      supabase.channel('permissions-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'permissions' }, () => {
          fetchMenusAndPermissions();
        })
        .subscribe(),
      
      supabase.channel('menus-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'menus' }, () => {
          fetchMenusAndPermissions();
        })
        .subscribe(),
      
      supabase.channel('role-permissions-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'role_permissions' }, () => {
          fetchMenusAndPermissions();
        })
        .subscribe(),
      
      supabase.channel('role-menu-permissions-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'role_menu_permissions' }, () => {
          fetchMenusAndPermissions();
        })
        .subscribe(),
      
      supabase.channel('sub-role-menu-permissions-changes')
        .on('postgres_changes', { event: '*', schema: 'public', table: 'sub_role_menu_permissions' }, () => {
          fetchMenusAndPermissions();
        })
        .subscribe()
    ];

    return () => {
      channels.forEach(channel => supabase.removeChannel(channel));
    };
  }, [user?.id]);

  return {
    menus,
    permissions,
    loading,
    error,
    isSuperAdmin,
    refetch: fetchMenusAndPermissions
  };
};