import { useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import {
  updateProfileAddress,
  getProfileAddress,
  updateJobPickupLocation,
  updateJobDeliveryLocation,
  type StoredAddress,
} from '@/lib/addressStorage';
import type { GeocodeResult } from '@/lib/geocoding';

export function useAddressStorage() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const saveProfileAddress = async (
    userId: string,
    address: GeocodeResult
  ): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      await updateProfileAddress(userId, address);
      toast({
        title: 'Address Saved',
        description: 'Your address has been saved successfully.',
      });
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to save address';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: errorMessage,
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const loadProfileAddress = async (userId: string): Promise<GeocodeResult | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const address = await getProfileAddress(userId);
      return address;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to load address';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: errorMessage,
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const saveJobPickup = async (
    jobId: string,
    address: StoredAddress
  ): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      await updateJobPickupLocation(jobId, address);
      toast({
        title: 'Pickup Location Saved',
        description: 'The pickup location has been saved successfully.',
      });
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to save pickup location';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: errorMessage,
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const saveJobDelivery = async (
    jobId: string,
    address: StoredAddress
  ): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      await updateJobDeliveryLocation(jobId, address);
      toast({
        title: 'Delivery Location Saved',
        description: 'The delivery location has been saved successfully.',
      });
      return true;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to save delivery location';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: errorMessage,
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    saveProfileAddress,
    loadProfileAddress,
    saveJobPickup,
    saveJobDelivery,
    isLoading,
    error,
  };
}
