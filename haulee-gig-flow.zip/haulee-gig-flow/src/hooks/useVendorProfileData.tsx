import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface VendorProfileData {
  personalInfo: {
    firstName: string;
    lastName: string;
    businessName: string;
    email: string;
    phone: string;
    storeAddress: string;
    dbaName?: string;
    einTaxId?: string;
    yearEstablished?: number | null;
    businessType?: string;
    mailingAddress?: string;
    deliveryRadius?: number | null;
    productCategories?: string[];
    businessHours?: any;
    bankName?: string;
    accountHolderName?: string;
  };
  paymentInfo: {
    paymentMethodType: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
  };
  accountStatus: {
    status: string;
    businessVerification: string;
    taxIdVerification: string;
    memberSince: string;
    totalOrders: number;
  };
}

export function useVendorProfileData() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState<VendorProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    async function fetchVendorData() {
      try {
        setLoading(true);
        setError(null);

        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;

        // Fetch vendor profile
        const { data: vendorProfile, error: vendorError } = await supabase
          .from('vendor_profiles')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (vendorError && vendorError.code !== 'PGRST116') {
          console.error('Error fetching vendor profile:', vendorError);
        }

        // Count vendor orders (assuming there's a vendor_orders or jobs table)
        const { count: ordersCount } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('vendor_id', user.id);

        // Format address
        const formatAddress = (addr: any) => {
          if (!addr) return '';
          if (typeof addr === 'string') return addr;
          return `${addr.street_number || ''} ${addr.route || ''}, ${addr.city || ''}, ${addr.state || ''} ${addr.zip || ''}`.trim();
        };

        // Placeholder for task submissions - implement when task_submissions table is available
        const paymentData: any = {};

        const data: VendorProfileData = {
          personalInfo: {
            firstName: profile?.full_name?.split(' ')[0] || '',
            lastName: profile?.full_name?.split(' ').slice(1).join(' ') || '',
            businessName: vendorProfile?.business_name || '',
            email: user.email || '',
            phone: vendorProfile?.primary_contact_phone || profile?.phone || '',
            storeAddress: formatAddress(vendorProfile?.store_address) || '',
            dbaName: vendorProfile?.dba_name || '',
            einTaxId: vendorProfile?.ein_tax_id || '',
            yearEstablished: vendorProfile?.year_established || null,
            businessType: vendorProfile?.business_type || '',
            mailingAddress: formatAddress(vendorProfile?.mailing_address) || '',
            deliveryRadius: vendorProfile?.delivery_radius_miles || null,
            productCategories: vendorProfile?.product_categories || [],
            businessHours: vendorProfile?.business_hours || null,
            bankName: vendorProfile?.bank_name || '',
            accountHolderName: vendorProfile?.account_holder_name || '',
          },
          paymentInfo: {
            paymentMethodType: paymentData?.type || 'credit',
            bankName: vendorProfile?.bank_name || paymentData?.bankName || '',
            accountNumber: paymentData?.accountNumber || '',
            routingNumber: paymentData?.routingNumber || '',
          },
          accountStatus: {
            status: profile?.is_active ? 'Active' : 'Inactive',
            businessVerification: vendorProfile?.business_verified ? 'Verified' : 'Pending',
            taxIdVerification: vendorProfile?.tax_id_verified ? 'Verified' : 'Pending',
            memberSince: profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A',
            totalOrders: ordersCount || 0,
          },
        };

        setProfileData(data);
      } catch (err: any) {
        console.error('Error fetching vendor profile data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchVendorData();
  }, [user]);

  return { profileData, loading, error };
}
