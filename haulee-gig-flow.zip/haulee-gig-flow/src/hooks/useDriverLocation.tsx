import { useState, useEffect, useRef } from 'react';
import { toast } from 'sonner';

export interface LocationCoordinates {
  lat: number;
  lng: number;
}

export interface DriverLocationState {
  coordinates: LocationCoordinates | null;
  isLoading: boolean;
  error: string | null;
  accuracy: number | null;
}

export function useDriverLocation() {
  const [state, setState] = useState<DriverLocationState>({
    coordinates: null,
    isLoading: true,
    error: null,
    accuracy: null,
  });
  
  const watchIdRef = useRef<number | null>(null);

  useEffect(() => {
    if (!navigator.geolocation) {
      setState({
        coordinates: null,
        isLoading: false,
        error: 'Geolocation is not supported by your browser',
        accuracy: null,
      });
      toast.error('Geolocation not supported');
      return;
    }

    const handleSuccess = (position: GeolocationPosition) => {
      setState({
        coordinates: {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        },
        isLoading: false,
        error: null,
        accuracy: position.coords.accuracy,
      });
    };

    const handleError = (error: GeolocationPositionError) => {
      let errorMessage = 'Failed to get location';
      
      switch (error.code) {
        case error.PERMISSION_DENIED:
          errorMessage = 'Location permission denied. Please enable location access.';
          break;
        case error.POSITION_UNAVAILABLE:
          errorMessage = 'Location information unavailable';
          break;
        case error.TIMEOUT:
          errorMessage = 'Location request timed out';
          break;
      }

      setState({
        coordinates: null,
        isLoading: false,
        error: errorMessage,
        accuracy: null,
      });
      toast.error(errorMessage);
    };

    // Get initial position with increased timeout and cached position allowed
    navigator.geolocation.getCurrentPosition(handleSuccess, handleError, {
      enableHighAccuracy: true,
      timeout: 30000, // 30 seconds for initial lock
      maximumAge: 60000, // Allow cached position up to 1 minute old
    });

    // Watch position for real-time updates
    watchIdRef.current = navigator.geolocation.watchPosition(
      handleSuccess,
      handleError,
      {
        enableHighAccuracy: true,
        timeout: 30000, // 30 seconds
        maximumAge: 5000, // Update every 5 seconds
      }
    );

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
    };
  }, []);

  return state;
}
