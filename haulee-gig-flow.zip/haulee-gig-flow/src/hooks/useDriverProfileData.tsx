import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface DriverProfileData {
  personalInfo: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: string;
    emergencyContact: string;
    preferredLanguage: string;
  };
  vehicleInfo: {
    make: string;
    model: string;
    year: string;
    color: string;
    licensePlate: string;
    vin: string;
    registrationExpiry: string;
  };
  insuranceInfo: {
    company: string;
    policyNumber: string;
    expiryDate: string;
    coverageAmount: string;
  };
  paymentInfo: {
    paymentMethodType: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
  };
  accountStatus: {
    status: string;
    backgroundCheck: string;
    driverLicense: string;
    insurance: string;
    vehicleRegistration: string;
    memberSince: string;
    totalDeliveries: number;
  };
}

export function useDriverProfileData() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState<DriverProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    async function fetchDriverData() {
      try {
        setLoading(true);
        setError(null);

        // Fetch profile data
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;

        // Fetch total completed deliveries
        const { count: totalDeliveries } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('assigned_driver_id', user.id)
          .eq('status', 'completed');

        // Fetch vehicle data
        const { data: vehicleData } = await supabase
          .from('driver_vehicles')
          .select('*')
          .eq('driver_id', user.id)
          .eq('is_primary', true)
          .single();

        // Fetch insurance data
        const { data: insuranceData } = await supabase
          .from('driver_insurance')
          .select('*')
          .eq('driver_id', user.id)
          .eq('is_active', true)
          .single();

        // Fetch payment method data
        const { data: paymentData } = await supabase
          .from('driver_payment_methods')
          .select('*')
          .eq('driver_id', user.id)
          .eq('is_primary', true)
          .single();

        // For now, determine status based on available data
        // Background check and driver license can be added via custom tasks later

        // Construct profile data
        const data: DriverProfileData = {
          personalInfo: {
            firstName: profile?.full_name?.split(' ')[0] || '',
            lastName: profile?.full_name?.split(' ').slice(1).join(' ') || '',
            email: user.email || '',
            phone: profile?.phone || '',
            address: profile?.full_address || '',
            emergencyContact: profile?.emergency_contact_name && profile?.emergency_contact_phone 
              ? `${profile.emergency_contact_name} - ${profile.emergency_contact_phone}`
              : '',
            preferredLanguage: (profile as any)?.notification_preferences?.language || 'English',
          },
          vehicleInfo: {
            make: vehicleData?.make || '',
            model: vehicleData?.model || '',
            year: vehicleData?.year || '',
            color: vehicleData?.color || '',
            licensePlate: vehicleData?.license_plate || '',
            vin: vehicleData?.vin || '',
            registrationExpiry: vehicleData?.registration_expiry || '',
          },
          insuranceInfo: {
            company: insuranceData?.company || '',
            policyNumber: insuranceData?.policy_number || '',
            expiryDate: insuranceData?.expiry_date || '',
            coverageAmount: insuranceData?.coverage_amount?.toString() || '',
          },
          paymentInfo: {
            paymentMethodType: paymentData?.payment_type || 'bank_account',
            bankName: paymentData?.bank_name || '',
            accountNumber: paymentData?.account_number_last4 ? `****${paymentData.account_number_last4}` : '',
            routingNumber: paymentData?.routing_number || '',
          },
          accountStatus: {
            status: profile?.is_active ? 'Active' : 'Inactive',
            backgroundCheck: 'Pending', // Can be updated via custom tasks
            driverLicense: vehicleData ? 'Verified' : 'Pending',
            insurance: insuranceData?.expiry_date ? (new Date(insuranceData.expiry_date) > new Date() ? 'Valid' : 'Expired') : 'Pending',
            vehicleRegistration: vehicleData?.registration_expiry ? (new Date(vehicleData.registration_expiry) > new Date() ? 'Valid' : 'Expired') : 'Pending',
            memberSince: profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A',
            totalDeliveries: totalDeliveries || 0,
          },
        };

        setProfileData(data);
      } catch (err: any) {
        console.error('Error fetching driver profile data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchDriverData();
  }, [user]);

  return { profileData, loading, error };
}
