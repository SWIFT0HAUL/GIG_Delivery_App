import { useState } from 'react';
import { geocodeByAddress } from '@/lib/geocoding';

export interface LocationWithCoords {
  address: string;
  city?: string;
  state?: string;
  zipCode?: string;
  lat: number;
  lng: number;
  [key: string]: string | number | undefined; // Index signature for Json compatibility
}

export function useJobLocationGeocoding() {
  const [isGeocoding, setIsGeocoding] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /**
   * Geocode an address string and return location object with coordinates
   */
  const geocodeLocation = async (
    addressString: string
  ): Promise<LocationWithCoords | null> => {
    if (!addressString) return null;

    setIsGeocoding(true);
    setError(null);

    try {
      const result = await geocodeByAddress(addressString);
      
      // Parse city, state, zip from formatted address if possible
      const parts = result.address.split(',').map(p => p.trim());
      let city, state, zipCode;
      
      if (parts.length >= 2) {
        // Last part usually contains state and zip
        const lastPart = parts[parts.length - 1];
        const stateZipMatch = lastPart.match(/([A-Z]{2})\s+(\d{5})/);
        if (stateZipMatch) {
          state = stateZipMatch[1];
          zipCode = stateZipMatch[2];
        }
        
        // Second to last is usually city
        if (parts.length >= 2) {
          city = parts[parts.length - 2];
        }
      }

      return {
        address: result.address,
        city,
        state,
        zipCode,
        lat: result.lat,
        lng: result.lng,
      };
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Geocoding failed';
      setError(errorMessage);
      console.error('Geocoding error:', err);
      return null;
    } finally {
      setIsGeocoding(false);
    }
  };

  /**
   * Ensure a location object has coordinates, geocoding if necessary
   */
  const ensureLocationHasCoords = async (
    location: any
  ): Promise<LocationWithCoords | null> => {
    // If already has coordinates, return as-is
    if (location?.lat && location?.lng) {
      return {
        address: location.address || '',
        city: location.city,
        state: location.state,
        zipCode: location.zipCode,
        lat: location.lat,
        lng: location.lng,
      };
    }

    // Build address string from available fields
    const addressString = location?.address || 
      [location?.city, location?.state, location?.zipCode]
        .filter(Boolean)
        .join(', ');

    if (!addressString) return null;

    return geocodeLocation(addressString);
  };

  return {
    geocodeLocation,
    ensureLocationHasCoords,
    isGeocoding,
    error,
  };
}
