import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useUserRole } from './useUserRole';

export interface JobPermissions {
  canView: boolean;
  canEdit: boolean;
  canCreate: boolean;
  canAssign: boolean;
  canCancel: boolean;
  canUpdateStatus: boolean;
  canAddNotes: boolean;
  canUpdateETA: boolean;
  canSendMessages: boolean;
  canViewKPIs: boolean;
  canManageAll: boolean;
}

export const useJobPermissions = () => {
  const { user } = useAuth();
  const { profile, isAdmin, isSuperAdmin } = useUserRole();
  const [permissions, setPermissions] = useState<JobPermissions>({
    canView: false,
    canEdit: false,
    canCreate: false,
    canAssign: false,
    canCancel: false,
    canUpdateStatus: false,
    canAddNotes: false,
    canUpdateETA: false,
    canSendMessages: false,
    canViewKPIs: false,
    canManageAll: false,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user?.id || !profile?.role_name) {
      setLoading(false);
      return;
    }

    const role = profile.role_name;

    // Define role-based permissions
    const rolePermissions: Record<string, Partial<JobPermissions>> = {
      super_admin: {
        canView: true,
        canEdit: true,
        canCreate: true,
        canAssign: true,
        canCancel: true,
        canUpdateStatus: true,
        canAddNotes: true,
        canUpdateETA: true,
        canSendMessages: true,
        canViewKPIs: true,
        canManageAll: true,
      },
      admin: {
        canView: true,
        canEdit: true,
        canCreate: true,
        canAssign: true,
        canCancel: true,
        canUpdateStatus: true,
        canAddNotes: true,
        canUpdateETA: true,
        canSendMessages: true,
        canViewKPIs: true,
        canManageAll: true,
      },
      broker: {
        canView: true,
        canEdit: true,
        canCreate: false,
        canAssign: true,
        canCancel: true,
        canUpdateStatus: true,
        canAddNotes: true,
        canUpdateETA: false,
        canSendMessages: true,
        canViewKPIs: true,
        canManageAll: false,
      },
      vendor: {
        canView: true,
        canEdit: false,
        canCreate: false,
        canAssign: false,
        canCancel: false,
        canUpdateStatus: true,
        canAddNotes: true,
        canUpdateETA: false,
        canSendMessages: true,
        canViewKPIs: false,
        canManageAll: false,
      },
      shipper: {
        canView: true,
        canEdit: false,
        canCreate: false,
        canAssign: false,
        canCancel: false,
        canUpdateStatus: false,
        canAddNotes: true,
        canUpdateETA: false,
        canSendMessages: true,
        canViewKPIs: false,
        canManageAll: false,
      },
      carrier: {
        canView: true,
        canEdit: false,
        canCreate: false,
        canAssign: false,
        canCancel: false,
        canUpdateStatus: true,
        canAddNotes: true,
        canUpdateETA: true,
        canSendMessages: true,
        canViewKPIs: false,
        canManageAll: false,
      },
      driver: {
        canView: true,
        canEdit: false,
        canCreate: false,
        canAssign: false,
        canCancel: false,
        canUpdateStatus: true,
        canAddNotes: true,
        canUpdateETA: true,
        canSendMessages: true,
        canViewKPIs: false,
        canManageAll: false,
      }
    };

    const defaultPermissions = {
      canView: true,
      canEdit: false,
      canCreate: false,
      canAssign: false,
      canCancel: false,
      canUpdateStatus: false,
      canAddNotes: false,
      canUpdateETA: false,
      canSendMessages: true,
      canViewKPIs: false,
      canManageAll: false,
    };

    setPermissions({
      ...defaultPermissions,
      ...rolePermissions[role]
    });
    setLoading(false);
  }, [user?.id, profile?.role_name]);

  // Use useUserRole functions instead of duplicating
  const isBroker = () => {
    return profile?.role_name === 'broker' || isAdmin();
  };

  return {
    permissions,
    userRole: profile?.role_name || '',
    loading,
    isAdmin, // From useUserRole
    isSuperAdmin, // From useUserRole
    isBroker,
  };
};