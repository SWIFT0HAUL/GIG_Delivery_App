import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export const useKYCStatus = () => {
  const { user } = useAuth();
  const [kycVerified, setKycVerified] = useState(false);
  const [kycStatus, setKycStatus] = useState<string>('not_submitted');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      checkKYCStatus();
    } else {
      setLoading(false);
    }
  }, [user]);

  const checkKYCStatus = async () => {
    try {
      // Check if user is super admin first
      const { data: profileData } = await supabase
        .from('profiles' as any)
        .select('kyc_status, role_key')
        .eq('id', user?.id)
        .single();

      if (profileData) {
        const profile = profileData as any;
        
        // Super admins bypass KYC
        if (profile.role_key === 'super_admin') {
          setKycVerified(true);
          setKycStatus('approved');
          setLoading(false);
          return;
        }
        
        setKycStatus(profile.kyc_status || 'not_submitted');
      }

      // For non-super admins, check KYC normally
      const { data, error } = await supabase.rpc('user_can_access_critical_features' as any, {
        _user_id: user?.id
      });

      if (error) throw error;
      
      setKycVerified(Boolean(data) || false);
    } catch (error) {
      console.error('Error checking KYC status:', error);
      setKycVerified(false);
      setKycStatus('not_submitted');
    } finally {
      setLoading(false);
    }
  };

  return {
    kycVerified,
    kycStatus,
    loading,
    refetch: checkKYCStatus
  };
};
