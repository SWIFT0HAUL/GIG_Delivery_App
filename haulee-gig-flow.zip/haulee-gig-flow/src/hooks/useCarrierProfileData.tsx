import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface CarrierProfileData {
  personalInfo: {
    firstName: string;
    lastName: string;
    companyName: string;
    dotNumber: string;
    mcNumber: string;
    email: string;
    phone: string;
    dbaName?: string;
    carrierType?: string;
    einTaxId?: string;
    yearEstablished?: number | null;
    operationType?: string;
    fleetSize?: number | null;
    driverCount?: number | null;
    address?: string;
    mailingAddress?: string;
    insuranceCompany?: string;
    insurancePolicyNumber?: string;
    insuranceCoverageType?: string;
    insuranceCoverageLimit?: number | null;
    insuranceExpiryDate?: string;
    vehicleTypes?: string[];
  };
  paymentInfo: {
    paymentMethodType: string;
    bankName: string;
    accountNumber: string;
    routingNumber: string;
  };
  accountStatus: {
    status: string;
    dotVerification: string;
    insurance: string;
    memberSince: string;
    complianceScore: number;
    totalJobs: number;
  };
}

export function useCarrierProfileData() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState<CarrierProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    async function fetchCarrierData() {
      try {
        setLoading(true);
        setError(null);

        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;

        // Fetch carrier company status with all fields
        const { data: carrierStatus, error: carrierError } = await supabase
          .from('carrier_company_status')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (carrierError && carrierError.code !== 'PGRST116') {
          console.error('Error fetching carrier status:', carrierError);
        }

        // Fetch total jobs
        const { count: totalJobs } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('carrier_id', user.id);

        // Format address from JSONB
        const formatAddress = (addr: any) => {
          if (!addr) return '';
          if (typeof addr === 'string') return addr;
          return `${addr.street_number || ''} ${addr.route || ''}, ${addr.city || ''}, ${addr.state || ''} ${addr.zip || ''}`.trim();
        };

        // Placeholder for task submissions - implement when task_submissions table is available
        const paymentData: any = {};

        const data: CarrierProfileData = {
          personalInfo: {
            firstName: profile?.full_name?.split(' ')[0] || '',
            lastName: profile?.full_name?.split(' ').slice(1).join(' ') || '',
            companyName: carrierStatus?.company_name || '',
            dotNumber: carrierStatus?.dot_number || '',
            mcNumber: carrierStatus?.mc_number || '',
            email: user.email || '',
            phone: carrierStatus?.primary_contact_phone || profile?.phone || '',
            dbaName: carrierStatus?.dba_name || '',
            carrierType: carrierStatus?.carrier_type || '',
            einTaxId: carrierStatus?.ein_tax_id || '',
            yearEstablished: carrierStatus?.year_established || null,
            operationType: carrierStatus?.operation_type || '',
            fleetSize: carrierStatus?.fleet_size || null,
            driverCount: carrierStatus?.driver_count || null,
            address: formatAddress(carrierStatus?.physical_address) || '',
            mailingAddress: formatAddress(carrierStatus?.mailing_address) || '',
            insuranceCompany: carrierStatus?.insurance_company || '',
            insurancePolicyNumber: carrierStatus?.insurance_policy_number || '',
            insuranceCoverageType: carrierStatus?.insurance_coverage_type || '',
            insuranceCoverageLimit: carrierStatus?.insurance_coverage_limit || null,
            insuranceExpiryDate: carrierStatus?.insurance_expiry_date || '',
            vehicleTypes: carrierStatus?.vehicle_types || [],
          },
          paymentInfo: {
            paymentMethodType: paymentData?.type || 'bank',
            bankName: paymentData?.bankName || '',
            accountNumber: paymentData?.accountNumber || '',
            routingNumber: paymentData?.routingNumber || '',
          },
          accountStatus: {
            status: profile?.is_active ? 'Active' : 'Inactive',
            dotVerification: carrierStatus?.dot_number ? 'Verified' : 'Pending',
            insurance: carrierStatus?.insurance_verified ? 'Current' : 'Pending',
            memberSince: profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A',
            complianceScore: carrierStatus?.compliance_score || 0,
            totalJobs: totalJobs || 0,
          },
        };

        setProfileData(data);
      } catch (err: any) {
        console.error('Error fetching carrier profile data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchCarrierData();
  }, [user]);

  return { profileData, loading, error };
}
