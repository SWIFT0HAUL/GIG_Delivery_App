import { useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';

export const useSessionAwareness = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  // Check if user still exists and is active
  const checkUserStatus = useCallback(async () => {
    if (!user?.id) return;

    try {
      const { data: profile, error } = await supabase
        .from('profiles')
        .select('is_active, is_approved, role_key')
        .eq('id', user.id)
        .single();

      if (error || !profile) {
        // User deleted
        toast({
          title: 'Account Deleted',
          description: 'Your account has been deleted. You will be signed out.',
          variant: 'destructive',
        });
        await signOut();
        navigate('/auth');
        return;
      }

      if (!profile.is_active) {
        // User deactivated
        toast({
          title: 'Account Deactivated',
          description: 'Your account has been deactivated. Please contact support.',
          variant: 'destructive',
        });
        await signOut();
        navigate('/auth');
        return;
      }

    } catch (error) {
      console.error('Error checking user status:', error);
    }
  }, [user?.id, signOut, navigate]);

  // Monitor profile changes
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel(`session-profile-changes-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`
        },
        async (payload) => {
          const newProfile = payload.new;

          // Check if user was deactivated or deleted
          if (newProfile.is_active === false) {
            toast({
              title: 'Account Deactivated',
              description: 'Your account has been deactivated.',
              variant: 'destructive',
            });
            await signOut();
            navigate('/auth');
          }

          // Check for role changes
          if (payload.old.role_key !== newProfile.role_key) {
            toast({
              title: 'Role Changed',
              description: `Your role has been changed to ${newProfile.role_key}`,
            });
            // Refresh the page to reload permissions
            window.location.reload();
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'profiles',
          filter: `id=eq.${user.id}`
        },
        async () => {
          toast({
            title: 'Account Deleted',
            description: 'Your account has been deleted.',
            variant: 'destructive',
          });
          await signOut();
          navigate('/auth');
        }
      )
      .subscribe();

    // Check status periodically (every 5 minutes)
    const interval = setInterval(checkUserStatus, 5 * 60 * 1000);

    return () => {
      supabase.removeChannel(channel);
      clearInterval(interval);
    };
  }, [user?.id]);

  // Monitor auth state changes
  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === 'TOKEN_REFRESHED') {
        console.log('Session token refreshed');
      }

      if (event === 'SIGNED_OUT') {
        navigate('/auth');
      }

      if (event === 'USER_UPDATED') {
        // Check if password change is required
        const metadata = session?.user?.user_metadata;
        if (metadata?.force_password_change) {
          toast({
            title: 'Password Change Required',
            description: 'Please change your password to continue.',
            variant: 'destructive',
          });
        }
      }
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [navigate]);

  return {
    checkUserStatus,
  };
};
