import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export interface ShipperProfileData {
  personalInfo: {
    firstName: string;
    lastName: string;
    companyName: string;
    email: string;
    phone: string;
    dbaName?: string;
    einTaxId?: string;
    yearEstablished?: number | null;
    businessType?: string;
    industry?: string;
    address?: string;
    mailingAddress?: string;
    billingContactName?: string;
    billingContactEmail?: string;
    shippingVolume?: number | null;
    preferredCarriers?: string[];
  };
  paymentInfo: {
    paymentMethodType: string;
    cardNumber: string;
    expiry: string;
    cvc: string;
  };
  accountStatus: {
    status: string;
    verification: string;
    memberSince: string;
    totalJobs: number;
  };
}

export function useShipperProfileData() {
  const { user } = useAuth();
  const [profileData, setProfileData] = useState<ShipperProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    async function fetchShipperData() {
      try {
        setLoading(true);
        setError(null);

        // Fetch profile data
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();

        if (profileError) throw profileError;

        // Fetch shipper profile
        const { data: shipperProfile, error: shipperError } = await supabase
          .from('shipper_profiles')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        if (shipperError && shipperError.code !== 'PGRST116') {
          console.error('Error fetching shipper profile:', shipperError);
        }

        // Fetch total jobs created
        const { count: totalJobs } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('shipper_id', user.id);

        // Format address
        const formatAddress = (addr: any) => {
          if (!addr) return '';
          if (typeof addr === 'string') return addr;
          return `${addr.street_number || ''} ${addr.route || ''}, ${addr.city || ''}, ${addr.state || ''} ${addr.zip || ''}`.trim();
        };

        // Placeholder for task submissions - implement when task_submissions table is available
        const paymentData: any = {};

        const data: ShipperProfileData = {
          personalInfo: {
            firstName: profile?.full_name?.split(' ')[0] || '',
            lastName: profile?.full_name?.split(' ').slice(1).join(' ') || '',
            companyName: shipperProfile?.company_name || '',
            email: user.email || '',
            phone: shipperProfile?.primary_contact_phone || profile?.phone || '',
            dbaName: shipperProfile?.dba_name || '',
            einTaxId: shipperProfile?.ein_tax_id || '',
            yearEstablished: shipperProfile?.year_established || null,
            businessType: shipperProfile?.business_type || '',
            industry: shipperProfile?.industry || '',
            address: formatAddress(shipperProfile?.physical_address) || '',
            mailingAddress: formatAddress(shipperProfile?.mailing_address) || '',
            billingContactName: shipperProfile?.billing_contact_name || '',
            billingContactEmail: shipperProfile?.billing_contact_email || '',
            shippingVolume: shipperProfile?.shipping_volume_monthly || null,
            preferredCarriers: shipperProfile?.preferred_carriers || [],
          },
          paymentInfo: {
            paymentMethodType: paymentData?.type || 'credit',
            cardNumber: paymentData?.cardNumber || '',
            expiry: paymentData?.expiry || '',
            cvc: paymentData?.cvc || '',
          },
          accountStatus: {
            status: profile?.is_active ? 'Active' : 'Inactive',
            verification: profile?.is_approved ? 'Verified' : 'Pending',
            memberSince: profile?.created_at ? new Date(profile.created_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A',
            totalJobs: totalJobs || 0,
          },
        };

        setProfileData(data);
      } catch (err: any) {
        console.error('Error fetching shipper profile data:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    }

    fetchShipperData();
  }, [user]);

  return { profileData, loading, error };
}
