import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { TimesheetApiExtended } from '@/lib/api/timesheet/timesheetApiExtended';
import { useToast } from '@/hooks/use-toast';
import { TimesheetEntry } from '@/components/admin/timesheet/types';

export const useTimesheet = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeSession, setActiveSession] = useState<TimesheetEntry | null>(null);
  const [loading, setLoading] = useState(true);
  const [elapsedTime, setElapsedTime] = useState<number>(0);

  // Fetch active session
  const fetchActiveSession = async () => {
    if (!user?.id) return;
    
    try {
      setLoading(true);
      const session = await TimesheetApiExtended.getActiveSession(user.id);
      setActiveSession(session);
      
      if (session) {
        const elapsed = Math.floor((Date.now() - new Date(session.clock_in).getTime()) / 1000);
        setElapsedTime(elapsed);
      }
    } catch (error) {
      console.error('Error fetching active session:', error);
    } finally {
      setLoading(false);
    }
  };

  // Clock in
  const clockIn = async (params?: { taskId?: string; jobId?: string; jobStage?: string; mileage?: number }) => {
    if (!user?.id) {
      toast({
        title: 'Error',
        description: 'You must be logged in to clock in',
        variant: 'destructive',
      });
      return;
    }

    try {
      await TimesheetApiExtended.clockIn({
        user_id: user.id,
        task_id: params?.taskId,
        job_id: params?.jobId,
        job_stage: params?.jobStage,
        mileage: params?.mileage,
      });
      
      toast({
        title: 'Success',
        description: 'Clocked in successfully',
      });
      
      await fetchActiveSession();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to clock in',
        variant: 'destructive',
      });
    }
  };

  // Clock out
  const clockOut = async (params?: { mileage?: number; waitTimeMinutes?: number; breakTimeMinutes?: number }) => {
    if (!activeSession) {
      toast({
        title: 'Error',
        description: 'No active session found',
        variant: 'destructive',
      });
      return;
    }

    try {
      await TimesheetApiExtended.clockOut({
        timesheet_id: activeSession.id,
        mileage: params?.mileage,
        wait_time_minutes: params?.waitTimeMinutes,
        break_time_minutes: params?.breakTimeMinutes,
      });
      
      toast({
        title: 'Success',
        description: 'Clocked out successfully',
      });
      
      setActiveSession(null);
      setElapsedTime(0);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message || 'Failed to clock out',
        variant: 'destructive',
      });
    }
  };

  // Format duration
  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Update elapsed time every second
  useEffect(() => {
    if (!activeSession) return;

    const interval = setInterval(() => {
      const elapsed = Math.floor((Date.now() - new Date(activeSession.clock_in).getTime()) / 1000);
      setElapsedTime(elapsed);
    }, 1000);

    return () => clearInterval(interval);
  }, [activeSession]);

  // Load active session on mount
  useEffect(() => {
    fetchActiveSession();
  }, [user?.id]);

  return {
    activeSession,
    loading,
    elapsedTime,
    clockIn,
    clockOut,
    formatDuration,
    refetch: fetchActiveSession,
  };
};