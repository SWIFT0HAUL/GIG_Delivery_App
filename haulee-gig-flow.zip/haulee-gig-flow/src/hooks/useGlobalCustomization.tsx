import { useEffect } from "react";
import { usePlatformSettings } from "@/contexts/PlatformSettingsContext";

// Global initializer: apply platform defaults immediately, then override with user-specific settings once auth is available.

function hexToHslTriple(hex: string | undefined): [number, number, number] | undefined {
  if (!hex) return undefined;
  let c = hex.replace("#", "");
  if (c.length === 3) c = c.split("").map((ch) => ch + ch).join("");
  if (c.length !== 6) return undefined;
  const r = parseInt(c.substring(0, 2), 16) / 255;
  const g = parseInt(c.substring(2, 4), 16) / 255;
  const b = parseInt(c.substring(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  let h = 0, s = 0, l = (max + min) / 2;
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    switch (max) {
      case r: h = (g - b) / d + (g < b ? 6 : 0); break;
      case g: h = (b - r) / d + 2; break;
      case b: h = (r - g) / d + 4; break;
    }
    h /= 6;
  }
  return [Math.round(h * 360), Math.round(s * 100), Math.round(l * 100)];
}

function hslString(hex?: string): string | undefined {
  const t = hexToHslTriple(hex);
  return t ? `${t[0]} ${t[1]}% ${t[2]}%` : undefined;
}

function applyCustomizationToDOM(settings: any) {
  if (!settings) return;
  
  console.log('🎨 Applying Platform Settings to DOM:', settings);
  
  const root = document.documentElement;

  // Apply Theme & Colors from platform_settings
  const primary = hslString(settings.primaryColor || settings.primary_color);
  const secondary = hslString(settings.secondaryColor || settings.secondary_color);
  const accent = hslString(settings.accentColor || settings.accent_color);
  const background = hslString(settings.backgroundColor || settings.background_color);
  const surface = hslString(settings.surfaceColor || settings.surface_color);
  const textPrimary = hslString(settings.textPrimary || settings.text_primary);
  const textSecondary = hslString(settings.textSecondary || settings.text_secondary);
  const borderColor = hslString(settings.borderColor || settings.border_color);

  console.log('🎨 Applying Colors:', { primary, secondary, accent, background });

  if (primary) {
    root.style.setProperty("--primary", primary);
    root.style.setProperty("--primary-foreground", "210 40% 98%");
  }
  if (secondary) {
    root.style.setProperty("--secondary", secondary);
    root.style.setProperty("--secondary-foreground", "222.2 47.4% 11.2%");
  }
  if (accent) {
    root.style.setProperty("--accent", accent);
    root.style.setProperty("--accent-foreground", "210 40% 98%");
  }
  if (background) {
    root.style.setProperty("--background", background);
  }
  if (surface) {
    root.style.setProperty("--card", surface);
    root.style.setProperty("--popover", surface);
  }
  if (textPrimary) {
    root.style.setProperty("--foreground", textPrimary);
  }
  if (textSecondary) {
    root.style.setProperty("--muted-foreground", textSecondary);
  }
  if (borderColor) {
    root.style.setProperty("--border", borderColor);
  }

  // Background settings
  const bgType = settings.backgroundType || settings.background_type;
  const bgGradient = settings.backgroundGradient || settings.background_gradient;
  const bgImage = settings.backgroundImage || settings.background_image;

  if (bgType === 'gradient' && bgGradient) {
    root.style.setProperty('background', bgGradient);
  } else if (bgType === 'image' && bgImage) {
    root.style.setProperty('background-image', `url(${bgImage})`);
    root.style.setProperty('background-size', 'cover');
    root.style.setProperty('background-position', 'center');
  }

  // Typography settings
  const fontFamily = settings.fontFamily || settings.font_family;
  const headingFont = settings.headingFont || settings.heading_font;
  const fontSize = settings.fontSize || settings.font_size;
  const headingSize = settings.headingSize || settings.heading_size;
  const lineHeight = settings.lineHeight || settings.line_height;
  const letterSpacing = settings.letterSpacing || settings.letter_spacing;
  const fontWeight = settings.fontWeight || settings.font_weight;

  if (fontFamily) root.style.setProperty("--font-sans", fontFamily);
  if (headingFont) root.style.setProperty("--font-heading", headingFont);
  if (typeof fontSize === "number") root.style.setProperty("--font-size-base", `${fontSize}px`);
  if (typeof headingSize === "number") root.style.setProperty("--font-size-heading", `${headingSize}px`);
  if (typeof lineHeight === "number") root.style.setProperty("--line-height", `${lineHeight}`);
  if (typeof letterSpacing === "number") root.style.setProperty("--letter-spacing", `${letterSpacing}px`);
  if (typeof fontWeight === "number") root.style.setProperty("--font-weight", `${fontWeight}`);

  // Layout settings
  const borderRadius = settings.borderRadius || settings.border_radius;
  const sidebarWidth = settings.sidebarWidth || settings.sidebar_width;
  const headerHeight = settings.headerHeight || settings.header_height;
  const contentPadding = settings.contentPadding || settings.content_padding;
  const maxContentWidth = settings.maxContentWidth || settings.max_content_width;

  if (typeof borderRadius === "number") root.style.setProperty("--radius", `${borderRadius}px`);
  if (typeof sidebarWidth === "number") root.style.setProperty("--sidebar-width", `${sidebarWidth}px`);
  if (typeof headerHeight === "number") root.style.setProperty("--header-height", `${headerHeight}px`);
  if (contentPadding) root.style.setProperty("--content-padding", contentPadding);
  if (maxContentWidth) root.style.setProperty("--max-content-width", maxContentWidth);

  // Animation settings
  const reduceMotion = settings.reduceMotion ?? settings.reduce_motion;
  const transitionSpeed = settings.transitionSpeed ?? settings.transition_speed;
  const animationsEnabled = settings.animationsEnabled ?? settings.animations_enabled;

  if (reduceMotion || !animationsEnabled) {
    root.style.setProperty("--transition-speed", `0ms`);
  } else if (typeof transitionSpeed === "number") {
    root.style.setProperty("--transition-speed", `${transitionSpeed}ms`);
  }

  // Gradient settings
  const gradientPrimary = settings.gradientPrimary ?? settings.gradient_primary;
  const gradientSecondary = settings.gradientSecondary ?? settings.gradient_secondary;
  if (gradientPrimary) root.style.setProperty("--gradient-primary", gradientPrimary);
  if (gradientSecondary) root.style.setProperty("--gradient-secondary", gradientSecondary);

  // Shadow settings
  const shadowIntensity = settings.shadowIntensity || settings.shadow_intensity;
  if (shadowIntensity) {
    const shadowValue = shadowIntensity === 'none' ? 'none' :
                       shadowIntensity === 'light' ? '0 1px 3px 0 rgb(0 0 0 / 0.1)' :
                       shadowIntensity === 'medium' ? '0 4px 6px -1px rgb(0 0 0 / 0.1)' :
                       '0 10px 15px -3px rgb(0 0 0 / 0.1)';
    root.style.setProperty("--shadow", shadowValue);
  }

  console.log('✅ Platform settings applied to DOM');
}

export function useGlobalCustomization() {
  const { settings } = usePlatformSettings();

  useEffect(() => {
    applyCustomizationToDOM(settings);
  }, [settings]);
}

