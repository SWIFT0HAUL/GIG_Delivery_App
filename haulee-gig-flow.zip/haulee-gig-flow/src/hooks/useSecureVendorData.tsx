import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export interface SecureVendorData {
  business_name: string;
  business_type: string;
  created_at: string;
  verification_status: 'pending' | 'approved' | 'rejected';
}

export interface FinancialData {
  has_bank_account: boolean;
  has_card: boolean;
  verification_status: 'pending' | 'approved' | 'rejected';
}

export interface FinancialAccessLog {
  id: string;
  user_id: string;
  accessed_by: string;
  data_type: string;
  action: string;
  ip_address?: unknown;
  metadata: any;
  created_at: string;
}

export function useSecureVendorData(vendorUserId?: string) {
  const [data, setData] = useState<SecureVendorData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    fetchSecureVendorData();
  }, [vendorUserId, user]);

  const fetchSecureVendorData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Use the secure function instead of direct table access
      const { data: result, error: fetchError } = await supabase
        .rpc('get_vendor_onboarding_secure', {
          _user_id: vendorUserId || null
        });

      if (fetchError) {
        throw fetchError;
      }

      setData(result || []);
    } catch (err: any) {
      console.error('Error fetching secure vendor data:', err);
      setError(err.message);
      toast.error('Failed to load vendor data');
    } finally {
      setLoading(false);
    }
  };

  return {
    data,
    loading,
    error,
    refetch: fetchSecureVendorData
  };
}

// Hook for admins to access full financial data (unmasked)
export function useVendorFinancialData(vendorUserId: string) {
  const [data, setData] = useState<FinancialData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchFinancialData = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data: result, error: fetchError } = await supabase
        .rpc('get_vendor_financial_data', {
          _user_id: vendorUserId
        });

      if (fetchError) {
        throw fetchError;
      }

      // RPC returns array, extract first element
      const financialData = Array.isArray(result) ? (result.length > 0 ? result[0] : null) : result;
      setData(financialData);
      toast.success('Financial data accessed (logged for audit)');
    } catch (err: any) {
      console.error('Error fetching financial data:', err);
      setError(err.message);
      toast.error('Failed to access financial data: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return {
    data,
    loading,
    error,
    fetchFinancialData
  };
}

// Hook for viewing financial access logs (admin only)
export function useFinancialAccessLogs() {
  const [logs, setLogs] = useState<FinancialAccessLog[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchLogs = async () => {
    try {
      setLoading(true);
      setError(null);

      const { data, error: fetchError } = await supabase
        .from('financial_data_access_log')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (fetchError) {
        throw fetchError;
      }

      setLogs(data || []);
    } catch (err: any) {
      console.error('Error fetching access logs:', err);
      setError(err.message);
      toast.error('Failed to load access logs');
    } finally {
      setLoading(false);
    }
  };

  return {
    logs,
    loading,
    error,
    fetchLogs
  };
}