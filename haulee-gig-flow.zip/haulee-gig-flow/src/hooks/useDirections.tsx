import { useState } from 'react';
import { getDirections, type DirectionsParams, type DirectionsResult, calculateTotals } from '@/lib/directions';
import { useToast } from '@/hooks/use-toast';

export function useDirections() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [directionsResult, setDirectionsResult] = useState<DirectionsResult | null>(null);
  const { toast } = useToast();

  const fetchDirections = async (params: DirectionsParams): Promise<DirectionsResult | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const result = await getDirections(params);
      setDirectionsResult(result);
      return result;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get directions';
      setError(errorMessage);
      toast({
        variant: 'destructive',
        title: 'Directions Error',
        description: errorMessage,
      });
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  const clearDirections = () => {
    setDirectionsResult(null);
    setError(null);
  };

  const getTotals = () => {
    if (!directionsResult) {
      return null;
    }
    return calculateTotals(directionsResult);
  };

  return {
    fetchDirections,
    clearDirections,
    getTotals,
    directionsResult,
    isLoading,
    error,
  };
}
